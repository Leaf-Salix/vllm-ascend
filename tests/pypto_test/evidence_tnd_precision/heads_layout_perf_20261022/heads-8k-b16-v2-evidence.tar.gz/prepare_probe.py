"""Adapt the accepted fixture/graph harness; performance precedes comparison."""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
OLD = HERE.parent/'dsv4-tnd-fixed-eight-l1-20261021/tools/probe_csa.py'
s = OLD.read_text()
s = s.replace('"""8K真实权重、Native/TND完整CSA FULL图验收；首差停止。"""',
              '"""完整CSA布局候选：先性能筛选，只有收益候选再对Native验精度。"""')
s = s.replace("from source_identity import source_identity", "from source_identity import source_identity\nfrom load_candidate import operators_for")
s = s.replace("'candidate_experiment':'accepted-Native-SK0-vs-QA168-fixed-precision-overlap'",
              "'candidate_experiment':'heads direct/packed vs preserved QA168 overlap; performance first'")
s = s.replace("source_record=source_identity()", """source_record=source_identity()
candidate_proof=json.loads((ROOT/'SOURCE.json').read_text())
report['isolated_candidates']=candidate_proof
for compile_arm in ('direct','packed'):
    receipt=json.loads((ROOT/('compile-'+compile_arm+'-receipt.json')).read_text())
    assert receipt['pass'] and receipt['device_execution'] is False and receipt['source']==source_record
    assert receipt['candidate_source_sha256']==hashlib.sha256((ROOT/'SOURCE.json').read_bytes()).hexdigest()
report['no_device_compile_pass']=True""")
s = s.replace("states, fixtures, rows, keepalive, b_states = {}, {}, {}, [], {}",
              "states, fixtures, rows, keepalive, b_states = {}, {}, {}, [], {}\npackets_by_arm = {}")
s = s.replace("for arm in ('native','candidate'):", "for arm in ('native','frozen','direct','packed'):")
s = s.replace("operators=(SerialOperators if arm=='serial' else CSAOperators).register()", "operators=operators_for(arm)")
s = s.replace("runtime=(SerialRuntime if arm=='serial' else CSAServiceRuntime)(layer.self_attn,operators,40,layer)",
              "runtime=CSAServiceRuntime(layer.self_attn,operators,40,layer)")
begin = s.index('        compiled_state=collect_state(f,output,topk)')
end = s.index('    def restore_readonly(fixture):',begin)
s = s[:begin] + '''        # Execution-validity checks only; no Native/PTO numerical comparison yet.
        restore(f);output.fill_(float('nan'));topk.fill_(-12345);graph.replay();torch.npu.synchronize()
        assert bool(torch.isfinite(output).all()),(arm,'nonfinite output')
        assert not bool((topk==-12345).any()),(arm,'unwritten TopK')
        guards=guard_checks(f)
        assert all(value['status']=='PASS' for value in guards.values()),(arm,'guard',guards)
        states[arm]=collect_state(f,output,topk)
        rows[arm]=(graph,f,output,topk)
        keepalive.append((compiled,module,owner,runtime))
        report['graphs'][arm]={'actual_acl_graph':True,'fullgraph':True,'options':options,
            'true_tokens':tokens,'graph_tokens':tokens,'guards':guards,'output_poison_written':True}
        if runtime is not None:
            assert guarded.calls>0,'PTO runtime was never invoked'
            schema=str(runtime.operators.attention._schema)
            expected={'frozen':'dsv4_csa_tnd_precision_spmd_overlap::attention',
                      'direct':'heads_direct_perf::attention','packed':'heads_packed_perf::attention'}[arm]
            assert schema.startswith(expected+'(') and schema.split(' -> ')[0].count('Tensor')==64,(arm,schema)
            report['graphs'][arm].update(root_schema=schema,pto_dispatch_calls=guarded.calls)
            packets_by_arm[arm]=(readonly_packets,packet_snapshots)
        save()
        print('ARM_CAPTURED_NO_ACCURACY_COMPARISON',arm,flush=True)
''' + s[end:]
begin = s.index("    report['cross_bucket_scope']=")
end = s.index('except Exception as exc:',begin)
s = s[:begin] + '''    report['test_order']='performance screening first; Native comparison only for winners'
    report['accuracy_executed']=False
    arms=('frozen','direct','packed')
    report['performance']={'event_windows':[],'l1_windows':[],'replays_per_event_window':100,
        'warmup':3,'dep_gen':False,'criterion':'event median >=1% faster and >=10/12 paired wins; L1 median also faster'}
    report['execution_checks']=[]
    def check_execution(arm,phase,repeat):
        graph,f,output,topk=rows[arm]
        assert bool(torch.isfinite(output).all()),(arm,phase,repeat,'nonfinite output')
        guards=guard_checks(f)
        assert all(g['status']=='PASS' for g in guards.values()),(arm,phase,repeat,guards)
        live,snapshots=packets_by_arm[arm]
        assert all(exact(v.cpu(),snapshots[k]) for k,v in live.items()),(arm,phase,repeat,'readonly packet')
        report['execution_checks'].append({'arm':arm,'phase':phase,'repeat':repeat,'guards':len(guards),'pass':True})
    for arm in arms:
        graph,f,output,topk=rows[arm]
        restore(f);restore_readonly(f);torch.npu.synchronize()
        for _ in range(3):graph.replay()
        torch.npu.synchronize()
        check_execution(arm,'warmup',0)
    # Each round changes order to balance clock and position effects.
    for repeat in range(12):
        order=list(arms[repeat%3:]+arms[:repeat%3])
        if repeat%2:order.reverse()
        for arm in order:
            graph,f,output,topk=rows[arm]
            restore(f);restore_readonly(f);torch.npu.synchronize()
            start=torch.npu.Event(enable_timing=True);end=torch.npu.Event(enable_timing=True)
            start.record()
            for _ in range(100):graph.replay()
            end.record();end.synchronize()
            value=start.elapsed_time(end)*1000/100
            report['performance']['event_windows'].append({'repeat':repeat,'arm':arm,'us':value})
            check_execution(arm,'event',repeat)
            print('EVENT_WINDOW',repeat,arm,value,flush=True)
    dfx_index=0
    for repeat in range(5):
        order=list(arms[repeat%3:]+arms[:repeat%3])
        if repeat%2:order.reverse()
        for arm in order:
            graph,f,output,topk=rows[arm]
            restore(f);restore_readonly(f);torch.npu.synchronize()
            pypto.torch.begin_dfx();graph.replay();pypto.torch.end_dfx()
            raw_path=args.out/'dfx'
            if dfx_index:raw_path=raw_path/f'window_{dfx_index}'
            raw_path=raw_path/'chip_swimlane_records.json'
            raw=json.loads(raw_path.read_text());records=raw['aicore_tasks'];frequency=raw['metadata']['clock_freq_hz']
            assert raw['chip_swimlane_level']==1 and frequency>0
            assert raw['metadata']['core_types']==['aic']*24+['aiv']*48
            assert raw['metadata']['dropped_run_boundaries']==0 and len(raw['metadata']['run_boundaries'])==1
            assert {r[0] for r in records}==set(range(72))
            assert all(len(r)==6 and 0<r[3]<=r[4] for r in records)
            span=(max(r[4] for r in records)-min(r[3] for r in records))*1e6/frequency
            report['performance']['l1_windows'].append({'repeat':repeat,'arm':arm,'us':span,'raw':str(raw_path)})
            check_execution(arm,'l1',repeat)
            print('L1_WINDOW',repeat,arm,span,flush=True)
            dfx_index+=1
    summary={}
    for arm in arms:
        event=[r['us'] for r in report['performance']['event_windows'] if r['arm']==arm]
        l1=[r['us'] for r in report['performance']['l1_windows'] if r['arm']==arm]
        summary[arm]={'event_us':event,'event_median_us':statistics.median(event),
                      'l1_us':l1,'l1_median_us':statistics.median(l1)}
        graph,f,output,topk=rows[arm]
        assert bool(torch.isfinite(output).all())
        assert all(g['status']=='PASS' for g in guard_checks(f).values()),(arm,'post-performance guards')
        live,snapshots=packets_by_arm[arm]
        assert all(exact(v.cpu(),snapshots[k]) for k,v in live.items()),(arm,'readonly packet')
    winners=[]
    for arm in ('direct','packed'):
        candidate=summary[arm];control=summary['frozen']
        improvement=1-candidate['event_median_us']/control['event_median_us']
        wins=sum(a<b for a,b in zip(candidate['event_us'],control['event_us'],strict=True))
        candidate.update(event_improvement=improvement,paired_event_wins=wins,
                         l1_improvement=1-candidate['l1_median_us']/control['l1_median_us'])
        if improvement>=0.01 and wins>=10 and candidate['l1_median_us']<control['l1_median_us']:
            winners.append(arm)
    report['performance']['summary']=summary
    report['performance']['winners']=winners
    report['timing_executed']=True
    save()
    print('PERFORMANCE_SCREEN_COMPLETE',json.dumps(summary),winners,flush=True)
    # Only after the performance result is persisted do we begin numerical A/B.
    for arm in (['native','frozen']+winners if winners else []):
        graph,f,output,topk=rows[arm]
        restore(f);restore_readonly(f);graph.replay();torch.npu.synchronize()
        actual=collect_state(f,output,topk)
        if arm=='native':
            reference=actual
        else:
            checks={name:metric(value,reference[name]) for name,value in actual.items()}
            report['comparisons'][arm]=checks;report['accuracy_executed']=True;save()
            if not all(m['bit_equal'] for m in checks.values()):
                report['first_failed_arm']=arm
                report['failed_boundaries']=[n for n,m in checks.items() if not m['bit_equal']]
                raise RuntimeError(arm+': first accuracy difference after performance; stop')
        before=f['hidden'].clone()
        restore(f);f['hidden'].add_(0.125);graph.replay();torch.npu.synchronize()
        b_states[arm]=collect_state(f,output,topk)
        if arm!='native':
            checks={name:metric(value,b_states['native'][name]) for name,value in b_states[arm].items()}
            report.setdefault('B_comparisons',{})[arm]=checks;save()
            if not all(m['bit_equal'] for m in checks.values()):raise RuntimeError(arm+': first B accuracy difference')
        f['hidden'].copy_(before);restore(f);graph.replay();torch.npu.synchronize()
        restored=collect_state(f,output,topk)
        assert all(exact(v,actual[n]) for n,v in restored.items()),(arm,'ABA')
        assert all(g['status']=='PASS' for g in guard_checks(f).values()),(arm,'precision guards')
        report['graphs'][arm]['live_input_ABA']=True
        save()
    report['accuracy_skipped_for']=[a for a in ('direct','packed') if a not in winners]
    report['complete']=True
    report['pass']=True
    save()
''' + s[end:]
ast.parse(s)
(HERE/'probe_perf.py').write_text(s)
names=('binding.json','source_identity.py','ragged_fixture.py','SOURCE.json','load_candidate.py',
       'probe_perf.py','heads_direct_root.py','heads_direct_sparse.py','heads_packed_root.py','heads_packed_oproj.py',
       'env.sh','run.sh','preflight.py','compile.sh','compile_candidate.py',
       'compile-direct-receipt.json','compile-packed-receipt.json')
(HERE/'manifest.json').write_text(json.dumps({n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in names},indent=2)+'\n')
