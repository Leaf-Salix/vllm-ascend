"""Prepare two isolated layout-only candidates from the preserved checkout."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
REPO = WORK / 'vllm-ascend-nalinaly-tnd-20261008-codex'
BASE = REPO / 'vllm_ascend/ops/pypto'
TOOLS = WORK / 'reports/dsv4-tnd-fixed-eight-l1-20261021/tools'
P = 'vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision'
F = 'vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision'
S = 'vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap'
sources = {
    'root': BASE/'deepseek_v4_flash_csa_tnd_precision_spmd_overlap/decode_csa.py',
    'sparse': BASE/'deepseek_v4_flash_csa_tnd_precision/decode_sparse_attn_csa.py',
    'oproj': BASE/'deepseek_v4_flash_csa_tnd_full_precision/o_proj.py',
}
original = {k:p.read_text() for k,p in sources.items()}

def replace_once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)

direct = replace_once(original['sparse'],
    'o_packed_heads: pl.Tensor[[O_GROUPS * T_PAD, O_GROUP_IN], pl.BF16],',
    'o_packed_heads: pl.Tensor[[T_DYN, H * HEAD_DIM], pl.BF16],')
direct = replace_once(direct,
    'n_pack_row = (m_h0 // HEADS_PER_GROUP) * T_PAD + m_t\n'
    '            n_pack_row_second = n_pack_row + T_PAD\n'
    '            pl.store(n_pack_first, [n_pack_row, 0], o_packed_heads)\n'
    '            pl.store(n_pack_second, [n_pack_row_second, 0], o_packed_heads)',
    'pl.store(n_pack_first, [m_t, m_h0 * HEAD_DIM], o_packed_heads)\n'
    '            pl.store(n_pack_second, [m_t, m_h0 * HEAD_DIM + O_GROUP_IN], o_packed_heads)')
direct = direct.replace('Write CSA heads as ``[group, T_PAD, O_GROUP_IN]`` slabs.',
                        'Write the same BF16 heads directly as Native [T, H*HEAD_DIM].')
direct = replace_once(direct,
    'Only the first runtime ``t_dim`` rows in each group are valid. The\n'
    '    returned task ID covers every write to the packed output tensor.',
    'Only runtime ``t_dim`` Native rows are written. The\n'
    '    returned task ID covers every write to the Native output tensor.')
root_a = replace_once(original['root'], f'from {P}.decode_sparse_attn_csa import sparse_attn_csa_tp1',
                      f'from {P}.heads_direct_sparse import sparse_attn_csa_tp1')
copy_block = ('        with pl.scope():\n'
              '            _published_heads = publish_native_heads(o_packed_heads, heads, t_dim, heads_dep)\n')
alloc = '        o_packed_heads = pl.create_tensor([O_GROUPS * T_PAD, O_GROUP_IN], dtype=pl.BF16)\n'
root_a = replace_once(root_a, alloc, '')
root_a = replace_once(root_a, 'o_packed_heads, heads_dep = sparse_attn_csa_tp1(', '_heads_result, heads_dep = sparse_attn_csa_tp1(')
root_a = replace_once(root_a, '            o_packed_heads,\n            32,', '            heads,\n            32,')
root_a = replace_once(root_a, copy_block, '')
root_a = replace_once(root_a, f'from {F}.heads import publish_native_heads\n', '')

# Replace each and only each heads input slice coordinate, leaving arithmetic,
# matmul shape, packet order and every non-heads expression unchanged.
packed = original['oproj']
tree = ast.parse(packed)
lines = packed.splitlines(keepends=True)
starts = [0]
for line in lines: starts.append(starts[-1] + len(line))
edits, addresses = [], []
for node in ast.walk(tree):
    if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute): continue
    if node.func.attr != 'slice' or not node.args or not isinstance(node.args[0], ast.Name) or node.args[0].id != 'heads': continue
    coords = node.args[2]
    row, col = coords.elts
    assert isinstance(col, ast.BinOp) and isinstance(col.op, ast.Add)
    group_product, offset = col.left, col.right
    assert isinstance(group_product, ast.BinOp) and isinstance(group_product.op, ast.Mult)
    assert isinstance(group_product.right, ast.Constant) and group_product.right.value == 4096
    group = ast.unparse(group_product.left)
    replacement = f'[{group} * T_PAD + {ast.unparse(row)}, {ast.unparse(offset)}]'
    edits.append((starts[coords.lineno-1]+coords.col_offset, starts[coords.end_lineno-1]+coords.end_col_offset, replacement))
    addresses.append({'old':ast.unparse(coords), 'new':replacement})
assert len(edits) == 11
for begin, end, replacement in sorted(edits, reverse=True): packed = packed[:begin] + replacement + packed[end:]
packed = replace_once(packed, 'T = pl.dynamic("FULL_PRECISION_OPROJ_T")',
                      'from ..deepseek_v4_flash_csa_tnd_precision.decode_csa import T_PAD\n\nT = pl.dynamic("FULL_PRECISION_OPROJ_T")')
packed = replace_once(packed, 'heads: pl.Tensor[[T, 32768], pl.BF16],',
                      'heads: pl.Tensor[[8 * T_PAD, 4096], pl.BF16],\n    tokens: pl.Scalar[pl.INDEX],')
packed = replace_once(packed, '    heads.bind_dynamic(0, T)\n', '')
packed = replace_once(packed, 'rows = pl.tensor.dim(heads, 0)', 'rows = tokens')
root_b = replace_once(original['root'], f'from {F}.o_proj import o_proj_entry', f'from {F}.heads_packed_oproj import o_proj_entry')
root_b = replace_once(root_b, f'from {F}.heads import publish_native_heads\n', '')
root_b = replace_once(root_b, '    heads = pl.create_tensor([tokens, H * HEAD_DIM], dtype=pl.BF16)',
                      '    o_packed_heads = pl.create_tensor([O_GROUPS * T_PAD, O_GROUP_IN], dtype=pl.BF16)')
root_b = replace_once(root_b, alloc, '')
root_b = replace_once(root_b, 'o_packed_heads, heads_dep = sparse_attn_csa_tp1(', '_packed_result, heads_dep = sparse_attn_csa_tp1(')
root_b = replace_once(root_b, copy_block, '')
root_b = replace_once(root_b, '            heads, wo_a, wo_b, wo_b_scale, oproj_start, projected_o, quantized_o, scale_o, attention_out',
                      '            o_packed_heads, tokens, wo_a, wo_b, wo_b_scale, oproj_start, projected_o, quantized_o, scale_o, attention_out')
outputs = {'heads_direct_sparse.py':('sparse',direct), 'heads_direct_root.py':('root',root_a),
           'heads_packed_oproj.py':('oproj',packed), 'heads_packed_root.py':('root',root_b)}
for name,(key,text) in outputs.items():
    ast.parse(text)
    (HERE/name).write_text(text)
    (HERE/(name+'.diff')).write_text(''.join(difflib.unified_diff(original[key].splitlines(True),text.splitlines(True),fromfile=str(sources[key]),tofile=name)))
for name in ('binding.json','ragged_fixture.py','source_identity.py'):
    shutil.copy2(TOOLS/name,HERE/name)
proof = {'formal_commit':'ed2b2e5c3c88a6d8682a6ad2ab8262686bcc2dc3',
         'baseline':{k:{'path':str(p.relative_to(REPO)), 'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in sources.items()},
         'candidates':{n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in outputs},
         'packed_address_changes':addresses, 'formal_source_unchanged':True}
(HERE/'SOURCE.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2))
