#!/usr/bin/env bash
set -euo pipefail
heads_job_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
arm=${1:?}
[[ "$arm" == direct || "$arm" == packed ]]
source "$heads_job_root/env.sh"
job="$heads_job_root"
export ASCEND_RT_VISIBLE_DEVICES=''
python "$job/preflight.py" > "$job/preflight-$arm.json"
ccache -s > "$job/ccache-$arm.txt"
timeout --signal=TERM --kill-after=15s 750s python "$job/compile_candidate.py" "$arm" > "$job/compile-$arm.log" 2>&1
