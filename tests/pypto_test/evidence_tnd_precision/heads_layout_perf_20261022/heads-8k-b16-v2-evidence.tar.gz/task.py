"""Submit once / observe once; no background watcher or scheduler."""
import json
import re
import shlex
import subprocess
import sys
from datetime import datetime
from pathlib import Path

HERE=Path(__file__).resolve().parent
REMOTE='/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/heads-perf-20261022-codex'
BASE='/data/pyptouser/yejia'
action,case=sys.argv[1:3]
assert re.fullmatch(r'heads-(8k|128k)-b[0-9]+-v[0-9]+',case)
receipt=HERE/(case+'-submission.json')
if action=='submit':
    assert not receipt.exists(),'Never retry an unknown submission'
    batch,history=map(int,sys.argv[3:5])
    assert 1<=batch<=40 and history in (8192,131072)
    args=['task-submit','--device','auto','--device-num','1','--ptoas','0.63','--max-time','780']
    env={
        'PYTHONNOUSERSITE':'1',
        'ASCEND_HOME_PATH':BASE+'/vllm-cann92-main/env/Ascend/cann-9.2.0-beta.2',
        'PTOAS_ROOT':BASE+'/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/reference-env/bin',
        'CCACHE_DIR':BASE+'/vllm-cann901-csa-0251rc1/src/pypto/.ccache',
        'CMAKE_BUILD_PARALLEL_LEVEL':'4',
    }
    for key,value in env.items():args+=['--env',key+'='+value]
    command=shlex.join([*args,f'bash {REMOTE}/run.sh {case} {batch} {history}'])
else:
    assert action=='observe'
    task=json.loads(receipt.read_text())['task_id']
    assert re.fullmatch(r'task_[0-9_]+',task)
    code="import json;from pathlib import Path;p=Path("+repr(REMOTE+'/results/'+case+'/result.json')+");r=json.loads(p.read_text()) if p.exists() else {};print(json.dumps({k:r.get(k) for k in ('complete','pass','error','accuracy_executed','accuracy_skipped_for')}));print(json.dumps(r.get('performance',{}).get('summary',{})))"
    command=f'task-submit --status {task}; tail -5 {REMOTE}/results/{case}-run.log 2>/dev/null; python3 -c '+shlex.quote(code)
result=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','pto227',command],capture_output=True,text=True,timeout=60)
if action=='submit':
    ids=re.findall(r'task_[0-9_]+',result.stdout)
    row={'case':case,'batch':batch,'history':history,'command':command,'submitted':datetime.now().isoformat(),
         'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr,
         'task_id':ids[0] if len(ids)==1 else None}
    receipt.write_text(json.dumps(row,indent=2)+'\n')
    print(json.dumps(row,indent=2))
    assert result.returncode==0 and row['task_id'],'Inspect queue before retry'
else:
    text=datetime.now().isoformat()+'\n'+result.stdout+result.stderr
    with (HERE/(case+'-observations.log')).open('a') as log:log.write(text+'\n')
    print(text)
    assert result.returncode==0
