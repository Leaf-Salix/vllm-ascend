#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
heads_job_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
case_name=${1:?}; batch=${2:?}; history=${3:?}
[[ "$case_name" =~ ^[a-z0-9-]+$ && "$batch" =~ ^[0-9]+$ && "$history" =~ ^[0-9]+$ ]]
source "$heads_job_root/env.sh"
job="$heads_job_root"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
out="$job/results/$case_name"
test ! -e "$out"
mkdir -p "$job/results"
python "$job/preflight.py" > "$out-preflight.json"
export ASCEND_CACHE_PATH="$out-ascend-cache" ASCEND_PROCESS_LOG_PATH="$out-ascend-log" VLLM_CACHE_ROOT="$out-vllm-cache"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out-opp-env")
lengths=6
for ((i=1;i<batch;i++)); do lengths+=,6; done
ccache -s > "$out-ccache.txt"
printf 'TASK_RUN_START %s\n' "$(date -Iseconds)"
trap 'printf "TASK_RUN_END %s\n" "$(date -Iseconds)"' EXIT
timeout --signal=TERM --kill-after=15s 750s python "$job/probe_perf.py" --out "$out" --lengths "$lengths" --layer 4 --history "$history" > "$out-run.log" 2>&1
