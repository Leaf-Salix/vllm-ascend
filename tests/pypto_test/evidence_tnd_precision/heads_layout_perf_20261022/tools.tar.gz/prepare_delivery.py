"""Publish only test documentation and reproducible textual evidence."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]/'vllm-ascend-nalinaly-tnd-20261008-codex'
DEST=REPO/'tests/pypto_test/evidence_tnd_precision/heads_layout_perf_20261022'
cases=('heads-8k-b16-v1','heads-8k-b16-v2','heads-128k-b24-v1')
checks=json.loads((HERE/'RECHECK.json').read_text())
assert set(checks)==set(cases) and all(v['pass'] for v in checks.values())
assert all(checks[c]['accuracy_executed'] for c in cases[:2])
assert checks[cases[-1]]['accuracy_executed'] is False and checks[cases[-1]]['winners']==[]
DEST.mkdir(exist_ok=False)
shutil.copy2(HERE/'REPORT.md',REPO/'tests/pypto_test/DSV4_FLASH_CSA_TND_HEADS_LAYOUT_PERFORMANCE_20261022.md')
for case in cases:shutil.copy2(HERE/(case+'-evidence.tar.gz'),DEST)
for name in ('RECHECK.json','STATIC_REVIEW.md'):shutil.copy2(HERE/name,DEST/name)
shutil.copy2(HERE/'verify_delivery.py',DEST/'verify.py')
with tarfile.open(DEST/'tools.tar.gz','w:gz') as archive:
    for p in sorted(HERE.iterdir()):
        if p.is_file() and (p.suffix in ('.py','.sh','.json','.diff') or p.name.endswith('-final-status.txt')):
            archive.add(p,arcname=p.name,recursive=False)
    for p in sorted(HERE.glob('orchestration-*/*.cpp')):archive.add(p,arcname=p.relative_to(HERE),recursive=False)
files=[p for p in DEST.iterdir() if p.name!='SHA256SUMS']
(DEST/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(files)))
print(DEST)
