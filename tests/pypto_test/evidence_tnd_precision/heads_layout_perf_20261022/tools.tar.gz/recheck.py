"""Recompute timing and qualification from collected textual evidence."""
import hashlib
import json
from pathlib import Path
import statistics
import sys

HERE=Path(__file__).resolve().parent
cases=sys.argv[1:]
assert cases
summary={}
for case in cases:
    evidence=HERE/('evidence-'+case)
    r=json.loads((evidence/'results'/case/'result.json').read_text())
    assert r['complete'] is True and r['pass'] is True
    assert r['no_device_compile_pass'] is True
    for name,digest in r['helper_sha'].items():
        assert hashlib.sha256((evidence/name).read_bytes()).hexdigest()==digest,name
    manifest=(evidence/'manifest.json').read_bytes()
    assert hashlib.sha256(manifest).hexdigest()==r['manifest_sha256']
    assert json.loads(manifest)==r['helper_sha']
    for arm in ('direct','packed'):
        receipt=json.loads((evidence/('compile-'+arm+'-receipt.json')).read_text())
        assert receipt['pass'] and receipt['npu_initialized'] is False
        assert receipt['candidate_source_sha256']==hashlib.sha256((evidence/'SOURCE.json').read_bytes()).hexdigest()
    assert r['timing_executed'] is True
    assert len(r['execution_checks'])==54
    assert all(v['pass'] and v['guards']==33 for v in r['execution_checks'])
    outputs={}
    for arm in ('frozen','direct','packed'):
        graph=r['graphs'][arm]
        assert graph['actual_acl_graph'] and graph['fullgraph'] and graph['pto_dispatch_calls']>0
        assert graph['root_schema'].split(' -> ')[0].count('Tensor')==64
        assert r['entry'][arm]['eligible'] and r['entry'][arm]['route']=='PTO'
        event=[v for v in r['performance']['event_windows'] if v['arm']==arm]
        raw=[v for v in r['performance']['l1_windows'] if v['arm']==arm]
        assert [v['repeat'] for v in event]==list(range(12))
        assert [v['repeat'] for v in raw]==list(range(5))
        l1=[]
        for row in raw:
            rel=row['raw'].split('/heads-perf-20261022-codex/',1)[1]
            trace=json.loads((evidence/rel).read_text())
            tasks=trace['aicore_tasks'];meta=trace['metadata']
            assert trace['chip_swimlane_level']==1 and len(meta['run_boundaries'])==1
            assert meta['dropped_run_boundaries']==0 and meta['clock_freq_hz']>0
            assert {t[0] for t in tasks}==set(range(72))
            value=(max(t[4] for t in tasks)-min(t[3] for t in tasks))*1e6/meta['clock_freq_hz']
            assert abs(value-row['us'])<1e-8
            l1.append(value)
        actual=r['performance']['summary'][arm]
        assert [x['us'] for x in event]==actual['event_us']
        assert l1==actual['l1_us']
        assert statistics.median(l1)==actual['l1_median_us']
        assert statistics.median([x['us'] for x in event])==actual['event_median_us']
        outputs[arm]={'event_median_us':actual['event_median_us'],'l1_median_us':actual['l1_median_us']}
    winners=[]
    for arm in ('direct','packed'):
        v=r['performance']['summary'][arm];f=r['performance']['summary']['frozen']
        gain=1-v['event_median_us']/f['event_median_us']
        wins=sum(a<b for a,b in zip(v['event_us'],f['event_us'],strict=True))
        assert gain==v['event_improvement'] and wins==v['paired_event_wins']
        if gain>=.01 and wins>=10 and v['l1_median_us']<f['l1_median_us']:winners.append(arm)
        outputs[arm].update(event_improvement=gain,paired_event_wins=wins,l1_improvement=v['l1_improvement'])
    assert winners==r['performance']['winners']
    assert r['accuracy_executed']==bool(winners)
    assert r['accuracy_skipped_for']==[a for a in ('direct','packed') if a not in winners]
    if not winners:
        assert not r['comparisons'] and not r.get('B_comparisons')
    if winners:
        for arm in ('frozen',*winners):
            for group in ('comparisons','B_comparisons'):
                assert len(r[group][arm])==8
                assert all(m['bit_equal'] and m['different_elements']==0 for m in r[group][arm].values())
            assert r['graphs'][arm]['live_input_ABA']
        assert r['graphs']['native']['live_input_ABA']
    summary[case]={'pass':True,'winners':winners,'accuracy_executed':r['accuracy_executed'],'results':outputs}
(HERE/'RECHECK.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
