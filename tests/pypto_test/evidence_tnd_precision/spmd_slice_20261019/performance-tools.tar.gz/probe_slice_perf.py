"""真实C4权重的Norm→WKV切片对拍；非完整CSA或整模型验收。"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import statistics

import torch
import torch_npu
import pypto.torch
import simpler
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
import vllm_ascend.ops.pypto as namespace
from dsv4_csa_native_case import native_session
from dsv4_csa_single_layer import make_layer

experiment = Path(os.environ['SPMD_EXPERIMENT'])
namespace.__path__.insert(0, str(experiment / 'src/vllm_ascend/ops/pypto'))
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.norm_wkv import precision_norm_wkv
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.input_norm import input_norm_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv import wkv_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv_order_data import (
    WKV_COLUMN_ORDERS, WKV_K_ORDERS, WKV_TOKEN_MODES,
)

parser = argparse.ArgumentParser()
parser.add_argument('--tokens', type=int, required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
assert 1 <= args.tokens <= 256 and args.tokens != 6, 'T6 needs separate static-profile qualification'
args.out.mkdir(parents=True, exist_ok=False)
report = {'complete': False, 'pass': False, 'tokens': args.tokens,
          'scope': 'real C4 weights, synthetic norm input, single Norm/WKV slice; direct ACLGraph, not vLLM FULL',
          'helper_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'comparisons': {}, 'cann': os.environ['ASCEND_HOME_PATH'], 'ptoas': os.environ['PTOAS_ROOT'],
          'pypto': pypto.__file__, 'simpler': simpler.__file__}
assert 'low-acceptance-20261010/runtime-package/pypto' in pypto.__file__
assert 'pypto-reference/runtime/python/simpler' in simpler.__file__
package = experiment / 'src/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision_spmd'
identity = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in package.glob('*.py')}
compiled_identity = json.loads((experiment / 'compile-slice.json').read_text())['sources']
assert identity == compiled_identity, 'source differs from successful no-device compilation'
report['candidate_sources'] = identity
control_package = Path(os.environ['SOURCE_ROOT']) / 'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision'
report['control_sources'] = {name: hashlib.sha256((control_package/name).read_bytes()).hexdigest()
                             for name in ('input_norm.py', 'wkv.py', 'wkv_order_data.py')}


def save():
    (args.out / 'result.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')

def require_exact(name, actual, expected):
    a, b = actual.contiguous().cpu(), expected.contiguous().cpu()
    if a.is_floating_point():
        assert bool(torch.isfinite(a).all()) and bool(torch.isfinite(b).all()), name+' nonfinite'
    equal = a.shape == b.shape and a.dtype == b.dtype and torch.equal(a.view(torch.uint8), b.view(torch.uint8))
    report['comparisons'][name] = {'bit_equal': equal, 'different_elements': int((a != b).sum()),
                                  'max_abs': float((a.float() - b.float()).abs().max())}
    save()
    if not equal:
        torch.save({'actual': a, 'expected': b}, args.out / 'first-difference.pt')
        raise RuntimeError('First bit difference at ' + name)

current_platform.pre_register_and_update()
torch.npu.set_device(0)
torch.npu.config.allow_internal_format = True
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
from vllm_ascend.utils import enable_custom_op
assert enable_custom_op()
checkpoint = Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config = EngineArgs(model=str(checkpoint), tokenizer_mode='deepseek_v4', trust_remote_code=True,
    tensor_parallel_size=1, dtype='bfloat16', quantization='ascend', hf_overrides={'sliding_window':128},
    max_model_len=16384, max_num_seqs=40, max_num_batched_tokens=256, enable_prefix_caching=False,
    enforce_eager=False, block_size=32,
    speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},
    compilation_config={'cudagraph_mode':'FULL_DECODE_ONLY','cudagraph_capture_sizes':[args.tokens],
                        'cache_dir':str(args.out/'vllm-cache')},
    additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,
        'fuse_norm_quant':True,'align_decode_capture_sizes':False},'enable_cpu_binding':False,
        'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,
        'enable_dsa_cp':False}).create_engine_config()
save()
with native_session(config, 0), torch.inference_mode():
    layer, details = make_layer(config, checkpoint, torch.device('npu:0'), 4)
    report['weights'] = details
    pypto.torch.init()
    norm_op = pypto.torch.register(input_norm_test, 'precision_spmd_control::norm')
    wkv_op = pypto.torch.register(wkv_test, 'precision_spmd_control::wkv')
    candidate = pypto.torch.register(precision_norm_wkv, 'precision_spmd_slice::run')
    t = args.tokens
    weight = layer.self_attn.wkv.weight.detach()
    report['weight_initial_format'] = torch_npu.get_npu_format(weight)
    # Match the preserved service's one-time layout conversion, without dtype changes.
    if torch_npu.get_npu_format(weight) not in (0, 2):
        weight = torch_npu.npu_format_cast(weight, 2)
    weight = weight.contiguous()
    report['weight_pto_format'] = torch_npu.get_npu_format(weight)
    require_exact('weight-layout-values', weight, layer.self_attn.wkv.weight.detach())
    gamma = layer.input_layernorm.weight.detach().contiguous()
    assert weight.dtype == torch.bfloat16 and weight.shape == (512, 4096)
    order = torch.tensor([WKV_K_ORDERS[i] for i in WKV_COLUMN_ORDERS[WKV_TOKEN_MODES[t-1]]],
                         dtype=torch.int32, device='npu:0')
    torch.manual_seed(1024)
    x_a = torch.randn(t, 4096, device='npu:0', dtype=torch.bfloat16)
    x_b = (x_a.float() * 1.125 + 0.03125).to(torch.bfloat16)
    x = x_a.clone()
    # Separate front/back guards; physical Cube writes may cover padding but not guards.
    allocations = []
    def guarded(rows, cols, dtype):
        storage = torch.full((rows+2, cols), 37, dtype=dtype, device='npu:0')
        allocations.append(storage)
        return storage[1:-1]
    normalized = guarded(t, 4096, torch.bfloat16)
    rstd = guarded(t, 8, torch.float32)
    accum = guarded(t+63, 512, torch.float32)
    output = guarded(t, 512, torch.bfloat16)
    ffts = torch.zeros(256, dtype=torch.int64, device='npu:0')
    assert accum.shape[0] >= ((t+63)//64)*64
    # Explicit permitted alias; all other inputs/workspaces have separate storage.
    accum_read = accum
    assert accum_read is accum  # the registered op must receive the same NPU Tensor object
    unique = [x, gamma, weight, order, normalized, rstd, accum, output, ffts]
    assert len({v.untyped_storage().data_ptr() for v in unique}) == len(unique)
    fixed = {name: value.clone() for name, value in [('gamma',gamma), ('weight',weight), ('order',order)]}
    def run():
        candidate(x, gamma, weight, order, normalized, rstd, accum, accum_read, output, ffts)
    run()
    torch.npu.synchronize()
    graph = torch.npu.NPUGraph()
    with torch.npu.graph(graph):
        run()
    torch.npu.synchronize()
    for label, data in [('A',x_a), ('B',x_b), ('A-restored',x_a)]:
        x.copy_(data)
        control_norm, control_rstd = torch.empty_like(normalized), torch.empty_like(rstd)
        norm_op(x, gamma, control_norm, control_rstd)
        control_output = torch.empty_like(output)
        wkv_op(control_norm, weight, order, control_output)
        native_norm = layer.input_layernorm(x)
        native_output = layer.self_attn.wkv(native_norm)
        if isinstance(native_output, tuple):
            native_output = native_output[0]
        torch.npu.synchronize()
        # Check the preserved control against actual Native first, before judging SPMD.
        require_exact(label+'/control-norm-vs-native', control_norm, native_norm)
        require_exact(label+'/control-wkv-vs-native', control_output, native_output)
        for repeat in range(3):
            normalized.fill_(float('nan')); rstd.fill_(float('nan'))
            accum.fill_(float('nan')); output.fill_(float('nan'))
            graph.replay(); torch.npu.synchronize()
            require_exact(f'{label}/{repeat}/norm', normalized, native_norm)
            require_exact(f'{label}/{repeat}/rstd', rstd, control_rstd)
            require_exact(f'{label}/{repeat}/wkv', output, native_output)
            require_exact(f'{label}/{repeat}/input', x, data)
            assert torch.isfinite(accum[:t]).all(), 'incomplete Cube output'
            for storage in allocations:
                assert bool((storage[0] == 37).all() and (storage[-1] == 37).all()), 'guard overwritten'
    for name, value in [('gamma',gamma), ('weight',weight), ('order',order)]:
        require_exact('readonly/'+name, value, fixed[name])
    # This is still only Norm->WKV, not full CSA/serving performance.
    control_graph = torch.npu.NPUGraph()
    with torch.npu.graph(control_graph):
        norm_op(x, gamma, control_norm, control_rstd)
        wkv_op(control_norm, weight, order, control_output)
    torch.npu.synchronize()
    native_graph = torch.npu.NPUGraph()
    with torch.npu.graph(native_graph):
        native_graph_norm = layer.input_layernorm(x)
        native_graph_output = layer.self_attn.wkv(native_graph_norm)
        if isinstance(native_graph_output, tuple):
            native_graph_output = native_graph_output[0]
    torch.npu.synchronize()
    graphs = {'native': native_graph, 'control': control_graph, 'spmd': graph}
    samples = {name: [] for name in graphs}
    orders = [('native', 'control', 'spmd'), ('spmd', 'native', 'control'), ('control', 'spmd', 'native')]
    for window in range(6):
        for arm in orders[window % 3]:
            begin, end = torch.npu.Event(enable_timing=True), torch.npu.Event(enable_timing=True)
            begin.record()
            for _ in range(50): graphs[arm].replay()
            end.record(); end.synchronize()
            samples[arm].append(begin.elapsed_time(end)*1000/50)
        require_exact(f'timing-window-{window}/native-norm', native_graph_norm, native_norm)
        require_exact(f'timing-window-{window}/native-wkv', native_graph_output, native_output)
        require_exact(f'timing-window-{window}/control-norm', control_norm, native_norm)
        require_exact(f'timing-window-{window}/control-wkv', control_output, native_output)
        require_exact(f'timing-window-{window}/spmd-norm', normalized, native_norm)
        require_exact(f'timing-window-{window}/spmd-wkv', output, native_output)
    require_exact('after-timing/norm', normalized, native_norm)
    require_exact('after-timing/rstd', rstd, control_rstd)
    require_exact('after-timing/wkv', output, native_output)
    require_exact('after-timing/input', x, x_a)
    for name, value in [('gamma',gamma), ('weight',weight), ('order',order)]:
        require_exact('after-timing/readonly/'+name, value, fixed[name])
    for storage in allocations:
        assert bool((storage[0] == 37).all() and (storage[-1] == 37).all()), 'after-timing guard overwritten'
    report['graph_replay_us'] = {
        arm: {'samples':values, 'median':statistics.median(values), 'min':min(values),
              'mean':statistics.mean(values), 'max':max(values)} for arm,values in samples.items()}
    report['timing_order'] = [orders[i % 3] for i in range(6)]
    report['timing_scope'] = 'Norm/WKV slice only; direct ACLGraph; 6 balanced windows x 50 replay, no discarded samples'
    report.update(complete=True, **{'pass':True})
    save()
    print('SPMD_SLICE_PASS', json.dumps(report['graph_replay_us']), flush=True)
