"""No-device compilation of the separate precision-SPMD slice."""

import hashlib
import json
import os
from pathlib import Path

import pypto
import simpler
from pypto.runtime import RunConfig

import vllm_ascend.ops.pypto as namespace

experiment = Path(os.environ["SPMD_EXPERIMENT"])
source = experiment / "src/vllm_ascend/ops/pypto"
namespace.__path__.insert(0, str(source))

from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.norm_wkv import precision_norm_wkv

assert "low-acceptance-20261010/runtime-package/pypto" in pypto.__file__
assert "pypto-reference/runtime/python/simpler" in simpler.__file__
assert os.environ["ASCEND_RT_VISIBLE_DEVICES"] == ""
assert os.environ.get("PTOAS_ROOT") and os.environ.get("ASCEND_HOME_PATH")
package = source / "deepseek_v4_flash_csa_tnd_precision_spmd"
record = {
    "scope": "Norm/WKV slice only; no hardware or complete CSA qualification",
    "hardware_executed": False,
    "pypto": pypto.__file__,
    "simpler": simpler.__file__,
    "sources": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in package.glob("*.py")},
}
print(json.dumps(record), flush=True)
compiled = precision_norm_wkv.compile(
    config=RunConfig(platform="a2a3", dump_passes=True, save_kernels=True, save_kernels_dir=str(experiment / "norm-wkv-artifact"))
)
# Exercise the exact kernel-mode ABI gate used by torch.register as well.
# This is a diagnostic call into the installed SDK, not a framework change.
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program

program = precision_norm_wkv.specialize()
abi = kernel_abi_for_program(program, platform="a2a3", runtime="tensormap_and_ringbuffer")
_kernel = _compile_impl(program, output_dir=str(experiment / "norm-wkv-kernel-artifact"),
                        platform="a2a3", dump_passes=True, _kernel_abi=abi)
record["kernel_mode_abi_pass"] = True
record.update(
    compiled=True,
    output_dir=str(compiled.output_dir),
    runtime=compiled.runtime_name,
    generated={
        str(p.relative_to(compiled.output_dir)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in Path(compiled.output_dir).rglob("*")
        if p.is_file() and p.suffix in (".cpp", ".py", ".json")
    },
)
(experiment / "compile-slice.json").write_text(json.dumps(record, indent=2) + "\n")
print("PRECISION_SPMD_SLICE_COMPILED", record["output_dir"], flush=True)
