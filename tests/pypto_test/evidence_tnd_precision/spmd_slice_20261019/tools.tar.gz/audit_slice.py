"""离线审计切片收据；不执行候选或NPU。"""
import argparse
import hashlib
import json
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('result',type=Path)
parser.add_argument('--source',type=Path,required=True)
args=parser.parse_args()
result=json.loads(args.result.read_text())
assert result['complete'] is True and result['pass'] is True
assert result['tokens'] in range(1,257)
assert 'not vLLM FULL' in result['scope']
identity={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in args.source.glob('*.py')}
assert identity == result['candidate_sources']
assert len(result['comparisons']) >= 53
assert all(c['bit_equal'] is True and c['different_elements']==0 and c['max_abs']==0 for c in result['comparisons'].values())
for phase in ('A','B','A-restored'):
    for suffix in ('control-norm-vs-native','control-wkv-vs-native'):
        assert result['comparisons'][phase+'/'+suffix]['bit_equal']
    for repeat in range(3):
        for stage in ('norm','rstd','wkv','input'):
            assert result['comparisons'][f'{phase}/{repeat}/{stage}']['bit_equal']
for stage in ('norm','rstd','wkv','input','readonly/gamma','readonly/weight','readonly/order'):
    assert result['comparisons']['after-timing/'+stage]['bit_equal']
assert 'runtime-package/pypto' in result['pypto']
assert 'pypto-reference/runtime/python/simpler' in result['simpler']
print(json.dumps({'audit_pass':True,'result_sha256':hashlib.sha256(args.result.read_bytes()).hexdigest(),
                  'tokens':result['tokens'],'checks':len(result['comparisons']),
                  'scope':'Norm/WKV BF16 vs Native, rstd vs control; not all FP32 intermediates or full CSA'},indent=2))
