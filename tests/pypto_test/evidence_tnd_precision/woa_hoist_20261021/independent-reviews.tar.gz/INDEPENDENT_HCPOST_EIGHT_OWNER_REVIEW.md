# HC-post八owner依赖：独立源与实际生成物审查

## 结论

**候选c9c944…未发现设备前阻断，可先唯一T126首差停止强对拍。** 本审查读取完整CPU编译/ABI16/Artifact.load回执及实际PTO/C++；尚未运行设备，不宣告数值或性能通过。候选独立从owner2派生，不叠加channelpreload/obowners，正式源与SDK未改。

记录修正已复核：postowners_probe的scope已准确写为“HC-post phase5 AIV producer waits”，不再继承WO-B标签。当前harness SHA已按修正后的实际文件绑定；候选数学未因标签修正改变。

## 实际依赖证明

parent dequant的block=worker+48i，每块16×512；给定row16块r，8个512列块的生产worker恰为 `(r*8+j)%48`，j=0…7。HC-post每块4token且t0=4×token_block，4整除16，尾部有效token也不跨16行边界。因此只需等待：

```text
post_owner=((t0//16)*8+j)%48
signal=(5*72+24+post_owner)*128
```

通过actual parent AST dequant outer range与row/col/valid赋值构建逐行512列写者表，再执行candidate实际HC-post t0和owner表达式。T1…256、48worker全部12288场景、263168个有效512列读取片段逐项匹配；每个token恰一次HC-post处理，8个owner唯一，tail都在合法有效行内。不是只将公式两边相等当证明。

publish5在生产者完成其**全部**dequant块并执行原bar_all/fence/cache维护后发布；等到这8槽即可读取本4token的全部4096列。其余Vector可能还在dequant其它行，但不会改写本段所读矩形。producer当前不等待HC-post消费者，且每core先完成自己的dequant并publish5才进入任何HC-post wait，因此无反向环/自身未发布等待。

producer仍先经历原全24AIC phase4等待，因此本候选的量化、scale和integer业务完成链均未精简；只改变HC-post何时可消费已就绪行。最后MIX任务完成仍覆盖所有core，下一调用不得并发复用同workspace。不能把本证明泛化到不同M/N分工或删掉publish5。

## 数学、缓存与实际执行

独立最小逆变换：删除post loop内新增8owner等待与三条acquire，恢复原loop前wait5，则整个Vector AST逐字恢复owner2；其它函数逐AST相同，仅cluster hint改名。HC-post 4-token原pipeline(stage2)、输入读取、乘法相加顺序及BF16边界均未动。

实际PTO1494行为每个token_block内部的post_dep=0…7；地址包含49152=(5×72+24)×128的相位基址。1506行是单INT32/GE TWAIT，1508…1510保留原GM payload acquire，之后才进入原HC-post pipeline及attended输入读取。没有把acquire提前到等待前或移出循环。

实际编排仍1个MIX{0,1,1}，24block/sync-start、split48AIV，原16Tensor/8InOut，没有新增workspace/rt_alloc。没有扩展大tile跨等待生存期；新增量主要是Scalar索引、等待和按块payload获取。CPU编译通过不替代NPU位比较。

## 调用数量与性能限制

| T | 原wait5调用 | 新调用 | 原payload acquire | 新acquire | 同worker重复已等owner调用 |
|---|---:|---:|---:|---:|---:|
|126|2304|256|48|32|0|
|240|2304|480|48|60|96|
|256|2304|512|48|64|128|

T>192时部分worker有第二个HC-post块，t0差192，相应producer集合模48后相同，故有重复ready等待。计数不代表失败轮询数或固定节省。初次不加去重状态，避免同时改变实现。

有些较早完成dequant的行可先做HC-post，其他行仍在反量化；因此同一AIV任务内关键路径可能改善，也可能因更多cache维护/Vector与MTE并发而恶化。不得把fence次数、已就绪wait数量简单换算延迟；不得将三项独立候选百分比相加。

## 设备验证

沿用独立frozen/owner2/new三臂、真实L4权重和同合成输入的五边界逐位/finite，A/B/A/毒化/guard/只读SHA、信号完整mask和代际1204、12×100同stream轮换，无DFX/PMU夹带计时。发现首差即停，先T126再据实判断T240；每任务<=780秒。这里只是后缀，未新增Native完整CSA/整模型/非等长metadata资格。

## 身份

```json
{
  "woa-pipeline-20261020/candidate-owner2.py": "399dbc67a1709a5e2fda636afb245d6e6478a5f1cec20763471caae6fd98e54b",
  "woa-hoist-20261021/candidate-postowners.py": "c9c944a8aa31405b5de1b3d220ef20000c832d127b7693d5b0814e075d734c29",
  "woa-hoist-20261021/candidate-postowners.json": "8a9263b45710752682c7f4e3e6f968fa037f80485eaa22b4d8c70c61775f929f",
  "woa-hoist-20261021/postowners_probe.py": "436551a84740847a52955ce01aaff26130ee360dfd51c03cd24b455fc441de43",
  "woa-hoist-20261021/generated-postowners/postowners/ptoas/resident_post_actual_owners.pto": "caa2ab78ffb494f32abb58d67932c23a5d31e076aab6d15b1f14f1d0ebe83a2f",
  "woa-hoist-20261021/generated-postowners/postowners/ptoas/resident_post_actual_owners.cpp": "c9e6f60b4a7c3eb9d0d8e3dc2341d210d9379631728d8b3873d0395e4401d85c",
  "woa-hoist-20261021/generated-postowners/postowners/orchestration/resident_suffix.cpp": "1d397840989413321106b6a03e188c8bc6c4a183299aaa99b26da51e144424d3",
  "woa-hoist-20261021/generated-postowners/postowners/kernel_config.py": "d28bf30ec2796bd2d0065be7fead91febbed0f41514b83acc7a1826566c8c541",
  "woa-hoist-20261021/generated-postowners/result.json": "97305ccf9b884cf90e8f1f9f531df43746cd95b66fce971d71bccfa61c3c0432"
}
```
