# 通道系数前移：独立源码与实际生成物审查

## 设备前结论

**未发现阻断，可按计划先做唯一T126首差停止对拍。** 这不是性能或数值硬件通过。此次只读审查候选9f601c…、原owner2 399dbc…、实际CPU完整编译产物；未修改候选、SDK/生成C++、正式源码或提交任务。

已有 `generated/result.json` 为完整PTOAS/CCEC、16Tensor注册、Artifact.load通过、device_execution=false。本报告同时读取实际PTO/C++，没有只依赖该PASS标签。

## 数学与索引证明

原dequant的block=worker+48×i，48能被8整除，因此每个worker的 `(block%8)*512 == (worker%8)*512`。wo_b_scale只读；前移的512个FP32通道、原full(1.0)和原col_expand_mul只依赖worker，完全不依赖integer_accum、token_scale、phase4结果。

独立对候选AST逆变换：只将3个原表达式恢复到原dequant loop位置、删除新增channel_col别名，vector全函数AST回到parent；其余函数全相同，仅cluster hint改名用于候选身份。保留原 `1×channel → coefficient_channel×token_scale → FP32(integer)×coefficient → BF16 rint` 顺序；没有合并、重关联、删除乘1或预读token_scale。即使某些数值下乘1可简化，也不借此增加新数值变化。

CPU枚举T1…256、48worker和所有block，列恒定、512列加载区间0…4096、有效行与尾部、每block唯一owner均通过。16×512系数采用原full有效形状；消费端仍用真实valid行，不给尾行新增store。

当前候选对全部48worker无条件前移。T1…80有未参与dequant的worker也进行只读系数计算：地址仍在4096通道内，且同8组scale本来均被有效worker读取，因此不是越界，但增加短T工作量。T81起全部48worker活跃；T126原64次系数生成变48次（16个worker有2块），T240原120次变48次（24个worker有3块）。本轮T126/T240不含未活跃worker额外数量，但不据此保证短T性能。

## 跨等待与实际UB别名

当前PTO明确：1436行从wo_b_scale加载，1441行原TCOLEXPANDMUL，1447行才进入phase4 TWAIT；不是仅在Python源中前移，实际生成体也在等待之前。

| 活值/暂存 | UB字节区间 | 结论 |
|---|---|---|
|hoisted coefficient_channel|[0,32768)|等待及全部dequant迭代中只读|
|ob_integer、cast、ob_scaled等可复用暂存|[32768,65536)|不覆盖常驻系数|
|每块coefficient|[65536,98304)|row_expand_mul新输出|
|token_scale tile|98304起|仍在等待后按真实row读取|

初始coefficient_one与coefficient_channel同址是原逐元素乘法允许的in-place复用；**后续row_expand_mul输出现在是65536，而非0**，因此不会把常驻channel乘上第一块scale后污染后续块。独立检查dequant loop没有addr0分配/写输出。实际C++对应v422@0只读，v467@65536是TROWEXPANDMUL目的；不是只看逻辑变量名。

preload的1×512通道载入在32768，随后可复用给ob_integer。实际生成有MTE2→V event4保证载入后再扩展；扩展后V→MTE2 event6，并在phase4 wait结束后wait该event再复用输入缓冲。保留常量本身不与这些复用暂存重叠。

wait_group内cacheinvalid在PTO标记为GM，C++是ENTIRE_DATA_CACHE DCCI；UB的Vec tile是独立片上存储，不因DCache失效被清除。fence/PIPE_ALL会影响何时完成，不改变已存UB值。仍需硬件五边界检测编译/别名实际风险，尤其T126多迭代覆盖。

不能把32KiB常驻视为免费：它缩短了其它暂存可复用的范围，可能提高UB压力/改变寄存器和事件编排。完整CCEC已过说明当前构建能容纳，但不证明延迟收益；没有根据逻辑tile简单求和冒报整个kernel峰值。前移的只读load/Vector指令也与WO-B并发，可能发生资源竞争。

## 协议、任务与对拍范围

publish3保持在前移之前，未延迟AIC等待量化完成的放行点；phase4全部24owner等待、原payload fence/cacheinvalid/fence、通知顺序、owner集合、phase槽及每调用一次代际均不变。当前实际编排仍1个MIX、24block、sync_start、split AIV48，16Tensor ABI/原8InOut，未增加rt_alloc或workspace。

channelpreload_probe明确parent=owner2、candidate自身路径/SHA、祖先链与冻结模块身份；沿用三臂frozen/owner2/new、同输入五边界、A/B/A、NaN/整数反码毒化、外层guard、只读SHA、完整信号mask和最终1204代、12×100轮换计时，首差停止。这里的金值仍是冻结PTO后缀，不是新增Native整层/真实模型验收，也不新增非等长metadata资格。

先T126能覆盖常量跨2次block使用；通过后T240能覆盖3次复用。不能只用一块的小T通过来排除常量被第一次消费覆写的问题。每任务仍遵守750秒内部/780秒调度上限，不先铺大配置。

## 若资源或性能不佳的最小备选

只前移1×512 FP32 channel load（约2KiB常驻），原full/col_expand_mul仍每块执行，可作为另一个独立候选。它降低常驻UB压力，保留相同算术顺序，并能区分“大系数复用”与“只读load提前”两类效果。不要同时再预读token_scale/integer_accum：它们有业务阶段依赖且row不同，会扩大风险。当前先测已生成版本，不盲加备选任务。

## 身份

```json
{
  "woa-pipeline-20261020/candidate-owner2.py": "399dbc67a1709a5e2fda636afb245d6e6478a5f1cec20763471caae6fd98e54b",
  "woa-hoist-20261021/candidate-channelpreload.py": "9f601c6457cf77737b8956ee5ac01d2f1c75bb93c01c9af03ab426d078abd9ed",
  "woa-hoist-20261021/candidate-channelpreload.json": "413d34cd73d240b45d99432f54bd088a130151bd78d7143cdb9eb9de68065b69",
  "woa-hoist-20261021/channelpreload_probe.py": "07624d842361559bde0b8219b01131de9c506268856274921bbefdb4f9d0b908",
  "woa-hoist-20261021/generated/channelpreload/ptoas/resident_channel_preload.pto": "412f2a06a88c46ee320d8c91836f8e69d7ef8c6a245e0c2e30649657b4cf5b13",
  "woa-hoist-20261021/generated/channelpreload/ptoas/resident_channel_preload.cpp": "598a1736ed2f960a1b871343900b85849c5dd2ac389c2bb8bb09c1260f570f28",
  "woa-hoist-20261021/generated/channelpreload/orchestration/resident_suffix.cpp": "ad24af2ae60dddce978e06a887dab0afe05456cf5ba468e2a46dc5af25ea0ce3",
  "woa-hoist-20261021/generated/channelpreload/kernel_config.py": "d28bf30ec2796bd2d0065be7fead91febbed0f41514b83acc7a1826566c8c541",
  "woa-hoist-20261021/generated/result.json": "fd23ac119848acdbdf7ac54a9e5f3ed1e6da1509979365d48f997bf2baddd02b"
}
```
