# WO-B反量化四owner依赖：独立源级审查

## 结论及适用条件

**当前owner2的WO-B分工下设计成立，实际候选96ad820…源级未发现阻断；实际完整CPU与生成物审查亦已完成，无已知设备前阻断；硬件数值/性能尚未验证。** 本候选独立从owner2派生，不包含channelpreload；不修改通知、代际、量化或WO-B数学。此审查只写reports，无SDK/候选修改、无设备提交。

## 从实际生产者映射证明

当前AIC的低T分支为M16/N128，高T分支为M64/N128，每worker接收wide_block=worker+24i；所有K512×16顺序不变。Vector每block消费16×512，行起点为16的倍数，因此不跨64行panel，512列恰由连续4个N128输出构成：

```text
T<=16: owner=((row//16)*32+col//128+j)%24
T>16:  owner=((row//64)*32+col//128+j)%24
j=0..3
```

独立CPU验证使用**实际parent AST的AIC outer range和前三个row/col/valid赋值**枚举所有写块，再使用actual Vector loop前三赋值枚举读取；将candidate实际条件/owner表达式求值，与唯一包含该读取的写矩形逐项匹配。T1…256、48个Vector worker全部12288个场景通过，每个128列分片匹配唯一生产者、其有效行覆盖读取，4个owner互不重复。没有只用相同公式两边自证。

资格严格绑定当前高T M64/低T M16、N128和24个AIC；若未来WO-B改M128或grid分工，必须重推，不能直接复用本公式。

## 阶段语义和可见性

publish4由该AIC完成其所有WO-B块、原bar_all/fence/cache维护之后发布；虽比逐块事件更保守，等到4个owner就足以保证本512列有效数据完成。不依赖其它20个owner即可反量化本块。

新token_scale读取虽可早于其它AIC的phase4，但仍安全：**每个被等待的phase4生产者本身先等待全部48个AIV的phase3**，phase3发布在全8192列统一量化及token_scale写入后。因此任何一个所需phase4满足都传递保证该代全部量化/scale完成。这依赖当前AIC wait3全集未变；不能随未来wait3精简继续默认成立。

候选在每个block的4次等待后保留原payload `fence → cacheinvalid(all) → fence`，之后才load integer_accum/token_scale。不能只首次block获取后，在下一组新生产者尚未完成时继续用旧cache。原TNOTIFY、每个active/inactive Vector的publish5和全48owner phase5等待均保留；HC-post仍须全部attended完成。无反向依赖：AIC在WO-B前只等phase3，而Vector已publish3才进入本段等待。MIX完成仍覆盖全部AIC/AIV；不允许下次调用提前覆写workspace。

对实际candidate做最小逆变换：只删除loop内新增协议4节点、恢复原loop前wait4，整个Vector AST与owner2完全相同；其它函数AST相同，仅cluster hint改名。没有重关联反量化乘法、改变BF16舍入或移动token_scale到其依赖之前。

## 等待数量、重复及成本

| T | 原TWAIT调用 | 新调用 | 原payload acquire | 新acquire | 新调用中同worker已等过owner的重复 |
|---|---:|---:|---:|---:|---:|
|1…16|1152|32|48|8|0|
|126|1152|256|48|64|0|
|240|1152|480|48|120|96|
|256|1152|512|48|128|128|

计数是动态调用次数，不是失败轮询次数或墙钟等待时间。T240中前三块的部分64行panel的owner集合模24后重复，因此96次是同worker对同代已满足owner的再次ready等待。初次方案可以保留这些重复，避免额外去重状态和控制流；只有实际数据证明需要时另立去重单因素。

新方案减少不必要owner等待，也分散原先48个Vector都从owner0开始的轮询次序；但每块payload acquire更频繁，并允许反量化MTE2/Vector与未结束WO-B更早并发。因此可能改善或恶化生产者/消费者，不能预设净收益，也不能将全部差值叫固定wait成本或DDR流量变化。

## 对L1/流水及后续门禁

AIC数据传输、MMA顺序、L1/L0布局及缓冲生存期源码未改；本候选不直接改变WO-B L1流水。但跨角色资源环境改变，AIC实测span可能随之变化。先核actual AIC生成体与parent同构、保留原set/wait事件；不能因source未改就预言硬件跨度不变。

实际CPU生成后必须核：原1MIX/24AIC+48AIV、16ABI不变；loop内4个动态owner的phase4地址正确，payload acquire在integer load前；原wait3/publish4、Vector publish5/最后全集wait5未丢；没有生成仅首块等待或把acquire移出loop。整数索引/SSA的CPU通过不代替这些实际核验。

再用frozen/owner2/new三臂、同输入五边界逐位、A/B/A/毒化/guard/只读与1204代、12×100无插桩计时。发现首差先停，先T126，确认有效再决定T240；每任务<=780秒。不与channelpreload叠加，不把独立候选相对parent下降百分比相加，不在胜过冻结及完整CSA门禁前进入wholemodel。

## 身份与枚举结果

```json
{
  "identity": {
    "woa-pipeline-20261020/candidate-owner2.py": "399dbc67a1709a5e2fda636afb245d6e6478a5f1cec20763471caae6fd98e54b",
    "woa-hoist-20261021/candidate-obowners.py": "96ad820736e7bb908bcbdadcc059083945f900b8d162c93809c32fd9e252d209",
    "woa-hoist-20261021/candidate-obowners.json": "3c96842b9e828470229b8494489ad2b92fb46746c4103a47a6f6968cc2c5c692"
  },
  "geometry_examples": [
    {
      "T": 1,
      "old_wait_calls": 1152,
      "new_wait_calls": 32,
      "old_payload_acquires": 48,
      "new_payload_acquires": 8,
      "repeat_ready_wait_calls_per_worker_aggregate": 0,
      "unique_wait_calls_per_worker_aggregate": 32
    },
    {
      "T": 16,
      "old_wait_calls": 1152,
      "new_wait_calls": 32,
      "old_payload_acquires": 48,
      "new_payload_acquires": 8,
      "repeat_ready_wait_calls_per_worker_aggregate": 0,
      "unique_wait_calls_per_worker_aggregate": 32
    },
    {
      "T": 17,
      "old_wait_calls": 1152,
      "new_wait_calls": 64,
      "old_payload_acquires": 48,
      "new_payload_acquires": 16,
      "repeat_ready_wait_calls_per_worker_aggregate": 0,
      "unique_wait_calls_per_worker_aggregate": 64
    },
    {
      "T": 80,
      "old_wait_calls": 1152,
      "new_wait_calls": 160,
      "old_payload_acquires": 48,
      "new_payload_acquires": 40,
      "repeat_ready_wait_calls_per_worker_aggregate": 0,
      "unique_wait_calls_per_worker_aggregate": 160
    },
    {
      "T": 96,
      "old_wait_calls": 1152,
      "new_wait_calls": 192,
      "old_payload_acquires": 48,
      "new_payload_acquires": 48,
      "repeat_ready_wait_calls_per_worker_aggregate": 0,
      "unique_wait_calls_per_worker_aggregate": 192
    },
    {
      "T": 126,
      "old_wait_calls": 1152,
      "new_wait_calls": 256,
      "old_payload_acquires": 48,
      "new_payload_acquires": 64,
      "repeat_ready_wait_calls_per_worker_aggregate": 0,
      "unique_wait_calls_per_worker_aggregate": 256
    },
    {
      "T": 240,
      "old_wait_calls": 1152,
      "new_wait_calls": 480,
      "old_payload_acquires": 48,
      "new_payload_acquires": 120,
      "repeat_ready_wait_calls_per_worker_aggregate": 96,
      "unique_wait_calls_per_worker_aggregate": 384
    },
    {
      "T": 256,
      "old_wait_calls": 1152,
      "new_wait_calls": 512,
      "old_payload_acquires": 48,
      "new_payload_acquires": 128,
      "repeat_ready_wait_calls_per_worker_aggregate": 128,
      "unique_wait_calls_per_worker_aggregate": 384
    }
  ],
  "scenarios": 12288,
  "producer_matches": 69632
}
```

## 后补实际生成物审查

已独立读取generated-obowners完整CPU receipt（PTOAS/CCEC+Artifact load、ABI16、未初始化NPU）及实际PTO/C++。每dequant block内部保留ob_dep=0…3，低T按row//16、高T按row//64再mod24；phase4槽为(288+owner)×128。PTO1469行是GE TWAIT，1471…1473原GM payload acquire，1478才integer tload；token_scale读取也在后。原publish4/全部AIV publish5/最终wait5未删。实际仍一MIX{0,1,1}、24block/sync-start、原16Tensor，无rt_alloc。未发现生成码阻断，可先T126五边界首差停止门禁。

```json
{
  "generated-obowners/obowners/ptoas/resident_ob_actual_owners.pto": "0caeb71fe88c4f5cdaeede7795e0c16b7a1a83233221c4bbf60af2b186f23e2b",
  "generated-obowners/obowners/ptoas/resident_ob_actual_owners.cpp": "2a89abb4dcbbe4cf89e55615a281f021b9ba96eff53f9dee83e91322660b3ec0",
  "generated-obowners/obowners/orchestration/resident_suffix.cpp": "d432b5354ced981ab62ed4f2d90c6c904b6c55c432fa0f55ca0d74e28dc5f1c5",
  "generated-obowners/obowners/kernel_config.py": "d28bf30ec2796bd2d0065be7fead91febbed0f41514b83acc7a1826566c8c541",
  "generated-obowners/result.json": "8a701cbcf41b67fb7a5c8eaeade881097964f31960e5aee40dac31b28e5e90fb"
}
```
