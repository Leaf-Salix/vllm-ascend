# 本轮最终独立审查（纯DSL系数前移与依赖等待）

## 结论

**审查通过，无发布阻断。** 8份原始结果、最终回执与报告一致；1280项逐位指标通过。本轮仅obowners在**T240这一已测形状**的两次独立任务稳定领先冻结后缀，不能推广成全部高T有效。T126/T144仍未胜冻结，coefearly也未跨过短T门槛；不接完整CSA、不跑8K/128K新整模型验收、不改正式路由，与当前证据一致。

审查只读源、实际生成物、原始JSON及归档。仅写本报告/FINAL_REVIEW.json，没有修改正式运行源码、SDK、候选或原始结果，没有新提交设备任务。

## 独立核对内容

- 八份raw均pass/complete、FULL graph/guards/readonly为true，无首差error；每份16个检查点×两候选臂×五边界=160，合计1280。逐项bit_equal=true、different_elements/max_abs=0；未把1280指标说成1280个独立输入或全模型测试。
- 实际harness文件SHA与RUNS及raw一致；candidate/parent源SHA逐份核验。前三候选父版owner2，coefearly父版obowners；新W→旧Wold→phase1的祖先链逐边匹配，未错把owner2历史值当coefearly直接父臂。
- 每份最终parent/new generation均1204，冻结实际模块SHA与原source proof匹配。scope标签修正已发生在实际harness身份中，未修改已运行raw。
- 逐任务从原12窗样本重算min/median/mean/max、对父版/冻结耗时比及配对窗方向，全部与RESULT_VALIDATION逐字段一致。无删样；原三臂轮转/反转12窗，每臂每位置恰4次。
- 两次obowners T240不仅形状相同，原始input_A SHA及wo_a/wo_b/channel/start SHA也一致。新候选两次中位数387.7786/388.9584μs；冻结470.1494/466.5799μs；父臂有漂移，因此必须使用各任务同组基线，不将跨任务差值归为组合收益。
- 最终回执归档中8份raw与本地逐字节一致；FINAL_STATUSES及各task-status均completed(exit=0)，launcher START→END为97…115秒，全部小于780秒。没有将提交至结束含排队的时间混称占卡时间。

## 主要结果复核

| 候选/形状 | 较实际父版 | 较同任务冻结 | 新候选领先冻结窗数 | 判断 |
|---|---:|---:|---:|---|
|channelpreload T126|−7.6950%|+13.4846%|0/12|局部改进但未胜冻结|
|channelpreload T240|+4.7166%|+16.4874%|0/12|回退|
|obowners T126|−17.6020%|+2.3678%|0/12|仍有差距|
|postowners T126|+1.7068%|+18.5648%|0/12|回退，不扩测|
|obowners T240首次|−27.0267%|−17.5201%|12/12|此形状有效|
|obowners T240重复|−31.3690%|−16.6363%|12/12|同形状重复确认|
|coefearly T126|−2.5082%|+0.8484%|0/12|尚未胜冻结，不扩大|
|obowners T144|−23.2824%|+4.7824%|0/12|未通过另一目标形状门槛|

负号是耗时减少；它们是后缀FULL图窗口平均耗时的中位数，不是单个kernel指令时间、TPOT或整模型吞吐。两次T240相对冻结领先16.64%…17.52%的窄结论成立；不能将不同候选百分比相加，也不由T240推导T>=192均有效。

## 精度/架构与报告限定

四个候选的独立源/实际编译审查已经分别保留：原K/舍入/全8192量化不变；channel常量UB跨等待不被覆盖；WO-B四owner、HC-post八owner以及coefearly phase3尺度依赖的T1…256实际AST覆盖通过。生成物是既有DSL自动产物的只读证据，没有修改C++或SDK。本轮没有使用等待退避helper。

T1…256是CPU索引/覆盖证明，不是每个T的NPU验证。设备只测T126/T144/T240。gold是冻结PTO后缀五边界，使用真实第4层WO-A/B权重、合成heads/residual/gates；未新测Native完整CSA、真实模型token或非等长请求metadata。报告已明确T144只是相应行数形状，不包含128K历史。

本轮没有PMU/泳道，因此不能把收益再拆成计算、搬运、同步的贡献，也不能以静态TWAIT调用数推失败轮询或DDR流量变化。完整scope信号初始化/条件分流仍是未实现设计，未给其贴硬件通过标签。

## 文档复现检查

REPORT_DRAFT八行数值/范围限定与raw一致；REPRODUCTION已经补T144、check-coefearly及“最终代际1204”用语。RUNS保存全部原命令和父链，每任务独立单卡、内部750秒/外780秒、未留下自有任务。发布应原样保留失败/回退结果和全部样本。

机器可读结论、8个raw SHA、候选父SHA、实际计时和收据持续时间见同目录FINAL_REVIEW.json。本审查所读REPORT_DRAFT SHA：`e679f815e518c6511d45b27bc5befb77f7268cb861c5fa16eca54d2e8f7eb4be`；REPRODUCTION SHA：`39e850151d13856f7726f35a349a5584532f8ddbadae59299f95832ffd84249f`。
