# 高T后缀接入完整CSA：独立最小设计审查

## 结论

**原则可行，但当前只应作为后续私有候选，不能由T240后缀领先直接赋予完整CSA/整模型资格。** 本轮未实现此改写、未改正式源/SDK、未提交任务。若采用T>=192的新后缀/短T冻结路径，应在同一PTO公开根内做orchestration分支，而非把两根从Python串起来；短T分支保留原两个scope。

已重读当前正式overlap `_full_csa_tnd_prepacked`：64Tensor根，已有根级flat_hc=reshape(x_hc,[T,16384])；末尾原Oproj与HCpost是两个兄弟scope。权重wo_a/wo_b、oproj_start和projected_o/quantized_o/scale_o/attention_out已有合法输入/中间值。新方案只替换末两scope，不改变prefix FFTS协议、metadata/cache或真正TND边界。

## 需要保持的结构

```text
高T分支中的后缀scope
  accum[T+127,8192] FP32
  integer[T+63,4096] INT32
  signals[6*72*128] INT32
  独立DSL init task: signals作为Out，返回/重绑
  MIX group: 原heads/weights/start/post/comb/flat_hc输入
             原输出及scratch/signals作为InOut并返回/重绑
  原x_out的[T,16384]描述符view写回
低T分支: 原Oproj scope + 原HCpost scope
root返回原x_out，仍64Tensor
```

MIX复用incore函数及inline group，不在根中调用注册好的Python runtime op，不嵌入另一个顶层JIT入口。flat output view应在父级建立，确认与x_out同地址/offset，不能用GM copy或偷偷清x_out来掩盖Out纪律问题。动态scratch尺寸保持affine，分支内L0C不跨分支合并；完整caller的specialize/SSA/GCC/CCEC仍是新门禁。

## signals零初始化：不能省掉的依赖与可见性

`create_tensor`不是零初始化。必须init Out→MIX InOut同一descriptor的实际完成依赖；helper返回值要重绑，MIX读signals不能绕回未登记原alias。默认非early-resolve依赖才保证所有初始化worker结束后才begin；源代码顺序和scopeexit均不是设备barrier。

init可清**全部6×72=432个phase/core stamp（每槽word0）**，其余127个word不必为等待语义清零，条件是审计当前begin/TWAIT/TNOTIFY仅访问这些单INT32槽、没有profile时间戳或其它辅助字段读取。应清所有phase，不能只清phase0：若旧phase4/5>=1，新代1可能错误立即通过。清未使用角色的stamp也合理，便于固定mask审计。

这比旧FULL_INTEGRATION_REVIEW中“完整55296个word清零”的建议更精确：旧建议给出保守全字节初始化合同；**等待协议实际只需所有可能读取的stamp被初始化**。不改写旧报告历史，也不将原诊断harness“其余word全0”的证据贴给新方案。若仍要复用该字节合同，就应全数组清零；若只清stamp，则独立验证其它word不被读、可保持毒化哨兵。

若init用Scalar GM store，不能只依赖普通赋值及任务完成假设DCache脏行已对其它核可见。须使用当前DSL合法的cache维护/DDR fence/通知语义，核实际生成的store、DCCI/DSB或MTE3完成尾部；不要加C++。432个stamp跨216KiB、各512B隔离，需证明所有init worker写区域不重叠、全部Out→MIX依赖，没有只等最后一个worker。

可以选择单AIV循环或单独AIV SPMD，零任务本身不需要核间等待。若SPMD48，要像已审quantcut-aiv那样确认实际注册为唯一AIV、flat0…47、任务数/角色，不放假空闲Cube占位。stamp-only Scalar随机行清理不一定比216KiB连续MTE3清零更快；不能先认定节省初始化成本。

## 每次fresh代1的证明

每次root init完成，72个core begin各读0并写1，本次phase1…5用1；scratch scope只能在MIX所有consumer完成后回收，下一调用不得并发复用相同存储。MIX与zero task均应持有正确tensor producer/consumer引用。

必须证明zero在**每次FULL graph replay**都实际执行，不能只在capture执行一次。最终读到stamp=1本身也不充分；结合实际DAG、init/MIX执行计数、连续A/B/A与毒化/allocator复用验证。原persistent-signal后缀的1204代证据不等于此fresh-workspace的验收；不能静默改掉旧测试预期后声称同一协议通过。

原heads发布、post/comb及root-owned中间值也须通过Tensor依赖连接MIX；不借prefix FFTS workspace做新信号，不重解释只读order/weight packet存储。

## 容量与生命周期

按当前方案，T240三份scratch共16.4140625MiB，T256为17.1640625MiB。原Oproj本来已有同尺寸accum(T+127)和integer(T+63)，因此名义增加仅signals的216KiB及init/task元数据。**不是实际每ring峰值只增加216KiB的证明**：MIX将scratch持有到HCpost完成，且scopeexit不等待前面Attention/Indexer结束，存在异步生命周期与arena重叠。

需核actual alloc_tensors/ring/scope、分支是否只分配所选路径、是否不小心同时保留原Oproj scratch和新MIX scratch；根级已有输出不重复创建。保持后缀私有scope，不把大scratch提升到根级或与Indexer arena合成巨scope。估算不替代首次整层实际allocator门禁。

## 最小后续资格

先现有独立后缀各自重复性能与五边界门禁，再决定是否实现。私有完整候选编译后核64根ABI、1个顶层、init→MIX强DAG、仅后缀差异、原Native K/量化/HCpost舍入不变、无C++数学。条件分流需覆盖T191/192/193等边界及真实非等长T，不以padding S6获得资格。

完整CSA应同输入Native/冻结/新根精度首差停止，包含重复回放和fresh-init行为，计时包含清零、分配、额外task与调度成本。先赢完整CSA后再谈真实8K/128K token验收；不能由后缀局部17%收益推断整模型同幅度改善，也不提前跑大配置。

## 阅读身份

```json
{
  "current_formal_decode_csa_sha256": "0bf0a034f92e4a34f50a42eaa217edfe2d043b793afc382c15b67cdd5e3c52be",
  "current_source_path": "vllm-ascend-nalinaly-tnd-20261008-codex/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision_spmd_overlap/decode_csa.py",
  "proposal_status": "read-only not implemented",
  "scratch_T240_bytes": 17211392,
  "scratch_T256_bytes": 17997824
}
```
