# 在WO-B等待前预制反量化系数：独立审查

## 结论

**parent=obowners、candidate=coefearly（7bae7759…）的源级设计成立，实际生成物审查亦已完成，未发现设备前阻断。** 这不是硬件数值或性能通过；本审查未改源/SDK、未提交任务。没有叠加跨block channelpreload或HC-post依赖改动。

## phase3依赖正确性

原量化以8行/块，quant block=q交给logical AIV `q%48`，实际core=24+owner。token_scale写入后由该core发布phase3，因此所需槽是：

```text
scale_owner=(row//8+dep)%48，dep=0,1
address=(3*72+24+scale_owner)*128
```

16行dequant块按16对齐，最多跨两个8行scale块。T<=256时两个owner最大31，均在合法48槽内；不得误用phase2 cast槽或AIC phase3槽。所有线程已完成本代自身quant并publish3后才进入新增wait，生产者没有等待系数消费者的反向边，无依赖环。

用actual parent量化loop的range/row/valid AST构建token_scale逐行写者，再执行actual candidate dequant几何和owner表达式，T1…256×48worker=12288场景、全部有效scale行逐项被覆盖。没有假设整个scale向量已就绪。

尾valid<=8时实际上仅需第一个量化owner，第二个owner可能没有本代有效scale写入；**仍安全**，因为所有48 AIV不论是否有量化工作都原样publish3。本实现是覆盖所需读取的保守两槽等待，不能对所有尾部称“恰好两个必要生产者”；T126和T240的有效dequant块均确需两槽。不要为此擅删未活跃核publish。

## 数值、载入和进度

独立逆变换：删除新增phase3等待/acquire，将原channel/scale/full/col_expand_mul/row_expand_mul五个节点放回ob_integer后，Vector整函数AST恢复obowners；其它函数AST相同，只改cluster hint。保留：

```text
RN_FP32(1*channel)
  → RN_FP32(coefficient_channel*token_scale)
  → RN_FP32(FP32(integer)*coefficient)
  → BF16 rint
```

没有重关联乘法、把channel预量化，或改变整数转换/全8192量化及HC-post。新增phase3 acquire之后才能读取token_scale；原phase4四owner等待/acquire之后才能读取integer_accum。两个payload acquire分别服务两组生产者，不可合并成只保留一个，也不能把signal单行DCCI当payload获取。

AIC仍等待全部48 phase3再做WO-B；系数可以在所需两量化生产者完成后就算，允许与其它线程量化或WO-B重叠。也可能竞争MTE/Vector资源，所以“藏在等待前”是组织意图，不是已经证明完全隐藏成本。

## UB跨等待和实际代码门禁

每block重新生成完整coefficient，只需最终32KiB FP32系数活到原4个WO-B等待结束；channel、ones、coefficient_channel在最终coefficient产生后可复用。与跨block channelpreload不同，不要求系数跨下一block保持不变。

实际生成必须核：coefficient准备发生在phase4 TWAIT之前；其32KiB缓冲不被随后integer load或INT32→FP32 cast覆盖。最终TMUL若在读完系数后合法原位覆盖该缓冲可以接受，因本block系数已最后使用；不能只见逻辑变量不同就认定物理不重叠。系数跨wait不会被GM cacheinvalid清除，但仍要核实际owner/SSA生存期和自动MTE/V事件。

完整CPU compile、Artifact.load/ABI16之外，还要看PTO/C++实际两个等待阶段的顺序、各自acquire、buffer地址和1MIX/24AIC+48AIV未变。没有新workspace/rt_alloc/新通知或代际动作。

## 新增代价及对拍

| T | 父4owner wait调用 | 新增scale wait | 合计 | 父payload acquire | 新acquire |
|---|---:|---:|---:|---:|---:|
|126|256|128|384|64|128|
|240|480|240|720|120|240|

计数不是未就绪循环数，也不是固定耗时；phase3热点和额外DCache维护可能抵消重叠。按同任务frozen/obowners/new三臂实测；不能拿owner2历史值当直接父版，也不将本项收益与其它独立候选相加。

harness实际parent resolver从新W读取obowners，继而回旧Wold读取owner2/phase1，边的SHA逐项核对；数学候选路径独立。沿用五边界逐bit/finite、A/B/A、NaN/整数反码毒化、guards/只读/信号mask与1204代、12×100三臂平衡轮换、首差停止。内部750秒/外780秒。scope文字应准确列实际三臂，不能多称有owner2第四臂；本项依然不是Native完整CSA或整模型验证。

## 身份及枚举

```json
{
  "identity": {
    "woa-hoist-20261021/candidate-obowners.py": "96ad820736e7bb908bcbdadcc059083945f900b8d162c93809c32fd9e252d209",
    "woa-hoist-20261021/candidate-coefearly.py": "7bae7759ecb77c83da38ef0759cfc0fa992f682fdc354f4d2361c69d29af1615",
    "woa-hoist-20261021/candidate-coefearly.json": "8e3eea1502d187cbeac7fdf44ad0ec0226ed363973189ae53c120cbff7bc01e9",
    "woa-hoist-20261021/coefearly_probe.py": "e52fc0d1462c9a5ca7835420c852e7474059f9a4bd7feb3bd64a38e5aad25d2c"
  },
  "examples": [
    {
      "T": 1,
      "blocks": 8,
      "parent_phase4_wait_calls": 32,
      "additional_phase3_wait_calls": 16,
      "total_current_phase3plus4_wait_calls": 48,
      "parent_payload_acquires": 8,
      "candidate_payload_acquires": 16,
      "extra_conservative_scale_waits": 8
    },
    {
      "T": 8,
      "blocks": 8,
      "parent_phase4_wait_calls": 32,
      "additional_phase3_wait_calls": 16,
      "total_current_phase3plus4_wait_calls": 48,
      "parent_payload_acquires": 8,
      "candidate_payload_acquires": 16,
      "extra_conservative_scale_waits": 8
    },
    {
      "T": 9,
      "blocks": 8,
      "parent_phase4_wait_calls": 32,
      "additional_phase3_wait_calls": 16,
      "total_current_phase3plus4_wait_calls": 48,
      "parent_payload_acquires": 8,
      "candidate_payload_acquires": 16,
      "extra_conservative_scale_waits": 0
    },
    {
      "T": 17,
      "blocks": 16,
      "parent_phase4_wait_calls": 64,
      "additional_phase3_wait_calls": 32,
      "total_current_phase3plus4_wait_calls": 96,
      "parent_payload_acquires": 16,
      "candidate_payload_acquires": 32,
      "extra_conservative_scale_waits": 8
    },
    {
      "T": 120,
      "blocks": 64,
      "parent_phase4_wait_calls": 256,
      "additional_phase3_wait_calls": 128,
      "total_current_phase3plus4_wait_calls": 384,
      "parent_payload_acquires": 64,
      "candidate_payload_acquires": 128,
      "extra_conservative_scale_waits": 8
    },
    {
      "T": 126,
      "blocks": 64,
      "parent_phase4_wait_calls": 256,
      "additional_phase3_wait_calls": 128,
      "total_current_phase3plus4_wait_calls": 384,
      "parent_payload_acquires": 64,
      "candidate_payload_acquires": 128,
      "extra_conservative_scale_waits": 0
    },
    {
      "T": 240,
      "blocks": 120,
      "parent_phase4_wait_calls": 480,
      "additional_phase3_wait_calls": 240,
      "total_current_phase3plus4_wait_calls": 720,
      "parent_payload_acquires": 120,
      "candidate_payload_acquires": 240,
      "extra_conservative_scale_waits": 0
    },
    {
      "T": 241,
      "blocks": 128,
      "parent_phase4_wait_calls": 512,
      "additional_phase3_wait_calls": 256,
      "total_current_phase3plus4_wait_calls": 768,
      "parent_payload_acquires": 128,
      "candidate_payload_acquires": 256,
      "extra_conservative_scale_waits": 8
    },
    {
      "T": 256,
      "blocks": 128,
      "parent_phase4_wait_calls": 512,
      "additional_phase3_wait_calls": 256,
      "total_current_phase3plus4_wait_calls": 768,
      "parent_payload_acquires": 128,
      "candidate_payload_acquires": 256,
      "extra_conservative_scale_waits": 0
    }
  ],
  "scenarios": 12288,
  "scale_row_matches": 263168
}
```

## 后补实际编译/缓冲/执行审查

完整PTOAS/CCEC、16Tensor ABI及Artifact.load回执通过，未初始化NPU。实际PTO1452行是新增phase3等待，1454…1456获取后才读取scale；1469/1471保留原两步系数计算，1470最终coefficient位于UB[0,32768)。1501是原四owner phase4等待，1503…1505再次payload获取，1510的integer load及1512的FP32 cast使用[32768,65536)，不会覆盖系数。1514最终TMUL输出回[0,32768)是合法最后使用后的in-place覆盖，每个block都会重新生成系数。

C++同样v457是系数源、v484是独立integer cast，最后TMUL(v488,v484,v457)目的可复用系数；预制后设置V→MTE2 event7，读取integer前等待，避免复用旧scale/channel区域时向量读仍未完成。原publish5与最后wait5仍在。编排仍1MIX{0,1,1}/24block/sync-start/16Tensor，无新增rt_alloc。harness scope已修正为实际obowners/frozen/new三臂，SHA已刷新。无已知设备前阻断，可先T126首差门禁；没有提前宣称硬件精度或收益。

```json
{
  "woa-hoist-20261021/generated-coefearly/coefearly/ptoas/resident_coefficient_early.pto": "f7281f377dbf7854ec9e258618c5eac2e3a313a99b1a9d6358095609786b9311",
  "woa-hoist-20261021/generated-coefearly/coefearly/ptoas/resident_coefficient_early.cpp": "098ed273c218b7a5ab8dd88aefd53137180376c3462148a3d6364cb464b03a8d",
  "woa-hoist-20261021/generated-coefearly/coefearly/orchestration/resident_suffix.cpp": "5260fbfcde37311ed6586c36be4ed9b92b8c149edf068756c4c19a98be9397cb",
  "woa-hoist-20261021/generated-coefearly/coefearly/kernel_config.py": "d28bf30ec2796bd2d0065be7fead91febbed0f41514b83acc7a1826566c8c541",
  "woa-hoist-20261021/generated-coefearly/coefearly/compiled_meta.json": "2c40ae42e31bba8ec4d598e02b037292bd42e4841e170d974d7723e6ca9936c2",
  "woa-hoist-20261021/generated-coefearly/result.json": "9ba32b8727324145a097dca46d1b8e04f7be700a5ada9d722878a12c6999723c"
}
```
