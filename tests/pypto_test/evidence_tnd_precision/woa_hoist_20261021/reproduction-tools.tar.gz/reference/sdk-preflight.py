"""无设备核对新SDK源、DSO和接口；不将导入成功当成硬件验收。"""
import hashlib
import importlib
import importlib.abc
import importlib.machinery
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys

sdk = Path("/data/pyptouser/yejia/csa-spmd-sdk-20261020")
roots = {"pypto": sdk / "sources/pypto", "simpler": sdk / "sources/simpler"}
package_roots = {
    "pypto": roots["pypto"] / "python", "simpler": roots["simpler"] / "python",
    "simpler_setup": roots["simpler"],
    "_task_interface": roots["simpler"] / ".venv/lib/python3.12/site-packages",
}
for name, root in package_roots.items():
    loaded = sys.modules.get(name)
    if loaded is not None:
        assert root in Path(loaded.__file__).resolve().parents, (name, loaded.__file__)

class SDKFinder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        top = fullname.partition(".")[0]
        if top not in package_roots:
            return None
        search = path if "." in fullname else [str(package_roots[top])]
        spec = importlib.machinery.PathFinder.find_spec(fullname, search)
        if spec is None:
            raise ImportError(f"SDK package missing: {fullname}: {package_roots[top]}")
        return spec

sys.meta_path.insert(0, SDKFinder())
sys.path[:0] = [str(p) for p in package_roots.values()]
os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] = "0"
import torch
import torch_npu
assert not torch_npu.npu.is_initialized()
names = ("pypto", "pypto.pypto_core", "pypto._torch_npu", "simpler", "simpler_setup", "_task_interface")
modules = {name: importlib.import_module(name) for name in names}
for name, module in modules.items():
    root = roots["pypto" if name.startswith("pypto") else "simpler"]
    assert root in Path(module.__file__).resolve().parents, (name, module.__file__)
import pypto.language as pl
from pypto._kernel_abi import MAX_KERNEL_TENSORS, MAX_KERNEL_SCALARS, SIMPLER_KERNEL_REVISION
assert MAX_KERNEL_TENSORS == 256 and MAX_KERNEL_SCALARS == 128
assert modules["pypto._torch_npu"].simpler_revision == SIMPLER_KERNEL_REVISION == "57e499238fd4ee3548947ad860be456aaeeb16b5"
assert hasattr(pl.system, "signal_notify") and hasattr(pl.system, "signal_wait")
assert not torch_npu.npu.is_initialized()
record = {
    "scope": "CPU import/ABI/API preflight only; no NPU execution or full PTOAS qualification",
    "pass": True, "npu_initialized": False, "python": sys.executable,
    "python_version": sys.version,
    "source_heads": {name: subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"], text=True).strip() for name, root in roots.items()},
    "imports": {name: module.__file__ for name, module in modules.items()},
    "binary_sha256": {name: hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest() for name, module in modules.items() if str(module.__file__).endswith(".so")},
    "torch": torch.__version__, "torch_npu": torch_npu.__version__,
    "dependencies": {name: importlib.metadata.version(name) for name in ("nanobind", "scikit-build-core", "cmake", "ninja")},
    "root_max_tensor_args": MAX_KERNEL_TENSORS, "root_max_scalar_args": MAX_KERNEL_SCALARS,
    "signal_notify": True, "signal_wait": True,
    "ASCEND_HOME_PATH": os.environ.get("ASCEND_HOME_PATH"),
}
assert record["ASCEND_HOME_PATH"] == "/data/pyptouser/yejia/vllm-cann92-main/env/Ascend/cann-9.2.0-beta.2"
(sdk / "results/pypto-import-preflight.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
if sys.argv[1:] and sys.argv[1] == "--pytest":
    import pytest
    raise SystemExit(pytest.main(sys.argv[2:]))
