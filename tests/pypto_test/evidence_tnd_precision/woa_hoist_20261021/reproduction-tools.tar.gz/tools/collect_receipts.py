"""收集本轮8项自有任务最终回执及4个纯DSL CPU检查身份。"""
import io
import json
from pathlib import Path
import subprocess
import tarfile

sdk=Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
root=sdk/'woa-hoist-20261021'
runs=json.loads((root/'RUNS.json').read_text())
statuses={}
with tarfile.open(sdk/'woa-hoist-run-receipts-v1.tar.gz','w:gz') as archive:
 def blob(name,value):
  data=value.encode();info=tarfile.TarInfo(name);info.size=len(data);archive.addfile(info,io.BytesIO(data))
 for case,item in runs['runs'].items():
  status=subprocess.run(['task-submit','--status',item['task']],capture_output=True,text=True,timeout=30)
  assert status.returncode==0 and f"completed (exit={item['exit_code']})" in status.stdout,(case,status.stdout)
  statuses[case]={'task':item['task'],'status':status.stdout.strip()}
  blob(case+'/task-status.txt',status.stdout+status.stderr)
  log=subprocess.run(['task-submit','--log',item['task']],capture_output=True,text=True,timeout=30)
  blob(case+'/task.log',log.stdout+log.stderr)
  for path in (sdk/'results'/case/'result.json',sdk/'results'/(case+'-run.log')):
   assert path.is_file();archive.add(path,arcname=case+'/'+path.name)
 for case in ('woa-channelpreload-cpu-v1','woa-obowners-cpu-v1','woa-postowners-cpu-v1','woa-coefearly-cpu-v1'):
  path=sdk/'results'/case
  for p in (path/'result.json',sdk/'logs'/(case+'.log')):
   assert p.is_file();archive.add(p,arcname='cpu/'+case+'/'+p.name)
  for p in path.glob('*/kernel_config.py'):
   archive.add(p,arcname='cpu/'+case+'/'+str(p.relative_to(path)))
  for p in path.glob('*/compiled_meta.json'):
   archive.add(p,arcname='cpu/'+case+'/'+str(p.relative_to(path)))
 blob('FINAL_STATUSES.json',json.dumps(statuses,indent=2)+'\n')
print('all own tasks ended:',len(statuses))
