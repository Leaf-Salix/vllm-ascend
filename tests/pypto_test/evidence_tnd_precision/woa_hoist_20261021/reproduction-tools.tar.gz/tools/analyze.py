"""由原样本重算逐位门禁与配对窗延迟，不删离群值。"""
import json
import statistics
from pathlib import Path
root=Path(__file__).resolve().parent
runs=json.loads((root/'RUNS.json').read_text())['runs']
summary={}
for case,receipt in runs.items():
 path=root/(case+'.json')
 if not path.exists():continue
 r=json.loads(path.read_text())
 assert r['pass'] and r['complete'] and r['actual_acl_graph'] and r['guards'] and r['readonly']
 assert r['source_baseline']=='48c58ce7c467dfce63d5cb5c41afd225488d6012'
 assert r['harness_sha256']==receipt['harness_sha256']
 metrics=[v for stage in r['comparisons'].values() for v in stage.values()]
 assert len(metrics)==160 and all(x['bit_equal'] and x['different_elements']==0 and x['max_abs']==0 for x in metrics)
 assert r['final_generation']=={'parent':1204,'new':1204}
 samples=r['timings']['samples'];assert set(samples)=={'frozen','resident','new'}
 assert all(len(v)==12 for v in samples.values()) and not r['timings']['outliers_removed']
 med={k:statistics.median(v) for k,v in samples.items()}
 for k in samples:assert r['timings']['summary'][k]['median']==med[k]
 summary[case]={'tokens':r['tokens'],'bit_metrics':len(metrics),'median_us':med,
  'new_vs_parent_percent':100*(med['new']/med['resident']-1),
  'new_vs_frozen_percent':100*(med['new']/med['frozen']-1),
  'windows_faster_parent':sum(a<b for a,b in zip(samples['new'],samples['resident'])),
  'windows_faster_frozen':sum(a<b for a,b in zip(samples['new'],samples['frozen']))}
(root/'RESULT_VALIDATION.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
