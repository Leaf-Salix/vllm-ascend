"""设备前核对冻结后缀两入口的动态参数与CPU lowering。"""
from pathlib import Path
import json,os,runpy,sys,traceback
sdk=Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
sys.argv=[str(sdk/'sdk-preflight.py')]
runpy.run_path(sys.argv[0],run_name='__main__')
sys.path.insert(0,os.environ['SOURCE_ROOT'])
import pypto.torch
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program
import torch_npu
import importlib.util
entries=[]
for name in ('channelpreload',):
 spec=importlib.util.spec_from_file_location('diagnosis_'+name,sdk/'woa-hoist-20261021'/f'candidate-{name}.py')
 mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
 entries.append((name,mod.resident_suffix,16))
out=sdk/'results/woa-channelpreload-cpu-v1';out.mkdir(exist_ok=False)
report={'pass':False,'device_execution':False,'skip_ptoas':False,'entries':{}}
try:
 for name,entry,n in entries:
  try:
   p=entry.specialize();abi=kernel_abi_for_program(p,platform='a2a3',runtime='tensormap_and_ringbuffer')
   assert len(abi.parameters)==n
   op=pypto.torch.register(entry,'suffix_candidate_cpu::'+name.replace('-','_'))
   _compile_impl(p,output_dir=str(out/name),platform='a2a3',skip_ptoas=False,_kernel_abi=abi)
   from pypto.runtime._kernel_artifact import KernelArtifact
   artifact=KernelArtifact(out/name,abi);artifact.load()
   report['entries'][name]={'args':n,'schema':str(op._schema),'lowering':True}
  except BaseException:report['entries'][name]={'pass':False,'error':traceback.format_exc()}
 assert not torch_npu.npu.is_initialized()
 report['pass']=all(v.get('lowering',False) for v in report['entries'].values())
except BaseException:report['error']=traceback.format_exc()
finally:(out/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if not report['pass']:raise SystemExit(1)
