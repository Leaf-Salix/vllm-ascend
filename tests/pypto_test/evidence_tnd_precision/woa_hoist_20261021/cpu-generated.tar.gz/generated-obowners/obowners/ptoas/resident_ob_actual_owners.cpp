#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void cube(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int32_t v22 = 1;
  // pto: %c0_i64
  const int64_t v23 = 0;
  // pto: %c65536_i64
  const int64_t v24 = 65536;
  // pto: %c32768_i64
  const int64_t v25 = 32768;
  // pto: %c131072_i64
  const int64_t v26 = 131072;
  // pto: %c196608_i64
  const int64_t v27 = 196608;
  // pto: %c32768_index
  const int64_t v28 = 32768;
  // pto: %c1_index
  const int64_t v29 = 1;
  // pto: %c8_index
  const int64_t v30 = 8;
  const int64_t v31 = 64;
  // pto: %c256_index
  const int64_t v32 = 256;
  // pto: %c16_index
  const int64_t v33 = 16;
  // pto: %c4194304_index
  const int64_t v34 = 4194304;
  // pto: %c65536_index
  const int64_t v35 = 65536;
  const int64_t v36 = 128;
  // pto: %c512_index
  const int64_t v37 = 512;
  // pto: %c32_index
  const int64_t v38 = 32;
  // pto: %c33554432_index
  const int64_t v39 = 33554432;
  // pto: %c262144_index
  const int64_t v40 = 262144;
  // pto: %c4096_index
  const int64_t v41 = 4096;
  // pto: %c8192_index
  const int64_t v42 = 8192;
  // pto: %c4_index
  const int64_t v43 = 4;
  // pto: %c55296_index
  const int64_t v44 = 55296;
  // pto: %c0_index
  const int64_t v45 = 0;
  // pto: %c15_index
  const int64_t v46 = 15;
  // pto: %c192_index
  const int64_t v47 = 192;
  // pto: %c24_index
  const int64_t v48 = 24;
  // pto: %c7_index
  const int64_t v49 = 7;
  // pto: %c2_index
  const int64_t v50 = 2;
  // pto: %c3_index
  const int64_t v51 = 3;
  // pto: %c5_index
  const int64_t v52 = 5;
  // pto: %c6_index
  const int64_t v53 = 6;
  // pto: %c240_index
  const int64_t v54 = 240;
  // pto: %c1024_index
  const int64_t v55 = 1024;
  // pto: %c241_index
  const int64_t v56 = 241;
  // pto: %c9216_index
  const int64_t v57 = 9216;
  // pto: %c72_index
  const int64_t v58 = 72;
  // pto: %c27648_index
  const int64_t v59 = 27648;
  // pto: %c63_index
  const int64_t v60 = 63;
  // pto: %c36864_index
  const int64_t v61 = 36864;
  // pto: %heads__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v65 = (int64_t) v17;
  // pto: %heads__ssa_v0_view
  int64_t v66 = v65 * v28;
  // pto: %heads__ssa_v0_view
  int64_t v67 = v64 * v66;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v68 = pto::Shape<1, 1, 1, -1, -1>(v62, v63, v64, v65, v28);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v69 = pto::Stride<-1, -1, -1, -1, -1>(v63 * v67, v67, v66, v28, v29);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v70 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v68, v69);
  // pto: %wo_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v71 = pto::Shape<-1, -1, -1, -1, -1>(v30, v31, v32, v33, v33);
  // pto: %wo_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v34, v35, v32, v33, v29);
  // pto: %wo_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v73 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v71, v72);
  // pto: %wo_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v74 = pto::Shape<-1, -1, -1, -1, -1>(v29, v36, v37, v33, v38);
  // pto: %wo_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v75 = pto::Stride<-1, -1, -1, -1, -1>(v39, v40, v37, v38, v29);
  // pto: %wo_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v76 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v3, v74, v75);
  // pto: %quantized__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v79 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v80 = (int64_t) v17;
  // pto: %quantized__ssa_v0_view
  int64_t v81 = v80 * v42;
  // pto: %quantized__ssa_v0_view
  int64_t v82 = v79 * v81;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v83 = pto::Shape<1, 1, 1, -1, -1>(v77, v78, v79, v80, v42);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v84 = pto::Stride<-1, -1, -1, -1, -1>(v78 * v82, v82, v81, v42, v29);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v85 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v83, v84);
  // pto: %accum__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v88 = 1;
  // pto: %accum__ssa_v0_view
  int64_t v89 = (int64_t) v18;
  // pto: %accum__ssa_v0_view
  int64_t v90 = v89 * v42;
  // pto: %accum__ssa_v0_view
  int64_t v91 = v88 * v90;
  // pto: %accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v92 = pto::Shape<1, 1, 1, -1, -1>(v86, v87, v88, v89, v42);
  // pto: %accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v93 = pto::Stride<-1, -1, -1, -1, -1>(v87 * v91, v91, v90, v42, v29);
  // pto: %accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v94 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v92, v93);
  // pto: %integer_accum__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v97 = 1;
  // pto: %integer_accum__ssa_v0_view
  int64_t v98 = (int64_t) v19;
  // pto: %integer_accum__ssa_v0_view
  int64_t v99 = v98 * v41;
  // pto: %integer_accum__ssa_v0_view
  int64_t v100 = v97 * v99;
  // pto: %integer_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v101 = pto::Shape<1, 1, 1, -1, -1>(v95, v96, v97, v98, v41);
  // pto: %integer_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v102 = pto::Stride<-1, -1, -1, -1, -1>(v96 * v100, v100, v99, v41, v29);
  // pto: %integer_accum__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v103 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v101, v102);
  // pto: %signals__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v105 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v106 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v107 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v108 = v44 * v29;
  // pto: %signals__ssa_v0_view
  int64_t v109 = v107 * v108;
  // pto: %signals__ssa_v0_view
  int64_t v110 = v106 * v109;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v111 = pto::Shape<1, 1, 1, 1, -1>(v104, v105, v106, v107, v44);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v112 = pto::Stride<-1, -1, -1, -1, -1>(v105 * v110, v110, v109, v108, v29);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v113 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v111, v112);
  // pto: %seed_fast_acc__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v114 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %seed_fast_acc__phi_v7
  uint64_t v115 = (uint64_t) v23;
  TASSIGN(v114, v115);
  // pto: %223
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v116 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %223
  uint64_t v117 = (uint64_t) v23;
  TASSIGN(v116, v117);
  // pto: %261
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v118 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %261
  uint64_t v119 = (uint64_t) v23;
  TASSIGN(v118, v119);
  // pto: %seed_narrow_acc__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
  // pto: %seed_narrow_acc__phi_v7
  uint64_t v121 = (uint64_t) v23;
  TASSIGN(v120, v121);
  // pto: %v4_wide_acc__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v122 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %v4_wide_acc__phi_v7
  uint64_t v123 = (uint64_t) v23;
  TASSIGN(v122, v123);
  // pto: %v4_narrow_acc__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
  // pto: %v4_narrow_acc__phi_v7
  uint64_t v125 = (uint64_t) v23;
  TASSIGN(v124, v125);
  // pto: %worker__ssa_v0
  int64_t v126 = (int64_t) v20;
  // pto: %63
  int64_t v127 = (int64_t) ((uint64_t) v126 * (uint64_t) v36);
  // pto: %64
  int64_t v128 = v127 < v45 ? v45 : v127;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v129 = PTOAS__GLOBAL_TENSOR_DATA(v113);
  // pto: %signals__ssa_v0_pview
  const int64_t v130 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v131 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v132 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v133 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v129 + (v130 + v128), v131, v132);
  __gm__ int32_t* v134 = PTOAS__GLOBAL_TENSOR_DATA(v133);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v134);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
  // pto: %t__tile
  int32_t v135 = (v16)[v127];
  // pto: %66
  int32_t v136 = (int32_t) ((uint32_t) v135 + (uint32_t) v22);
  pipe_barrier(PIPE_ALL);
  pto::comm::NotifyOp v137 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v133, v136, v137);
  // pto: %68, %69
  int64_t v138 = (int64_t) ((uint64_t) v17 + (uint64_t) v46) / v33;
  // pto: %70
  if (v17 >= v47) {
    for (int64_t v139 = v126; v139 < v31; v139 += v48) {
      // pto: %71
      ;
      int64_t v140 = v139 / v30;
      // pto: %72
      ;
      int64_t v141 = v139 % v30;
      // pto: %73, %74, %75
      ;
      int64_t v142 = v141 < v45 ? (int64_t) ((uint64_t) v141 + (uint64_t) v30) : v141;
      // pto: %76
      ;
      int64_t v143 = (int64_t) ((uint64_t) v142 * (uint64_t) v36);
      // pto: %77, %78
      ;
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v144 = v45; v144 < ((int64_t) ((uint64_t) v138 + (uint64_t) v49) / v30); v144 += v29) {
        // pto: %79
        ;
        int64_t v145 = (int64_t) ((uint64_t) v144 * (uint64_t) v30);
        // pto: %flat_offset, %81, %82, %80
        ;
        int32_t v146 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v144 * (uint64_t) v31) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
        // pto: %83
        ;
        int64_t v147 = (int64_t) v146;
        // pto: %84
        ;
        int64_t v148 = v147 < v45 ? v45 : v147;
        // pto: %85
        ;
        int64_t v149 = (int64_t) ((uint64_t) v145 + (uint64_t) v29);
        // pto: %86
        ;
        // pto: %seed_same_start__phi_v3
        ;
        int64_t v150;
        if (v149 < v138) {
          // pto: %89, %90, %91, %92, %87
          ;
          int32_t v151 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v149 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %93
          ;
          int64_t v152 = (int64_t) v151;
          // pto: %94
          ;
          int64_t v153 = v152 < v45 ? v45 : v152;
          // pto: %95, %seed_same_start__phi_v2
          ;
          v150 = v153 != v148 ? v45 : v29;
        } else {
          v150 = v29;
        };
        // pto: %96
        ;
        int64_t v154 = (int64_t) ((uint64_t) v145 + (uint64_t) v50);
        // pto: %97
        ;
        // pto: %seed_same_start__phi_v6
        ;
        int64_t v155;
        if (v154 < v138) {
          // pto: %100, %101, %102, %103, %98
          ;
          int32_t v156 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v154 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %104
          ;
          int64_t v157 = (int64_t) v156;
          // pto: %105
          ;
          int64_t v158 = v157 < v45 ? v45 : v157;
          // pto: %106, %seed_same_start__phi_v5
          ;
          int64_t v159 = v158 != v148 ? v45 : v150;
          v155 = v159;
        } else {
          v155 = v150;
        };
        // pto: %107
        ;
        int64_t v160 = (int64_t) ((uint64_t) v145 + (uint64_t) v51);
        // pto: %108
        ;
        // pto: %seed_same_start__phi_v9
        ;
        int64_t v161;
        if (v160 < v138) {
          // pto: %111, %112, %113, %114, %109
          ;
          int32_t v162 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v160 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %115
          ;
          int64_t v163 = (int64_t) v162;
          // pto: %116
          ;
          int64_t v164 = v163 < v45 ? v45 : v163;
          // pto: %117, %seed_same_start__phi_v8
          ;
          int64_t v165 = v164 != v148 ? v45 : v155;
          v161 = v165;
        } else {
          v161 = v155;
        };
        // pto: %118
        ;
        int64_t v166 = (int64_t) ((uint64_t) v145 + (uint64_t) v43);
        // pto: %119
        ;
        // pto: %seed_same_start__phi_v12
        ;
        int64_t v167;
        if (v166 < v138) {
          // pto: %122, %123, %124, %125, %120
          ;
          int32_t v168 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v166 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %126
          ;
          int64_t v169 = (int64_t) v168;
          // pto: %127
          ;
          int64_t v170 = v169 < v45 ? v45 : v169;
          // pto: %128, %seed_same_start__phi_v11
          ;
          int64_t v171 = v170 != v148 ? v45 : v161;
          v167 = v171;
        } else {
          v167 = v161;
        };
        // pto: %129
        ;
        int64_t v172 = (int64_t) ((uint64_t) v145 + (uint64_t) v52);
        // pto: %130
        ;
        // pto: %seed_same_start__phi_v15
        ;
        int64_t v173;
        if (v172 < v138) {
          // pto: %133, %134, %135, %136, %131
          ;
          int32_t v174 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v172 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %137
          ;
          int64_t v175 = (int64_t) v174;
          // pto: %138
          ;
          int64_t v176 = v175 < v45 ? v45 : v175;
          // pto: %139, %seed_same_start__phi_v14
          ;
          int64_t v177 = v176 != v148 ? v45 : v167;
          v173 = v177;
        } else {
          v173 = v167;
        };
        // pto: %140
        ;
        int64_t v178 = (int64_t) ((uint64_t) v145 + (uint64_t) v53);
        // pto: %141
        ;
        // pto: %seed_same_start__phi_v18
        ;
        int64_t v179;
        if (v178 < v138) {
          // pto: %144, %145, %146, %147, %142
          ;
          int32_t v180 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v178 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %148
          ;
          int64_t v181 = (int64_t) v180;
          // pto: %149
          ;
          int64_t v182 = v181 < v45 ? v45 : v181;
          // pto: %150, %seed_same_start__phi_v17
          ;
          int64_t v183 = v182 != v148 ? v45 : v173;
          v179 = v183;
        } else {
          v179 = v173;
        };
        // pto: %151
        ;
        int64_t v184 = (int64_t) ((uint64_t) v145 + (uint64_t) v49);
        // pto: %152
        ;
        // pto: %seed_same_start__phi_v21
        ;
        int64_t v185;
        if (v184 < v138) {
          // pto: %155, %156, %157, %158, %153
          ;
          int32_t v186 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v184 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %159
          ;
          int64_t v187 = (int64_t) v186;
          // pto: %160
          ;
          int64_t v188 = v187 < v45 ? v45 : v187;
          // pto: %161, %seed_same_start__phi_v20
          ;
          int64_t v189 = v188 != v148 ? v45 : v179;
          v185 = v189;
        } else {
          v185 = v179;
        };
        // pto: %162, %seed_same_start__phi_v25
        ;
        int64_t v190 = v148 > v54 ? v45 : v185;
        // pto: %163
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        if (v190 == v29) {
          int64_t v191 = (int64_t) ((uint64_t) v144 * (uint64_t) v36);
          // pto: %165
          ;
          int64_t v192 = (int64_t) ((uint64_t) v17 - (uint64_t) v191);
          // pto: %166
          ;
          int64_t v193 = v192 < v36 ? v192 : v36;
          // pto: %167
          ;
          int64_t v194 = (int64_t) ((uint64_t) v148 * (uint64_t) v33);
          // pto: %seed_fast_seed_x__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v195 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v32);
          // pto: %seed_fast_seed_x__tile
          ;
          uint64_t v196 = (uint64_t) v23;
          TASSIGN(v195, v196);
          // pto: %168
          ;
          int64_t v197 = v191 < v45 ? v45 : v191;
          // pto: %169
          ;
          int64_t v198 = (int64_t) ((uint64_t) v140 * (uint64_t) v41);
          // pto: %170
          ;
          int64_t v199 = (int64_t) ((uint64_t) v198 + (uint64_t) v194);
          // pto: %171
          ;
          int64_t v200 = v199 < v45 ? v45 : v199;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v201 = 0;
          // pto: %heads__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v202 = PTOAS__GLOBAL_TENSOR_DATA(v70);
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v203 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v204 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v205 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          int64_t v206 = v193 * v28;
          // pto: %heads__ssa_v0_pview
          ;
          int64_t v207 = v205 * v206;
          // pto: %heads__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, -1, 256> v208 = pto::Shape<1, 1, 1, -1, 256>(v203, v204, v205, v193, v32);
          // pto: %heads__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v209 = pto::Stride<-1, -1, -1, -1, -1>(v204 * v207, v207, v206, v28, v29);
          // pto: %heads__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v210 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v202 + (v201 + v197 * v28 + v200 * v29), v208, v209);
          TLOAD(v195, v210);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %seed_fast_seed_w__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
          // pto: %seed_fast_seed_w__tile
          ;
          uint64_t v212 = (uint64_t) v24;
          TASSIGN(v211, v212);
          // pto: %172
          ;
          int64_t v213 = v140 < v45 ? v45 : v140;
          // pto: %173
          ;
          int64_t v214 = v143 / v33;
          // pto: %174
          ;
          int64_t v215 = v214 < v45 ? v45 : v214;
          // pto: %175
          ;
          int64_t v216 = v194 / v33;
          // pto: %176
          ;
          int64_t v217 = v216 < v45 ? v45 : v216;
          // pto: %wo_a__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v218 = PTOAS__GLOBAL_TENSOR_DATA(v73);
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v219 = 0;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v220 = 4194304;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v221 = 65536;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v222 = 256;
          // pto: %wo_a__ssa_v0_pview
          ;
          pto::Shape<1, 8, 16, 16, 16> v223 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %wo_a__ssa_v0_pview
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v224 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %wo_a__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v225 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v218 + ((v219 + v213 * v220) + v215 * v221 + v217 * v222), v223, v224);
          TLOAD(v211, v225);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %seed_fast_acc__tile_l0_init_storage
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v226 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
          // pto: %seed_fast_acc__tile_l0_init_storage
          ;
          uint64_t v227 = (uint64_t) v23;
          TASSIGN(v226, v227);
          v226.SetValidShape(v193, v36);
          // pto: %seed_fast_acc__tile_l0_a
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v228 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
          // pto: %seed_fast_acc__tile_l0_a
          ;
          uint64_t v229 = (uint64_t) v23;
          TASSIGN(v228, v229);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          uint16_t v230 = static_cast<uint16_t>(v45);
          uint16_t v231 = static_cast<uint16_t>(v45);
          TEXTRACT(v228, v195, v230, v231);
          // pto: %seed_fast_acc__tile_l0_b
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
          // pto: %seed_fast_acc__tile_l0_b
          ;
          uint64_t v233 = (uint64_t) v23;
          TASSIGN(v232, v233);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v234 = static_cast<uint16_t>(v45);
          uint16_t v235 = static_cast<uint16_t>(v45);
          TEXTRACT(v232, v211, v234, v235);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          // pto: %0
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v236 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
          // pto: %0
          ;
          uint64_t v237 = (uint64_t) v25;
          TASSIGN(v236, v237);
          uint16_t v238 = static_cast<uint16_t>(v45);
          uint16_t v239 = static_cast<uint16_t>(v36);
          TEXTRACT(v236, v195, v238, v239);
          // pto: %1
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
          // pto: %1
          ;
          uint64_t v241 = (uint64_t) v25;
          TASSIGN(v240, v241);
          uint16_t v242 = static_cast<uint16_t>(v36);
          uint16_t v243 = static_cast<uint16_t>(v45);
          TEXTRACT(v240, v211, v242, v243);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          TMATMUL(v226, v228, v232);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          TMATMUL_ACC(v226, v226, v236, v240);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
          for (int64_t v244 = v29; v244 < v46; v244 += v50) {
            // pto: %177
            ;
            int64_t v245 = (int64_t) ((uint64_t) v244 * (uint64_t) v33);
            // pto: %178, %179
            ;
            int64_t v246 = (int64_t) ((uint64_t) v148 + (uint64_t) v245) % v32;
            // pto: %180, %181, %182
            ;
            int64_t v247 = v246 < v45 ? (int64_t) ((uint64_t) v246 + (uint64_t) v32) : v246;
            // pto: %185, %184, %186
            ;
            int64_t v248 = (int64_t) ((uint64_t) v148 + (uint64_t) ((int64_t) (uint64_t) v245 + (uint64_t) v33)) % v32;
            // pto: %187, %188, %189
            ;
            int64_t v249 = v248 < v45 ? (int64_t) ((uint64_t) v248 + (uint64_t) v32) : v248;
            // pto: %190
            ;
            // pto: %191
            ;
            int64_t v250 = v193 < v36 ? v193 : v36;
            v114.SetValidShape(v250, v36);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            if (v247 <= v54) {
              // pto: %192
              ;
              int64_t v251 = (int64_t) ((uint64_t) v247 * (uint64_t) v33);
              // pto: %seed_fast_packet_x__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v252 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v32);
              // pto: %seed_fast_packet_x__tile
              ;
              uint64_t v253 = (uint64_t) v23;
              TASSIGN(v252, v253);
              // pto: %195
              ;
              int64_t v254 = (int64_t) ((uint64_t) v198 + (uint64_t) v251);
              // pto: %196
              ;
              int64_t v255 = v254 < v45 ? v45 : v254;
              // pto: %197
              ;
              const int64_t v256 = 0;
              // pto: %197
              ;
              __gm__ bfloat16_t* v257 = PTOAS__GLOBAL_TENSOR_DATA(v70);
              // pto: %197
              ;
              const int64_t v258 = 1;
              // pto: %197
              ;
              const int64_t v259 = 1;
              // pto: %197
              ;
              const int64_t v260 = 1;
              // pto: %197
              ;
              int64_t v261 = v193 * v28;
              // pto: %197
              ;
              int64_t v262 = v260 * v261;
              // pto: %197
              ;
              pto::Shape<1, 1, 1, -1, 256> v263 = pto::Shape<1, 1, 1, -1, 256>(v258, v259, v260, v193, v32);
              // pto: %197
              ;
              pto::Stride<-1, -1, -1, -1, -1> v264 = pto::Stride<-1, -1, -1, -1, -1>(v259 * v262, v262, v261, v28, v29);
              // pto: %197
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v265 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v257 + (v256 + v197 * v28 + v255 * v29), v263, v264);
              TLOAD(v252, v265);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
              // pto: %seed_fast_packet_w__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
              // pto: %seed_fast_packet_w__tile
              ;
              uint64_t v267 = (uint64_t) v24;
              TASSIGN(v266, v267);
              // pto: %201
              ;
              int64_t v268 = v251 / v33;
              // pto: %202
              ;
              int64_t v269 = v268 < v45 ? v45 : v268;
              // pto: %203
              ;
              __gm__ bfloat16_t* v270 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %203
              ;
              const int64_t v271 = 0;
              // pto: %203
              ;
              const int64_t v272 = 4194304;
              // pto: %203
              ;
              const int64_t v273 = 65536;
              // pto: %203
              ;
              const int64_t v274 = 256;
              // pto: %203
              ;
              pto::Shape<1, 8, 16, 16, 16> v275 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %203
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v276 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %203
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v277 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v270 + ((v271 + v213 * v272) + v215 * v273 + v269 * v274), v275, v276);
              TLOAD(v266, v277);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
              // pto: %seed_fast_acc__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v278 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
              // pto: %seed_fast_acc__iter_v1_l0_a
              ;
              uint64_t v279 = (uint64_t) v23;
              TASSIGN(v278, v279);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
              uint16_t v280 = static_cast<uint16_t>(v45);
              uint16_t v281 = static_cast<uint16_t>(v45);
              TEXTRACT(v278, v252, v280, v281);
              // pto: %seed_fast_acc__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v282 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %seed_fast_acc__iter_v1_l0_b
              ;
              uint64_t v283 = (uint64_t) v23;
              TASSIGN(v282, v283);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
              uint16_t v284 = static_cast<uint16_t>(v45);
              uint16_t v285 = static_cast<uint16_t>(v45);
              TEXTRACT(v282, v266, v284, v285);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
              // pto: %3
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v286 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
              // pto: %3
              ;
              uint64_t v287 = (uint64_t) v25;
              TASSIGN(v286, v287);
              uint16_t v288 = static_cast<uint16_t>(v45);
              uint16_t v289 = static_cast<uint16_t>(v36);
              TEXTRACT(v286, v252, v288, v289);
              // pto: %4
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %4
              ;
              uint64_t v291 = (uint64_t) v25;
              TASSIGN(v290, v291);
              uint16_t v292 = static_cast<uint16_t>(v36);
              uint16_t v293 = static_cast<uint16_t>(v45);
              TEXTRACT(v290, v266, v292, v293);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v226, v226, v278, v282);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
              TMATMUL_ACC(v226, v226, v286, v290);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              for (int64_t v294 = v45; v294 < v33; v294 += v29) {
                // pto: %204, %205
                ;
                int64_t v295 = (int64_t) ((uint64_t) v247 + (uint64_t) v294) % v32;
                // pto: %206, %207, %208
                ;
                int64_t v296 = v295 < v45 ? (int64_t) ((uint64_t) v295 + (uint64_t) v32) : v295;
                // pto: %209
                ;
                int64_t v297 = (int64_t) ((uint64_t) v296 * (uint64_t) v33);
                // pto: %seed_fast_wrap_x__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v33);
                // pto: %seed_fast_wrap_x__tile
                ;
                uint64_t v299 = (uint64_t) v23;
                TASSIGN(v298, v299);
                // pto: %212
                ;
                int64_t v300 = (int64_t) ((uint64_t) v198 + (uint64_t) v297);
                // pto: %213
                ;
                int64_t v301 = v300 < v45 ? v45 : v300;
                // pto: %214
                ;
                const int64_t v302 = 0;
                // pto: %214
                ;
                __gm__ bfloat16_t* v303 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                // pto: %214
                ;
                const int64_t v304 = 1;
                // pto: %214
                ;
                const int64_t v305 = 1;
                // pto: %214
                ;
                const int64_t v306 = 1;
                // pto: %214
                ;
                int64_t v307 = v193 * v28;
                // pto: %214
                ;
                int64_t v308 = v306 * v307;
                // pto: %214
                ;
                pto::Shape<1, 1, 1, -1, 16> v309 = pto::Shape<1, 1, 1, -1, 16>(v304, v305, v306, v193, v33);
                // pto: %214
                ;
                pto::Stride<-1, -1, -1, -1, -1> v310 = pto::Stride<-1, -1, -1, -1, -1>(v305 * v308, v308, v307, v28, v29);
                // pto: %214
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v311 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v303 + (v302 + v197 * v28 + v301 * v29), v309, v310);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v298, v311);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
                // pto: %seed_fast_wrap_w__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %seed_fast_wrap_w__tile
                ;
                uint64_t v313 = (uint64_t) v24;
                TASSIGN(v312, v313);
                // pto: %218
                ;
                int64_t v314 = v297 / v33;
                // pto: %219
                ;
                int64_t v315 = v314 < v45 ? v45 : v314;
                // pto: %220
                ;
                __gm__ bfloat16_t* v316 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                // pto: %220
                ;
                const int64_t v317 = 0;
                // pto: %220
                ;
                const int64_t v318 = 4194304;
                // pto: %220
                ;
                const int64_t v319 = 65536;
                // pto: %220
                ;
                const int64_t v320 = 256;
                // pto: %220
                ;
                pto::Shape<1, 8, 1, 16, 16> v321 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %220
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v322 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %220
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v323 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v316 + ((v317 + v213 * v318) + v215 * v319 + v315 * v320), v321, v322);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
                TLOAD(v312, v323);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
                // pto: %lhs_slice_0_textract
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v324 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v33);
                // pto: %lhs_slice_0_textract
                ;
                uint64_t v325 = (uint64_t) v23;
                TASSIGN(v324, v325);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
                uint16_t v326 = static_cast<uint16_t>(v45);
                uint16_t v327 = static_cast<uint16_t>(v45);
                TEXTRACT(v324, v298, v326, v327);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                // pto: %rhs_slice_0_textract
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %rhs_slice_0_textract
                ;
                uint64_t v329 = (uint64_t) v23;
                TASSIGN(v328, v329);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
                uint16_t v330 = static_cast<uint16_t>(v45);
                uint16_t v331 = static_cast<uint16_t>(v45);
                TEXTRACT(v328, v312, v330, v331);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v226, v226, v324, v328);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              };
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            // pto: %221
            ;
            v116.SetValidShape(v250, v36);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
            if (v249 <= v54) {
              // pto: %224
              ;
              int64_t v332 = (int64_t) ((uint64_t) v249 * (uint64_t) v33);
              // pto: %6
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v333 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v32);
              // pto: %6
              ;
              uint64_t v334 = (uint64_t) v26;
              TASSIGN(v333, v334);
              // pto: %227
              ;
              int64_t v335 = (int64_t) ((uint64_t) v198 + (uint64_t) v332);
              // pto: %228
              ;
              int64_t v336 = v335 < v45 ? v45 : v335;
              // pto: %229
              ;
              const int64_t v337 = 0;
              // pto: %229
              ;
              __gm__ bfloat16_t* v338 = PTOAS__GLOBAL_TENSOR_DATA(v70);
              // pto: %229
              ;
              const int64_t v339 = 1;
              // pto: %229
              ;
              const int64_t v340 = 1;
              // pto: %229
              ;
              const int64_t v341 = 1;
              // pto: %229
              ;
              int64_t v342 = v193 * v28;
              // pto: %229
              ;
              int64_t v343 = v341 * v342;
              // pto: %229
              ;
              pto::Shape<1, 1, 1, -1, 256> v344 = pto::Shape<1, 1, 1, -1, 256>(v339, v340, v341, v193, v32);
              // pto: %229
              ;
              pto::Stride<-1, -1, -1, -1, -1> v345 = pto::Stride<-1, -1, -1, -1, -1>(v340 * v343, v343, v342, v28, v29);
              // pto: %229
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v346 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v338 + (v337 + v197 * v28 + v336 * v29), v344, v345);
              TLOAD(v333, v346);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
              // pto: %7
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
              // pto: %7
              ;
              uint64_t v348 = (uint64_t) v27;
              TASSIGN(v347, v348);
              // pto: %233
              ;
              int64_t v349 = v332 / v33;
              // pto: %234
              ;
              int64_t v350 = v349 < v45 ? v45 : v349;
              // pto: %235
              ;
              __gm__ bfloat16_t* v351 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %235
              ;
              const int64_t v352 = 0;
              // pto: %235
              ;
              const int64_t v353 = 4194304;
              // pto: %235
              ;
              const int64_t v354 = 65536;
              // pto: %235
              ;
              const int64_t v355 = 256;
              // pto: %235
              ;
              pto::Shape<1, 8, 16, 16, 16> v356 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %235
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v357 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %235
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v358 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v351 + ((v352 + v213 * v353) + v215 * v354 + v350 * v355), v356, v357);
              TLOAD(v347, v358);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
              // pto: %8
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v359 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
              // pto: %8
              ;
              uint64_t v360 = (uint64_t) v23;
              TASSIGN(v359, v360);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
              uint16_t v361 = static_cast<uint16_t>(v45);
              uint16_t v362 = static_cast<uint16_t>(v45);
              TEXTRACT(v359, v333, v361, v362);
              // pto: %9
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v363 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %9
              ;
              uint64_t v364 = (uint64_t) v23;
              TASSIGN(v363, v364);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
              uint16_t v365 = static_cast<uint16_t>(v45);
              uint16_t v366 = static_cast<uint16_t>(v45);
              TEXTRACT(v363, v347, v365, v366);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
              // pto: %10
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v367 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
              // pto: %10
              ;
              uint64_t v368 = (uint64_t) v25;
              TASSIGN(v367, v368);
              uint16_t v369 = static_cast<uint16_t>(v45);
              uint16_t v370 = static_cast<uint16_t>(v36);
              TEXTRACT(v367, v333, v369, v370);
              // pto: %11
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v371 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %11
              ;
              uint64_t v372 = (uint64_t) v25;
              TASSIGN(v371, v372);
              uint16_t v373 = static_cast<uint16_t>(v36);
              uint16_t v374 = static_cast<uint16_t>(v45);
              TEXTRACT(v371, v347, v373, v374);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v114, v114, v359, v363);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
              TMATMUL_ACC(v114, v114, v367, v371);
            } else {
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
              for (int64_t v375 = v45; v375 < v33; v375 += v29) {
                // pto: %237, %238
                ;
                int64_t v376 = (int64_t) ((uint64_t) v249 + (uint64_t) v375) % v32;
                // pto: %239, %240, %241
                ;
                int64_t v377 = v376 < v45 ? (int64_t) ((uint64_t) v376 + (uint64_t) v32) : v376;
                // pto: %242
                ;
                int64_t v378 = (int64_t) ((uint64_t) v377 * (uint64_t) v33);
                // pto: %14
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v379 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v33);
                // pto: %14
                ;
                uint64_t v380 = (uint64_t) v26;
                TASSIGN(v379, v380);
                // pto: %245
                ;
                int64_t v381 = (int64_t) ((uint64_t) v198 + (uint64_t) v378);
                // pto: %246
                ;
                int64_t v382 = v381 < v45 ? v45 : v381;
                // pto: %247
                ;
                const int64_t v383 = 0;
                // pto: %247
                ;
                __gm__ bfloat16_t* v384 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                // pto: %247
                ;
                const int64_t v385 = 1;
                // pto: %247
                ;
                const int64_t v386 = 1;
                // pto: %247
                ;
                const int64_t v387 = 1;
                // pto: %247
                ;
                int64_t v388 = v193 * v28;
                // pto: %247
                ;
                int64_t v389 = v387 * v388;
                // pto: %247
                ;
                pto::Shape<1, 1, 1, -1, 16> v390 = pto::Shape<1, 1, 1, -1, 16>(v385, v386, v387, v193, v33);
                // pto: %247
                ;
                pto::Stride<-1, -1, -1, -1, -1> v391 = pto::Stride<-1, -1, -1, -1, -1>(v386 * v389, v389, v388, v28, v29);
                // pto: %247
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v392 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v384 + (v383 + v197 * v28 + v382 * v29), v390, v391);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                TLOAD(v379, v392);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %15
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v393 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %15
                ;
                uint64_t v394 = (uint64_t) v27;
                TASSIGN(v393, v394);
                // pto: %251
                ;
                int64_t v395 = v378 / v33;
                // pto: %252
                ;
                int64_t v396 = v395 < v45 ? v45 : v395;
                // pto: %253
                ;
                __gm__ bfloat16_t* v397 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                // pto: %253
                ;
                const int64_t v398 = 0;
                // pto: %253
                ;
                const int64_t v399 = 4194304;
                // pto: %253
                ;
                const int64_t v400 = 65536;
                // pto: %253
                ;
                const int64_t v401 = 256;
                // pto: %253
                ;
                pto::Shape<1, 8, 1, 16, 16> v402 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %253
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v403 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %253
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v404 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v397 + ((v398 + v213 * v399) + v215 * v400 + v396 * v401), v402, v403);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
                TLOAD(v393, v404);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %16
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v405 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v33);
                // pto: %16
                ;
                uint64_t v406 = (uint64_t) v23;
                TASSIGN(v405, v406);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
                uint16_t v407 = static_cast<uint16_t>(v45);
                uint16_t v408 = static_cast<uint16_t>(v45);
                TEXTRACT(v405, v379, v407, v408);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                // pto: %17
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v409 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %17
                ;
                uint64_t v410 = (uint64_t) v23;
                TASSIGN(v409, v410);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v411 = static_cast<uint16_t>(v45);
                uint16_t v412 = static_cast<uint16_t>(v45);
                TEXTRACT(v409, v393, v411, v412);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v114, v114, v405, v409);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
              };
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %254, %255
          ;
          int64_t v413 = (int64_t) ((uint64_t) v148 + (uint64_t) v54) % v32;
          // pto: %256, %257, %258
          ;
          int64_t v414 = v413 < v45 ? (int64_t) ((uint64_t) v413 + (uint64_t) v32) : v413;
          // pto: %259
          ;
          // pto: %260
          ;
          int64_t v415 = v193 < v36 ? v193 : v36;
          v118.SetValidShape(v415, v36);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
          if (v414 <= v54) {
            // pto: %262
            ;
            int64_t v416 = (int64_t) ((uint64_t) v414 * (uint64_t) v33);
            // pto: %19
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v417 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v32);
            // pto: %19
            ;
            uint64_t v418 = (uint64_t) v23;
            TASSIGN(v417, v418);
            // pto: %265
            ;
            int64_t v419 = (int64_t) ((uint64_t) v198 + (uint64_t) v416);
            // pto: %266
            ;
            int64_t v420 = v419 < v45 ? v45 : v419;
            // pto: %267
            ;
            const int64_t v421 = 0;
            // pto: %267
            ;
            __gm__ bfloat16_t* v422 = PTOAS__GLOBAL_TENSOR_DATA(v70);
            // pto: %267
            ;
            const int64_t v423 = 1;
            // pto: %267
            ;
            const int64_t v424 = 1;
            // pto: %267
            ;
            const int64_t v425 = 1;
            // pto: %267
            ;
            int64_t v426 = v193 * v28;
            // pto: %267
            ;
            int64_t v427 = v425 * v426;
            // pto: %267
            ;
            pto::Shape<1, 1, 1, -1, 256> v428 = pto::Shape<1, 1, 1, -1, 256>(v423, v424, v425, v193, v32);
            // pto: %267
            ;
            pto::Stride<-1, -1, -1, -1, -1> v429 = pto::Stride<-1, -1, -1, -1, -1>(v424 * v427, v427, v426, v28, v29);
            // pto: %267
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v430 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v422 + (v421 + v197 * v28 + v420 * v29), v428, v429);
            TLOAD(v417, v430);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %20
            ;
            Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v431 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
            // pto: %20
            ;
            uint64_t v432 = (uint64_t) v24;
            TASSIGN(v431, v432);
            // pto: %271
            ;
            int64_t v433 = v416 / v33;
            // pto: %272
            ;
            int64_t v434 = v433 < v45 ? v45 : v433;
            // pto: %273
            ;
            __gm__ bfloat16_t* v435 = PTOAS__GLOBAL_TENSOR_DATA(v73);
            // pto: %273
            ;
            const int64_t v436 = 0;
            // pto: %273
            ;
            const int64_t v437 = 4194304;
            // pto: %273
            ;
            const int64_t v438 = 65536;
            // pto: %273
            ;
            const int64_t v439 = 256;
            // pto: %273
            ;
            pto::Shape<1, 8, 16, 16, 16> v440 = pto::Shape<1, 8, 16, 16, 16>();
            // pto: %273
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v441 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %273
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v442 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v435 + ((v436 + v213 * v437) + v215 * v438 + v434 * v439), v440, v441);
            TLOAD(v431, v442);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %21
            ;
            Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v443 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
            // pto: %21
            ;
            uint64_t v444 = (uint64_t) v23;
            TASSIGN(v443, v444);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            uint16_t v445 = static_cast<uint16_t>(v45);
            uint16_t v446 = static_cast<uint16_t>(v45);
            TEXTRACT(v443, v417, v445, v446);
            // pto: %22
            ;
            Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v447 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
            // pto: %22
            ;
            uint64_t v448 = (uint64_t) v23;
            TASSIGN(v447, v448);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v449 = static_cast<uint16_t>(v45);
            uint16_t v450 = static_cast<uint16_t>(v45);
            TEXTRACT(v447, v431, v449, v450);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            // pto: %23
            ;
            Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v451 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
            // pto: %23
            ;
            uint64_t v452 = (uint64_t) v25;
            TASSIGN(v451, v452);
            uint16_t v453 = static_cast<uint16_t>(v45);
            uint16_t v454 = static_cast<uint16_t>(v36);
            TEXTRACT(v451, v417, v453, v454);
            // pto: %24
            ;
            Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v455 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
            // pto: %24
            ;
            uint64_t v456 = (uint64_t) v25;
            TASSIGN(v455, v456);
            uint16_t v457 = static_cast<uint16_t>(v36);
            uint16_t v458 = static_cast<uint16_t>(v45);
            TEXTRACT(v455, v431, v457, v458);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v226, v226, v443, v447);
            pipe_barrier(PIPE_M);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
            TMATMUL_ACC(v226, v226, v451, v455);
          } else {
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            for (int64_t v459 = v45; v459 < v33; v459 += v29) {
              // pto: %275, %276
              ;
              int64_t v460 = (int64_t) ((uint64_t) v414 + (uint64_t) v459) % v32;
              // pto: %277, %278, %279
              ;
              int64_t v461 = v460 < v45 ? (int64_t) ((uint64_t) v460 + (uint64_t) v32) : v460;
              // pto: %280
              ;
              int64_t v462 = (int64_t) ((uint64_t) v461 * (uint64_t) v33);
              // pto: %27
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v463 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v33);
              // pto: %27
              ;
              uint64_t v464 = (uint64_t) v23;
              TASSIGN(v463, v464);
              // pto: %283
              ;
              int64_t v465 = (int64_t) ((uint64_t) v198 + (uint64_t) v462);
              // pto: %284
              ;
              int64_t v466 = v465 < v45 ? v45 : v465;
              // pto: %285
              ;
              const int64_t v467 = 0;
              // pto: %285
              ;
              __gm__ bfloat16_t* v468 = PTOAS__GLOBAL_TENSOR_DATA(v70);
              // pto: %285
              ;
              const int64_t v469 = 1;
              // pto: %285
              ;
              const int64_t v470 = 1;
              // pto: %285
              ;
              const int64_t v471 = 1;
              // pto: %285
              ;
              int64_t v472 = v193 * v28;
              // pto: %285
              ;
              int64_t v473 = v471 * v472;
              // pto: %285
              ;
              pto::Shape<1, 1, 1, -1, 16> v474 = pto::Shape<1, 1, 1, -1, 16>(v469, v470, v471, v193, v33);
              // pto: %285
              ;
              pto::Stride<-1, -1, -1, -1, -1> v475 = pto::Stride<-1, -1, -1, -1, -1>(v470 * v473, v473, v472, v28, v29);
              // pto: %285
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v476 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v468 + (v467 + v197 * v28 + v466 * v29), v474, v475);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              TLOAD(v463, v476);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %28
              ;
              Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v477 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %28
              ;
              uint64_t v478 = (uint64_t) v24;
              TASSIGN(v477, v478);
              // pto: %289
              ;
              int64_t v479 = v462 / v33;
              // pto: %290
              ;
              int64_t v480 = v479 < v45 ? v45 : v479;
              // pto: %291
              ;
              __gm__ bfloat16_t* v481 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %291
              ;
              const int64_t v482 = 0;
              // pto: %291
              ;
              const int64_t v483 = 4194304;
              // pto: %291
              ;
              const int64_t v484 = 65536;
              // pto: %291
              ;
              const int64_t v485 = 256;
              // pto: %291
              ;
              pto::Shape<1, 8, 1, 16, 16> v486 = pto::Shape<1, 8, 1, 16, 16>();
              // pto: %291
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v487 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %291
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v488 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v481 + ((v482 + v213 * v483) + v215 * v484 + v480 * v485), v486, v487);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              TLOAD(v477, v488);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %29
              ;
              Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v489 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v33);
              // pto: %29
              ;
              uint64_t v490 = (uint64_t) v23;
              TASSIGN(v489, v490);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
              uint16_t v491 = static_cast<uint16_t>(v45);
              uint16_t v492 = static_cast<uint16_t>(v45);
              TEXTRACT(v489, v463, v491, v492);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              // pto: %30
              ;
              Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v493 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %30
              ;
              uint64_t v494 = (uint64_t) v23;
              TASSIGN(v493, v494);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v495 = static_cast<uint16_t>(v45);
              uint16_t v496 = static_cast<uint16_t>(v45);
              TEXTRACT(v493, v477, v495, v496);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v226, v226, v489, v493);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            };
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          };
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          // pto: %seed_fast_acc__rv_v2
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v497 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v193, v36);
          // pto: %seed_fast_acc__rv_v2
          ;
          uint64_t v498 = (uint64_t) v23;
          TASSIGN(v497, v498);
          // pto: %293, %294
          ;
          int64_t v499 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v55) + (uint64_t) v143);
          // pto: %295
          ;
          int64_t v500 = v499 < v45 ? v45 : v499;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v501 = 0;
          // pto: %accum__ssa_v0_pview
          ;
          __gm__ float* v502 = PTOAS__GLOBAL_TENSOR_DATA(v94);
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v503 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v504 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v505 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          int64_t v506 = v193 * v42;
          // pto: %accum__ssa_v0_pview
          ;
          int64_t v507 = v505 * v506;
          // pto: %accum__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, -1, 128> v508 = pto::Shape<1, 1, 1, -1, 128>(v503, v504, v505, v193, v36);
          // pto: %accum__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v509 = pto::Stride<-1, -1, -1, -1, -1>(v504 * v507, v507, v506, v42, v29);
          // pto: %accum__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v510 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v502 + (v501 + v197 * v42 + v500 * v29), v508, v509);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          TSTORE(v510, v497);
        } else {
          for (int64_t v511 = v45; v511 < v30; v511 += v29) {
            // pto: %296
            ;
            int64_t v512 = (int64_t) ((uint64_t) v145 + (uint64_t) v511);
            // pto: %297
            ;
            if (v512 < v138) {
              // pto: %298
              ;
              int64_t v513 = (int64_t) ((uint64_t) v512 * (uint64_t) v33);
              // pto: %299
              ;
              int64_t v514 = (int64_t) ((uint64_t) v17 - (uint64_t) v513);
              // pto: %300
              ;
              int64_t v515 = v514 < v33 ? v514 : v33;
              // pto: %302, %303, %304, %305, %301
              ;
              int32_t v516 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v512 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
              // pto: %306
              ;
              int64_t v517 = (int64_t) v516;
              // pto: %307
              ;
              int64_t v518 = v517 < v45 ? v45 : v517;
              // pto: %seed_narrow_acc__tile
              ;
              Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v519 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %seed_narrow_acc__tile
              ;
              uint64_t v520 = (uint64_t) v23;
              TASSIGN(v519, v520);
              wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              for (int64_t v521 = v45; v521 < v33; v521 += v29) {
                // pto: %308
                ;
                int64_t v522 = (int64_t) ((uint64_t) v521 * (uint64_t) v33);
                // pto: %309, %310
                ;
                int64_t v523 = (int64_t) ((uint64_t) v518 + (uint64_t) v522) % v32;
                // pto: %311, %312, %313
                ;
                int64_t v524 = v523 < v45 ? (int64_t) ((uint64_t) v523 + (uint64_t) v32) : v523;
                // pto: %314
                ;
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                if (v524 <= v54) {
                  // pto: %315
                  ;
                  int64_t v525 = (int64_t) ((uint64_t) v524 * (uint64_t) v33);
                  // pto: %seed_narrow_packet_x__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v526 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v515, v32);
                  // pto: %seed_narrow_packet_x__tile
                  ;
                  uint64_t v527 = (uint64_t) v24;
                  TASSIGN(v526, v527);
                  // pto: %316
                  ;
                  int64_t v528 = v513 < v45 ? v45 : v513;
                  // pto: %317, %318
                  ;
                  int64_t v529 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v41) + (uint64_t) v525);
                  // pto: %319
                  ;
                  int64_t v530 = v529 < v45 ? v45 : v529;
                  // pto: %320
                  ;
                  const int64_t v531 = 0;
                  // pto: %320
                  ;
                  __gm__ bfloat16_t* v532 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                  // pto: %320
                  ;
                  const int64_t v533 = 1;
                  // pto: %320
                  ;
                  const int64_t v534 = 1;
                  // pto: %320
                  ;
                  const int64_t v535 = 1;
                  // pto: %320
                  ;
                  int64_t v536 = v515 * v28;
                  // pto: %320
                  ;
                  int64_t v537 = v535 * v536;
                  // pto: %320
                  ;
                  pto::Shape<1, 1, 1, -1, 256> v538 = pto::Shape<1, 1, 1, -1, 256>(v533, v534, v535, v515, v32);
                  // pto: %320
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v539 = pto::Stride<-1, -1, -1, -1, -1>(v534 * v537, v537, v536, v28, v29);
                  // pto: %320
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v540 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v532 + (v531 + v528 * v28 + v530 * v29), v538, v539);
                  TLOAD(v526, v540);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  // pto: %seed_narrow_packet_w__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v541 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
                  // pto: %seed_narrow_packet_w__tile
                  ;
                  uint64_t v542 = (uint64_t) v23;
                  TASSIGN(v541, v542);
                  // pto: %321
                  ;
                  int64_t v543 = v140 < v45 ? v45 : v140;
                  // pto: %322
                  ;
                  int64_t v544 = v143 / v33;
                  // pto: %323
                  ;
                  int64_t v545 = v544 < v45 ? v45 : v544;
                  // pto: %324
                  ;
                  int64_t v546 = v525 / v33;
                  // pto: %325
                  ;
                  int64_t v547 = v546 < v45 ? v45 : v546;
                  // pto: %326
                  ;
                  __gm__ bfloat16_t* v548 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                  // pto: %326
                  ;
                  const int64_t v549 = 0;
                  // pto: %326
                  ;
                  const int64_t v550 = 4194304;
                  // pto: %326
                  ;
                  const int64_t v551 = 65536;
                  // pto: %326
                  ;
                  const int64_t v552 = 256;
                  // pto: %326
                  ;
                  pto::Shape<1, 8, 16, 16, 16> v553 = pto::Shape<1, 8, 16, 16, 16>();
                  // pto: %326
                  ;
                  pto::Stride<4194304, 65536, 256, 16, 1> v554 = pto::Stride<4194304, 65536, 256, 16, 1>();
                  // pto: %326
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v555 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v548 + ((v549 + v543 * v550) + v545 * v551 + v547 * v552), v553, v554);
                  TLOAD(v541, v555);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  // pto: %seed_narrow_acc__iter_v1_l0_a
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v556 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v515, v36);
                  // pto: %seed_narrow_acc__iter_v1_l0_a
                  ;
                  uint64_t v557 = (uint64_t) v23;
                  TASSIGN(v556, v557);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  uint16_t v558 = static_cast<uint16_t>(v45);
                  uint16_t v559 = static_cast<uint16_t>(v45);
                  TEXTRACT(v556, v526, v558, v559);
                  // pto: %seed_narrow_acc__iter_v1_l0_b
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v560 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %seed_narrow_acc__iter_v1_l0_b
                  ;
                  uint64_t v561 = (uint64_t) v23;
                  TASSIGN(v560, v561);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  uint16_t v562 = static_cast<uint16_t>(v45);
                  uint16_t v563 = static_cast<uint16_t>(v45);
                  TEXTRACT(v560, v541, v562, v563);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  // pto: %32
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v564 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v515, v36);
                  // pto: %32
                  ;
                  uint64_t v565 = (uint64_t) v25;
                  TASSIGN(v564, v565);
                  uint16_t v566 = static_cast<uint16_t>(v45);
                  uint16_t v567 = static_cast<uint16_t>(v36);
                  TEXTRACT(v564, v526, v566, v567);
                  // pto: %33
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v568 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %33
                  ;
                  uint64_t v569 = (uint64_t) v25;
                  TASSIGN(v568, v569);
                  uint16_t v570 = static_cast<uint16_t>(v36);
                  uint16_t v571 = static_cast<uint16_t>(v45);
                  TEXTRACT(v568, v541, v570, v571);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  // pto: %327
                  ;
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  if (v521 == v45) {
                    pipe_barrier(PIPE_M);
                    TMATMUL(v519, v556, v560);
                  } else {
                    pipe_barrier(PIPE_M);
                    TMATMUL_ACC(v519, v519, v556, v560);
                  };
                  pipe_barrier(PIPE_M);
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  TMATMUL_ACC(v519, v519, v564, v568);
                } else {
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  for (int64_t v572 = v45; v572 < v33; v572 += v29) {
                    // pto: %328, %329
                    ;
                    int64_t v573 = (int64_t) ((uint64_t) v524 + (uint64_t) v572) % v32;
                    // pto: %330, %331, %332
                    ;
                    int64_t v574 = v573 < v45 ? (int64_t) ((uint64_t) v573 + (uint64_t) v32) : v573;
                    // pto: %333
                    ;
                    int64_t v575 = (int64_t) ((uint64_t) v574 * (uint64_t) v33);
                    // pto: %seed_narrow_wrap_x__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v576 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v515, v33);
                    // pto: %seed_narrow_wrap_x__tile
                    ;
                    uint64_t v577 = (uint64_t) v24;
                    TASSIGN(v576, v577);
                    // pto: %334
                    ;
                    int64_t v578 = v513 < v45 ? v45 : v513;
                    // pto: %335, %336
                    ;
                    int64_t v579 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v41) + (uint64_t) v575);
                    // pto: %337
                    ;
                    int64_t v580 = v579 < v45 ? v45 : v579;
                    // pto: %338
                    ;
                    const int64_t v581 = 0;
                    // pto: %338
                    ;
                    __gm__ bfloat16_t* v582 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                    // pto: %338
                    ;
                    const int64_t v583 = 1;
                    // pto: %338
                    ;
                    const int64_t v584 = 1;
                    // pto: %338
                    ;
                    const int64_t v585 = 1;
                    // pto: %338
                    ;
                    int64_t v586 = v515 * v28;
                    // pto: %338
                    ;
                    int64_t v587 = v585 * v586;
                    // pto: %338
                    ;
                    pto::Shape<1, 1, 1, -1, 16> v588 = pto::Shape<1, 1, 1, -1, 16>(v583, v584, v585, v515, v33);
                    // pto: %338
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v589 = pto::Stride<-1, -1, -1, -1, -1>(v584 * v587, v587, v586, v28, v29);
                    // pto: %338
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v590 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v582 + (v581 + v578 * v28 + v580 * v29), v588, v589);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v576, v590);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    // pto: %seed_narrow_wrap_w__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v591 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %seed_narrow_wrap_w__tile
                    ;
                    uint64_t v592 = (uint64_t) v23;
                    TASSIGN(v591, v592);
                    // pto: %339
                    ;
                    int64_t v593 = v140 < v45 ? v45 : v140;
                    // pto: %340
                    ;
                    int64_t v594 = v143 / v33;
                    // pto: %341
                    ;
                    int64_t v595 = v594 < v45 ? v45 : v594;
                    // pto: %342
                    ;
                    int64_t v596 = v575 / v33;
                    // pto: %343
                    ;
                    int64_t v597 = v596 < v45 ? v45 : v596;
                    // pto: %344
                    ;
                    __gm__ bfloat16_t* v598 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                    // pto: %344
                    ;
                    const int64_t v599 = 0;
                    // pto: %344
                    ;
                    const int64_t v600 = 4194304;
                    // pto: %344
                    ;
                    const int64_t v601 = 65536;
                    // pto: %344
                    ;
                    const int64_t v602 = 256;
                    // pto: %344
                    ;
                    pto::Shape<1, 8, 1, 16, 16> v603 = pto::Shape<1, 8, 1, 16, 16>();
                    // pto: %344
                    ;
                    pto::Stride<4194304, 65536, 256, 16, 1> v604 = pto::Stride<4194304, 65536, 256, 16, 1>();
                    // pto: %344
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v605 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v598 + ((v599 + v593 * v600) + v595 * v601 + v597 * v602), v603, v604);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    TLOAD(v591, v605);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    // pto: %35
                    ;
                    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v606 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v515, v33);
                    // pto: %35
                    ;
                    uint64_t v607 = (uint64_t) v23;
                    TASSIGN(v606, v607);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                    uint16_t v608 = static_cast<uint16_t>(v45);
                    uint16_t v609 = static_cast<uint16_t>(v45);
                    TEXTRACT(v606, v576, v608, v609);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    // pto: %36
                    ;
                    Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v610 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %36
                    ;
                    uint64_t v611 = (uint64_t) v23;
                    TASSIGN(v610, v611);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    uint16_t v612 = static_cast<uint16_t>(v45);
                    uint16_t v613 = static_cast<uint16_t>(v45);
                    TEXTRACT(v610, v591, v612, v613);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    // pto: %346, %347
                    ;
                    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    if ((int64_t) ((uint64_t) v522 + (uint64_t) v572) == v45) {
                      pipe_barrier(PIPE_M);
                      TMATMUL(v519, v606, v610);
                    } else {
                      pipe_barrier(PIPE_M);
                      TMATMUL_ACC(v519, v519, v606, v610);
                    };
                    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  };
                  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
              // pto: %348
              ;
              int64_t v614 = v513 < v45 ? v45 : v513;
              // pto: %349, %350
              ;
              int64_t v615 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v55) + (uint64_t) v143);
              // pto: %351
              ;
              int64_t v616 = v615 < v45 ? v45 : v615;
              // pto: %352
              ;
              __gm__ float* v617 = PTOAS__GLOBAL_TENSOR_DATA(v94);
              // pto: %352
              ;
              const int64_t v618 = 0;
              // pto: %352
              ;
              const int64_t v619 = 8192;
              // pto: %352
              ;
              pto::Shape<1, 1, 1, 16, 128> v620 = pto::Shape<1, 1, 1, 16, 128>();
              // pto: %352
              ;
              pto::Stride<131072, 131072, 131072, 8192, 1> v621 = pto::Stride<131072, 131072, 131072, 8192, 1>();
              // pto: %352
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v622 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v617 + (v618 + v614 * v619 + v616), v620, v621);
              wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
              pipe_barrier(PIPE_FIX);
              TSTORE(v622, v519);
              set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
            };
          };
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    };
  } else {
    for (int64_t v623 = v126; v623 < v31; v623 += v48) {
      // pto: %354
      ;
      int64_t v624 = v623 / v30;
      // pto: %355
      ;
      int64_t v625 = v623 % v30;
      // pto: %356, %357, %358
      ;
      int64_t v626 = v625 < v45 ? (int64_t) ((uint64_t) v625 + (uint64_t) v30) : v625;
      // pto: %359
      ;
      int64_t v627 = (int64_t) ((uint64_t) v626 * (uint64_t) v36);
      // pto: %360, %361
      ;
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v628 = v45; v628 < ((int64_t) ((uint64_t) v138 + (uint64_t) v49) / v30); v628 += v29) {
        // pto: %362
        ;
        int64_t v629 = (int64_t) ((uint64_t) v628 * (uint64_t) v30);
        // pto: %365, %366, %367, %363
        ;
        int32_t v630 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v628 * (uint64_t) v31) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
        // pto: %368
        ;
        int64_t v631 = (int64_t) v630;
        // pto: %369
        ;
        int64_t v632 = v631 < v45 ? v45 : v631;
        // pto: %370
        ;
        int64_t v633 = (int64_t) ((uint64_t) v629 + (uint64_t) v29);
        // pto: %371
        ;
        // pto: %v4_same_start__phi_v3
        ;
        int64_t v634;
        if (v633 < v138) {
          // pto: %374, %375, %376, %377, %372
          ;
          int32_t v635 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v633 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %378
          ;
          int64_t v636 = (int64_t) v635;
          // pto: %379
          ;
          int64_t v637 = v636 < v45 ? v45 : v636;
          // pto: %380, %v4_same_start__phi_v2
          ;
          v634 = v637 != v632 ? v45 : v29;
        } else {
          v634 = v29;
        };
        // pto: %381
        ;
        int64_t v638 = (int64_t) ((uint64_t) v629 + (uint64_t) v50);
        // pto: %382
        ;
        // pto: %v4_same_start__phi_v6
        ;
        int64_t v639;
        if (v638 < v138) {
          // pto: %385, %386, %387, %388, %383
          ;
          int32_t v640 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v638 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %389
          ;
          int64_t v641 = (int64_t) v640;
          // pto: %390
          ;
          int64_t v642 = v641 < v45 ? v45 : v641;
          // pto: %391, %v4_same_start__phi_v5
          ;
          int64_t v643 = v642 != v632 ? v45 : v634;
          v639 = v643;
        } else {
          v639 = v634;
        };
        // pto: %392
        ;
        int64_t v644 = (int64_t) ((uint64_t) v629 + (uint64_t) v51);
        // pto: %393
        ;
        // pto: %v4_same_start__phi_v9
        ;
        int64_t v645;
        if (v644 < v138) {
          // pto: %396, %397, %398, %399, %394
          ;
          int32_t v646 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v644 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %400
          ;
          int64_t v647 = (int64_t) v646;
          // pto: %401
          ;
          int64_t v648 = v647 < v45 ? v45 : v647;
          // pto: %402, %v4_same_start__phi_v8
          ;
          int64_t v649 = v648 != v632 ? v45 : v639;
          v645 = v649;
        } else {
          v645 = v639;
        };
        // pto: %403
        ;
        int64_t v650 = (int64_t) ((uint64_t) v629 + (uint64_t) v43);
        // pto: %404
        ;
        // pto: %v4_same_start__phi_v12
        ;
        int64_t v651;
        if (v650 < v138) {
          // pto: %407, %408, %409, %410, %405
          ;
          int32_t v652 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v650 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %411
          ;
          int64_t v653 = (int64_t) v652;
          // pto: %412
          ;
          int64_t v654 = v653 < v45 ? v45 : v653;
          // pto: %413, %v4_same_start__phi_v11
          ;
          int64_t v655 = v654 != v632 ? v45 : v645;
          v651 = v655;
        } else {
          v651 = v645;
        };
        // pto: %414
        ;
        int64_t v656 = (int64_t) ((uint64_t) v629 + (uint64_t) v52);
        // pto: %415
        ;
        // pto: %v4_same_start__phi_v15
        ;
        int64_t v657;
        if (v656 < v138) {
          // pto: %418, %419, %420, %421, %416
          ;
          int32_t v658 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v656 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %422
          ;
          int64_t v659 = (int64_t) v658;
          // pto: %423
          ;
          int64_t v660 = v659 < v45 ? v45 : v659;
          // pto: %424, %v4_same_start__phi_v14
          ;
          int64_t v661 = v660 != v632 ? v45 : v651;
          v657 = v661;
        } else {
          v657 = v651;
        };
        // pto: %425
        ;
        int64_t v662 = (int64_t) ((uint64_t) v629 + (uint64_t) v53);
        // pto: %426
        ;
        // pto: %v4_same_start__phi_v18
        ;
        int64_t v663;
        if (v662 < v138) {
          // pto: %429, %430, %431, %432, %427
          ;
          int32_t v664 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v662 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %433
          ;
          int64_t v665 = (int64_t) v664;
          // pto: %434
          ;
          int64_t v666 = v665 < v45 ? v45 : v665;
          // pto: %435, %v4_same_start__phi_v17
          ;
          int64_t v667 = v666 != v632 ? v45 : v657;
          v663 = v667;
        } else {
          v663 = v657;
        };
        // pto: %436
        ;
        int64_t v668 = (int64_t) ((uint64_t) v629 + (uint64_t) v49);
        // pto: %437
        ;
        // pto: %v4_same_start__phi_v21
        ;
        int64_t v669;
        if (v668 < v138) {
          // pto: %440, %441, %442, %443, %438
          ;
          int32_t v670 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v668 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %444
          ;
          int64_t v671 = (int64_t) v670;
          // pto: %445
          ;
          int64_t v672 = v671 < v45 ? v45 : v671;
          // pto: %446, %v4_same_start__phi_v20
          ;
          int64_t v673 = v672 != v632 ? v45 : v663;
          v669 = v673;
        } else {
          v669 = v663;
        };
        // pto: %447, %v4_same_start__phi_v23
        ;
        int64_t v674 = v17 <= v33 ? v45 : v669;
        // pto: %448
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        if (v674 == v29) {
          int64_t v675 = (int64_t) ((uint64_t) v628 * (uint64_t) v36);
          // pto: %450
          ;
          int64_t v676 = (int64_t) ((uint64_t) v17 - (uint64_t) v675);
          // pto: %451
          ;
          int64_t v677 = v676 < v36 ? v676 : v36;
          // pto: %452
          ;
          int64_t v678 = v632 % v32;
          // pto: %453, %454, %455
          ;
          int64_t v679 = v678 < v45 ? (int64_t) ((uint64_t) v678 + (uint64_t) v32) : v678;
          // pto: %456
          ;
          int64_t v680 = (int64_t) ((uint64_t) v679 * (uint64_t) v33);
          // pto: %v4_wide_seed_x__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v681 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v677, v33);
          // pto: %v4_wide_seed_x__tile
          ;
          uint64_t v682 = (uint64_t) v23;
          TASSIGN(v681, v682);
          // pto: %457
          ;
          int64_t v683 = v675 < v45 ? v45 : v675;
          // pto: %458
          ;
          int64_t v684 = (int64_t) ((uint64_t) v624 * (uint64_t) v41);
          // pto: %459
          ;
          int64_t v685 = (int64_t) ((uint64_t) v684 + (uint64_t) v680);
          // pto: %460
          ;
          int64_t v686 = v685 < v45 ? v45 : v685;
          // pto: %461
          ;
          const int64_t v687 = 0;
          // pto: %461
          ;
          __gm__ bfloat16_t* v688 = PTOAS__GLOBAL_TENSOR_DATA(v70);
          // pto: %461
          ;
          const int64_t v689 = 1;
          // pto: %461
          ;
          const int64_t v690 = 1;
          // pto: %461
          ;
          const int64_t v691 = 1;
          // pto: %461
          ;
          int64_t v692 = v677 * v28;
          // pto: %461
          ;
          int64_t v693 = v691 * v692;
          // pto: %461
          ;
          pto::Shape<1, 1, 1, -1, 16> v694 = pto::Shape<1, 1, 1, -1, 16>(v689, v690, v691, v677, v33);
          // pto: %461
          ;
          pto::Stride<-1, -1, -1, -1, -1> v695 = pto::Stride<-1, -1, -1, -1, -1>(v690 * v693, v693, v692, v28, v29);
          // pto: %461
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v696 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v688 + (v687 + v683 * v28 + v686 * v29), v694, v695);
          TLOAD(v681, v696);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %v4_wide_seed_w__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v697 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
          // pto: %v4_wide_seed_w__tile
          ;
          uint64_t v698 = (uint64_t) v24;
          TASSIGN(v697, v698);
          // pto: %462
          ;
          int64_t v699 = v624 < v45 ? v45 : v624;
          // pto: %463
          ;
          int64_t v700 = v627 / v33;
          // pto: %464
          ;
          int64_t v701 = v700 < v45 ? v45 : v700;
          // pto: %465
          ;
          int64_t v702 = v680 / v33;
          // pto: %466
          ;
          int64_t v703 = v702 < v45 ? v45 : v702;
          // pto: %467
          ;
          __gm__ bfloat16_t* v704 = PTOAS__GLOBAL_TENSOR_DATA(v73);
          // pto: %467
          ;
          const int64_t v705 = 0;
          // pto: %467
          ;
          const int64_t v706 = 4194304;
          // pto: %467
          ;
          const int64_t v707 = 65536;
          // pto: %467
          ;
          const int64_t v708 = 256;
          // pto: %467
          ;
          pto::Shape<1, 8, 1, 16, 16> v709 = pto::Shape<1, 8, 1, 16, 16>();
          // pto: %467
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v710 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %467
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v711 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v704 + ((v705 + v699 * v706) + v701 * v707 + v703 * v708), v709, v710);
          TLOAD(v697, v711);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %37
          ;
          Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v712 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v677, v33);
          // pto: %37
          ;
          uint64_t v713 = (uint64_t) v23;
          TASSIGN(v712, v713);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          uint16_t v714 = static_cast<uint16_t>(v45);
          uint16_t v715 = static_cast<uint16_t>(v45);
          TEXTRACT(v712, v681, v714, v715);
          // pto: %38
          ;
          Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v716 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
          // pto: %38
          ;
          uint64_t v717 = (uint64_t) v23;
          TASSIGN(v716, v717);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v718 = static_cast<uint16_t>(v45);
          uint16_t v719 = static_cast<uint16_t>(v45);
          TEXTRACT(v716, v697, v718, v719);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %v4_wide_acc__tile
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v720 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v677, v36);
          // pto: %v4_wide_acc__tile
          ;
          uint64_t v721 = (uint64_t) v23;
          TASSIGN(v720, v721);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          TMATMUL(v720, v712, v716);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          for (int64_t v722 = v45; v722 < v46; v722 += v29) {
            // pto: %469, %468, %470, %471
            ;
            int64_t v723 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v632 + (uint64_t) ((int64_t) (uint64_t) v722 * (uint64_t) v33)) + (uint64_t) v29) % v32;
            // pto: %472, %473, %474
            ;
            int64_t v724 = v723 < v45 ? (int64_t) ((uint64_t) v723 + (uint64_t) v32) : v723;
            // pto: %475
            ;
            // pto: %476
            ;
            int64_t v725 = v677 < v36 ? v677 : v36;
            v122.SetValidShape(v725, v36);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            if (v724 <= v54) {
              // pto: %477
              ;
              int64_t v726 = (int64_t) ((uint64_t) v724 * (uint64_t) v33);
              // pto: %v4_wide_packet_x__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v727 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v677, v32);
              // pto: %v4_wide_packet_x__tile
              ;
              uint64_t v728 = (uint64_t) v23;
              TASSIGN(v727, v728);
              // pto: %480
              ;
              int64_t v729 = (int64_t) ((uint64_t) v684 + (uint64_t) v726);
              // pto: %481
              ;
              int64_t v730 = v729 < v45 ? v45 : v729;
              // pto: %482
              ;
              const int64_t v731 = 0;
              // pto: %482
              ;
              __gm__ bfloat16_t* v732 = PTOAS__GLOBAL_TENSOR_DATA(v70);
              // pto: %482
              ;
              const int64_t v733 = 1;
              // pto: %482
              ;
              const int64_t v734 = 1;
              // pto: %482
              ;
              const int64_t v735 = 1;
              // pto: %482
              ;
              int64_t v736 = v677 * v28;
              // pto: %482
              ;
              int64_t v737 = v735 * v736;
              // pto: %482
              ;
              pto::Shape<1, 1, 1, -1, 256> v738 = pto::Shape<1, 1, 1, -1, 256>(v733, v734, v735, v677, v32);
              // pto: %482
              ;
              pto::Stride<-1, -1, -1, -1, -1> v739 = pto::Stride<-1, -1, -1, -1, -1>(v734 * v737, v737, v736, v28, v29);
              // pto: %482
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v740 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v732 + (v731 + v683 * v28 + v730 * v29), v738, v739);
              TLOAD(v727, v740);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %v4_wide_packet_w__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v741 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
              // pto: %v4_wide_packet_w__tile
              ;
              uint64_t v742 = (uint64_t) v24;
              TASSIGN(v741, v742);
              // pto: %486
              ;
              int64_t v743 = v726 / v33;
              // pto: %487
              ;
              int64_t v744 = v743 < v45 ? v45 : v743;
              // pto: %488
              ;
              __gm__ bfloat16_t* v745 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %488
              ;
              const int64_t v746 = 0;
              // pto: %488
              ;
              const int64_t v747 = 4194304;
              // pto: %488
              ;
              const int64_t v748 = 65536;
              // pto: %488
              ;
              const int64_t v749 = 256;
              // pto: %488
              ;
              pto::Shape<1, 8, 16, 16, 16> v750 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %488
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v751 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %488
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v752 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v745 + ((v746 + v699 * v747) + v701 * v748 + v744 * v749), v750, v751);
              TLOAD(v741, v752);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %v4_wide_acc__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v753 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v677, v36);
              // pto: %v4_wide_acc__iter_v1_l0_a
              ;
              uint64_t v754 = (uint64_t) v23;
              TASSIGN(v753, v754);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              uint16_t v755 = static_cast<uint16_t>(v45);
              uint16_t v756 = static_cast<uint16_t>(v45);
              TEXTRACT(v753, v727, v755, v756);
              // pto: %v4_wide_acc__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v757 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %v4_wide_acc__iter_v1_l0_b
              ;
              uint64_t v758 = (uint64_t) v23;
              TASSIGN(v757, v758);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v759 = static_cast<uint16_t>(v45);
              uint16_t v760 = static_cast<uint16_t>(v45);
              TEXTRACT(v757, v741, v759, v760);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              // pto: %39
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v761 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v677, v36);
              // pto: %39
              ;
              uint64_t v762 = (uint64_t) v25;
              TASSIGN(v761, v762);
              uint16_t v763 = static_cast<uint16_t>(v45);
              uint16_t v764 = static_cast<uint16_t>(v36);
              TEXTRACT(v761, v727, v763, v764);
              // pto: %40
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v765 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %40
              ;
              uint64_t v766 = (uint64_t) v25;
              TASSIGN(v765, v766);
              uint16_t v767 = static_cast<uint16_t>(v36);
              uint16_t v768 = static_cast<uint16_t>(v45);
              TEXTRACT(v765, v741, v767, v768);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v720, v720, v753, v757);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              TMATMUL_ACC(v720, v720, v761, v765);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              for (int64_t v769 = v45; v769 < v33; v769 += v29) {
                // pto: %489, %490
                ;
                int64_t v770 = (int64_t) ((uint64_t) v724 + (uint64_t) v769) % v32;
                // pto: %491, %492, %493
                ;
                int64_t v771 = v770 < v45 ? (int64_t) ((uint64_t) v770 + (uint64_t) v32) : v770;
                // pto: %494
                ;
                int64_t v772 = (int64_t) ((uint64_t) v771 * (uint64_t) v33);
                // pto: %v4_wide_wrap_x__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v773 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v677, v33);
                // pto: %v4_wide_wrap_x__tile
                ;
                uint64_t v774 = (uint64_t) v23;
                TASSIGN(v773, v774);
                // pto: %497
                ;
                int64_t v775 = (int64_t) ((uint64_t) v684 + (uint64_t) v772);
                // pto: %498
                ;
                int64_t v776 = v775 < v45 ? v45 : v775;
                // pto: %499
                ;
                const int64_t v777 = 0;
                // pto: %499
                ;
                __gm__ bfloat16_t* v778 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                // pto: %499
                ;
                const int64_t v779 = 1;
                // pto: %499
                ;
                const int64_t v780 = 1;
                // pto: %499
                ;
                const int64_t v781 = 1;
                // pto: %499
                ;
                int64_t v782 = v677 * v28;
                // pto: %499
                ;
                int64_t v783 = v781 * v782;
                // pto: %499
                ;
                pto::Shape<1, 1, 1, -1, 16> v784 = pto::Shape<1, 1, 1, -1, 16>(v779, v780, v781, v677, v33);
                // pto: %499
                ;
                pto::Stride<-1, -1, -1, -1, -1> v785 = pto::Stride<-1, -1, -1, -1, -1>(v780 * v783, v783, v782, v28, v29);
                // pto: %499
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v786 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v778 + (v777 + v683 * v28 + v776 * v29), v784, v785);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                TLOAD(v773, v786);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %v4_wide_wrap_w__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v787 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %v4_wide_wrap_w__tile
                ;
                uint64_t v788 = (uint64_t) v24;
                TASSIGN(v787, v788);
                // pto: %503
                ;
                int64_t v789 = v772 / v33;
                // pto: %504
                ;
                int64_t v790 = v789 < v45 ? v45 : v789;
                // pto: %505
                ;
                __gm__ bfloat16_t* v791 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                // pto: %505
                ;
                const int64_t v792 = 0;
                // pto: %505
                ;
                const int64_t v793 = 4194304;
                // pto: %505
                ;
                const int64_t v794 = 65536;
                // pto: %505
                ;
                const int64_t v795 = 256;
                // pto: %505
                ;
                pto::Shape<1, 8, 1, 16, 16> v796 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %505
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v797 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %505
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v798 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v791 + ((v792 + v699 * v793) + v701 * v794 + v790 * v795), v796, v797);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v787, v798);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %42
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v799 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v677, v33);
                // pto: %42
                ;
                uint64_t v800 = (uint64_t) v23;
                TASSIGN(v799, v800);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                uint16_t v801 = static_cast<uint16_t>(v45);
                uint16_t v802 = static_cast<uint16_t>(v45);
                TEXTRACT(v799, v773, v801, v802);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                // pto: %43
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v803 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %43
                ;
                uint64_t v804 = (uint64_t) v23;
                TASSIGN(v803, v804);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v805 = static_cast<uint16_t>(v45);
                uint16_t v806 = static_cast<uint16_t>(v45);
                TEXTRACT(v803, v787, v805, v806);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v720, v720, v799, v803);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          for (int64_t v807 = v56; v807 < v32; v807 += v29) {
            // pto: %506, %507
            ;
            int64_t v808 = (int64_t) ((uint64_t) v632 + (uint64_t) v807) % v32;
            // pto: %508, %509, %510
            ;
            int64_t v809 = v808 < v45 ? (int64_t) ((uint64_t) v808 + (uint64_t) v32) : v808;
            // pto: %511
            ;
            int64_t v810 = (int64_t) ((uint64_t) v809 * (uint64_t) v33);
            // pto: %v4_wide_tail_x__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v811 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v677, v33);
            // pto: %v4_wide_tail_x__tile
            ;
            uint64_t v812 = (uint64_t) v23;
            TASSIGN(v811, v812);
            // pto: %514
            ;
            int64_t v813 = (int64_t) ((uint64_t) v684 + (uint64_t) v810);
            // pto: %515
            ;
            int64_t v814 = v813 < v45 ? v45 : v813;
            // pto: %516
            ;
            const int64_t v815 = 0;
            // pto: %516
            ;
            __gm__ bfloat16_t* v816 = PTOAS__GLOBAL_TENSOR_DATA(v70);
            // pto: %516
            ;
            const int64_t v817 = 1;
            // pto: %516
            ;
            const int64_t v818 = 1;
            // pto: %516
            ;
            const int64_t v819 = 1;
            // pto: %516
            ;
            int64_t v820 = v677 * v28;
            // pto: %516
            ;
            int64_t v821 = v819 * v820;
            // pto: %516
            ;
            pto::Shape<1, 1, 1, -1, 16> v822 = pto::Shape<1, 1, 1, -1, 16>(v817, v818, v819, v677, v33);
            // pto: %516
            ;
            pto::Stride<-1, -1, -1, -1, -1> v823 = pto::Stride<-1, -1, -1, -1, -1>(v818 * v821, v821, v820, v28, v29);
            // pto: %516
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v824 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v816 + (v815 + v683 * v28 + v814 * v29), v822, v823);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            TLOAD(v811, v824);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %v4_wide_tail_w__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v825 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
            // pto: %v4_wide_tail_w__tile
            ;
            uint64_t v826 = (uint64_t) v24;
            TASSIGN(v825, v826);
            // pto: %520
            ;
            int64_t v827 = v810 / v33;
            // pto: %521
            ;
            int64_t v828 = v827 < v45 ? v45 : v827;
            // pto: %522
            ;
            __gm__ bfloat16_t* v829 = PTOAS__GLOBAL_TENSOR_DATA(v73);
            // pto: %522
            ;
            const int64_t v830 = 0;
            // pto: %522
            ;
            const int64_t v831 = 4194304;
            // pto: %522
            ;
            const int64_t v832 = 65536;
            // pto: %522
            ;
            const int64_t v833 = 256;
            // pto: %522
            ;
            pto::Shape<1, 8, 1, 16, 16> v834 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %522
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v835 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %522
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v836 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v829 + ((v830 + v699 * v831) + v701 * v832 + v828 * v833), v834, v835);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            TLOAD(v825, v836);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %44
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v837 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v677, v33);
            // pto: %44
            ;
            uint64_t v838 = (uint64_t) v23;
            TASSIGN(v837, v838);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            uint16_t v839 = static_cast<uint16_t>(v45);
            uint16_t v840 = static_cast<uint16_t>(v45);
            TEXTRACT(v837, v811, v839, v840);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            // pto: %45
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v841 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
            // pto: %45
            ;
            uint64_t v842 = (uint64_t) v23;
            TASSIGN(v841, v842);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v843 = static_cast<uint16_t>(v45);
            uint16_t v844 = static_cast<uint16_t>(v45);
            TEXTRACT(v841, v825, v843, v844);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v720, v720, v837, v841);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
          // pto: %524, %525
          ;
          int64_t v845 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v624 * (uint64_t) v55) + (uint64_t) v627);
          // pto: %526
          ;
          int64_t v846 = v845 < v45 ? v45 : v845;
          // pto: %527
          ;
          const int64_t v847 = 0;
          // pto: %527
          ;
          __gm__ float* v848 = PTOAS__GLOBAL_TENSOR_DATA(v94);
          // pto: %527
          ;
          const int64_t v849 = 1;
          // pto: %527
          ;
          const int64_t v850 = 1;
          // pto: %527
          ;
          const int64_t v851 = 1;
          // pto: %527
          ;
          int64_t v852 = v677 * v42;
          // pto: %527
          ;
          int64_t v853 = v851 * v852;
          // pto: %527
          ;
          pto::Shape<1, 1, 1, -1, 128> v854 = pto::Shape<1, 1, 1, -1, 128>(v849, v850, v851, v677, v36);
          // pto: %527
          ;
          pto::Stride<-1, -1, -1, -1, -1> v855 = pto::Stride<-1, -1, -1, -1, -1>(v850 * v853, v853, v852, v42, v29);
          // pto: %527
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v856 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v848 + (v847 + v683 * v42 + v846 * v29), v854, v855);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
          TSTORE(v856, v720);
        } else {
          for (int64_t v857 = v45; v857 < v30; v857 += v29) {
            // pto: %528
            ;
            int64_t v858 = (int64_t) ((uint64_t) v629 + (uint64_t) v857);
            // pto: %529
            ;
            if (v858 < v138) {
              // pto: %530
              ;
              int64_t v859 = (int64_t) ((uint64_t) v858 * (uint64_t) v33);
              // pto: %531
              ;
              int64_t v860 = (int64_t) ((uint64_t) v17 - (uint64_t) v859);
              // pto: %532
              ;
              int64_t v861 = v860 < v33 ? v860 : v33;
              // pto: %534, %535, %536, %537, %533
              ;
              int32_t v862 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v858 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
              // pto: %538
              ;
              int64_t v863 = (int64_t) v862;
              // pto: %539
              ;
              int64_t v864 = v863 < v45 ? v45 : v863;
              // pto: %v4_narrow_acc__tile
              ;
              Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v865 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %v4_narrow_acc__tile
              ;
              uint64_t v866 = (uint64_t) v23;
              TASSIGN(v865, v866);
              wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              for (int64_t v867 = v45; v867 < v33; v867 += v29) {
                // pto: %540
                ;
                int64_t v868 = (int64_t) ((uint64_t) v867 * (uint64_t) v33);
                // pto: %541, %542
                ;
                int64_t v869 = (int64_t) ((uint64_t) v864 + (uint64_t) v868) % v32;
                // pto: %543, %544, %545
                ;
                int64_t v870 = v869 < v45 ? (int64_t) ((uint64_t) v869 + (uint64_t) v32) : v869;
                // pto: %546
                ;
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                if (v870 <= v54) {
                  // pto: %547
                  ;
                  int64_t v871 = (int64_t) ((uint64_t) v870 * (uint64_t) v33);
                  // pto: %v4_narrow_packet_x__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v872 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v861, v32);
                  // pto: %v4_narrow_packet_x__tile
                  ;
                  uint64_t v873 = (uint64_t) v24;
                  TASSIGN(v872, v873);
                  // pto: %548
                  ;
                  int64_t v874 = v859 < v45 ? v45 : v859;
                  // pto: %549, %550
                  ;
                  int64_t v875 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v624 * (uint64_t) v41) + (uint64_t) v871);
                  // pto: %551
                  ;
                  int64_t v876 = v875 < v45 ? v45 : v875;
                  // pto: %552
                  ;
                  const int64_t v877 = 0;
                  // pto: %552
                  ;
                  __gm__ bfloat16_t* v878 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                  // pto: %552
                  ;
                  const int64_t v879 = 1;
                  // pto: %552
                  ;
                  const int64_t v880 = 1;
                  // pto: %552
                  ;
                  const int64_t v881 = 1;
                  // pto: %552
                  ;
                  int64_t v882 = v861 * v28;
                  // pto: %552
                  ;
                  int64_t v883 = v881 * v882;
                  // pto: %552
                  ;
                  pto::Shape<1, 1, 1, -1, 256> v884 = pto::Shape<1, 1, 1, -1, 256>(v879, v880, v881, v861, v32);
                  // pto: %552
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v885 = pto::Stride<-1, -1, -1, -1, -1>(v880 * v883, v883, v882, v28, v29);
                  // pto: %552
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v886 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v878 + (v877 + v874 * v28 + v876 * v29), v884, v885);
                  TLOAD(v872, v886);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  // pto: %v4_narrow_packet_w__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v887 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
                  // pto: %v4_narrow_packet_w__tile
                  ;
                  uint64_t v888 = (uint64_t) v23;
                  TASSIGN(v887, v888);
                  // pto: %553
                  ;
                  int64_t v889 = v624 < v45 ? v45 : v624;
                  // pto: %554
                  ;
                  int64_t v890 = v627 / v33;
                  // pto: %555
                  ;
                  int64_t v891 = v890 < v45 ? v45 : v890;
                  // pto: %556
                  ;
                  int64_t v892 = v871 / v33;
                  // pto: %557
                  ;
                  int64_t v893 = v892 < v45 ? v45 : v892;
                  // pto: %558
                  ;
                  __gm__ bfloat16_t* v894 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                  // pto: %558
                  ;
                  const int64_t v895 = 0;
                  // pto: %558
                  ;
                  const int64_t v896 = 4194304;
                  // pto: %558
                  ;
                  const int64_t v897 = 65536;
                  // pto: %558
                  ;
                  const int64_t v898 = 256;
                  // pto: %558
                  ;
                  pto::Shape<1, 8, 16, 16, 16> v899 = pto::Shape<1, 8, 16, 16, 16>();
                  // pto: %558
                  ;
                  pto::Stride<4194304, 65536, 256, 16, 1> v900 = pto::Stride<4194304, 65536, 256, 16, 1>();
                  // pto: %558
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v901 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v894 + ((v895 + v889 * v896) + v891 * v897 + v893 * v898), v899, v900);
                  TLOAD(v887, v901);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  // pto: %v4_narrow_acc__iter_v1_l0_a
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v902 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v861, v36);
                  // pto: %v4_narrow_acc__iter_v1_l0_a
                  ;
                  uint64_t v903 = (uint64_t) v23;
                  TASSIGN(v902, v903);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  uint16_t v904 = static_cast<uint16_t>(v45);
                  uint16_t v905 = static_cast<uint16_t>(v45);
                  TEXTRACT(v902, v872, v904, v905);
                  // pto: %v4_narrow_acc__iter_v1_l0_b
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v906 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %v4_narrow_acc__iter_v1_l0_b
                  ;
                  uint64_t v907 = (uint64_t) v23;
                  TASSIGN(v906, v907);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  uint16_t v908 = static_cast<uint16_t>(v45);
                  uint16_t v909 = static_cast<uint16_t>(v45);
                  TEXTRACT(v906, v887, v908, v909);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  // pto: %46
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v910 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v861, v36);
                  // pto: %46
                  ;
                  uint64_t v911 = (uint64_t) v25;
                  TASSIGN(v910, v911);
                  uint16_t v912 = static_cast<uint16_t>(v45);
                  uint16_t v913 = static_cast<uint16_t>(v36);
                  TEXTRACT(v910, v872, v912, v913);
                  // pto: %47
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v914 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %47
                  ;
                  uint64_t v915 = (uint64_t) v25;
                  TASSIGN(v914, v915);
                  uint16_t v916 = static_cast<uint16_t>(v36);
                  uint16_t v917 = static_cast<uint16_t>(v45);
                  TEXTRACT(v914, v887, v916, v917);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  // pto: %559
                  ;
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  if (v867 == v45) {
                    pipe_barrier(PIPE_M);
                    TMATMUL(v865, v902, v906);
                  } else {
                    pipe_barrier(PIPE_M);
                    TMATMUL_ACC(v865, v865, v902, v906);
                  };
                  pipe_barrier(PIPE_M);
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  TMATMUL_ACC(v865, v865, v910, v914);
                } else {
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  for (int64_t v918 = v45; v918 < v33; v918 += v29) {
                    // pto: %560, %561
                    ;
                    int64_t v919 = (int64_t) ((uint64_t) v870 + (uint64_t) v918) % v32;
                    // pto: %562, %563, %564
                    ;
                    int64_t v920 = v919 < v45 ? (int64_t) ((uint64_t) v919 + (uint64_t) v32) : v919;
                    // pto: %565
                    ;
                    int64_t v921 = (int64_t) ((uint64_t) v920 * (uint64_t) v33);
                    // pto: %v4_narrow_wrap_x__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v922 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v861, v33);
                    // pto: %v4_narrow_wrap_x__tile
                    ;
                    uint64_t v923 = (uint64_t) v24;
                    TASSIGN(v922, v923);
                    // pto: %566
                    ;
                    int64_t v924 = v859 < v45 ? v45 : v859;
                    // pto: %567, %568
                    ;
                    int64_t v925 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v624 * (uint64_t) v41) + (uint64_t) v921);
                    // pto: %569
                    ;
                    int64_t v926 = v925 < v45 ? v45 : v925;
                    // pto: %570
                    ;
                    const int64_t v927 = 0;
                    // pto: %570
                    ;
                    __gm__ bfloat16_t* v928 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                    // pto: %570
                    ;
                    const int64_t v929 = 1;
                    // pto: %570
                    ;
                    const int64_t v930 = 1;
                    // pto: %570
                    ;
                    const int64_t v931 = 1;
                    // pto: %570
                    ;
                    int64_t v932 = v861 * v28;
                    // pto: %570
                    ;
                    int64_t v933 = v931 * v932;
                    // pto: %570
                    ;
                    pto::Shape<1, 1, 1, -1, 16> v934 = pto::Shape<1, 1, 1, -1, 16>(v929, v930, v931, v861, v33);
                    // pto: %570
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v935 = pto::Stride<-1, -1, -1, -1, -1>(v930 * v933, v933, v932, v28, v29);
                    // pto: %570
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v936 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v928 + (v927 + v924 * v28 + v926 * v29), v934, v935);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v922, v936);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    // pto: %v4_narrow_wrap_w__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v937 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %v4_narrow_wrap_w__tile
                    ;
                    uint64_t v938 = (uint64_t) v23;
                    TASSIGN(v937, v938);
                    // pto: %571
                    ;
                    int64_t v939 = v624 < v45 ? v45 : v624;
                    // pto: %572
                    ;
                    int64_t v940 = v627 / v33;
                    // pto: %573
                    ;
                    int64_t v941 = v940 < v45 ? v45 : v940;
                    // pto: %574
                    ;
                    int64_t v942 = v921 / v33;
                    // pto: %575
                    ;
                    int64_t v943 = v942 < v45 ? v45 : v942;
                    // pto: %576
                    ;
                    __gm__ bfloat16_t* v944 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                    // pto: %576
                    ;
                    const int64_t v945 = 0;
                    // pto: %576
                    ;
                    const int64_t v946 = 4194304;
                    // pto: %576
                    ;
                    const int64_t v947 = 65536;
                    // pto: %576
                    ;
                    const int64_t v948 = 256;
                    // pto: %576
                    ;
                    pto::Shape<1, 8, 1, 16, 16> v949 = pto::Shape<1, 8, 1, 16, 16>();
                    // pto: %576
                    ;
                    pto::Stride<4194304, 65536, 256, 16, 1> v950 = pto::Stride<4194304, 65536, 256, 16, 1>();
                    // pto: %576
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v951 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v944 + ((v945 + v939 * v946) + v941 * v947 + v943 * v948), v949, v950);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    TLOAD(v937, v951);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    // pto: %49
                    ;
                    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v952 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v861, v33);
                    // pto: %49
                    ;
                    uint64_t v953 = (uint64_t) v23;
                    TASSIGN(v952, v953);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                    uint16_t v954 = static_cast<uint16_t>(v45);
                    uint16_t v955 = static_cast<uint16_t>(v45);
                    TEXTRACT(v952, v922, v954, v955);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    // pto: %50
                    ;
                    Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v956 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %50
                    ;
                    uint64_t v957 = (uint64_t) v23;
                    TASSIGN(v956, v957);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    uint16_t v958 = static_cast<uint16_t>(v45);
                    uint16_t v959 = static_cast<uint16_t>(v45);
                    TEXTRACT(v956, v937, v958, v959);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    // pto: %578, %579
                    ;
                    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    if ((int64_t) ((uint64_t) v868 + (uint64_t) v918) == v45) {
                      pipe_barrier(PIPE_M);
                      TMATMUL(v865, v952, v956);
                    } else {
                      pipe_barrier(PIPE_M);
                      TMATMUL_ACC(v865, v865, v952, v956);
                    };
                    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  };
                  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
              // pto: %580
              ;
              int64_t v960 = v859 < v45 ? v45 : v859;
              // pto: %581, %582
              ;
              int64_t v961 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v624 * (uint64_t) v55) + (uint64_t) v627);
              // pto: %583
              ;
              int64_t v962 = v961 < v45 ? v45 : v961;
              // pto: %584
              ;
              __gm__ float* v963 = PTOAS__GLOBAL_TENSOR_DATA(v94);
              // pto: %584
              ;
              const int64_t v964 = 0;
              // pto: %584
              ;
              const int64_t v965 = 8192;
              // pto: %584
              ;
              pto::Shape<1, 1, 1, 16, 128> v966 = pto::Shape<1, 1, 1, 16, 128>();
              // pto: %584
              ;
              pto::Stride<131072, 131072, 131072, 8192, 1> v967 = pto::Stride<131072, 131072, 131072, 8192, 1>();
              // pto: %584
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v968 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v963 + (v964 + v960 * v965 + v962), v966, v967);
              wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
              pipe_barrier(PIPE_FIX);
              TSTORE(v968, v865);
              set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
            };
          };
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    };
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %586
  int64_t v969 = (int64_t) ((uint64_t) v127 + (uint64_t) v57);
  // pto: %587
  int64_t v970 = v969 < v45 ? v45 : v969;
  // pto: %signals__ssa_v1_signal_pview
  __gm__ int32_t* v971 = PTOAS__GLOBAL_TENSOR_DATA(v113);
  // pto: %signals__ssa_v1_signal_pview
  const int64_t v972 = 0;
  // pto: %signals__ssa_v1_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v973 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v974 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v975 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v971 + (v972 + v970), v973, v974);
  pto::comm::NotifyOp v976 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v975, v136, v976);
  for (int64_t v977 = v48; v977 < v58; v977 += v29) {
    // pto: %588, %589
    ;
    int64_t v978 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v977 * (uint64_t) v36) + (uint64_t) v59);
    // pto: %590
    ;
    int64_t v979 = v978 < v45 ? v45 : v978;
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v980 = PTOAS__GLOBAL_TENSOR_DATA(v113);
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    const int64_t v981 = 0;
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v982 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v983 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v984 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v980 + (v981 + v979), v982, v983);
    pto::comm::WaitCmp v985 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v984, v136, v985);
  }
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %591
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  if (v17 <= v33) {
    // pto: %592
    ;
    for (int64_t v986 = v126; v986 < ((int64_t) ((uint64_t) v138 * (uint64_t) v38)); v986 += v48) {
      // pto: %593, %594
      ;
      int64_t v987 = (int64_t) ((uint64_t) (v986 / v38) * (uint64_t) v33);
      // pto: %595
      ;
      int64_t v988 = v986 % v38;
      // pto: %596, %597, %598
      ;
      int64_t v989 = v988 < v45 ? (int64_t) ((uint64_t) v988 + (uint64_t) v38) : v988;
      // pto: %599
      ;
      int64_t v990 = (int64_t) ((uint64_t) v989 * (uint64_t) v36);
      // pto: %600
      ;
      int64_t v991 = (int64_t) ((uint64_t) v17 - (uint64_t) v987);
      // pto: %601
      ;
      int64_t v992 = v991 < v33 ? v991 : v33;
      // pto: %b_acc__tile
      ;
      Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v993 = Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
      // pto: %b_acc__tile
      ;
      uint64_t v994 = (uint64_t) v23;
      TASSIGN(v993, v994);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      for (int64_t v995 = v45; v995 < v33; v995 += v29) {
        // pto: %602
        ;
        int64_t v996 = (int64_t) ((uint64_t) v995 * (uint64_t) v37);
        // pto: %b_input__tile
        ;
        Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v997 = Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v992, v37);
        // pto: %b_input__tile
        ;
        uint64_t v998 = (uint64_t) v24;
        TASSIGN(v997, v998);
        // pto: %603
        ;
        int64_t v999 = v987 < v45 ? v45 : v987;
        // pto: %604
        ;
        int64_t v1000 = v996 < v45 ? v45 : v996;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v1001 = 0;
        // pto: %quantized__ssa_v0_pview
        ;
        __gm__ int8_t* v1002 = PTOAS__GLOBAL_TENSOR_DATA(v85);
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v1003 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v1004 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v1005 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        int64_t v1006 = v992 * v42;
        // pto: %quantized__ssa_v0_pview
        ;
        int64_t v1007 = v1005 * v1006;
        // pto: %quantized__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 512> v1008 = pto::Shape<1, 1, 1, -1, 512>(v1003, v1004, v1005, v992, v37);
        // pto: %quantized__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1009 = pto::Stride<-1, -1, -1, -1, -1>(v1004 * v1007, v1007, v1006, v42, v29);
        // pto: %quantized__ssa_v0_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1010 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1002 + (v1001 + v999 * v42 + v1000 * v29), v1008, v1009);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v997, v1010);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %b_weight__tile
        ;
        Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1011 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v37, v36);
        // pto: %b_weight__tile
        ;
        uint64_t v1012 = (uint64_t) v23;
        TASSIGN(v1011, v1012);
        // pto: %605
        ;
        int64_t v1013 = v990 / v38;
        // pto: %606
        ;
        int64_t v1014 = v1013 < v45 ? v45 : v1013;
        // pto: %607
        ;
        int64_t v1015 = v996 / v33;
        // pto: %608
        ;
        int64_t v1016 = v1015 < v45 ? v45 : v1015;
        // pto: %wo_b__ssa_v0_pview
        ;
        __gm__ int8_t* v1017 = PTOAS__GLOBAL_TENSOR_DATA(v76);
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v1018 = 0;
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v1019 = 262144;
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v1020 = 512;
        // pto: %wo_b__ssa_v0_pview
        ;
        pto::Shape<1, 4, 32, 16, 32> v1021 = pto::Shape<1, 4, 32, 16, 32>();
        // pto: %wo_b__ssa_v0_pview
        ;
        pto::Stride<33554432, 262144, 512, 32, 1> v1022 = pto::Stride<33554432, 262144, 512, 32, 1>();
        // pto: %wo_b__ssa_v0_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v1023 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v1017 + (v1018 + v1014 * v1019 + v1016 * v1020), v1021, v1022);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v1011, v1023);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %b_acc__tile_l0_a
        ;
        Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1024 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v992, v32);
        // pto: %b_acc__tile_l0_a
        ;
        uint64_t v1025 = (uint64_t) v23;
        TASSIGN(v1024, v1025);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        uint16_t v1026 = static_cast<uint16_t>(v45);
        uint16_t v1027 = static_cast<uint16_t>(v45);
        TEXTRACT(v1024, v997, v1026, v1027);
        // pto: %b_acc__tile_l0_b
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1028 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %b_acc__tile_l0_b
        ;
        uint64_t v1029 = (uint64_t) v23;
        TASSIGN(v1028, v1029);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v1030 = static_cast<uint16_t>(v45);
        uint16_t v1031 = static_cast<uint16_t>(v45);
        TEXTRACT(v1028, v1011, v1030, v1031);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %51
        ;
        Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1032 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v992, v32);
        // pto: %51
        ;
        uint64_t v1033 = (uint64_t) v25;
        TASSIGN(v1032, v1033);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v1034 = static_cast<uint16_t>(v45);
        uint16_t v1035 = static_cast<uint16_t>(v32);
        TEXTRACT(v1032, v997, v1034, v1035);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        // pto: %52
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1036 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %52
        ;
        uint64_t v1037 = (uint64_t) v25;
        TASSIGN(v1036, v1037);
        uint16_t v1038 = static_cast<uint16_t>(v32);
        uint16_t v1039 = static_cast<uint16_t>(v45);
        TEXTRACT(v1036, v1011, v1038, v1039);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %609
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v995 == v45) {
          pipe_barrier(PIPE_M);
          TMATMUL(v993, v1024, v1028);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v993, v993, v1024, v1028);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v993, v993, v1032, v1036);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
      // pto: %610
      ;
      int64_t v1040 = v987 < v45 ? v45 : v987;
      // pto: %611
      ;
      int64_t v1041 = v990 < v45 ? v45 : v990;
      // pto: %integer_accum__ssa_v0_pview
      ;
      __gm__ int32_t* v1042 = PTOAS__GLOBAL_TENSOR_DATA(v103);
      // pto: %integer_accum__ssa_v0_pview
      ;
      const int64_t v1043 = 0;
      // pto: %integer_accum__ssa_v0_pview
      ;
      const int64_t v1044 = 4096;
      // pto: %integer_accum__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 128> v1045 = pto::Shape<1, 1, 1, 16, 128>();
      // pto: %integer_accum__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v1046 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %integer_accum__ssa_v0_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v1047 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v1042 + (v1043 + v1040 * v1044 + v1041), v1045, v1046);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
      pipe_barrier(PIPE_FIX);
      TSTORE(v1047, v993);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
    };
  } else {
    // pto: %612, %613, %614
    ;
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    for (int64_t v1048 = v126; v1048 < ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v60) / v31) * (uint64_t) v38)); v1048 += v48) {
      // pto: %615, %616
      ;
      int64_t v1049 = (int64_t) ((uint64_t) (v1048 / v38) * (uint64_t) v31);
      // pto: %617
      ;
      int64_t v1050 = v1048 % v38;
      // pto: %618, %619, %620
      ;
      int64_t v1051 = v1050 < v45 ? (int64_t) ((uint64_t) v1050 + (uint64_t) v38) : v1050;
      // pto: %621
      ;
      int64_t v1052 = (int64_t) ((uint64_t) v1051 * (uint64_t) v36);
      // pto: %622
      ;
      int64_t v1053 = (int64_t) ((uint64_t) v17 - (uint64_t) v1049);
      // pto: %623
      ;
      int64_t v1054 = v1053 < v31 ? v1053 : v31;
      // pto: %wide_first_input__tile
      ;
      Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1055 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v1054, v37);
      // pto: %wide_first_input__tile
      ;
      uint64_t v1056 = (uint64_t) v24;
      TASSIGN(v1055, v1056);
      // pto: %624
      ;
      int64_t v1057 = v1049 < v45 ? v45 : v1049;
      // pto: %625
      ;
      const int64_t v1058 = 0;
      // pto: %625
      ;
      __gm__ int8_t* v1059 = PTOAS__GLOBAL_TENSOR_DATA(v85);
      // pto: %625
      ;
      const int64_t v1060 = 1;
      // pto: %625
      ;
      const int64_t v1061 = 1;
      // pto: %625
      ;
      const int64_t v1062 = 1;
      // pto: %625
      ;
      int64_t v1063 = v1054 * v42;
      // pto: %625
      ;
      int64_t v1064 = v1062 * v1063;
      // pto: %625
      ;
      pto::Shape<1, 1, 1, -1, 512> v1065 = pto::Shape<1, 1, 1, -1, 512>(v1060, v1061, v1062, v1054, v37);
      // pto: %625
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1066 = pto::Stride<-1, -1, -1, -1, -1>(v1061 * v1064, v1064, v1063, v42, v29);
      // pto: %625
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1067 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1059 + (v1058 + v1057 * v42 + v45 * v29), v1065, v1066);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v1055, v1067);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %wide_first_weight__tile
      ;
      Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1068 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v37, v36);
      // pto: %wide_first_weight__tile
      ;
      uint64_t v1069 = (uint64_t) v23;
      TASSIGN(v1068, v1069);
      // pto: %626
      ;
      int64_t v1070 = v1052 / v38;
      // pto: %627
      ;
      int64_t v1071 = v1070 < v45 ? v45 : v1070;
      // pto: %628
      ;
      __gm__ int8_t* v1072 = PTOAS__GLOBAL_TENSOR_DATA(v76);
      // pto: %628
      ;
      const int64_t v1073 = 0;
      // pto: %628
      ;
      const int64_t v1074 = 262144;
      // pto: %628
      ;
      pto::Shape<1, 4, 32, 16, 32> v1075 = pto::Shape<1, 4, 32, 16, 32>();
      // pto: %628
      ;
      pto::Stride<33554432, 262144, 512, 32, 1> v1076 = pto::Stride<33554432, 262144, 512, 32, 1>();
      // pto: %628
      ;
      GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v1077 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v1072 + (v1073 + v1071 * v1074), v1075, v1076);
      TLOAD(v1068, v1077);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %wide_b_acc__tile_l0_init_storage
      ;
      Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v1078 = Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v31, v36);
      // pto: %wide_b_acc__tile_l0_init_storage
      ;
      uint64_t v1079 = (uint64_t) v23;
      TASSIGN(v1078, v1079);
      v1078.SetValidShape(v1054, v36);
      // pto: %wide_b_acc__tile_l0_a
      ;
      Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1080 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v1054, v32);
      // pto: %wide_b_acc__tile_l0_a
      ;
      uint64_t v1081 = (uint64_t) v23;
      TASSIGN(v1080, v1081);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      uint16_t v1082 = static_cast<uint16_t>(v45);
      uint16_t v1083 = static_cast<uint16_t>(v45);
      TEXTRACT(v1080, v1055, v1082, v1083);
      // pto: %wide_b_acc__tile_l0_b
      ;
      Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1084 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
      // pto: %wide_b_acc__tile_l0_b
      ;
      uint64_t v1085 = (uint64_t) v23;
      TASSIGN(v1084, v1085);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      uint16_t v1086 = static_cast<uint16_t>(v45);
      uint16_t v1087 = static_cast<uint16_t>(v45);
      TEXTRACT(v1084, v1068, v1086, v1087);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %54
      ;
      Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1088 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v1054, v32);
      // pto: %54
      ;
      uint64_t v1089 = (uint64_t) v25;
      TASSIGN(v1088, v1089);
      uint16_t v1090 = static_cast<uint16_t>(v45);
      uint16_t v1091 = static_cast<uint16_t>(v32);
      TEXTRACT(v1088, v1055, v1090, v1091);
      // pto: %55
      ;
      Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1092 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
      // pto: %55
      ;
      uint64_t v1093 = (uint64_t) v25;
      TASSIGN(v1092, v1093);
      uint16_t v1094 = static_cast<uint16_t>(v32);
      uint16_t v1095 = static_cast<uint16_t>(v45);
      TEXTRACT(v1092, v1068, v1094, v1095);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
      TMATMUL(v1078, v1080, v1084);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v1078, v1078, v1088, v1092);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t v1096 = v29; v1096 < v33; v1096 += v29) {
        // pto: %629
        ;
        int64_t v1097 = (int64_t) ((uint64_t) v1096 * (uint64_t) v37);
        // pto: %wide_b_input__tile
        ;
        Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1098 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v1054, v37);
        // pto: %wide_b_input__tile
        ;
        uint64_t v1099 = (uint64_t) v24;
        TASSIGN(v1098, v1099);
        // pto: %631
        ;
        int64_t v1100 = v1097 < v45 ? v45 : v1097;
        // pto: %632
        ;
        const int64_t v1101 = 0;
        // pto: %632
        ;
        __gm__ int8_t* v1102 = PTOAS__GLOBAL_TENSOR_DATA(v85);
        // pto: %632
        ;
        const int64_t v1103 = 1;
        // pto: %632
        ;
        const int64_t v1104 = 1;
        // pto: %632
        ;
        const int64_t v1105 = 1;
        // pto: %632
        ;
        int64_t v1106 = v1054 * v42;
        // pto: %632
        ;
        int64_t v1107 = v1105 * v1106;
        // pto: %632
        ;
        pto::Shape<1, 1, 1, -1, 512> v1108 = pto::Shape<1, 1, 1, -1, 512>(v1103, v1104, v1105, v1054, v37);
        // pto: %632
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1109 = pto::Stride<-1, -1, -1, -1, -1>(v1104 * v1107, v1107, v1106, v42, v29);
        // pto: %632
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1110 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1102 + (v1101 + v1057 * v42 + v1100 * v29), v1108, v1109);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v1098, v1110);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %wide_b_weight__tile
        ;
        Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1111 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v37, v36);
        // pto: %wide_b_weight__tile
        ;
        uint64_t v1112 = (uint64_t) v23;
        TASSIGN(v1111, v1112);
        // pto: %635
        ;
        int64_t v1113 = v1097 / v33;
        // pto: %636
        ;
        int64_t v1114 = v1113 < v45 ? v45 : v1113;
        // pto: %637
        ;
        __gm__ int8_t* v1115 = PTOAS__GLOBAL_TENSOR_DATA(v76);
        // pto: %637
        ;
        const int64_t v1116 = 0;
        // pto: %637
        ;
        const int64_t v1117 = 262144;
        // pto: %637
        ;
        const int64_t v1118 = 512;
        // pto: %637
        ;
        pto::Shape<1, 4, 32, 16, 32> v1119 = pto::Shape<1, 4, 32, 16, 32>();
        // pto: %637
        ;
        pto::Stride<33554432, 262144, 512, 32, 1> v1120 = pto::Stride<33554432, 262144, 512, 32, 1>();
        // pto: %637
        ;
        GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v1121 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v1115 + (v1116 + v1071 * v1117 + v1114 * v1118), v1119, v1120);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        TLOAD(v1111, v1121);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %57
        ;
        Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1122 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v1054, v32);
        // pto: %57
        ;
        uint64_t v1123 = (uint64_t) v23;
        TASSIGN(v1122, v1123);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v1124 = static_cast<uint16_t>(v45);
        uint16_t v1125 = static_cast<uint16_t>(v45);
        TEXTRACT(v1122, v1098, v1124, v1125);
        // pto: %58
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1126 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %58
        ;
        uint64_t v1127 = (uint64_t) v23;
        TASSIGN(v1126, v1127);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v1128 = static_cast<uint16_t>(v45);
        uint16_t v1129 = static_cast<uint16_t>(v45);
        TEXTRACT(v1126, v1111, v1128, v1129);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %59
        ;
        Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1130 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v1054, v32);
        // pto: %59
        ;
        uint64_t v1131 = (uint64_t) v25;
        TASSIGN(v1130, v1131);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1132 = static_cast<uint16_t>(v45);
        uint16_t v1133 = static_cast<uint16_t>(v32);
        TEXTRACT(v1130, v1098, v1132, v1133);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        // pto: %60
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1134 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %60
        ;
        uint64_t v1135 = (uint64_t) v25;
        TASSIGN(v1134, v1135);
        uint16_t v1136 = static_cast<uint16_t>(v32);
        uint16_t v1137 = static_cast<uint16_t>(v45);
        TEXTRACT(v1134, v1111, v1136, v1137);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v1078, v1078, v1122, v1126);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v1078, v1078, v1130, v1134);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
      // pto: %639
      ;
      int64_t v1138 = v1052 < v45 ? v45 : v1052;
      // pto: %640
      ;
      const int64_t v1139 = 0;
      // pto: %640
      ;
      __gm__ int32_t* v1140 = PTOAS__GLOBAL_TENSOR_DATA(v103);
      // pto: %640
      ;
      const int64_t v1141 = 1;
      // pto: %640
      ;
      const int64_t v1142 = 1;
      // pto: %640
      ;
      const int64_t v1143 = 1;
      // pto: %640
      ;
      int64_t v1144 = v1054 * v41;
      // pto: %640
      ;
      int64_t v1145 = v1143 * v1144;
      // pto: %640
      ;
      pto::Shape<1, 1, 1, -1, 128> v1146 = pto::Shape<1, 1, 1, -1, 128>(v1141, v1142, v1143, v1054, v36);
      // pto: %640
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1147 = pto::Stride<-1, -1, -1, -1, -1>(v1142 * v1145, v1145, v1144, v41, v29);
      // pto: %640
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1148 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1140 + (v1139 + v1057 * v41 + v1138 * v29), v1146, v1147);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
      TSTORE(v1148, v1078);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    };
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %642
  int64_t v1149 = (int64_t) ((uint64_t) v127 + (uint64_t) v61);
  // pto: %643
  int64_t v1150 = v1149 < v45 ? v45 : v1149;
  // pto: %signals_v2__ssa_v0_signal_pview
  __gm__ int32_t* v1151 = PTOAS__GLOBAL_TENSOR_DATA(v113);
  // pto: %signals_v2__ssa_v0_signal_pview
  const int64_t v1152 = 0;
  // pto: %signals_v2__ssa_v0_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v1153 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals_v2__ssa_v0_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v1154 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals_v2__ssa_v0_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v1155 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v1151 + (v1152 + v1150), v1153, v1154);
  pto::comm::NotifyOp v1156 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v1155, v136, v1156);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void vector(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21, int32_t v22) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int32_t v23 = 1;
  // pto: %c0_i64
  const int64_t v24 = 0;
  // pto: %c32768_i64
  const int64_t v25 = 32768;
  // pto: %c65536_i64
  const int64_t v26 = 65536;
  // pto: %c65568_i64
  const int64_t v27 = 65568;
  // pto: %c32_i64
  const int64_t v28 = 32;
  // pto: %c64_i64
  const int64_t v29 = 64;
  // pto: %c49152_i64
  const int64_t v30 = 49152;
  // pto: %c67584_i64
  const int64_t v31 = 67584;
  // pto: %c16384_i64
  const int64_t v32 = 16384;
  // pto: %c81920_i64
  const int64_t v33 = 81920;
  // pto: %c98304_i64
  const int64_t v34 = 98304;
  // pto: %c114688_i64
  const int64_t v35 = 114688;
  // pto: %c122880_i64
  const int64_t v36 = 122880;
  // pto: %c1_index
  const int64_t v37 = 1;
  // pto: %c8_index
  const int64_t v38 = 8;
  // pto: %c64_index
  const int64_t v39 = 64;
  // pto: %c16_index
  const int64_t v40 = 16;
  // pto: %c128_index
  const int64_t v41 = 128;
  // pto: %c512_index
  const int64_t v42 = 512;
  // pto: %c32_index
  const int64_t v43 = 32;
  // pto: %c4096_index
  const int64_t v44 = 4096;
  // pto: %c8192_index
  const int64_t v45 = 8192;
  // pto: %c16384_index
  const int64_t v46 = 16384;
  // pto: %c4_index
  const int64_t v47 = 4;
  // pto: %c55296_index
  const int64_t v48 = 55296;
  // pto: %c2_index
  const int64_t v49 = 2;
  // pto: %c24_index
  const int64_t v50 = 24;
  // pto: %c0_index
  const int64_t v51 = 0;
  // pto: %c15_index
  const int64_t v52 = 15;
  // pto: %c9216_index
  const int64_t v53 = 9216;
  // pto: %c48_index
  const int64_t v54 = 48;
  // pto: %c1024_index
  const int64_t v55 = 1024;
  // pto: %c18432_index
  const int64_t v56 = 18432;
  // pto: %c7_index
  const int64_t v57 = 7;
  // pto: %c21504_index
  const int64_t v58 = 21504;
  // pto: %cst_41
  const float v59 = 0.00787401571f;
  // pto: %cst_42
  const float v60 = 0.0f;
  // pto: %cst_43
  const float v61 = 1.0f;
  // pto: %cst_44
  const float v62 = 127.0f;
  // pto: %c27648_index
  const int64_t v63 = 27648;
  // pto: %c36864_index
  const int64_t v64 = 36864;
  // pto: %c46080_index
  const int64_t v65 = 46080;
  // pto: %c72_index
  const int64_t v66 = 72;
  // pto: %c3_index
  const int64_t v67 = 3;
  // pto: %c12_index
  const int64_t v68 = 12;
  // pto: %c5_index
  const int64_t v69 = 5;
  // pto: %c9_index
  const int64_t v70 = 9;
  // pto: %c13_index
  const int64_t v71 = 13;
  // pto: %c6_index
  const int64_t v72 = 6;
  // pto: %c10_index
  const int64_t v73 = 10;
  // pto: %c14_index
  const int64_t v74 = 14;
  // pto: %c11_index
  const int64_t v75 = 11;
  // pto: %c12288_index
  const int64_t v76 = 12288;
  // pto: %cn1_index
  const int64_t v77 = -1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v79 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v80 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v81 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v82 = v44 * v37;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v83 = v81 * v82;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v84 = v80 * v83;
  // pto: %wo_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v85 = pto::Shape<1, 1, 1, 1, -1>(v78, v79, v80, v81, v44);
  // pto: %wo_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v86 = pto::Stride<-1, -1, -1, -1, -1>(v79 * v84, v84, v83, v82, v37);
  // pto: %wo_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v87 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v85, v86);
  // pto: %projected__ssa_v0_view
  const int64_t v88 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v89 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v90 = 1;
  // pto: %projected__ssa_v0_view
  int64_t v91 = (int64_t) v17;
  // pto: %projected__ssa_v0_view
  int64_t v92 = v91 * v45;
  // pto: %projected__ssa_v0_view
  int64_t v93 = v90 * v92;
  // pto: %projected__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v94 = pto::Shape<1, 1, 1, -1, -1>(v88, v89, v90, v91, v45);
  // pto: %projected__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v95 = pto::Stride<-1, -1, -1, -1, -1>(v89 * v93, v93, v92, v45, v37);
  // pto: %projected__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v96 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v94, v95);
  // pto: %quantized__ssa_v0_view
  const int64_t v97 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v98 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v99 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v100 = (int64_t) v17;
  // pto: %quantized__ssa_v0_view
  int64_t v101 = v100 * v45;
  // pto: %quantized__ssa_v0_view
  int64_t v102 = v99 * v101;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v103 = pto::Shape<1, 1, 1, -1, -1>(v97, v98, v99, v100, v45);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v104 = pto::Stride<-1, -1, -1, -1, -1>(v98 * v102, v102, v101, v45, v37);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v105 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v103, v104);
  // pto: %token_scale__ssa_v0_view
  const int64_t v106 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v107 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v108 = 1;
  // pto: %token_scale__ssa_v0_view
  int64_t v109 = (int64_t) v17;
  // pto: %token_scale__ssa_v0_view
  int64_t v110 = v109 * v37;
  // pto: %token_scale__ssa_v0_view
  int64_t v111 = v108 * v110;
  // pto: %token_scale__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v112 = pto::Shape<1, 1, 1, -1, -1>(v106, v107, v108, v109, v37);
  // pto: %token_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v113 = pto::Stride<-1, -1, -1, -1, -1>(v107 * v111, v111, v110, v37, (int64_t) v17);
  // pto: %token_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v114 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v8, v112, v113);
  // pto: %attended__ssa_v0_view
  const int64_t v115 = 1;
  // pto: %attended__ssa_v0_view
  const int64_t v116 = 1;
  // pto: %attended__ssa_v0_view
  const int64_t v117 = 1;
  // pto: %attended__ssa_v0_view
  int64_t v118 = (int64_t) v17;
  // pto: %attended__ssa_v0_view
  int64_t v119 = v118 * v44;
  // pto: %attended__ssa_v0_view
  int64_t v120 = v117 * v119;
  // pto: %attended__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v121 = pto::Shape<1, 1, 1, -1, -1>(v115, v116, v117, v118, v44);
  // pto: %attended__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v122 = pto::Stride<-1, -1, -1, -1, -1>(v116 * v120, v120, v119, v44, v37);
  // pto: %attended__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v123 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v121, v122);
  // pto: %residual__ssa_v0_view
  const int64_t v124 = 1;
  // pto: %residual__ssa_v0_view
  const int64_t v125 = 1;
  // pto: %residual__ssa_v0_view
  const int64_t v126 = 1;
  // pto: %residual__ssa_v0_view
  int64_t v127 = (int64_t) v17;
  // pto: %residual__ssa_v0_view
  int64_t v128 = v127 * v46;
  // pto: %residual__ssa_v0_view
  int64_t v129 = v126 * v128;
  // pto: %residual__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v130 = pto::Shape<1, 1, 1, -1, -1>(v124, v125, v126, v127, v46);
  // pto: %residual__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v131 = pto::Stride<-1, -1, -1, -1, -1>(v125 * v129, v129, v128, v46, v37);
  // pto: %residual__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v132 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v130, v131);
  // pto: %output__ssa_v0_view
  const int64_t v133 = 1;
  // pto: %output__ssa_v0_view
  const int64_t v134 = 1;
  // pto: %output__ssa_v0_view
  const int64_t v135 = 1;
  // pto: %output__ssa_v0_view
  int64_t v136 = (int64_t) v17;
  // pto: %output__ssa_v0_view
  int64_t v137 = v136 * v46;
  // pto: %output__ssa_v0_view
  int64_t v138 = v135 * v137;
  // pto: %output__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v139 = pto::Shape<1, 1, 1, -1, -1>(v133, v134, v135, v136, v46);
  // pto: %output__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v140 = pto::Stride<-1, -1, -1, -1, -1>(v134 * v138, v138, v137, v46, v37);
  // pto: %output__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v141 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v139, v140);
  // pto: %accum__ssa_v0_view
  const int64_t v142 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v143 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v144 = 1;
  // pto: %accum__ssa_v0_view
  int64_t v145 = (int64_t) v18;
  // pto: %accum__ssa_v0_view
  int64_t v146 = v145 * v45;
  // pto: %accum__ssa_v0_view
  int64_t v147 = v144 * v146;
  // pto: %accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v148 = pto::Shape<1, 1, 1, -1, -1>(v142, v143, v144, v145, v45);
  // pto: %accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v149 = pto::Stride<-1, -1, -1, -1, -1>(v143 * v147, v147, v146, v45, v37);
  // pto: %accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v150 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v148, v149);
  // pto: %integer_accum__ssa_v0_view
  const int64_t v151 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v152 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v153 = 1;
  // pto: %integer_accum__ssa_v0_view
  int64_t v154 = (int64_t) v19;
  // pto: %integer_accum__ssa_v0_view
  int64_t v155 = v154 * v44;
  // pto: %integer_accum__ssa_v0_view
  int64_t v156 = v153 * v155;
  // pto: %integer_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v157 = pto::Shape<1, 1, 1, -1, -1>(v151, v152, v153, v154, v44);
  // pto: %integer_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v158 = pto::Stride<-1, -1, -1, -1, -1>(v152 * v156, v156, v155, v44, v37);
  // pto: %integer_accum__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v159 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v157, v158);
  // pto: %signals__ssa_v0_view
  const int64_t v160 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v161 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v162 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v163 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v164 = v48 * v37;
  // pto: %signals__ssa_v0_view
  int64_t v165 = v163 * v164;
  // pto: %signals__ssa_v0_view
  int64_t v166 = v162 * v165;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v167 = pto::Shape<1, 1, 1, 1, -1>(v160, v161, v162, v163, v48);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v168 = pto::Stride<-1, -1, -1, -1, -1>(v161 * v166, v166, v165, v164, v37);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v169 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v167, v168);
  // pto: %t__tmp_v0, %145, %146, %t__tmp_v1
  int64_t v170 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v20) * (uint64_t) v49) + (uint64_t) ((int64_t) v22));
  // pto: %147, %148
  int64_t v171 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v170 + (uint64_t) v50) * (uint64_t) v41);
  // pto: %149
  int64_t v172 = v171 < v51 ? v51 : v171;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v173 = PTOAS__GLOBAL_TENSOR_DATA(v169);
  // pto: %signals__ssa_v0_pview
  const int64_t v174 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v175 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v176 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v177 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v173 + (v174 + v172), v175, v176);
  __gm__ int32_t* v178 = PTOAS__GLOBAL_TENSOR_DATA(v177);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v178);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  // pto: %150
  int32_t v179 = (v16)[v171];
  // pto: %152
  int32_t v180 = (int32_t) ((uint32_t) v179 + (uint32_t) v23);
  pipe_barrier(PIPE_ALL);
  pto::comm::NotifyOp v181 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v177, v180, v181);
  // pto: %154, %155, %156
  int64_t v182 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v52) / v40) * (uint64_t) v38);
  // pto: %157
  if (v170 < v182) {
    for (int64_t v183 = v51; v183 < v38; v183 += v37) {
      // pto: %158
      ;
      int64_t v184 = v170 % v38;
      // pto: %159, %160, %161
      ;
      int64_t v185 = v184 < v51 ? (int64_t) ((uint64_t) v184 + (uint64_t) v38) : v184;
      // pto: %162, %163, %164
      ;
      int64_t v186 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v185 * (uint64_t) v38) + (uint64_t) v183) % v50;
      // pto: %165, %166, %167
      ;
      int64_t v187 = v186 < v51 ? (int64_t) ((uint64_t) v186 + (uint64_t) v50) : v186;
      // pto: %168, %169
      ;
      int64_t v188 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v187 * (uint64_t) v41) + (uint64_t) v53);
      // pto: %170
      ;
      int64_t v189 = v188 < v51 ? v51 : v188;
      // pto: %signals__ssa_v1_signal_pview
      ;
      __gm__ int32_t* v190 = PTOAS__GLOBAL_TENSOR_DATA(v169);
      // pto: %signals__ssa_v1_signal_pview
      ;
      const int64_t v191 = 0;
      // pto: %signals__ssa_v1_signal_pview
      ;
      pto::Shape<1, 1, 1, 1, 1> v192 = pto::Shape<1, 1, 1, 1, 1>();
      // pto: %signals__ssa_v1_signal_pview
      ;
      pto::Stride<1, 1, 1, 1, 1> v193 = pto::Stride<1, 1, 1, 1, 1>();
      // pto: %signals__ssa_v1_signal_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v194 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v190 + (v191 + v189), v192, v193);
      pto::comm::WaitCmp v195 = pto::comm::WaitCmp::GE;
      pto::comm::TWAIT(v194, v180, v195);
    };
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
  }
  for (int64_t v196 = v170; v196 < v182; v196 += v54) {
    // pto: %172, %173
    ;
    int64_t v197 = (int64_t) ((uint64_t) (v196 / v38) * (uint64_t) v40);
    // pto: %174
    ;
    int64_t v198 = v196 % v38;
    // pto: %175, %176, %177
    ;
    int64_t v199 = v198 < v51 ? (int64_t) ((uint64_t) v198 + (uint64_t) v38) : v198;
    // pto: %178
    ;
    int64_t v200 = (int64_t) ((uint64_t) v199 * (uint64_t) v55);
    // pto: %179
    ;
    int64_t v201 = (int64_t) ((uint64_t) v17 - (uint64_t) v197);
    // pto: %180
    ;
    int64_t v202 = v201 < v40 ? v201 : v40;
    // pto: %oa_value__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v203 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v202, v55);
    // pto: %oa_value__ssa_v0
    ;
    uint64_t v204 = (uint64_t) v24;
    TASSIGN(v203, v204);
    // pto: %181
    ;
    int64_t v205 = v197 < v51 ? v51 : v197;
    // pto: %182
    ;
    int64_t v206 = v200 < v51 ? v51 : v200;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v207 = 0;
    // pto: %accum__ssa_v0_pview
    ;
    __gm__ float* v208 = PTOAS__GLOBAL_TENSOR_DATA(v150);
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v209 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v210 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v211 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    int64_t v212 = v202 * v45;
    // pto: %accum__ssa_v0_pview
    ;
    int64_t v213 = v211 * v212;
    // pto: %accum__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v214 = pto::Shape<1, 1, 1, -1, 1024>(v209, v210, v211, v202, v55);
    // pto: %accum__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v215 = pto::Stride<-1, -1, -1, -1, -1>(v210 * v213, v213, v212, v45, v37);
    // pto: %accum__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v216 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v208 + (v207 + v205 * v45 + v206 * v37), v214, v215);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v203, v216);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %t__tmp_v3
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v202, v55);
    // pto: %t__tmp_v3
    ;
    uint64_t v218 = (uint64_t) v24;
    TASSIGN(v217, v218);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v219 = RoundMode::CAST_RINT;
    SaturationMode v220 = SaturationMode::ON;
    TCVT(v217, v203, v219, v220);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v221 = 0;
    // pto: %projected__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v222 = PTOAS__GLOBAL_TENSOR_DATA(v96);
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v223 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v224 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v225 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    int64_t v226 = v202 * v45;
    // pto: %projected__ssa_v0_pview
    ;
    int64_t v227 = v225 * v226;
    // pto: %projected__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v228 = pto::Shape<1, 1, 1, -1, 1024>(v223, v224, v225, v202, v55);
    // pto: %projected__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v229 = pto::Stride<-1, -1, -1, -1, -1>(v224 * v227, v227, v226, v45, v37);
    // pto: %projected__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v230 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v222 + (v221 + v205 * v45 + v206 * v37), v228, v229);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v230, v217);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %186
  int64_t v231 = (int64_t) ((uint64_t) v171 + (uint64_t) v56);
  // pto: %187
  int64_t v232 = v231 < v51 ? v51 : v231;
  // pto: %188
  __gm__ int32_t* v233 = PTOAS__GLOBAL_TENSOR_DATA(v169);
  // pto: %188
  const int64_t v234 = 0;
  // pto: %188
  pto::Shape<1, 1, 1, 1, 1> v235 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %188
  pto::Stride<1, 1, 1, 1, 1> v236 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %188
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v237 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v233 + (v234 + v232), v235, v236);
  pto::comm::NotifyOp v238 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v237, v180, v238);
  // pto: %189, %190
  int64_t v239 = (int64_t) ((uint64_t) v17 + (uint64_t) v57) / v38;
  // pto: %191
  if (v170 < v239) {
    for (int64_t v240 = v51; v240 < v38; v240 += v37) {
      // pto: %192, %193, %194, %195
      ;
      int64_t v241 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v170 / v49) * (uint64_t) v38) + (uint64_t) v240) % v54;
      // pto: %196, %197, %198
      ;
      int64_t v242 = v241 < v51 ? (int64_t) ((uint64_t) v241 + (uint64_t) v54) : v241;
      // pto: %199, %200
      ;
      int64_t v243 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v242 * (uint64_t) v41) + (uint64_t) v58);
      // pto: %201
      ;
      int64_t v244 = v243 < v51 ? v51 : v243;
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      __gm__ int32_t* v245 = PTOAS__GLOBAL_TENSOR_DATA(v169);
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      const int64_t v246 = 0;
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      pto::Shape<1, 1, 1, 1, 1> v247 = pto::Shape<1, 1, 1, 1, 1>();
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      pto::Stride<1, 1, 1, 1, 1> v248 = pto::Stride<1, 1, 1, 1, 1>();
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v249 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v245 + (v246 + v244), v247, v248);
      pto::comm::WaitCmp v250 = pto::comm::WaitCmp::GE;
      pto::comm::TWAIT(v249, v180, v250);
    };
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  for (int64_t v251 = v170; v251 < v239; v251 += v54) {
    // pto: %203
    ;
    int64_t v252 = (int64_t) ((uint64_t) v251 * (uint64_t) v38);
    // pto: %204
    ;
    int64_t v253 = (int64_t) ((uint64_t) v17 - (uint64_t) v252);
    // pto: %205
    ;
    int64_t v254 = v253 < v38 ? v253 : v38;
    // pto: %first_quant__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v55);
    // pto: %first_quant__ssa_v0
    ;
    uint64_t v256 = (uint64_t) v25;
    TASSIGN(v255, v256);
    // pto: %206
    ;
    int64_t v257 = v252 < v51 ? v51 : v252;
    // pto: %207
    ;
    const int64_t v258 = 0;
    // pto: %207
    ;
    __gm__ bfloat16_t* v259 = PTOAS__GLOBAL_TENSOR_DATA(v96);
    // pto: %207
    ;
    const int64_t v260 = 1;
    // pto: %207
    ;
    const int64_t v261 = 1;
    // pto: %207
    ;
    const int64_t v262 = 1;
    // pto: %207
    ;
    int64_t v263 = v254 * v45;
    // pto: %207
    ;
    int64_t v264 = v262 * v263;
    // pto: %207
    ;
    pto::Shape<1, 1, 1, -1, 1024> v265 = pto::Shape<1, 1, 1, -1, 1024>(v260, v261, v262, v254, v55);
    // pto: %207
    ;
    pto::Stride<-1, -1, -1, -1, -1> v266 = pto::Stride<-1, -1, -1, -1, -1>(v261 * v264, v264, v263, v45, v37);
    // pto: %207
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v267 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v259 + (v258 + v257 * v45 + v51 * v37), v265, v266);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v255, v267);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %t__tmp_v4
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v268 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v55);
    // pto: %t__tmp_v4
    ;
    uint64_t v269 = (uint64_t) v24;
    TASSIGN(v268, v269);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    RoundMode v270 = RoundMode::CAST_ROUND;
    SaturationMode v271 = SaturationMode::ON;
    TCVT(v268, v255, v270, v271);
    // pto: %first_abs__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v272 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v55);
    // pto: %first_abs__ssa_v0
    ;
    uint64_t v273 = (uint64_t) v24;
    TASSIGN(v272, v273);
    pipe_barrier(PIPE_V);
    TABS(v272, v268);
    // pto: %t__tmp_v5
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v274 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v55);
    // pto: %t__tmp_v5
    ;
    uint64_t v275 = (uint64_t) v25;
    TASSIGN(v274, v275);
    // pto: %amax__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v276 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v37);
    // pto: %amax__ssa_v0
    ;
    uint64_t v277 = (uint64_t) v26;
    TASSIGN(v276, v277);
    pipe_barrier(PIPE_V);
    TROWMAX(v276, v272, v274);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    for (int64_t v278 = v37; v278 < v38; v278 += v37) {
      // pto: %q_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v55);
      // pto: %q_bf16__ssa_v0
      ;
      uint64_t v280 = (uint64_t) v25;
      TASSIGN(v279, v280);
      // pto: %209
      ;
      int64_t v281 = (int64_t) ((uint64_t) v278 * (uint64_t) v55);
      // pto: %210
      ;
      int64_t v282 = v281 < v51 ? v51 : v281;
      // pto: %211
      ;
      const int64_t v283 = 0;
      // pto: %211
      ;
      __gm__ bfloat16_t* v284 = PTOAS__GLOBAL_TENSOR_DATA(v96);
      // pto: %211
      ;
      const int64_t v285 = 1;
      // pto: %211
      ;
      const int64_t v286 = 1;
      // pto: %211
      ;
      const int64_t v287 = 1;
      // pto: %211
      ;
      int64_t v288 = v254 * v45;
      // pto: %211
      ;
      int64_t v289 = v287 * v288;
      // pto: %211
      ;
      pto::Shape<1, 1, 1, -1, 1024> v290 = pto::Shape<1, 1, 1, -1, 1024>(v285, v286, v287, v254, v55);
      // pto: %211
      ;
      pto::Stride<-1, -1, -1, -1, -1> v291 = pto::Stride<-1, -1, -1, -1, -1>(v286 * v289, v289, v288, v45, v37);
      // pto: %211
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v292 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v284 + (v283 + v257 * v45 + v282 * v37), v290, v291);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v279, v292);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %q_fp32__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v55);
      // pto: %q_fp32__ssa_v0
      ;
      uint64_t v294 = (uint64_t) v24;
      TASSIGN(v293, v294);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      pipe_barrier(PIPE_V);
      RoundMode v295 = RoundMode::CAST_ROUND;
      SaturationMode v296 = SaturationMode::ON;
      TCVT(v293, v279, v295, v296);
      // pto: %t__tmp_v6
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v55);
      // pto: %t__tmp_v6
      ;
      uint64_t v298 = (uint64_t) v24;
      TASSIGN(v297, v298);
      pipe_barrier(PIPE_V);
      TABS(v297, v293);
      // pto: %t__tmp_v7
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v55);
      // pto: %t__tmp_v7
      ;
      uint64_t v300 = (uint64_t) v25;
      TASSIGN(v299, v300);
      // pto: %t__tmp_v8
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v37);
      // pto: %t__tmp_v8
      ;
      uint64_t v302 = (uint64_t) v27;
      TASSIGN(v301, v302);
      pipe_barrier(PIPE_V);
      TROWMAX(v301, v297, v299);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      // pto: %amax__rm_a0_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v254);
      // pto: %amax__rm_a0_tmp_v0
      ;
      uint64_t v304 = (uint64_t) v26;
      TASSIGN(v303, v304);
      // pto: %amax__rm_a1_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v254);
      // pto: %amax__rm_a1_tmp_v1
      ;
      uint64_t v306 = (uint64_t) v27;
      TASSIGN(v305, v306);
      // pto: %amax__row_major_tmp_v2
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v254);
      // pto: %amax__row_major_tmp_v2
      ;
      uint64_t v308 = (uint64_t) v24;
      TASSIGN(v307, v308);
      pipe_barrier(PIPE_V);
      TMAX(v307, v303, v305);
      // pto: %amax__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v37);
      // pto: %amax__ssa_v3
      ;
      uint64_t v310 = (uint64_t) v24;
      TASSIGN(v309, v310);
      // pto: %amax__ssa_v3_mv
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v37);
      // pto: %amax__ssa_v3_mv
      ;
      uint64_t v312 = (uint64_t) v26;
      TASSIGN(v311, v312);
      pipe_barrier(PIPE_V);
      TMOV(v311, v309);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    // pto: %dequant__rm_a0_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v254);
    // pto: %dequant__rm_a0_tmp_v3
    ;
    uint64_t v314 = (uint64_t) v26;
    TASSIGN(v313, v314);
    // pto: %dequant__row_major_tmp_v4
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v254);
    // pto: %dequant__row_major_tmp_v4
    ;
    uint64_t v316 = (uint64_t) v24;
    TASSIGN(v315, v316);
    pipe_barrier(PIPE_V);
    TMULS(v315, v313, v59);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %dequant__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v37);
    // pto: %dequant__ssa_v0
    ;
    uint64_t v318 = (uint64_t) v24;
    TASSIGN(v317, v318);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v319 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v254);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    uint64_t v320 = (uint64_t) v26;
    TASSIGN(v319, v320);
    // pto: %denominator__row_major_tmp_v6
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v254);
    // pto: %denominator__row_major_tmp_v6
    ;
    uint64_t v322 = (uint64_t) v28;
    TASSIGN(v321, v322);
    TADDS(v321, v319, v60);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    // pto: %denominator__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v323 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v37);
    // pto: %denominator__ssa_v0
    ;
    uint64_t v324 = (uint64_t) v28;
    TASSIGN(v323, v324);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    for (int64_t v325 = v51; v325 < v254; v325 += v37) {
      // pto: %magnitude__ssa_v0
      ;
      float v326 = v323.GetValue(v325);
      // pto: %212
      ;
      bool v327 = v326 != v326 || v60 != v60;
      // pto: %212
      ;
      if ((v326 == v326 && v60 == v60) && v326 == v60) {
        v323.SetValue(v325, v61);
      };
    };
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    // pto: %t__rm_a0_tmp_v7
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v254);
    // pto: %t__rm_a0_tmp_v7
    ;
    uint64_t v329 = (uint64_t) v26;
    TASSIGN(v328, v329);
    // pto: %t__row_major_tmp_v8
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v330 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v254);
    // pto: %t__row_major_tmp_v8
    ;
    uint64_t v331 = (uint64_t) v29;
    TASSIGN(v330, v331);
    TMULS(v330, v328, v60);
    // pto: %t__tmp_v9
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v332 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v37);
    // pto: %t__tmp_v9
    ;
    uint64_t v333 = (uint64_t) v29;
    TASSIGN(v332, v333);
    // pto: %t__rm_a0_tmp_v9
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v334 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v254);
    // pto: %t__rm_a0_tmp_v9
    ;
    uint64_t v335 = (uint64_t) v29;
    TASSIGN(v334, v335);
    // pto: %t__row_major_tmp_v10
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v336 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v254);
    // pto: %t__row_major_tmp_v10
    ;
    uint64_t v337 = (uint64_t) v29;
    TASSIGN(v336, v337);
    pipe_barrier(PIPE_V);
    TADDS(v336, v334, v62);
    // pto: %t__tmp_v10
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v338 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v37);
    // pto: %t__tmp_v10
    ;
    uint64_t v339 = (uint64_t) v29;
    TASSIGN(v338, v339);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v340 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v254);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    uint64_t v341 = (uint64_t) v29;
    TASSIGN(v340, v341);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v342 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v254);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    uint64_t v343 = (uint64_t) v28;
    TASSIGN(v342, v343);
    // pto: %multiplier__row_major_tmp_v13
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v344 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v254);
    // pto: %multiplier__row_major_tmp_v13
    ;
    uint64_t v345 = (uint64_t) v30;
    TASSIGN(v344, v345);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    TDIV(v344, v340, v342);
    // pto: %multiplier__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v346 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v37);
    // pto: %multiplier__ssa_v0
    ;
    uint64_t v347 = (uint64_t) v30;
    TASSIGN(v346, v347);
    v317.SetValidShape(v254, v37);
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v348 = (int64_t) v17;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v349 = 0;
    // pto: %token_scale__ssa_v0_pview
    ;
    __gm__ float* v350 = PTOAS__GLOBAL_TENSOR_DATA(v114);
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v351 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v352 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v353 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v354 = v254 * v37;
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v355 = v353 * v354;
    // pto: %token_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1> v356 = pto::Shape<1, 1, 1, -1, 1>(v351, v352, v353, v254, v37);
    // pto: %token_scale__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v357 = pto::Stride<-1, -1, -1, -1, -1>(v352 * v355, v355, v354, v37, v348);
    // pto: %token_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v358 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v350 + (v349 + v257 * v37 + v51 * v348), v356, v357);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    TSTORE(v358, v317);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    for (int64_t v359 = v51; v359 < v38; v359 += v37) {
      // pto: %217
      ;
      int64_t v360 = (int64_t) ((uint64_t) v359 * (uint64_t) v55);
      // pto: %quant_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v361 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v55);
      // pto: %quant_bf16__ssa_v0
      ;
      uint64_t v362 = (uint64_t) v25;
      TASSIGN(v361, v362);
      // pto: %219
      ;
      int64_t v363 = v360 < v51 ? v51 : v360;
      // pto: %220
      ;
      const int64_t v364 = 0;
      // pto: %220
      ;
      __gm__ bfloat16_t* v365 = PTOAS__GLOBAL_TENSOR_DATA(v96);
      // pto: %220
      ;
      const int64_t v366 = 1;
      // pto: %220
      ;
      const int64_t v367 = 1;
      // pto: %220
      ;
      const int64_t v368 = 1;
      // pto: %220
      ;
      int64_t v369 = v254 * v45;
      // pto: %220
      ;
      int64_t v370 = v368 * v369;
      // pto: %220
      ;
      pto::Shape<1, 1, 1, -1, 1024> v371 = pto::Shape<1, 1, 1, -1, 1024>(v366, v367, v368, v254, v55);
      // pto: %220
      ;
      pto::Stride<-1, -1, -1, -1, -1> v372 = pto::Stride<-1, -1, -1, -1, -1>(v367 * v370, v370, v369, v45, v37);
      // pto: %220
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v373 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v365 + (v364 + v257 * v45 + v363 * v37), v371, v372);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      TLOAD(v361, v373);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %t__tmp_v12
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v374 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v55);
      // pto: %t__tmp_v12
      ;
      uint64_t v375 = (uint64_t) v24;
      TASSIGN(v374, v375);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      RoundMode v376 = RoundMode::CAST_ROUND;
      SaturationMode v377 = SaturationMode::ON;
      TCVT(v374, v361, v376, v377);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      // pto: %quant_scaled__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v378 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v55);
      // pto: %quant_scaled__ssa_v0
      ;
      uint64_t v379 = (uint64_t) v24;
      TASSIGN(v378, v379);
      pipe_barrier(PIPE_V);
      TROWEXPANDMUL(v378, v374, v346);
      // pto: %integer__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v380 = Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v55);
      // pto: %integer__ssa_v0
      ;
      uint64_t v381 = (uint64_t) v24;
      TASSIGN(v380, v381);
      pipe_barrier(PIPE_V);
      RoundMode v382 = RoundMode::CAST_RINT;
      SaturationMode v383 = SaturationMode::ON;
      TCVT(v380, v378, v382, v383);
      // pto: %half__ssa_v0
      ;
      Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v384 = Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v55);
      // pto: %half__ssa_v0
      ;
      uint64_t v385 = (uint64_t) v24;
      TASSIGN(v384, v385);
      pipe_barrier(PIPE_V);
      RoundMode v386 = RoundMode::CAST_ROUND;
      SaturationMode v387 = SaturationMode::ON;
      TCVT(v384, v380, v386, v387);
      // pto: %result__ssa_v0
      ;
      Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v388 = Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v254, v55);
      // pto: %result__ssa_v0
      ;
      uint64_t v389 = (uint64_t) v24;
      TASSIGN(v388, v389);
      pipe_barrier(PIPE_V);
      RoundMode v390 = RoundMode::CAST_TRUNC;
      SaturationMode v391 = SaturationMode::ON;
      TCVT(v388, v384, v390, v391);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      v388.SetValidShape(v254, v55);
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v392 = 0;
      // pto: %quantized__ssa_v0_pview
      ;
      __gm__ int8_t* v393 = PTOAS__GLOBAL_TENSOR_DATA(v105);
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v394 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v395 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v396 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      int64_t v397 = v254 * v45;
      // pto: %quantized__ssa_v0_pview
      ;
      int64_t v398 = v396 * v397;
      // pto: %quantized__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 1024> v399 = pto::Shape<1, 1, 1, -1, 1024>(v394, v395, v396, v254, v55);
      // pto: %quantized__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v400 = pto::Stride<-1, -1, -1, -1, -1>(v395 * v398, v398, v397, v45, v37);
      // pto: %quantized__ssa_v0_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v401 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v393 + (v392 + v257 * v45 + v363 * v37), v399, v400);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      TSTORE(v401, v388);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %224
  int64_t v402 = (int64_t) ((uint64_t) v171 + (uint64_t) v63);
  // pto: %225
  int64_t v403 = v402 < v51 ? v51 : v402;
  // pto: %226
  __gm__ int32_t* v404 = PTOAS__GLOBAL_TENSOR_DATA(v169);
  // pto: %226
  const int64_t v405 = 0;
  // pto: %226
  pto::Shape<1, 1, 1, 1, 1> v406 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %226
  pto::Stride<1, 1, 1, 1, 1> v407 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %226
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v408 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v404 + (v405 + v403), v406, v407);
  pto::comm::NotifyOp v409 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v408, v180, v409);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  for (int64_t v410 = v170; v410 < v182; v410 += v54) {
    // pto: %229, %230
    ;
    int64_t v411 = (int64_t) ((uint64_t) (v410 / v38) * (uint64_t) v40);
    // pto: %231
    ;
    int64_t v412 = v410 % v38;
    // pto: %232, %233, %234
    ;
    int64_t v413 = v412 < v51 ? (int64_t) ((uint64_t) v412 + (uint64_t) v38) : v412;
    // pto: %235
    ;
    int64_t v414 = (int64_t) ((uint64_t) v413 * (uint64_t) v42);
    // pto: %236
    ;
    int64_t v415 = (int64_t) ((uint64_t) v17 - (uint64_t) v411);
    // pto: %237
    ;
    int64_t v416 = v415 < v40 ? v415 : v40;
    for (int64_t v417 = v51; v417 < v47; v417 += v37) {
      // pto: %238
      ;
      // pto: %ob_owner__phi_v2
      ;
      int64_t v418;
      if (v17 <= v40) {
        // pto: %239, %240, %242, %241, %243, %244
        ;
        int64_t v419 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) (v411 / v40) * (uint64_t) v43) + (uint64_t) (v414 / v41)) + (uint64_t) v417) % v50;
        // pto: %245, %246, %247
        ;
        v418 = v419 < v51 ? (int64_t) ((uint64_t) v419 + (uint64_t) v50) : v419;
      } else {
        // pto: %248, %249, %251, %250, %252, %253
        ;
        int64_t v420 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) (v411 / v39) * (uint64_t) v43) + (uint64_t) (v414 / v41)) + (uint64_t) v417) % v50;
        // pto: %254, %255, %256
        ;
        v418 = v420 < v51 ? (int64_t) ((uint64_t) v420 + (uint64_t) v50) : v420;
      };
      // pto: %257
      ;
      uint64_t v421 = (uint64_t) v418;
      // pto: %257, %258
      ;
      int64_t v422 = (int64_t) ((uint64_t) ((int64_t) v421 * (uint64_t) v41) + (uint64_t) v64);
      // pto: %259
      ;
      int64_t v423 = v422 < v51 ? v51 : v422;
      // pto: %signals_v2__ssa_v0_signal_pview
      ;
      __gm__ int32_t* v424 = PTOAS__GLOBAL_TENSOR_DATA(v169);
      // pto: %signals_v2__ssa_v0_signal_pview
      ;
      const int64_t v425 = 0;
      // pto: %signals_v2__ssa_v0_signal_pview
      ;
      pto::Shape<1, 1, 1, 1, 1> v426 = pto::Shape<1, 1, 1, 1, 1>();
      // pto: %signals_v2__ssa_v0_signal_pview
      ;
      pto::Stride<1, 1, 1, 1, 1> v427 = pto::Stride<1, 1, 1, 1, 1>();
      // pto: %signals_v2__ssa_v0_signal_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v428 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v424 + (v425 + v423), v426, v427);
      pto::comm::WaitCmp v429 = pto::comm::WaitCmp::GE;
      pto::comm::TWAIT(v428, v180, v429);
    };
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    // pto: %ob_integer__ssa_v0
    ;
    Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v430 = Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v416, v42);
    // pto: %ob_integer__ssa_v0
    ;
    uint64_t v431 = (uint64_t) v24;
    TASSIGN(v430, v431);
    // pto: %260
    ;
    int64_t v432 = v411 < v51 ? v51 : v411;
    // pto: %261
    ;
    int64_t v433 = v414 < v51 ? v51 : v414;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v434 = 0;
    // pto: %integer_accum__ssa_v0_pview
    ;
    __gm__ int32_t* v435 = PTOAS__GLOBAL_TENSOR_DATA(v159);
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v436 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v437 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v438 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    int64_t v439 = v416 * v44;
    // pto: %integer_accum__ssa_v0_pview
    ;
    int64_t v440 = v438 * v439;
    // pto: %integer_accum__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v441 = pto::Shape<1, 1, 1, -1, 512>(v436, v437, v438, v416, v42);
    // pto: %integer_accum__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v442 = pto::Stride<-1, -1, -1, -1, -1>(v437 * v440, v440, v439, v44, v37);
    // pto: %integer_accum__ssa_v0_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v443 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v435 + (v434 + v432 * v44 + v433 * v37), v441, v442);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    TLOAD(v430, v443);
    // pto: %t__tmp_v14
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v444 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
    // pto: %t__tmp_v14
    ;
    uint64_t v445 = (uint64_t) v26;
    TASSIGN(v444, v445);
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    __gm__ float* v446 = PTOAS__GLOBAL_TENSOR_DATA(v87);
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    const int64_t v447 = 0;
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 512> v448 = pto::Shape<1, 1, 1, 1, 512>();
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    pto::Stride<512, 512, 512, 512, 1> v449 = pto::Stride<512, 512, 512, 512, 1>();
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v450 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v446 + (v447 + v433), v448, v449);
    TLOAD(v444, v450);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    // pto: %channel__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v451 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
    // pto: %channel__ssa_v0
    ;
    uint64_t v452 = (uint64_t) v26;
    TASSIGN(v451, v452);
    // pto: %scale__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v453 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v416, v37);
    // pto: %scale__ssa_v0
    ;
    uint64_t v454 = (uint64_t) v31;
    TASSIGN(v453, v454);
    // pto: %264
    ;
    int64_t v455 = (int64_t) v17;
    // pto: %264
    ;
    const int64_t v456 = 0;
    // pto: %264
    ;
    __gm__ float* v457 = PTOAS__GLOBAL_TENSOR_DATA(v114);
    // pto: %264
    ;
    const int64_t v458 = 1;
    // pto: %264
    ;
    const int64_t v459 = 1;
    // pto: %264
    ;
    const int64_t v460 = 1;
    // pto: %264
    ;
    int64_t v461 = v416 * v37;
    // pto: %264
    ;
    int64_t v462 = v460 * v461;
    // pto: %264
    ;
    pto::Shape<1, 1, 1, -1, 1> v463 = pto::Shape<1, 1, 1, -1, 1>(v458, v459, v460, v416, v37);
    // pto: %264
    ;
    pto::Stride<-1, -1, -1, -1, -1> v464 = pto::Stride<-1, -1, -1, -1, -1>(v459 * v462, v462, v461, v37, v455);
    // pto: %264
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v465 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v457 + (v456 + v432 * v37 + v51 * v455), v463, v464);
    TLOAD(v453, v465);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    // pto: %coefficient_one__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v40, v42);
    // pto: %coefficient_one__ssa_v0
    ;
    uint64_t v467 = (uint64_t) v25;
    TASSIGN(v466, v467);
    pipe_barrier(PIPE_V);
    TEXPANDS(v466, v61);
    // pto: %coefficient_channel__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v468 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v40, v42);
    // pto: %coefficient_channel__ssa_v0
    ;
    uint64_t v469 = (uint64_t) v25;
    TASSIGN(v468, v469);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    TCOLEXPANDMUL(v468, v466, v451);
    // pto: %coefficient__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v470 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v40, v42);
    // pto: %coefficient__ssa_v0
    ;
    uint64_t v471 = (uint64_t) v25;
    TASSIGN(v470, v471);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    TROWEXPANDMUL(v470, v468, v453);
    // pto: %t__tmp_v15
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v416, v42);
    // pto: %t__tmp_v15
    ;
    uint64_t v473 = (uint64_t) v24;
    TASSIGN(v472, v473);
    RoundMode v474 = RoundMode::CAST_ROUND;
    SaturationMode v475 = SaturationMode::ON;
    TCVT(v472, v430, v474, v475);
    // pto: %ob_scaled__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v476 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v416, v42);
    // pto: %ob_scaled__ssa_v0
    ;
    uint64_t v477 = (uint64_t) v24;
    TASSIGN(v476, v477);
    pipe_barrier(PIPE_V);
    TMUL(v476, v472, v470);
    // pto: %t__tmp_v16
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v478 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v416, v42);
    // pto: %t__tmp_v16
    ;
    uint64_t v479 = (uint64_t) v24;
    TASSIGN(v478, v479);
    pipe_barrier(PIPE_V);
    RoundMode v480 = RoundMode::CAST_RINT;
    SaturationMode v481 = SaturationMode::ON;
    TCVT(v478, v476, v480, v481);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v482 = 0;
    // pto: %attended__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v483 = PTOAS__GLOBAL_TENSOR_DATA(v123);
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v484 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v485 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v486 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    int64_t v487 = v416 * v44;
    // pto: %attended__ssa_v0_pview
    ;
    int64_t v488 = v486 * v487;
    // pto: %attended__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v489 = pto::Shape<1, 1, 1, -1, 512>(v484, v485, v486, v416, v42);
    // pto: %attended__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v490 = pto::Stride<-1, -1, -1, -1, -1>(v485 * v488, v488, v487, v44, v37);
    // pto: %attended__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v491 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v483 + (v482 + v432 * v44 + v433 * v37), v489, v490);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    TSTORE(v491, v478);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %268
  int64_t v492 = (int64_t) ((uint64_t) v171 + (uint64_t) v65);
  // pto: %269
  int64_t v493 = v492 < v51 ? v51 : v492;
  // pto: %270
  __gm__ int32_t* v494 = PTOAS__GLOBAL_TENSOR_DATA(v169);
  // pto: %270
  const int64_t v495 = 0;
  // pto: %270
  pto::Shape<1, 1, 1, 1, 1> v496 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %270
  pto::Stride<1, 1, 1, 1, 1> v497 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %270
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v498 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v494 + (v495 + v493), v496, v497);
  pto::comm::NotifyOp v499 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v498, v180, v499);
  for (int64_t v500 = v50; v500 < v66; v500 += v37) {
    // pto: %271, %272
    ;
    int64_t v501 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v500 * (uint64_t) v41) + (uint64_t) v65);
    // pto: %273
    ;
    int64_t v502 = v501 < v51 ? v51 : v501;
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v503 = PTOAS__GLOBAL_TENSOR_DATA(v169);
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    const int64_t v504 = 0;
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v505 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v506 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v507 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v503 + (v504 + v502), v505, v506);
    pto::comm::WaitCmp v508 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v507, v180, v508);
  }
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %274, %275
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  for (int64_t v509 = v170; v509 < ((int64_t) ((uint64_t) v17 + (uint64_t) v67) / v47); v509 += v54) {
    // pto: %276
    ;
    int64_t v510 = (int64_t) ((uint64_t) v509 * (uint64_t) v47);
    // pto: %277
    ;
    int64_t v511 = (int64_t) ((uint64_t) v510 + (uint64_t) v47);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    for (int64_t v512 = v510; v512 < v511; v512 += v49) {
      // pto: %278
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      if (v512 < v17) {
        // pto: %279
        ;
        int64_t v513 = (int64_t) ((uint64_t) v512 * (uint64_t) v47);
        // pto: %post_scalar__tile
        ;
        float v514 = (v11)[v513];
        // pto: %281
        ;
        int64_t v515 = (int64_t) ((uint64_t) v512 * (uint64_t) v40);
        // pto: %comb_scalar_0__tile
        ;
        float v516 = (v12)[v515];
        // pto: %284, %comb_scalar_1__tile
        ;
        float v517 = (v12)[(int64_t) ((uint64_t) v515 + (uint64_t) v47)];
        // pto: %286, %comb_scalar_2__tile
        ;
        float v518 = (v12)[(int64_t) ((uint64_t) v515 + (uint64_t) v38)];
        // pto: %288, %comb_scalar_3__tile
        ;
        float v519 = (v12)[(int64_t) ((uint64_t) v515 + (uint64_t) v68)];
        // pto: %291, %289
        ;
        float v520 = (v11)[(int64_t) ((uint64_t) v513 + (uint64_t) v37)];
        // pto: %294, %292
        ;
        float v521 = (v12)[(int64_t) ((uint64_t) v515 + (uint64_t) v37)];
        // pto: %297, %295
        ;
        float v522 = (v12)[(int64_t) ((uint64_t) v515 + (uint64_t) v69)];
        // pto: %300, %298
        ;
        float v523 = (v12)[(int64_t) ((uint64_t) v515 + (uint64_t) v70)];
        // pto: %303, %301
        ;
        float v524 = (v12)[(int64_t) ((uint64_t) v515 + (uint64_t) v71)];
        // pto: %306, %304
        ;
        float v525 = (v11)[(int64_t) ((uint64_t) v513 + (uint64_t) v49)];
        // pto: %309, %307
        ;
        float v526 = (v12)[(int64_t) ((uint64_t) v515 + (uint64_t) v49)];
        // pto: %312, %310
        ;
        float v527 = (v12)[(int64_t) ((uint64_t) v515 + (uint64_t) v72)];
        // pto: %315, %313
        ;
        float v528 = (v12)[(int64_t) ((uint64_t) v515 + (uint64_t) v73)];
        // pto: %318, %316
        ;
        float v529 = (v12)[(int64_t) ((uint64_t) v515 + (uint64_t) v74)];
        // pto: %321, %319
        ;
        float v530 = (v11)[(int64_t) ((uint64_t) v513 + (uint64_t) v67)];
        // pto: %324, %322
        ;
        float v531 = (v12)[(int64_t) ((uint64_t) v515 + (uint64_t) v67)];
        // pto: %327, %325
        ;
        float v532 = (v12)[(int64_t) ((uint64_t) v515 + (uint64_t) v57)];
        // pto: %330, %328
        ;
        float v533 = (v12)[(int64_t) ((uint64_t) v515 + (uint64_t) v75)];
        // pto: %333, %331
        ;
        float v534 = (v12)[(int64_t) ((uint64_t) v515 + (uint64_t) v52)];
        // pto: %x_block__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v535 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %x_block__tile
        ;
        uint64_t v536 = (uint64_t) v32;
        TASSIGN(v535, v536);
        // pto: %334
        ;
        int64_t v537 = v512 < v51 ? v51 : v512;
        // pto: %x__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v538 = PTOAS__GLOBAL_TENSOR_DATA(v123);
        // pto: %x__ssa_v0_pview
        ;
        const int64_t v539 = 0;
        // pto: %x__ssa_v0_pview
        ;
        const int64_t v540 = 4096;
        // pto: %x__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v541 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %x__ssa_v0_pview
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v542 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %x__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v543 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v538 + (v539 + v537 * v540), v541, v542);
        TLOAD(v535, v543);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        // pto: %335
        ;
        int64_t v544 = (int64_t) ((uint64_t) v17 - (uint64_t) v512);
        // pto: %336
        ;
        int64_t v545 = v544 < v51 ? v51 : v544;
        // pto: %337
        ;
        int64_t v546 = v545 < v37 ? v545 : v37;
        // pto: %t__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v547 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %t__tile
        ;
        uint64_t v548 = (uint64_t) v25;
        TASSIGN(v547, v548);
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v549 = 0;
        // pto: %residual_flat__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v550 = PTOAS__GLOBAL_TENSOR_DATA(v132);
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v551 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v552 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v553 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        int64_t v554 = v546 * v46;
        // pto: %residual_flat__ssa_v0_pview
        ;
        int64_t v555 = v553 * v554;
        // pto: %residual_flat__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 4096> v556 = pto::Shape<1, 1, 1, -1, 4096>(v551, v552, v553, v546, v44);
        // pto: %residual_flat__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v557 = pto::Stride<-1, -1, -1, -1, -1>(v552 * v555, v555, v554, v46, v37);
        // pto: %residual_flat__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v558 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v550 + (v549 + v537 * v46 + v51 * v37), v556, v557);
        TLOAD(v547, v558);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        // pto: %0
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v559 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %0
        ;
        uint64_t v560 = (uint64_t) v30;
        TASSIGN(v559, v560);
        // pto: %349
        ;
        const int64_t v561 = 0;
        // pto: %349
        ;
        __gm__ bfloat16_t* v562 = PTOAS__GLOBAL_TENSOR_DATA(v132);
        // pto: %349
        ;
        const int64_t v563 = 1;
        // pto: %349
        ;
        const int64_t v564 = 1;
        // pto: %349
        ;
        const int64_t v565 = 1;
        // pto: %349
        ;
        int64_t v566 = v546 * v46;
        // pto: %349
        ;
        int64_t v567 = v565 * v566;
        // pto: %349
        ;
        pto::Shape<1, 1, 1, -1, 4096> v568 = pto::Shape<1, 1, 1, -1, 4096>(v563, v564, v565, v546, v44);
        // pto: %349
        ;
        pto::Stride<-1, -1, -1, -1, -1> v569 = pto::Stride<-1, -1, -1, -1, -1>(v564 * v567, v567, v566, v46, v37);
        // pto: %349
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v570 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v562 + (v561 + v537 * v46 + v44 * v37), v568, v569);
        TLOAD(v559, v570);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %1
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v571 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %1
        ;
        uint64_t v572 = (uint64_t) v26;
        TASSIGN(v571, v572);
        // pto: %357
        ;
        const int64_t v573 = 0;
        // pto: %357
        ;
        __gm__ bfloat16_t* v574 = PTOAS__GLOBAL_TENSOR_DATA(v132);
        // pto: %357
        ;
        const int64_t v575 = 1;
        // pto: %357
        ;
        const int64_t v576 = 1;
        // pto: %357
        ;
        const int64_t v577 = 1;
        // pto: %357
        ;
        int64_t v578 = v546 * v46;
        // pto: %357
        ;
        int64_t v579 = v577 * v578;
        // pto: %357
        ;
        pto::Shape<1, 1, 1, -1, 4096> v580 = pto::Shape<1, 1, 1, -1, 4096>(v575, v576, v577, v546, v44);
        // pto: %357
        ;
        pto::Stride<-1, -1, -1, -1, -1> v581 = pto::Stride<-1, -1, -1, -1, -1>(v576 * v579, v579, v578, v46, v37);
        // pto: %357
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v582 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v574 + (v573 + v537 * v46 + v45 * v37), v580, v581);
        TLOAD(v571, v582);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %2
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v583 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %2
        ;
        uint64_t v584 = (uint64_t) v33;
        TASSIGN(v583, v584);
        // pto: %365
        ;
        const int64_t v585 = 0;
        // pto: %365
        ;
        __gm__ bfloat16_t* v586 = PTOAS__GLOBAL_TENSOR_DATA(v132);
        // pto: %365
        ;
        const int64_t v587 = 1;
        // pto: %365
        ;
        const int64_t v588 = 1;
        // pto: %365
        ;
        const int64_t v589 = 1;
        // pto: %365
        ;
        int64_t v590 = v546 * v46;
        // pto: %365
        ;
        int64_t v591 = v589 * v590;
        // pto: %365
        ;
        pto::Shape<1, 1, 1, -1, 4096> v592 = pto::Shape<1, 1, 1, -1, 4096>(v587, v588, v589, v546, v44);
        // pto: %365
        ;
        pto::Stride<-1, -1, -1, -1, -1> v593 = pto::Stride<-1, -1, -1, -1, -1>(v588 * v591, v591, v590, v46, v37);
        // pto: %365
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v594 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v586 + (v585 + v537 * v46 + v76 * v37), v592, v593);
        TLOAD(v583, v594);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %x_f32__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v595 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %x_f32__tile
        ;
        uint64_t v596 = (uint64_t) v24;
        TASSIGN(v595, v596);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        RoundMode v597 = RoundMode::CAST_ROUND;
        SaturationMode v598 = SaturationMode::ON;
        TCVT(v595, v535, v597, v598);
        // pto: %res_0__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v599 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %res_0__tile
        ;
        uint64_t v600 = (uint64_t) v32;
        TASSIGN(v599, v600);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        RoundMode v601 = RoundMode::CAST_ROUND;
        SaturationMode v602 = SaturationMode::ON;
        TCVT(v599, v547, v601, v602);
        // pto: %res_1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v603 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %res_1__tile
        ;
        uint64_t v604 = (uint64_t) v25;
        TASSIGN(v603, v604);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v605 = RoundMode::CAST_ROUND;
        SaturationMode v606 = SaturationMode::ON;
        TCVT(v603, v559, v605, v606);
        // pto: %res_2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v607 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %res_2__tile
        ;
        uint64_t v608 = (uint64_t) v30;
        TASSIGN(v607, v608);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v609 = RoundMode::CAST_ROUND;
        SaturationMode v610 = SaturationMode::ON;
        TCVT(v607, v571, v609, v610);
        // pto: %res_3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v611 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %res_3__tile
        ;
        uint64_t v612 = (uint64_t) v26;
        TASSIGN(v611, v612);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v613 = RoundMode::CAST_ROUND;
        SaturationMode v614 = SaturationMode::ON;
        TCVT(v611, v583, v613, v614);
        // pto: %single_y__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v615 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %single_y__tile
        ;
        uint64_t v616 = (uint64_t) v33;
        TASSIGN(v615, v616);
        pipe_barrier(PIPE_V);
        TMULS(v615, v595, v514);
        // pto: %single_weighted_0__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v617 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %single_weighted_0__tile
        ;
        uint64_t v618 = (uint64_t) v34;
        TASSIGN(v617, v618);
        TMULS(v617, v599, v516);
        // pto: %single_y_v1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v619 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %single_y_v1__tile
        ;
        uint64_t v620 = (uint64_t) v33;
        TASSIGN(v619, v620);
        pipe_barrier(PIPE_V);
        TADD(v619, v615, v617);
        // pto: %single_weighted_1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v621 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %single_weighted_1__tile
        ;
        uint64_t v622 = (uint64_t) v34;
        TASSIGN(v621, v622);
        pipe_barrier(PIPE_V);
        TMULS(v621, v603, v517);
        // pto: %single_y_v2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v623 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %single_y_v2__tile
        ;
        uint64_t v624 = (uint64_t) v33;
        TASSIGN(v623, v624);
        pipe_barrier(PIPE_V);
        TADD(v623, v619, v621);
        // pto: %single_weighted_2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v625 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %single_weighted_2__tile
        ;
        uint64_t v626 = (uint64_t) v34;
        TASSIGN(v625, v626);
        pipe_barrier(PIPE_V);
        TMULS(v625, v607, v518);
        // pto: %single_y_v3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v627 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %single_y_v3__tile
        ;
        uint64_t v628 = (uint64_t) v33;
        TASSIGN(v627, v628);
        pipe_barrier(PIPE_V);
        TADD(v627, v623, v625);
        // pto: %single_weighted_3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v629 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %single_weighted_3__tile
        ;
        uint64_t v630 = (uint64_t) v34;
        TASSIGN(v629, v630);
        pipe_barrier(PIPE_V);
        TMULS(v629, v611, v519);
        // pto: %single_y_v4__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v631 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %single_y_v4__tile
        ;
        uint64_t v632 = (uint64_t) v33;
        TASSIGN(v631, v632);
        pipe_barrier(PIPE_V);
        TADD(v631, v627, v629);
        // pto: %single_result__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v633 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %single_result__tile
        ;
        uint64_t v634 = (uint64_t) v35;
        TASSIGN(v633, v634);
        pipe_barrier(PIPE_V);
        RoundMode v635 = RoundMode::CAST_RINT;
        SaturationMode v636 = SaturationMode::ON;
        TCVT(v633, v631, v635, v636);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        v633.SetValidShape(v37, v44);
        // pto: %4
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v637 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %4
        ;
        uint64_t v638 = (uint64_t) v33;
        TASSIGN(v637, v638);
        pipe_barrier(PIPE_V);
        TMULS(v637, v595, v520);
        // pto: %5
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v639 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %5
        ;
        uint64_t v640 = (uint64_t) v34;
        TASSIGN(v639, v640);
        TMULS(v639, v599, v521);
        // pto: %6
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v641 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %6
        ;
        uint64_t v642 = (uint64_t) v33;
        TASSIGN(v641, v642);
        pipe_barrier(PIPE_V);
        TADD(v641, v637, v639);
        // pto: %7
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v643 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %7
        ;
        uint64_t v644 = (uint64_t) v34;
        TASSIGN(v643, v644);
        pipe_barrier(PIPE_V);
        TMULS(v643, v603, v522);
        // pto: %8
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v645 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %8
        ;
        uint64_t v646 = (uint64_t) v33;
        TASSIGN(v645, v646);
        pipe_barrier(PIPE_V);
        TADD(v645, v641, v643);
        // pto: %9
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v647 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %9
        ;
        uint64_t v648 = (uint64_t) v34;
        TASSIGN(v647, v648);
        pipe_barrier(PIPE_V);
        TMULS(v647, v607, v523);
        // pto: %10
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v649 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %10
        ;
        uint64_t v650 = (uint64_t) v33;
        TASSIGN(v649, v650);
        pipe_barrier(PIPE_V);
        TADD(v649, v645, v647);
        // pto: %11
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v651 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %11
        ;
        uint64_t v652 = (uint64_t) v34;
        TASSIGN(v651, v652);
        pipe_barrier(PIPE_V);
        TMULS(v651, v611, v524);
        // pto: %12
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v653 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %12
        ;
        uint64_t v654 = (uint64_t) v33;
        TASSIGN(v653, v654);
        pipe_barrier(PIPE_V);
        TADD(v653, v649, v651);
        // pto: %13
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v655 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %13
        ;
        uint64_t v656 = (uint64_t) v36;
        TASSIGN(v655, v656);
        pipe_barrier(PIPE_V);
        RoundMode v657 = RoundMode::CAST_RINT;
        SaturationMode v658 = SaturationMode::ON;
        TCVT(v655, v653, v657, v658);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        v655.SetValidShape(v37, v44);
        // pto: %15
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v659 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %15
        ;
        uint64_t v660 = (uint64_t) v33;
        TASSIGN(v659, v660);
        pipe_barrier(PIPE_V);
        TMULS(v659, v595, v525);
        // pto: %16
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v661 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %16
        ;
        uint64_t v662 = (uint64_t) v34;
        TASSIGN(v661, v662);
        TMULS(v661, v599, v526);
        // pto: %17
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v663 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %17
        ;
        uint64_t v664 = (uint64_t) v33;
        TASSIGN(v663, v664);
        pipe_barrier(PIPE_V);
        TADD(v663, v659, v661);
        // pto: %18
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v665 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %18
        ;
        uint64_t v666 = (uint64_t) v34;
        TASSIGN(v665, v666);
        pipe_barrier(PIPE_V);
        TMULS(v665, v603, v527);
        // pto: %19
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v667 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %19
        ;
        uint64_t v668 = (uint64_t) v33;
        TASSIGN(v667, v668);
        pipe_barrier(PIPE_V);
        TADD(v667, v663, v665);
        // pto: %20
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v669 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %20
        ;
        uint64_t v670 = (uint64_t) v34;
        TASSIGN(v669, v670);
        pipe_barrier(PIPE_V);
        TMULS(v669, v607, v528);
        // pto: %21
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v671 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %21
        ;
        uint64_t v672 = (uint64_t) v33;
        TASSIGN(v671, v672);
        pipe_barrier(PIPE_V);
        TADD(v671, v667, v669);
        // pto: %22
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v673 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %22
        ;
        uint64_t v674 = (uint64_t) v34;
        TASSIGN(v673, v674);
        pipe_barrier(PIPE_V);
        TMULS(v673, v611, v529);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v675 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %23
        ;
        uint64_t v676 = (uint64_t) v33;
        TASSIGN(v675, v676);
        pipe_barrier(PIPE_V);
        TADD(v675, v671, v673);
        // pto: %24
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v677 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %24
        ;
        uint64_t v678 = (uint64_t) v33;
        TASSIGN(v677, v678);
        pipe_barrier(PIPE_V);
        RoundMode v679 = RoundMode::CAST_RINT;
        SaturationMode v680 = SaturationMode::ON;
        TCVT(v677, v675, v679, v680);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        v677.SetValidShape(v37, v44);
        // pto: %26
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v681 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %26
        ;
        uint64_t v682 = (uint64_t) v24;
        TASSIGN(v681, v682);
        TMULS(v681, v595, v530);
        // pto: %27
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v683 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %27
        ;
        uint64_t v684 = (uint64_t) v32;
        TASSIGN(v683, v684);
        TMULS(v683, v599, v531);
        // pto: %28
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v685 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %28
        ;
        uint64_t v686 = (uint64_t) v24;
        TASSIGN(v685, v686);
        pipe_barrier(PIPE_V);
        TADD(v685, v681, v683);
        // pto: %29
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v687 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %29
        ;
        uint64_t v688 = (uint64_t) v32;
        TASSIGN(v687, v688);
        pipe_barrier(PIPE_V);
        TMULS(v687, v603, v532);
        // pto: %30
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v689 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %30
        ;
        uint64_t v690 = (uint64_t) v24;
        TASSIGN(v689, v690);
        pipe_barrier(PIPE_V);
        TADD(v689, v685, v687);
        // pto: %31
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v691 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %31
        ;
        uint64_t v692 = (uint64_t) v32;
        TASSIGN(v691, v692);
        pipe_barrier(PIPE_V);
        TMULS(v691, v607, v533);
        // pto: %32
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v693 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %32
        ;
        uint64_t v694 = (uint64_t) v24;
        TASSIGN(v693, v694);
        pipe_barrier(PIPE_V);
        TADD(v693, v689, v691);
        // pto: %33
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v695 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546, v44);
        // pto: %33
        ;
        uint64_t v696 = (uint64_t) v32;
        TASSIGN(v695, v696);
        pipe_barrier(PIPE_V);
        TMULS(v695, v611, v534);
        // pto: %34
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v697 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %34
        ;
        uint64_t v698 = (uint64_t) v24;
        TASSIGN(v697, v698);
        pipe_barrier(PIPE_V);
        TADD(v697, v693, v695);
        // pto: %35
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v699 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %35
        ;
        uint64_t v700 = (uint64_t) v24;
        TASSIGN(v699, v700);
        pipe_barrier(PIPE_V);
        RoundMode v701 = RoundMode::CAST_RINT;
        SaturationMode v702 = SaturationMode::ON;
        TCVT(v699, v697, v701, v702);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        v699.SetValidShape(v37, v44);
        // pto: %y_flat__iter_v3_pview
        ;
        __gm__ bfloat16_t* v703 = PTOAS__GLOBAL_TENSOR_DATA(v141);
        // pto: %y_flat__iter_v3_pview
        ;
        const int64_t v704 = 0;
        // pto: %y_flat__iter_v3_pview
        ;
        const int64_t v705 = 16384;
        // pto: %y_flat__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v706 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__iter_v3_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v707 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v708 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v703 + (v704 + v537 * v705), v706, v707);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        TSTORE(v708, v633);
        // pto: %y_flat__tile_pview
        ;
        __gm__ bfloat16_t* v709 = PTOAS__GLOBAL_TENSOR_DATA(v141);
        // pto: %y_flat__tile_pview
        ;
        const int64_t v710 = 4096;
        // pto: %y_flat__tile_pview
        ;
        const int64_t v711 = 16384;
        // pto: %y_flat__tile_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v712 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__tile_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v713 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__tile_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v714 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v709 + (v710 + v537 * v711), v712, v713);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        TSTORE(v714, v655);
        // pto: %431
        ;
        __gm__ bfloat16_t* v715 = PTOAS__GLOBAL_TENSOR_DATA(v141);
        // pto: %431
        ;
        const int64_t v716 = 8192;
        // pto: %431
        ;
        const int64_t v717 = 16384;
        // pto: %431
        ;
        pto::Shape<1, 1, 1, 1, 4096> v718 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %431
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v719 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %431
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v720 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v715 + (v716 + v537 * v717), v718, v719);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        TSTORE(v720, v677);
        // pto: %434
        ;
        __gm__ bfloat16_t* v721 = PTOAS__GLOBAL_TENSOR_DATA(v141);
        // pto: %434
        ;
        const int64_t v722 = 12288;
        // pto: %434
        ;
        const int64_t v723 = 16384;
        // pto: %434
        ;
        pto::Shape<1, 1, 1, 1, 4096> v724 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %434
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v725 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %434
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v726 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v721 + (v722 + v537 * v723), v724, v725);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        TSTORE(v726, v699);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %435
      ;
      int64_t v727 = (int64_t) ((uint64_t) v512 + (uint64_t) v37);
      // pto: %436
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      if (v727 < v17) {
        // pto: %439
        ;
        int64_t v728 = (int64_t) ((uint64_t) v727 * (uint64_t) v47);
        // pto: %437
        ;
        float v729 = (v11)[v728];
        // pto: %443
        ;
        int64_t v730 = (int64_t) ((uint64_t) v727 * (uint64_t) v40);
        // pto: %441
        ;
        float v731 = (v12)[v730];
        // pto: %448, %445
        ;
        float v732 = (v12)[(int64_t) ((uint64_t) v730 + (uint64_t) v47)];
        // pto: %452, %449
        ;
        float v733 = (v12)[(int64_t) ((uint64_t) v730 + (uint64_t) v38)];
        // pto: %456, %453
        ;
        float v734 = (v12)[(int64_t) ((uint64_t) v730 + (uint64_t) v68)];
        // pto: %460, %457
        ;
        float v735 = (v11)[(int64_t) ((uint64_t) v728 + (uint64_t) v37)];
        // pto: %464, %461
        ;
        float v736 = (v12)[(int64_t) ((uint64_t) v730 + (uint64_t) v37)];
        // pto: %468, %465
        ;
        float v737 = (v12)[(int64_t) ((uint64_t) v730 + (uint64_t) v69)];
        // pto: %472, %469
        ;
        float v738 = (v12)[(int64_t) ((uint64_t) v730 + (uint64_t) v70)];
        // pto: %476, %473
        ;
        float v739 = (v12)[(int64_t) ((uint64_t) v730 + (uint64_t) v71)];
        // pto: %480, %477
        ;
        float v740 = (v11)[(int64_t) ((uint64_t) v728 + (uint64_t) v49)];
        // pto: %484, %481
        ;
        float v741 = (v12)[(int64_t) ((uint64_t) v730 + (uint64_t) v49)];
        // pto: %488, %485
        ;
        float v742 = (v12)[(int64_t) ((uint64_t) v730 + (uint64_t) v72)];
        // pto: %492, %489
        ;
        float v743 = (v12)[(int64_t) ((uint64_t) v730 + (uint64_t) v73)];
        // pto: %496, %493
        ;
        float v744 = (v12)[(int64_t) ((uint64_t) v730 + (uint64_t) v74)];
        // pto: %500, %497
        ;
        float v745 = (v11)[(int64_t) ((uint64_t) v728 + (uint64_t) v67)];
        // pto: %504, %501
        ;
        float v746 = (v12)[(int64_t) ((uint64_t) v730 + (uint64_t) v67)];
        // pto: %508, %505
        ;
        float v747 = (v12)[(int64_t) ((uint64_t) v730 + (uint64_t) v57)];
        // pto: %512, %509
        ;
        float v748 = (v12)[(int64_t) ((uint64_t) v730 + (uint64_t) v75)];
        // pto: %516, %513
        ;
        float v749 = (v12)[(int64_t) ((uint64_t) v730 + (uint64_t) v52)];
        // pto: %37
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v750 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %37
        ;
        uint64_t v751 = (uint64_t) v32;
        TASSIGN(v750, v751);
        // pto: %518
        ;
        int64_t v752 = v727 < v51 ? v51 : v727;
        // pto: %519
        ;
        __gm__ bfloat16_t* v753 = PTOAS__GLOBAL_TENSOR_DATA(v123);
        // pto: %519
        ;
        const int64_t v754 = 0;
        // pto: %519
        ;
        const int64_t v755 = 4096;
        // pto: %519
        ;
        pto::Shape<1, 1, 1, 1, 4096> v756 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %519
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v757 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %519
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v758 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v753 + (v754 + v752 * v755), v756, v757);
        TLOAD(v750, v758);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %520, %521
        ;
        int64_t v759 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v17 - (uint64_t) v512) + (uint64_t) v77);
        // pto: %522
        ;
        int64_t v760 = v759 < v51 ? v51 : v759;
        // pto: %523
        ;
        int64_t v761 = v760 < v37 ? v760 : v37;
        // pto: %38
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v762 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %38
        ;
        uint64_t v763 = (uint64_t) v25;
        TASSIGN(v762, v763);
        // pto: %530
        ;
        const int64_t v764 = 0;
        // pto: %530
        ;
        __gm__ bfloat16_t* v765 = PTOAS__GLOBAL_TENSOR_DATA(v132);
        // pto: %530
        ;
        const int64_t v766 = 1;
        // pto: %530
        ;
        const int64_t v767 = 1;
        // pto: %530
        ;
        const int64_t v768 = 1;
        // pto: %530
        ;
        int64_t v769 = v761 * v46;
        // pto: %530
        ;
        int64_t v770 = v768 * v769;
        // pto: %530
        ;
        pto::Shape<1, 1, 1, -1, 4096> v771 = pto::Shape<1, 1, 1, -1, 4096>(v766, v767, v768, v761, v44);
        // pto: %530
        ;
        pto::Stride<-1, -1, -1, -1, -1> v772 = pto::Stride<-1, -1, -1, -1, -1>(v767 * v770, v770, v769, v46, v37);
        // pto: %530
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v773 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v765 + (v764 + v752 * v46 + v51 * v37), v771, v772);
        TLOAD(v762, v773);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %39
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v774 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %39
        ;
        uint64_t v775 = (uint64_t) v30;
        TASSIGN(v774, v775);
        // pto: %541
        ;
        const int64_t v776 = 0;
        // pto: %541
        ;
        __gm__ bfloat16_t* v777 = PTOAS__GLOBAL_TENSOR_DATA(v132);
        // pto: %541
        ;
        const int64_t v778 = 1;
        // pto: %541
        ;
        const int64_t v779 = 1;
        // pto: %541
        ;
        const int64_t v780 = 1;
        // pto: %541
        ;
        int64_t v781 = v761 * v46;
        // pto: %541
        ;
        int64_t v782 = v780 * v781;
        // pto: %541
        ;
        pto::Shape<1, 1, 1, -1, 4096> v783 = pto::Shape<1, 1, 1, -1, 4096>(v778, v779, v780, v761, v44);
        // pto: %541
        ;
        pto::Stride<-1, -1, -1, -1, -1> v784 = pto::Stride<-1, -1, -1, -1, -1>(v779 * v782, v782, v781, v46, v37);
        // pto: %541
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v785 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v777 + (v776 + v752 * v46 + v44 * v37), v783, v784);
        TLOAD(v774, v785);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %40
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v786 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %40
        ;
        uint64_t v787 = (uint64_t) v26;
        TASSIGN(v786, v787);
        // pto: %552
        ;
        const int64_t v788 = 0;
        // pto: %552
        ;
        __gm__ bfloat16_t* v789 = PTOAS__GLOBAL_TENSOR_DATA(v132);
        // pto: %552
        ;
        const int64_t v790 = 1;
        // pto: %552
        ;
        const int64_t v791 = 1;
        // pto: %552
        ;
        const int64_t v792 = 1;
        // pto: %552
        ;
        int64_t v793 = v761 * v46;
        // pto: %552
        ;
        int64_t v794 = v792 * v793;
        // pto: %552
        ;
        pto::Shape<1, 1, 1, -1, 4096> v795 = pto::Shape<1, 1, 1, -1, 4096>(v790, v791, v792, v761, v44);
        // pto: %552
        ;
        pto::Stride<-1, -1, -1, -1, -1> v796 = pto::Stride<-1, -1, -1, -1, -1>(v791 * v794, v794, v793, v46, v37);
        // pto: %552
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v797 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v789 + (v788 + v752 * v46 + v45 * v37), v795, v796);
        TLOAD(v786, v797);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %41
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v798 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %41
        ;
        uint64_t v799 = (uint64_t) v33;
        TASSIGN(v798, v799);
        // pto: %563
        ;
        const int64_t v800 = 0;
        // pto: %563
        ;
        __gm__ bfloat16_t* v801 = PTOAS__GLOBAL_TENSOR_DATA(v132);
        // pto: %563
        ;
        const int64_t v802 = 1;
        // pto: %563
        ;
        const int64_t v803 = 1;
        // pto: %563
        ;
        const int64_t v804 = 1;
        // pto: %563
        ;
        int64_t v805 = v761 * v46;
        // pto: %563
        ;
        int64_t v806 = v804 * v805;
        // pto: %563
        ;
        pto::Shape<1, 1, 1, -1, 4096> v807 = pto::Shape<1, 1, 1, -1, 4096>(v802, v803, v804, v761, v44);
        // pto: %563
        ;
        pto::Stride<-1, -1, -1, -1, -1> v808 = pto::Stride<-1, -1, -1, -1, -1>(v803 * v806, v806, v805, v46, v37);
        // pto: %563
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v809 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v801 + (v800 + v752 * v46 + v76 * v37), v807, v808);
        TLOAD(v798, v809);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        // pto: %42
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v810 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %42
        ;
        uint64_t v811 = (uint64_t) v24;
        TASSIGN(v810, v811);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v812 = RoundMode::CAST_ROUND;
        SaturationMode v813 = SaturationMode::ON;
        TCVT(v810, v750, v812, v813);
        // pto: %43
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v814 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %43
        ;
        uint64_t v815 = (uint64_t) v32;
        TASSIGN(v814, v815);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v816 = RoundMode::CAST_ROUND;
        SaturationMode v817 = SaturationMode::ON;
        TCVT(v814, v762, v816, v817);
        // pto: %44
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v818 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %44
        ;
        uint64_t v819 = (uint64_t) v25;
        TASSIGN(v818, v819);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v820 = RoundMode::CAST_ROUND;
        SaturationMode v821 = SaturationMode::ON;
        TCVT(v818, v774, v820, v821);
        // pto: %45
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v822 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %45
        ;
        uint64_t v823 = (uint64_t) v30;
        TASSIGN(v822, v823);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        RoundMode v824 = RoundMode::CAST_ROUND;
        SaturationMode v825 = SaturationMode::ON;
        TCVT(v822, v786, v824, v825);
        // pto: %46
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v826 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %46
        ;
        uint64_t v827 = (uint64_t) v26;
        TASSIGN(v826, v827);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        RoundMode v828 = RoundMode::CAST_ROUND;
        SaturationMode v829 = SaturationMode::ON;
        TCVT(v826, v798, v828, v829);
        // pto: %47
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v830 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %47
        ;
        uint64_t v831 = (uint64_t) v33;
        TASSIGN(v830, v831);
        pipe_barrier(PIPE_V);
        TMULS(v830, v810, v729);
        // pto: %48
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v832 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %48
        ;
        uint64_t v833 = (uint64_t) v34;
        TASSIGN(v832, v833);
        TMULS(v832, v814, v731);
        // pto: %49
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v834 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %49
        ;
        uint64_t v835 = (uint64_t) v33;
        TASSIGN(v834, v835);
        pipe_barrier(PIPE_V);
        TADD(v834, v830, v832);
        // pto: %50
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v836 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %50
        ;
        uint64_t v837 = (uint64_t) v34;
        TASSIGN(v836, v837);
        pipe_barrier(PIPE_V);
        TMULS(v836, v818, v732);
        // pto: %51
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v838 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %51
        ;
        uint64_t v839 = (uint64_t) v33;
        TASSIGN(v838, v839);
        pipe_barrier(PIPE_V);
        TADD(v838, v834, v836);
        // pto: %52
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v840 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %52
        ;
        uint64_t v841 = (uint64_t) v34;
        TASSIGN(v840, v841);
        pipe_barrier(PIPE_V);
        TMULS(v840, v822, v733);
        // pto: %53
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v842 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %53
        ;
        uint64_t v843 = (uint64_t) v33;
        TASSIGN(v842, v843);
        pipe_barrier(PIPE_V);
        TADD(v842, v838, v840);
        // pto: %54
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v844 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %54
        ;
        uint64_t v845 = (uint64_t) v34;
        TASSIGN(v844, v845);
        pipe_barrier(PIPE_V);
        TMULS(v844, v826, v734);
        // pto: %55
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v846 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %55
        ;
        uint64_t v847 = (uint64_t) v33;
        TASSIGN(v846, v847);
        pipe_barrier(PIPE_V);
        TADD(v846, v842, v844);
        // pto: %56
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v848 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %56
        ;
        uint64_t v849 = (uint64_t) v35;
        TASSIGN(v848, v849);
        pipe_barrier(PIPE_V);
        RoundMode v850 = RoundMode::CAST_RINT;
        SaturationMode v851 = SaturationMode::ON;
        TCVT(v848, v846, v850, v851);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v848.SetValidShape(v37, v44);
        // pto: %58
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v852 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %58
        ;
        uint64_t v853 = (uint64_t) v33;
        TASSIGN(v852, v853);
        pipe_barrier(PIPE_V);
        TMULS(v852, v810, v735);
        // pto: %59
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v854 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %59
        ;
        uint64_t v855 = (uint64_t) v34;
        TASSIGN(v854, v855);
        TMULS(v854, v814, v736);
        // pto: %60
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v856 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %60
        ;
        uint64_t v857 = (uint64_t) v33;
        TASSIGN(v856, v857);
        pipe_barrier(PIPE_V);
        TADD(v856, v852, v854);
        // pto: %61
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v858 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %61
        ;
        uint64_t v859 = (uint64_t) v34;
        TASSIGN(v858, v859);
        pipe_barrier(PIPE_V);
        TMULS(v858, v818, v737);
        // pto: %62
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v860 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %62
        ;
        uint64_t v861 = (uint64_t) v33;
        TASSIGN(v860, v861);
        pipe_barrier(PIPE_V);
        TADD(v860, v856, v858);
        // pto: %63
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v862 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %63
        ;
        uint64_t v863 = (uint64_t) v34;
        TASSIGN(v862, v863);
        pipe_barrier(PIPE_V);
        TMULS(v862, v822, v738);
        // pto: %64
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v864 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %64
        ;
        uint64_t v865 = (uint64_t) v33;
        TASSIGN(v864, v865);
        pipe_barrier(PIPE_V);
        TADD(v864, v860, v862);
        // pto: %65
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v866 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %65
        ;
        uint64_t v867 = (uint64_t) v34;
        TASSIGN(v866, v867);
        pipe_barrier(PIPE_V);
        TMULS(v866, v826, v739);
        // pto: %66
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v868 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %66
        ;
        uint64_t v869 = (uint64_t) v33;
        TASSIGN(v868, v869);
        pipe_barrier(PIPE_V);
        TADD(v868, v864, v866);
        // pto: %67
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v870 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %67
        ;
        uint64_t v871 = (uint64_t) v36;
        TASSIGN(v870, v871);
        pipe_barrier(PIPE_V);
        RoundMode v872 = RoundMode::CAST_RINT;
        SaturationMode v873 = SaturationMode::ON;
        TCVT(v870, v868, v872, v873);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        v870.SetValidShape(v37, v44);
        // pto: %69
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v874 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %69
        ;
        uint64_t v875 = (uint64_t) v33;
        TASSIGN(v874, v875);
        pipe_barrier(PIPE_V);
        TMULS(v874, v810, v740);
        // pto: %70
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v876 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %70
        ;
        uint64_t v877 = (uint64_t) v34;
        TASSIGN(v876, v877);
        TMULS(v876, v814, v741);
        // pto: %71
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v878 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %71
        ;
        uint64_t v879 = (uint64_t) v33;
        TASSIGN(v878, v879);
        pipe_barrier(PIPE_V);
        TADD(v878, v874, v876);
        // pto: %72
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v880 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %72
        ;
        uint64_t v881 = (uint64_t) v34;
        TASSIGN(v880, v881);
        pipe_barrier(PIPE_V);
        TMULS(v880, v818, v742);
        // pto: %73
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v882 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %73
        ;
        uint64_t v883 = (uint64_t) v33;
        TASSIGN(v882, v883);
        pipe_barrier(PIPE_V);
        TADD(v882, v878, v880);
        // pto: %74
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v884 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %74
        ;
        uint64_t v885 = (uint64_t) v34;
        TASSIGN(v884, v885);
        pipe_barrier(PIPE_V);
        TMULS(v884, v822, v743);
        // pto: %75
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v886 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %75
        ;
        uint64_t v887 = (uint64_t) v33;
        TASSIGN(v886, v887);
        pipe_barrier(PIPE_V);
        TADD(v886, v882, v884);
        // pto: %76
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v888 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %76
        ;
        uint64_t v889 = (uint64_t) v34;
        TASSIGN(v888, v889);
        pipe_barrier(PIPE_V);
        TMULS(v888, v826, v744);
        // pto: %77
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v890 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %77
        ;
        uint64_t v891 = (uint64_t) v33;
        TASSIGN(v890, v891);
        pipe_barrier(PIPE_V);
        TADD(v890, v886, v888);
        // pto: %78
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v892 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %78
        ;
        uint64_t v893 = (uint64_t) v33;
        TASSIGN(v892, v893);
        pipe_barrier(PIPE_V);
        RoundMode v894 = RoundMode::CAST_RINT;
        SaturationMode v895 = SaturationMode::ON;
        TCVT(v892, v890, v894, v895);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        v892.SetValidShape(v37, v44);
        // pto: %80
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v896 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %80
        ;
        uint64_t v897 = (uint64_t) v24;
        TASSIGN(v896, v897);
        TMULS(v896, v810, v745);
        // pto: %81
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v898 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %81
        ;
        uint64_t v899 = (uint64_t) v32;
        TASSIGN(v898, v899);
        TMULS(v898, v814, v746);
        // pto: %82
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v900 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %82
        ;
        uint64_t v901 = (uint64_t) v24;
        TASSIGN(v900, v901);
        pipe_barrier(PIPE_V);
        TADD(v900, v896, v898);
        // pto: %83
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v902 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %83
        ;
        uint64_t v903 = (uint64_t) v32;
        TASSIGN(v902, v903);
        pipe_barrier(PIPE_V);
        TMULS(v902, v818, v747);
        // pto: %84
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v904 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %84
        ;
        uint64_t v905 = (uint64_t) v24;
        TASSIGN(v904, v905);
        pipe_barrier(PIPE_V);
        TADD(v904, v900, v902);
        // pto: %85
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v906 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %85
        ;
        uint64_t v907 = (uint64_t) v32;
        TASSIGN(v906, v907);
        pipe_barrier(PIPE_V);
        TMULS(v906, v822, v748);
        // pto: %86
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v908 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %86
        ;
        uint64_t v909 = (uint64_t) v24;
        TASSIGN(v908, v909);
        pipe_barrier(PIPE_V);
        TADD(v908, v904, v906);
        // pto: %87
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v910 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v761, v44);
        // pto: %87
        ;
        uint64_t v911 = (uint64_t) v32;
        TASSIGN(v910, v911);
        pipe_barrier(PIPE_V);
        TMULS(v910, v826, v749);
        // pto: %88
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v912 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %88
        ;
        uint64_t v913 = (uint64_t) v24;
        TASSIGN(v912, v913);
        pipe_barrier(PIPE_V);
        TADD(v912, v908, v910);
        // pto: %89
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v914 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %89
        ;
        uint64_t v915 = (uint64_t) v24;
        TASSIGN(v914, v915);
        pipe_barrier(PIPE_V);
        RoundMode v916 = RoundMode::CAST_RINT;
        SaturationMode v917 = SaturationMode::ON;
        TCVT(v914, v912, v916, v917);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        v914.SetValidShape(v37, v44);
        // pto: %y_flat__phi_v9_pview
        ;
        __gm__ bfloat16_t* v918 = PTOAS__GLOBAL_TENSOR_DATA(v141);
        // pto: %y_flat__phi_v9_pview
        ;
        const int64_t v919 = 0;
        // pto: %y_flat__phi_v9_pview
        ;
        const int64_t v920 = 16384;
        // pto: %y_flat__phi_v9_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v921 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__phi_v9_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v922 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__phi_v9_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v923 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v918 + (v919 + v752 * v920), v921, v922);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v923, v848);
        // pto: %650
        ;
        __gm__ bfloat16_t* v924 = PTOAS__GLOBAL_TENSOR_DATA(v141);
        // pto: %650
        ;
        const int64_t v925 = 4096;
        // pto: %650
        ;
        const int64_t v926 = 16384;
        // pto: %650
        ;
        pto::Shape<1, 1, 1, 1, 4096> v927 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %650
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v928 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %650
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v929 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v924 + (v925 + v752 * v926), v927, v928);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v929, v870);
        // pto: %654
        ;
        __gm__ bfloat16_t* v930 = PTOAS__GLOBAL_TENSOR_DATA(v141);
        // pto: %654
        ;
        const int64_t v931 = 8192;
        // pto: %654
        ;
        const int64_t v932 = 16384;
        // pto: %654
        ;
        pto::Shape<1, 1, 1, 1, 4096> v933 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %654
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v934 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %654
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v935 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v930 + (v931 + v752 * v932), v933, v934);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v935, v892);
        // pto: %658
        ;
        __gm__ bfloat16_t* v936 = PTOAS__GLOBAL_TENSOR_DATA(v141);
        // pto: %658
        ;
        const int64_t v937 = 12288;
        // pto: %658
        ;
        const int64_t v938 = 16384;
        // pto: %658
        ;
        pto::Shape<1, 1, 1, 1, 4096> v939 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %658
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v940 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %658
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v941 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v936 + (v937 + v752 * v938), v939, v940);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        TSTORE(v941, v914);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    // pto: %659, %660, %661
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    if ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v510 - (uint64_t) v511) + (uint64_t) v47) == v37) {
      // pto: %662
      ;
      if (v511 < v17) {
        // pto: %91
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v942 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %91
        ;
        uint64_t v943 = (uint64_t) v32;
        TASSIGN(v942, v943);
        // pto: %663
        ;
        int64_t v944 = v511 < v51 ? v51 : v511;
        // pto: %664
        ;
        __gm__ bfloat16_t* v945 = PTOAS__GLOBAL_TENSOR_DATA(v123);
        // pto: %664
        ;
        const int64_t v946 = 0;
        // pto: %664
        ;
        const int64_t v947 = 4096;
        // pto: %664
        ;
        pto::Shape<1, 1, 1, 1, 4096> v948 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %664
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v949 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %664
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v950 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v945 + (v946 + v944 * v947), v948, v949);
        TLOAD(v942, v950);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %92
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v951 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %92
        ;
        uint64_t v952 = (uint64_t) v24;
        TASSIGN(v951, v952);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v953 = RoundMode::CAST_ROUND;
        SaturationMode v954 = SaturationMode::ON;
        TCVT(v951, v942, v953, v954);
        // pto: %665
        ;
        int64_t v955 = (int64_t) ((uint64_t) v17 - (uint64_t) v511);
        // pto: %666
        ;
        int64_t v956 = v955 < v51 ? v51 : v955;
        // pto: %667
        ;
        int64_t v957 = v956 < v37 ? v956 : v37;
        // pto: %93
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v958 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %93
        ;
        uint64_t v959 = (uint64_t) v25;
        TASSIGN(v958, v959);
        // pto: %672
        ;
        const int64_t v960 = 0;
        // pto: %672
        ;
        __gm__ bfloat16_t* v961 = PTOAS__GLOBAL_TENSOR_DATA(v132);
        // pto: %672
        ;
        const int64_t v962 = 1;
        // pto: %672
        ;
        const int64_t v963 = 1;
        // pto: %672
        ;
        const int64_t v964 = 1;
        // pto: %672
        ;
        int64_t v965 = v957 * v46;
        // pto: %672
        ;
        int64_t v966 = v964 * v965;
        // pto: %672
        ;
        pto::Shape<1, 1, 1, -1, 4096> v967 = pto::Shape<1, 1, 1, -1, 4096>(v962, v963, v964, v957, v44);
        // pto: %672
        ;
        pto::Stride<-1, -1, -1, -1, -1> v968 = pto::Stride<-1, -1, -1, -1, -1>(v963 * v966, v966, v965, v46, v37);
        // pto: %672
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v969 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v961 + (v960 + v944 * v46 + v51 * v37), v967, v968);
        TLOAD(v958, v969);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %94
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v970 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %94
        ;
        uint64_t v971 = (uint64_t) v32;
        TASSIGN(v970, v971);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v972 = RoundMode::CAST_ROUND;
        SaturationMode v973 = SaturationMode::ON;
        TCVT(v970, v958, v972, v973);
        // pto: %95
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v974 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %95
        ;
        uint64_t v975 = (uint64_t) v30;
        TASSIGN(v974, v975);
        // pto: %683
        ;
        const int64_t v976 = 0;
        // pto: %683
        ;
        __gm__ bfloat16_t* v977 = PTOAS__GLOBAL_TENSOR_DATA(v132);
        // pto: %683
        ;
        const int64_t v978 = 1;
        // pto: %683
        ;
        const int64_t v979 = 1;
        // pto: %683
        ;
        const int64_t v980 = 1;
        // pto: %683
        ;
        int64_t v981 = v957 * v46;
        // pto: %683
        ;
        int64_t v982 = v980 * v981;
        // pto: %683
        ;
        pto::Shape<1, 1, 1, -1, 4096> v983 = pto::Shape<1, 1, 1, -1, 4096>(v978, v979, v980, v957, v44);
        // pto: %683
        ;
        pto::Stride<-1, -1, -1, -1, -1> v984 = pto::Stride<-1, -1, -1, -1, -1>(v979 * v982, v982, v981, v46, v37);
        // pto: %683
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v985 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v977 + (v976 + v944 * v46 + v44 * v37), v983, v984);
        TLOAD(v974, v985);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %96
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v986 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %96
        ;
        uint64_t v987 = (uint64_t) v25;
        TASSIGN(v986, v987);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v988 = RoundMode::CAST_ROUND;
        SaturationMode v989 = SaturationMode::ON;
        TCVT(v986, v974, v988, v989);
        // pto: %97
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v990 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %97
        ;
        uint64_t v991 = (uint64_t) v26;
        TASSIGN(v990, v991);
        // pto: %694
        ;
        const int64_t v992 = 0;
        // pto: %694
        ;
        __gm__ bfloat16_t* v993 = PTOAS__GLOBAL_TENSOR_DATA(v132);
        // pto: %694
        ;
        const int64_t v994 = 1;
        // pto: %694
        ;
        const int64_t v995 = 1;
        // pto: %694
        ;
        const int64_t v996 = 1;
        // pto: %694
        ;
        int64_t v997 = v957 * v46;
        // pto: %694
        ;
        int64_t v998 = v996 * v997;
        // pto: %694
        ;
        pto::Shape<1, 1, 1, -1, 4096> v999 = pto::Shape<1, 1, 1, -1, 4096>(v994, v995, v996, v957, v44);
        // pto: %694
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1000 = pto::Stride<-1, -1, -1, -1, -1>(v995 * v998, v998, v997, v46, v37);
        // pto: %694
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1001 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v993 + (v992 + v944 * v46 + v45 * v37), v999, v1000);
        TLOAD(v990, v1001);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %98
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1002 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %98
        ;
        uint64_t v1003 = (uint64_t) v30;
        TASSIGN(v1002, v1003);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v1004 = RoundMode::CAST_ROUND;
        SaturationMode v1005 = SaturationMode::ON;
        TCVT(v1002, v990, v1004, v1005);
        // pto: %99
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1006 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %99
        ;
        uint64_t v1007 = (uint64_t) v33;
        TASSIGN(v1006, v1007);
        // pto: %705
        ;
        const int64_t v1008 = 0;
        // pto: %705
        ;
        __gm__ bfloat16_t* v1009 = PTOAS__GLOBAL_TENSOR_DATA(v132);
        // pto: %705
        ;
        const int64_t v1010 = 1;
        // pto: %705
        ;
        const int64_t v1011 = 1;
        // pto: %705
        ;
        const int64_t v1012 = 1;
        // pto: %705
        ;
        int64_t v1013 = v957 * v46;
        // pto: %705
        ;
        int64_t v1014 = v1012 * v1013;
        // pto: %705
        ;
        pto::Shape<1, 1, 1, -1, 4096> v1015 = pto::Shape<1, 1, 1, -1, 4096>(v1010, v1011, v1012, v957, v44);
        // pto: %705
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1016 = pto::Stride<-1, -1, -1, -1, -1>(v1011 * v1014, v1014, v1013, v46, v37);
        // pto: %705
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1017 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1009 + (v1008 + v944 * v46 + v76 * v37), v1015, v1016);
        TLOAD(v1006, v1017);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %100
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1018 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %100
        ;
        uint64_t v1019 = (uint64_t) v26;
        TASSIGN(v1018, v1019);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v1020 = RoundMode::CAST_ROUND;
        SaturationMode v1021 = SaturationMode::ON;
        TCVT(v1018, v1006, v1020, v1021);
        // pto: %710
        ;
        int64_t v1022 = (int64_t) ((uint64_t) v511 * (uint64_t) v47);
        // pto: %709
        ;
        float v1023 = (v11)[v1022];
        // pto: %101
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1024 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %101
        ;
        uint64_t v1025 = (uint64_t) v33;
        TASSIGN(v1024, v1025);
        pipe_barrier(PIPE_V);
        TMULS(v1024, v951, v1023);
        // pto: %713
        ;
        int64_t v1026 = (int64_t) ((uint64_t) v511 * (uint64_t) v40);
        // pto: %712
        ;
        float v1027 = (v12)[v1026];
        // pto: %102
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1028 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %102
        ;
        uint64_t v1029 = (uint64_t) v34;
        TASSIGN(v1028, v1029);
        TMULS(v1028, v970, v1027);
        // pto: %103
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1030 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %103
        ;
        uint64_t v1031 = (uint64_t) v33;
        TASSIGN(v1030, v1031);
        pipe_barrier(PIPE_V);
        TADD(v1030, v1024, v1028);
        // pto: %720, %718
        ;
        float v1032 = (v12)[(int64_t) ((uint64_t) v1026 + (uint64_t) v47)];
        // pto: %104
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1033 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %104
        ;
        uint64_t v1034 = (uint64_t) v34;
        TASSIGN(v1033, v1034);
        pipe_barrier(PIPE_V);
        TMULS(v1033, v986, v1032);
        // pto: %105
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1035 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %105
        ;
        uint64_t v1036 = (uint64_t) v33;
        TASSIGN(v1035, v1036);
        pipe_barrier(PIPE_V);
        TADD(v1035, v1030, v1033);
        // pto: %726, %724
        ;
        float v1037 = (v12)[(int64_t) ((uint64_t) v1026 + (uint64_t) v38)];
        // pto: %106
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1038 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %106
        ;
        uint64_t v1039 = (uint64_t) v34;
        TASSIGN(v1038, v1039);
        pipe_barrier(PIPE_V);
        TMULS(v1038, v1002, v1037);
        // pto: %107
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1040 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %107
        ;
        uint64_t v1041 = (uint64_t) v33;
        TASSIGN(v1040, v1041);
        pipe_barrier(PIPE_V);
        TADD(v1040, v1035, v1038);
        // pto: %732, %730
        ;
        float v1042 = (v12)[(int64_t) ((uint64_t) v1026 + (uint64_t) v68)];
        // pto: %108
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1043 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %108
        ;
        uint64_t v1044 = (uint64_t) v34;
        TASSIGN(v1043, v1044);
        pipe_barrier(PIPE_V);
        TMULS(v1043, v1018, v1042);
        // pto: %109
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1045 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %109
        ;
        uint64_t v1046 = (uint64_t) v33;
        TASSIGN(v1045, v1046);
        pipe_barrier(PIPE_V);
        TADD(v1045, v1040, v1043);
        // pto: %110
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1047 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %110
        ;
        uint64_t v1048 = (uint64_t) v33;
        TASSIGN(v1047, v1048);
        pipe_barrier(PIPE_V);
        RoundMode v1049 = RoundMode::CAST_RINT;
        SaturationMode v1050 = SaturationMode::ON;
        TCVT(v1047, v1045, v1049, v1050);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1047.SetValidShape(v37, v44);
        // pto: %y_flat__rv_v4_main_pview
        ;
        __gm__ bfloat16_t* v1051 = PTOAS__GLOBAL_TENSOR_DATA(v141);
        // pto: %y_flat__rv_v4_main_pview
        ;
        const int64_t v1052 = 0;
        // pto: %y_flat__rv_v4_main_pview
        ;
        const int64_t v1053 = 16384;
        // pto: %y_flat__rv_v4_main_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1054 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__rv_v4_main_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1055 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__rv_v4_main_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1056 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1051 + (v1052 + v944 * v1053), v1054, v1055);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1056, v1047);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
        // pto: %740, %738
        ;
        float v1057 = (v11)[(int64_t) ((uint64_t) v1022 + (uint64_t) v37)];
        // pto: %112
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1058 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %112
        ;
        uint64_t v1059 = (uint64_t) v33;
        TASSIGN(v1058, v1059);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
        TMULS(v1058, v951, v1057);
        // pto: %743, %741
        ;
        float v1060 = (v12)[(int64_t) ((uint64_t) v1026 + (uint64_t) v37)];
        // pto: %113
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1061 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %113
        ;
        uint64_t v1062 = (uint64_t) v34;
        TASSIGN(v1061, v1062);
        TMULS(v1061, v970, v1060);
        // pto: %114
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1063 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %114
        ;
        uint64_t v1064 = (uint64_t) v33;
        TASSIGN(v1063, v1064);
        pipe_barrier(PIPE_V);
        TADD(v1063, v1058, v1061);
        // pto: %749, %747
        ;
        float v1065 = (v12)[(int64_t) ((uint64_t) v1026 + (uint64_t) v69)];
        // pto: %115
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1066 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %115
        ;
        uint64_t v1067 = (uint64_t) v34;
        TASSIGN(v1066, v1067);
        pipe_barrier(PIPE_V);
        TMULS(v1066, v986, v1065);
        // pto: %116
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1068 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %116
        ;
        uint64_t v1069 = (uint64_t) v33;
        TASSIGN(v1068, v1069);
        pipe_barrier(PIPE_V);
        TADD(v1068, v1063, v1066);
        // pto: %755, %753
        ;
        float v1070 = (v12)[(int64_t) ((uint64_t) v1026 + (uint64_t) v70)];
        // pto: %117
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1071 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %117
        ;
        uint64_t v1072 = (uint64_t) v34;
        TASSIGN(v1071, v1072);
        pipe_barrier(PIPE_V);
        TMULS(v1071, v1002, v1070);
        // pto: %118
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1073 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %118
        ;
        uint64_t v1074 = (uint64_t) v33;
        TASSIGN(v1073, v1074);
        pipe_barrier(PIPE_V);
        TADD(v1073, v1068, v1071);
        // pto: %761, %759
        ;
        float v1075 = (v12)[(int64_t) ((uint64_t) v1026 + (uint64_t) v71)];
        // pto: %119
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1076 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %119
        ;
        uint64_t v1077 = (uint64_t) v34;
        TASSIGN(v1076, v1077);
        pipe_barrier(PIPE_V);
        TMULS(v1076, v1018, v1075);
        // pto: %120
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1078 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %120
        ;
        uint64_t v1079 = (uint64_t) v33;
        TASSIGN(v1078, v1079);
        pipe_barrier(PIPE_V);
        TADD(v1078, v1073, v1076);
        // pto: %121
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1080 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %121
        ;
        uint64_t v1081 = (uint64_t) v33;
        TASSIGN(v1080, v1081);
        pipe_barrier(PIPE_V);
        RoundMode v1082 = RoundMode::CAST_RINT;
        SaturationMode v1083 = SaturationMode::ON;
        TCVT(v1080, v1078, v1082, v1083);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1080.SetValidShape(v37, v44);
        // pto: %767
        ;
        __gm__ bfloat16_t* v1084 = PTOAS__GLOBAL_TENSOR_DATA(v141);
        // pto: %767
        ;
        const int64_t v1085 = 4096;
        // pto: %767
        ;
        const int64_t v1086 = 16384;
        // pto: %767
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1087 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %767
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1088 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %767
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1089 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1084 + (v1085 + v944 * v1086), v1087, v1088);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1089, v1080);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        // pto: %770, %768
        ;
        float v1090 = (v11)[(int64_t) ((uint64_t) v1022 + (uint64_t) v49)];
        // pto: %123
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1091 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %123
        ;
        uint64_t v1092 = (uint64_t) v33;
        TASSIGN(v1091, v1092);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        TMULS(v1091, v951, v1090);
        // pto: %773, %771
        ;
        float v1093 = (v12)[(int64_t) ((uint64_t) v1026 + (uint64_t) v49)];
        // pto: %124
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1094 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %124
        ;
        uint64_t v1095 = (uint64_t) v34;
        TASSIGN(v1094, v1095);
        TMULS(v1094, v970, v1093);
        // pto: %125
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1096 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %125
        ;
        uint64_t v1097 = (uint64_t) v33;
        TASSIGN(v1096, v1097);
        pipe_barrier(PIPE_V);
        TADD(v1096, v1091, v1094);
        // pto: %779, %777
        ;
        float v1098 = (v12)[(int64_t) ((uint64_t) v1026 + (uint64_t) v72)];
        // pto: %126
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1099 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %126
        ;
        uint64_t v1100 = (uint64_t) v34;
        TASSIGN(v1099, v1100);
        pipe_barrier(PIPE_V);
        TMULS(v1099, v986, v1098);
        // pto: %127
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1101 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %127
        ;
        uint64_t v1102 = (uint64_t) v33;
        TASSIGN(v1101, v1102);
        pipe_barrier(PIPE_V);
        TADD(v1101, v1096, v1099);
        // pto: %785, %783
        ;
        float v1103 = (v12)[(int64_t) ((uint64_t) v1026 + (uint64_t) v73)];
        // pto: %128
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1104 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %128
        ;
        uint64_t v1105 = (uint64_t) v34;
        TASSIGN(v1104, v1105);
        pipe_barrier(PIPE_V);
        TMULS(v1104, v1002, v1103);
        // pto: %129
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1106 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %129
        ;
        uint64_t v1107 = (uint64_t) v33;
        TASSIGN(v1106, v1107);
        pipe_barrier(PIPE_V);
        TADD(v1106, v1101, v1104);
        // pto: %791, %789
        ;
        float v1108 = (v12)[(int64_t) ((uint64_t) v1026 + (uint64_t) v74)];
        // pto: %130
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1109 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %130
        ;
        uint64_t v1110 = (uint64_t) v34;
        TASSIGN(v1109, v1110);
        pipe_barrier(PIPE_V);
        TMULS(v1109, v1018, v1108);
        // pto: %131
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1111 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %131
        ;
        uint64_t v1112 = (uint64_t) v33;
        TASSIGN(v1111, v1112);
        pipe_barrier(PIPE_V);
        TADD(v1111, v1106, v1109);
        // pto: %132
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1113 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %132
        ;
        uint64_t v1114 = (uint64_t) v33;
        TASSIGN(v1113, v1114);
        pipe_barrier(PIPE_V);
        RoundMode v1115 = RoundMode::CAST_RINT;
        SaturationMode v1116 = SaturationMode::ON;
        TCVT(v1113, v1111, v1115, v1116);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1113.SetValidShape(v37, v44);
        // pto: %797
        ;
        __gm__ bfloat16_t* v1117 = PTOAS__GLOBAL_TENSOR_DATA(v141);
        // pto: %797
        ;
        const int64_t v1118 = 8192;
        // pto: %797
        ;
        const int64_t v1119 = 16384;
        // pto: %797
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1120 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %797
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1121 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %797
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1122 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1117 + (v1118 + v944 * v1119), v1120, v1121);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1122, v1113);
        // pto: %800, %798
        ;
        float v1123 = (v11)[(int64_t) ((uint64_t) v1022 + (uint64_t) v67)];
        // pto: %134
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1124 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %134
        ;
        uint64_t v1125 = (uint64_t) v24;
        TASSIGN(v1124, v1125);
        TMULS(v1124, v951, v1123);
        // pto: %803, %801
        ;
        float v1126 = (v12)[(int64_t) ((uint64_t) v1026 + (uint64_t) v67)];
        // pto: %135
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1127 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %135
        ;
        uint64_t v1128 = (uint64_t) v32;
        TASSIGN(v1127, v1128);
        TMULS(v1127, v970, v1126);
        // pto: %136
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1129 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %136
        ;
        uint64_t v1130 = (uint64_t) v24;
        TASSIGN(v1129, v1130);
        pipe_barrier(PIPE_V);
        TADD(v1129, v1124, v1127);
        // pto: %809, %807
        ;
        float v1131 = (v12)[(int64_t) ((uint64_t) v1026 + (uint64_t) v57)];
        // pto: %137
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1132 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %137
        ;
        uint64_t v1133 = (uint64_t) v32;
        TASSIGN(v1132, v1133);
        pipe_barrier(PIPE_V);
        TMULS(v1132, v986, v1131);
        // pto: %138
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1134 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %138
        ;
        uint64_t v1135 = (uint64_t) v24;
        TASSIGN(v1134, v1135);
        pipe_barrier(PIPE_V);
        TADD(v1134, v1129, v1132);
        // pto: %815, %813
        ;
        float v1136 = (v12)[(int64_t) ((uint64_t) v1026 + (uint64_t) v75)];
        // pto: %139
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1137 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %139
        ;
        uint64_t v1138 = (uint64_t) v32;
        TASSIGN(v1137, v1138);
        pipe_barrier(PIPE_V);
        TMULS(v1137, v1002, v1136);
        // pto: %140
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1139 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %140
        ;
        uint64_t v1140 = (uint64_t) v24;
        TASSIGN(v1139, v1140);
        pipe_barrier(PIPE_V);
        TADD(v1139, v1134, v1137);
        // pto: %821, %819
        ;
        float v1141 = (v12)[(int64_t) ((uint64_t) v1026 + (uint64_t) v52)];
        // pto: %141
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1142 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v957, v44);
        // pto: %141
        ;
        uint64_t v1143 = (uint64_t) v32;
        TASSIGN(v1142, v1143);
        pipe_barrier(PIPE_V);
        TMULS(v1142, v1018, v1141);
        // pto: %142
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1144 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %142
        ;
        uint64_t v1145 = (uint64_t) v24;
        TASSIGN(v1144, v1145);
        pipe_barrier(PIPE_V);
        TADD(v1144, v1139, v1142);
        // pto: %143
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1146 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %143
        ;
        uint64_t v1147 = (uint64_t) v24;
        TASSIGN(v1146, v1147);
        pipe_barrier(PIPE_V);
        RoundMode v1148 = RoundMode::CAST_RINT;
        SaturationMode v1149 = SaturationMode::ON;
        TCVT(v1146, v1144, v1148, v1149);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1146.SetValidShape(v37, v44);
        // pto: %827
        ;
        __gm__ bfloat16_t* v1150 = PTOAS__GLOBAL_TENSOR_DATA(v141);
        // pto: %827
        ;
        const int64_t v1151 = 12288;
        // pto: %827
        ;
        const int64_t v1152 = 16384;
        // pto: %827
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1153 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %827
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1154 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %827
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1155 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1150 + (v1151 + v944 * v1152), v1153, v1154);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v1155, v1146);
      };
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  pipe_barrier(PIPE_ALL);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}