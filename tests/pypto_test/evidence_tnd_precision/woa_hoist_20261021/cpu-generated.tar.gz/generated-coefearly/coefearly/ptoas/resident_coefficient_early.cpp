#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void cube(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int32_t v22 = 1;
  // pto: %c0_i64
  const int64_t v23 = 0;
  // pto: %c65536_i64
  const int64_t v24 = 65536;
  // pto: %c32768_i64
  const int64_t v25 = 32768;
  // pto: %c131072_i64
  const int64_t v26 = 131072;
  // pto: %c196608_i64
  const int64_t v27 = 196608;
  // pto: %c32768_index
  const int64_t v28 = 32768;
  // pto: %c1_index
  const int64_t v29 = 1;
  // pto: %c8_index
  const int64_t v30 = 8;
  const int64_t v31 = 64;
  // pto: %c256_index
  const int64_t v32 = 256;
  // pto: %c16_index
  const int64_t v33 = 16;
  // pto: %c4194304_index
  const int64_t v34 = 4194304;
  // pto: %c65536_index
  const int64_t v35 = 65536;
  const int64_t v36 = 128;
  // pto: %c512_index
  const int64_t v37 = 512;
  // pto: %c32_index
  const int64_t v38 = 32;
  // pto: %c33554432_index
  const int64_t v39 = 33554432;
  // pto: %c262144_index
  const int64_t v40 = 262144;
  // pto: %c4096_index
  const int64_t v41 = 4096;
  // pto: %c8192_index
  const int64_t v42 = 8192;
  // pto: %c4_index
  const int64_t v43 = 4;
  // pto: %c55296_index
  const int64_t v44 = 55296;
  // pto: %c0_index
  const int64_t v45 = 0;
  // pto: %c15_index
  const int64_t v46 = 15;
  // pto: %c192_index
  const int64_t v47 = 192;
  // pto: %c24_index
  const int64_t v48 = 24;
  // pto: %c7_index
  const int64_t v49 = 7;
  // pto: %c2_index
  const int64_t v50 = 2;
  // pto: %c3_index
  const int64_t v51 = 3;
  // pto: %c5_index
  const int64_t v52 = 5;
  // pto: %c6_index
  const int64_t v53 = 6;
  // pto: %c240_index
  const int64_t v54 = 240;
  // pto: %c1024_index
  const int64_t v55 = 1024;
  // pto: %c241_index
  const int64_t v56 = 241;
  // pto: %c9216_index
  const int64_t v57 = 9216;
  // pto: %c72_index
  const int64_t v58 = 72;
  // pto: %c27648_index
  const int64_t v59 = 27648;
  // pto: %c63_index
  const int64_t v60 = 63;
  // pto: %c36864_index
  const int64_t v61 = 36864;
  // pto: %heads__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v65 = (int64_t) v17;
  // pto: %heads__ssa_v0_view
  int64_t v66 = v65 * v28;
  // pto: %heads__ssa_v0_view
  int64_t v67 = v64 * v66;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v68 = pto::Shape<1, 1, 1, -1, -1>(v62, v63, v64, v65, v28);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v69 = pto::Stride<-1, -1, -1, -1, -1>(v63 * v67, v67, v66, v28, v29);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v70 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v68, v69);
  // pto: %wo_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v71 = pto::Shape<-1, -1, -1, -1, -1>(v30, v31, v32, v33, v33);
  // pto: %wo_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v34, v35, v32, v33, v29);
  // pto: %wo_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v73 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v71, v72);
  // pto: %wo_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v74 = pto::Shape<-1, -1, -1, -1, -1>(v29, v36, v37, v33, v38);
  // pto: %wo_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v75 = pto::Stride<-1, -1, -1, -1, -1>(v39, v40, v37, v38, v29);
  // pto: %wo_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v76 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v3, v74, v75);
  // pto: %quantized__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v79 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v80 = (int64_t) v17;
  // pto: %quantized__ssa_v0_view
  int64_t v81 = v80 * v42;
  // pto: %quantized__ssa_v0_view
  int64_t v82 = v79 * v81;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v83 = pto::Shape<1, 1, 1, -1, -1>(v77, v78, v79, v80, v42);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v84 = pto::Stride<-1, -1, -1, -1, -1>(v78 * v82, v82, v81, v42, v29);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v85 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v83, v84);
  // pto: %accum__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v88 = 1;
  // pto: %accum__ssa_v0_view
  int64_t v89 = (int64_t) v18;
  // pto: %accum__ssa_v0_view
  int64_t v90 = v89 * v42;
  // pto: %accum__ssa_v0_view
  int64_t v91 = v88 * v90;
  // pto: %accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v92 = pto::Shape<1, 1, 1, -1, -1>(v86, v87, v88, v89, v42);
  // pto: %accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v93 = pto::Stride<-1, -1, -1, -1, -1>(v87 * v91, v91, v90, v42, v29);
  // pto: %accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v94 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v92, v93);
  // pto: %integer_accum__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v97 = 1;
  // pto: %integer_accum__ssa_v0_view
  int64_t v98 = (int64_t) v19;
  // pto: %integer_accum__ssa_v0_view
  int64_t v99 = v98 * v41;
  // pto: %integer_accum__ssa_v0_view
  int64_t v100 = v97 * v99;
  // pto: %integer_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v101 = pto::Shape<1, 1, 1, -1, -1>(v95, v96, v97, v98, v41);
  // pto: %integer_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v102 = pto::Stride<-1, -1, -1, -1, -1>(v96 * v100, v100, v99, v41, v29);
  // pto: %integer_accum__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v103 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v101, v102);
  // pto: %signals__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v105 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v106 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v107 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v108 = v44 * v29;
  // pto: %signals__ssa_v0_view
  int64_t v109 = v107 * v108;
  // pto: %signals__ssa_v0_view
  int64_t v110 = v106 * v109;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v111 = pto::Shape<1, 1, 1, 1, -1>(v104, v105, v106, v107, v44);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v112 = pto::Stride<-1, -1, -1, -1, -1>(v105 * v110, v110, v109, v108, v29);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v113 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v111, v112);
  // pto: %seed_fast_acc__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v114 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %seed_fast_acc__phi_v7
  uint64_t v115 = (uint64_t) v23;
  TASSIGN(v114, v115);
  // pto: %223
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v116 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %223
  uint64_t v117 = (uint64_t) v23;
  TASSIGN(v116, v117);
  // pto: %261
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v118 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %261
  uint64_t v119 = (uint64_t) v23;
  TASSIGN(v118, v119);
  // pto: %seed_narrow_acc__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
  // pto: %seed_narrow_acc__phi_v7
  uint64_t v121 = (uint64_t) v23;
  TASSIGN(v120, v121);
  // pto: %v4_wide_acc__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v122 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %v4_wide_acc__phi_v7
  uint64_t v123 = (uint64_t) v23;
  TASSIGN(v122, v123);
  // pto: %v4_narrow_acc__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
  // pto: %v4_narrow_acc__phi_v7
  uint64_t v125 = (uint64_t) v23;
  TASSIGN(v124, v125);
  // pto: %worker__ssa_v0
  int64_t v126 = (int64_t) v20;
  // pto: %63
  int64_t v127 = (int64_t) ((uint64_t) v126 * (uint64_t) v36);
  // pto: %64
  int64_t v128 = v127 < v45 ? v45 : v127;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v129 = PTOAS__GLOBAL_TENSOR_DATA(v113);
  // pto: %signals__ssa_v0_pview
  const int64_t v130 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v131 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v132 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v133 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v129 + (v130 + v128), v131, v132);
  __gm__ int32_t* v134 = PTOAS__GLOBAL_TENSOR_DATA(v133);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v134);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
  // pto: %t__tile
  int32_t v135 = (v16)[v127];
  // pto: %66
  int32_t v136 = (int32_t) ((uint32_t) v135 + (uint32_t) v22);
  pipe_barrier(PIPE_ALL);
  pto::comm::NotifyOp v137 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v133, v136, v137);
  // pto: %68, %69
  int64_t v138 = (int64_t) ((uint64_t) v17 + (uint64_t) v46) / v33;
  // pto: %70
  if (v17 >= v47) {
    for (int64_t v139 = v126; v139 < v31; v139 += v48) {
      // pto: %71
      ;
      int64_t v140 = v139 / v30;
      // pto: %72
      ;
      int64_t v141 = v139 % v30;
      // pto: %73, %74, %75
      ;
      int64_t v142 = v141 < v45 ? (int64_t) ((uint64_t) v141 + (uint64_t) v30) : v141;
      // pto: %76
      ;
      int64_t v143 = (int64_t) ((uint64_t) v142 * (uint64_t) v36);
      // pto: %77, %78
      ;
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v144 = v45; v144 < ((int64_t) ((uint64_t) v138 + (uint64_t) v49) / v30); v144 += v29) {
        // pto: %79
        ;
        int64_t v145 = (int64_t) ((uint64_t) v144 * (uint64_t) v30);
        // pto: %flat_offset, %81, %82, %80
        ;
        int32_t v146 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v144 * (uint64_t) v31) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
        // pto: %83
        ;
        int64_t v147 = (int64_t) v146;
        // pto: %84
        ;
        int64_t v148 = v147 < v45 ? v45 : v147;
        // pto: %85
        ;
        int64_t v149 = (int64_t) ((uint64_t) v145 + (uint64_t) v29);
        // pto: %86
        ;
        // pto: %seed_same_start__phi_v3
        ;
        int64_t v150;
        if (v149 < v138) {
          // pto: %89, %90, %91, %92, %87
          ;
          int32_t v151 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v149 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %93
          ;
          int64_t v152 = (int64_t) v151;
          // pto: %94
          ;
          int64_t v153 = v152 < v45 ? v45 : v152;
          // pto: %95, %seed_same_start__phi_v2
          ;
          v150 = v153 != v148 ? v45 : v29;
        } else {
          v150 = v29;
        };
        // pto: %96
        ;
        int64_t v154 = (int64_t) ((uint64_t) v145 + (uint64_t) v50);
        // pto: %97
        ;
        // pto: %seed_same_start__phi_v6
        ;
        int64_t v155;
        if (v154 < v138) {
          // pto: %100, %101, %102, %103, %98
          ;
          int32_t v156 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v154 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %104
          ;
          int64_t v157 = (int64_t) v156;
          // pto: %105
          ;
          int64_t v158 = v157 < v45 ? v45 : v157;
          // pto: %106, %seed_same_start__phi_v5
          ;
          int64_t v159 = v158 != v148 ? v45 : v150;
          v155 = v159;
        } else {
          v155 = v150;
        };
        // pto: %107
        ;
        int64_t v160 = (int64_t) ((uint64_t) v145 + (uint64_t) v51);
        // pto: %108
        ;
        // pto: %seed_same_start__phi_v9
        ;
        int64_t v161;
        if (v160 < v138) {
          // pto: %111, %112, %113, %114, %109
          ;
          int32_t v162 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v160 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %115
          ;
          int64_t v163 = (int64_t) v162;
          // pto: %116
          ;
          int64_t v164 = v163 < v45 ? v45 : v163;
          // pto: %117, %seed_same_start__phi_v8
          ;
          int64_t v165 = v164 != v148 ? v45 : v155;
          v161 = v165;
        } else {
          v161 = v155;
        };
        // pto: %118
        ;
        int64_t v166 = (int64_t) ((uint64_t) v145 + (uint64_t) v43);
        // pto: %119
        ;
        // pto: %seed_same_start__phi_v12
        ;
        int64_t v167;
        if (v166 < v138) {
          // pto: %122, %123, %124, %125, %120
          ;
          int32_t v168 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v166 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %126
          ;
          int64_t v169 = (int64_t) v168;
          // pto: %127
          ;
          int64_t v170 = v169 < v45 ? v45 : v169;
          // pto: %128, %seed_same_start__phi_v11
          ;
          int64_t v171 = v170 != v148 ? v45 : v161;
          v167 = v171;
        } else {
          v167 = v161;
        };
        // pto: %129
        ;
        int64_t v172 = (int64_t) ((uint64_t) v145 + (uint64_t) v52);
        // pto: %130
        ;
        // pto: %seed_same_start__phi_v15
        ;
        int64_t v173;
        if (v172 < v138) {
          // pto: %133, %134, %135, %136, %131
          ;
          int32_t v174 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v172 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %137
          ;
          int64_t v175 = (int64_t) v174;
          // pto: %138
          ;
          int64_t v176 = v175 < v45 ? v45 : v175;
          // pto: %139, %seed_same_start__phi_v14
          ;
          int64_t v177 = v176 != v148 ? v45 : v167;
          v173 = v177;
        } else {
          v173 = v167;
        };
        // pto: %140
        ;
        int64_t v178 = (int64_t) ((uint64_t) v145 + (uint64_t) v53);
        // pto: %141
        ;
        // pto: %seed_same_start__phi_v18
        ;
        int64_t v179;
        if (v178 < v138) {
          // pto: %144, %145, %146, %147, %142
          ;
          int32_t v180 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v178 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %148
          ;
          int64_t v181 = (int64_t) v180;
          // pto: %149
          ;
          int64_t v182 = v181 < v45 ? v45 : v181;
          // pto: %150, %seed_same_start__phi_v17
          ;
          int64_t v183 = v182 != v148 ? v45 : v173;
          v179 = v183;
        } else {
          v179 = v173;
        };
        // pto: %151
        ;
        int64_t v184 = (int64_t) ((uint64_t) v145 + (uint64_t) v49);
        // pto: %152
        ;
        // pto: %seed_same_start__phi_v21
        ;
        int64_t v185;
        if (v184 < v138) {
          // pto: %155, %156, %157, %158, %153
          ;
          int32_t v186 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v184 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %159
          ;
          int64_t v187 = (int64_t) v186;
          // pto: %160
          ;
          int64_t v188 = v187 < v45 ? v45 : v187;
          // pto: %161, %seed_same_start__phi_v20
          ;
          int64_t v189 = v188 != v148 ? v45 : v179;
          v185 = v189;
        } else {
          v185 = v179;
        };
        // pto: %162, %seed_same_start__phi_v25
        ;
        int64_t v190 = v148 > v54 ? v45 : v185;
        // pto: %163
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        if (v190 == v29) {
          int64_t v191 = (int64_t) ((uint64_t) v144 * (uint64_t) v36);
          // pto: %165
          ;
          int64_t v192 = (int64_t) ((uint64_t) v17 - (uint64_t) v191);
          // pto: %166
          ;
          int64_t v193 = v192 < v36 ? v192 : v36;
          // pto: %167
          ;
          int64_t v194 = (int64_t) ((uint64_t) v148 * (uint64_t) v33);
          // pto: %seed_fast_seed_x__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v195 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v32);
          // pto: %seed_fast_seed_x__tile
          ;
          uint64_t v196 = (uint64_t) v23;
          TASSIGN(v195, v196);
          // pto: %168
          ;
          int64_t v197 = v191 < v45 ? v45 : v191;
          // pto: %169
          ;
          int64_t v198 = (int64_t) ((uint64_t) v140 * (uint64_t) v41);
          // pto: %170
          ;
          int64_t v199 = (int64_t) ((uint64_t) v198 + (uint64_t) v194);
          // pto: %171
          ;
          int64_t v200 = v199 < v45 ? v45 : v199;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v201 = 0;
          // pto: %heads__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v202 = PTOAS__GLOBAL_TENSOR_DATA(v70);
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v203 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v204 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v205 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          int64_t v206 = v193 * v28;
          // pto: %heads__ssa_v0_pview
          ;
          int64_t v207 = v205 * v206;
          // pto: %heads__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, -1, 256> v208 = pto::Shape<1, 1, 1, -1, 256>(v203, v204, v205, v193, v32);
          // pto: %heads__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v209 = pto::Stride<-1, -1, -1, -1, -1>(v204 * v207, v207, v206, v28, v29);
          // pto: %heads__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v210 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v202 + (v201 + v197 * v28 + v200 * v29), v208, v209);
          TLOAD(v195, v210);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %seed_fast_seed_w__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
          // pto: %seed_fast_seed_w__tile
          ;
          uint64_t v212 = (uint64_t) v24;
          TASSIGN(v211, v212);
          // pto: %172
          ;
          int64_t v213 = v140 < v45 ? v45 : v140;
          // pto: %173
          ;
          int64_t v214 = v143 / v33;
          // pto: %174
          ;
          int64_t v215 = v214 < v45 ? v45 : v214;
          // pto: %175
          ;
          int64_t v216 = v194 / v33;
          // pto: %176
          ;
          int64_t v217 = v216 < v45 ? v45 : v216;
          // pto: %wo_a__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v218 = PTOAS__GLOBAL_TENSOR_DATA(v73);
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v219 = 0;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v220 = 4194304;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v221 = 65536;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v222 = 256;
          // pto: %wo_a__ssa_v0_pview
          ;
          pto::Shape<1, 8, 16, 16, 16> v223 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %wo_a__ssa_v0_pview
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v224 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %wo_a__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v225 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v218 + ((v219 + v213 * v220) + v215 * v221 + v217 * v222), v223, v224);
          TLOAD(v211, v225);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %seed_fast_acc__tile_l0_init_storage
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v226 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
          // pto: %seed_fast_acc__tile_l0_init_storage
          ;
          uint64_t v227 = (uint64_t) v23;
          TASSIGN(v226, v227);
          v226.SetValidShape(v193, v36);
          // pto: %seed_fast_acc__tile_l0_a
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v228 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
          // pto: %seed_fast_acc__tile_l0_a
          ;
          uint64_t v229 = (uint64_t) v23;
          TASSIGN(v228, v229);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          uint16_t v230 = static_cast<uint16_t>(v45);
          uint16_t v231 = static_cast<uint16_t>(v45);
          TEXTRACT(v228, v195, v230, v231);
          // pto: %seed_fast_acc__tile_l0_b
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
          // pto: %seed_fast_acc__tile_l0_b
          ;
          uint64_t v233 = (uint64_t) v23;
          TASSIGN(v232, v233);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v234 = static_cast<uint16_t>(v45);
          uint16_t v235 = static_cast<uint16_t>(v45);
          TEXTRACT(v232, v211, v234, v235);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          // pto: %0
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v236 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
          // pto: %0
          ;
          uint64_t v237 = (uint64_t) v25;
          TASSIGN(v236, v237);
          uint16_t v238 = static_cast<uint16_t>(v45);
          uint16_t v239 = static_cast<uint16_t>(v36);
          TEXTRACT(v236, v195, v238, v239);
          // pto: %1
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
          // pto: %1
          ;
          uint64_t v241 = (uint64_t) v25;
          TASSIGN(v240, v241);
          uint16_t v242 = static_cast<uint16_t>(v36);
          uint16_t v243 = static_cast<uint16_t>(v45);
          TEXTRACT(v240, v211, v242, v243);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          TMATMUL(v226, v228, v232);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          TMATMUL_ACC(v226, v226, v236, v240);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
          for (int64_t v244 = v29; v244 < v46; v244 += v50) {
            // pto: %177
            ;
            int64_t v245 = (int64_t) ((uint64_t) v244 * (uint64_t) v33);
            // pto: %178, %179
            ;
            int64_t v246 = (int64_t) ((uint64_t) v148 + (uint64_t) v245) % v32;
            // pto: %180, %181, %182
            ;
            int64_t v247 = v246 < v45 ? (int64_t) ((uint64_t) v246 + (uint64_t) v32) : v246;
            // pto: %185, %184, %186
            ;
            int64_t v248 = (int64_t) ((uint64_t) v148 + (uint64_t) ((int64_t) (uint64_t) v245 + (uint64_t) v33)) % v32;
            // pto: %187, %188, %189
            ;
            int64_t v249 = v248 < v45 ? (int64_t) ((uint64_t) v248 + (uint64_t) v32) : v248;
            // pto: %190
            ;
            // pto: %191
            ;
            int64_t v250 = v193 < v36 ? v193 : v36;
            v114.SetValidShape(v250, v36);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            if (v247 <= v54) {
              // pto: %192
              ;
              int64_t v251 = (int64_t) ((uint64_t) v247 * (uint64_t) v33);
              // pto: %seed_fast_packet_x__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v252 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v32);
              // pto: %seed_fast_packet_x__tile
              ;
              uint64_t v253 = (uint64_t) v23;
              TASSIGN(v252, v253);
              // pto: %195
              ;
              int64_t v254 = (int64_t) ((uint64_t) v198 + (uint64_t) v251);
              // pto: %196
              ;
              int64_t v255 = v254 < v45 ? v45 : v254;
              // pto: %197
              ;
              const int64_t v256 = 0;
              // pto: %197
              ;
              __gm__ bfloat16_t* v257 = PTOAS__GLOBAL_TENSOR_DATA(v70);
              // pto: %197
              ;
              const int64_t v258 = 1;
              // pto: %197
              ;
              const int64_t v259 = 1;
              // pto: %197
              ;
              const int64_t v260 = 1;
              // pto: %197
              ;
              int64_t v261 = v193 * v28;
              // pto: %197
              ;
              int64_t v262 = v260 * v261;
              // pto: %197
              ;
              pto::Shape<1, 1, 1, -1, 256> v263 = pto::Shape<1, 1, 1, -1, 256>(v258, v259, v260, v193, v32);
              // pto: %197
              ;
              pto::Stride<-1, -1, -1, -1, -1> v264 = pto::Stride<-1, -1, -1, -1, -1>(v259 * v262, v262, v261, v28, v29);
              // pto: %197
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v265 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v257 + (v256 + v197 * v28 + v255 * v29), v263, v264);
              TLOAD(v252, v265);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
              // pto: %seed_fast_packet_w__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
              // pto: %seed_fast_packet_w__tile
              ;
              uint64_t v267 = (uint64_t) v24;
              TASSIGN(v266, v267);
              // pto: %201
              ;
              int64_t v268 = v251 / v33;
              // pto: %202
              ;
              int64_t v269 = v268 < v45 ? v45 : v268;
              // pto: %203
              ;
              __gm__ bfloat16_t* v270 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %203
              ;
              const int64_t v271 = 0;
              // pto: %203
              ;
              const int64_t v272 = 4194304;
              // pto: %203
              ;
              const int64_t v273 = 65536;
              // pto: %203
              ;
              const int64_t v274 = 256;
              // pto: %203
              ;
              pto::Shape<1, 8, 16, 16, 16> v275 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %203
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v276 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %203
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v277 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v270 + ((v271 + v213 * v272) + v215 * v273 + v269 * v274), v275, v276);
              TLOAD(v266, v277);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
              // pto: %seed_fast_acc__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v278 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
              // pto: %seed_fast_acc__iter_v1_l0_a
              ;
              uint64_t v279 = (uint64_t) v23;
              TASSIGN(v278, v279);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
              uint16_t v280 = static_cast<uint16_t>(v45);
              uint16_t v281 = static_cast<uint16_t>(v45);
              TEXTRACT(v278, v252, v280, v281);
              // pto: %seed_fast_acc__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v282 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %seed_fast_acc__iter_v1_l0_b
              ;
              uint64_t v283 = (uint64_t) v23;
              TASSIGN(v282, v283);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
              uint16_t v284 = static_cast<uint16_t>(v45);
              uint16_t v285 = static_cast<uint16_t>(v45);
              TEXTRACT(v282, v266, v284, v285);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
              // pto: %3
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v286 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
              // pto: %3
              ;
              uint64_t v287 = (uint64_t) v25;
              TASSIGN(v286, v287);
              uint16_t v288 = static_cast<uint16_t>(v45);
              uint16_t v289 = static_cast<uint16_t>(v36);
              TEXTRACT(v286, v252, v288, v289);
              // pto: %4
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %4
              ;
              uint64_t v291 = (uint64_t) v25;
              TASSIGN(v290, v291);
              uint16_t v292 = static_cast<uint16_t>(v36);
              uint16_t v293 = static_cast<uint16_t>(v45);
              TEXTRACT(v290, v266, v292, v293);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v226, v226, v278, v282);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
              TMATMUL_ACC(v226, v226, v286, v290);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              for (int64_t v294 = v45; v294 < v33; v294 += v29) {
                // pto: %204, %205
                ;
                int64_t v295 = (int64_t) ((uint64_t) v247 + (uint64_t) v294) % v32;
                // pto: %206, %207, %208
                ;
                int64_t v296 = v295 < v45 ? (int64_t) ((uint64_t) v295 + (uint64_t) v32) : v295;
                // pto: %209
                ;
                int64_t v297 = (int64_t) ((uint64_t) v296 * (uint64_t) v33);
                // pto: %seed_fast_wrap_x__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v33);
                // pto: %seed_fast_wrap_x__tile
                ;
                uint64_t v299 = (uint64_t) v23;
                TASSIGN(v298, v299);
                // pto: %212
                ;
                int64_t v300 = (int64_t) ((uint64_t) v198 + (uint64_t) v297);
                // pto: %213
                ;
                int64_t v301 = v300 < v45 ? v45 : v300;
                // pto: %214
                ;
                const int64_t v302 = 0;
                // pto: %214
                ;
                __gm__ bfloat16_t* v303 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                // pto: %214
                ;
                const int64_t v304 = 1;
                // pto: %214
                ;
                const int64_t v305 = 1;
                // pto: %214
                ;
                const int64_t v306 = 1;
                // pto: %214
                ;
                int64_t v307 = v193 * v28;
                // pto: %214
                ;
                int64_t v308 = v306 * v307;
                // pto: %214
                ;
                pto::Shape<1, 1, 1, -1, 16> v309 = pto::Shape<1, 1, 1, -1, 16>(v304, v305, v306, v193, v33);
                // pto: %214
                ;
                pto::Stride<-1, -1, -1, -1, -1> v310 = pto::Stride<-1, -1, -1, -1, -1>(v305 * v308, v308, v307, v28, v29);
                // pto: %214
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v311 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v303 + (v302 + v197 * v28 + v301 * v29), v309, v310);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v298, v311);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
                // pto: %seed_fast_wrap_w__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %seed_fast_wrap_w__tile
                ;
                uint64_t v313 = (uint64_t) v24;
                TASSIGN(v312, v313);
                // pto: %218
                ;
                int64_t v314 = v297 / v33;
                // pto: %219
                ;
                int64_t v315 = v314 < v45 ? v45 : v314;
                // pto: %220
                ;
                __gm__ bfloat16_t* v316 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                // pto: %220
                ;
                const int64_t v317 = 0;
                // pto: %220
                ;
                const int64_t v318 = 4194304;
                // pto: %220
                ;
                const int64_t v319 = 65536;
                // pto: %220
                ;
                const int64_t v320 = 256;
                // pto: %220
                ;
                pto::Shape<1, 8, 1, 16, 16> v321 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %220
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v322 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %220
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v323 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v316 + ((v317 + v213 * v318) + v215 * v319 + v315 * v320), v321, v322);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
                TLOAD(v312, v323);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
                // pto: %lhs_slice_0_textract
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v324 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v33);
                // pto: %lhs_slice_0_textract
                ;
                uint64_t v325 = (uint64_t) v23;
                TASSIGN(v324, v325);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
                uint16_t v326 = static_cast<uint16_t>(v45);
                uint16_t v327 = static_cast<uint16_t>(v45);
                TEXTRACT(v324, v298, v326, v327);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                // pto: %rhs_slice_0_textract
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %rhs_slice_0_textract
                ;
                uint64_t v329 = (uint64_t) v23;
                TASSIGN(v328, v329);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
                uint16_t v330 = static_cast<uint16_t>(v45);
                uint16_t v331 = static_cast<uint16_t>(v45);
                TEXTRACT(v328, v312, v330, v331);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v226, v226, v324, v328);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              };
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            // pto: %221
            ;
            v116.SetValidShape(v250, v36);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
            if (v249 <= v54) {
              // pto: %224
              ;
              int64_t v332 = (int64_t) ((uint64_t) v249 * (uint64_t) v33);
              // pto: %6
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v333 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v32);
              // pto: %6
              ;
              uint64_t v334 = (uint64_t) v26;
              TASSIGN(v333, v334);
              // pto: %227
              ;
              int64_t v335 = (int64_t) ((uint64_t) v198 + (uint64_t) v332);
              // pto: %228
              ;
              int64_t v336 = v335 < v45 ? v45 : v335;
              // pto: %229
              ;
              const int64_t v337 = 0;
              // pto: %229
              ;
              __gm__ bfloat16_t* v338 = PTOAS__GLOBAL_TENSOR_DATA(v70);
              // pto: %229
              ;
              const int64_t v339 = 1;
              // pto: %229
              ;
              const int64_t v340 = 1;
              // pto: %229
              ;
              const int64_t v341 = 1;
              // pto: %229
              ;
              int64_t v342 = v193 * v28;
              // pto: %229
              ;
              int64_t v343 = v341 * v342;
              // pto: %229
              ;
              pto::Shape<1, 1, 1, -1, 256> v344 = pto::Shape<1, 1, 1, -1, 256>(v339, v340, v341, v193, v32);
              // pto: %229
              ;
              pto::Stride<-1, -1, -1, -1, -1> v345 = pto::Stride<-1, -1, -1, -1, -1>(v340 * v343, v343, v342, v28, v29);
              // pto: %229
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v346 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v338 + (v337 + v197 * v28 + v336 * v29), v344, v345);
              TLOAD(v333, v346);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
              // pto: %7
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
              // pto: %7
              ;
              uint64_t v348 = (uint64_t) v27;
              TASSIGN(v347, v348);
              // pto: %233
              ;
              int64_t v349 = v332 / v33;
              // pto: %234
              ;
              int64_t v350 = v349 < v45 ? v45 : v349;
              // pto: %235
              ;
              __gm__ bfloat16_t* v351 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %235
              ;
              const int64_t v352 = 0;
              // pto: %235
              ;
              const int64_t v353 = 4194304;
              // pto: %235
              ;
              const int64_t v354 = 65536;
              // pto: %235
              ;
              const int64_t v355 = 256;
              // pto: %235
              ;
              pto::Shape<1, 8, 16, 16, 16> v356 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %235
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v357 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %235
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v358 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v351 + ((v352 + v213 * v353) + v215 * v354 + v350 * v355), v356, v357);
              TLOAD(v347, v358);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
              // pto: %8
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v359 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
              // pto: %8
              ;
              uint64_t v360 = (uint64_t) v23;
              TASSIGN(v359, v360);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
              uint16_t v361 = static_cast<uint16_t>(v45);
              uint16_t v362 = static_cast<uint16_t>(v45);
              TEXTRACT(v359, v333, v361, v362);
              // pto: %9
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v363 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %9
              ;
              uint64_t v364 = (uint64_t) v23;
              TASSIGN(v363, v364);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
              uint16_t v365 = static_cast<uint16_t>(v45);
              uint16_t v366 = static_cast<uint16_t>(v45);
              TEXTRACT(v363, v347, v365, v366);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
              // pto: %10
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v367 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
              // pto: %10
              ;
              uint64_t v368 = (uint64_t) v25;
              TASSIGN(v367, v368);
              uint16_t v369 = static_cast<uint16_t>(v45);
              uint16_t v370 = static_cast<uint16_t>(v36);
              TEXTRACT(v367, v333, v369, v370);
              // pto: %11
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v371 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %11
              ;
              uint64_t v372 = (uint64_t) v25;
              TASSIGN(v371, v372);
              uint16_t v373 = static_cast<uint16_t>(v36);
              uint16_t v374 = static_cast<uint16_t>(v45);
              TEXTRACT(v371, v347, v373, v374);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v114, v114, v359, v363);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
              TMATMUL_ACC(v114, v114, v367, v371);
            } else {
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
              for (int64_t v375 = v45; v375 < v33; v375 += v29) {
                // pto: %237, %238
                ;
                int64_t v376 = (int64_t) ((uint64_t) v249 + (uint64_t) v375) % v32;
                // pto: %239, %240, %241
                ;
                int64_t v377 = v376 < v45 ? (int64_t) ((uint64_t) v376 + (uint64_t) v32) : v376;
                // pto: %242
                ;
                int64_t v378 = (int64_t) ((uint64_t) v377 * (uint64_t) v33);
                // pto: %14
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v379 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v33);
                // pto: %14
                ;
                uint64_t v380 = (uint64_t) v26;
                TASSIGN(v379, v380);
                // pto: %245
                ;
                int64_t v381 = (int64_t) ((uint64_t) v198 + (uint64_t) v378);
                // pto: %246
                ;
                int64_t v382 = v381 < v45 ? v45 : v381;
                // pto: %247
                ;
                const int64_t v383 = 0;
                // pto: %247
                ;
                __gm__ bfloat16_t* v384 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                // pto: %247
                ;
                const int64_t v385 = 1;
                // pto: %247
                ;
                const int64_t v386 = 1;
                // pto: %247
                ;
                const int64_t v387 = 1;
                // pto: %247
                ;
                int64_t v388 = v193 * v28;
                // pto: %247
                ;
                int64_t v389 = v387 * v388;
                // pto: %247
                ;
                pto::Shape<1, 1, 1, -1, 16> v390 = pto::Shape<1, 1, 1, -1, 16>(v385, v386, v387, v193, v33);
                // pto: %247
                ;
                pto::Stride<-1, -1, -1, -1, -1> v391 = pto::Stride<-1, -1, -1, -1, -1>(v386 * v389, v389, v388, v28, v29);
                // pto: %247
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v392 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v384 + (v383 + v197 * v28 + v382 * v29), v390, v391);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                TLOAD(v379, v392);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %15
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v393 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %15
                ;
                uint64_t v394 = (uint64_t) v27;
                TASSIGN(v393, v394);
                // pto: %251
                ;
                int64_t v395 = v378 / v33;
                // pto: %252
                ;
                int64_t v396 = v395 < v45 ? v45 : v395;
                // pto: %253
                ;
                __gm__ bfloat16_t* v397 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                // pto: %253
                ;
                const int64_t v398 = 0;
                // pto: %253
                ;
                const int64_t v399 = 4194304;
                // pto: %253
                ;
                const int64_t v400 = 65536;
                // pto: %253
                ;
                const int64_t v401 = 256;
                // pto: %253
                ;
                pto::Shape<1, 8, 1, 16, 16> v402 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %253
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v403 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %253
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v404 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v397 + ((v398 + v213 * v399) + v215 * v400 + v396 * v401), v402, v403);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
                TLOAD(v393, v404);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %16
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v405 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v33);
                // pto: %16
                ;
                uint64_t v406 = (uint64_t) v23;
                TASSIGN(v405, v406);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
                uint16_t v407 = static_cast<uint16_t>(v45);
                uint16_t v408 = static_cast<uint16_t>(v45);
                TEXTRACT(v405, v379, v407, v408);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                // pto: %17
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v409 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %17
                ;
                uint64_t v410 = (uint64_t) v23;
                TASSIGN(v409, v410);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v411 = static_cast<uint16_t>(v45);
                uint16_t v412 = static_cast<uint16_t>(v45);
                TEXTRACT(v409, v393, v411, v412);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v114, v114, v405, v409);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
              };
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %254, %255
          ;
          int64_t v413 = (int64_t) ((uint64_t) v148 + (uint64_t) v54) % v32;
          // pto: %256, %257, %258
          ;
          int64_t v414 = v413 < v45 ? (int64_t) ((uint64_t) v413 + (uint64_t) v32) : v413;
          // pto: %259
          ;
          // pto: %260
          ;
          int64_t v415 = v193 < v36 ? v193 : v36;
          v118.SetValidShape(v415, v36);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
          if (v414 <= v54) {
            // pto: %262
            ;
            int64_t v416 = (int64_t) ((uint64_t) v414 * (uint64_t) v33);
            // pto: %19
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v417 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v32);
            // pto: %19
            ;
            uint64_t v418 = (uint64_t) v23;
            TASSIGN(v417, v418);
            // pto: %265
            ;
            int64_t v419 = (int64_t) ((uint64_t) v198 + (uint64_t) v416);
            // pto: %266
            ;
            int64_t v420 = v419 < v45 ? v45 : v419;
            // pto: %267
            ;
            const int64_t v421 = 0;
            // pto: %267
            ;
            __gm__ bfloat16_t* v422 = PTOAS__GLOBAL_TENSOR_DATA(v70);
            // pto: %267
            ;
            const int64_t v423 = 1;
            // pto: %267
            ;
            const int64_t v424 = 1;
            // pto: %267
            ;
            const int64_t v425 = 1;
            // pto: %267
            ;
            int64_t v426 = v193 * v28;
            // pto: %267
            ;
            int64_t v427 = v425 * v426;
            // pto: %267
            ;
            pto::Shape<1, 1, 1, -1, 256> v428 = pto::Shape<1, 1, 1, -1, 256>(v423, v424, v425, v193, v32);
            // pto: %267
            ;
            pto::Stride<-1, -1, -1, -1, -1> v429 = pto::Stride<-1, -1, -1, -1, -1>(v424 * v427, v427, v426, v28, v29);
            // pto: %267
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v430 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v422 + (v421 + v197 * v28 + v420 * v29), v428, v429);
            TLOAD(v417, v430);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %20
            ;
            Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v431 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
            // pto: %20
            ;
            uint64_t v432 = (uint64_t) v24;
            TASSIGN(v431, v432);
            // pto: %271
            ;
            int64_t v433 = v416 / v33;
            // pto: %272
            ;
            int64_t v434 = v433 < v45 ? v45 : v433;
            // pto: %273
            ;
            __gm__ bfloat16_t* v435 = PTOAS__GLOBAL_TENSOR_DATA(v73);
            // pto: %273
            ;
            const int64_t v436 = 0;
            // pto: %273
            ;
            const int64_t v437 = 4194304;
            // pto: %273
            ;
            const int64_t v438 = 65536;
            // pto: %273
            ;
            const int64_t v439 = 256;
            // pto: %273
            ;
            pto::Shape<1, 8, 16, 16, 16> v440 = pto::Shape<1, 8, 16, 16, 16>();
            // pto: %273
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v441 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %273
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v442 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v435 + ((v436 + v213 * v437) + v215 * v438 + v434 * v439), v440, v441);
            TLOAD(v431, v442);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %21
            ;
            Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v443 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
            // pto: %21
            ;
            uint64_t v444 = (uint64_t) v23;
            TASSIGN(v443, v444);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            uint16_t v445 = static_cast<uint16_t>(v45);
            uint16_t v446 = static_cast<uint16_t>(v45);
            TEXTRACT(v443, v417, v445, v446);
            // pto: %22
            ;
            Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v447 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
            // pto: %22
            ;
            uint64_t v448 = (uint64_t) v23;
            TASSIGN(v447, v448);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v449 = static_cast<uint16_t>(v45);
            uint16_t v450 = static_cast<uint16_t>(v45);
            TEXTRACT(v447, v431, v449, v450);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            // pto: %23
            ;
            Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v451 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
            // pto: %23
            ;
            uint64_t v452 = (uint64_t) v25;
            TASSIGN(v451, v452);
            uint16_t v453 = static_cast<uint16_t>(v45);
            uint16_t v454 = static_cast<uint16_t>(v36);
            TEXTRACT(v451, v417, v453, v454);
            // pto: %24
            ;
            Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v455 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
            // pto: %24
            ;
            uint64_t v456 = (uint64_t) v25;
            TASSIGN(v455, v456);
            uint16_t v457 = static_cast<uint16_t>(v36);
            uint16_t v458 = static_cast<uint16_t>(v45);
            TEXTRACT(v455, v431, v457, v458);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v226, v226, v443, v447);
            pipe_barrier(PIPE_M);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
            TMATMUL_ACC(v226, v226, v451, v455);
          } else {
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            for (int64_t v459 = v45; v459 < v33; v459 += v29) {
              // pto: %275, %276
              ;
              int64_t v460 = (int64_t) ((uint64_t) v414 + (uint64_t) v459) % v32;
              // pto: %277, %278, %279
              ;
              int64_t v461 = v460 < v45 ? (int64_t) ((uint64_t) v460 + (uint64_t) v32) : v460;
              // pto: %280
              ;
              int64_t v462 = (int64_t) ((uint64_t) v461 * (uint64_t) v33);
              // pto: %27
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v463 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v33);
              // pto: %27
              ;
              uint64_t v464 = (uint64_t) v23;
              TASSIGN(v463, v464);
              // pto: %283
              ;
              int64_t v465 = (int64_t) ((uint64_t) v198 + (uint64_t) v462);
              // pto: %284
              ;
              int64_t v466 = v465 < v45 ? v45 : v465;
              // pto: %285
              ;
              const int64_t v467 = 0;
              // pto: %285
              ;
              __gm__ bfloat16_t* v468 = PTOAS__GLOBAL_TENSOR_DATA(v70);
              // pto: %285
              ;
              const int64_t v469 = 1;
              // pto: %285
              ;
              const int64_t v470 = 1;
              // pto: %285
              ;
              const int64_t v471 = 1;
              // pto: %285
              ;
              int64_t v472 = v193 * v28;
              // pto: %285
              ;
              int64_t v473 = v471 * v472;
              // pto: %285
              ;
              pto::Shape<1, 1, 1, -1, 16> v474 = pto::Shape<1, 1, 1, -1, 16>(v469, v470, v471, v193, v33);
              // pto: %285
              ;
              pto::Stride<-1, -1, -1, -1, -1> v475 = pto::Stride<-1, -1, -1, -1, -1>(v470 * v473, v473, v472, v28, v29);
              // pto: %285
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v476 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v468 + (v467 + v197 * v28 + v466 * v29), v474, v475);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              TLOAD(v463, v476);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %28
              ;
              Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v477 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %28
              ;
              uint64_t v478 = (uint64_t) v24;
              TASSIGN(v477, v478);
              // pto: %289
              ;
              int64_t v479 = v462 / v33;
              // pto: %290
              ;
              int64_t v480 = v479 < v45 ? v45 : v479;
              // pto: %291
              ;
              __gm__ bfloat16_t* v481 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %291
              ;
              const int64_t v482 = 0;
              // pto: %291
              ;
              const int64_t v483 = 4194304;
              // pto: %291
              ;
              const int64_t v484 = 65536;
              // pto: %291
              ;
              const int64_t v485 = 256;
              // pto: %291
              ;
              pto::Shape<1, 8, 1, 16, 16> v486 = pto::Shape<1, 8, 1, 16, 16>();
              // pto: %291
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v487 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %291
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v488 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v481 + ((v482 + v213 * v483) + v215 * v484 + v480 * v485), v486, v487);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              TLOAD(v477, v488);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %29
              ;
              Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v489 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v33);
              // pto: %29
              ;
              uint64_t v490 = (uint64_t) v23;
              TASSIGN(v489, v490);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
              uint16_t v491 = static_cast<uint16_t>(v45);
              uint16_t v492 = static_cast<uint16_t>(v45);
              TEXTRACT(v489, v463, v491, v492);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              // pto: %30
              ;
              Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v493 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %30
              ;
              uint64_t v494 = (uint64_t) v23;
              TASSIGN(v493, v494);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v495 = static_cast<uint16_t>(v45);
              uint16_t v496 = static_cast<uint16_t>(v45);
              TEXTRACT(v493, v477, v495, v496);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v226, v226, v489, v493);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            };
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          };
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          // pto: %seed_fast_acc__rv_v2
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v497 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v193, v36);
          // pto: %seed_fast_acc__rv_v2
          ;
          uint64_t v498 = (uint64_t) v23;
          TASSIGN(v497, v498);
          // pto: %293, %294
          ;
          int64_t v499 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v55) + (uint64_t) v143);
          // pto: %295
          ;
          int64_t v500 = v499 < v45 ? v45 : v499;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v501 = 0;
          // pto: %accum__ssa_v0_pview
          ;
          __gm__ float* v502 = PTOAS__GLOBAL_TENSOR_DATA(v94);
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v503 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v504 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v505 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          int64_t v506 = v193 * v42;
          // pto: %accum__ssa_v0_pview
          ;
          int64_t v507 = v505 * v506;
          // pto: %accum__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, -1, 128> v508 = pto::Shape<1, 1, 1, -1, 128>(v503, v504, v505, v193, v36);
          // pto: %accum__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v509 = pto::Stride<-1, -1, -1, -1, -1>(v504 * v507, v507, v506, v42, v29);
          // pto: %accum__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v510 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v502 + (v501 + v197 * v42 + v500 * v29), v508, v509);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          TSTORE(v510, v497);
        } else {
          for (int64_t v511 = v45; v511 < v30; v511 += v29) {
            // pto: %296
            ;
            int64_t v512 = (int64_t) ((uint64_t) v145 + (uint64_t) v511);
            // pto: %297
            ;
            if (v512 < v138) {
              // pto: %298
              ;
              int64_t v513 = (int64_t) ((uint64_t) v512 * (uint64_t) v33);
              // pto: %299
              ;
              int64_t v514 = (int64_t) ((uint64_t) v17 - (uint64_t) v513);
              // pto: %300
              ;
              int64_t v515 = v514 < v33 ? v514 : v33;
              // pto: %302, %303, %304, %305, %301
              ;
              int32_t v516 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v512 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
              // pto: %306
              ;
              int64_t v517 = (int64_t) v516;
              // pto: %307
              ;
              int64_t v518 = v517 < v45 ? v45 : v517;
              // pto: %seed_narrow_acc__tile
              ;
              Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v519 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %seed_narrow_acc__tile
              ;
              uint64_t v520 = (uint64_t) v23;
              TASSIGN(v519, v520);
              wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              for (int64_t v521 = v45; v521 < v33; v521 += v29) {
                // pto: %308
                ;
                int64_t v522 = (int64_t) ((uint64_t) v521 * (uint64_t) v33);
                // pto: %309, %310
                ;
                int64_t v523 = (int64_t) ((uint64_t) v518 + (uint64_t) v522) % v32;
                // pto: %311, %312, %313
                ;
                int64_t v524 = v523 < v45 ? (int64_t) ((uint64_t) v523 + (uint64_t) v32) : v523;
                // pto: %314
                ;
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                if (v524 <= v54) {
                  // pto: %315
                  ;
                  int64_t v525 = (int64_t) ((uint64_t) v524 * (uint64_t) v33);
                  // pto: %seed_narrow_packet_x__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v526 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v515, v32);
                  // pto: %seed_narrow_packet_x__tile
                  ;
                  uint64_t v527 = (uint64_t) v24;
                  TASSIGN(v526, v527);
                  // pto: %316
                  ;
                  int64_t v528 = v513 < v45 ? v45 : v513;
                  // pto: %317, %318
                  ;
                  int64_t v529 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v41) + (uint64_t) v525);
                  // pto: %319
                  ;
                  int64_t v530 = v529 < v45 ? v45 : v529;
                  // pto: %320
                  ;
                  const int64_t v531 = 0;
                  // pto: %320
                  ;
                  __gm__ bfloat16_t* v532 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                  // pto: %320
                  ;
                  const int64_t v533 = 1;
                  // pto: %320
                  ;
                  const int64_t v534 = 1;
                  // pto: %320
                  ;
                  const int64_t v535 = 1;
                  // pto: %320
                  ;
                  int64_t v536 = v515 * v28;
                  // pto: %320
                  ;
                  int64_t v537 = v535 * v536;
                  // pto: %320
                  ;
                  pto::Shape<1, 1, 1, -1, 256> v538 = pto::Shape<1, 1, 1, -1, 256>(v533, v534, v535, v515, v32);
                  // pto: %320
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v539 = pto::Stride<-1, -1, -1, -1, -1>(v534 * v537, v537, v536, v28, v29);
                  // pto: %320
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v540 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v532 + (v531 + v528 * v28 + v530 * v29), v538, v539);
                  TLOAD(v526, v540);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  // pto: %seed_narrow_packet_w__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v541 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
                  // pto: %seed_narrow_packet_w__tile
                  ;
                  uint64_t v542 = (uint64_t) v23;
                  TASSIGN(v541, v542);
                  // pto: %321
                  ;
                  int64_t v543 = v140 < v45 ? v45 : v140;
                  // pto: %322
                  ;
                  int64_t v544 = v143 / v33;
                  // pto: %323
                  ;
                  int64_t v545 = v544 < v45 ? v45 : v544;
                  // pto: %324
                  ;
                  int64_t v546 = v525 / v33;
                  // pto: %325
                  ;
                  int64_t v547 = v546 < v45 ? v45 : v546;
                  // pto: %326
                  ;
                  __gm__ bfloat16_t* v548 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                  // pto: %326
                  ;
                  const int64_t v549 = 0;
                  // pto: %326
                  ;
                  const int64_t v550 = 4194304;
                  // pto: %326
                  ;
                  const int64_t v551 = 65536;
                  // pto: %326
                  ;
                  const int64_t v552 = 256;
                  // pto: %326
                  ;
                  pto::Shape<1, 8, 16, 16, 16> v553 = pto::Shape<1, 8, 16, 16, 16>();
                  // pto: %326
                  ;
                  pto::Stride<4194304, 65536, 256, 16, 1> v554 = pto::Stride<4194304, 65536, 256, 16, 1>();
                  // pto: %326
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v555 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v548 + ((v549 + v543 * v550) + v545 * v551 + v547 * v552), v553, v554);
                  TLOAD(v541, v555);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  // pto: %seed_narrow_acc__iter_v1_l0_a
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v556 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v515, v36);
                  // pto: %seed_narrow_acc__iter_v1_l0_a
                  ;
                  uint64_t v557 = (uint64_t) v23;
                  TASSIGN(v556, v557);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  uint16_t v558 = static_cast<uint16_t>(v45);
                  uint16_t v559 = static_cast<uint16_t>(v45);
                  TEXTRACT(v556, v526, v558, v559);
                  // pto: %seed_narrow_acc__iter_v1_l0_b
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v560 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %seed_narrow_acc__iter_v1_l0_b
                  ;
                  uint64_t v561 = (uint64_t) v23;
                  TASSIGN(v560, v561);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  uint16_t v562 = static_cast<uint16_t>(v45);
                  uint16_t v563 = static_cast<uint16_t>(v45);
                  TEXTRACT(v560, v541, v562, v563);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  // pto: %32
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v564 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v515, v36);
                  // pto: %32
                  ;
                  uint64_t v565 = (uint64_t) v25;
                  TASSIGN(v564, v565);
                  uint16_t v566 = static_cast<uint16_t>(v45);
                  uint16_t v567 = static_cast<uint16_t>(v36);
                  TEXTRACT(v564, v526, v566, v567);
                  // pto: %33
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v568 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %33
                  ;
                  uint64_t v569 = (uint64_t) v25;
                  TASSIGN(v568, v569);
                  uint16_t v570 = static_cast<uint16_t>(v36);
                  uint16_t v571 = static_cast<uint16_t>(v45);
                  TEXTRACT(v568, v541, v570, v571);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  // pto: %327
                  ;
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  if (v521 == v45) {
                    pipe_barrier(PIPE_M);
                    TMATMUL(v519, v556, v560);
                  } else {
                    pipe_barrier(PIPE_M);
                    TMATMUL_ACC(v519, v519, v556, v560);
                  };
                  pipe_barrier(PIPE_M);
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  TMATMUL_ACC(v519, v519, v564, v568);
                } else {
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  for (int64_t v572 = v45; v572 < v33; v572 += v29) {
                    // pto: %328, %329
                    ;
                    int64_t v573 = (int64_t) ((uint64_t) v524 + (uint64_t) v572) % v32;
                    // pto: %330, %331, %332
                    ;
                    int64_t v574 = v573 < v45 ? (int64_t) ((uint64_t) v573 + (uint64_t) v32) : v573;
                    // pto: %333
                    ;
                    int64_t v575 = (int64_t) ((uint64_t) v574 * (uint64_t) v33);
                    // pto: %seed_narrow_wrap_x__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v576 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v515, v33);
                    // pto: %seed_narrow_wrap_x__tile
                    ;
                    uint64_t v577 = (uint64_t) v24;
                    TASSIGN(v576, v577);
                    // pto: %334
                    ;
                    int64_t v578 = v513 < v45 ? v45 : v513;
                    // pto: %335, %336
                    ;
                    int64_t v579 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v41) + (uint64_t) v575);
                    // pto: %337
                    ;
                    int64_t v580 = v579 < v45 ? v45 : v579;
                    // pto: %338
                    ;
                    const int64_t v581 = 0;
                    // pto: %338
                    ;
                    __gm__ bfloat16_t* v582 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                    // pto: %338
                    ;
                    const int64_t v583 = 1;
                    // pto: %338
                    ;
                    const int64_t v584 = 1;
                    // pto: %338
                    ;
                    const int64_t v585 = 1;
                    // pto: %338
                    ;
                    int64_t v586 = v515 * v28;
                    // pto: %338
                    ;
                    int64_t v587 = v585 * v586;
                    // pto: %338
                    ;
                    pto::Shape<1, 1, 1, -1, 16> v588 = pto::Shape<1, 1, 1, -1, 16>(v583, v584, v585, v515, v33);
                    // pto: %338
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v589 = pto::Stride<-1, -1, -1, -1, -1>(v584 * v587, v587, v586, v28, v29);
                    // pto: %338
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v590 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v582 + (v581 + v578 * v28 + v580 * v29), v588, v589);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v576, v590);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    // pto: %seed_narrow_wrap_w__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v591 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %seed_narrow_wrap_w__tile
                    ;
                    uint64_t v592 = (uint64_t) v23;
                    TASSIGN(v591, v592);
                    // pto: %339
                    ;
                    int64_t v593 = v140 < v45 ? v45 : v140;
                    // pto: %340
                    ;
                    int64_t v594 = v143 / v33;
                    // pto: %341
                    ;
                    int64_t v595 = v594 < v45 ? v45 : v594;
                    // pto: %342
                    ;
                    int64_t v596 = v575 / v33;
                    // pto: %343
                    ;
                    int64_t v597 = v596 < v45 ? v45 : v596;
                    // pto: %344
                    ;
                    __gm__ bfloat16_t* v598 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                    // pto: %344
                    ;
                    const int64_t v599 = 0;
                    // pto: %344
                    ;
                    const int64_t v600 = 4194304;
                    // pto: %344
                    ;
                    const int64_t v601 = 65536;
                    // pto: %344
                    ;
                    const int64_t v602 = 256;
                    // pto: %344
                    ;
                    pto::Shape<1, 8, 1, 16, 16> v603 = pto::Shape<1, 8, 1, 16, 16>();
                    // pto: %344
                    ;
                    pto::Stride<4194304, 65536, 256, 16, 1> v604 = pto::Stride<4194304, 65536, 256, 16, 1>();
                    // pto: %344
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v605 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v598 + ((v599 + v593 * v600) + v595 * v601 + v597 * v602), v603, v604);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    TLOAD(v591, v605);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    // pto: %35
                    ;
                    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v606 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v515, v33);
                    // pto: %35
                    ;
                    uint64_t v607 = (uint64_t) v23;
                    TASSIGN(v606, v607);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                    uint16_t v608 = static_cast<uint16_t>(v45);
                    uint16_t v609 = static_cast<uint16_t>(v45);
                    TEXTRACT(v606, v576, v608, v609);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    // pto: %36
                    ;
                    Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v610 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %36
                    ;
                    uint64_t v611 = (uint64_t) v23;
                    TASSIGN(v610, v611);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    uint16_t v612 = static_cast<uint16_t>(v45);
                    uint16_t v613 = static_cast<uint16_t>(v45);
                    TEXTRACT(v610, v591, v612, v613);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    // pto: %346, %347
                    ;
                    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    if ((int64_t) ((uint64_t) v522 + (uint64_t) v572) == v45) {
                      pipe_barrier(PIPE_M);
                      TMATMUL(v519, v606, v610);
                    } else {
                      pipe_barrier(PIPE_M);
                      TMATMUL_ACC(v519, v519, v606, v610);
                    };
                    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  };
                  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
              // pto: %348
              ;
              int64_t v614 = v513 < v45 ? v45 : v513;
              // pto: %349, %350
              ;
              int64_t v615 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v55) + (uint64_t) v143);
              // pto: %351
              ;
              int64_t v616 = v615 < v45 ? v45 : v615;
              // pto: %352
              ;
              __gm__ float* v617 = PTOAS__GLOBAL_TENSOR_DATA(v94);
              // pto: %352
              ;
              const int64_t v618 = 0;
              // pto: %352
              ;
              const int64_t v619 = 8192;
              // pto: %352
              ;
              pto::Shape<1, 1, 1, 16, 128> v620 = pto::Shape<1, 1, 1, 16, 128>();
              // pto: %352
              ;
              pto::Stride<131072, 131072, 131072, 8192, 1> v621 = pto::Stride<131072, 131072, 131072, 8192, 1>();
              // pto: %352
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v622 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v617 + (v618 + v614 * v619 + v616), v620, v621);
              wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
              pipe_barrier(PIPE_FIX);
              TSTORE(v622, v519);
              set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
            };
          };
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    };
  } else {
    for (int64_t v623 = v126; v623 < v31; v623 += v48) {
      // pto: %354
      ;
      int64_t v624 = v623 / v30;
      // pto: %355
      ;
      int64_t v625 = v623 % v30;
      // pto: %356, %357, %358
      ;
      int64_t v626 = v625 < v45 ? (int64_t) ((uint64_t) v625 + (uint64_t) v30) : v625;
      // pto: %359
      ;
      int64_t v627 = (int64_t) ((uint64_t) v626 * (uint64_t) v36);
      // pto: %360, %361
      ;
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v628 = v45; v628 < ((int64_t) ((uint64_t) v138 + (uint64_t) v49) / v30); v628 += v29) {
        // pto: %362
        ;
        int64_t v629 = (int64_t) ((uint64_t) v628 * (uint64_t) v30);
        // pto: %365, %366, %367, %363
        ;
        int32_t v630 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v628 * (uint64_t) v31) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
        // pto: %368
        ;
        int64_t v631 = (int64_t) v630;
        // pto: %369
        ;
        int64_t v632 = v631 < v45 ? v45 : v631;
        // pto: %370
        ;
        int64_t v633 = (int64_t) ((uint64_t) v629 + (uint64_t) v29);
        // pto: %371
        ;
        // pto: %v4_same_start__phi_v3
        ;
        int64_t v634;
        if (v633 < v138) {
          // pto: %374, %375, %376, %377, %372
          ;
          int32_t v635 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v633 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %378
          ;
          int64_t v636 = (int64_t) v635;
          // pto: %379
          ;
          int64_t v637 = v636 < v45 ? v45 : v636;
          // pto: %380, %v4_same_start__phi_v2
          ;
          v634 = v637 != v632 ? v45 : v29;
        } else {
          v634 = v29;
        };
        // pto: %381
        ;
        int64_t v638 = (int64_t) ((uint64_t) v629 + (uint64_t) v50);
        // pto: %382
        ;
        // pto: %v4_same_start__phi_v6
        ;
        int64_t v639;
        if (v638 < v138) {
          // pto: %385, %386, %387, %388, %383
          ;
          int32_t v640 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v638 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %389
          ;
          int64_t v641 = (int64_t) v640;
          // pto: %390
          ;
          int64_t v642 = v641 < v45 ? v45 : v641;
          // pto: %391, %v4_same_start__phi_v5
          ;
          int64_t v643 = v642 != v632 ? v45 : v634;
          v639 = v643;
        } else {
          v639 = v634;
        };
        // pto: %392
        ;
        int64_t v644 = (int64_t) ((uint64_t) v629 + (uint64_t) v51);
        // pto: %393
        ;
        // pto: %v4_same_start__phi_v9
        ;
        int64_t v645;
        if (v644 < v138) {
          // pto: %396, %397, %398, %399, %394
          ;
          int32_t v646 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v644 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %400
          ;
          int64_t v647 = (int64_t) v646;
          // pto: %401
          ;
          int64_t v648 = v647 < v45 ? v45 : v647;
          // pto: %402, %v4_same_start__phi_v8
          ;
          int64_t v649 = v648 != v632 ? v45 : v639;
          v645 = v649;
        } else {
          v645 = v639;
        };
        // pto: %403
        ;
        int64_t v650 = (int64_t) ((uint64_t) v629 + (uint64_t) v43);
        // pto: %404
        ;
        // pto: %v4_same_start__phi_v12
        ;
        int64_t v651;
        if (v650 < v138) {
          // pto: %407, %408, %409, %410, %405
          ;
          int32_t v652 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v650 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %411
          ;
          int64_t v653 = (int64_t) v652;
          // pto: %412
          ;
          int64_t v654 = v653 < v45 ? v45 : v653;
          // pto: %413, %v4_same_start__phi_v11
          ;
          int64_t v655 = v654 != v632 ? v45 : v645;
          v651 = v655;
        } else {
          v651 = v645;
        };
        // pto: %414
        ;
        int64_t v656 = (int64_t) ((uint64_t) v629 + (uint64_t) v52);
        // pto: %415
        ;
        // pto: %v4_same_start__phi_v15
        ;
        int64_t v657;
        if (v656 < v138) {
          // pto: %418, %419, %420, %421, %416
          ;
          int32_t v658 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v656 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %422
          ;
          int64_t v659 = (int64_t) v658;
          // pto: %423
          ;
          int64_t v660 = v659 < v45 ? v45 : v659;
          // pto: %424, %v4_same_start__phi_v14
          ;
          int64_t v661 = v660 != v632 ? v45 : v651;
          v657 = v661;
        } else {
          v657 = v651;
        };
        // pto: %425
        ;
        int64_t v662 = (int64_t) ((uint64_t) v629 + (uint64_t) v53);
        // pto: %426
        ;
        // pto: %v4_same_start__phi_v18
        ;
        int64_t v663;
        if (v662 < v138) {
          // pto: %429, %430, %431, %432, %427
          ;
          int32_t v664 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v662 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %433
          ;
          int64_t v665 = (int64_t) v664;
          // pto: %434
          ;
          int64_t v666 = v665 < v45 ? v45 : v665;
          // pto: %435, %v4_same_start__phi_v17
          ;
          int64_t v667 = v666 != v632 ? v45 : v657;
          v663 = v667;
        } else {
          v663 = v657;
        };
        // pto: %436
        ;
        int64_t v668 = (int64_t) ((uint64_t) v629 + (uint64_t) v49);
        // pto: %437
        ;
        // pto: %v4_same_start__phi_v21
        ;
        int64_t v669;
        if (v668 < v138) {
          // pto: %440, %441, %442, %443, %438
          ;
          int32_t v670 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v668 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %444
          ;
          int64_t v671 = (int64_t) v670;
          // pto: %445
          ;
          int64_t v672 = v671 < v45 ? v45 : v671;
          // pto: %446, %v4_same_start__phi_v20
          ;
          int64_t v673 = v672 != v632 ? v45 : v663;
          v669 = v673;
        } else {
          v669 = v663;
        };
        // pto: %447, %v4_same_start__phi_v23
        ;
        int64_t v674 = v17 <= v33 ? v45 : v669;
        // pto: %448
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        if (v674 == v29) {
          int64_t v675 = (int64_t) ((uint64_t) v628 * (uint64_t) v36);
          // pto: %450
          ;
          int64_t v676 = (int64_t) ((uint64_t) v17 - (uint64_t) v675);
          // pto: %451
          ;
          int64_t v677 = v676 < v36 ? v676 : v36;
          // pto: %452
          ;
          int64_t v678 = v632 % v32;
          // pto: %453, %454, %455
          ;
          int64_t v679 = v678 < v45 ? (int64_t) ((uint64_t) v678 + (uint64_t) v32) : v678;
          // pto: %456
          ;
          int64_t v680 = (int64_t) ((uint64_t) v679 * (uint64_t) v33);
          // pto: %v4_wide_seed_x__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v681 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v677, v33);
          // pto: %v4_wide_seed_x__tile
          ;
          uint64_t v682 = (uint64_t) v23;
          TASSIGN(v681, v682);
          // pto: %457
          ;
          int64_t v683 = v675 < v45 ? v45 : v675;
          // pto: %458
          ;
          int64_t v684 = (int64_t) ((uint64_t) v624 * (uint64_t) v41);
          // pto: %459
          ;
          int64_t v685 = (int64_t) ((uint64_t) v684 + (uint64_t) v680);
          // pto: %460
          ;
          int64_t v686 = v685 < v45 ? v45 : v685;
          // pto: %461
          ;
          const int64_t v687 = 0;
          // pto: %461
          ;
          __gm__ bfloat16_t* v688 = PTOAS__GLOBAL_TENSOR_DATA(v70);
          // pto: %461
          ;
          const int64_t v689 = 1;
          // pto: %461
          ;
          const int64_t v690 = 1;
          // pto: %461
          ;
          const int64_t v691 = 1;
          // pto: %461
          ;
          int64_t v692 = v677 * v28;
          // pto: %461
          ;
          int64_t v693 = v691 * v692;
          // pto: %461
          ;
          pto::Shape<1, 1, 1, -1, 16> v694 = pto::Shape<1, 1, 1, -1, 16>(v689, v690, v691, v677, v33);
          // pto: %461
          ;
          pto::Stride<-1, -1, -1, -1, -1> v695 = pto::Stride<-1, -1, -1, -1, -1>(v690 * v693, v693, v692, v28, v29);
          // pto: %461
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v696 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v688 + (v687 + v683 * v28 + v686 * v29), v694, v695);
          TLOAD(v681, v696);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %v4_wide_seed_w__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v697 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
          // pto: %v4_wide_seed_w__tile
          ;
          uint64_t v698 = (uint64_t) v24;
          TASSIGN(v697, v698);
          // pto: %462
          ;
          int64_t v699 = v624 < v45 ? v45 : v624;
          // pto: %463
          ;
          int64_t v700 = v627 / v33;
          // pto: %464
          ;
          int64_t v701 = v700 < v45 ? v45 : v700;
          // pto: %465
          ;
          int64_t v702 = v680 / v33;
          // pto: %466
          ;
          int64_t v703 = v702 < v45 ? v45 : v702;
          // pto: %467
          ;
          __gm__ bfloat16_t* v704 = PTOAS__GLOBAL_TENSOR_DATA(v73);
          // pto: %467
          ;
          const int64_t v705 = 0;
          // pto: %467
          ;
          const int64_t v706 = 4194304;
          // pto: %467
          ;
          const int64_t v707 = 65536;
          // pto: %467
          ;
          const int64_t v708 = 256;
          // pto: %467
          ;
          pto::Shape<1, 8, 1, 16, 16> v709 = pto::Shape<1, 8, 1, 16, 16>();
          // pto: %467
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v710 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %467
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v711 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v704 + ((v705 + v699 * v706) + v701 * v707 + v703 * v708), v709, v710);
          TLOAD(v697, v711);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %37
          ;
          Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v712 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v677, v33);
          // pto: %37
          ;
          uint64_t v713 = (uint64_t) v23;
          TASSIGN(v712, v713);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          uint16_t v714 = static_cast<uint16_t>(v45);
          uint16_t v715 = static_cast<uint16_t>(v45);
          TEXTRACT(v712, v681, v714, v715);
          // pto: %38
          ;
          Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v716 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
          // pto: %38
          ;
          uint64_t v717 = (uint64_t) v23;
          TASSIGN(v716, v717);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v718 = static_cast<uint16_t>(v45);
          uint16_t v719 = static_cast<uint16_t>(v45);
          TEXTRACT(v716, v697, v718, v719);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %v4_wide_acc__tile
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v720 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v677, v36);
          // pto: %v4_wide_acc__tile
          ;
          uint64_t v721 = (uint64_t) v23;
          TASSIGN(v720, v721);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          TMATMUL(v720, v712, v716);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          for (int64_t v722 = v45; v722 < v46; v722 += v29) {
            // pto: %469, %468, %470, %471
            ;
            int64_t v723 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v632 + (uint64_t) ((int64_t) (uint64_t) v722 * (uint64_t) v33)) + (uint64_t) v29) % v32;
            // pto: %472, %473, %474
            ;
            int64_t v724 = v723 < v45 ? (int64_t) ((uint64_t) v723 + (uint64_t) v32) : v723;
            // pto: %475
            ;
            // pto: %476
            ;
            int64_t v725 = v677 < v36 ? v677 : v36;
            v122.SetValidShape(v725, v36);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            if (v724 <= v54) {
              // pto: %477
              ;
              int64_t v726 = (int64_t) ((uint64_t) v724 * (uint64_t) v33);
              // pto: %v4_wide_packet_x__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v727 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v677, v32);
              // pto: %v4_wide_packet_x__tile
              ;
              uint64_t v728 = (uint64_t) v23;
              TASSIGN(v727, v728);
              // pto: %480
              ;
              int64_t v729 = (int64_t) ((uint64_t) v684 + (uint64_t) v726);
              // pto: %481
              ;
              int64_t v730 = v729 < v45 ? v45 : v729;
              // pto: %482
              ;
              const int64_t v731 = 0;
              // pto: %482
              ;
              __gm__ bfloat16_t* v732 = PTOAS__GLOBAL_TENSOR_DATA(v70);
              // pto: %482
              ;
              const int64_t v733 = 1;
              // pto: %482
              ;
              const int64_t v734 = 1;
              // pto: %482
              ;
              const int64_t v735 = 1;
              // pto: %482
              ;
              int64_t v736 = v677 * v28;
              // pto: %482
              ;
              int64_t v737 = v735 * v736;
              // pto: %482
              ;
              pto::Shape<1, 1, 1, -1, 256> v738 = pto::Shape<1, 1, 1, -1, 256>(v733, v734, v735, v677, v32);
              // pto: %482
              ;
              pto::Stride<-1, -1, -1, -1, -1> v739 = pto::Stride<-1, -1, -1, -1, -1>(v734 * v737, v737, v736, v28, v29);
              // pto: %482
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v740 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v732 + (v731 + v683 * v28 + v730 * v29), v738, v739);
              TLOAD(v727, v740);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %v4_wide_packet_w__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v741 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
              // pto: %v4_wide_packet_w__tile
              ;
              uint64_t v742 = (uint64_t) v24;
              TASSIGN(v741, v742);
              // pto: %486
              ;
              int64_t v743 = v726 / v33;
              // pto: %487
              ;
              int64_t v744 = v743 < v45 ? v45 : v743;
              // pto: %488
              ;
              __gm__ bfloat16_t* v745 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %488
              ;
              const int64_t v746 = 0;
              // pto: %488
              ;
              const int64_t v747 = 4194304;
              // pto: %488
              ;
              const int64_t v748 = 65536;
              // pto: %488
              ;
              const int64_t v749 = 256;
              // pto: %488
              ;
              pto::Shape<1, 8, 16, 16, 16> v750 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %488
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v751 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %488
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v752 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v745 + ((v746 + v699 * v747) + v701 * v748 + v744 * v749), v750, v751);
              TLOAD(v741, v752);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %v4_wide_acc__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v753 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v677, v36);
              // pto: %v4_wide_acc__iter_v1_l0_a
              ;
              uint64_t v754 = (uint64_t) v23;
              TASSIGN(v753, v754);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              uint16_t v755 = static_cast<uint16_t>(v45);
              uint16_t v756 = static_cast<uint16_t>(v45);
              TEXTRACT(v753, v727, v755, v756);
              // pto: %v4_wide_acc__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v757 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %v4_wide_acc__iter_v1_l0_b
              ;
              uint64_t v758 = (uint64_t) v23;
              TASSIGN(v757, v758);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v759 = static_cast<uint16_t>(v45);
              uint16_t v760 = static_cast<uint16_t>(v45);
              TEXTRACT(v757, v741, v759, v760);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              // pto: %39
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v761 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v677, v36);
              // pto: %39
              ;
              uint64_t v762 = (uint64_t) v25;
              TASSIGN(v761, v762);
              uint16_t v763 = static_cast<uint16_t>(v45);
              uint16_t v764 = static_cast<uint16_t>(v36);
              TEXTRACT(v761, v727, v763, v764);
              // pto: %40
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v765 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %40
              ;
              uint64_t v766 = (uint64_t) v25;
              TASSIGN(v765, v766);
              uint16_t v767 = static_cast<uint16_t>(v36);
              uint16_t v768 = static_cast<uint16_t>(v45);
              TEXTRACT(v765, v741, v767, v768);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v720, v720, v753, v757);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              TMATMUL_ACC(v720, v720, v761, v765);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              for (int64_t v769 = v45; v769 < v33; v769 += v29) {
                // pto: %489, %490
                ;
                int64_t v770 = (int64_t) ((uint64_t) v724 + (uint64_t) v769) % v32;
                // pto: %491, %492, %493
                ;
                int64_t v771 = v770 < v45 ? (int64_t) ((uint64_t) v770 + (uint64_t) v32) : v770;
                // pto: %494
                ;
                int64_t v772 = (int64_t) ((uint64_t) v771 * (uint64_t) v33);
                // pto: %v4_wide_wrap_x__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v773 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v677, v33);
                // pto: %v4_wide_wrap_x__tile
                ;
                uint64_t v774 = (uint64_t) v23;
                TASSIGN(v773, v774);
                // pto: %497
                ;
                int64_t v775 = (int64_t) ((uint64_t) v684 + (uint64_t) v772);
                // pto: %498
                ;
                int64_t v776 = v775 < v45 ? v45 : v775;
                // pto: %499
                ;
                const int64_t v777 = 0;
                // pto: %499
                ;
                __gm__ bfloat16_t* v778 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                // pto: %499
                ;
                const int64_t v779 = 1;
                // pto: %499
                ;
                const int64_t v780 = 1;
                // pto: %499
                ;
                const int64_t v781 = 1;
                // pto: %499
                ;
                int64_t v782 = v677 * v28;
                // pto: %499
                ;
                int64_t v783 = v781 * v782;
                // pto: %499
                ;
                pto::Shape<1, 1, 1, -1, 16> v784 = pto::Shape<1, 1, 1, -1, 16>(v779, v780, v781, v677, v33);
                // pto: %499
                ;
                pto::Stride<-1, -1, -1, -1, -1> v785 = pto::Stride<-1, -1, -1, -1, -1>(v780 * v783, v783, v782, v28, v29);
                // pto: %499
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v786 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v778 + (v777 + v683 * v28 + v776 * v29), v784, v785);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                TLOAD(v773, v786);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %v4_wide_wrap_w__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v787 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %v4_wide_wrap_w__tile
                ;
                uint64_t v788 = (uint64_t) v24;
                TASSIGN(v787, v788);
                // pto: %503
                ;
                int64_t v789 = v772 / v33;
                // pto: %504
                ;
                int64_t v790 = v789 < v45 ? v45 : v789;
                // pto: %505
                ;
                __gm__ bfloat16_t* v791 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                // pto: %505
                ;
                const int64_t v792 = 0;
                // pto: %505
                ;
                const int64_t v793 = 4194304;
                // pto: %505
                ;
                const int64_t v794 = 65536;
                // pto: %505
                ;
                const int64_t v795 = 256;
                // pto: %505
                ;
                pto::Shape<1, 8, 1, 16, 16> v796 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %505
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v797 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %505
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v798 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v791 + ((v792 + v699 * v793) + v701 * v794 + v790 * v795), v796, v797);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v787, v798);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %42
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v799 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v677, v33);
                // pto: %42
                ;
                uint64_t v800 = (uint64_t) v23;
                TASSIGN(v799, v800);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                uint16_t v801 = static_cast<uint16_t>(v45);
                uint16_t v802 = static_cast<uint16_t>(v45);
                TEXTRACT(v799, v773, v801, v802);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                // pto: %43
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v803 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %43
                ;
                uint64_t v804 = (uint64_t) v23;
                TASSIGN(v803, v804);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v805 = static_cast<uint16_t>(v45);
                uint16_t v806 = static_cast<uint16_t>(v45);
                TEXTRACT(v803, v787, v805, v806);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v720, v720, v799, v803);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          for (int64_t v807 = v56; v807 < v32; v807 += v29) {
            // pto: %506, %507
            ;
            int64_t v808 = (int64_t) ((uint64_t) v632 + (uint64_t) v807) % v32;
            // pto: %508, %509, %510
            ;
            int64_t v809 = v808 < v45 ? (int64_t) ((uint64_t) v808 + (uint64_t) v32) : v808;
            // pto: %511
            ;
            int64_t v810 = (int64_t) ((uint64_t) v809 * (uint64_t) v33);
            // pto: %v4_wide_tail_x__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v811 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v677, v33);
            // pto: %v4_wide_tail_x__tile
            ;
            uint64_t v812 = (uint64_t) v23;
            TASSIGN(v811, v812);
            // pto: %514
            ;
            int64_t v813 = (int64_t) ((uint64_t) v684 + (uint64_t) v810);
            // pto: %515
            ;
            int64_t v814 = v813 < v45 ? v45 : v813;
            // pto: %516
            ;
            const int64_t v815 = 0;
            // pto: %516
            ;
            __gm__ bfloat16_t* v816 = PTOAS__GLOBAL_TENSOR_DATA(v70);
            // pto: %516
            ;
            const int64_t v817 = 1;
            // pto: %516
            ;
            const int64_t v818 = 1;
            // pto: %516
            ;
            const int64_t v819 = 1;
            // pto: %516
            ;
            int64_t v820 = v677 * v28;
            // pto: %516
            ;
            int64_t v821 = v819 * v820;
            // pto: %516
            ;
            pto::Shape<1, 1, 1, -1, 16> v822 = pto::Shape<1, 1, 1, -1, 16>(v817, v818, v819, v677, v33);
            // pto: %516
            ;
            pto::Stride<-1, -1, -1, -1, -1> v823 = pto::Stride<-1, -1, -1, -1, -1>(v818 * v821, v821, v820, v28, v29);
            // pto: %516
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v824 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v816 + (v815 + v683 * v28 + v814 * v29), v822, v823);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            TLOAD(v811, v824);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %v4_wide_tail_w__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v825 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
            // pto: %v4_wide_tail_w__tile
            ;
            uint64_t v826 = (uint64_t) v24;
            TASSIGN(v825, v826);
            // pto: %520
            ;
            int64_t v827 = v810 / v33;
            // pto: %521
            ;
            int64_t v828 = v827 < v45 ? v45 : v827;
            // pto: %522
            ;
            __gm__ bfloat16_t* v829 = PTOAS__GLOBAL_TENSOR_DATA(v73);
            // pto: %522
            ;
            const int64_t v830 = 0;
            // pto: %522
            ;
            const int64_t v831 = 4194304;
            // pto: %522
            ;
            const int64_t v832 = 65536;
            // pto: %522
            ;
            const int64_t v833 = 256;
            // pto: %522
            ;
            pto::Shape<1, 8, 1, 16, 16> v834 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %522
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v835 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %522
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v836 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v829 + ((v830 + v699 * v831) + v701 * v832 + v828 * v833), v834, v835);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            TLOAD(v825, v836);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %44
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v837 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v677, v33);
            // pto: %44
            ;
            uint64_t v838 = (uint64_t) v23;
            TASSIGN(v837, v838);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            uint16_t v839 = static_cast<uint16_t>(v45);
            uint16_t v840 = static_cast<uint16_t>(v45);
            TEXTRACT(v837, v811, v839, v840);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            // pto: %45
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v841 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
            // pto: %45
            ;
            uint64_t v842 = (uint64_t) v23;
            TASSIGN(v841, v842);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v843 = static_cast<uint16_t>(v45);
            uint16_t v844 = static_cast<uint16_t>(v45);
            TEXTRACT(v841, v825, v843, v844);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v720, v720, v837, v841);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
          // pto: %524, %525
          ;
          int64_t v845 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v624 * (uint64_t) v55) + (uint64_t) v627);
          // pto: %526
          ;
          int64_t v846 = v845 < v45 ? v45 : v845;
          // pto: %527
          ;
          const int64_t v847 = 0;
          // pto: %527
          ;
          __gm__ float* v848 = PTOAS__GLOBAL_TENSOR_DATA(v94);
          // pto: %527
          ;
          const int64_t v849 = 1;
          // pto: %527
          ;
          const int64_t v850 = 1;
          // pto: %527
          ;
          const int64_t v851 = 1;
          // pto: %527
          ;
          int64_t v852 = v677 * v42;
          // pto: %527
          ;
          int64_t v853 = v851 * v852;
          // pto: %527
          ;
          pto::Shape<1, 1, 1, -1, 128> v854 = pto::Shape<1, 1, 1, -1, 128>(v849, v850, v851, v677, v36);
          // pto: %527
          ;
          pto::Stride<-1, -1, -1, -1, -1> v855 = pto::Stride<-1, -1, -1, -1, -1>(v850 * v853, v853, v852, v42, v29);
          // pto: %527
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v856 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v848 + (v847 + v683 * v42 + v846 * v29), v854, v855);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
          TSTORE(v856, v720);
        } else {
          for (int64_t v857 = v45; v857 < v30; v857 += v29) {
            // pto: %528
            ;
            int64_t v858 = (int64_t) ((uint64_t) v629 + (uint64_t) v857);
            // pto: %529
            ;
            if (v858 < v138) {
              // pto: %530
              ;
              int64_t v859 = (int64_t) ((uint64_t) v858 * (uint64_t) v33);
              // pto: %531
              ;
              int64_t v860 = (int64_t) ((uint64_t) v17 - (uint64_t) v859);
              // pto: %532
              ;
              int64_t v861 = v860 < v33 ? v860 : v33;
              // pto: %534, %535, %536, %537, %533
              ;
              int32_t v862 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v858 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
              // pto: %538
              ;
              int64_t v863 = (int64_t) v862;
              // pto: %539
              ;
              int64_t v864 = v863 < v45 ? v45 : v863;
              // pto: %v4_narrow_acc__tile
              ;
              Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v865 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %v4_narrow_acc__tile
              ;
              uint64_t v866 = (uint64_t) v23;
              TASSIGN(v865, v866);
              wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              for (int64_t v867 = v45; v867 < v33; v867 += v29) {
                // pto: %540
                ;
                int64_t v868 = (int64_t) ((uint64_t) v867 * (uint64_t) v33);
                // pto: %541, %542
                ;
                int64_t v869 = (int64_t) ((uint64_t) v864 + (uint64_t) v868) % v32;
                // pto: %543, %544, %545
                ;
                int64_t v870 = v869 < v45 ? (int64_t) ((uint64_t) v869 + (uint64_t) v32) : v869;
                // pto: %546
                ;
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                if (v870 <= v54) {
                  // pto: %547
                  ;
                  int64_t v871 = (int64_t) ((uint64_t) v870 * (uint64_t) v33);
                  // pto: %v4_narrow_packet_x__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v872 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v861, v32);
                  // pto: %v4_narrow_packet_x__tile
                  ;
                  uint64_t v873 = (uint64_t) v24;
                  TASSIGN(v872, v873);
                  // pto: %548
                  ;
                  int64_t v874 = v859 < v45 ? v45 : v859;
                  // pto: %549, %550
                  ;
                  int64_t v875 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v624 * (uint64_t) v41) + (uint64_t) v871);
                  // pto: %551
                  ;
                  int64_t v876 = v875 < v45 ? v45 : v875;
                  // pto: %552
                  ;
                  const int64_t v877 = 0;
                  // pto: %552
                  ;
                  __gm__ bfloat16_t* v878 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                  // pto: %552
                  ;
                  const int64_t v879 = 1;
                  // pto: %552
                  ;
                  const int64_t v880 = 1;
                  // pto: %552
                  ;
                  const int64_t v881 = 1;
                  // pto: %552
                  ;
                  int64_t v882 = v861 * v28;
                  // pto: %552
                  ;
                  int64_t v883 = v881 * v882;
                  // pto: %552
                  ;
                  pto::Shape<1, 1, 1, -1, 256> v884 = pto::Shape<1, 1, 1, -1, 256>(v879, v880, v881, v861, v32);
                  // pto: %552
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v885 = pto::Stride<-1, -1, -1, -1, -1>(v880 * v883, v883, v882, v28, v29);
                  // pto: %552
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v886 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v878 + (v877 + v874 * v28 + v876 * v29), v884, v885);
                  TLOAD(v872, v886);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  // pto: %v4_narrow_packet_w__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v887 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
                  // pto: %v4_narrow_packet_w__tile
                  ;
                  uint64_t v888 = (uint64_t) v23;
                  TASSIGN(v887, v888);
                  // pto: %553
                  ;
                  int64_t v889 = v624 < v45 ? v45 : v624;
                  // pto: %554
                  ;
                  int64_t v890 = v627 / v33;
                  // pto: %555
                  ;
                  int64_t v891 = v890 < v45 ? v45 : v890;
                  // pto: %556
                  ;
                  int64_t v892 = v871 / v33;
                  // pto: %557
                  ;
                  int64_t v893 = v892 < v45 ? v45 : v892;
                  // pto: %558
                  ;
                  __gm__ bfloat16_t* v894 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                  // pto: %558
                  ;
                  const int64_t v895 = 0;
                  // pto: %558
                  ;
                  const int64_t v896 = 4194304;
                  // pto: %558
                  ;
                  const int64_t v897 = 65536;
                  // pto: %558
                  ;
                  const int64_t v898 = 256;
                  // pto: %558
                  ;
                  pto::Shape<1, 8, 16, 16, 16> v899 = pto::Shape<1, 8, 16, 16, 16>();
                  // pto: %558
                  ;
                  pto::Stride<4194304, 65536, 256, 16, 1> v900 = pto::Stride<4194304, 65536, 256, 16, 1>();
                  // pto: %558
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v901 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v894 + ((v895 + v889 * v896) + v891 * v897 + v893 * v898), v899, v900);
                  TLOAD(v887, v901);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  // pto: %v4_narrow_acc__iter_v1_l0_a
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v902 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v861, v36);
                  // pto: %v4_narrow_acc__iter_v1_l0_a
                  ;
                  uint64_t v903 = (uint64_t) v23;
                  TASSIGN(v902, v903);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  uint16_t v904 = static_cast<uint16_t>(v45);
                  uint16_t v905 = static_cast<uint16_t>(v45);
                  TEXTRACT(v902, v872, v904, v905);
                  // pto: %v4_narrow_acc__iter_v1_l0_b
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v906 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %v4_narrow_acc__iter_v1_l0_b
                  ;
                  uint64_t v907 = (uint64_t) v23;
                  TASSIGN(v906, v907);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  uint16_t v908 = static_cast<uint16_t>(v45);
                  uint16_t v909 = static_cast<uint16_t>(v45);
                  TEXTRACT(v906, v887, v908, v909);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  // pto: %46
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v910 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v861, v36);
                  // pto: %46
                  ;
                  uint64_t v911 = (uint64_t) v25;
                  TASSIGN(v910, v911);
                  uint16_t v912 = static_cast<uint16_t>(v45);
                  uint16_t v913 = static_cast<uint16_t>(v36);
                  TEXTRACT(v910, v872, v912, v913);
                  // pto: %47
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v914 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %47
                  ;
                  uint64_t v915 = (uint64_t) v25;
                  TASSIGN(v914, v915);
                  uint16_t v916 = static_cast<uint16_t>(v36);
                  uint16_t v917 = static_cast<uint16_t>(v45);
                  TEXTRACT(v914, v887, v916, v917);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  // pto: %559
                  ;
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  if (v867 == v45) {
                    pipe_barrier(PIPE_M);
                    TMATMUL(v865, v902, v906);
                  } else {
                    pipe_barrier(PIPE_M);
                    TMATMUL_ACC(v865, v865, v902, v906);
                  };
                  pipe_barrier(PIPE_M);
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  TMATMUL_ACC(v865, v865, v910, v914);
                } else {
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  for (int64_t v918 = v45; v918 < v33; v918 += v29) {
                    // pto: %560, %561
                    ;
                    int64_t v919 = (int64_t) ((uint64_t) v870 + (uint64_t) v918) % v32;
                    // pto: %562, %563, %564
                    ;
                    int64_t v920 = v919 < v45 ? (int64_t) ((uint64_t) v919 + (uint64_t) v32) : v919;
                    // pto: %565
                    ;
                    int64_t v921 = (int64_t) ((uint64_t) v920 * (uint64_t) v33);
                    // pto: %v4_narrow_wrap_x__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v922 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v861, v33);
                    // pto: %v4_narrow_wrap_x__tile
                    ;
                    uint64_t v923 = (uint64_t) v24;
                    TASSIGN(v922, v923);
                    // pto: %566
                    ;
                    int64_t v924 = v859 < v45 ? v45 : v859;
                    // pto: %567, %568
                    ;
                    int64_t v925 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v624 * (uint64_t) v41) + (uint64_t) v921);
                    // pto: %569
                    ;
                    int64_t v926 = v925 < v45 ? v45 : v925;
                    // pto: %570
                    ;
                    const int64_t v927 = 0;
                    // pto: %570
                    ;
                    __gm__ bfloat16_t* v928 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                    // pto: %570
                    ;
                    const int64_t v929 = 1;
                    // pto: %570
                    ;
                    const int64_t v930 = 1;
                    // pto: %570
                    ;
                    const int64_t v931 = 1;
                    // pto: %570
                    ;
                    int64_t v932 = v861 * v28;
                    // pto: %570
                    ;
                    int64_t v933 = v931 * v932;
                    // pto: %570
                    ;
                    pto::Shape<1, 1, 1, -1, 16> v934 = pto::Shape<1, 1, 1, -1, 16>(v929, v930, v931, v861, v33);
                    // pto: %570
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v935 = pto::Stride<-1, -1, -1, -1, -1>(v930 * v933, v933, v932, v28, v29);
                    // pto: %570
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v936 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v928 + (v927 + v924 * v28 + v926 * v29), v934, v935);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v922, v936);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    // pto: %v4_narrow_wrap_w__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v937 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %v4_narrow_wrap_w__tile
                    ;
                    uint64_t v938 = (uint64_t) v23;
                    TASSIGN(v937, v938);
                    // pto: %571
                    ;
                    int64_t v939 = v624 < v45 ? v45 : v624;
                    // pto: %572
                    ;
                    int64_t v940 = v627 / v33;
                    // pto: %573
                    ;
                    int64_t v941 = v940 < v45 ? v45 : v940;
                    // pto: %574
                    ;
                    int64_t v942 = v921 / v33;
                    // pto: %575
                    ;
                    int64_t v943 = v942 < v45 ? v45 : v942;
                    // pto: %576
                    ;
                    __gm__ bfloat16_t* v944 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                    // pto: %576
                    ;
                    const int64_t v945 = 0;
                    // pto: %576
                    ;
                    const int64_t v946 = 4194304;
                    // pto: %576
                    ;
                    const int64_t v947 = 65536;
                    // pto: %576
                    ;
                    const int64_t v948 = 256;
                    // pto: %576
                    ;
                    pto::Shape<1, 8, 1, 16, 16> v949 = pto::Shape<1, 8, 1, 16, 16>();
                    // pto: %576
                    ;
                    pto::Stride<4194304, 65536, 256, 16, 1> v950 = pto::Stride<4194304, 65536, 256, 16, 1>();
                    // pto: %576
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v951 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v944 + ((v945 + v939 * v946) + v941 * v947 + v943 * v948), v949, v950);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    TLOAD(v937, v951);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    // pto: %49
                    ;
                    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v952 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v861, v33);
                    // pto: %49
                    ;
                    uint64_t v953 = (uint64_t) v23;
                    TASSIGN(v952, v953);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                    uint16_t v954 = static_cast<uint16_t>(v45);
                    uint16_t v955 = static_cast<uint16_t>(v45);
                    TEXTRACT(v952, v922, v954, v955);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    // pto: %50
                    ;
                    Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v956 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %50
                    ;
                    uint64_t v957 = (uint64_t) v23;
                    TASSIGN(v956, v957);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    uint16_t v958 = static_cast<uint16_t>(v45);
                    uint16_t v959 = static_cast<uint16_t>(v45);
                    TEXTRACT(v956, v937, v958, v959);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    // pto: %578, %579
                    ;
                    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    if ((int64_t) ((uint64_t) v868 + (uint64_t) v918) == v45) {
                      pipe_barrier(PIPE_M);
                      TMATMUL(v865, v952, v956);
                    } else {
                      pipe_barrier(PIPE_M);
                      TMATMUL_ACC(v865, v865, v952, v956);
                    };
                    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  };
                  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
              // pto: %580
              ;
              int64_t v960 = v859 < v45 ? v45 : v859;
              // pto: %581, %582
              ;
              int64_t v961 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v624 * (uint64_t) v55) + (uint64_t) v627);
              // pto: %583
              ;
              int64_t v962 = v961 < v45 ? v45 : v961;
              // pto: %584
              ;
              __gm__ float* v963 = PTOAS__GLOBAL_TENSOR_DATA(v94);
              // pto: %584
              ;
              const int64_t v964 = 0;
              // pto: %584
              ;
              const int64_t v965 = 8192;
              // pto: %584
              ;
              pto::Shape<1, 1, 1, 16, 128> v966 = pto::Shape<1, 1, 1, 16, 128>();
              // pto: %584
              ;
              pto::Stride<131072, 131072, 131072, 8192, 1> v967 = pto::Stride<131072, 131072, 131072, 8192, 1>();
              // pto: %584
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v968 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v963 + (v964 + v960 * v965 + v962), v966, v967);
              wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
              pipe_barrier(PIPE_FIX);
              TSTORE(v968, v865);
              set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
            };
          };
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    };
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %586
  int64_t v969 = (int64_t) ((uint64_t) v127 + (uint64_t) v57);
  // pto: %587
  int64_t v970 = v969 < v45 ? v45 : v969;
  // pto: %signals__ssa_v1_signal_pview
  __gm__ int32_t* v971 = PTOAS__GLOBAL_TENSOR_DATA(v113);
  // pto: %signals__ssa_v1_signal_pview
  const int64_t v972 = 0;
  // pto: %signals__ssa_v1_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v973 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v974 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v975 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v971 + (v972 + v970), v973, v974);
  pto::comm::NotifyOp v976 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v975, v136, v976);
  for (int64_t v977 = v48; v977 < v58; v977 += v29) {
    // pto: %588, %589
    ;
    int64_t v978 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v977 * (uint64_t) v36) + (uint64_t) v59);
    // pto: %590
    ;
    int64_t v979 = v978 < v45 ? v45 : v978;
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v980 = PTOAS__GLOBAL_TENSOR_DATA(v113);
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    const int64_t v981 = 0;
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v982 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v983 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v984 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v980 + (v981 + v979), v982, v983);
    pto::comm::WaitCmp v985 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v984, v136, v985);
  }
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %591
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  if (v17 <= v33) {
    // pto: %592
    ;
    for (int64_t v986 = v126; v986 < ((int64_t) ((uint64_t) v138 * (uint64_t) v38)); v986 += v48) {
      // pto: %593, %594
      ;
      int64_t v987 = (int64_t) ((uint64_t) (v986 / v38) * (uint64_t) v33);
      // pto: %595
      ;
      int64_t v988 = v986 % v38;
      // pto: %596, %597, %598
      ;
      int64_t v989 = v988 < v45 ? (int64_t) ((uint64_t) v988 + (uint64_t) v38) : v988;
      // pto: %599
      ;
      int64_t v990 = (int64_t) ((uint64_t) v989 * (uint64_t) v36);
      // pto: %600
      ;
      int64_t v991 = (int64_t) ((uint64_t) v17 - (uint64_t) v987);
      // pto: %601
      ;
      int64_t v992 = v991 < v33 ? v991 : v33;
      // pto: %b_acc__tile
      ;
      Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v993 = Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
      // pto: %b_acc__tile
      ;
      uint64_t v994 = (uint64_t) v23;
      TASSIGN(v993, v994);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      for (int64_t v995 = v45; v995 < v33; v995 += v29) {
        // pto: %602
        ;
        int64_t v996 = (int64_t) ((uint64_t) v995 * (uint64_t) v37);
        // pto: %b_input__tile
        ;
        Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v997 = Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v992, v37);
        // pto: %b_input__tile
        ;
        uint64_t v998 = (uint64_t) v24;
        TASSIGN(v997, v998);
        // pto: %603
        ;
        int64_t v999 = v987 < v45 ? v45 : v987;
        // pto: %604
        ;
        int64_t v1000 = v996 < v45 ? v45 : v996;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v1001 = 0;
        // pto: %quantized__ssa_v0_pview
        ;
        __gm__ int8_t* v1002 = PTOAS__GLOBAL_TENSOR_DATA(v85);
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v1003 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v1004 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v1005 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        int64_t v1006 = v992 * v42;
        // pto: %quantized__ssa_v0_pview
        ;
        int64_t v1007 = v1005 * v1006;
        // pto: %quantized__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 512> v1008 = pto::Shape<1, 1, 1, -1, 512>(v1003, v1004, v1005, v992, v37);
        // pto: %quantized__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1009 = pto::Stride<-1, -1, -1, -1, -1>(v1004 * v1007, v1007, v1006, v42, v29);
        // pto: %quantized__ssa_v0_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1010 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1002 + (v1001 + v999 * v42 + v1000 * v29), v1008, v1009);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v997, v1010);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %b_weight__tile
        ;
        Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1011 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v37, v36);
        // pto: %b_weight__tile
        ;
        uint64_t v1012 = (uint64_t) v23;
        TASSIGN(v1011, v1012);
        // pto: %605
        ;
        int64_t v1013 = v990 / v38;
        // pto: %606
        ;
        int64_t v1014 = v1013 < v45 ? v45 : v1013;
        // pto: %607
        ;
        int64_t v1015 = v996 / v33;
        // pto: %608
        ;
        int64_t v1016 = v1015 < v45 ? v45 : v1015;
        // pto: %wo_b__ssa_v0_pview
        ;
        __gm__ int8_t* v1017 = PTOAS__GLOBAL_TENSOR_DATA(v76);
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v1018 = 0;
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v1019 = 262144;
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v1020 = 512;
        // pto: %wo_b__ssa_v0_pview
        ;
        pto::Shape<1, 4, 32, 16, 32> v1021 = pto::Shape<1, 4, 32, 16, 32>();
        // pto: %wo_b__ssa_v0_pview
        ;
        pto::Stride<33554432, 262144, 512, 32, 1> v1022 = pto::Stride<33554432, 262144, 512, 32, 1>();
        // pto: %wo_b__ssa_v0_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v1023 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v1017 + (v1018 + v1014 * v1019 + v1016 * v1020), v1021, v1022);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v1011, v1023);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %b_acc__tile_l0_a
        ;
        Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1024 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v992, v32);
        // pto: %b_acc__tile_l0_a
        ;
        uint64_t v1025 = (uint64_t) v23;
        TASSIGN(v1024, v1025);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        uint16_t v1026 = static_cast<uint16_t>(v45);
        uint16_t v1027 = static_cast<uint16_t>(v45);
        TEXTRACT(v1024, v997, v1026, v1027);
        // pto: %b_acc__tile_l0_b
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1028 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %b_acc__tile_l0_b
        ;
        uint64_t v1029 = (uint64_t) v23;
        TASSIGN(v1028, v1029);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v1030 = static_cast<uint16_t>(v45);
        uint16_t v1031 = static_cast<uint16_t>(v45);
        TEXTRACT(v1028, v1011, v1030, v1031);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %51
        ;
        Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1032 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v992, v32);
        // pto: %51
        ;
        uint64_t v1033 = (uint64_t) v25;
        TASSIGN(v1032, v1033);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v1034 = static_cast<uint16_t>(v45);
        uint16_t v1035 = static_cast<uint16_t>(v32);
        TEXTRACT(v1032, v997, v1034, v1035);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        // pto: %52
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1036 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %52
        ;
        uint64_t v1037 = (uint64_t) v25;
        TASSIGN(v1036, v1037);
        uint16_t v1038 = static_cast<uint16_t>(v32);
        uint16_t v1039 = static_cast<uint16_t>(v45);
        TEXTRACT(v1036, v1011, v1038, v1039);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %609
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v995 == v45) {
          pipe_barrier(PIPE_M);
          TMATMUL(v993, v1024, v1028);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v993, v993, v1024, v1028);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v993, v993, v1032, v1036);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
      // pto: %610
      ;
      int64_t v1040 = v987 < v45 ? v45 : v987;
      // pto: %611
      ;
      int64_t v1041 = v990 < v45 ? v45 : v990;
      // pto: %integer_accum__ssa_v0_pview
      ;
      __gm__ int32_t* v1042 = PTOAS__GLOBAL_TENSOR_DATA(v103);
      // pto: %integer_accum__ssa_v0_pview
      ;
      const int64_t v1043 = 0;
      // pto: %integer_accum__ssa_v0_pview
      ;
      const int64_t v1044 = 4096;
      // pto: %integer_accum__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 128> v1045 = pto::Shape<1, 1, 1, 16, 128>();
      // pto: %integer_accum__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v1046 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %integer_accum__ssa_v0_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v1047 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v1042 + (v1043 + v1040 * v1044 + v1041), v1045, v1046);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
      pipe_barrier(PIPE_FIX);
      TSTORE(v1047, v993);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
    };
  } else {
    // pto: %612, %613, %614
    ;
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    for (int64_t v1048 = v126; v1048 < ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v60) / v31) * (uint64_t) v38)); v1048 += v48) {
      // pto: %615, %616
      ;
      int64_t v1049 = (int64_t) ((uint64_t) (v1048 / v38) * (uint64_t) v31);
      // pto: %617
      ;
      int64_t v1050 = v1048 % v38;
      // pto: %618, %619, %620
      ;
      int64_t v1051 = v1050 < v45 ? (int64_t) ((uint64_t) v1050 + (uint64_t) v38) : v1050;
      // pto: %621
      ;
      int64_t v1052 = (int64_t) ((uint64_t) v1051 * (uint64_t) v36);
      // pto: %622
      ;
      int64_t v1053 = (int64_t) ((uint64_t) v17 - (uint64_t) v1049);
      // pto: %623
      ;
      int64_t v1054 = v1053 < v31 ? v1053 : v31;
      // pto: %wide_first_input__tile
      ;
      Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1055 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v1054, v37);
      // pto: %wide_first_input__tile
      ;
      uint64_t v1056 = (uint64_t) v24;
      TASSIGN(v1055, v1056);
      // pto: %624
      ;
      int64_t v1057 = v1049 < v45 ? v45 : v1049;
      // pto: %625
      ;
      const int64_t v1058 = 0;
      // pto: %625
      ;
      __gm__ int8_t* v1059 = PTOAS__GLOBAL_TENSOR_DATA(v85);
      // pto: %625
      ;
      const int64_t v1060 = 1;
      // pto: %625
      ;
      const int64_t v1061 = 1;
      // pto: %625
      ;
      const int64_t v1062 = 1;
      // pto: %625
      ;
      int64_t v1063 = v1054 * v42;
      // pto: %625
      ;
      int64_t v1064 = v1062 * v1063;
      // pto: %625
      ;
      pto::Shape<1, 1, 1, -1, 512> v1065 = pto::Shape<1, 1, 1, -1, 512>(v1060, v1061, v1062, v1054, v37);
      // pto: %625
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1066 = pto::Stride<-1, -1, -1, -1, -1>(v1061 * v1064, v1064, v1063, v42, v29);
      // pto: %625
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1067 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1059 + (v1058 + v1057 * v42 + v45 * v29), v1065, v1066);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v1055, v1067);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %wide_first_weight__tile
      ;
      Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1068 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v37, v36);
      // pto: %wide_first_weight__tile
      ;
      uint64_t v1069 = (uint64_t) v23;
      TASSIGN(v1068, v1069);
      // pto: %626
      ;
      int64_t v1070 = v1052 / v38;
      // pto: %627
      ;
      int64_t v1071 = v1070 < v45 ? v45 : v1070;
      // pto: %628
      ;
      __gm__ int8_t* v1072 = PTOAS__GLOBAL_TENSOR_DATA(v76);
      // pto: %628
      ;
      const int64_t v1073 = 0;
      // pto: %628
      ;
      const int64_t v1074 = 262144;
      // pto: %628
      ;
      pto::Shape<1, 4, 32, 16, 32> v1075 = pto::Shape<1, 4, 32, 16, 32>();
      // pto: %628
      ;
      pto::Stride<33554432, 262144, 512, 32, 1> v1076 = pto::Stride<33554432, 262144, 512, 32, 1>();
      // pto: %628
      ;
      GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v1077 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v1072 + (v1073 + v1071 * v1074), v1075, v1076);
      TLOAD(v1068, v1077);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %wide_b_acc__tile_l0_init_storage
      ;
      Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v1078 = Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v31, v36);
      // pto: %wide_b_acc__tile_l0_init_storage
      ;
      uint64_t v1079 = (uint64_t) v23;
      TASSIGN(v1078, v1079);
      v1078.SetValidShape(v1054, v36);
      // pto: %wide_b_acc__tile_l0_a
      ;
      Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1080 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v1054, v32);
      // pto: %wide_b_acc__tile_l0_a
      ;
      uint64_t v1081 = (uint64_t) v23;
      TASSIGN(v1080, v1081);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      uint16_t v1082 = static_cast<uint16_t>(v45);
      uint16_t v1083 = static_cast<uint16_t>(v45);
      TEXTRACT(v1080, v1055, v1082, v1083);
      // pto: %wide_b_acc__tile_l0_b
      ;
      Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1084 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
      // pto: %wide_b_acc__tile_l0_b
      ;
      uint64_t v1085 = (uint64_t) v23;
      TASSIGN(v1084, v1085);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      uint16_t v1086 = static_cast<uint16_t>(v45);
      uint16_t v1087 = static_cast<uint16_t>(v45);
      TEXTRACT(v1084, v1068, v1086, v1087);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %54
      ;
      Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1088 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v1054, v32);
      // pto: %54
      ;
      uint64_t v1089 = (uint64_t) v25;
      TASSIGN(v1088, v1089);
      uint16_t v1090 = static_cast<uint16_t>(v45);
      uint16_t v1091 = static_cast<uint16_t>(v32);
      TEXTRACT(v1088, v1055, v1090, v1091);
      // pto: %55
      ;
      Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1092 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
      // pto: %55
      ;
      uint64_t v1093 = (uint64_t) v25;
      TASSIGN(v1092, v1093);
      uint16_t v1094 = static_cast<uint16_t>(v32);
      uint16_t v1095 = static_cast<uint16_t>(v45);
      TEXTRACT(v1092, v1068, v1094, v1095);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
      TMATMUL(v1078, v1080, v1084);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v1078, v1078, v1088, v1092);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t v1096 = v29; v1096 < v33; v1096 += v29) {
        // pto: %629
        ;
        int64_t v1097 = (int64_t) ((uint64_t) v1096 * (uint64_t) v37);
        // pto: %wide_b_input__tile
        ;
        Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1098 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v1054, v37);
        // pto: %wide_b_input__tile
        ;
        uint64_t v1099 = (uint64_t) v24;
        TASSIGN(v1098, v1099);
        // pto: %631
        ;
        int64_t v1100 = v1097 < v45 ? v45 : v1097;
        // pto: %632
        ;
        const int64_t v1101 = 0;
        // pto: %632
        ;
        __gm__ int8_t* v1102 = PTOAS__GLOBAL_TENSOR_DATA(v85);
        // pto: %632
        ;
        const int64_t v1103 = 1;
        // pto: %632
        ;
        const int64_t v1104 = 1;
        // pto: %632
        ;
        const int64_t v1105 = 1;
        // pto: %632
        ;
        int64_t v1106 = v1054 * v42;
        // pto: %632
        ;
        int64_t v1107 = v1105 * v1106;
        // pto: %632
        ;
        pto::Shape<1, 1, 1, -1, 512> v1108 = pto::Shape<1, 1, 1, -1, 512>(v1103, v1104, v1105, v1054, v37);
        // pto: %632
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1109 = pto::Stride<-1, -1, -1, -1, -1>(v1104 * v1107, v1107, v1106, v42, v29);
        // pto: %632
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1110 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1102 + (v1101 + v1057 * v42 + v1100 * v29), v1108, v1109);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v1098, v1110);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %wide_b_weight__tile
        ;
        Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1111 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v37, v36);
        // pto: %wide_b_weight__tile
        ;
        uint64_t v1112 = (uint64_t) v23;
        TASSIGN(v1111, v1112);
        // pto: %635
        ;
        int64_t v1113 = v1097 / v33;
        // pto: %636
        ;
        int64_t v1114 = v1113 < v45 ? v45 : v1113;
        // pto: %637
        ;
        __gm__ int8_t* v1115 = PTOAS__GLOBAL_TENSOR_DATA(v76);
        // pto: %637
        ;
        const int64_t v1116 = 0;
        // pto: %637
        ;
        const int64_t v1117 = 262144;
        // pto: %637
        ;
        const int64_t v1118 = 512;
        // pto: %637
        ;
        pto::Shape<1, 4, 32, 16, 32> v1119 = pto::Shape<1, 4, 32, 16, 32>();
        // pto: %637
        ;
        pto::Stride<33554432, 262144, 512, 32, 1> v1120 = pto::Stride<33554432, 262144, 512, 32, 1>();
        // pto: %637
        ;
        GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v1121 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v1115 + (v1116 + v1071 * v1117 + v1114 * v1118), v1119, v1120);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        TLOAD(v1111, v1121);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %57
        ;
        Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1122 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v1054, v32);
        // pto: %57
        ;
        uint64_t v1123 = (uint64_t) v23;
        TASSIGN(v1122, v1123);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v1124 = static_cast<uint16_t>(v45);
        uint16_t v1125 = static_cast<uint16_t>(v45);
        TEXTRACT(v1122, v1098, v1124, v1125);
        // pto: %58
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1126 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %58
        ;
        uint64_t v1127 = (uint64_t) v23;
        TASSIGN(v1126, v1127);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v1128 = static_cast<uint16_t>(v45);
        uint16_t v1129 = static_cast<uint16_t>(v45);
        TEXTRACT(v1126, v1111, v1128, v1129);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %59
        ;
        Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1130 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v1054, v32);
        // pto: %59
        ;
        uint64_t v1131 = (uint64_t) v25;
        TASSIGN(v1130, v1131);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1132 = static_cast<uint16_t>(v45);
        uint16_t v1133 = static_cast<uint16_t>(v32);
        TEXTRACT(v1130, v1098, v1132, v1133);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        // pto: %60
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1134 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %60
        ;
        uint64_t v1135 = (uint64_t) v25;
        TASSIGN(v1134, v1135);
        uint16_t v1136 = static_cast<uint16_t>(v32);
        uint16_t v1137 = static_cast<uint16_t>(v45);
        TEXTRACT(v1134, v1111, v1136, v1137);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v1078, v1078, v1122, v1126);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v1078, v1078, v1130, v1134);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
      // pto: %639
      ;
      int64_t v1138 = v1052 < v45 ? v45 : v1052;
      // pto: %640
      ;
      const int64_t v1139 = 0;
      // pto: %640
      ;
      __gm__ int32_t* v1140 = PTOAS__GLOBAL_TENSOR_DATA(v103);
      // pto: %640
      ;
      const int64_t v1141 = 1;
      // pto: %640
      ;
      const int64_t v1142 = 1;
      // pto: %640
      ;
      const int64_t v1143 = 1;
      // pto: %640
      ;
      int64_t v1144 = v1054 * v41;
      // pto: %640
      ;
      int64_t v1145 = v1143 * v1144;
      // pto: %640
      ;
      pto::Shape<1, 1, 1, -1, 128> v1146 = pto::Shape<1, 1, 1, -1, 128>(v1141, v1142, v1143, v1054, v36);
      // pto: %640
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1147 = pto::Stride<-1, -1, -1, -1, -1>(v1142 * v1145, v1145, v1144, v41, v29);
      // pto: %640
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1148 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1140 + (v1139 + v1057 * v41 + v1138 * v29), v1146, v1147);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
      TSTORE(v1148, v1078);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    };
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %642
  int64_t v1149 = (int64_t) ((uint64_t) v127 + (uint64_t) v61);
  // pto: %643
  int64_t v1150 = v1149 < v45 ? v45 : v1149;
  // pto: %signals_v2__ssa_v0_signal_pview
  __gm__ int32_t* v1151 = PTOAS__GLOBAL_TENSOR_DATA(v113);
  // pto: %signals_v2__ssa_v0_signal_pview
  const int64_t v1152 = 0;
  // pto: %signals_v2__ssa_v0_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v1153 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals_v2__ssa_v0_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v1154 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals_v2__ssa_v0_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v1155 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v1151 + (v1152 + v1150), v1153, v1154);
  pto::comm::NotifyOp v1156 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v1155, v136, v1156);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void vector(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21, int32_t v22) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int32_t v23 = 1;
  // pto: %c0_i64
  const int64_t v24 = 0;
  // pto: %c32768_i64
  const int64_t v25 = 32768;
  // pto: %c65536_i64
  const int64_t v26 = 65536;
  // pto: %c65568_i64
  const int64_t v27 = 65568;
  // pto: %c32_i64
  const int64_t v28 = 32;
  // pto: %c64_i64
  const int64_t v29 = 64;
  // pto: %c49152_i64
  const int64_t v30 = 49152;
  // pto: %c34816_i64
  const int64_t v31 = 34816;
  // pto: %c16384_i64
  const int64_t v32 = 16384;
  // pto: %c81920_i64
  const int64_t v33 = 81920;
  // pto: %c98304_i64
  const int64_t v34 = 98304;
  // pto: %c114688_i64
  const int64_t v35 = 114688;
  // pto: %c122880_i64
  const int64_t v36 = 122880;
  // pto: %c1_index
  const int64_t v37 = 1;
  // pto: %c8_index
  const int64_t v38 = 8;
  // pto: %c64_index
  const int64_t v39 = 64;
  // pto: %c16_index
  const int64_t v40 = 16;
  // pto: %c128_index
  const int64_t v41 = 128;
  // pto: %c512_index
  const int64_t v42 = 512;
  // pto: %c32_index
  const int64_t v43 = 32;
  // pto: %c4096_index
  const int64_t v44 = 4096;
  // pto: %c8192_index
  const int64_t v45 = 8192;
  // pto: %c16384_index
  const int64_t v46 = 16384;
  // pto: %c4_index
  const int64_t v47 = 4;
  // pto: %c55296_index
  const int64_t v48 = 55296;
  // pto: %c2_index
  const int64_t v49 = 2;
  // pto: %c24_index
  const int64_t v50 = 24;
  // pto: %c0_index
  const int64_t v51 = 0;
  // pto: %c15_index
  const int64_t v52 = 15;
  // pto: %c9216_index
  const int64_t v53 = 9216;
  // pto: %c48_index
  const int64_t v54 = 48;
  // pto: %c1024_index
  const int64_t v55 = 1024;
  // pto: %c18432_index
  const int64_t v56 = 18432;
  // pto: %c7_index
  const int64_t v57 = 7;
  // pto: %c21504_index
  const int64_t v58 = 21504;
  // pto: %cst_41
  const float v59 = 0.00787401571f;
  // pto: %cst_42
  const float v60 = 0.0f;
  // pto: %cst_43
  const float v61 = 1.0f;
  // pto: %cst_44
  const float v62 = 127.0f;
  // pto: %c27648_index
  const int64_t v63 = 27648;
  // pto: %c30720_index
  const int64_t v64 = 30720;
  // pto: %c36864_index
  const int64_t v65 = 36864;
  // pto: %c46080_index
  const int64_t v66 = 46080;
  // pto: %c72_index
  const int64_t v67 = 72;
  // pto: %c3_index
  const int64_t v68 = 3;
  // pto: %c12_index
  const int64_t v69 = 12;
  // pto: %c5_index
  const int64_t v70 = 5;
  // pto: %c9_index
  const int64_t v71 = 9;
  // pto: %c13_index
  const int64_t v72 = 13;
  // pto: %c6_index
  const int64_t v73 = 6;
  // pto: %c10_index
  const int64_t v74 = 10;
  // pto: %c14_index
  const int64_t v75 = 14;
  // pto: %c11_index
  const int64_t v76 = 11;
  // pto: %c12288_index
  const int64_t v77 = 12288;
  // pto: %cn1_index
  const int64_t v78 = -1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v79 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v80 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v81 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v82 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v83 = v44 * v37;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v84 = v82 * v83;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v85 = v81 * v84;
  // pto: %wo_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v86 = pto::Shape<1, 1, 1, 1, -1>(v79, v80, v81, v82, v44);
  // pto: %wo_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v87 = pto::Stride<-1, -1, -1, -1, -1>(v80 * v85, v85, v84, v83, v37);
  // pto: %wo_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v88 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v86, v87);
  // pto: %projected__ssa_v0_view
  const int64_t v89 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v90 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v91 = 1;
  // pto: %projected__ssa_v0_view
  int64_t v92 = (int64_t) v17;
  // pto: %projected__ssa_v0_view
  int64_t v93 = v92 * v45;
  // pto: %projected__ssa_v0_view
  int64_t v94 = v91 * v93;
  // pto: %projected__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v95 = pto::Shape<1, 1, 1, -1, -1>(v89, v90, v91, v92, v45);
  // pto: %projected__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v96 = pto::Stride<-1, -1, -1, -1, -1>(v90 * v94, v94, v93, v45, v37);
  // pto: %projected__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v97 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v95, v96);
  // pto: %quantized__ssa_v0_view
  const int64_t v98 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v99 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v100 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v101 = (int64_t) v17;
  // pto: %quantized__ssa_v0_view
  int64_t v102 = v101 * v45;
  // pto: %quantized__ssa_v0_view
  int64_t v103 = v100 * v102;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v104 = pto::Shape<1, 1, 1, -1, -1>(v98, v99, v100, v101, v45);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v105 = pto::Stride<-1, -1, -1, -1, -1>(v99 * v103, v103, v102, v45, v37);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v106 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v104, v105);
  // pto: %token_scale__ssa_v0_view
  const int64_t v107 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v108 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v109 = 1;
  // pto: %token_scale__ssa_v0_view
  int64_t v110 = (int64_t) v17;
  // pto: %token_scale__ssa_v0_view
  int64_t v111 = v110 * v37;
  // pto: %token_scale__ssa_v0_view
  int64_t v112 = v109 * v111;
  // pto: %token_scale__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v113 = pto::Shape<1, 1, 1, -1, -1>(v107, v108, v109, v110, v37);
  // pto: %token_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v114 = pto::Stride<-1, -1, -1, -1, -1>(v108 * v112, v112, v111, v37, (int64_t) v17);
  // pto: %token_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v115 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v8, v113, v114);
  // pto: %attended__ssa_v0_view
  const int64_t v116 = 1;
  // pto: %attended__ssa_v0_view
  const int64_t v117 = 1;
  // pto: %attended__ssa_v0_view
  const int64_t v118 = 1;
  // pto: %attended__ssa_v0_view
  int64_t v119 = (int64_t) v17;
  // pto: %attended__ssa_v0_view
  int64_t v120 = v119 * v44;
  // pto: %attended__ssa_v0_view
  int64_t v121 = v118 * v120;
  // pto: %attended__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v122 = pto::Shape<1, 1, 1, -1, -1>(v116, v117, v118, v119, v44);
  // pto: %attended__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v123 = pto::Stride<-1, -1, -1, -1, -1>(v117 * v121, v121, v120, v44, v37);
  // pto: %attended__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v124 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v122, v123);
  // pto: %residual__ssa_v0_view
  const int64_t v125 = 1;
  // pto: %residual__ssa_v0_view
  const int64_t v126 = 1;
  // pto: %residual__ssa_v0_view
  const int64_t v127 = 1;
  // pto: %residual__ssa_v0_view
  int64_t v128 = (int64_t) v17;
  // pto: %residual__ssa_v0_view
  int64_t v129 = v128 * v46;
  // pto: %residual__ssa_v0_view
  int64_t v130 = v127 * v129;
  // pto: %residual__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v131 = pto::Shape<1, 1, 1, -1, -1>(v125, v126, v127, v128, v46);
  // pto: %residual__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v132 = pto::Stride<-1, -1, -1, -1, -1>(v126 * v130, v130, v129, v46, v37);
  // pto: %residual__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v133 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v131, v132);
  // pto: %output__ssa_v0_view
  const int64_t v134 = 1;
  // pto: %output__ssa_v0_view
  const int64_t v135 = 1;
  // pto: %output__ssa_v0_view
  const int64_t v136 = 1;
  // pto: %output__ssa_v0_view
  int64_t v137 = (int64_t) v17;
  // pto: %output__ssa_v0_view
  int64_t v138 = v137 * v46;
  // pto: %output__ssa_v0_view
  int64_t v139 = v136 * v138;
  // pto: %output__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v140 = pto::Shape<1, 1, 1, -1, -1>(v134, v135, v136, v137, v46);
  // pto: %output__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v141 = pto::Stride<-1, -1, -1, -1, -1>(v135 * v139, v139, v138, v46, v37);
  // pto: %output__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v142 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v140, v141);
  // pto: %accum__ssa_v0_view
  const int64_t v143 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v144 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v145 = 1;
  // pto: %accum__ssa_v0_view
  int64_t v146 = (int64_t) v18;
  // pto: %accum__ssa_v0_view
  int64_t v147 = v146 * v45;
  // pto: %accum__ssa_v0_view
  int64_t v148 = v145 * v147;
  // pto: %accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v149 = pto::Shape<1, 1, 1, -1, -1>(v143, v144, v145, v146, v45);
  // pto: %accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v150 = pto::Stride<-1, -1, -1, -1, -1>(v144 * v148, v148, v147, v45, v37);
  // pto: %accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v151 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v149, v150);
  // pto: %integer_accum__ssa_v0_view
  const int64_t v152 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v153 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v154 = 1;
  // pto: %integer_accum__ssa_v0_view
  int64_t v155 = (int64_t) v19;
  // pto: %integer_accum__ssa_v0_view
  int64_t v156 = v155 * v44;
  // pto: %integer_accum__ssa_v0_view
  int64_t v157 = v154 * v156;
  // pto: %integer_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v158 = pto::Shape<1, 1, 1, -1, -1>(v152, v153, v154, v155, v44);
  // pto: %integer_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v159 = pto::Stride<-1, -1, -1, -1, -1>(v153 * v157, v157, v156, v44, v37);
  // pto: %integer_accum__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v160 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v158, v159);
  // pto: %signals__ssa_v0_view
  const int64_t v161 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v162 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v163 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v164 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v165 = v48 * v37;
  // pto: %signals__ssa_v0_view
  int64_t v166 = v164 * v165;
  // pto: %signals__ssa_v0_view
  int64_t v167 = v163 * v166;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v168 = pto::Shape<1, 1, 1, 1, -1>(v161, v162, v163, v164, v48);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v169 = pto::Stride<-1, -1, -1, -1, -1>(v162 * v167, v167, v166, v165, v37);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v170 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v168, v169);
  // pto: %t__tmp_v0, %145, %146, %t__tmp_v1
  int64_t v171 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v20) * (uint64_t) v49) + (uint64_t) ((int64_t) v22));
  // pto: %147, %148
  int64_t v172 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v171 + (uint64_t) v50) * (uint64_t) v41);
  // pto: %149
  int64_t v173 = v172 < v51 ? v51 : v172;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v174 = PTOAS__GLOBAL_TENSOR_DATA(v170);
  // pto: %signals__ssa_v0_pview
  const int64_t v175 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v176 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v177 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v178 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v174 + (v175 + v173), v176, v177);
  __gm__ int32_t* v179 = PTOAS__GLOBAL_TENSOR_DATA(v178);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v179);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  // pto: %150
  int32_t v180 = (v16)[v172];
  // pto: %152
  int32_t v181 = (int32_t) ((uint32_t) v180 + (uint32_t) v23);
  pipe_barrier(PIPE_ALL);
  pto::comm::NotifyOp v182 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v178, v181, v182);
  // pto: %154, %155, %156
  int64_t v183 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v52) / v40) * (uint64_t) v38);
  // pto: %157
  if (v171 < v183) {
    for (int64_t v184 = v51; v184 < v38; v184 += v37) {
      // pto: %158
      ;
      int64_t v185 = v171 % v38;
      // pto: %159, %160, %161
      ;
      int64_t v186 = v185 < v51 ? (int64_t) ((uint64_t) v185 + (uint64_t) v38) : v185;
      // pto: %162, %163, %164
      ;
      int64_t v187 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v186 * (uint64_t) v38) + (uint64_t) v184) % v50;
      // pto: %165, %166, %167
      ;
      int64_t v188 = v187 < v51 ? (int64_t) ((uint64_t) v187 + (uint64_t) v50) : v187;
      // pto: %168, %169
      ;
      int64_t v189 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v188 * (uint64_t) v41) + (uint64_t) v53);
      // pto: %170
      ;
      int64_t v190 = v189 < v51 ? v51 : v189;
      // pto: %signals__ssa_v1_signal_pview
      ;
      __gm__ int32_t* v191 = PTOAS__GLOBAL_TENSOR_DATA(v170);
      // pto: %signals__ssa_v1_signal_pview
      ;
      const int64_t v192 = 0;
      // pto: %signals__ssa_v1_signal_pview
      ;
      pto::Shape<1, 1, 1, 1, 1> v193 = pto::Shape<1, 1, 1, 1, 1>();
      // pto: %signals__ssa_v1_signal_pview
      ;
      pto::Stride<1, 1, 1, 1, 1> v194 = pto::Stride<1, 1, 1, 1, 1>();
      // pto: %signals__ssa_v1_signal_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v195 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v191 + (v192 + v190), v193, v194);
      pto::comm::WaitCmp v196 = pto::comm::WaitCmp::GE;
      pto::comm::TWAIT(v195, v181, v196);
    };
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
  }
  for (int64_t v197 = v171; v197 < v183; v197 += v54) {
    // pto: %172, %173
    ;
    int64_t v198 = (int64_t) ((uint64_t) (v197 / v38) * (uint64_t) v40);
    // pto: %174
    ;
    int64_t v199 = v197 % v38;
    // pto: %175, %176, %177
    ;
    int64_t v200 = v199 < v51 ? (int64_t) ((uint64_t) v199 + (uint64_t) v38) : v199;
    // pto: %178
    ;
    int64_t v201 = (int64_t) ((uint64_t) v200 * (uint64_t) v55);
    // pto: %179
    ;
    int64_t v202 = (int64_t) ((uint64_t) v17 - (uint64_t) v198);
    // pto: %180
    ;
    int64_t v203 = v202 < v40 ? v202 : v40;
    // pto: %oa_value__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v204 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v203, v55);
    // pto: %oa_value__ssa_v0
    ;
    uint64_t v205 = (uint64_t) v24;
    TASSIGN(v204, v205);
    // pto: %181
    ;
    int64_t v206 = v198 < v51 ? v51 : v198;
    // pto: %182
    ;
    int64_t v207 = v201 < v51 ? v51 : v201;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v208 = 0;
    // pto: %accum__ssa_v0_pview
    ;
    __gm__ float* v209 = PTOAS__GLOBAL_TENSOR_DATA(v151);
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v210 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v211 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v212 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    int64_t v213 = v203 * v45;
    // pto: %accum__ssa_v0_pview
    ;
    int64_t v214 = v212 * v213;
    // pto: %accum__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v215 = pto::Shape<1, 1, 1, -1, 1024>(v210, v211, v212, v203, v55);
    // pto: %accum__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v216 = pto::Stride<-1, -1, -1, -1, -1>(v211 * v214, v214, v213, v45, v37);
    // pto: %accum__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v217 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v209 + (v208 + v206 * v45 + v207 * v37), v215, v216);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v204, v217);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %t__tmp_v3
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v203, v55);
    // pto: %t__tmp_v3
    ;
    uint64_t v219 = (uint64_t) v24;
    TASSIGN(v218, v219);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v220 = RoundMode::CAST_RINT;
    SaturationMode v221 = SaturationMode::ON;
    TCVT(v218, v204, v220, v221);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v222 = 0;
    // pto: %projected__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v223 = PTOAS__GLOBAL_TENSOR_DATA(v97);
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v224 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v225 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v226 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    int64_t v227 = v203 * v45;
    // pto: %projected__ssa_v0_pview
    ;
    int64_t v228 = v226 * v227;
    // pto: %projected__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v229 = pto::Shape<1, 1, 1, -1, 1024>(v224, v225, v226, v203, v55);
    // pto: %projected__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v230 = pto::Stride<-1, -1, -1, -1, -1>(v225 * v228, v228, v227, v45, v37);
    // pto: %projected__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v231 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v223 + (v222 + v206 * v45 + v207 * v37), v229, v230);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v231, v218);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %186
  int64_t v232 = (int64_t) ((uint64_t) v172 + (uint64_t) v56);
  // pto: %187
  int64_t v233 = v232 < v51 ? v51 : v232;
  // pto: %188
  __gm__ int32_t* v234 = PTOAS__GLOBAL_TENSOR_DATA(v170);
  // pto: %188
  const int64_t v235 = 0;
  // pto: %188
  pto::Shape<1, 1, 1, 1, 1> v236 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %188
  pto::Stride<1, 1, 1, 1, 1> v237 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %188
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v238 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v234 + (v235 + v233), v236, v237);
  pto::comm::NotifyOp v239 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v238, v181, v239);
  // pto: %189, %190
  int64_t v240 = (int64_t) ((uint64_t) v17 + (uint64_t) v57) / v38;
  // pto: %191
  if (v171 < v240) {
    for (int64_t v241 = v51; v241 < v38; v241 += v37) {
      // pto: %192, %193, %194, %195
      ;
      int64_t v242 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v171 / v49) * (uint64_t) v38) + (uint64_t) v241) % v54;
      // pto: %196, %197, %198
      ;
      int64_t v243 = v242 < v51 ? (int64_t) ((uint64_t) v242 + (uint64_t) v54) : v242;
      // pto: %199, %200
      ;
      int64_t v244 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v243 * (uint64_t) v41) + (uint64_t) v58);
      // pto: %201
      ;
      int64_t v245 = v244 < v51 ? v51 : v244;
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      __gm__ int32_t* v246 = PTOAS__GLOBAL_TENSOR_DATA(v170);
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      const int64_t v247 = 0;
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      pto::Shape<1, 1, 1, 1, 1> v248 = pto::Shape<1, 1, 1, 1, 1>();
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      pto::Stride<1, 1, 1, 1, 1> v249 = pto::Stride<1, 1, 1, 1, 1>();
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v250 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v246 + (v247 + v245), v248, v249);
      pto::comm::WaitCmp v251 = pto::comm::WaitCmp::GE;
      pto::comm::TWAIT(v250, v181, v251);
    };
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v252 = v171; v252 < v240; v252 += v54) {
    // pto: %203
    ;
    int64_t v253 = (int64_t) ((uint64_t) v252 * (uint64_t) v38);
    // pto: %204
    ;
    int64_t v254 = (int64_t) ((uint64_t) v17 - (uint64_t) v253);
    // pto: %205
    ;
    int64_t v255 = v254 < v38 ? v254 : v38;
    // pto: %first_quant__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v256 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v55);
    // pto: %first_quant__ssa_v0
    ;
    uint64_t v257 = (uint64_t) v25;
    TASSIGN(v256, v257);
    // pto: %206
    ;
    int64_t v258 = v253 < v51 ? v51 : v253;
    // pto: %207
    ;
    const int64_t v259 = 0;
    // pto: %207
    ;
    __gm__ bfloat16_t* v260 = PTOAS__GLOBAL_TENSOR_DATA(v97);
    // pto: %207
    ;
    const int64_t v261 = 1;
    // pto: %207
    ;
    const int64_t v262 = 1;
    // pto: %207
    ;
    const int64_t v263 = 1;
    // pto: %207
    ;
    int64_t v264 = v255 * v45;
    // pto: %207
    ;
    int64_t v265 = v263 * v264;
    // pto: %207
    ;
    pto::Shape<1, 1, 1, -1, 1024> v266 = pto::Shape<1, 1, 1, -1, 1024>(v261, v262, v263, v255, v55);
    // pto: %207
    ;
    pto::Stride<-1, -1, -1, -1, -1> v267 = pto::Stride<-1, -1, -1, -1, -1>(v262 * v265, v265, v264, v45, v37);
    // pto: %207
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v268 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v260 + (v259 + v258 * v45 + v51 * v37), v266, v267);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v256, v268);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %t__tmp_v4
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v55);
    // pto: %t__tmp_v4
    ;
    uint64_t v270 = (uint64_t) v24;
    TASSIGN(v269, v270);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    RoundMode v271 = RoundMode::CAST_ROUND;
    SaturationMode v272 = SaturationMode::ON;
    TCVT(v269, v256, v271, v272);
    // pto: %first_abs__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v55);
    // pto: %first_abs__ssa_v0
    ;
    uint64_t v274 = (uint64_t) v24;
    TASSIGN(v273, v274);
    pipe_barrier(PIPE_V);
    TABS(v273, v269);
    // pto: %t__tmp_v5
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v55);
    // pto: %t__tmp_v5
    ;
    uint64_t v276 = (uint64_t) v25;
    TASSIGN(v275, v276);
    // pto: %amax__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v37);
    // pto: %amax__ssa_v0
    ;
    uint64_t v278 = (uint64_t) v26;
    TASSIGN(v277, v278);
    pipe_barrier(PIPE_V);
    TROWMAX(v277, v273, v275);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    for (int64_t v279 = v37; v279 < v38; v279 += v37) {
      // pto: %q_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v280 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v55);
      // pto: %q_bf16__ssa_v0
      ;
      uint64_t v281 = (uint64_t) v25;
      TASSIGN(v280, v281);
      // pto: %209
      ;
      int64_t v282 = (int64_t) ((uint64_t) v279 * (uint64_t) v55);
      // pto: %210
      ;
      int64_t v283 = v282 < v51 ? v51 : v282;
      // pto: %211
      ;
      const int64_t v284 = 0;
      // pto: %211
      ;
      __gm__ bfloat16_t* v285 = PTOAS__GLOBAL_TENSOR_DATA(v97);
      // pto: %211
      ;
      const int64_t v286 = 1;
      // pto: %211
      ;
      const int64_t v287 = 1;
      // pto: %211
      ;
      const int64_t v288 = 1;
      // pto: %211
      ;
      int64_t v289 = v255 * v45;
      // pto: %211
      ;
      int64_t v290 = v288 * v289;
      // pto: %211
      ;
      pto::Shape<1, 1, 1, -1, 1024> v291 = pto::Shape<1, 1, 1, -1, 1024>(v286, v287, v288, v255, v55);
      // pto: %211
      ;
      pto::Stride<-1, -1, -1, -1, -1> v292 = pto::Stride<-1, -1, -1, -1, -1>(v287 * v290, v290, v289, v45, v37);
      // pto: %211
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v293 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v285 + (v284 + v258 * v45 + v283 * v37), v291, v292);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v280, v293);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %q_fp32__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v294 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v55);
      // pto: %q_fp32__ssa_v0
      ;
      uint64_t v295 = (uint64_t) v24;
      TASSIGN(v294, v295);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      pipe_barrier(PIPE_V);
      RoundMode v296 = RoundMode::CAST_ROUND;
      SaturationMode v297 = SaturationMode::ON;
      TCVT(v294, v280, v296, v297);
      // pto: %t__tmp_v6
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v55);
      // pto: %t__tmp_v6
      ;
      uint64_t v299 = (uint64_t) v24;
      TASSIGN(v298, v299);
      pipe_barrier(PIPE_V);
      TABS(v298, v294);
      // pto: %t__tmp_v7
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v300 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v55);
      // pto: %t__tmp_v7
      ;
      uint64_t v301 = (uint64_t) v25;
      TASSIGN(v300, v301);
      // pto: %t__tmp_v8
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v302 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v37);
      // pto: %t__tmp_v8
      ;
      uint64_t v303 = (uint64_t) v27;
      TASSIGN(v302, v303);
      pipe_barrier(PIPE_V);
      TROWMAX(v302, v298, v300);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      // pto: %amax__rm_a0_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v304 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v255);
      // pto: %amax__rm_a0_tmp_v0
      ;
      uint64_t v305 = (uint64_t) v26;
      TASSIGN(v304, v305);
      // pto: %amax__rm_a1_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v255);
      // pto: %amax__rm_a1_tmp_v1
      ;
      uint64_t v307 = (uint64_t) v27;
      TASSIGN(v306, v307);
      // pto: %amax__row_major_tmp_v2
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v308 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v255);
      // pto: %amax__row_major_tmp_v2
      ;
      uint64_t v309 = (uint64_t) v24;
      TASSIGN(v308, v309);
      pipe_barrier(PIPE_V);
      TMAX(v308, v304, v306);
      // pto: %amax__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v310 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v37);
      // pto: %amax__ssa_v3
      ;
      uint64_t v311 = (uint64_t) v24;
      TASSIGN(v310, v311);
      // pto: %amax__ssa_v3_mv
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v37);
      // pto: %amax__ssa_v3_mv
      ;
      uint64_t v313 = (uint64_t) v26;
      TASSIGN(v312, v313);
      pipe_barrier(PIPE_V);
      TMOV(v312, v310);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    // pto: %dequant__rm_a0_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v314 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v255);
    // pto: %dequant__rm_a0_tmp_v3
    ;
    uint64_t v315 = (uint64_t) v26;
    TASSIGN(v314, v315);
    // pto: %dequant__row_major_tmp_v4
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v316 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v255);
    // pto: %dequant__row_major_tmp_v4
    ;
    uint64_t v317 = (uint64_t) v24;
    TASSIGN(v316, v317);
    pipe_barrier(PIPE_V);
    TMULS(v316, v314, v59);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %dequant__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v318 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v37);
    // pto: %dequant__ssa_v0
    ;
    uint64_t v319 = (uint64_t) v24;
    TASSIGN(v318, v319);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v320 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v255);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    uint64_t v321 = (uint64_t) v26;
    TASSIGN(v320, v321);
    // pto: %denominator__row_major_tmp_v6
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v322 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v255);
    // pto: %denominator__row_major_tmp_v6
    ;
    uint64_t v323 = (uint64_t) v28;
    TASSIGN(v322, v323);
    TADDS(v322, v320, v60);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    // pto: %denominator__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v324 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v37);
    // pto: %denominator__ssa_v0
    ;
    uint64_t v325 = (uint64_t) v28;
    TASSIGN(v324, v325);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    for (int64_t v326 = v51; v326 < v255; v326 += v37) {
      // pto: %magnitude__ssa_v0
      ;
      float v327 = v324.GetValue(v326);
      // pto: %212
      ;
      bool v328 = v327 != v327 || v60 != v60;
      // pto: %212
      ;
      if ((v327 == v327 && v60 == v60) && v327 == v60) {
        v324.SetValue(v326, v61);
      };
    };
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    // pto: %t__rm_a0_tmp_v7
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v329 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v255);
    // pto: %t__rm_a0_tmp_v7
    ;
    uint64_t v330 = (uint64_t) v26;
    TASSIGN(v329, v330);
    // pto: %t__row_major_tmp_v8
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v331 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v255);
    // pto: %t__row_major_tmp_v8
    ;
    uint64_t v332 = (uint64_t) v29;
    TASSIGN(v331, v332);
    TMULS(v331, v329, v60);
    // pto: %t__tmp_v9
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v333 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v37);
    // pto: %t__tmp_v9
    ;
    uint64_t v334 = (uint64_t) v29;
    TASSIGN(v333, v334);
    // pto: %t__rm_a0_tmp_v9
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v335 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v255);
    // pto: %t__rm_a0_tmp_v9
    ;
    uint64_t v336 = (uint64_t) v29;
    TASSIGN(v335, v336);
    // pto: %t__row_major_tmp_v10
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v337 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v255);
    // pto: %t__row_major_tmp_v10
    ;
    uint64_t v338 = (uint64_t) v29;
    TASSIGN(v337, v338);
    pipe_barrier(PIPE_V);
    TADDS(v337, v335, v62);
    // pto: %t__tmp_v10
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v339 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v37);
    // pto: %t__tmp_v10
    ;
    uint64_t v340 = (uint64_t) v29;
    TASSIGN(v339, v340);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v341 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v255);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    uint64_t v342 = (uint64_t) v29;
    TASSIGN(v341, v342);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v255);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    uint64_t v344 = (uint64_t) v28;
    TASSIGN(v343, v344);
    // pto: %multiplier__row_major_tmp_v13
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v345 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v255);
    // pto: %multiplier__row_major_tmp_v13
    ;
    uint64_t v346 = (uint64_t) v30;
    TASSIGN(v345, v346);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    TDIV(v345, v341, v343);
    // pto: %multiplier__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v37);
    // pto: %multiplier__ssa_v0
    ;
    uint64_t v348 = (uint64_t) v30;
    TASSIGN(v347, v348);
    v318.SetValidShape(v255, v37);
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v349 = (int64_t) v17;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v350 = 0;
    // pto: %token_scale__ssa_v0_pview
    ;
    __gm__ float* v351 = PTOAS__GLOBAL_TENSOR_DATA(v115);
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v352 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v353 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v354 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v355 = v255 * v37;
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v356 = v354 * v355;
    // pto: %token_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1> v357 = pto::Shape<1, 1, 1, -1, 1>(v352, v353, v354, v255, v37);
    // pto: %token_scale__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v358 = pto::Stride<-1, -1, -1, -1, -1>(v353 * v356, v356, v355, v37, v349);
    // pto: %token_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v359 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v351 + (v350 + v258 * v37 + v51 * v349), v357, v358);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    TSTORE(v359, v318);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    for (int64_t v360 = v51; v360 < v38; v360 += v37) {
      // pto: %217
      ;
      int64_t v361 = (int64_t) ((uint64_t) v360 * (uint64_t) v55);
      // pto: %quant_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v362 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v55);
      // pto: %quant_bf16__ssa_v0
      ;
      uint64_t v363 = (uint64_t) v25;
      TASSIGN(v362, v363);
      // pto: %219
      ;
      int64_t v364 = v361 < v51 ? v51 : v361;
      // pto: %220
      ;
      const int64_t v365 = 0;
      // pto: %220
      ;
      __gm__ bfloat16_t* v366 = PTOAS__GLOBAL_TENSOR_DATA(v97);
      // pto: %220
      ;
      const int64_t v367 = 1;
      // pto: %220
      ;
      const int64_t v368 = 1;
      // pto: %220
      ;
      const int64_t v369 = 1;
      // pto: %220
      ;
      int64_t v370 = v255 * v45;
      // pto: %220
      ;
      int64_t v371 = v369 * v370;
      // pto: %220
      ;
      pto::Shape<1, 1, 1, -1, 1024> v372 = pto::Shape<1, 1, 1, -1, 1024>(v367, v368, v369, v255, v55);
      // pto: %220
      ;
      pto::Stride<-1, -1, -1, -1, -1> v373 = pto::Stride<-1, -1, -1, -1, -1>(v368 * v371, v371, v370, v45, v37);
      // pto: %220
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v374 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v366 + (v365 + v258 * v45 + v364 * v37), v372, v373);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      TLOAD(v362, v374);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %t__tmp_v12
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v375 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v55);
      // pto: %t__tmp_v12
      ;
      uint64_t v376 = (uint64_t) v24;
      TASSIGN(v375, v376);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      RoundMode v377 = RoundMode::CAST_ROUND;
      SaturationMode v378 = SaturationMode::ON;
      TCVT(v375, v362, v377, v378);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      // pto: %quant_scaled__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v379 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v55);
      // pto: %quant_scaled__ssa_v0
      ;
      uint64_t v380 = (uint64_t) v24;
      TASSIGN(v379, v380);
      pipe_barrier(PIPE_V);
      TROWEXPANDMUL(v379, v375, v347);
      // pto: %integer__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v381 = Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v55);
      // pto: %integer__ssa_v0
      ;
      uint64_t v382 = (uint64_t) v24;
      TASSIGN(v381, v382);
      pipe_barrier(PIPE_V);
      RoundMode v383 = RoundMode::CAST_RINT;
      SaturationMode v384 = SaturationMode::ON;
      TCVT(v381, v379, v383, v384);
      // pto: %half__ssa_v0
      ;
      Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v385 = Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v55);
      // pto: %half__ssa_v0
      ;
      uint64_t v386 = (uint64_t) v24;
      TASSIGN(v385, v386);
      pipe_barrier(PIPE_V);
      RoundMode v387 = RoundMode::CAST_ROUND;
      SaturationMode v388 = SaturationMode::ON;
      TCVT(v385, v381, v387, v388);
      // pto: %result__ssa_v0
      ;
      Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v389 = Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v255, v55);
      // pto: %result__ssa_v0
      ;
      uint64_t v390 = (uint64_t) v24;
      TASSIGN(v389, v390);
      pipe_barrier(PIPE_V);
      RoundMode v391 = RoundMode::CAST_TRUNC;
      SaturationMode v392 = SaturationMode::ON;
      TCVT(v389, v385, v391, v392);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      v389.SetValidShape(v255, v55);
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v393 = 0;
      // pto: %quantized__ssa_v0_pview
      ;
      __gm__ int8_t* v394 = PTOAS__GLOBAL_TENSOR_DATA(v106);
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v395 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v396 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v397 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      int64_t v398 = v255 * v45;
      // pto: %quantized__ssa_v0_pview
      ;
      int64_t v399 = v397 * v398;
      // pto: %quantized__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 1024> v400 = pto::Shape<1, 1, 1, -1, 1024>(v395, v396, v397, v255, v55);
      // pto: %quantized__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v401 = pto::Stride<-1, -1, -1, -1, -1>(v396 * v399, v399, v398, v45, v37);
      // pto: %quantized__ssa_v0_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v402 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v394 + (v393 + v258 * v45 + v364 * v37), v400, v401);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      TSTORE(v402, v389);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %224
  int64_t v403 = (int64_t) ((uint64_t) v172 + (uint64_t) v63);
  // pto: %225
  int64_t v404 = v403 < v51 ? v51 : v403;
  // pto: %226
  __gm__ int32_t* v405 = PTOAS__GLOBAL_TENSOR_DATA(v170);
  // pto: %226
  const int64_t v406 = 0;
  // pto: %226
  pto::Shape<1, 1, 1, 1, 1> v407 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %226
  pto::Stride<1, 1, 1, 1, 1> v408 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %226
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v409 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v405 + (v406 + v404), v407, v408);
  pto::comm::NotifyOp v410 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v409, v181, v410);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  for (int64_t v411 = v171; v411 < v183; v411 += v54) {
    // pto: %229, %230
    ;
    int64_t v412 = (int64_t) ((uint64_t) (v411 / v38) * (uint64_t) v40);
    // pto: %231
    ;
    int64_t v413 = v411 % v38;
    // pto: %232, %233, %234
    ;
    int64_t v414 = v413 < v51 ? (int64_t) ((uint64_t) v413 + (uint64_t) v38) : v413;
    // pto: %235
    ;
    int64_t v415 = (int64_t) ((uint64_t) v414 * (uint64_t) v42);
    // pto: %236
    ;
    int64_t v416 = (int64_t) ((uint64_t) v17 - (uint64_t) v412);
    // pto: %237
    ;
    int64_t v417 = v416 < v40 ? v416 : v40;
    for (int64_t v418 = v51; v418 < v49; v418 += v37) {
      // pto: %238, %239, %240
      ;
      int64_t v419 = (int64_t) ((uint64_t) (v412 / v38) + (uint64_t) v418) % v54;
      // pto: %241, %242, %243
      ;
      int64_t v420 = v419 < v51 ? (int64_t) ((uint64_t) v419 + (uint64_t) v54) : v419;
      // pto: %244, %245
      ;
      int64_t v421 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v420 * (uint64_t) v41) + (uint64_t) v64);
      // pto: %246
      ;
      int64_t v422 = v421 < v51 ? v51 : v421;
      // pto: %signals_v2__ssa_v0_signal_pview
      ;
      __gm__ int32_t* v423 = PTOAS__GLOBAL_TENSOR_DATA(v170);
      // pto: %signals_v2__ssa_v0_signal_pview
      ;
      const int64_t v424 = 0;
      // pto: %signals_v2__ssa_v0_signal_pview
      ;
      pto::Shape<1, 1, 1, 1, 1> v425 = pto::Shape<1, 1, 1, 1, 1>();
      // pto: %signals_v2__ssa_v0_signal_pview
      ;
      pto::Stride<1, 1, 1, 1, 1> v426 = pto::Stride<1, 1, 1, 1, 1>();
      // pto: %signals_v2__ssa_v0_signal_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v427 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v423 + (v424 + v422), v425, v426);
      pto::comm::WaitCmp v428 = pto::comm::WaitCmp::GE;
      pto::comm::TWAIT(v427, v181, v428);
    };
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    // pto: %t__tmp_v14
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v429 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
    // pto: %t__tmp_v14
    ;
    uint64_t v430 = (uint64_t) v25;
    TASSIGN(v429, v430);
    // pto: %247
    ;
    int64_t v431 = v415 < v51 ? v51 : v415;
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    __gm__ float* v432 = PTOAS__GLOBAL_TENSOR_DATA(v88);
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    const int64_t v433 = 0;
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 512> v434 = pto::Shape<1, 1, 1, 1, 512>();
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    pto::Stride<512, 512, 512, 512, 1> v435 = pto::Stride<512, 512, 512, 512, 1>();
    // pto: %wo_b_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v436 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v432 + (v433 + v431), v434, v435);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    TLOAD(v429, v436);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    // pto: %channel__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v437 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
    // pto: %channel__ssa_v0
    ;
    uint64_t v438 = (uint64_t) v25;
    TASSIGN(v437, v438);
    // pto: %scale__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v439 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v417, v37);
    // pto: %scale__ssa_v0
    ;
    uint64_t v440 = (uint64_t) v31;
    TASSIGN(v439, v440);
    // pto: %248
    ;
    int64_t v441 = v412 < v51 ? v51 : v412;
    // pto: %249
    ;
    int64_t v442 = (int64_t) v17;
    // pto: %249
    ;
    const int64_t v443 = 0;
    // pto: %249
    ;
    __gm__ float* v444 = PTOAS__GLOBAL_TENSOR_DATA(v115);
    // pto: %249
    ;
    const int64_t v445 = 1;
    // pto: %249
    ;
    const int64_t v446 = 1;
    // pto: %249
    ;
    const int64_t v447 = 1;
    // pto: %249
    ;
    int64_t v448 = v417 * v37;
    // pto: %249
    ;
    int64_t v449 = v447 * v448;
    // pto: %249
    ;
    pto::Shape<1, 1, 1, -1, 1> v450 = pto::Shape<1, 1, 1, -1, 1>(v445, v446, v447, v417, v37);
    // pto: %249
    ;
    pto::Stride<-1, -1, -1, -1, -1> v451 = pto::Stride<-1, -1, -1, -1, -1>(v446 * v449, v449, v448, v37, v442);
    // pto: %249
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v452 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v444 + (v443 + v441 * v37 + v51 * v442), v450, v451);
    TLOAD(v439, v452);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    // pto: %coefficient_one__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v453 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v40, v42);
    // pto: %coefficient_one__ssa_v0
    ;
    uint64_t v454 = (uint64_t) v24;
    TASSIGN(v453, v454);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    TEXPANDS(v453, v61);
    // pto: %coefficient_channel__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v455 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v40, v42);
    // pto: %coefficient_channel__ssa_v0
    ;
    uint64_t v456 = (uint64_t) v24;
    TASSIGN(v455, v456);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    TCOLEXPANDMUL(v455, v453, v437);
    // pto: %coefficient__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v457 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v40, v42);
    // pto: %coefficient__ssa_v0
    ;
    uint64_t v458 = (uint64_t) v24;
    TASSIGN(v457, v458);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    TROWEXPANDMUL(v457, v455, v439);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    for (int64_t v459 = v51; v459 < v47; v459 += v37) {
      // pto: %250
      ;
      // pto: %ob_owner__phi_v2
      ;
      int64_t v460;
      if (v17 <= v40) {
        // pto: %251, %252, %254, %253, %255, %256
        ;
        int64_t v461 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) (v412 / v40) * (uint64_t) v43) + (uint64_t) (v415 / v41)) + (uint64_t) v459) % v50;
        // pto: %257, %258, %259
        ;
        v460 = v461 < v51 ? (int64_t) ((uint64_t) v461 + (uint64_t) v50) : v461;
      } else {
        // pto: %260, %261, %263, %262, %264, %265
        ;
        int64_t v462 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) (v412 / v39) * (uint64_t) v43) + (uint64_t) (v415 / v41)) + (uint64_t) v459) % v50;
        // pto: %266, %267, %268
        ;
        v460 = v462 < v51 ? (int64_t) ((uint64_t) v462 + (uint64_t) v50) : v462;
      };
      // pto: %269
      ;
      uint64_t v463 = (uint64_t) v460;
      // pto: %269, %270
      ;
      int64_t v464 = (int64_t) ((uint64_t) ((int64_t) v463 * (uint64_t) v41) + (uint64_t) v65);
      // pto: %271
      ;
      int64_t v465 = v464 < v51 ? v51 : v464;
      // pto: %272
      ;
      __gm__ int32_t* v466 = PTOAS__GLOBAL_TENSOR_DATA(v170);
      // pto: %272
      ;
      const int64_t v467 = 0;
      // pto: %272
      ;
      pto::Shape<1, 1, 1, 1, 1> v468 = pto::Shape<1, 1, 1, 1, 1>();
      // pto: %272
      ;
      pto::Stride<1, 1, 1, 1, 1> v469 = pto::Stride<1, 1, 1, 1, 1>();
      // pto: %272
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v470 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v466 + (v467 + v465), v468, v469);
      pto::comm::WaitCmp v471 = pto::comm::WaitCmp::GE;
      pto::comm::TWAIT(v470, v181, v471);
    };
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    // pto: %ob_integer__ssa_v0
    ;
    Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v417, v42);
    // pto: %ob_integer__ssa_v0
    ;
    uint64_t v473 = (uint64_t) v25;
    TASSIGN(v472, v473);
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v474 = 0;
    // pto: %integer_accum__ssa_v0_pview
    ;
    __gm__ int32_t* v475 = PTOAS__GLOBAL_TENSOR_DATA(v160);
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v476 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v477 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v478 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    int64_t v479 = v417 * v44;
    // pto: %integer_accum__ssa_v0_pview
    ;
    int64_t v480 = v478 * v479;
    // pto: %integer_accum__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v481 = pto::Shape<1, 1, 1, -1, 512>(v476, v477, v478, v417, v42);
    // pto: %integer_accum__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v482 = pto::Stride<-1, -1, -1, -1, -1>(v477 * v480, v480, v479, v44, v37);
    // pto: %integer_accum__ssa_v0_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v483 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v475 + (v474 + v441 * v44 + v431 * v37), v481, v482);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    TLOAD(v472, v483);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    // pto: %t__tmp_v15
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v484 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v417, v42);
    // pto: %t__tmp_v15
    ;
    uint64_t v485 = (uint64_t) v25;
    TASSIGN(v484, v485);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    RoundMode v486 = RoundMode::CAST_ROUND;
    SaturationMode v487 = SaturationMode::ON;
    TCVT(v484, v472, v486, v487);
    // pto: %ob_scaled__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v488 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v417, v42);
    // pto: %ob_scaled__ssa_v0
    ;
    uint64_t v489 = (uint64_t) v24;
    TASSIGN(v488, v489);
    pipe_barrier(PIPE_V);
    TMUL(v488, v484, v457);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    // pto: %t__tmp_v16
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v490 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v417, v42);
    // pto: %t__tmp_v16
    ;
    uint64_t v491 = (uint64_t) v24;
    TASSIGN(v490, v491);
    pipe_barrier(PIPE_V);
    RoundMode v492 = RoundMode::CAST_RINT;
    SaturationMode v493 = SaturationMode::ON;
    TCVT(v490, v488, v492, v493);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v494 = 0;
    // pto: %attended__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v495 = PTOAS__GLOBAL_TENSOR_DATA(v124);
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v496 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v497 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v498 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    int64_t v499 = v417 * v44;
    // pto: %attended__ssa_v0_pview
    ;
    int64_t v500 = v498 * v499;
    // pto: %attended__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v501 = pto::Shape<1, 1, 1, -1, 512>(v496, v497, v498, v417, v42);
    // pto: %attended__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v502 = pto::Stride<-1, -1, -1, -1, -1>(v497 * v500, v500, v499, v44, v37);
    // pto: %attended__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v503 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v495 + (v494 + v441 * v44 + v431 * v37), v501, v502);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    TSTORE(v503, v490);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %278
  int64_t v504 = (int64_t) ((uint64_t) v172 + (uint64_t) v66);
  // pto: %279
  int64_t v505 = v504 < v51 ? v51 : v504;
  // pto: %280
  __gm__ int32_t* v506 = PTOAS__GLOBAL_TENSOR_DATA(v170);
  // pto: %280
  const int64_t v507 = 0;
  // pto: %280
  pto::Shape<1, 1, 1, 1, 1> v508 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %280
  pto::Stride<1, 1, 1, 1, 1> v509 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %280
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v510 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v506 + (v507 + v505), v508, v509);
  pto::comm::NotifyOp v511 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v510, v181, v511);
  for (int64_t v512 = v50; v512 < v67; v512 += v37) {
    // pto: %281, %282
    ;
    int64_t v513 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v512 * (uint64_t) v41) + (uint64_t) v66);
    // pto: %283
    ;
    int64_t v514 = v513 < v51 ? v51 : v513;
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v515 = PTOAS__GLOBAL_TENSOR_DATA(v170);
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    const int64_t v516 = 0;
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v517 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v518 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v3__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v519 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v515 + (v516 + v514), v517, v518);
    pto::comm::WaitCmp v520 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v519, v181, v520);
  }
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %284, %285
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v521 = v171; v521 < ((int64_t) ((uint64_t) v17 + (uint64_t) v68) / v47); v521 += v54) {
    // pto: %286
    ;
    int64_t v522 = (int64_t) ((uint64_t) v521 * (uint64_t) v47);
    // pto: %287
    ;
    int64_t v523 = (int64_t) ((uint64_t) v522 + (uint64_t) v47);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    for (int64_t v524 = v522; v524 < v523; v524 += v49) {
      // pto: %288
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
      if (v524 < v17) {
        // pto: %289
        ;
        int64_t v525 = (int64_t) ((uint64_t) v524 * (uint64_t) v47);
        // pto: %post_scalar__tile
        ;
        float v526 = (v11)[v525];
        // pto: %291
        ;
        int64_t v527 = (int64_t) ((uint64_t) v524 * (uint64_t) v40);
        // pto: %comb_scalar_0__tile
        ;
        float v528 = (v12)[v527];
        // pto: %294, %comb_scalar_1__tile
        ;
        float v529 = (v12)[(int64_t) ((uint64_t) v527 + (uint64_t) v47)];
        // pto: %296, %comb_scalar_2__tile
        ;
        float v530 = (v12)[(int64_t) ((uint64_t) v527 + (uint64_t) v38)];
        // pto: %298, %comb_scalar_3__tile
        ;
        float v531 = (v12)[(int64_t) ((uint64_t) v527 + (uint64_t) v69)];
        // pto: %301, %299
        ;
        float v532 = (v11)[(int64_t) ((uint64_t) v525 + (uint64_t) v37)];
        // pto: %304, %302
        ;
        float v533 = (v12)[(int64_t) ((uint64_t) v527 + (uint64_t) v37)];
        // pto: %307, %305
        ;
        float v534 = (v12)[(int64_t) ((uint64_t) v527 + (uint64_t) v70)];
        // pto: %310, %308
        ;
        float v535 = (v12)[(int64_t) ((uint64_t) v527 + (uint64_t) v71)];
        // pto: %313, %311
        ;
        float v536 = (v12)[(int64_t) ((uint64_t) v527 + (uint64_t) v72)];
        // pto: %316, %314
        ;
        float v537 = (v11)[(int64_t) ((uint64_t) v525 + (uint64_t) v49)];
        // pto: %319, %317
        ;
        float v538 = (v12)[(int64_t) ((uint64_t) v527 + (uint64_t) v49)];
        // pto: %322, %320
        ;
        float v539 = (v12)[(int64_t) ((uint64_t) v527 + (uint64_t) v73)];
        // pto: %325, %323
        ;
        float v540 = (v12)[(int64_t) ((uint64_t) v527 + (uint64_t) v74)];
        // pto: %328, %326
        ;
        float v541 = (v12)[(int64_t) ((uint64_t) v527 + (uint64_t) v75)];
        // pto: %331, %329
        ;
        float v542 = (v11)[(int64_t) ((uint64_t) v525 + (uint64_t) v68)];
        // pto: %334, %332
        ;
        float v543 = (v12)[(int64_t) ((uint64_t) v527 + (uint64_t) v68)];
        // pto: %337, %335
        ;
        float v544 = (v12)[(int64_t) ((uint64_t) v527 + (uint64_t) v57)];
        // pto: %340, %338
        ;
        float v545 = (v12)[(int64_t) ((uint64_t) v527 + (uint64_t) v76)];
        // pto: %343, %341
        ;
        float v546 = (v12)[(int64_t) ((uint64_t) v527 + (uint64_t) v52)];
        // pto: %x_block__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v547 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %x_block__tile
        ;
        uint64_t v548 = (uint64_t) v32;
        TASSIGN(v547, v548);
        // pto: %344
        ;
        int64_t v549 = v524 < v51 ? v51 : v524;
        // pto: %x__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v550 = PTOAS__GLOBAL_TENSOR_DATA(v124);
        // pto: %x__ssa_v0_pview
        ;
        const int64_t v551 = 0;
        // pto: %x__ssa_v0_pview
        ;
        const int64_t v552 = 4096;
        // pto: %x__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v553 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %x__ssa_v0_pview
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v554 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %x__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v555 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v550 + (v551 + v549 * v552), v553, v554);
        TLOAD(v547, v555);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        // pto: %345
        ;
        int64_t v556 = (int64_t) ((uint64_t) v17 - (uint64_t) v524);
        // pto: %346
        ;
        int64_t v557 = v556 < v51 ? v51 : v556;
        // pto: %347
        ;
        int64_t v558 = v557 < v37 ? v557 : v37;
        // pto: %t__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v559 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %t__tile
        ;
        uint64_t v560 = (uint64_t) v25;
        TASSIGN(v559, v560);
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v561 = 0;
        // pto: %residual_flat__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v562 = PTOAS__GLOBAL_TENSOR_DATA(v133);
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v563 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v564 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v565 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        int64_t v566 = v558 * v46;
        // pto: %residual_flat__ssa_v0_pview
        ;
        int64_t v567 = v565 * v566;
        // pto: %residual_flat__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 4096> v568 = pto::Shape<1, 1, 1, -1, 4096>(v563, v564, v565, v558, v44);
        // pto: %residual_flat__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v569 = pto::Stride<-1, -1, -1, -1, -1>(v564 * v567, v567, v566, v46, v37);
        // pto: %residual_flat__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v570 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v562 + (v561 + v549 * v46 + v51 * v37), v568, v569);
        TLOAD(v559, v570);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %0
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v571 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %0
        ;
        uint64_t v572 = (uint64_t) v30;
        TASSIGN(v571, v572);
        // pto: %359
        ;
        const int64_t v573 = 0;
        // pto: %359
        ;
        __gm__ bfloat16_t* v574 = PTOAS__GLOBAL_TENSOR_DATA(v133);
        // pto: %359
        ;
        const int64_t v575 = 1;
        // pto: %359
        ;
        const int64_t v576 = 1;
        // pto: %359
        ;
        const int64_t v577 = 1;
        // pto: %359
        ;
        int64_t v578 = v558 * v46;
        // pto: %359
        ;
        int64_t v579 = v577 * v578;
        // pto: %359
        ;
        pto::Shape<1, 1, 1, -1, 4096> v580 = pto::Shape<1, 1, 1, -1, 4096>(v575, v576, v577, v558, v44);
        // pto: %359
        ;
        pto::Stride<-1, -1, -1, -1, -1> v581 = pto::Stride<-1, -1, -1, -1, -1>(v576 * v579, v579, v578, v46, v37);
        // pto: %359
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v582 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v574 + (v573 + v549 * v46 + v44 * v37), v580, v581);
        TLOAD(v571, v582);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %1
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v583 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %1
        ;
        uint64_t v584 = (uint64_t) v26;
        TASSIGN(v583, v584);
        // pto: %367
        ;
        const int64_t v585 = 0;
        // pto: %367
        ;
        __gm__ bfloat16_t* v586 = PTOAS__GLOBAL_TENSOR_DATA(v133);
        // pto: %367
        ;
        const int64_t v587 = 1;
        // pto: %367
        ;
        const int64_t v588 = 1;
        // pto: %367
        ;
        const int64_t v589 = 1;
        // pto: %367
        ;
        int64_t v590 = v558 * v46;
        // pto: %367
        ;
        int64_t v591 = v589 * v590;
        // pto: %367
        ;
        pto::Shape<1, 1, 1, -1, 4096> v592 = pto::Shape<1, 1, 1, -1, 4096>(v587, v588, v589, v558, v44);
        // pto: %367
        ;
        pto::Stride<-1, -1, -1, -1, -1> v593 = pto::Stride<-1, -1, -1, -1, -1>(v588 * v591, v591, v590, v46, v37);
        // pto: %367
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v594 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v586 + (v585 + v549 * v46 + v45 * v37), v592, v593);
        TLOAD(v583, v594);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %2
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v595 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %2
        ;
        uint64_t v596 = (uint64_t) v33;
        TASSIGN(v595, v596);
        // pto: %375
        ;
        const int64_t v597 = 0;
        // pto: %375
        ;
        __gm__ bfloat16_t* v598 = PTOAS__GLOBAL_TENSOR_DATA(v133);
        // pto: %375
        ;
        const int64_t v599 = 1;
        // pto: %375
        ;
        const int64_t v600 = 1;
        // pto: %375
        ;
        const int64_t v601 = 1;
        // pto: %375
        ;
        int64_t v602 = v558 * v46;
        // pto: %375
        ;
        int64_t v603 = v601 * v602;
        // pto: %375
        ;
        pto::Shape<1, 1, 1, -1, 4096> v604 = pto::Shape<1, 1, 1, -1, 4096>(v599, v600, v601, v558, v44);
        // pto: %375
        ;
        pto::Stride<-1, -1, -1, -1, -1> v605 = pto::Stride<-1, -1, -1, -1, -1>(v600 * v603, v603, v602, v46, v37);
        // pto: %375
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v606 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v598 + (v597 + v549 * v46 + v77 * v37), v604, v605);
        TLOAD(v595, v606);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %x_f32__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v607 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %x_f32__tile
        ;
        uint64_t v608 = (uint64_t) v24;
        TASSIGN(v607, v608);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        pipe_barrier(PIPE_V);
        RoundMode v609 = RoundMode::CAST_ROUND;
        SaturationMode v610 = SaturationMode::ON;
        TCVT(v607, v547, v609, v610);
        // pto: %res_0__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v611 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %res_0__tile
        ;
        uint64_t v612 = (uint64_t) v32;
        TASSIGN(v611, v612);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v613 = RoundMode::CAST_ROUND;
        SaturationMode v614 = SaturationMode::ON;
        TCVT(v611, v559, v613, v614);
        // pto: %res_1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v615 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %res_1__tile
        ;
        uint64_t v616 = (uint64_t) v25;
        TASSIGN(v615, v616);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v617 = RoundMode::CAST_ROUND;
        SaturationMode v618 = SaturationMode::ON;
        TCVT(v615, v571, v617, v618);
        // pto: %res_2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v619 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %res_2__tile
        ;
        uint64_t v620 = (uint64_t) v30;
        TASSIGN(v619, v620);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v621 = RoundMode::CAST_ROUND;
        SaturationMode v622 = SaturationMode::ON;
        TCVT(v619, v583, v621, v622);
        // pto: %res_3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v623 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %res_3__tile
        ;
        uint64_t v624 = (uint64_t) v26;
        TASSIGN(v623, v624);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        RoundMode v625 = RoundMode::CAST_ROUND;
        SaturationMode v626 = SaturationMode::ON;
        TCVT(v623, v595, v625, v626);
        // pto: %single_y__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v627 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %single_y__tile
        ;
        uint64_t v628 = (uint64_t) v33;
        TASSIGN(v627, v628);
        pipe_barrier(PIPE_V);
        TMULS(v627, v607, v526);
        // pto: %single_weighted_0__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v629 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %single_weighted_0__tile
        ;
        uint64_t v630 = (uint64_t) v34;
        TASSIGN(v629, v630);
        TMULS(v629, v611, v528);
        // pto: %single_y_v1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v631 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %single_y_v1__tile
        ;
        uint64_t v632 = (uint64_t) v33;
        TASSIGN(v631, v632);
        pipe_barrier(PIPE_V);
        TADD(v631, v627, v629);
        // pto: %single_weighted_1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v633 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %single_weighted_1__tile
        ;
        uint64_t v634 = (uint64_t) v34;
        TASSIGN(v633, v634);
        pipe_barrier(PIPE_V);
        TMULS(v633, v615, v529);
        // pto: %single_y_v2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v635 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %single_y_v2__tile
        ;
        uint64_t v636 = (uint64_t) v33;
        TASSIGN(v635, v636);
        pipe_barrier(PIPE_V);
        TADD(v635, v631, v633);
        // pto: %single_weighted_2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v637 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %single_weighted_2__tile
        ;
        uint64_t v638 = (uint64_t) v34;
        TASSIGN(v637, v638);
        pipe_barrier(PIPE_V);
        TMULS(v637, v619, v530);
        // pto: %single_y_v3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v639 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %single_y_v3__tile
        ;
        uint64_t v640 = (uint64_t) v33;
        TASSIGN(v639, v640);
        pipe_barrier(PIPE_V);
        TADD(v639, v635, v637);
        // pto: %single_weighted_3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v641 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %single_weighted_3__tile
        ;
        uint64_t v642 = (uint64_t) v34;
        TASSIGN(v641, v642);
        pipe_barrier(PIPE_V);
        TMULS(v641, v623, v531);
        // pto: %single_y_v4__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v643 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %single_y_v4__tile
        ;
        uint64_t v644 = (uint64_t) v33;
        TASSIGN(v643, v644);
        pipe_barrier(PIPE_V);
        TADD(v643, v639, v641);
        // pto: %single_result__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v645 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %single_result__tile
        ;
        uint64_t v646 = (uint64_t) v35;
        TASSIGN(v645, v646);
        pipe_barrier(PIPE_V);
        RoundMode v647 = RoundMode::CAST_RINT;
        SaturationMode v648 = SaturationMode::ON;
        TCVT(v645, v643, v647, v648);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        v645.SetValidShape(v37, v44);
        // pto: %4
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v649 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %4
        ;
        uint64_t v650 = (uint64_t) v33;
        TASSIGN(v649, v650);
        pipe_barrier(PIPE_V);
        TMULS(v649, v607, v532);
        // pto: %5
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v651 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %5
        ;
        uint64_t v652 = (uint64_t) v34;
        TASSIGN(v651, v652);
        TMULS(v651, v611, v533);
        // pto: %6
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v653 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %6
        ;
        uint64_t v654 = (uint64_t) v33;
        TASSIGN(v653, v654);
        pipe_barrier(PIPE_V);
        TADD(v653, v649, v651);
        // pto: %7
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v655 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %7
        ;
        uint64_t v656 = (uint64_t) v34;
        TASSIGN(v655, v656);
        pipe_barrier(PIPE_V);
        TMULS(v655, v615, v534);
        // pto: %8
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v657 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %8
        ;
        uint64_t v658 = (uint64_t) v33;
        TASSIGN(v657, v658);
        pipe_barrier(PIPE_V);
        TADD(v657, v653, v655);
        // pto: %9
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v659 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %9
        ;
        uint64_t v660 = (uint64_t) v34;
        TASSIGN(v659, v660);
        pipe_barrier(PIPE_V);
        TMULS(v659, v619, v535);
        // pto: %10
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v661 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %10
        ;
        uint64_t v662 = (uint64_t) v33;
        TASSIGN(v661, v662);
        pipe_barrier(PIPE_V);
        TADD(v661, v657, v659);
        // pto: %11
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v663 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %11
        ;
        uint64_t v664 = (uint64_t) v34;
        TASSIGN(v663, v664);
        pipe_barrier(PIPE_V);
        TMULS(v663, v623, v536);
        // pto: %12
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v665 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %12
        ;
        uint64_t v666 = (uint64_t) v33;
        TASSIGN(v665, v666);
        pipe_barrier(PIPE_V);
        TADD(v665, v661, v663);
        // pto: %13
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v667 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %13
        ;
        uint64_t v668 = (uint64_t) v36;
        TASSIGN(v667, v668);
        pipe_barrier(PIPE_V);
        RoundMode v669 = RoundMode::CAST_RINT;
        SaturationMode v670 = SaturationMode::ON;
        TCVT(v667, v665, v669, v670);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        v667.SetValidShape(v37, v44);
        // pto: %15
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v671 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %15
        ;
        uint64_t v672 = (uint64_t) v33;
        TASSIGN(v671, v672);
        pipe_barrier(PIPE_V);
        TMULS(v671, v607, v537);
        // pto: %16
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v673 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %16
        ;
        uint64_t v674 = (uint64_t) v34;
        TASSIGN(v673, v674);
        TMULS(v673, v611, v538);
        // pto: %17
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v675 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %17
        ;
        uint64_t v676 = (uint64_t) v33;
        TASSIGN(v675, v676);
        pipe_barrier(PIPE_V);
        TADD(v675, v671, v673);
        // pto: %18
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v677 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %18
        ;
        uint64_t v678 = (uint64_t) v34;
        TASSIGN(v677, v678);
        pipe_barrier(PIPE_V);
        TMULS(v677, v615, v539);
        // pto: %19
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v679 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %19
        ;
        uint64_t v680 = (uint64_t) v33;
        TASSIGN(v679, v680);
        pipe_barrier(PIPE_V);
        TADD(v679, v675, v677);
        // pto: %20
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v681 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %20
        ;
        uint64_t v682 = (uint64_t) v34;
        TASSIGN(v681, v682);
        pipe_barrier(PIPE_V);
        TMULS(v681, v619, v540);
        // pto: %21
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v683 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %21
        ;
        uint64_t v684 = (uint64_t) v33;
        TASSIGN(v683, v684);
        pipe_barrier(PIPE_V);
        TADD(v683, v679, v681);
        // pto: %22
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v685 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %22
        ;
        uint64_t v686 = (uint64_t) v34;
        TASSIGN(v685, v686);
        pipe_barrier(PIPE_V);
        TMULS(v685, v623, v541);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v687 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %23
        ;
        uint64_t v688 = (uint64_t) v33;
        TASSIGN(v687, v688);
        pipe_barrier(PIPE_V);
        TADD(v687, v683, v685);
        // pto: %24
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v689 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %24
        ;
        uint64_t v690 = (uint64_t) v33;
        TASSIGN(v689, v690);
        pipe_barrier(PIPE_V);
        RoundMode v691 = RoundMode::CAST_RINT;
        SaturationMode v692 = SaturationMode::ON;
        TCVT(v689, v687, v691, v692);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        v689.SetValidShape(v37, v44);
        // pto: %26
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v693 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %26
        ;
        uint64_t v694 = (uint64_t) v24;
        TASSIGN(v693, v694);
        TMULS(v693, v607, v542);
        // pto: %27
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v695 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %27
        ;
        uint64_t v696 = (uint64_t) v32;
        TASSIGN(v695, v696);
        TMULS(v695, v611, v543);
        // pto: %28
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v697 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %28
        ;
        uint64_t v698 = (uint64_t) v24;
        TASSIGN(v697, v698);
        pipe_barrier(PIPE_V);
        TADD(v697, v693, v695);
        // pto: %29
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v699 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %29
        ;
        uint64_t v700 = (uint64_t) v32;
        TASSIGN(v699, v700);
        pipe_barrier(PIPE_V);
        TMULS(v699, v615, v544);
        // pto: %30
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v701 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %30
        ;
        uint64_t v702 = (uint64_t) v24;
        TASSIGN(v701, v702);
        pipe_barrier(PIPE_V);
        TADD(v701, v697, v699);
        // pto: %31
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v703 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %31
        ;
        uint64_t v704 = (uint64_t) v32;
        TASSIGN(v703, v704);
        pipe_barrier(PIPE_V);
        TMULS(v703, v619, v545);
        // pto: %32
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v705 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %32
        ;
        uint64_t v706 = (uint64_t) v24;
        TASSIGN(v705, v706);
        pipe_barrier(PIPE_V);
        TADD(v705, v701, v703);
        // pto: %33
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v707 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v558, v44);
        // pto: %33
        ;
        uint64_t v708 = (uint64_t) v32;
        TASSIGN(v707, v708);
        pipe_barrier(PIPE_V);
        TMULS(v707, v623, v546);
        // pto: %34
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v709 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %34
        ;
        uint64_t v710 = (uint64_t) v24;
        TASSIGN(v709, v710);
        pipe_barrier(PIPE_V);
        TADD(v709, v705, v707);
        // pto: %35
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v711 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %35
        ;
        uint64_t v712 = (uint64_t) v24;
        TASSIGN(v711, v712);
        pipe_barrier(PIPE_V);
        RoundMode v713 = RoundMode::CAST_RINT;
        SaturationMode v714 = SaturationMode::ON;
        TCVT(v711, v709, v713, v714);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        v711.SetValidShape(v37, v44);
        // pto: %y_flat__iter_v3_pview
        ;
        __gm__ bfloat16_t* v715 = PTOAS__GLOBAL_TENSOR_DATA(v142);
        // pto: %y_flat__iter_v3_pview
        ;
        const int64_t v716 = 0;
        // pto: %y_flat__iter_v3_pview
        ;
        const int64_t v717 = 16384;
        // pto: %y_flat__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v718 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__iter_v3_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v719 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v720 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v715 + (v716 + v549 * v717), v718, v719);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        TSTORE(v720, v645);
        // pto: %y_flat__tile_pview
        ;
        __gm__ bfloat16_t* v721 = PTOAS__GLOBAL_TENSOR_DATA(v142);
        // pto: %y_flat__tile_pview
        ;
        const int64_t v722 = 4096;
        // pto: %y_flat__tile_pview
        ;
        const int64_t v723 = 16384;
        // pto: %y_flat__tile_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v724 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__tile_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v725 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__tile_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v726 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v721 + (v722 + v549 * v723), v724, v725);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        TSTORE(v726, v667);
        // pto: %441
        ;
        __gm__ bfloat16_t* v727 = PTOAS__GLOBAL_TENSOR_DATA(v142);
        // pto: %441
        ;
        const int64_t v728 = 8192;
        // pto: %441
        ;
        const int64_t v729 = 16384;
        // pto: %441
        ;
        pto::Shape<1, 1, 1, 1, 4096> v730 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %441
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v731 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %441
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v732 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v727 + (v728 + v549 * v729), v730, v731);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        TSTORE(v732, v689);
        // pto: %444
        ;
        __gm__ bfloat16_t* v733 = PTOAS__GLOBAL_TENSOR_DATA(v142);
        // pto: %444
        ;
        const int64_t v734 = 12288;
        // pto: %444
        ;
        const int64_t v735 = 16384;
        // pto: %444
        ;
        pto::Shape<1, 1, 1, 1, 4096> v736 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %444
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v737 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %444
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v738 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v733 + (v734 + v549 * v735), v736, v737);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        TSTORE(v738, v711);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      // pto: %445
      ;
      int64_t v739 = (int64_t) ((uint64_t) v524 + (uint64_t) v37);
      // pto: %446
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
      if (v739 < v17) {
        // pto: %449
        ;
        int64_t v740 = (int64_t) ((uint64_t) v739 * (uint64_t) v47);
        // pto: %447
        ;
        float v741 = (v11)[v740];
        // pto: %453
        ;
        int64_t v742 = (int64_t) ((uint64_t) v739 * (uint64_t) v40);
        // pto: %451
        ;
        float v743 = (v12)[v742];
        // pto: %458, %455
        ;
        float v744 = (v12)[(int64_t) ((uint64_t) v742 + (uint64_t) v47)];
        // pto: %462, %459
        ;
        float v745 = (v12)[(int64_t) ((uint64_t) v742 + (uint64_t) v38)];
        // pto: %466, %463
        ;
        float v746 = (v12)[(int64_t) ((uint64_t) v742 + (uint64_t) v69)];
        // pto: %470, %467
        ;
        float v747 = (v11)[(int64_t) ((uint64_t) v740 + (uint64_t) v37)];
        // pto: %474, %471
        ;
        float v748 = (v12)[(int64_t) ((uint64_t) v742 + (uint64_t) v37)];
        // pto: %478, %475
        ;
        float v749 = (v12)[(int64_t) ((uint64_t) v742 + (uint64_t) v70)];
        // pto: %482, %479
        ;
        float v750 = (v12)[(int64_t) ((uint64_t) v742 + (uint64_t) v71)];
        // pto: %486, %483
        ;
        float v751 = (v12)[(int64_t) ((uint64_t) v742 + (uint64_t) v72)];
        // pto: %490, %487
        ;
        float v752 = (v11)[(int64_t) ((uint64_t) v740 + (uint64_t) v49)];
        // pto: %494, %491
        ;
        float v753 = (v12)[(int64_t) ((uint64_t) v742 + (uint64_t) v49)];
        // pto: %498, %495
        ;
        float v754 = (v12)[(int64_t) ((uint64_t) v742 + (uint64_t) v73)];
        // pto: %502, %499
        ;
        float v755 = (v12)[(int64_t) ((uint64_t) v742 + (uint64_t) v74)];
        // pto: %506, %503
        ;
        float v756 = (v12)[(int64_t) ((uint64_t) v742 + (uint64_t) v75)];
        // pto: %510, %507
        ;
        float v757 = (v11)[(int64_t) ((uint64_t) v740 + (uint64_t) v68)];
        // pto: %514, %511
        ;
        float v758 = (v12)[(int64_t) ((uint64_t) v742 + (uint64_t) v68)];
        // pto: %518, %515
        ;
        float v759 = (v12)[(int64_t) ((uint64_t) v742 + (uint64_t) v57)];
        // pto: %522, %519
        ;
        float v760 = (v12)[(int64_t) ((uint64_t) v742 + (uint64_t) v76)];
        // pto: %526, %523
        ;
        float v761 = (v12)[(int64_t) ((uint64_t) v742 + (uint64_t) v52)];
        // pto: %37
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v762 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %37
        ;
        uint64_t v763 = (uint64_t) v32;
        TASSIGN(v762, v763);
        // pto: %528
        ;
        int64_t v764 = v739 < v51 ? v51 : v739;
        // pto: %529
        ;
        __gm__ bfloat16_t* v765 = PTOAS__GLOBAL_TENSOR_DATA(v124);
        // pto: %529
        ;
        const int64_t v766 = 0;
        // pto: %529
        ;
        const int64_t v767 = 4096;
        // pto: %529
        ;
        pto::Shape<1, 1, 1, 1, 4096> v768 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %529
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v769 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %529
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v770 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v765 + (v766 + v764 * v767), v768, v769);
        TLOAD(v762, v770);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %530, %531
        ;
        int64_t v771 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v17 - (uint64_t) v524) + (uint64_t) v78);
        // pto: %532
        ;
        int64_t v772 = v771 < v51 ? v51 : v771;
        // pto: %533
        ;
        int64_t v773 = v772 < v37 ? v772 : v37;
        // pto: %38
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v774 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %38
        ;
        uint64_t v775 = (uint64_t) v25;
        TASSIGN(v774, v775);
        // pto: %540
        ;
        const int64_t v776 = 0;
        // pto: %540
        ;
        __gm__ bfloat16_t* v777 = PTOAS__GLOBAL_TENSOR_DATA(v133);
        // pto: %540
        ;
        const int64_t v778 = 1;
        // pto: %540
        ;
        const int64_t v779 = 1;
        // pto: %540
        ;
        const int64_t v780 = 1;
        // pto: %540
        ;
        int64_t v781 = v773 * v46;
        // pto: %540
        ;
        int64_t v782 = v780 * v781;
        // pto: %540
        ;
        pto::Shape<1, 1, 1, -1, 4096> v783 = pto::Shape<1, 1, 1, -1, 4096>(v778, v779, v780, v773, v44);
        // pto: %540
        ;
        pto::Stride<-1, -1, -1, -1, -1> v784 = pto::Stride<-1, -1, -1, -1, -1>(v779 * v782, v782, v781, v46, v37);
        // pto: %540
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v785 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v777 + (v776 + v764 * v46 + v51 * v37), v783, v784);
        TLOAD(v774, v785);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %39
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v786 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %39
        ;
        uint64_t v787 = (uint64_t) v30;
        TASSIGN(v786, v787);
        // pto: %551
        ;
        const int64_t v788 = 0;
        // pto: %551
        ;
        __gm__ bfloat16_t* v789 = PTOAS__GLOBAL_TENSOR_DATA(v133);
        // pto: %551
        ;
        const int64_t v790 = 1;
        // pto: %551
        ;
        const int64_t v791 = 1;
        // pto: %551
        ;
        const int64_t v792 = 1;
        // pto: %551
        ;
        int64_t v793 = v773 * v46;
        // pto: %551
        ;
        int64_t v794 = v792 * v793;
        // pto: %551
        ;
        pto::Shape<1, 1, 1, -1, 4096> v795 = pto::Shape<1, 1, 1, -1, 4096>(v790, v791, v792, v773, v44);
        // pto: %551
        ;
        pto::Stride<-1, -1, -1, -1, -1> v796 = pto::Stride<-1, -1, -1, -1, -1>(v791 * v794, v794, v793, v46, v37);
        // pto: %551
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v797 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v789 + (v788 + v764 * v46 + v44 * v37), v795, v796);
        TLOAD(v786, v797);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %40
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v798 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %40
        ;
        uint64_t v799 = (uint64_t) v26;
        TASSIGN(v798, v799);
        // pto: %562
        ;
        const int64_t v800 = 0;
        // pto: %562
        ;
        __gm__ bfloat16_t* v801 = PTOAS__GLOBAL_TENSOR_DATA(v133);
        // pto: %562
        ;
        const int64_t v802 = 1;
        // pto: %562
        ;
        const int64_t v803 = 1;
        // pto: %562
        ;
        const int64_t v804 = 1;
        // pto: %562
        ;
        int64_t v805 = v773 * v46;
        // pto: %562
        ;
        int64_t v806 = v804 * v805;
        // pto: %562
        ;
        pto::Shape<1, 1, 1, -1, 4096> v807 = pto::Shape<1, 1, 1, -1, 4096>(v802, v803, v804, v773, v44);
        // pto: %562
        ;
        pto::Stride<-1, -1, -1, -1, -1> v808 = pto::Stride<-1, -1, -1, -1, -1>(v803 * v806, v806, v805, v46, v37);
        // pto: %562
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v809 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v801 + (v800 + v764 * v46 + v45 * v37), v807, v808);
        TLOAD(v798, v809);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %41
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v810 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %41
        ;
        uint64_t v811 = (uint64_t) v33;
        TASSIGN(v810, v811);
        // pto: %573
        ;
        const int64_t v812 = 0;
        // pto: %573
        ;
        __gm__ bfloat16_t* v813 = PTOAS__GLOBAL_TENSOR_DATA(v133);
        // pto: %573
        ;
        const int64_t v814 = 1;
        // pto: %573
        ;
        const int64_t v815 = 1;
        // pto: %573
        ;
        const int64_t v816 = 1;
        // pto: %573
        ;
        int64_t v817 = v773 * v46;
        // pto: %573
        ;
        int64_t v818 = v816 * v817;
        // pto: %573
        ;
        pto::Shape<1, 1, 1, -1, 4096> v819 = pto::Shape<1, 1, 1, -1, 4096>(v814, v815, v816, v773, v44);
        // pto: %573
        ;
        pto::Stride<-1, -1, -1, -1, -1> v820 = pto::Stride<-1, -1, -1, -1, -1>(v815 * v818, v818, v817, v46, v37);
        // pto: %573
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v821 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v813 + (v812 + v764 * v46 + v77 * v37), v819, v820);
        TLOAD(v810, v821);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        // pto: %42
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v822 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %42
        ;
        uint64_t v823 = (uint64_t) v24;
        TASSIGN(v822, v823);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v824 = RoundMode::CAST_ROUND;
        SaturationMode v825 = SaturationMode::ON;
        TCVT(v822, v762, v824, v825);
        // pto: %43
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v826 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %43
        ;
        uint64_t v827 = (uint64_t) v32;
        TASSIGN(v826, v827);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v828 = RoundMode::CAST_ROUND;
        SaturationMode v829 = SaturationMode::ON;
        TCVT(v826, v774, v828, v829);
        // pto: %44
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v830 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %44
        ;
        uint64_t v831 = (uint64_t) v25;
        TASSIGN(v830, v831);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v832 = RoundMode::CAST_ROUND;
        SaturationMode v833 = SaturationMode::ON;
        TCVT(v830, v786, v832, v833);
        // pto: %45
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v834 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %45
        ;
        uint64_t v835 = (uint64_t) v30;
        TASSIGN(v834, v835);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        RoundMode v836 = RoundMode::CAST_ROUND;
        SaturationMode v837 = SaturationMode::ON;
        TCVT(v834, v798, v836, v837);
        // pto: %46
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v838 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %46
        ;
        uint64_t v839 = (uint64_t) v26;
        TASSIGN(v838, v839);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        RoundMode v840 = RoundMode::CAST_ROUND;
        SaturationMode v841 = SaturationMode::ON;
        TCVT(v838, v810, v840, v841);
        // pto: %47
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v842 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %47
        ;
        uint64_t v843 = (uint64_t) v33;
        TASSIGN(v842, v843);
        pipe_barrier(PIPE_V);
        TMULS(v842, v822, v741);
        // pto: %48
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v844 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %48
        ;
        uint64_t v845 = (uint64_t) v34;
        TASSIGN(v844, v845);
        TMULS(v844, v826, v743);
        // pto: %49
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v846 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %49
        ;
        uint64_t v847 = (uint64_t) v33;
        TASSIGN(v846, v847);
        pipe_barrier(PIPE_V);
        TADD(v846, v842, v844);
        // pto: %50
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v848 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %50
        ;
        uint64_t v849 = (uint64_t) v34;
        TASSIGN(v848, v849);
        pipe_barrier(PIPE_V);
        TMULS(v848, v830, v744);
        // pto: %51
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v850 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %51
        ;
        uint64_t v851 = (uint64_t) v33;
        TASSIGN(v850, v851);
        pipe_barrier(PIPE_V);
        TADD(v850, v846, v848);
        // pto: %52
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v852 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %52
        ;
        uint64_t v853 = (uint64_t) v34;
        TASSIGN(v852, v853);
        pipe_barrier(PIPE_V);
        TMULS(v852, v834, v745);
        // pto: %53
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v854 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %53
        ;
        uint64_t v855 = (uint64_t) v33;
        TASSIGN(v854, v855);
        pipe_barrier(PIPE_V);
        TADD(v854, v850, v852);
        // pto: %54
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v856 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %54
        ;
        uint64_t v857 = (uint64_t) v34;
        TASSIGN(v856, v857);
        pipe_barrier(PIPE_V);
        TMULS(v856, v838, v746);
        // pto: %55
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v858 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %55
        ;
        uint64_t v859 = (uint64_t) v33;
        TASSIGN(v858, v859);
        pipe_barrier(PIPE_V);
        TADD(v858, v854, v856);
        // pto: %56
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v860 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %56
        ;
        uint64_t v861 = (uint64_t) v35;
        TASSIGN(v860, v861);
        pipe_barrier(PIPE_V);
        RoundMode v862 = RoundMode::CAST_RINT;
        SaturationMode v863 = SaturationMode::ON;
        TCVT(v860, v858, v862, v863);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v860.SetValidShape(v37, v44);
        // pto: %58
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v864 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %58
        ;
        uint64_t v865 = (uint64_t) v33;
        TASSIGN(v864, v865);
        pipe_barrier(PIPE_V);
        TMULS(v864, v822, v747);
        // pto: %59
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v866 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %59
        ;
        uint64_t v867 = (uint64_t) v34;
        TASSIGN(v866, v867);
        TMULS(v866, v826, v748);
        // pto: %60
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v868 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %60
        ;
        uint64_t v869 = (uint64_t) v33;
        TASSIGN(v868, v869);
        pipe_barrier(PIPE_V);
        TADD(v868, v864, v866);
        // pto: %61
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v870 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %61
        ;
        uint64_t v871 = (uint64_t) v34;
        TASSIGN(v870, v871);
        pipe_barrier(PIPE_V);
        TMULS(v870, v830, v749);
        // pto: %62
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v872 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %62
        ;
        uint64_t v873 = (uint64_t) v33;
        TASSIGN(v872, v873);
        pipe_barrier(PIPE_V);
        TADD(v872, v868, v870);
        // pto: %63
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v874 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %63
        ;
        uint64_t v875 = (uint64_t) v34;
        TASSIGN(v874, v875);
        pipe_barrier(PIPE_V);
        TMULS(v874, v834, v750);
        // pto: %64
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v876 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %64
        ;
        uint64_t v877 = (uint64_t) v33;
        TASSIGN(v876, v877);
        pipe_barrier(PIPE_V);
        TADD(v876, v872, v874);
        // pto: %65
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v878 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %65
        ;
        uint64_t v879 = (uint64_t) v34;
        TASSIGN(v878, v879);
        pipe_barrier(PIPE_V);
        TMULS(v878, v838, v751);
        // pto: %66
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v880 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %66
        ;
        uint64_t v881 = (uint64_t) v33;
        TASSIGN(v880, v881);
        pipe_barrier(PIPE_V);
        TADD(v880, v876, v878);
        // pto: %67
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v882 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %67
        ;
        uint64_t v883 = (uint64_t) v36;
        TASSIGN(v882, v883);
        pipe_barrier(PIPE_V);
        RoundMode v884 = RoundMode::CAST_RINT;
        SaturationMode v885 = SaturationMode::ON;
        TCVT(v882, v880, v884, v885);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        v882.SetValidShape(v37, v44);
        // pto: %69
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v886 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %69
        ;
        uint64_t v887 = (uint64_t) v33;
        TASSIGN(v886, v887);
        pipe_barrier(PIPE_V);
        TMULS(v886, v822, v752);
        // pto: %70
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v888 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %70
        ;
        uint64_t v889 = (uint64_t) v34;
        TASSIGN(v888, v889);
        TMULS(v888, v826, v753);
        // pto: %71
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v890 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %71
        ;
        uint64_t v891 = (uint64_t) v33;
        TASSIGN(v890, v891);
        pipe_barrier(PIPE_V);
        TADD(v890, v886, v888);
        // pto: %72
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v892 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %72
        ;
        uint64_t v893 = (uint64_t) v34;
        TASSIGN(v892, v893);
        pipe_barrier(PIPE_V);
        TMULS(v892, v830, v754);
        // pto: %73
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v894 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %73
        ;
        uint64_t v895 = (uint64_t) v33;
        TASSIGN(v894, v895);
        pipe_barrier(PIPE_V);
        TADD(v894, v890, v892);
        // pto: %74
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v896 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %74
        ;
        uint64_t v897 = (uint64_t) v34;
        TASSIGN(v896, v897);
        pipe_barrier(PIPE_V);
        TMULS(v896, v834, v755);
        // pto: %75
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v898 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %75
        ;
        uint64_t v899 = (uint64_t) v33;
        TASSIGN(v898, v899);
        pipe_barrier(PIPE_V);
        TADD(v898, v894, v896);
        // pto: %76
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v900 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %76
        ;
        uint64_t v901 = (uint64_t) v34;
        TASSIGN(v900, v901);
        pipe_barrier(PIPE_V);
        TMULS(v900, v838, v756);
        // pto: %77
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v902 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %77
        ;
        uint64_t v903 = (uint64_t) v33;
        TASSIGN(v902, v903);
        pipe_barrier(PIPE_V);
        TADD(v902, v898, v900);
        // pto: %78
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v904 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %78
        ;
        uint64_t v905 = (uint64_t) v33;
        TASSIGN(v904, v905);
        pipe_barrier(PIPE_V);
        RoundMode v906 = RoundMode::CAST_RINT;
        SaturationMode v907 = SaturationMode::ON;
        TCVT(v904, v902, v906, v907);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        v904.SetValidShape(v37, v44);
        // pto: %80
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v908 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %80
        ;
        uint64_t v909 = (uint64_t) v24;
        TASSIGN(v908, v909);
        TMULS(v908, v822, v757);
        // pto: %81
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v910 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %81
        ;
        uint64_t v911 = (uint64_t) v32;
        TASSIGN(v910, v911);
        TMULS(v910, v826, v758);
        // pto: %82
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v912 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %82
        ;
        uint64_t v913 = (uint64_t) v24;
        TASSIGN(v912, v913);
        pipe_barrier(PIPE_V);
        TADD(v912, v908, v910);
        // pto: %83
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v914 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %83
        ;
        uint64_t v915 = (uint64_t) v32;
        TASSIGN(v914, v915);
        pipe_barrier(PIPE_V);
        TMULS(v914, v830, v759);
        // pto: %84
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v916 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %84
        ;
        uint64_t v917 = (uint64_t) v24;
        TASSIGN(v916, v917);
        pipe_barrier(PIPE_V);
        TADD(v916, v912, v914);
        // pto: %85
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v918 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %85
        ;
        uint64_t v919 = (uint64_t) v32;
        TASSIGN(v918, v919);
        pipe_barrier(PIPE_V);
        TMULS(v918, v834, v760);
        // pto: %86
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v920 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %86
        ;
        uint64_t v921 = (uint64_t) v24;
        TASSIGN(v920, v921);
        pipe_barrier(PIPE_V);
        TADD(v920, v916, v918);
        // pto: %87
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v922 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v773, v44);
        // pto: %87
        ;
        uint64_t v923 = (uint64_t) v32;
        TASSIGN(v922, v923);
        pipe_barrier(PIPE_V);
        TMULS(v922, v838, v761);
        // pto: %88
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v924 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %88
        ;
        uint64_t v925 = (uint64_t) v24;
        TASSIGN(v924, v925);
        pipe_barrier(PIPE_V);
        TADD(v924, v920, v922);
        // pto: %89
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v926 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %89
        ;
        uint64_t v927 = (uint64_t) v24;
        TASSIGN(v926, v927);
        pipe_barrier(PIPE_V);
        RoundMode v928 = RoundMode::CAST_RINT;
        SaturationMode v929 = SaturationMode::ON;
        TCVT(v926, v924, v928, v929);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        v926.SetValidShape(v37, v44);
        // pto: %y_flat__phi_v9_pview
        ;
        __gm__ bfloat16_t* v930 = PTOAS__GLOBAL_TENSOR_DATA(v142);
        // pto: %y_flat__phi_v9_pview
        ;
        const int64_t v931 = 0;
        // pto: %y_flat__phi_v9_pview
        ;
        const int64_t v932 = 16384;
        // pto: %y_flat__phi_v9_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v933 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__phi_v9_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v934 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__phi_v9_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v935 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v930 + (v931 + v764 * v932), v933, v934);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v935, v860);
        // pto: %660
        ;
        __gm__ bfloat16_t* v936 = PTOAS__GLOBAL_TENSOR_DATA(v142);
        // pto: %660
        ;
        const int64_t v937 = 4096;
        // pto: %660
        ;
        const int64_t v938 = 16384;
        // pto: %660
        ;
        pto::Shape<1, 1, 1, 1, 4096> v939 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %660
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v940 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %660
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v941 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v936 + (v937 + v764 * v938), v939, v940);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v941, v882);
        // pto: %664
        ;
        __gm__ bfloat16_t* v942 = PTOAS__GLOBAL_TENSOR_DATA(v142);
        // pto: %664
        ;
        const int64_t v943 = 8192;
        // pto: %664
        ;
        const int64_t v944 = 16384;
        // pto: %664
        ;
        pto::Shape<1, 1, 1, 1, 4096> v945 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %664
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v946 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %664
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v947 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v942 + (v943 + v764 * v944), v945, v946);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v947, v904);
        // pto: %668
        ;
        __gm__ bfloat16_t* v948 = PTOAS__GLOBAL_TENSOR_DATA(v142);
        // pto: %668
        ;
        const int64_t v949 = 12288;
        // pto: %668
        ;
        const int64_t v950 = 16384;
        // pto: %668
        ;
        pto::Shape<1, 1, 1, 1, 4096> v951 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %668
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v952 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %668
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v953 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v948 + (v949 + v764 * v950), v951, v952);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        TSTORE(v953, v926);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    // pto: %669, %670, %671
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
    if ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v522 - (uint64_t) v523) + (uint64_t) v47) == v37) {
      // pto: %672
      ;
      if (v523 < v17) {
        // pto: %91
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v954 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %91
        ;
        uint64_t v955 = (uint64_t) v32;
        TASSIGN(v954, v955);
        // pto: %673
        ;
        int64_t v956 = v523 < v51 ? v51 : v523;
        // pto: %674
        ;
        __gm__ bfloat16_t* v957 = PTOAS__GLOBAL_TENSOR_DATA(v124);
        // pto: %674
        ;
        const int64_t v958 = 0;
        // pto: %674
        ;
        const int64_t v959 = 4096;
        // pto: %674
        ;
        pto::Shape<1, 1, 1, 1, 4096> v960 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %674
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v961 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %674
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v962 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v957 + (v958 + v956 * v959), v960, v961);
        TLOAD(v954, v962);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %92
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v963 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %92
        ;
        uint64_t v964 = (uint64_t) v24;
        TASSIGN(v963, v964);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v965 = RoundMode::CAST_ROUND;
        SaturationMode v966 = SaturationMode::ON;
        TCVT(v963, v954, v965, v966);
        // pto: %675
        ;
        int64_t v967 = (int64_t) ((uint64_t) v17 - (uint64_t) v523);
        // pto: %676
        ;
        int64_t v968 = v967 < v51 ? v51 : v967;
        // pto: %677
        ;
        int64_t v969 = v968 < v37 ? v968 : v37;
        // pto: %93
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v970 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %93
        ;
        uint64_t v971 = (uint64_t) v25;
        TASSIGN(v970, v971);
        // pto: %682
        ;
        const int64_t v972 = 0;
        // pto: %682
        ;
        __gm__ bfloat16_t* v973 = PTOAS__GLOBAL_TENSOR_DATA(v133);
        // pto: %682
        ;
        const int64_t v974 = 1;
        // pto: %682
        ;
        const int64_t v975 = 1;
        // pto: %682
        ;
        const int64_t v976 = 1;
        // pto: %682
        ;
        int64_t v977 = v969 * v46;
        // pto: %682
        ;
        int64_t v978 = v976 * v977;
        // pto: %682
        ;
        pto::Shape<1, 1, 1, -1, 4096> v979 = pto::Shape<1, 1, 1, -1, 4096>(v974, v975, v976, v969, v44);
        // pto: %682
        ;
        pto::Stride<-1, -1, -1, -1, -1> v980 = pto::Stride<-1, -1, -1, -1, -1>(v975 * v978, v978, v977, v46, v37);
        // pto: %682
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v981 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v973 + (v972 + v956 * v46 + v51 * v37), v979, v980);
        TLOAD(v970, v981);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %94
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v982 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %94
        ;
        uint64_t v983 = (uint64_t) v32;
        TASSIGN(v982, v983);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v984 = RoundMode::CAST_ROUND;
        SaturationMode v985 = SaturationMode::ON;
        TCVT(v982, v970, v984, v985);
        // pto: %95
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v986 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %95
        ;
        uint64_t v987 = (uint64_t) v30;
        TASSIGN(v986, v987);
        // pto: %693
        ;
        const int64_t v988 = 0;
        // pto: %693
        ;
        __gm__ bfloat16_t* v989 = PTOAS__GLOBAL_TENSOR_DATA(v133);
        // pto: %693
        ;
        const int64_t v990 = 1;
        // pto: %693
        ;
        const int64_t v991 = 1;
        // pto: %693
        ;
        const int64_t v992 = 1;
        // pto: %693
        ;
        int64_t v993 = v969 * v46;
        // pto: %693
        ;
        int64_t v994 = v992 * v993;
        // pto: %693
        ;
        pto::Shape<1, 1, 1, -1, 4096> v995 = pto::Shape<1, 1, 1, -1, 4096>(v990, v991, v992, v969, v44);
        // pto: %693
        ;
        pto::Stride<-1, -1, -1, -1, -1> v996 = pto::Stride<-1, -1, -1, -1, -1>(v991 * v994, v994, v993, v46, v37);
        // pto: %693
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v997 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v989 + (v988 + v956 * v46 + v44 * v37), v995, v996);
        TLOAD(v986, v997);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %96
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v998 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %96
        ;
        uint64_t v999 = (uint64_t) v25;
        TASSIGN(v998, v999);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v1000 = RoundMode::CAST_ROUND;
        SaturationMode v1001 = SaturationMode::ON;
        TCVT(v998, v986, v1000, v1001);
        // pto: %97
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1002 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %97
        ;
        uint64_t v1003 = (uint64_t) v26;
        TASSIGN(v1002, v1003);
        // pto: %704
        ;
        const int64_t v1004 = 0;
        // pto: %704
        ;
        __gm__ bfloat16_t* v1005 = PTOAS__GLOBAL_TENSOR_DATA(v133);
        // pto: %704
        ;
        const int64_t v1006 = 1;
        // pto: %704
        ;
        const int64_t v1007 = 1;
        // pto: %704
        ;
        const int64_t v1008 = 1;
        // pto: %704
        ;
        int64_t v1009 = v969 * v46;
        // pto: %704
        ;
        int64_t v1010 = v1008 * v1009;
        // pto: %704
        ;
        pto::Shape<1, 1, 1, -1, 4096> v1011 = pto::Shape<1, 1, 1, -1, 4096>(v1006, v1007, v1008, v969, v44);
        // pto: %704
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1012 = pto::Stride<-1, -1, -1, -1, -1>(v1007 * v1010, v1010, v1009, v46, v37);
        // pto: %704
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1013 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1005 + (v1004 + v956 * v46 + v45 * v37), v1011, v1012);
        TLOAD(v1002, v1013);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %98
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1014 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %98
        ;
        uint64_t v1015 = (uint64_t) v30;
        TASSIGN(v1014, v1015);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v1016 = RoundMode::CAST_ROUND;
        SaturationMode v1017 = SaturationMode::ON;
        TCVT(v1014, v1002, v1016, v1017);
        // pto: %99
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1018 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %99
        ;
        uint64_t v1019 = (uint64_t) v33;
        TASSIGN(v1018, v1019);
        // pto: %715
        ;
        const int64_t v1020 = 0;
        // pto: %715
        ;
        __gm__ bfloat16_t* v1021 = PTOAS__GLOBAL_TENSOR_DATA(v133);
        // pto: %715
        ;
        const int64_t v1022 = 1;
        // pto: %715
        ;
        const int64_t v1023 = 1;
        // pto: %715
        ;
        const int64_t v1024 = 1;
        // pto: %715
        ;
        int64_t v1025 = v969 * v46;
        // pto: %715
        ;
        int64_t v1026 = v1024 * v1025;
        // pto: %715
        ;
        pto::Shape<1, 1, 1, -1, 4096> v1027 = pto::Shape<1, 1, 1, -1, 4096>(v1022, v1023, v1024, v969, v44);
        // pto: %715
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1028 = pto::Stride<-1, -1, -1, -1, -1>(v1023 * v1026, v1026, v1025, v46, v37);
        // pto: %715
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1029 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1021 + (v1020 + v956 * v46 + v77 * v37), v1027, v1028);
        TLOAD(v1018, v1029);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %100
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1030 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %100
        ;
        uint64_t v1031 = (uint64_t) v26;
        TASSIGN(v1030, v1031);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v1032 = RoundMode::CAST_ROUND;
        SaturationMode v1033 = SaturationMode::ON;
        TCVT(v1030, v1018, v1032, v1033);
        // pto: %720
        ;
        int64_t v1034 = (int64_t) ((uint64_t) v523 * (uint64_t) v47);
        // pto: %719
        ;
        float v1035 = (v11)[v1034];
        // pto: %101
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1036 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %101
        ;
        uint64_t v1037 = (uint64_t) v33;
        TASSIGN(v1036, v1037);
        pipe_barrier(PIPE_V);
        TMULS(v1036, v963, v1035);
        // pto: %723
        ;
        int64_t v1038 = (int64_t) ((uint64_t) v523 * (uint64_t) v40);
        // pto: %722
        ;
        float v1039 = (v12)[v1038];
        // pto: %102
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1040 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %102
        ;
        uint64_t v1041 = (uint64_t) v34;
        TASSIGN(v1040, v1041);
        TMULS(v1040, v982, v1039);
        // pto: %103
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1042 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %103
        ;
        uint64_t v1043 = (uint64_t) v33;
        TASSIGN(v1042, v1043);
        pipe_barrier(PIPE_V);
        TADD(v1042, v1036, v1040);
        // pto: %730, %728
        ;
        float v1044 = (v12)[(int64_t) ((uint64_t) v1038 + (uint64_t) v47)];
        // pto: %104
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1045 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %104
        ;
        uint64_t v1046 = (uint64_t) v34;
        TASSIGN(v1045, v1046);
        pipe_barrier(PIPE_V);
        TMULS(v1045, v998, v1044);
        // pto: %105
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1047 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %105
        ;
        uint64_t v1048 = (uint64_t) v33;
        TASSIGN(v1047, v1048);
        pipe_barrier(PIPE_V);
        TADD(v1047, v1042, v1045);
        // pto: %736, %734
        ;
        float v1049 = (v12)[(int64_t) ((uint64_t) v1038 + (uint64_t) v38)];
        // pto: %106
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1050 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %106
        ;
        uint64_t v1051 = (uint64_t) v34;
        TASSIGN(v1050, v1051);
        pipe_barrier(PIPE_V);
        TMULS(v1050, v1014, v1049);
        // pto: %107
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1052 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %107
        ;
        uint64_t v1053 = (uint64_t) v33;
        TASSIGN(v1052, v1053);
        pipe_barrier(PIPE_V);
        TADD(v1052, v1047, v1050);
        // pto: %742, %740
        ;
        float v1054 = (v12)[(int64_t) ((uint64_t) v1038 + (uint64_t) v69)];
        // pto: %108
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1055 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %108
        ;
        uint64_t v1056 = (uint64_t) v34;
        TASSIGN(v1055, v1056);
        pipe_barrier(PIPE_V);
        TMULS(v1055, v1030, v1054);
        // pto: %109
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1057 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %109
        ;
        uint64_t v1058 = (uint64_t) v33;
        TASSIGN(v1057, v1058);
        pipe_barrier(PIPE_V);
        TADD(v1057, v1052, v1055);
        // pto: %110
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1059 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %110
        ;
        uint64_t v1060 = (uint64_t) v33;
        TASSIGN(v1059, v1060);
        pipe_barrier(PIPE_V);
        RoundMode v1061 = RoundMode::CAST_RINT;
        SaturationMode v1062 = SaturationMode::ON;
        TCVT(v1059, v1057, v1061, v1062);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1059.SetValidShape(v37, v44);
        // pto: %y_flat__rv_v4_main_pview
        ;
        __gm__ bfloat16_t* v1063 = PTOAS__GLOBAL_TENSOR_DATA(v142);
        // pto: %y_flat__rv_v4_main_pview
        ;
        const int64_t v1064 = 0;
        // pto: %y_flat__rv_v4_main_pview
        ;
        const int64_t v1065 = 16384;
        // pto: %y_flat__rv_v4_main_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1066 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__rv_v4_main_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1067 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__rv_v4_main_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1068 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1063 + (v1064 + v956 * v1065), v1066, v1067);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1068, v1059);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        // pto: %750, %748
        ;
        float v1069 = (v11)[(int64_t) ((uint64_t) v1034 + (uint64_t) v37)];
        // pto: %112
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1070 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %112
        ;
        uint64_t v1071 = (uint64_t) v33;
        TASSIGN(v1070, v1071);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        TMULS(v1070, v963, v1069);
        // pto: %753, %751
        ;
        float v1072 = (v12)[(int64_t) ((uint64_t) v1038 + (uint64_t) v37)];
        // pto: %113
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1073 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %113
        ;
        uint64_t v1074 = (uint64_t) v34;
        TASSIGN(v1073, v1074);
        TMULS(v1073, v982, v1072);
        // pto: %114
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1075 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %114
        ;
        uint64_t v1076 = (uint64_t) v33;
        TASSIGN(v1075, v1076);
        pipe_barrier(PIPE_V);
        TADD(v1075, v1070, v1073);
        // pto: %759, %757
        ;
        float v1077 = (v12)[(int64_t) ((uint64_t) v1038 + (uint64_t) v70)];
        // pto: %115
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1078 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %115
        ;
        uint64_t v1079 = (uint64_t) v34;
        TASSIGN(v1078, v1079);
        pipe_barrier(PIPE_V);
        TMULS(v1078, v998, v1077);
        // pto: %116
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1080 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %116
        ;
        uint64_t v1081 = (uint64_t) v33;
        TASSIGN(v1080, v1081);
        pipe_barrier(PIPE_V);
        TADD(v1080, v1075, v1078);
        // pto: %765, %763
        ;
        float v1082 = (v12)[(int64_t) ((uint64_t) v1038 + (uint64_t) v71)];
        // pto: %117
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1083 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %117
        ;
        uint64_t v1084 = (uint64_t) v34;
        TASSIGN(v1083, v1084);
        pipe_barrier(PIPE_V);
        TMULS(v1083, v1014, v1082);
        // pto: %118
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1085 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %118
        ;
        uint64_t v1086 = (uint64_t) v33;
        TASSIGN(v1085, v1086);
        pipe_barrier(PIPE_V);
        TADD(v1085, v1080, v1083);
        // pto: %771, %769
        ;
        float v1087 = (v12)[(int64_t) ((uint64_t) v1038 + (uint64_t) v72)];
        // pto: %119
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1088 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %119
        ;
        uint64_t v1089 = (uint64_t) v34;
        TASSIGN(v1088, v1089);
        pipe_barrier(PIPE_V);
        TMULS(v1088, v1030, v1087);
        // pto: %120
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1090 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %120
        ;
        uint64_t v1091 = (uint64_t) v33;
        TASSIGN(v1090, v1091);
        pipe_barrier(PIPE_V);
        TADD(v1090, v1085, v1088);
        // pto: %121
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1092 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %121
        ;
        uint64_t v1093 = (uint64_t) v33;
        TASSIGN(v1092, v1093);
        pipe_barrier(PIPE_V);
        RoundMode v1094 = RoundMode::CAST_RINT;
        SaturationMode v1095 = SaturationMode::ON;
        TCVT(v1092, v1090, v1094, v1095);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1092.SetValidShape(v37, v44);
        // pto: %777
        ;
        __gm__ bfloat16_t* v1096 = PTOAS__GLOBAL_TENSOR_DATA(v142);
        // pto: %777
        ;
        const int64_t v1097 = 4096;
        // pto: %777
        ;
        const int64_t v1098 = 16384;
        // pto: %777
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1099 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %777
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1100 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %777
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1101 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1096 + (v1097 + v956 * v1098), v1099, v1100);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1101, v1092);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        // pto: %780, %778
        ;
        float v1102 = (v11)[(int64_t) ((uint64_t) v1034 + (uint64_t) v49)];
        // pto: %123
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1103 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %123
        ;
        uint64_t v1104 = (uint64_t) v33;
        TASSIGN(v1103, v1104);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        TMULS(v1103, v963, v1102);
        // pto: %783, %781
        ;
        float v1105 = (v12)[(int64_t) ((uint64_t) v1038 + (uint64_t) v49)];
        // pto: %124
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1106 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %124
        ;
        uint64_t v1107 = (uint64_t) v34;
        TASSIGN(v1106, v1107);
        TMULS(v1106, v982, v1105);
        // pto: %125
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1108 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %125
        ;
        uint64_t v1109 = (uint64_t) v33;
        TASSIGN(v1108, v1109);
        pipe_barrier(PIPE_V);
        TADD(v1108, v1103, v1106);
        // pto: %789, %787
        ;
        float v1110 = (v12)[(int64_t) ((uint64_t) v1038 + (uint64_t) v73)];
        // pto: %126
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1111 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %126
        ;
        uint64_t v1112 = (uint64_t) v34;
        TASSIGN(v1111, v1112);
        pipe_barrier(PIPE_V);
        TMULS(v1111, v998, v1110);
        // pto: %127
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1113 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %127
        ;
        uint64_t v1114 = (uint64_t) v33;
        TASSIGN(v1113, v1114);
        pipe_barrier(PIPE_V);
        TADD(v1113, v1108, v1111);
        // pto: %795, %793
        ;
        float v1115 = (v12)[(int64_t) ((uint64_t) v1038 + (uint64_t) v74)];
        // pto: %128
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1116 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %128
        ;
        uint64_t v1117 = (uint64_t) v34;
        TASSIGN(v1116, v1117);
        pipe_barrier(PIPE_V);
        TMULS(v1116, v1014, v1115);
        // pto: %129
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1118 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %129
        ;
        uint64_t v1119 = (uint64_t) v33;
        TASSIGN(v1118, v1119);
        pipe_barrier(PIPE_V);
        TADD(v1118, v1113, v1116);
        // pto: %801, %799
        ;
        float v1120 = (v12)[(int64_t) ((uint64_t) v1038 + (uint64_t) v75)];
        // pto: %130
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1121 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %130
        ;
        uint64_t v1122 = (uint64_t) v34;
        TASSIGN(v1121, v1122);
        pipe_barrier(PIPE_V);
        TMULS(v1121, v1030, v1120);
        // pto: %131
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1123 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %131
        ;
        uint64_t v1124 = (uint64_t) v33;
        TASSIGN(v1123, v1124);
        pipe_barrier(PIPE_V);
        TADD(v1123, v1118, v1121);
        // pto: %132
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1125 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %132
        ;
        uint64_t v1126 = (uint64_t) v33;
        TASSIGN(v1125, v1126);
        pipe_barrier(PIPE_V);
        RoundMode v1127 = RoundMode::CAST_RINT;
        SaturationMode v1128 = SaturationMode::ON;
        TCVT(v1125, v1123, v1127, v1128);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1125.SetValidShape(v37, v44);
        // pto: %807
        ;
        __gm__ bfloat16_t* v1129 = PTOAS__GLOBAL_TENSOR_DATA(v142);
        // pto: %807
        ;
        const int64_t v1130 = 8192;
        // pto: %807
        ;
        const int64_t v1131 = 16384;
        // pto: %807
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1132 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %807
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1133 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %807
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1134 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1129 + (v1130 + v956 * v1131), v1132, v1133);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1134, v1125);
        // pto: %810, %808
        ;
        float v1135 = (v11)[(int64_t) ((uint64_t) v1034 + (uint64_t) v68)];
        // pto: %134
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1136 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %134
        ;
        uint64_t v1137 = (uint64_t) v24;
        TASSIGN(v1136, v1137);
        TMULS(v1136, v963, v1135);
        // pto: %813, %811
        ;
        float v1138 = (v12)[(int64_t) ((uint64_t) v1038 + (uint64_t) v68)];
        // pto: %135
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1139 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %135
        ;
        uint64_t v1140 = (uint64_t) v32;
        TASSIGN(v1139, v1140);
        TMULS(v1139, v982, v1138);
        // pto: %136
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1141 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %136
        ;
        uint64_t v1142 = (uint64_t) v24;
        TASSIGN(v1141, v1142);
        pipe_barrier(PIPE_V);
        TADD(v1141, v1136, v1139);
        // pto: %819, %817
        ;
        float v1143 = (v12)[(int64_t) ((uint64_t) v1038 + (uint64_t) v57)];
        // pto: %137
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1144 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %137
        ;
        uint64_t v1145 = (uint64_t) v32;
        TASSIGN(v1144, v1145);
        pipe_barrier(PIPE_V);
        TMULS(v1144, v998, v1143);
        // pto: %138
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1146 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %138
        ;
        uint64_t v1147 = (uint64_t) v24;
        TASSIGN(v1146, v1147);
        pipe_barrier(PIPE_V);
        TADD(v1146, v1141, v1144);
        // pto: %825, %823
        ;
        float v1148 = (v12)[(int64_t) ((uint64_t) v1038 + (uint64_t) v76)];
        // pto: %139
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1149 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %139
        ;
        uint64_t v1150 = (uint64_t) v32;
        TASSIGN(v1149, v1150);
        pipe_barrier(PIPE_V);
        TMULS(v1149, v1014, v1148);
        // pto: %140
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1151 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %140
        ;
        uint64_t v1152 = (uint64_t) v24;
        TASSIGN(v1151, v1152);
        pipe_barrier(PIPE_V);
        TADD(v1151, v1146, v1149);
        // pto: %831, %829
        ;
        float v1153 = (v12)[(int64_t) ((uint64_t) v1038 + (uint64_t) v52)];
        // pto: %141
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1154 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969, v44);
        // pto: %141
        ;
        uint64_t v1155 = (uint64_t) v32;
        TASSIGN(v1154, v1155);
        pipe_barrier(PIPE_V);
        TMULS(v1154, v1030, v1153);
        // pto: %142
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1156 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %142
        ;
        uint64_t v1157 = (uint64_t) v24;
        TASSIGN(v1156, v1157);
        pipe_barrier(PIPE_V);
        TADD(v1156, v1151, v1154);
        // pto: %143
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1158 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v44);
        // pto: %143
        ;
        uint64_t v1159 = (uint64_t) v24;
        TASSIGN(v1158, v1159);
        pipe_barrier(PIPE_V);
        RoundMode v1160 = RoundMode::CAST_RINT;
        SaturationMode v1161 = SaturationMode::ON;
        TCVT(v1158, v1156, v1160, v1161);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1158.SetValidShape(v37, v44);
        // pto: %837
        ;
        __gm__ bfloat16_t* v1162 = PTOAS__GLOBAL_TENSOR_DATA(v142);
        // pto: %837
        ;
        const int64_t v1163 = 12288;
        // pto: %837
        ;
        const int64_t v1164 = 16384;
        // pto: %837
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1165 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %837
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1166 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %837
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1167 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1162 + (v1163 + v956 * v1164), v1165, v1166);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v1167, v1158);
      };
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  pipe_barrier(PIPE_ALL);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}