#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void cube(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int32_t v22 = 1;
  // pto: %c0_i64
  const int64_t v23 = 0;
  // pto: %c65536_i64
  const int64_t v24 = 65536;
  // pto: %c32768_i64
  const int64_t v25 = 32768;
  // pto: %c131072_i64
  const int64_t v26 = 131072;
  // pto: %c196608_i64
  const int64_t v27 = 196608;
  // pto: %c32768_index
  const int64_t v28 = 32768;
  // pto: %c1_index
  const int64_t v29 = 1;
  // pto: %c8_index
  const int64_t v30 = 8;
  const int64_t v31 = 64;
  // pto: %c256_index
  const int64_t v32 = 256;
  // pto: %c16_index
  const int64_t v33 = 16;
  // pto: %c4194304_index
  const int64_t v34 = 4194304;
  // pto: %c65536_index
  const int64_t v35 = 65536;
  const int64_t v36 = 128;
  // pto: %c512_index
  const int64_t v37 = 512;
  // pto: %c32_index
  const int64_t v38 = 32;
  // pto: %c33554432_index
  const int64_t v39 = 33554432;
  // pto: %c262144_index
  const int64_t v40 = 262144;
  // pto: %c4096_index
  const int64_t v41 = 4096;
  // pto: %c8192_index
  const int64_t v42 = 8192;
  // pto: %c4_index
  const int64_t v43 = 4;
  // pto: %c55296_index
  const int64_t v44 = 55296;
  // pto: %c0_index
  const int64_t v45 = 0;
  // pto: %c15_index
  const int64_t v46 = 15;
  // pto: %c192_index
  const int64_t v47 = 192;
  // pto: %c24_index
  const int64_t v48 = 24;
  // pto: %c7_index
  const int64_t v49 = 7;
  // pto: %c2_index
  const int64_t v50 = 2;
  // pto: %c3_index
  const int64_t v51 = 3;
  // pto: %c5_index
  const int64_t v52 = 5;
  // pto: %c6_index
  const int64_t v53 = 6;
  // pto: %c240_index
  const int64_t v54 = 240;
  // pto: %c1024_index
  const int64_t v55 = 1024;
  // pto: %c241_index
  const int64_t v56 = 241;
  // pto: %c9216_index
  const int64_t v57 = 9216;
  // pto: %c72_index
  const int64_t v58 = 72;
  // pto: %c27648_index
  const int64_t v59 = 27648;
  // pto: %c63_index
  const int64_t v60 = 63;
  // pto: %c36864_index
  const int64_t v61 = 36864;
  // pto: %heads__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v65 = (int64_t) v17;
  // pto: %heads__ssa_v0_view
  int64_t v66 = v65 * v28;
  // pto: %heads__ssa_v0_view
  int64_t v67 = v64 * v66;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v68 = pto::Shape<1, 1, 1, -1, -1>(v62, v63, v64, v65, v28);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v69 = pto::Stride<-1, -1, -1, -1, -1>(v63 * v67, v67, v66, v28, v29);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v70 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v68, v69);
  // pto: %wo_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v71 = pto::Shape<-1, -1, -1, -1, -1>(v30, v31, v32, v33, v33);
  // pto: %wo_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v34, v35, v32, v33, v29);
  // pto: %wo_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v73 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v71, v72);
  // pto: %wo_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v74 = pto::Shape<-1, -1, -1, -1, -1>(v29, v36, v37, v33, v38);
  // pto: %wo_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v75 = pto::Stride<-1, -1, -1, -1, -1>(v39, v40, v37, v38, v29);
  // pto: %wo_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v76 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v3, v74, v75);
  // pto: %quantized__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v79 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v80 = (int64_t) v17;
  // pto: %quantized__ssa_v0_view
  int64_t v81 = v80 * v42;
  // pto: %quantized__ssa_v0_view
  int64_t v82 = v79 * v81;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v83 = pto::Shape<1, 1, 1, -1, -1>(v77, v78, v79, v80, v42);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v84 = pto::Stride<-1, -1, -1, -1, -1>(v78 * v82, v82, v81, v42, v29);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v85 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v83, v84);
  // pto: %accum__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v88 = 1;
  // pto: %accum__ssa_v0_view
  int64_t v89 = (int64_t) v18;
  // pto: %accum__ssa_v0_view
  int64_t v90 = v89 * v42;
  // pto: %accum__ssa_v0_view
  int64_t v91 = v88 * v90;
  // pto: %accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v92 = pto::Shape<1, 1, 1, -1, -1>(v86, v87, v88, v89, v42);
  // pto: %accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v93 = pto::Stride<-1, -1, -1, -1, -1>(v87 * v91, v91, v90, v42, v29);
  // pto: %accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v94 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v92, v93);
  // pto: %integer_accum__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v97 = 1;
  // pto: %integer_accum__ssa_v0_view
  int64_t v98 = (int64_t) v19;
  // pto: %integer_accum__ssa_v0_view
  int64_t v99 = v98 * v41;
  // pto: %integer_accum__ssa_v0_view
  int64_t v100 = v97 * v99;
  // pto: %integer_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v101 = pto::Shape<1, 1, 1, -1, -1>(v95, v96, v97, v98, v41);
  // pto: %integer_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v102 = pto::Stride<-1, -1, -1, -1, -1>(v96 * v100, v100, v99, v41, v29);
  // pto: %integer_accum__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v103 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v101, v102);
  // pto: %signals__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v105 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v106 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v107 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v108 = v44 * v29;
  // pto: %signals__ssa_v0_view
  int64_t v109 = v107 * v108;
  // pto: %signals__ssa_v0_view
  int64_t v110 = v106 * v109;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v111 = pto::Shape<1, 1, 1, 1, -1>(v104, v105, v106, v107, v44);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v112 = pto::Stride<-1, -1, -1, -1, -1>(v105 * v110, v110, v109, v108, v29);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v113 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v111, v112);
  // pto: %seed_fast_acc__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v114 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %seed_fast_acc__phi_v7
  uint64_t v115 = (uint64_t) v23;
  TASSIGN(v114, v115);
  // pto: %223
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v116 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %223
  uint64_t v117 = (uint64_t) v23;
  TASSIGN(v116, v117);
  // pto: %261
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v118 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %261
  uint64_t v119 = (uint64_t) v23;
  TASSIGN(v118, v119);
  // pto: %seed_narrow_acc__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
  // pto: %seed_narrow_acc__phi_v7
  uint64_t v121 = (uint64_t) v23;
  TASSIGN(v120, v121);
  // pto: %v4_wide_acc__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v122 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
  // pto: %v4_wide_acc__phi_v7
  uint64_t v123 = (uint64_t) v23;
  TASSIGN(v122, v123);
  // pto: %v4_narrow_acc__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
  // pto: %v4_narrow_acc__phi_v7
  uint64_t v125 = (uint64_t) v23;
  TASSIGN(v124, v125);
  // pto: %worker__ssa_v0
  int64_t v126 = (int64_t) v20;
  // pto: %63
  int64_t v127 = (int64_t) ((uint64_t) v126 * (uint64_t) v36);
  // pto: %64
  int64_t v128 = v127 < v45 ? v45 : v127;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v129 = PTOAS__GLOBAL_TENSOR_DATA(v113);
  // pto: %signals__ssa_v0_pview
  const int64_t v130 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v131 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v132 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v133 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v129 + (v130 + v128), v131, v132);
  __gm__ int32_t* v134 = PTOAS__GLOBAL_TENSOR_DATA(v133);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v134);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
  // pto: %t__tile
  int32_t v135 = (v16)[v127];
  // pto: %66
  int32_t v136 = (int32_t) ((uint32_t) v135 + (uint32_t) v22);
  pipe_barrier(PIPE_ALL);
  pto::comm::NotifyOp v137 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v133, v136, v137);
  // pto: %68, %69
  int64_t v138 = (int64_t) ((uint64_t) v17 + (uint64_t) v46) / v33;
  // pto: %70
  if (v17 >= v47) {
    for (int64_t v139 = v126; v139 < v31; v139 += v48) {
      // pto: %71
      ;
      int64_t v140 = v139 / v30;
      // pto: %72
      ;
      int64_t v141 = v139 % v30;
      // pto: %73, %74, %75
      ;
      int64_t v142 = v141 < v45 ? (int64_t) ((uint64_t) v141 + (uint64_t) v30) : v141;
      // pto: %76
      ;
      int64_t v143 = (int64_t) ((uint64_t) v142 * (uint64_t) v36);
      // pto: %77, %78
      ;
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v144 = v45; v144 < ((int64_t) ((uint64_t) v138 + (uint64_t) v49) / v30); v144 += v29) {
        // pto: %79
        ;
        int64_t v145 = (int64_t) ((uint64_t) v144 * (uint64_t) v30);
        // pto: %flat_offset, %81, %82, %80
        ;
        int32_t v146 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v144 * (uint64_t) v31) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
        // pto: %83
        ;
        int64_t v147 = (int64_t) v146;
        // pto: %84
        ;
        int64_t v148 = v147 < v45 ? v45 : v147;
        // pto: %85
        ;
        int64_t v149 = (int64_t) ((uint64_t) v145 + (uint64_t) v29);
        // pto: %86
        ;
        // pto: %seed_same_start__phi_v3
        ;
        int64_t v150;
        if (v149 < v138) {
          // pto: %89, %90, %91, %92, %87
          ;
          int32_t v151 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v149 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %93
          ;
          int64_t v152 = (int64_t) v151;
          // pto: %94
          ;
          int64_t v153 = v152 < v45 ? v45 : v152;
          // pto: %95, %seed_same_start__phi_v2
          ;
          v150 = v153 != v148 ? v45 : v29;
        } else {
          v150 = v29;
        };
        // pto: %96
        ;
        int64_t v154 = (int64_t) ((uint64_t) v145 + (uint64_t) v50);
        // pto: %97
        ;
        // pto: %seed_same_start__phi_v6
        ;
        int64_t v155;
        if (v154 < v138) {
          // pto: %100, %101, %102, %103, %98
          ;
          int32_t v156 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v154 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %104
          ;
          int64_t v157 = (int64_t) v156;
          // pto: %105
          ;
          int64_t v158 = v157 < v45 ? v45 : v157;
          // pto: %106, %seed_same_start__phi_v5
          ;
          int64_t v159 = v158 != v148 ? v45 : v150;
          v155 = v159;
        } else {
          v155 = v150;
        };
        // pto: %107
        ;
        int64_t v160 = (int64_t) ((uint64_t) v145 + (uint64_t) v51);
        // pto: %108
        ;
        // pto: %seed_same_start__phi_v9
        ;
        int64_t v161;
        if (v160 < v138) {
          // pto: %111, %112, %113, %114, %109
          ;
          int32_t v162 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v160 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %115
          ;
          int64_t v163 = (int64_t) v162;
          // pto: %116
          ;
          int64_t v164 = v163 < v45 ? v45 : v163;
          // pto: %117, %seed_same_start__phi_v8
          ;
          int64_t v165 = v164 != v148 ? v45 : v155;
          v161 = v165;
        } else {
          v161 = v155;
        };
        // pto: %118
        ;
        int64_t v166 = (int64_t) ((uint64_t) v145 + (uint64_t) v43);
        // pto: %119
        ;
        // pto: %seed_same_start__phi_v12
        ;
        int64_t v167;
        if (v166 < v138) {
          // pto: %122, %123, %124, %125, %120
          ;
          int32_t v168 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v166 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %126
          ;
          int64_t v169 = (int64_t) v168;
          // pto: %127
          ;
          int64_t v170 = v169 < v45 ? v45 : v169;
          // pto: %128, %seed_same_start__phi_v11
          ;
          int64_t v171 = v170 != v148 ? v45 : v161;
          v167 = v171;
        } else {
          v167 = v161;
        };
        // pto: %129
        ;
        int64_t v172 = (int64_t) ((uint64_t) v145 + (uint64_t) v52);
        // pto: %130
        ;
        // pto: %seed_same_start__phi_v15
        ;
        int64_t v173;
        if (v172 < v138) {
          // pto: %133, %134, %135, %136, %131
          ;
          int32_t v174 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v172 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %137
          ;
          int64_t v175 = (int64_t) v174;
          // pto: %138
          ;
          int64_t v176 = v175 < v45 ? v45 : v175;
          // pto: %139, %seed_same_start__phi_v14
          ;
          int64_t v177 = v176 != v148 ? v45 : v167;
          v173 = v177;
        } else {
          v173 = v167;
        };
        // pto: %140
        ;
        int64_t v178 = (int64_t) ((uint64_t) v145 + (uint64_t) v53);
        // pto: %141
        ;
        // pto: %seed_same_start__phi_v18
        ;
        int64_t v179;
        if (v178 < v138) {
          // pto: %144, %145, %146, %147, %142
          ;
          int32_t v180 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v178 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %148
          ;
          int64_t v181 = (int64_t) v180;
          // pto: %149
          ;
          int64_t v182 = v181 < v45 ? v45 : v181;
          // pto: %150, %seed_same_start__phi_v17
          ;
          int64_t v183 = v182 != v148 ? v45 : v173;
          v179 = v183;
        } else {
          v179 = v173;
        };
        // pto: %151
        ;
        int64_t v184 = (int64_t) ((uint64_t) v145 + (uint64_t) v49);
        // pto: %152
        ;
        // pto: %seed_same_start__phi_v21
        ;
        int64_t v185;
        if (v184 < v138) {
          // pto: %155, %156, %157, %158, %153
          ;
          int32_t v186 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v184 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
          // pto: %159
          ;
          int64_t v187 = (int64_t) v186;
          // pto: %160
          ;
          int64_t v188 = v187 < v45 ? v45 : v187;
          // pto: %161, %seed_same_start__phi_v20
          ;
          int64_t v189 = v188 != v148 ? v45 : v179;
          v185 = v189;
        } else {
          v185 = v179;
        };
        // pto: %162, %seed_same_start__phi_v25
        ;
        int64_t v190 = v148 > v54 ? v45 : v185;
        // pto: %163
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        if (v190 == v29) {
          int64_t v191 = (int64_t) ((uint64_t) v144 * (uint64_t) v36);
          // pto: %165
          ;
          int64_t v192 = (int64_t) ((uint64_t) v17 - (uint64_t) v191);
          // pto: %166
          ;
          int64_t v193 = v192 < v36 ? v192 : v36;
          // pto: %167
          ;
          int64_t v194 = (int64_t) ((uint64_t) v148 * (uint64_t) v33);
          // pto: %seed_fast_seed_x__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v195 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v32);
          // pto: %seed_fast_seed_x__tile
          ;
          uint64_t v196 = (uint64_t) v23;
          TASSIGN(v195, v196);
          // pto: %168
          ;
          int64_t v197 = v191 < v45 ? v45 : v191;
          // pto: %169
          ;
          int64_t v198 = (int64_t) ((uint64_t) v140 * (uint64_t) v41);
          // pto: %170
          ;
          int64_t v199 = (int64_t) ((uint64_t) v198 + (uint64_t) v194);
          // pto: %171
          ;
          int64_t v200 = v199 < v45 ? v45 : v199;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v201 = 0;
          // pto: %heads__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v202 = PTOAS__GLOBAL_TENSOR_DATA(v70);
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v203 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v204 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          const int64_t v205 = 1;
          // pto: %heads__ssa_v0_pview
          ;
          int64_t v206 = v193 * v28;
          // pto: %heads__ssa_v0_pview
          ;
          int64_t v207 = v205 * v206;
          // pto: %heads__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, -1, 256> v208 = pto::Shape<1, 1, 1, -1, 256>(v203, v204, v205, v193, v32);
          // pto: %heads__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v209 = pto::Stride<-1, -1, -1, -1, -1>(v204 * v207, v207, v206, v28, v29);
          // pto: %heads__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v210 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v202 + (v201 + v197 * v28 + v200 * v29), v208, v209);
          TLOAD(v195, v210);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %seed_fast_seed_w__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
          // pto: %seed_fast_seed_w__tile
          ;
          uint64_t v212 = (uint64_t) v24;
          TASSIGN(v211, v212);
          // pto: %172
          ;
          int64_t v213 = v140 < v45 ? v45 : v140;
          // pto: %173
          ;
          int64_t v214 = v143 / v33;
          // pto: %174
          ;
          int64_t v215 = v214 < v45 ? v45 : v214;
          // pto: %175
          ;
          int64_t v216 = v194 / v33;
          // pto: %176
          ;
          int64_t v217 = v216 < v45 ? v45 : v216;
          // pto: %wo_a__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v218 = PTOAS__GLOBAL_TENSOR_DATA(v73);
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v219 = 0;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v220 = 4194304;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v221 = 65536;
          // pto: %wo_a__ssa_v0_pview
          ;
          const int64_t v222 = 256;
          // pto: %wo_a__ssa_v0_pview
          ;
          pto::Shape<1, 8, 16, 16, 16> v223 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %wo_a__ssa_v0_pview
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v224 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %wo_a__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v225 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v218 + ((v219 + v213 * v220) + v215 * v221 + v217 * v222), v223, v224);
          TLOAD(v211, v225);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %seed_fast_acc__tile_l0_init_storage
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v226 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v36, v36);
          // pto: %seed_fast_acc__tile_l0_init_storage
          ;
          uint64_t v227 = (uint64_t) v23;
          TASSIGN(v226, v227);
          v226.SetValidShape(v193, v36);
          // pto: %seed_fast_acc__tile_l0_a
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v228 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
          // pto: %seed_fast_acc__tile_l0_a
          ;
          uint64_t v229 = (uint64_t) v23;
          TASSIGN(v228, v229);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          uint16_t v230 = static_cast<uint16_t>(v45);
          uint16_t v231 = static_cast<uint16_t>(v45);
          TEXTRACT(v228, v195, v230, v231);
          // pto: %seed_fast_acc__tile_l0_b
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
          // pto: %seed_fast_acc__tile_l0_b
          ;
          uint64_t v233 = (uint64_t) v23;
          TASSIGN(v232, v233);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v234 = static_cast<uint16_t>(v45);
          uint16_t v235 = static_cast<uint16_t>(v45);
          TEXTRACT(v232, v211, v234, v235);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          // pto: %0
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v236 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
          // pto: %0
          ;
          uint64_t v237 = (uint64_t) v25;
          TASSIGN(v236, v237);
          uint16_t v238 = static_cast<uint16_t>(v45);
          uint16_t v239 = static_cast<uint16_t>(v36);
          TEXTRACT(v236, v195, v238, v239);
          // pto: %1
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
          // pto: %1
          ;
          uint64_t v241 = (uint64_t) v25;
          TASSIGN(v240, v241);
          uint16_t v242 = static_cast<uint16_t>(v36);
          uint16_t v243 = static_cast<uint16_t>(v45);
          TEXTRACT(v240, v211, v242, v243);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          TMATMUL(v226, v228, v232);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          TMATMUL_ACC(v226, v226, v236, v240);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
          for (int64_t v244 = v29; v244 < v46; v244 += v50) {
            // pto: %177
            ;
            int64_t v245 = (int64_t) ((uint64_t) v244 * (uint64_t) v33);
            // pto: %178, %179
            ;
            int64_t v246 = (int64_t) ((uint64_t) v148 + (uint64_t) v245) % v32;
            // pto: %180, %181, %182
            ;
            int64_t v247 = v246 < v45 ? (int64_t) ((uint64_t) v246 + (uint64_t) v32) : v246;
            // pto: %185, %184, %186
            ;
            int64_t v248 = (int64_t) ((uint64_t) v148 + (uint64_t) ((int64_t) (uint64_t) v245 + (uint64_t) v33)) % v32;
            // pto: %187, %188, %189
            ;
            int64_t v249 = v248 < v45 ? (int64_t) ((uint64_t) v248 + (uint64_t) v32) : v248;
            // pto: %190
            ;
            // pto: %191
            ;
            int64_t v250 = v193 < v36 ? v193 : v36;
            v114.SetValidShape(v250, v36);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            if (v247 <= v54) {
              // pto: %192
              ;
              int64_t v251 = (int64_t) ((uint64_t) v247 * (uint64_t) v33);
              // pto: %seed_fast_packet_x__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v252 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v32);
              // pto: %seed_fast_packet_x__tile
              ;
              uint64_t v253 = (uint64_t) v23;
              TASSIGN(v252, v253);
              // pto: %195
              ;
              int64_t v254 = (int64_t) ((uint64_t) v198 + (uint64_t) v251);
              // pto: %196
              ;
              int64_t v255 = v254 < v45 ? v45 : v254;
              // pto: %197
              ;
              const int64_t v256 = 0;
              // pto: %197
              ;
              __gm__ bfloat16_t* v257 = PTOAS__GLOBAL_TENSOR_DATA(v70);
              // pto: %197
              ;
              const int64_t v258 = 1;
              // pto: %197
              ;
              const int64_t v259 = 1;
              // pto: %197
              ;
              const int64_t v260 = 1;
              // pto: %197
              ;
              int64_t v261 = v193 * v28;
              // pto: %197
              ;
              int64_t v262 = v260 * v261;
              // pto: %197
              ;
              pto::Shape<1, 1, 1, -1, 256> v263 = pto::Shape<1, 1, 1, -1, 256>(v258, v259, v260, v193, v32);
              // pto: %197
              ;
              pto::Stride<-1, -1, -1, -1, -1> v264 = pto::Stride<-1, -1, -1, -1, -1>(v259 * v262, v262, v261, v28, v29);
              // pto: %197
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v265 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v257 + (v256 + v197 * v28 + v255 * v29), v263, v264);
              TLOAD(v252, v265);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
              // pto: %seed_fast_packet_w__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
              // pto: %seed_fast_packet_w__tile
              ;
              uint64_t v267 = (uint64_t) v24;
              TASSIGN(v266, v267);
              // pto: %201
              ;
              int64_t v268 = v251 / v33;
              // pto: %202
              ;
              int64_t v269 = v268 < v45 ? v45 : v268;
              // pto: %203
              ;
              __gm__ bfloat16_t* v270 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %203
              ;
              const int64_t v271 = 0;
              // pto: %203
              ;
              const int64_t v272 = 4194304;
              // pto: %203
              ;
              const int64_t v273 = 65536;
              // pto: %203
              ;
              const int64_t v274 = 256;
              // pto: %203
              ;
              pto::Shape<1, 8, 16, 16, 16> v275 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %203
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v276 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %203
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v277 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v270 + ((v271 + v213 * v272) + v215 * v273 + v269 * v274), v275, v276);
              TLOAD(v266, v277);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
              // pto: %seed_fast_acc__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v278 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
              // pto: %seed_fast_acc__iter_v1_l0_a
              ;
              uint64_t v279 = (uint64_t) v23;
              TASSIGN(v278, v279);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
              uint16_t v280 = static_cast<uint16_t>(v45);
              uint16_t v281 = static_cast<uint16_t>(v45);
              TEXTRACT(v278, v252, v280, v281);
              // pto: %seed_fast_acc__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v282 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %seed_fast_acc__iter_v1_l0_b
              ;
              uint64_t v283 = (uint64_t) v23;
              TASSIGN(v282, v283);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
              uint16_t v284 = static_cast<uint16_t>(v45);
              uint16_t v285 = static_cast<uint16_t>(v45);
              TEXTRACT(v282, v266, v284, v285);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
              // pto: %3
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v286 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
              // pto: %3
              ;
              uint64_t v287 = (uint64_t) v25;
              TASSIGN(v286, v287);
              uint16_t v288 = static_cast<uint16_t>(v45);
              uint16_t v289 = static_cast<uint16_t>(v36);
              TEXTRACT(v286, v252, v288, v289);
              // pto: %4
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %4
              ;
              uint64_t v291 = (uint64_t) v25;
              TASSIGN(v290, v291);
              uint16_t v292 = static_cast<uint16_t>(v36);
              uint16_t v293 = static_cast<uint16_t>(v45);
              TEXTRACT(v290, v266, v292, v293);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v226, v226, v278, v282);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
              TMATMUL_ACC(v226, v226, v286, v290);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              for (int64_t v294 = v45; v294 < v33; v294 += v29) {
                // pto: %204, %205
                ;
                int64_t v295 = (int64_t) ((uint64_t) v247 + (uint64_t) v294) % v32;
                // pto: %206, %207, %208
                ;
                int64_t v296 = v295 < v45 ? (int64_t) ((uint64_t) v295 + (uint64_t) v32) : v295;
                // pto: %209
                ;
                int64_t v297 = (int64_t) ((uint64_t) v296 * (uint64_t) v33);
                // pto: %seed_fast_wrap_x__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v33);
                // pto: %seed_fast_wrap_x__tile
                ;
                uint64_t v299 = (uint64_t) v23;
                TASSIGN(v298, v299);
                // pto: %212
                ;
                int64_t v300 = (int64_t) ((uint64_t) v198 + (uint64_t) v297);
                // pto: %213
                ;
                int64_t v301 = v300 < v45 ? v45 : v300;
                // pto: %214
                ;
                const int64_t v302 = 0;
                // pto: %214
                ;
                __gm__ bfloat16_t* v303 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                // pto: %214
                ;
                const int64_t v304 = 1;
                // pto: %214
                ;
                const int64_t v305 = 1;
                // pto: %214
                ;
                const int64_t v306 = 1;
                // pto: %214
                ;
                int64_t v307 = v193 * v28;
                // pto: %214
                ;
                int64_t v308 = v306 * v307;
                // pto: %214
                ;
                pto::Shape<1, 1, 1, -1, 16> v309 = pto::Shape<1, 1, 1, -1, 16>(v304, v305, v306, v193, v33);
                // pto: %214
                ;
                pto::Stride<-1, -1, -1, -1, -1> v310 = pto::Stride<-1, -1, -1, -1, -1>(v305 * v308, v308, v307, v28, v29);
                // pto: %214
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v311 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v303 + (v302 + v197 * v28 + v301 * v29), v309, v310);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v298, v311);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
                // pto: %seed_fast_wrap_w__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %seed_fast_wrap_w__tile
                ;
                uint64_t v313 = (uint64_t) v24;
                TASSIGN(v312, v313);
                // pto: %218
                ;
                int64_t v314 = v297 / v33;
                // pto: %219
                ;
                int64_t v315 = v314 < v45 ? v45 : v314;
                // pto: %220
                ;
                __gm__ bfloat16_t* v316 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                // pto: %220
                ;
                const int64_t v317 = 0;
                // pto: %220
                ;
                const int64_t v318 = 4194304;
                // pto: %220
                ;
                const int64_t v319 = 65536;
                // pto: %220
                ;
                const int64_t v320 = 256;
                // pto: %220
                ;
                pto::Shape<1, 8, 1, 16, 16> v321 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %220
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v322 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %220
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v323 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v316 + ((v317 + v213 * v318) + v215 * v319 + v315 * v320), v321, v322);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
                TLOAD(v312, v323);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
                // pto: %lhs_slice_0_textract
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v324 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v33);
                // pto: %lhs_slice_0_textract
                ;
                uint64_t v325 = (uint64_t) v23;
                TASSIGN(v324, v325);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
                uint16_t v326 = static_cast<uint16_t>(v45);
                uint16_t v327 = static_cast<uint16_t>(v45);
                TEXTRACT(v324, v298, v326, v327);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                // pto: %rhs_slice_0_textract
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %rhs_slice_0_textract
                ;
                uint64_t v329 = (uint64_t) v23;
                TASSIGN(v328, v329);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
                uint16_t v330 = static_cast<uint16_t>(v45);
                uint16_t v331 = static_cast<uint16_t>(v45);
                TEXTRACT(v328, v312, v330, v331);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v226, v226, v324, v328);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              };
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            // pto: %221
            ;
            v116.SetValidShape(v250, v36);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
            if (v249 <= v54) {
              // pto: %224
              ;
              int64_t v332 = (int64_t) ((uint64_t) v249 * (uint64_t) v33);
              // pto: %6
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v333 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v32);
              // pto: %6
              ;
              uint64_t v334 = (uint64_t) v26;
              TASSIGN(v333, v334);
              // pto: %227
              ;
              int64_t v335 = (int64_t) ((uint64_t) v198 + (uint64_t) v332);
              // pto: %228
              ;
              int64_t v336 = v335 < v45 ? v45 : v335;
              // pto: %229
              ;
              const int64_t v337 = 0;
              // pto: %229
              ;
              __gm__ bfloat16_t* v338 = PTOAS__GLOBAL_TENSOR_DATA(v70);
              // pto: %229
              ;
              const int64_t v339 = 1;
              // pto: %229
              ;
              const int64_t v340 = 1;
              // pto: %229
              ;
              const int64_t v341 = 1;
              // pto: %229
              ;
              int64_t v342 = v193 * v28;
              // pto: %229
              ;
              int64_t v343 = v341 * v342;
              // pto: %229
              ;
              pto::Shape<1, 1, 1, -1, 256> v344 = pto::Shape<1, 1, 1, -1, 256>(v339, v340, v341, v193, v32);
              // pto: %229
              ;
              pto::Stride<-1, -1, -1, -1, -1> v345 = pto::Stride<-1, -1, -1, -1, -1>(v340 * v343, v343, v342, v28, v29);
              // pto: %229
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v346 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v338 + (v337 + v197 * v28 + v336 * v29), v344, v345);
              TLOAD(v333, v346);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
              // pto: %7
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
              // pto: %7
              ;
              uint64_t v348 = (uint64_t) v27;
              TASSIGN(v347, v348);
              // pto: %233
              ;
              int64_t v349 = v332 / v33;
              // pto: %234
              ;
              int64_t v350 = v349 < v45 ? v45 : v349;
              // pto: %235
              ;
              __gm__ bfloat16_t* v351 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %235
              ;
              const int64_t v352 = 0;
              // pto: %235
              ;
              const int64_t v353 = 4194304;
              // pto: %235
              ;
              const int64_t v354 = 65536;
              // pto: %235
              ;
              const int64_t v355 = 256;
              // pto: %235
              ;
              pto::Shape<1, 8, 16, 16, 16> v356 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %235
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v357 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %235
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v358 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v351 + ((v352 + v213 * v353) + v215 * v354 + v350 * v355), v356, v357);
              TLOAD(v347, v358);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
              // pto: %8
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v359 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
              // pto: %8
              ;
              uint64_t v360 = (uint64_t) v23;
              TASSIGN(v359, v360);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
              uint16_t v361 = static_cast<uint16_t>(v45);
              uint16_t v362 = static_cast<uint16_t>(v45);
              TEXTRACT(v359, v333, v361, v362);
              // pto: %9
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v363 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %9
              ;
              uint64_t v364 = (uint64_t) v23;
              TASSIGN(v363, v364);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
              uint16_t v365 = static_cast<uint16_t>(v45);
              uint16_t v366 = static_cast<uint16_t>(v45);
              TEXTRACT(v363, v347, v365, v366);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
              // pto: %10
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v367 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
              // pto: %10
              ;
              uint64_t v368 = (uint64_t) v25;
              TASSIGN(v367, v368);
              uint16_t v369 = static_cast<uint16_t>(v45);
              uint16_t v370 = static_cast<uint16_t>(v36);
              TEXTRACT(v367, v333, v369, v370);
              // pto: %11
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v371 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %11
              ;
              uint64_t v372 = (uint64_t) v25;
              TASSIGN(v371, v372);
              uint16_t v373 = static_cast<uint16_t>(v36);
              uint16_t v374 = static_cast<uint16_t>(v45);
              TEXTRACT(v371, v347, v373, v374);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v114, v114, v359, v363);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
              TMATMUL_ACC(v114, v114, v367, v371);
            } else {
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
              for (int64_t v375 = v45; v375 < v33; v375 += v29) {
                // pto: %237, %238
                ;
                int64_t v376 = (int64_t) ((uint64_t) v249 + (uint64_t) v375) % v32;
                // pto: %239, %240, %241
                ;
                int64_t v377 = v376 < v45 ? (int64_t) ((uint64_t) v376 + (uint64_t) v32) : v376;
                // pto: %242
                ;
                int64_t v378 = (int64_t) ((uint64_t) v377 * (uint64_t) v33);
                // pto: %14
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v379 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v33);
                // pto: %14
                ;
                uint64_t v380 = (uint64_t) v26;
                TASSIGN(v379, v380);
                // pto: %245
                ;
                int64_t v381 = (int64_t) ((uint64_t) v198 + (uint64_t) v378);
                // pto: %246
                ;
                int64_t v382 = v381 < v45 ? v45 : v381;
                // pto: %247
                ;
                const int64_t v383 = 0;
                // pto: %247
                ;
                __gm__ bfloat16_t* v384 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                // pto: %247
                ;
                const int64_t v385 = 1;
                // pto: %247
                ;
                const int64_t v386 = 1;
                // pto: %247
                ;
                const int64_t v387 = 1;
                // pto: %247
                ;
                int64_t v388 = v193 * v28;
                // pto: %247
                ;
                int64_t v389 = v387 * v388;
                // pto: %247
                ;
                pto::Shape<1, 1, 1, -1, 16> v390 = pto::Shape<1, 1, 1, -1, 16>(v385, v386, v387, v193, v33);
                // pto: %247
                ;
                pto::Stride<-1, -1, -1, -1, -1> v391 = pto::Stride<-1, -1, -1, -1, -1>(v386 * v389, v389, v388, v28, v29);
                // pto: %247
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v392 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v384 + (v383 + v197 * v28 + v382 * v29), v390, v391);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                TLOAD(v379, v392);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %15
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v393 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %15
                ;
                uint64_t v394 = (uint64_t) v27;
                TASSIGN(v393, v394);
                // pto: %251
                ;
                int64_t v395 = v378 / v33;
                // pto: %252
                ;
                int64_t v396 = v395 < v45 ? v45 : v395;
                // pto: %253
                ;
                __gm__ bfloat16_t* v397 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                // pto: %253
                ;
                const int64_t v398 = 0;
                // pto: %253
                ;
                const int64_t v399 = 4194304;
                // pto: %253
                ;
                const int64_t v400 = 65536;
                // pto: %253
                ;
                const int64_t v401 = 256;
                // pto: %253
                ;
                pto::Shape<1, 8, 1, 16, 16> v402 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %253
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v403 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %253
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v404 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v397 + ((v398 + v213 * v399) + v215 * v400 + v396 * v401), v402, v403);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
                TLOAD(v393, v404);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %16
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v405 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v33);
                // pto: %16
                ;
                uint64_t v406 = (uint64_t) v23;
                TASSIGN(v405, v406);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
                uint16_t v407 = static_cast<uint16_t>(v45);
                uint16_t v408 = static_cast<uint16_t>(v45);
                TEXTRACT(v405, v379, v407, v408);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
                // pto: %17
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v409 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %17
                ;
                uint64_t v410 = (uint64_t) v23;
                TASSIGN(v409, v410);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v411 = static_cast<uint16_t>(v45);
                uint16_t v412 = static_cast<uint16_t>(v45);
                TEXTRACT(v409, v393, v411, v412);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v114, v114, v405, v409);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
              };
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %254, %255
          ;
          int64_t v413 = (int64_t) ((uint64_t) v148 + (uint64_t) v54) % v32;
          // pto: %256, %257, %258
          ;
          int64_t v414 = v413 < v45 ? (int64_t) ((uint64_t) v413 + (uint64_t) v32) : v413;
          // pto: %259
          ;
          // pto: %260
          ;
          int64_t v415 = v193 < v36 ? v193 : v36;
          v118.SetValidShape(v415, v36);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
          if (v414 <= v54) {
            // pto: %262
            ;
            int64_t v416 = (int64_t) ((uint64_t) v414 * (uint64_t) v33);
            // pto: %19
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v417 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v32);
            // pto: %19
            ;
            uint64_t v418 = (uint64_t) v23;
            TASSIGN(v417, v418);
            // pto: %265
            ;
            int64_t v419 = (int64_t) ((uint64_t) v198 + (uint64_t) v416);
            // pto: %266
            ;
            int64_t v420 = v419 < v45 ? v45 : v419;
            // pto: %267
            ;
            const int64_t v421 = 0;
            // pto: %267
            ;
            __gm__ bfloat16_t* v422 = PTOAS__GLOBAL_TENSOR_DATA(v70);
            // pto: %267
            ;
            const int64_t v423 = 1;
            // pto: %267
            ;
            const int64_t v424 = 1;
            // pto: %267
            ;
            const int64_t v425 = 1;
            // pto: %267
            ;
            int64_t v426 = v193 * v28;
            // pto: %267
            ;
            int64_t v427 = v425 * v426;
            // pto: %267
            ;
            pto::Shape<1, 1, 1, -1, 256> v428 = pto::Shape<1, 1, 1, -1, 256>(v423, v424, v425, v193, v32);
            // pto: %267
            ;
            pto::Stride<-1, -1, -1, -1, -1> v429 = pto::Stride<-1, -1, -1, -1, -1>(v424 * v427, v427, v426, v28, v29);
            // pto: %267
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v430 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v422 + (v421 + v197 * v28 + v420 * v29), v428, v429);
            TLOAD(v417, v430);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %20
            ;
            Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v431 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
            // pto: %20
            ;
            uint64_t v432 = (uint64_t) v24;
            TASSIGN(v431, v432);
            // pto: %271
            ;
            int64_t v433 = v416 / v33;
            // pto: %272
            ;
            int64_t v434 = v433 < v45 ? v45 : v433;
            // pto: %273
            ;
            __gm__ bfloat16_t* v435 = PTOAS__GLOBAL_TENSOR_DATA(v73);
            // pto: %273
            ;
            const int64_t v436 = 0;
            // pto: %273
            ;
            const int64_t v437 = 4194304;
            // pto: %273
            ;
            const int64_t v438 = 65536;
            // pto: %273
            ;
            const int64_t v439 = 256;
            // pto: %273
            ;
            pto::Shape<1, 8, 16, 16, 16> v440 = pto::Shape<1, 8, 16, 16, 16>();
            // pto: %273
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v441 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %273
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v442 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v435 + ((v436 + v213 * v437) + v215 * v438 + v434 * v439), v440, v441);
            TLOAD(v431, v442);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %21
            ;
            Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v443 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
            // pto: %21
            ;
            uint64_t v444 = (uint64_t) v23;
            TASSIGN(v443, v444);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            uint16_t v445 = static_cast<uint16_t>(v45);
            uint16_t v446 = static_cast<uint16_t>(v45);
            TEXTRACT(v443, v417, v445, v446);
            // pto: %22
            ;
            Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v447 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
            // pto: %22
            ;
            uint64_t v448 = (uint64_t) v23;
            TASSIGN(v447, v448);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v449 = static_cast<uint16_t>(v45);
            uint16_t v450 = static_cast<uint16_t>(v45);
            TEXTRACT(v447, v431, v449, v450);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            // pto: %23
            ;
            Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v451 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v36);
            // pto: %23
            ;
            uint64_t v452 = (uint64_t) v25;
            TASSIGN(v451, v452);
            uint16_t v453 = static_cast<uint16_t>(v45);
            uint16_t v454 = static_cast<uint16_t>(v36);
            TEXTRACT(v451, v417, v453, v454);
            // pto: %24
            ;
            Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v455 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
            // pto: %24
            ;
            uint64_t v456 = (uint64_t) v25;
            TASSIGN(v455, v456);
            uint16_t v457 = static_cast<uint16_t>(v36);
            uint16_t v458 = static_cast<uint16_t>(v45);
            TEXTRACT(v455, v431, v457, v458);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v226, v226, v443, v447);
            pipe_barrier(PIPE_M);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
            TMATMUL_ACC(v226, v226, v451, v455);
          } else {
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            for (int64_t v459 = v45; v459 < v33; v459 += v29) {
              // pto: %275, %276
              ;
              int64_t v460 = (int64_t) ((uint64_t) v414 + (uint64_t) v459) % v32;
              // pto: %277, %278, %279
              ;
              int64_t v461 = v460 < v45 ? (int64_t) ((uint64_t) v460 + (uint64_t) v32) : v460;
              // pto: %280
              ;
              int64_t v462 = (int64_t) ((uint64_t) v461 * (uint64_t) v33);
              // pto: %27
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v463 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v193, v33);
              // pto: %27
              ;
              uint64_t v464 = (uint64_t) v23;
              TASSIGN(v463, v464);
              // pto: %283
              ;
              int64_t v465 = (int64_t) ((uint64_t) v198 + (uint64_t) v462);
              // pto: %284
              ;
              int64_t v466 = v465 < v45 ? v45 : v465;
              // pto: %285
              ;
              const int64_t v467 = 0;
              // pto: %285
              ;
              __gm__ bfloat16_t* v468 = PTOAS__GLOBAL_TENSOR_DATA(v70);
              // pto: %285
              ;
              const int64_t v469 = 1;
              // pto: %285
              ;
              const int64_t v470 = 1;
              // pto: %285
              ;
              const int64_t v471 = 1;
              // pto: %285
              ;
              int64_t v472 = v193 * v28;
              // pto: %285
              ;
              int64_t v473 = v471 * v472;
              // pto: %285
              ;
              pto::Shape<1, 1, 1, -1, 16> v474 = pto::Shape<1, 1, 1, -1, 16>(v469, v470, v471, v193, v33);
              // pto: %285
              ;
              pto::Stride<-1, -1, -1, -1, -1> v475 = pto::Stride<-1, -1, -1, -1, -1>(v470 * v473, v473, v472, v28, v29);
              // pto: %285
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v476 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v468 + (v467 + v197 * v28 + v466 * v29), v474, v475);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              TLOAD(v463, v476);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %28
              ;
              Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v477 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %28
              ;
              uint64_t v478 = (uint64_t) v24;
              TASSIGN(v477, v478);
              // pto: %289
              ;
              int64_t v479 = v462 / v33;
              // pto: %290
              ;
              int64_t v480 = v479 < v45 ? v45 : v479;
              // pto: %291
              ;
              __gm__ bfloat16_t* v481 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %291
              ;
              const int64_t v482 = 0;
              // pto: %291
              ;
              const int64_t v483 = 4194304;
              // pto: %291
              ;
              const int64_t v484 = 65536;
              // pto: %291
              ;
              const int64_t v485 = 256;
              // pto: %291
              ;
              pto::Shape<1, 8, 1, 16, 16> v486 = pto::Shape<1, 8, 1, 16, 16>();
              // pto: %291
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v487 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %291
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v488 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v481 + ((v482 + v213 * v483) + v215 * v484 + v480 * v485), v486, v487);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              TLOAD(v477, v488);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %29
              ;
              Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v489 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v193, v33);
              // pto: %29
              ;
              uint64_t v490 = (uint64_t) v23;
              TASSIGN(v489, v490);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
              uint16_t v491 = static_cast<uint16_t>(v45);
              uint16_t v492 = static_cast<uint16_t>(v45);
              TEXTRACT(v489, v463, v491, v492);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              // pto: %30
              ;
              Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v493 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %30
              ;
              uint64_t v494 = (uint64_t) v23;
              TASSIGN(v493, v494);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v495 = static_cast<uint16_t>(v45);
              uint16_t v496 = static_cast<uint16_t>(v45);
              TEXTRACT(v493, v477, v495, v496);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v226, v226, v489, v493);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            };
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          };
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          // pto: %seed_fast_acc__rv_v2
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v497 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v193, v36);
          // pto: %seed_fast_acc__rv_v2
          ;
          uint64_t v498 = (uint64_t) v23;
          TASSIGN(v497, v498);
          // pto: %293, %294
          ;
          int64_t v499 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v55) + (uint64_t) v143);
          // pto: %295
          ;
          int64_t v500 = v499 < v45 ? v45 : v499;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v501 = 0;
          // pto: %accum__ssa_v0_pview
          ;
          __gm__ float* v502 = PTOAS__GLOBAL_TENSOR_DATA(v94);
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v503 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v504 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          const int64_t v505 = 1;
          // pto: %accum__ssa_v0_pview
          ;
          int64_t v506 = v193 * v42;
          // pto: %accum__ssa_v0_pview
          ;
          int64_t v507 = v505 * v506;
          // pto: %accum__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, -1, 128> v508 = pto::Shape<1, 1, 1, -1, 128>(v503, v504, v505, v193, v36);
          // pto: %accum__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v509 = pto::Stride<-1, -1, -1, -1, -1>(v504 * v507, v507, v506, v42, v29);
          // pto: %accum__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v510 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v502 + (v501 + v197 * v42 + v500 * v29), v508, v509);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          TSTORE(v510, v497);
        } else {
          for (int64_t v511 = v45; v511 < v30; v511 += v29) {
            // pto: %296
            ;
            int64_t v512 = (int64_t) ((uint64_t) v145 + (uint64_t) v511);
            // pto: %297
            ;
            if (v512 < v138) {
              // pto: %298
              ;
              int64_t v513 = (int64_t) ((uint64_t) v512 * (uint64_t) v33);
              // pto: %299
              ;
              int64_t v514 = (int64_t) ((uint64_t) v17 - (uint64_t) v513);
              // pto: %300
              ;
              int64_t v515 = v514 < v33 ? v514 : v33;
              // pto: %302, %303, %304, %305, %301
              ;
              int32_t v516 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v512 * (uint64_t) v30) + (uint64_t) v140) * (uint64_t) v30) + (uint64_t) v142)];
              // pto: %306
              ;
              int64_t v517 = (int64_t) v516;
              // pto: %307
              ;
              int64_t v518 = v517 < v45 ? v45 : v517;
              // pto: %seed_narrow_acc__tile
              ;
              Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v519 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %seed_narrow_acc__tile
              ;
              uint64_t v520 = (uint64_t) v23;
              TASSIGN(v519, v520);
              wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              for (int64_t v521 = v45; v521 < v33; v521 += v29) {
                // pto: %308
                ;
                int64_t v522 = (int64_t) ((uint64_t) v521 * (uint64_t) v33);
                // pto: %309, %310
                ;
                int64_t v523 = (int64_t) ((uint64_t) v518 + (uint64_t) v522) % v32;
                // pto: %311, %312, %313
                ;
                int64_t v524 = v523 < v45 ? (int64_t) ((uint64_t) v523 + (uint64_t) v32) : v523;
                // pto: %314
                ;
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                if (v524 <= v54) {
                  // pto: %315
                  ;
                  int64_t v525 = (int64_t) ((uint64_t) v524 * (uint64_t) v33);
                  // pto: %seed_narrow_packet_x__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v526 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v515, v32);
                  // pto: %seed_narrow_packet_x__tile
                  ;
                  uint64_t v527 = (uint64_t) v24;
                  TASSIGN(v526, v527);
                  // pto: %316
                  ;
                  int64_t v528 = v513 < v45 ? v45 : v513;
                  // pto: %317, %318
                  ;
                  int64_t v529 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v41) + (uint64_t) v525);
                  // pto: %319
                  ;
                  int64_t v530 = v529 < v45 ? v45 : v529;
                  // pto: %320
                  ;
                  const int64_t v531 = 0;
                  // pto: %320
                  ;
                  __gm__ bfloat16_t* v532 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                  // pto: %320
                  ;
                  const int64_t v533 = 1;
                  // pto: %320
                  ;
                  const int64_t v534 = 1;
                  // pto: %320
                  ;
                  const int64_t v535 = 1;
                  // pto: %320
                  ;
                  int64_t v536 = v515 * v28;
                  // pto: %320
                  ;
                  int64_t v537 = v535 * v536;
                  // pto: %320
                  ;
                  pto::Shape<1, 1, 1, -1, 256> v538 = pto::Shape<1, 1, 1, -1, 256>(v533, v534, v535, v515, v32);
                  // pto: %320
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v539 = pto::Stride<-1, -1, -1, -1, -1>(v534 * v537, v537, v536, v28, v29);
                  // pto: %320
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v540 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v532 + (v531 + v528 * v28 + v530 * v29), v538, v539);
                  TLOAD(v526, v540);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  // pto: %seed_narrow_packet_w__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v541 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
                  // pto: %seed_narrow_packet_w__tile
                  ;
                  uint64_t v542 = (uint64_t) v23;
                  TASSIGN(v541, v542);
                  // pto: %321
                  ;
                  int64_t v543 = v140 < v45 ? v45 : v140;
                  // pto: %322
                  ;
                  int64_t v544 = v143 / v33;
                  // pto: %323
                  ;
                  int64_t v545 = v544 < v45 ? v45 : v544;
                  // pto: %324
                  ;
                  int64_t v546 = v525 / v33;
                  // pto: %325
                  ;
                  int64_t v547 = v546 < v45 ? v45 : v546;
                  // pto: %326
                  ;
                  __gm__ bfloat16_t* v548 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                  // pto: %326
                  ;
                  const int64_t v549 = 0;
                  // pto: %326
                  ;
                  const int64_t v550 = 4194304;
                  // pto: %326
                  ;
                  const int64_t v551 = 65536;
                  // pto: %326
                  ;
                  const int64_t v552 = 256;
                  // pto: %326
                  ;
                  pto::Shape<1, 8, 16, 16, 16> v553 = pto::Shape<1, 8, 16, 16, 16>();
                  // pto: %326
                  ;
                  pto::Stride<4194304, 65536, 256, 16, 1> v554 = pto::Stride<4194304, 65536, 256, 16, 1>();
                  // pto: %326
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v555 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v548 + ((v549 + v543 * v550) + v545 * v551 + v547 * v552), v553, v554);
                  TLOAD(v541, v555);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  // pto: %seed_narrow_acc__iter_v1_l0_a
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v556 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v515, v36);
                  // pto: %seed_narrow_acc__iter_v1_l0_a
                  ;
                  uint64_t v557 = (uint64_t) v23;
                  TASSIGN(v556, v557);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  uint16_t v558 = static_cast<uint16_t>(v45);
                  uint16_t v559 = static_cast<uint16_t>(v45);
                  TEXTRACT(v556, v526, v558, v559);
                  // pto: %seed_narrow_acc__iter_v1_l0_b
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v560 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %seed_narrow_acc__iter_v1_l0_b
                  ;
                  uint64_t v561 = (uint64_t) v23;
                  TASSIGN(v560, v561);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  uint16_t v562 = static_cast<uint16_t>(v45);
                  uint16_t v563 = static_cast<uint16_t>(v45);
                  TEXTRACT(v560, v541, v562, v563);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  // pto: %32
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v564 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v515, v36);
                  // pto: %32
                  ;
                  uint64_t v565 = (uint64_t) v25;
                  TASSIGN(v564, v565);
                  uint16_t v566 = static_cast<uint16_t>(v45);
                  uint16_t v567 = static_cast<uint16_t>(v36);
                  TEXTRACT(v564, v526, v566, v567);
                  // pto: %33
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v568 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %33
                  ;
                  uint64_t v569 = (uint64_t) v25;
                  TASSIGN(v568, v569);
                  uint16_t v570 = static_cast<uint16_t>(v36);
                  uint16_t v571 = static_cast<uint16_t>(v45);
                  TEXTRACT(v568, v541, v570, v571);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  // pto: %327
                  ;
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  if (v521 == v45) {
                    pipe_barrier(PIPE_M);
                    TMATMUL(v519, v556, v560);
                  } else {
                    pipe_barrier(PIPE_M);
                    TMATMUL_ACC(v519, v519, v556, v560);
                  };
                  pipe_barrier(PIPE_M);
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  TMATMUL_ACC(v519, v519, v564, v568);
                } else {
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  for (int64_t v572 = v45; v572 < v33; v572 += v29) {
                    // pto: %328, %329
                    ;
                    int64_t v573 = (int64_t) ((uint64_t) v524 + (uint64_t) v572) % v32;
                    // pto: %330, %331, %332
                    ;
                    int64_t v574 = v573 < v45 ? (int64_t) ((uint64_t) v573 + (uint64_t) v32) : v573;
                    // pto: %333
                    ;
                    int64_t v575 = (int64_t) ((uint64_t) v574 * (uint64_t) v33);
                    // pto: %seed_narrow_wrap_x__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v576 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v515, v33);
                    // pto: %seed_narrow_wrap_x__tile
                    ;
                    uint64_t v577 = (uint64_t) v24;
                    TASSIGN(v576, v577);
                    // pto: %334
                    ;
                    int64_t v578 = v513 < v45 ? v45 : v513;
                    // pto: %335, %336
                    ;
                    int64_t v579 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v41) + (uint64_t) v575);
                    // pto: %337
                    ;
                    int64_t v580 = v579 < v45 ? v45 : v579;
                    // pto: %338
                    ;
                    const int64_t v581 = 0;
                    // pto: %338
                    ;
                    __gm__ bfloat16_t* v582 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                    // pto: %338
                    ;
                    const int64_t v583 = 1;
                    // pto: %338
                    ;
                    const int64_t v584 = 1;
                    // pto: %338
                    ;
                    const int64_t v585 = 1;
                    // pto: %338
                    ;
                    int64_t v586 = v515 * v28;
                    // pto: %338
                    ;
                    int64_t v587 = v585 * v586;
                    // pto: %338
                    ;
                    pto::Shape<1, 1, 1, -1, 16> v588 = pto::Shape<1, 1, 1, -1, 16>(v583, v584, v585, v515, v33);
                    // pto: %338
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v589 = pto::Stride<-1, -1, -1, -1, -1>(v584 * v587, v587, v586, v28, v29);
                    // pto: %338
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v590 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v582 + (v581 + v578 * v28 + v580 * v29), v588, v589);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v576, v590);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    // pto: %seed_narrow_wrap_w__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v591 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %seed_narrow_wrap_w__tile
                    ;
                    uint64_t v592 = (uint64_t) v23;
                    TASSIGN(v591, v592);
                    // pto: %339
                    ;
                    int64_t v593 = v140 < v45 ? v45 : v140;
                    // pto: %340
                    ;
                    int64_t v594 = v143 / v33;
                    // pto: %341
                    ;
                    int64_t v595 = v594 < v45 ? v45 : v594;
                    // pto: %342
                    ;
                    int64_t v596 = v575 / v33;
                    // pto: %343
                    ;
                    int64_t v597 = v596 < v45 ? v45 : v596;
                    // pto: %344
                    ;
                    __gm__ bfloat16_t* v598 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                    // pto: %344
                    ;
                    const int64_t v599 = 0;
                    // pto: %344
                    ;
                    const int64_t v600 = 4194304;
                    // pto: %344
                    ;
                    const int64_t v601 = 65536;
                    // pto: %344
                    ;
                    const int64_t v602 = 256;
                    // pto: %344
                    ;
                    pto::Shape<1, 8, 1, 16, 16> v603 = pto::Shape<1, 8, 1, 16, 16>();
                    // pto: %344
                    ;
                    pto::Stride<4194304, 65536, 256, 16, 1> v604 = pto::Stride<4194304, 65536, 256, 16, 1>();
                    // pto: %344
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v605 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v598 + ((v599 + v593 * v600) + v595 * v601 + v597 * v602), v603, v604);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    TLOAD(v591, v605);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    // pto: %35
                    ;
                    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v606 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v515, v33);
                    // pto: %35
                    ;
                    uint64_t v607 = (uint64_t) v23;
                    TASSIGN(v606, v607);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                    uint16_t v608 = static_cast<uint16_t>(v45);
                    uint16_t v609 = static_cast<uint16_t>(v45);
                    TEXTRACT(v606, v576, v608, v609);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    // pto: %36
                    ;
                    Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v610 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %36
                    ;
                    uint64_t v611 = (uint64_t) v23;
                    TASSIGN(v610, v611);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    uint16_t v612 = static_cast<uint16_t>(v45);
                    uint16_t v613 = static_cast<uint16_t>(v45);
                    TEXTRACT(v610, v591, v612, v613);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    // pto: %346, %347
                    ;
                    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    if ((int64_t) ((uint64_t) v522 + (uint64_t) v572) == v45) {
                      pipe_barrier(PIPE_M);
                      TMATMUL(v519, v606, v610);
                    } else {
                      pipe_barrier(PIPE_M);
                      TMATMUL_ACC(v519, v519, v606, v610);
                    };
                    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  };
                  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
              // pto: %348
              ;
              int64_t v614 = v513 < v45 ? v45 : v513;
              // pto: %349, %350
              ;
              int64_t v615 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 * (uint64_t) v55) + (uint64_t) v143);
              // pto: %351
              ;
              int64_t v616 = v615 < v45 ? v45 : v615;
              // pto: %352
              ;
              __gm__ float* v617 = PTOAS__GLOBAL_TENSOR_DATA(v94);
              // pto: %352
              ;
              const int64_t v618 = 0;
              // pto: %352
              ;
              const int64_t v619 = 8192;
              // pto: %352
              ;
              pto::Shape<1, 1, 1, 16, 128> v620 = pto::Shape<1, 1, 1, 16, 128>();
              // pto: %352
              ;
              pto::Stride<131072, 131072, 131072, 8192, 1> v621 = pto::Stride<131072, 131072, 131072, 8192, 1>();
              // pto: %352
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v622 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v617 + (v618 + v614 * v619 + v616), v620, v621);
              wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
              pipe_barrier(PIPE_FIX);
              TSTORE(v622, v519);
              set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
            };
          };
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    };
  } else {
    for (int64_t v623 = v126; v623 < v31; v623 += v48) {
      // pto: %354
      ;
      int64_t v624 = v623 / v30;
      // pto: %355
      ;
      int64_t v625 = v623 % v30;
      // pto: %356, %357, %358
      ;
      int64_t v626 = v625 < v45 ? (int64_t) ((uint64_t) v625 + (uint64_t) v30) : v625;
      // pto: %359
      ;
      int64_t v627 = (int64_t) ((uint64_t) v626 * (uint64_t) v36);
      // pto: %360, %361
      ;
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v628 = v45; v628 < ((int64_t) ((uint64_t) v138 + (uint64_t) v49) / v30); v628 += v29) {
        // pto: %362
        ;
        int64_t v629 = (int64_t) ((uint64_t) v628 * (uint64_t) v30);
        // pto: %365, %366, %367, %363
        ;
        int32_t v630 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v628 * (uint64_t) v31) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
        // pto: %368
        ;
        int64_t v631 = (int64_t) v630;
        // pto: %369
        ;
        int64_t v632 = v631 < v45 ? v45 : v631;
        // pto: %370
        ;
        int64_t v633 = (int64_t) ((uint64_t) v629 + (uint64_t) v29);
        // pto: %371
        ;
        // pto: %v4_same_start__phi_v3
        ;
        int64_t v634;
        if (v633 < v138) {
          // pto: %374, %375, %376, %377, %372
          ;
          int32_t v635 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v633 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %378
          ;
          int64_t v636 = (int64_t) v635;
          // pto: %379
          ;
          int64_t v637 = v636 < v45 ? v45 : v636;
          // pto: %380, %v4_same_start__phi_v2
          ;
          v634 = v637 != v632 ? v45 : v29;
        } else {
          v634 = v29;
        };
        // pto: %381
        ;
        int64_t v638 = (int64_t) ((uint64_t) v629 + (uint64_t) v50);
        // pto: %382
        ;
        // pto: %v4_same_start__phi_v6
        ;
        int64_t v639;
        if (v638 < v138) {
          // pto: %385, %386, %387, %388, %383
          ;
          int32_t v640 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v638 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %389
          ;
          int64_t v641 = (int64_t) v640;
          // pto: %390
          ;
          int64_t v642 = v641 < v45 ? v45 : v641;
          // pto: %391, %v4_same_start__phi_v5
          ;
          int64_t v643 = v642 != v632 ? v45 : v634;
          v639 = v643;
        } else {
          v639 = v634;
        };
        // pto: %392
        ;
        int64_t v644 = (int64_t) ((uint64_t) v629 + (uint64_t) v51);
        // pto: %393
        ;
        // pto: %v4_same_start__phi_v9
        ;
        int64_t v645;
        if (v644 < v138) {
          // pto: %396, %397, %398, %399, %394
          ;
          int32_t v646 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v644 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %400
          ;
          int64_t v647 = (int64_t) v646;
          // pto: %401
          ;
          int64_t v648 = v647 < v45 ? v45 : v647;
          // pto: %402, %v4_same_start__phi_v8
          ;
          int64_t v649 = v648 != v632 ? v45 : v639;
          v645 = v649;
        } else {
          v645 = v639;
        };
        // pto: %403
        ;
        int64_t v650 = (int64_t) ((uint64_t) v629 + (uint64_t) v43);
        // pto: %404
        ;
        // pto: %v4_same_start__phi_v12
        ;
        int64_t v651;
        if (v650 < v138) {
          // pto: %407, %408, %409, %410, %405
          ;
          int32_t v652 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v650 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %411
          ;
          int64_t v653 = (int64_t) v652;
          // pto: %412
          ;
          int64_t v654 = v653 < v45 ? v45 : v653;
          // pto: %413, %v4_same_start__phi_v11
          ;
          int64_t v655 = v654 != v632 ? v45 : v645;
          v651 = v655;
        } else {
          v651 = v645;
        };
        // pto: %414
        ;
        int64_t v656 = (int64_t) ((uint64_t) v629 + (uint64_t) v52);
        // pto: %415
        ;
        // pto: %v4_same_start__phi_v15
        ;
        int64_t v657;
        if (v656 < v138) {
          // pto: %418, %419, %420, %421, %416
          ;
          int32_t v658 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v656 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %422
          ;
          int64_t v659 = (int64_t) v658;
          // pto: %423
          ;
          int64_t v660 = v659 < v45 ? v45 : v659;
          // pto: %424, %v4_same_start__phi_v14
          ;
          int64_t v661 = v660 != v632 ? v45 : v651;
          v657 = v661;
        } else {
          v657 = v651;
        };
        // pto: %425
        ;
        int64_t v662 = (int64_t) ((uint64_t) v629 + (uint64_t) v53);
        // pto: %426
        ;
        // pto: %v4_same_start__phi_v18
        ;
        int64_t v663;
        if (v662 < v138) {
          // pto: %429, %430, %431, %432, %427
          ;
          int32_t v664 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v662 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %433
          ;
          int64_t v665 = (int64_t) v664;
          // pto: %434
          ;
          int64_t v666 = v665 < v45 ? v45 : v665;
          // pto: %435, %v4_same_start__phi_v17
          ;
          int64_t v667 = v666 != v632 ? v45 : v657;
          v663 = v667;
        } else {
          v663 = v657;
        };
        // pto: %436
        ;
        int64_t v668 = (int64_t) ((uint64_t) v629 + (uint64_t) v49);
        // pto: %437
        ;
        // pto: %v4_same_start__phi_v21
        ;
        int64_t v669;
        if (v668 < v138) {
          // pto: %440, %441, %442, %443, %438
          ;
          int32_t v670 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v668 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
          // pto: %444
          ;
          int64_t v671 = (int64_t) v670;
          // pto: %445
          ;
          int64_t v672 = v671 < v45 ? v45 : v671;
          // pto: %446, %v4_same_start__phi_v20
          ;
          int64_t v673 = v672 != v632 ? v45 : v663;
          v669 = v673;
        } else {
          v669 = v663;
        };
        // pto: %447, %v4_same_start__phi_v23
        ;
        int64_t v674 = v17 <= v33 ? v45 : v669;
        // pto: %448
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        if (v674 == v29) {
          int64_t v675 = (int64_t) ((uint64_t) v628 * (uint64_t) v36);
          // pto: %450
          ;
          int64_t v676 = (int64_t) ((uint64_t) v17 - (uint64_t) v675);
          // pto: %451
          ;
          int64_t v677 = v676 < v36 ? v676 : v36;
          // pto: %452
          ;
          int64_t v678 = v632 % v32;
          // pto: %453, %454, %455
          ;
          int64_t v679 = v678 < v45 ? (int64_t) ((uint64_t) v678 + (uint64_t) v32) : v678;
          // pto: %456
          ;
          int64_t v680 = (int64_t) ((uint64_t) v679 * (uint64_t) v33);
          // pto: %v4_wide_seed_x__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v681 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v677, v33);
          // pto: %v4_wide_seed_x__tile
          ;
          uint64_t v682 = (uint64_t) v23;
          TASSIGN(v681, v682);
          // pto: %457
          ;
          int64_t v683 = v675 < v45 ? v45 : v675;
          // pto: %458
          ;
          int64_t v684 = (int64_t) ((uint64_t) v624 * (uint64_t) v41);
          // pto: %459
          ;
          int64_t v685 = (int64_t) ((uint64_t) v684 + (uint64_t) v680);
          // pto: %460
          ;
          int64_t v686 = v685 < v45 ? v45 : v685;
          // pto: %461
          ;
          const int64_t v687 = 0;
          // pto: %461
          ;
          __gm__ bfloat16_t* v688 = PTOAS__GLOBAL_TENSOR_DATA(v70);
          // pto: %461
          ;
          const int64_t v689 = 1;
          // pto: %461
          ;
          const int64_t v690 = 1;
          // pto: %461
          ;
          const int64_t v691 = 1;
          // pto: %461
          ;
          int64_t v692 = v677 * v28;
          // pto: %461
          ;
          int64_t v693 = v691 * v692;
          // pto: %461
          ;
          pto::Shape<1, 1, 1, -1, 16> v694 = pto::Shape<1, 1, 1, -1, 16>(v689, v690, v691, v677, v33);
          // pto: %461
          ;
          pto::Stride<-1, -1, -1, -1, -1> v695 = pto::Stride<-1, -1, -1, -1, -1>(v690 * v693, v693, v692, v28, v29);
          // pto: %461
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v696 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v688 + (v687 + v683 * v28 + v686 * v29), v694, v695);
          TLOAD(v681, v696);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %v4_wide_seed_w__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v697 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
          // pto: %v4_wide_seed_w__tile
          ;
          uint64_t v698 = (uint64_t) v24;
          TASSIGN(v697, v698);
          // pto: %462
          ;
          int64_t v699 = v624 < v45 ? v45 : v624;
          // pto: %463
          ;
          int64_t v700 = v627 / v33;
          // pto: %464
          ;
          int64_t v701 = v700 < v45 ? v45 : v700;
          // pto: %465
          ;
          int64_t v702 = v680 / v33;
          // pto: %466
          ;
          int64_t v703 = v702 < v45 ? v45 : v702;
          // pto: %467
          ;
          __gm__ bfloat16_t* v704 = PTOAS__GLOBAL_TENSOR_DATA(v73);
          // pto: %467
          ;
          const int64_t v705 = 0;
          // pto: %467
          ;
          const int64_t v706 = 4194304;
          // pto: %467
          ;
          const int64_t v707 = 65536;
          // pto: %467
          ;
          const int64_t v708 = 256;
          // pto: %467
          ;
          pto::Shape<1, 8, 1, 16, 16> v709 = pto::Shape<1, 8, 1, 16, 16>();
          // pto: %467
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v710 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %467
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v711 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v704 + ((v705 + v699 * v706) + v701 * v707 + v703 * v708), v709, v710);
          TLOAD(v697, v711);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %37
          ;
          Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v712 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v677, v33);
          // pto: %37
          ;
          uint64_t v713 = (uint64_t) v23;
          TASSIGN(v712, v713);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          uint16_t v714 = static_cast<uint16_t>(v45);
          uint16_t v715 = static_cast<uint16_t>(v45);
          TEXTRACT(v712, v681, v714, v715);
          // pto: %38
          ;
          Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v716 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
          // pto: %38
          ;
          uint64_t v717 = (uint64_t) v23;
          TASSIGN(v716, v717);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v718 = static_cast<uint16_t>(v45);
          uint16_t v719 = static_cast<uint16_t>(v45);
          TEXTRACT(v716, v697, v718, v719);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %v4_wide_acc__tile
          ;
          Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v720 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v677, v36);
          // pto: %v4_wide_acc__tile
          ;
          uint64_t v721 = (uint64_t) v23;
          TASSIGN(v720, v721);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          TMATMUL(v720, v712, v716);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          for (int64_t v722 = v45; v722 < v46; v722 += v29) {
            // pto: %469, %468, %470, %471
            ;
            int64_t v723 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v632 + (uint64_t) ((int64_t) (uint64_t) v722 * (uint64_t) v33)) + (uint64_t) v29) % v32;
            // pto: %472, %473, %474
            ;
            int64_t v724 = v723 < v45 ? (int64_t) ((uint64_t) v723 + (uint64_t) v32) : v723;
            // pto: %475
            ;
            // pto: %476
            ;
            int64_t v725 = v677 < v36 ? v677 : v36;
            v122.SetValidShape(v725, v36);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            if (v724 <= v54) {
              // pto: %477
              ;
              int64_t v726 = (int64_t) ((uint64_t) v724 * (uint64_t) v33);
              // pto: %v4_wide_packet_x__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v727 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v677, v32);
              // pto: %v4_wide_packet_x__tile
              ;
              uint64_t v728 = (uint64_t) v23;
              TASSIGN(v727, v728);
              // pto: %480
              ;
              int64_t v729 = (int64_t) ((uint64_t) v684 + (uint64_t) v726);
              // pto: %481
              ;
              int64_t v730 = v729 < v45 ? v45 : v729;
              // pto: %482
              ;
              const int64_t v731 = 0;
              // pto: %482
              ;
              __gm__ bfloat16_t* v732 = PTOAS__GLOBAL_TENSOR_DATA(v70);
              // pto: %482
              ;
              const int64_t v733 = 1;
              // pto: %482
              ;
              const int64_t v734 = 1;
              // pto: %482
              ;
              const int64_t v735 = 1;
              // pto: %482
              ;
              int64_t v736 = v677 * v28;
              // pto: %482
              ;
              int64_t v737 = v735 * v736;
              // pto: %482
              ;
              pto::Shape<1, 1, 1, -1, 256> v738 = pto::Shape<1, 1, 1, -1, 256>(v733, v734, v735, v677, v32);
              // pto: %482
              ;
              pto::Stride<-1, -1, -1, -1, -1> v739 = pto::Stride<-1, -1, -1, -1, -1>(v734 * v737, v737, v736, v28, v29);
              // pto: %482
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v740 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v732 + (v731 + v683 * v28 + v730 * v29), v738, v739);
              TLOAD(v727, v740);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %v4_wide_packet_w__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v741 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
              // pto: %v4_wide_packet_w__tile
              ;
              uint64_t v742 = (uint64_t) v24;
              TASSIGN(v741, v742);
              // pto: %486
              ;
              int64_t v743 = v726 / v33;
              // pto: %487
              ;
              int64_t v744 = v743 < v45 ? v45 : v743;
              // pto: %488
              ;
              __gm__ bfloat16_t* v745 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %488
              ;
              const int64_t v746 = 0;
              // pto: %488
              ;
              const int64_t v747 = 4194304;
              // pto: %488
              ;
              const int64_t v748 = 65536;
              // pto: %488
              ;
              const int64_t v749 = 256;
              // pto: %488
              ;
              pto::Shape<1, 8, 16, 16, 16> v750 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %488
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v751 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %488
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v752 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v745 + ((v746 + v699 * v747) + v701 * v748 + v744 * v749), v750, v751);
              TLOAD(v741, v752);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %v4_wide_acc__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v753 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v677, v36);
              // pto: %v4_wide_acc__iter_v1_l0_a
              ;
              uint64_t v754 = (uint64_t) v23;
              TASSIGN(v753, v754);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              uint16_t v755 = static_cast<uint16_t>(v45);
              uint16_t v756 = static_cast<uint16_t>(v45);
              TEXTRACT(v753, v727, v755, v756);
              // pto: %v4_wide_acc__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v757 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %v4_wide_acc__iter_v1_l0_b
              ;
              uint64_t v758 = (uint64_t) v23;
              TASSIGN(v757, v758);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v759 = static_cast<uint16_t>(v45);
              uint16_t v760 = static_cast<uint16_t>(v45);
              TEXTRACT(v757, v741, v759, v760);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              // pto: %39
              ;
              Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v761 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v677, v36);
              // pto: %39
              ;
              uint64_t v762 = (uint64_t) v25;
              TASSIGN(v761, v762);
              uint16_t v763 = static_cast<uint16_t>(v45);
              uint16_t v764 = static_cast<uint16_t>(v36);
              TEXTRACT(v761, v727, v763, v764);
              // pto: %40
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v765 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
              // pto: %40
              ;
              uint64_t v766 = (uint64_t) v25;
              TASSIGN(v765, v766);
              uint16_t v767 = static_cast<uint16_t>(v36);
              uint16_t v768 = static_cast<uint16_t>(v45);
              TEXTRACT(v765, v741, v767, v768);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v720, v720, v753, v757);
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              TMATMUL_ACC(v720, v720, v761, v765);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              for (int64_t v769 = v45; v769 < v33; v769 += v29) {
                // pto: %489, %490
                ;
                int64_t v770 = (int64_t) ((uint64_t) v724 + (uint64_t) v769) % v32;
                // pto: %491, %492, %493
                ;
                int64_t v771 = v770 < v45 ? (int64_t) ((uint64_t) v770 + (uint64_t) v32) : v770;
                // pto: %494
                ;
                int64_t v772 = (int64_t) ((uint64_t) v771 * (uint64_t) v33);
                // pto: %v4_wide_wrap_x__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v773 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v677, v33);
                // pto: %v4_wide_wrap_x__tile
                ;
                uint64_t v774 = (uint64_t) v23;
                TASSIGN(v773, v774);
                // pto: %497
                ;
                int64_t v775 = (int64_t) ((uint64_t) v684 + (uint64_t) v772);
                // pto: %498
                ;
                int64_t v776 = v775 < v45 ? v45 : v775;
                // pto: %499
                ;
                const int64_t v777 = 0;
                // pto: %499
                ;
                __gm__ bfloat16_t* v778 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                // pto: %499
                ;
                const int64_t v779 = 1;
                // pto: %499
                ;
                const int64_t v780 = 1;
                // pto: %499
                ;
                const int64_t v781 = 1;
                // pto: %499
                ;
                int64_t v782 = v677 * v28;
                // pto: %499
                ;
                int64_t v783 = v781 * v782;
                // pto: %499
                ;
                pto::Shape<1, 1, 1, -1, 16> v784 = pto::Shape<1, 1, 1, -1, 16>(v779, v780, v781, v677, v33);
                // pto: %499
                ;
                pto::Stride<-1, -1, -1, -1, -1> v785 = pto::Stride<-1, -1, -1, -1, -1>(v780 * v783, v783, v782, v28, v29);
                // pto: %499
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v786 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v778 + (v777 + v683 * v28 + v776 * v29), v784, v785);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                TLOAD(v773, v786);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %v4_wide_wrap_w__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v787 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %v4_wide_wrap_w__tile
                ;
                uint64_t v788 = (uint64_t) v24;
                TASSIGN(v787, v788);
                // pto: %503
                ;
                int64_t v789 = v772 / v33;
                // pto: %504
                ;
                int64_t v790 = v789 < v45 ? v45 : v789;
                // pto: %505
                ;
                __gm__ bfloat16_t* v791 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                // pto: %505
                ;
                const int64_t v792 = 0;
                // pto: %505
                ;
                const int64_t v793 = 4194304;
                // pto: %505
                ;
                const int64_t v794 = 65536;
                // pto: %505
                ;
                const int64_t v795 = 256;
                // pto: %505
                ;
                pto::Shape<1, 8, 1, 16, 16> v796 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %505
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v797 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %505
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v798 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v791 + ((v792 + v699 * v793) + v701 * v794 + v790 * v795), v796, v797);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v787, v798);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %42
                ;
                Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v799 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v677, v33);
                // pto: %42
                ;
                uint64_t v800 = (uint64_t) v23;
                TASSIGN(v799, v800);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                uint16_t v801 = static_cast<uint16_t>(v45);
                uint16_t v802 = static_cast<uint16_t>(v45);
                TEXTRACT(v799, v773, v801, v802);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                // pto: %43
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v803 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                // pto: %43
                ;
                uint64_t v804 = (uint64_t) v23;
                TASSIGN(v803, v804);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v805 = static_cast<uint16_t>(v45);
                uint16_t v806 = static_cast<uint16_t>(v45);
                TEXTRACT(v803, v787, v805, v806);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v720, v720, v799, v803);
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          for (int64_t v807 = v56; v807 < v32; v807 += v29) {
            // pto: %506, %507
            ;
            int64_t v808 = (int64_t) ((uint64_t) v632 + (uint64_t) v807) % v32;
            // pto: %508, %509, %510
            ;
            int64_t v809 = v808 < v45 ? (int64_t) ((uint64_t) v808 + (uint64_t) v32) : v808;
            // pto: %511
            ;
            int64_t v810 = (int64_t) ((uint64_t) v809 * (uint64_t) v33);
            // pto: %v4_wide_tail_x__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v811 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v677, v33);
            // pto: %v4_wide_tail_x__tile
            ;
            uint64_t v812 = (uint64_t) v23;
            TASSIGN(v811, v812);
            // pto: %514
            ;
            int64_t v813 = (int64_t) ((uint64_t) v684 + (uint64_t) v810);
            // pto: %515
            ;
            int64_t v814 = v813 < v45 ? v45 : v813;
            // pto: %516
            ;
            const int64_t v815 = 0;
            // pto: %516
            ;
            __gm__ bfloat16_t* v816 = PTOAS__GLOBAL_TENSOR_DATA(v70);
            // pto: %516
            ;
            const int64_t v817 = 1;
            // pto: %516
            ;
            const int64_t v818 = 1;
            // pto: %516
            ;
            const int64_t v819 = 1;
            // pto: %516
            ;
            int64_t v820 = v677 * v28;
            // pto: %516
            ;
            int64_t v821 = v819 * v820;
            // pto: %516
            ;
            pto::Shape<1, 1, 1, -1, 16> v822 = pto::Shape<1, 1, 1, -1, 16>(v817, v818, v819, v677, v33);
            // pto: %516
            ;
            pto::Stride<-1, -1, -1, -1, -1> v823 = pto::Stride<-1, -1, -1, -1, -1>(v818 * v821, v821, v820, v28, v29);
            // pto: %516
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v824 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v816 + (v815 + v683 * v28 + v814 * v29), v822, v823);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            TLOAD(v811, v824);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %v4_wide_tail_w__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v825 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
            // pto: %v4_wide_tail_w__tile
            ;
            uint64_t v826 = (uint64_t) v24;
            TASSIGN(v825, v826);
            // pto: %520
            ;
            int64_t v827 = v810 / v33;
            // pto: %521
            ;
            int64_t v828 = v827 < v45 ? v45 : v827;
            // pto: %522
            ;
            __gm__ bfloat16_t* v829 = PTOAS__GLOBAL_TENSOR_DATA(v73);
            // pto: %522
            ;
            const int64_t v830 = 0;
            // pto: %522
            ;
            const int64_t v831 = 4194304;
            // pto: %522
            ;
            const int64_t v832 = 65536;
            // pto: %522
            ;
            const int64_t v833 = 256;
            // pto: %522
            ;
            pto::Shape<1, 8, 1, 16, 16> v834 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %522
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v835 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %522
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v836 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v829 + ((v830 + v699 * v831) + v701 * v832 + v828 * v833), v834, v835);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            TLOAD(v825, v836);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %44
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v837 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v677, v33);
            // pto: %44
            ;
            uint64_t v838 = (uint64_t) v23;
            TASSIGN(v837, v838);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            uint16_t v839 = static_cast<uint16_t>(v45);
            uint16_t v840 = static_cast<uint16_t>(v45);
            TEXTRACT(v837, v811, v839, v840);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            // pto: %45
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v841 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
            // pto: %45
            ;
            uint64_t v842 = (uint64_t) v23;
            TASSIGN(v841, v842);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v843 = static_cast<uint16_t>(v45);
            uint16_t v844 = static_cast<uint16_t>(v45);
            TEXTRACT(v841, v825, v843, v844);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v720, v720, v837, v841);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
          // pto: %524, %525
          ;
          int64_t v845 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v624 * (uint64_t) v55) + (uint64_t) v627);
          // pto: %526
          ;
          int64_t v846 = v845 < v45 ? v45 : v845;
          // pto: %527
          ;
          const int64_t v847 = 0;
          // pto: %527
          ;
          __gm__ float* v848 = PTOAS__GLOBAL_TENSOR_DATA(v94);
          // pto: %527
          ;
          const int64_t v849 = 1;
          // pto: %527
          ;
          const int64_t v850 = 1;
          // pto: %527
          ;
          const int64_t v851 = 1;
          // pto: %527
          ;
          int64_t v852 = v677 * v42;
          // pto: %527
          ;
          int64_t v853 = v851 * v852;
          // pto: %527
          ;
          pto::Shape<1, 1, 1, -1, 128> v854 = pto::Shape<1, 1, 1, -1, 128>(v849, v850, v851, v677, v36);
          // pto: %527
          ;
          pto::Stride<-1, -1, -1, -1, -1> v855 = pto::Stride<-1, -1, -1, -1, -1>(v850 * v853, v853, v852, v42, v29);
          // pto: %527
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v856 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v848 + (v847 + v683 * v42 + v846 * v29), v854, v855);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
          TSTORE(v856, v720);
        } else {
          for (int64_t v857 = v45; v857 < v30; v857 += v29) {
            // pto: %528
            ;
            int64_t v858 = (int64_t) ((uint64_t) v629 + (uint64_t) v857);
            // pto: %529
            ;
            if (v858 < v138) {
              // pto: %530
              ;
              int64_t v859 = (int64_t) ((uint64_t) v858 * (uint64_t) v33);
              // pto: %531
              ;
              int64_t v860 = (int64_t) ((uint64_t) v17 - (uint64_t) v859);
              // pto: %532
              ;
              int64_t v861 = v860 < v33 ? v860 : v33;
              // pto: %534, %535, %536, %537, %533
              ;
              int32_t v862 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v858 * (uint64_t) v30) + (uint64_t) v624) * (uint64_t) v30) + (uint64_t) v626)];
              // pto: %538
              ;
              int64_t v863 = (int64_t) v862;
              // pto: %539
              ;
              int64_t v864 = v863 < v45 ? v45 : v863;
              // pto: %v4_narrow_acc__tile
              ;
              Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v865 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
              // pto: %v4_narrow_acc__tile
              ;
              uint64_t v866 = (uint64_t) v23;
              TASSIGN(v865, v866);
              wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              for (int64_t v867 = v45; v867 < v33; v867 += v29) {
                // pto: %540
                ;
                int64_t v868 = (int64_t) ((uint64_t) v867 * (uint64_t) v33);
                // pto: %541, %542
                ;
                int64_t v869 = (int64_t) ((uint64_t) v864 + (uint64_t) v868) % v32;
                // pto: %543, %544, %545
                ;
                int64_t v870 = v869 < v45 ? (int64_t) ((uint64_t) v869 + (uint64_t) v32) : v869;
                // pto: %546
                ;
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                if (v870 <= v54) {
                  // pto: %547
                  ;
                  int64_t v871 = (int64_t) ((uint64_t) v870 * (uint64_t) v33);
                  // pto: %v4_narrow_packet_x__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v872 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v861, v32);
                  // pto: %v4_narrow_packet_x__tile
                  ;
                  uint64_t v873 = (uint64_t) v24;
                  TASSIGN(v872, v873);
                  // pto: %548
                  ;
                  int64_t v874 = v859 < v45 ? v45 : v859;
                  // pto: %549, %550
                  ;
                  int64_t v875 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v624 * (uint64_t) v41) + (uint64_t) v871);
                  // pto: %551
                  ;
                  int64_t v876 = v875 < v45 ? v45 : v875;
                  // pto: %552
                  ;
                  const int64_t v877 = 0;
                  // pto: %552
                  ;
                  __gm__ bfloat16_t* v878 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                  // pto: %552
                  ;
                  const int64_t v879 = 1;
                  // pto: %552
                  ;
                  const int64_t v880 = 1;
                  // pto: %552
                  ;
                  const int64_t v881 = 1;
                  // pto: %552
                  ;
                  int64_t v882 = v861 * v28;
                  // pto: %552
                  ;
                  int64_t v883 = v881 * v882;
                  // pto: %552
                  ;
                  pto::Shape<1, 1, 1, -1, 256> v884 = pto::Shape<1, 1, 1, -1, 256>(v879, v880, v881, v861, v32);
                  // pto: %552
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v885 = pto::Stride<-1, -1, -1, -1, -1>(v880 * v883, v883, v882, v28, v29);
                  // pto: %552
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v886 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v878 + (v877 + v874 * v28 + v876 * v29), v884, v885);
                  TLOAD(v872, v886);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  // pto: %v4_narrow_packet_w__tile
                  ;
                  Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v887 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
                  // pto: %v4_narrow_packet_w__tile
                  ;
                  uint64_t v888 = (uint64_t) v23;
                  TASSIGN(v887, v888);
                  // pto: %553
                  ;
                  int64_t v889 = v624 < v45 ? v45 : v624;
                  // pto: %554
                  ;
                  int64_t v890 = v627 / v33;
                  // pto: %555
                  ;
                  int64_t v891 = v890 < v45 ? v45 : v890;
                  // pto: %556
                  ;
                  int64_t v892 = v871 / v33;
                  // pto: %557
                  ;
                  int64_t v893 = v892 < v45 ? v45 : v892;
                  // pto: %558
                  ;
                  __gm__ bfloat16_t* v894 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                  // pto: %558
                  ;
                  const int64_t v895 = 0;
                  // pto: %558
                  ;
                  const int64_t v896 = 4194304;
                  // pto: %558
                  ;
                  const int64_t v897 = 65536;
                  // pto: %558
                  ;
                  const int64_t v898 = 256;
                  // pto: %558
                  ;
                  pto::Shape<1, 8, 16, 16, 16> v899 = pto::Shape<1, 8, 16, 16, 16>();
                  // pto: %558
                  ;
                  pto::Stride<4194304, 65536, 256, 16, 1> v900 = pto::Stride<4194304, 65536, 256, 16, 1>();
                  // pto: %558
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v901 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v894 + ((v895 + v889 * v896) + v891 * v897 + v893 * v898), v899, v900);
                  TLOAD(v887, v901);
                  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  // pto: %v4_narrow_acc__iter_v1_l0_a
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v902 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v861, v36);
                  // pto: %v4_narrow_acc__iter_v1_l0_a
                  ;
                  uint64_t v903 = (uint64_t) v23;
                  TASSIGN(v902, v903);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                  uint16_t v904 = static_cast<uint16_t>(v45);
                  uint16_t v905 = static_cast<uint16_t>(v45);
                  TEXTRACT(v902, v872, v904, v905);
                  // pto: %v4_narrow_acc__iter_v1_l0_b
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v906 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %v4_narrow_acc__iter_v1_l0_b
                  ;
                  uint64_t v907 = (uint64_t) v23;
                  TASSIGN(v906, v907);
                  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                  uint16_t v908 = static_cast<uint16_t>(v45);
                  uint16_t v909 = static_cast<uint16_t>(v45);
                  TEXTRACT(v906, v887, v908, v909);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  // pto: %46
                  ;
                  Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v910 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v861, v36);
                  // pto: %46
                  ;
                  uint64_t v911 = (uint64_t) v25;
                  TASSIGN(v910, v911);
                  uint16_t v912 = static_cast<uint16_t>(v45);
                  uint16_t v913 = static_cast<uint16_t>(v36);
                  TEXTRACT(v910, v872, v912, v913);
                  // pto: %47
                  ;
                  Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v914 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
                  // pto: %47
                  ;
                  uint64_t v915 = (uint64_t) v25;
                  TASSIGN(v914, v915);
                  uint16_t v916 = static_cast<uint16_t>(v36);
                  uint16_t v917 = static_cast<uint16_t>(v45);
                  TEXTRACT(v914, v887, v916, v917);
                  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  // pto: %559
                  ;
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                  if (v867 == v45) {
                    pipe_barrier(PIPE_M);
                    TMATMUL(v865, v902, v906);
                  } else {
                    pipe_barrier(PIPE_M);
                    TMATMUL_ACC(v865, v865, v902, v906);
                  };
                  pipe_barrier(PIPE_M);
                  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
                  TMATMUL_ACC(v865, v865, v910, v914);
                } else {
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  for (int64_t v918 = v45; v918 < v33; v918 += v29) {
                    // pto: %560, %561
                    ;
                    int64_t v919 = (int64_t) ((uint64_t) v870 + (uint64_t) v918) % v32;
                    // pto: %562, %563, %564
                    ;
                    int64_t v920 = v919 < v45 ? (int64_t) ((uint64_t) v919 + (uint64_t) v32) : v919;
                    // pto: %565
                    ;
                    int64_t v921 = (int64_t) ((uint64_t) v920 * (uint64_t) v33);
                    // pto: %v4_narrow_wrap_x__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v922 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v861, v33);
                    // pto: %v4_narrow_wrap_x__tile
                    ;
                    uint64_t v923 = (uint64_t) v24;
                    TASSIGN(v922, v923);
                    // pto: %566
                    ;
                    int64_t v924 = v859 < v45 ? v45 : v859;
                    // pto: %567, %568
                    ;
                    int64_t v925 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v624 * (uint64_t) v41) + (uint64_t) v921);
                    // pto: %569
                    ;
                    int64_t v926 = v925 < v45 ? v45 : v925;
                    // pto: %570
                    ;
                    const int64_t v927 = 0;
                    // pto: %570
                    ;
                    __gm__ bfloat16_t* v928 = PTOAS__GLOBAL_TENSOR_DATA(v70);
                    // pto: %570
                    ;
                    const int64_t v929 = 1;
                    // pto: %570
                    ;
                    const int64_t v930 = 1;
                    // pto: %570
                    ;
                    const int64_t v931 = 1;
                    // pto: %570
                    ;
                    int64_t v932 = v861 * v28;
                    // pto: %570
                    ;
                    int64_t v933 = v931 * v932;
                    // pto: %570
                    ;
                    pto::Shape<1, 1, 1, -1, 16> v934 = pto::Shape<1, 1, 1, -1, 16>(v929, v930, v931, v861, v33);
                    // pto: %570
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v935 = pto::Stride<-1, -1, -1, -1, -1>(v930 * v933, v933, v932, v28, v29);
                    // pto: %570
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v936 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v928 + (v927 + v924 * v28 + v926 * v29), v934, v935);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v922, v936);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    // pto: %v4_narrow_wrap_w__tile
                    ;
                    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v937 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %v4_narrow_wrap_w__tile
                    ;
                    uint64_t v938 = (uint64_t) v23;
                    TASSIGN(v937, v938);
                    // pto: %571
                    ;
                    int64_t v939 = v624 < v45 ? v45 : v624;
                    // pto: %572
                    ;
                    int64_t v940 = v627 / v33;
                    // pto: %573
                    ;
                    int64_t v941 = v940 < v45 ? v45 : v940;
                    // pto: %574
                    ;
                    int64_t v942 = v921 / v33;
                    // pto: %575
                    ;
                    int64_t v943 = v942 < v45 ? v45 : v942;
                    // pto: %576
                    ;
                    __gm__ bfloat16_t* v944 = PTOAS__GLOBAL_TENSOR_DATA(v73);
                    // pto: %576
                    ;
                    const int64_t v945 = 0;
                    // pto: %576
                    ;
                    const int64_t v946 = 4194304;
                    // pto: %576
                    ;
                    const int64_t v947 = 65536;
                    // pto: %576
                    ;
                    const int64_t v948 = 256;
                    // pto: %576
                    ;
                    pto::Shape<1, 8, 1, 16, 16> v949 = pto::Shape<1, 8, 1, 16, 16>();
                    // pto: %576
                    ;
                    pto::Stride<4194304, 65536, 256, 16, 1> v950 = pto::Stride<4194304, 65536, 256, 16, 1>();
                    // pto: %576
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v951 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v944 + ((v945 + v939 * v946) + v941 * v947 + v943 * v948), v949, v950);
                    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    TLOAD(v937, v951);
                    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    // pto: %49
                    ;
                    Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v952 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v861, v33);
                    // pto: %49
                    ;
                    uint64_t v953 = (uint64_t) v23;
                    TASSIGN(v952, v953);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                    uint16_t v954 = static_cast<uint16_t>(v45);
                    uint16_t v955 = static_cast<uint16_t>(v45);
                    TEXTRACT(v952, v922, v954, v955);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                    // pto: %50
                    ;
                    Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v956 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v33, v36);
                    // pto: %50
                    ;
                    uint64_t v957 = (uint64_t) v23;
                    TASSIGN(v956, v957);
                    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                    uint16_t v958 = static_cast<uint16_t>(v45);
                    uint16_t v959 = static_cast<uint16_t>(v45);
                    TEXTRACT(v956, v937, v958, v959);
                    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    // pto: %578, %579
                    ;
                    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                    if ((int64_t) ((uint64_t) v868 + (uint64_t) v918) == v45) {
                      pipe_barrier(PIPE_M);
                      TMATMUL(v865, v952, v956);
                    } else {
                      pipe_barrier(PIPE_M);
                      TMATMUL_ACC(v865, v865, v952, v956);
                    };
                    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  };
                  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
              set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
              // pto: %580
              ;
              int64_t v960 = v859 < v45 ? v45 : v859;
              // pto: %581, %582
              ;
              int64_t v961 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v624 * (uint64_t) v55) + (uint64_t) v627);
              // pto: %583
              ;
              int64_t v962 = v961 < v45 ? v45 : v961;
              // pto: %584
              ;
              __gm__ float* v963 = PTOAS__GLOBAL_TENSOR_DATA(v94);
              // pto: %584
              ;
              const int64_t v964 = 0;
              // pto: %584
              ;
              const int64_t v965 = 8192;
              // pto: %584
              ;
              pto::Shape<1, 1, 1, 16, 128> v966 = pto::Shape<1, 1, 1, 16, 128>();
              // pto: %584
              ;
              pto::Stride<131072, 131072, 131072, 8192, 1> v967 = pto::Stride<131072, 131072, 131072, 8192, 1>();
              // pto: %584
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v968 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v963 + (v964 + v960 * v965 + v962), v966, v967);
              wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
              pipe_barrier(PIPE_FIX);
              TSTORE(v968, v865);
              set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
            };
          };
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    };
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %586
  int64_t v969 = (int64_t) ((uint64_t) v127 + (uint64_t) v57);
  // pto: %587
  int64_t v970 = v969 < v45 ? v45 : v969;
  // pto: %signals__ssa_v1_signal_pview
  __gm__ int32_t* v971 = PTOAS__GLOBAL_TENSOR_DATA(v113);
  // pto: %signals__ssa_v1_signal_pview
  const int64_t v972 = 0;
  // pto: %signals__ssa_v1_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v973 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v974 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v1_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v975 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v971 + (v972 + v970), v973, v974);
  pto::comm::NotifyOp v976 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v975, v136, v976);
  for (int64_t v977 = v48; v977 < v58; v977 += v29) {
    // pto: %588, %589
    ;
    int64_t v978 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v977 * (uint64_t) v36) + (uint64_t) v59);
    // pto: %590
    ;
    int64_t v979 = v978 < v45 ? v45 : v978;
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v980 = PTOAS__GLOBAL_TENSOR_DATA(v113);
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    const int64_t v981 = 0;
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v982 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v983 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v1__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v984 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v980 + (v981 + v979), v982, v983);
    pto::comm::WaitCmp v985 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v984, v136, v985);
  }
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %591
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  if (v17 <= v33) {
    // pto: %592
    ;
    for (int64_t v986 = v126; v986 < ((int64_t) ((uint64_t) v138 * (uint64_t) v38)); v986 += v48) {
      // pto: %593, %594
      ;
      int64_t v987 = (int64_t) ((uint64_t) (v986 / v38) * (uint64_t) v33);
      // pto: %595
      ;
      int64_t v988 = v986 % v38;
      // pto: %596, %597, %598
      ;
      int64_t v989 = v988 < v45 ? (int64_t) ((uint64_t) v988 + (uint64_t) v38) : v988;
      // pto: %599
      ;
      int64_t v990 = (int64_t) ((uint64_t) v989 * (uint64_t) v36);
      // pto: %600
      ;
      int64_t v991 = (int64_t) ((uint64_t) v17 - (uint64_t) v987);
      // pto: %601
      ;
      int64_t v992 = v991 < v33 ? v991 : v33;
      // pto: %b_acc__tile
      ;
      Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v993 = Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v33, v36);
      // pto: %b_acc__tile
      ;
      uint64_t v994 = (uint64_t) v23;
      TASSIGN(v993, v994);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      for (int64_t v995 = v45; v995 < v33; v995 += v29) {
        // pto: %602
        ;
        int64_t v996 = (int64_t) ((uint64_t) v995 * (uint64_t) v37);
        // pto: %b_input__tile
        ;
        Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v997 = Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v992, v37);
        // pto: %b_input__tile
        ;
        uint64_t v998 = (uint64_t) v24;
        TASSIGN(v997, v998);
        // pto: %603
        ;
        int64_t v999 = v987 < v45 ? v45 : v987;
        // pto: %604
        ;
        int64_t v1000 = v996 < v45 ? v45 : v996;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v1001 = 0;
        // pto: %quantized__ssa_v0_pview
        ;
        __gm__ int8_t* v1002 = PTOAS__GLOBAL_TENSOR_DATA(v85);
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v1003 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v1004 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        const int64_t v1005 = 1;
        // pto: %quantized__ssa_v0_pview
        ;
        int64_t v1006 = v992 * v42;
        // pto: %quantized__ssa_v0_pview
        ;
        int64_t v1007 = v1005 * v1006;
        // pto: %quantized__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 512> v1008 = pto::Shape<1, 1, 1, -1, 512>(v1003, v1004, v1005, v992, v37);
        // pto: %quantized__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1009 = pto::Stride<-1, -1, -1, -1, -1>(v1004 * v1007, v1007, v1006, v42, v29);
        // pto: %quantized__ssa_v0_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1010 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1002 + (v1001 + v999 * v42 + v1000 * v29), v1008, v1009);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v997, v1010);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %b_weight__tile
        ;
        Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1011 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v37, v36);
        // pto: %b_weight__tile
        ;
        uint64_t v1012 = (uint64_t) v23;
        TASSIGN(v1011, v1012);
        // pto: %605
        ;
        int64_t v1013 = v990 / v38;
        // pto: %606
        ;
        int64_t v1014 = v1013 < v45 ? v45 : v1013;
        // pto: %607
        ;
        int64_t v1015 = v996 / v33;
        // pto: %608
        ;
        int64_t v1016 = v1015 < v45 ? v45 : v1015;
        // pto: %wo_b__ssa_v0_pview
        ;
        __gm__ int8_t* v1017 = PTOAS__GLOBAL_TENSOR_DATA(v76);
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v1018 = 0;
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v1019 = 262144;
        // pto: %wo_b__ssa_v0_pview
        ;
        const int64_t v1020 = 512;
        // pto: %wo_b__ssa_v0_pview
        ;
        pto::Shape<1, 4, 32, 16, 32> v1021 = pto::Shape<1, 4, 32, 16, 32>();
        // pto: %wo_b__ssa_v0_pview
        ;
        pto::Stride<33554432, 262144, 512, 32, 1> v1022 = pto::Stride<33554432, 262144, 512, 32, 1>();
        // pto: %wo_b__ssa_v0_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v1023 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v1017 + (v1018 + v1014 * v1019 + v1016 * v1020), v1021, v1022);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v1011, v1023);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %b_acc__tile_l0_a
        ;
        Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1024 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v992, v32);
        // pto: %b_acc__tile_l0_a
        ;
        uint64_t v1025 = (uint64_t) v23;
        TASSIGN(v1024, v1025);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        uint16_t v1026 = static_cast<uint16_t>(v45);
        uint16_t v1027 = static_cast<uint16_t>(v45);
        TEXTRACT(v1024, v997, v1026, v1027);
        // pto: %b_acc__tile_l0_b
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1028 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %b_acc__tile_l0_b
        ;
        uint64_t v1029 = (uint64_t) v23;
        TASSIGN(v1028, v1029);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v1030 = static_cast<uint16_t>(v45);
        uint16_t v1031 = static_cast<uint16_t>(v45);
        TEXTRACT(v1028, v1011, v1030, v1031);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %51
        ;
        Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1032 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v992, v32);
        // pto: %51
        ;
        uint64_t v1033 = (uint64_t) v25;
        TASSIGN(v1032, v1033);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v1034 = static_cast<uint16_t>(v45);
        uint16_t v1035 = static_cast<uint16_t>(v32);
        TEXTRACT(v1032, v997, v1034, v1035);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        // pto: %52
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1036 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %52
        ;
        uint64_t v1037 = (uint64_t) v25;
        TASSIGN(v1036, v1037);
        uint16_t v1038 = static_cast<uint16_t>(v32);
        uint16_t v1039 = static_cast<uint16_t>(v45);
        TEXTRACT(v1036, v1011, v1038, v1039);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %609
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v995 == v45) {
          pipe_barrier(PIPE_M);
          TMATMUL(v993, v1024, v1028);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v993, v993, v1024, v1028);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v993, v993, v1032, v1036);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
      // pto: %610
      ;
      int64_t v1040 = v987 < v45 ? v45 : v987;
      // pto: %611
      ;
      int64_t v1041 = v990 < v45 ? v45 : v990;
      // pto: %integer_accum__ssa_v0_pview
      ;
      __gm__ int32_t* v1042 = PTOAS__GLOBAL_TENSOR_DATA(v103);
      // pto: %integer_accum__ssa_v0_pview
      ;
      const int64_t v1043 = 0;
      // pto: %integer_accum__ssa_v0_pview
      ;
      const int64_t v1044 = 4096;
      // pto: %integer_accum__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 128> v1045 = pto::Shape<1, 1, 1, 16, 128>();
      // pto: %integer_accum__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v1046 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %integer_accum__ssa_v0_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v1047 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v1042 + (v1043 + v1040 * v1044 + v1041), v1045, v1046);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
      pipe_barrier(PIPE_FIX);
      TSTORE(v1047, v993);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
    };
  } else {
    // pto: %612, %613, %614
    ;
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    for (int64_t v1048 = v126; v1048 < ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v60) / v31) * (uint64_t) v38)); v1048 += v48) {
      // pto: %615, %616
      ;
      int64_t v1049 = (int64_t) ((uint64_t) (v1048 / v38) * (uint64_t) v31);
      // pto: %617
      ;
      int64_t v1050 = v1048 % v38;
      // pto: %618, %619, %620
      ;
      int64_t v1051 = v1050 < v45 ? (int64_t) ((uint64_t) v1050 + (uint64_t) v38) : v1050;
      // pto: %621
      ;
      int64_t v1052 = (int64_t) ((uint64_t) v1051 * (uint64_t) v36);
      // pto: %622
      ;
      int64_t v1053 = (int64_t) ((uint64_t) v17 - (uint64_t) v1049);
      // pto: %623
      ;
      int64_t v1054 = v1053 < v31 ? v1053 : v31;
      // pto: %wide_first_input__tile
      ;
      Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1055 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v1054, v37);
      // pto: %wide_first_input__tile
      ;
      uint64_t v1056 = (uint64_t) v24;
      TASSIGN(v1055, v1056);
      // pto: %624
      ;
      int64_t v1057 = v1049 < v45 ? v45 : v1049;
      // pto: %625
      ;
      const int64_t v1058 = 0;
      // pto: %625
      ;
      __gm__ int8_t* v1059 = PTOAS__GLOBAL_TENSOR_DATA(v85);
      // pto: %625
      ;
      const int64_t v1060 = 1;
      // pto: %625
      ;
      const int64_t v1061 = 1;
      // pto: %625
      ;
      const int64_t v1062 = 1;
      // pto: %625
      ;
      int64_t v1063 = v1054 * v42;
      // pto: %625
      ;
      int64_t v1064 = v1062 * v1063;
      // pto: %625
      ;
      pto::Shape<1, 1, 1, -1, 512> v1065 = pto::Shape<1, 1, 1, -1, 512>(v1060, v1061, v1062, v1054, v37);
      // pto: %625
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1066 = pto::Stride<-1, -1, -1, -1, -1>(v1061 * v1064, v1064, v1063, v42, v29);
      // pto: %625
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1067 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1059 + (v1058 + v1057 * v42 + v45 * v29), v1065, v1066);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v1055, v1067);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %wide_first_weight__tile
      ;
      Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1068 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v37, v36);
      // pto: %wide_first_weight__tile
      ;
      uint64_t v1069 = (uint64_t) v23;
      TASSIGN(v1068, v1069);
      // pto: %626
      ;
      int64_t v1070 = v1052 / v38;
      // pto: %627
      ;
      int64_t v1071 = v1070 < v45 ? v45 : v1070;
      // pto: %628
      ;
      __gm__ int8_t* v1072 = PTOAS__GLOBAL_TENSOR_DATA(v76);
      // pto: %628
      ;
      const int64_t v1073 = 0;
      // pto: %628
      ;
      const int64_t v1074 = 262144;
      // pto: %628
      ;
      pto::Shape<1, 4, 32, 16, 32> v1075 = pto::Shape<1, 4, 32, 16, 32>();
      // pto: %628
      ;
      pto::Stride<33554432, 262144, 512, 32, 1> v1076 = pto::Stride<33554432, 262144, 512, 32, 1>();
      // pto: %628
      ;
      GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v1077 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v1072 + (v1073 + v1071 * v1074), v1075, v1076);
      TLOAD(v1068, v1077);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %wide_b_acc__tile_l0_init_storage
      ;
      Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v1078 = Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v31, v36);
      // pto: %wide_b_acc__tile_l0_init_storage
      ;
      uint64_t v1079 = (uint64_t) v23;
      TASSIGN(v1078, v1079);
      v1078.SetValidShape(v1054, v36);
      // pto: %wide_b_acc__tile_l0_a
      ;
      Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1080 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v1054, v32);
      // pto: %wide_b_acc__tile_l0_a
      ;
      uint64_t v1081 = (uint64_t) v23;
      TASSIGN(v1080, v1081);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      uint16_t v1082 = static_cast<uint16_t>(v45);
      uint16_t v1083 = static_cast<uint16_t>(v45);
      TEXTRACT(v1080, v1055, v1082, v1083);
      // pto: %wide_b_acc__tile_l0_b
      ;
      Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1084 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
      // pto: %wide_b_acc__tile_l0_b
      ;
      uint64_t v1085 = (uint64_t) v23;
      TASSIGN(v1084, v1085);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      uint16_t v1086 = static_cast<uint16_t>(v45);
      uint16_t v1087 = static_cast<uint16_t>(v45);
      TEXTRACT(v1084, v1068, v1086, v1087);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %54
      ;
      Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1088 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v1054, v32);
      // pto: %54
      ;
      uint64_t v1089 = (uint64_t) v25;
      TASSIGN(v1088, v1089);
      uint16_t v1090 = static_cast<uint16_t>(v45);
      uint16_t v1091 = static_cast<uint16_t>(v32);
      TEXTRACT(v1088, v1055, v1090, v1091);
      // pto: %55
      ;
      Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1092 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
      // pto: %55
      ;
      uint64_t v1093 = (uint64_t) v25;
      TASSIGN(v1092, v1093);
      uint16_t v1094 = static_cast<uint16_t>(v32);
      uint16_t v1095 = static_cast<uint16_t>(v45);
      TEXTRACT(v1092, v1068, v1094, v1095);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
      TMATMUL(v1078, v1080, v1084);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v1078, v1078, v1088, v1092);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t v1096 = v29; v1096 < v33; v1096 += v29) {
        // pto: %629
        ;
        int64_t v1097 = (int64_t) ((uint64_t) v1096 * (uint64_t) v37);
        // pto: %wide_b_input__tile
        ;
        Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1098 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v1054, v37);
        // pto: %wide_b_input__tile
        ;
        uint64_t v1099 = (uint64_t) v24;
        TASSIGN(v1098, v1099);
        // pto: %631
        ;
        int64_t v1100 = v1097 < v45 ? v45 : v1097;
        // pto: %632
        ;
        const int64_t v1101 = 0;
        // pto: %632
        ;
        __gm__ int8_t* v1102 = PTOAS__GLOBAL_TENSOR_DATA(v85);
        // pto: %632
        ;
        const int64_t v1103 = 1;
        // pto: %632
        ;
        const int64_t v1104 = 1;
        // pto: %632
        ;
        const int64_t v1105 = 1;
        // pto: %632
        ;
        int64_t v1106 = v1054 * v42;
        // pto: %632
        ;
        int64_t v1107 = v1105 * v1106;
        // pto: %632
        ;
        pto::Shape<1, 1, 1, -1, 512> v1108 = pto::Shape<1, 1, 1, -1, 512>(v1103, v1104, v1105, v1054, v37);
        // pto: %632
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1109 = pto::Stride<-1, -1, -1, -1, -1>(v1104 * v1107, v1107, v1106, v42, v29);
        // pto: %632
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1110 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1102 + (v1101 + v1057 * v42 + v1100 * v29), v1108, v1109);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v1098, v1110);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %wide_b_weight__tile
        ;
        Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1111 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v37, v36);
        // pto: %wide_b_weight__tile
        ;
        uint64_t v1112 = (uint64_t) v23;
        TASSIGN(v1111, v1112);
        // pto: %635
        ;
        int64_t v1113 = v1097 / v33;
        // pto: %636
        ;
        int64_t v1114 = v1113 < v45 ? v45 : v1113;
        // pto: %637
        ;
        __gm__ int8_t* v1115 = PTOAS__GLOBAL_TENSOR_DATA(v76);
        // pto: %637
        ;
        const int64_t v1116 = 0;
        // pto: %637
        ;
        const int64_t v1117 = 262144;
        // pto: %637
        ;
        const int64_t v1118 = 512;
        // pto: %637
        ;
        pto::Shape<1, 4, 32, 16, 32> v1119 = pto::Shape<1, 4, 32, 16, 32>();
        // pto: %637
        ;
        pto::Stride<33554432, 262144, 512, 32, 1> v1120 = pto::Stride<33554432, 262144, 512, 32, 1>();
        // pto: %637
        ;
        GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v1121 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v1115 + (v1116 + v1071 * v1117 + v1114 * v1118), v1119, v1120);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        TLOAD(v1111, v1121);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %57
        ;
        Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1122 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v1054, v32);
        // pto: %57
        ;
        uint64_t v1123 = (uint64_t) v23;
        TASSIGN(v1122, v1123);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v1124 = static_cast<uint16_t>(v45);
        uint16_t v1125 = static_cast<uint16_t>(v45);
        TEXTRACT(v1122, v1098, v1124, v1125);
        // pto: %58
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1126 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %58
        ;
        uint64_t v1127 = (uint64_t) v23;
        TASSIGN(v1126, v1127);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v1128 = static_cast<uint16_t>(v45);
        uint16_t v1129 = static_cast<uint16_t>(v45);
        TEXTRACT(v1126, v1111, v1128, v1129);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %59
        ;
        Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v1130 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v1054, v32);
        // pto: %59
        ;
        uint64_t v1131 = (uint64_t) v25;
        TASSIGN(v1130, v1131);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1132 = static_cast<uint16_t>(v45);
        uint16_t v1133 = static_cast<uint16_t>(v32);
        TEXTRACT(v1130, v1098, v1132, v1133);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        // pto: %60
        ;
        Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1134 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v32, v36);
        // pto: %60
        ;
        uint64_t v1135 = (uint64_t) v25;
        TASSIGN(v1134, v1135);
        uint16_t v1136 = static_cast<uint16_t>(v32);
        uint16_t v1137 = static_cast<uint16_t>(v45);
        TEXTRACT(v1134, v1111, v1136, v1137);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v1078, v1078, v1122, v1126);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v1078, v1078, v1130, v1134);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
      // pto: %639
      ;
      int64_t v1138 = v1052 < v45 ? v45 : v1052;
      // pto: %640
      ;
      const int64_t v1139 = 0;
      // pto: %640
      ;
      __gm__ int32_t* v1140 = PTOAS__GLOBAL_TENSOR_DATA(v103);
      // pto: %640
      ;
      const int64_t v1141 = 1;
      // pto: %640
      ;
      const int64_t v1142 = 1;
      // pto: %640
      ;
      const int64_t v1143 = 1;
      // pto: %640
      ;
      int64_t v1144 = v1054 * v41;
      // pto: %640
      ;
      int64_t v1145 = v1143 * v1144;
      // pto: %640
      ;
      pto::Shape<1, 1, 1, -1, 128> v1146 = pto::Shape<1, 1, 1, -1, 128>(v1141, v1142, v1143, v1054, v36);
      // pto: %640
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1147 = pto::Stride<-1, -1, -1, -1, -1>(v1142 * v1145, v1145, v1144, v41, v29);
      // pto: %640
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1148 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1140 + (v1139 + v1057 * v41 + v1138 * v29), v1146, v1147);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
      TSTORE(v1148, v1078);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    };
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %642
  int64_t v1149 = (int64_t) ((uint64_t) v127 + (uint64_t) v61);
  // pto: %643
  int64_t v1150 = v1149 < v45 ? v45 : v1149;
  // pto: %signals_v2__ssa_v0_signal_pview
  __gm__ int32_t* v1151 = PTOAS__GLOBAL_TENSOR_DATA(v113);
  // pto: %signals_v2__ssa_v0_signal_pview
  const int64_t v1152 = 0;
  // pto: %signals_v2__ssa_v0_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v1153 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals_v2__ssa_v0_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v1154 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals_v2__ssa_v0_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v1155 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v1151 + (v1152 + v1150), v1153, v1154);
  pto::comm::NotifyOp v1156 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v1155, v136, v1156);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void vector(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ int8_t* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ bfloat16_t* v6, __gm__ int8_t* v7, __gm__ float* v8, __gm__ bfloat16_t* v9, __gm__ bfloat16_t* v10, __gm__ float* v11, __gm__ float* v12, __gm__ bfloat16_t* v13, __gm__ float* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21, int32_t v22) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int32_t v23 = 1;
  // pto: %c0_i64
  const int64_t v24 = 0;
  // pto: %c32768_i64
  const int64_t v25 = 32768;
  // pto: %c65536_i64
  const int64_t v26 = 65536;
  // pto: %c65568_i64
  const int64_t v27 = 65568;
  // pto: %c32_i64
  const int64_t v28 = 32;
  // pto: %c64_i64
  const int64_t v29 = 64;
  // pto: %c49152_i64
  const int64_t v30 = 49152;
  // pto: %c98304_i64
  const int64_t v31 = 98304;
  // pto: %c16384_i64
  const int64_t v32 = 16384;
  // pto: %c81920_i64
  const int64_t v33 = 81920;
  // pto: %c114688_i64
  const int64_t v34 = 114688;
  // pto: %c122880_i64
  const int64_t v35 = 122880;
  // pto: %c1_index
  const int64_t v36 = 1;
  // pto: %c8_index
  const int64_t v37 = 8;
  // pto: %c16_index
  const int64_t v38 = 16;
  // pto: %c128_index
  const int64_t v39 = 128;
  // pto: %c512_index
  const int64_t v40 = 512;
  // pto: %c4096_index
  const int64_t v41 = 4096;
  // pto: %c8192_index
  const int64_t v42 = 8192;
  // pto: %c16384_index
  const int64_t v43 = 16384;
  // pto: %c4_index
  const int64_t v44 = 4;
  // pto: %c55296_index
  const int64_t v45 = 55296;
  // pto: %c2_index
  const int64_t v46 = 2;
  // pto: %c24_index
  const int64_t v47 = 24;
  // pto: %c0_index
  const int64_t v48 = 0;
  // pto: %c15_index
  const int64_t v49 = 15;
  // pto: %c9216_index
  const int64_t v50 = 9216;
  // pto: %c48_index
  const int64_t v51 = 48;
  // pto: %c1024_index
  const int64_t v52 = 1024;
  // pto: %c18432_index
  const int64_t v53 = 18432;
  // pto: %c7_index
  const int64_t v54 = 7;
  // pto: %c21504_index
  const int64_t v55 = 21504;
  // pto: %cst_40
  const float v56 = 0.00787401571f;
  // pto: %cst_41
  const float v57 = 0.0f;
  // pto: %cst_42
  const float v58 = 1.0f;
  // pto: %cst_43
  const float v59 = 127.0f;
  // pto: %c27648_index
  const int64_t v60 = 27648;
  // pto: %c36864_index
  const int64_t v61 = 36864;
  // pto: %c46080_index
  const int64_t v62 = 46080;
  // pto: %c72_index
  const int64_t v63 = 72;
  // pto: %c3_index
  const int64_t v64 = 3;
  // pto: %c12_index
  const int64_t v65 = 12;
  // pto: %c5_index
  const int64_t v66 = 5;
  // pto: %c9_index
  const int64_t v67 = 9;
  // pto: %c13_index
  const int64_t v68 = 13;
  // pto: %c6_index
  const int64_t v69 = 6;
  // pto: %c10_index
  const int64_t v70 = 10;
  // pto: %c14_index
  const int64_t v71 = 14;
  // pto: %c11_index
  const int64_t v72 = 11;
  // pto: %c12288_index
  const int64_t v73 = 12288;
  // pto: %cn1_index
  const int64_t v74 = -1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v79 = v41 * v36;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v80 = v78 * v79;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v81 = v77 * v80;
  // pto: %wo_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v82 = pto::Shape<1, 1, 1, 1, -1>(v75, v76, v77, v78, v41);
  // pto: %wo_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v83 = pto::Stride<-1, -1, -1, -1, -1>(v76 * v81, v81, v80, v79, v36);
  // pto: %wo_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v84 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v82, v83);
  // pto: %projected__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %projected__ssa_v0_view
  int64_t v88 = (int64_t) v17;
  // pto: %projected__ssa_v0_view
  int64_t v89 = v88 * v42;
  // pto: %projected__ssa_v0_view
  int64_t v90 = v87 * v89;
  // pto: %projected__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v91 = pto::Shape<1, 1, 1, -1, -1>(v85, v86, v87, v88, v42);
  // pto: %projected__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v92 = pto::Stride<-1, -1, -1, -1, -1>(v86 * v90, v90, v89, v42, v36);
  // pto: %projected__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v93 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v91, v92);
  // pto: %quantized__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v97 = (int64_t) v17;
  // pto: %quantized__ssa_v0_view
  int64_t v98 = v97 * v42;
  // pto: %quantized__ssa_v0_view
  int64_t v99 = v96 * v98;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v100 = pto::Shape<1, 1, 1, -1, -1>(v94, v95, v96, v97, v42);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v101 = pto::Stride<-1, -1, -1, -1, -1>(v95 * v99, v99, v98, v42, v36);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v102 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v100, v101);
  // pto: %token_scale__ssa_v0_view
  const int64_t v103 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v105 = 1;
  // pto: %token_scale__ssa_v0_view
  int64_t v106 = (int64_t) v17;
  // pto: %token_scale__ssa_v0_view
  int64_t v107 = v106 * v36;
  // pto: %token_scale__ssa_v0_view
  int64_t v108 = v105 * v107;
  // pto: %token_scale__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v109 = pto::Shape<1, 1, 1, -1, -1>(v103, v104, v105, v106, v36);
  // pto: %token_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v110 = pto::Stride<-1, -1, -1, -1, -1>(v104 * v108, v108, v107, v36, (int64_t) v17);
  // pto: %token_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v111 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v8, v109, v110);
  // pto: %attended__ssa_v0_view
  const int64_t v112 = 1;
  // pto: %attended__ssa_v0_view
  const int64_t v113 = 1;
  // pto: %attended__ssa_v0_view
  const int64_t v114 = 1;
  // pto: %attended__ssa_v0_view
  int64_t v115 = (int64_t) v17;
  // pto: %attended__ssa_v0_view
  int64_t v116 = v115 * v41;
  // pto: %attended__ssa_v0_view
  int64_t v117 = v114 * v116;
  // pto: %attended__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v118 = pto::Shape<1, 1, 1, -1, -1>(v112, v113, v114, v115, v41);
  // pto: %attended__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v119 = pto::Stride<-1, -1, -1, -1, -1>(v113 * v117, v117, v116, v41, v36);
  // pto: %attended__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v120 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v118, v119);
  // pto: %residual__ssa_v0_view
  const int64_t v121 = 1;
  // pto: %residual__ssa_v0_view
  const int64_t v122 = 1;
  // pto: %residual__ssa_v0_view
  const int64_t v123 = 1;
  // pto: %residual__ssa_v0_view
  int64_t v124 = (int64_t) v17;
  // pto: %residual__ssa_v0_view
  int64_t v125 = v124 * v43;
  // pto: %residual__ssa_v0_view
  int64_t v126 = v123 * v125;
  // pto: %residual__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v127 = pto::Shape<1, 1, 1, -1, -1>(v121, v122, v123, v124, v43);
  // pto: %residual__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v128 = pto::Stride<-1, -1, -1, -1, -1>(v122 * v126, v126, v125, v43, v36);
  // pto: %residual__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v129 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v127, v128);
  // pto: %output__ssa_v0_view
  const int64_t v130 = 1;
  // pto: %output__ssa_v0_view
  const int64_t v131 = 1;
  // pto: %output__ssa_v0_view
  const int64_t v132 = 1;
  // pto: %output__ssa_v0_view
  int64_t v133 = (int64_t) v17;
  // pto: %output__ssa_v0_view
  int64_t v134 = v133 * v43;
  // pto: %output__ssa_v0_view
  int64_t v135 = v132 * v134;
  // pto: %output__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v136 = pto::Shape<1, 1, 1, -1, -1>(v130, v131, v132, v133, v43);
  // pto: %output__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v137 = pto::Stride<-1, -1, -1, -1, -1>(v131 * v135, v135, v134, v43, v36);
  // pto: %output__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v138 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v136, v137);
  // pto: %accum__ssa_v0_view
  const int64_t v139 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v140 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v141 = 1;
  // pto: %accum__ssa_v0_view
  int64_t v142 = (int64_t) v18;
  // pto: %accum__ssa_v0_view
  int64_t v143 = v142 * v42;
  // pto: %accum__ssa_v0_view
  int64_t v144 = v141 * v143;
  // pto: %accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v145 = pto::Shape<1, 1, 1, -1, -1>(v139, v140, v141, v142, v42);
  // pto: %accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v146 = pto::Stride<-1, -1, -1, -1, -1>(v140 * v144, v144, v143, v42, v36);
  // pto: %accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v147 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v145, v146);
  // pto: %integer_accum__ssa_v0_view
  const int64_t v148 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v149 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v150 = 1;
  // pto: %integer_accum__ssa_v0_view
  int64_t v151 = (int64_t) v19;
  // pto: %integer_accum__ssa_v0_view
  int64_t v152 = v151 * v41;
  // pto: %integer_accum__ssa_v0_view
  int64_t v153 = v150 * v152;
  // pto: %integer_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v154 = pto::Shape<1, 1, 1, -1, -1>(v148, v149, v150, v151, v41);
  // pto: %integer_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v155 = pto::Stride<-1, -1, -1, -1, -1>(v149 * v153, v153, v152, v41, v36);
  // pto: %integer_accum__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v156 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v154, v155);
  // pto: %signals__ssa_v0_view
  const int64_t v157 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v158 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v159 = 1;
  // pto: %signals__ssa_v0_view
  const int64_t v160 = 1;
  // pto: %signals__ssa_v0_view
  int64_t v161 = v45 * v36;
  // pto: %signals__ssa_v0_view
  int64_t v162 = v160 * v161;
  // pto: %signals__ssa_v0_view
  int64_t v163 = v159 * v162;
  // pto: %signals__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v164 = pto::Shape<1, 1, 1, 1, -1>(v157, v158, v159, v160, v45);
  // pto: %signals__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v165 = pto::Stride<-1, -1, -1, -1, -1>(v158 * v163, v163, v162, v161, v36);
  // pto: %signals__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v166 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v164, v165);
  // pto: %t__tmp_v0, %145, %146, %t__tmp_v1
  int64_t v167 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v20) * (uint64_t) v46) + (uint64_t) ((int64_t) v22));
  // pto: %147, %148
  int64_t v168 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v167 + (uint64_t) v47) * (uint64_t) v39);
  // pto: %149
  int64_t v169 = v168 < v48 ? v48 : v168;
  // pto: %signals__ssa_v0_pview
  __gm__ int32_t* v170 = PTOAS__GLOBAL_TENSOR_DATA(v166);
  // pto: %signals__ssa_v0_pview
  const int64_t v171 = 0;
  // pto: %signals__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 1> v172 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  pto::Stride<1, 1, 1, 1, 1> v173 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v174 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v170 + (v171 + v169), v172, v173);
  __gm__ int32_t* v175 = PTOAS__GLOBAL_TENSOR_DATA(v174);
  PTOAS__DCCI_SINGLE_CACHE_LINE(v175);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  // pto: %150
  int32_t v176 = (v16)[v168];
  // pto: %152
  int32_t v177 = (int32_t) ((uint32_t) v176 + (uint32_t) v23);
  pipe_barrier(PIPE_ALL);
  pto::comm::NotifyOp v178 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v174, v177, v178);
  // pto: %154, %155, %156
  int64_t v179 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v17 + (uint64_t) v49) / v38) * (uint64_t) v37);
  // pto: %157
  if (v167 < v179) {
    for (int64_t v180 = v48; v180 < v37; v180 += v36) {
      // pto: %158
      ;
      int64_t v181 = v167 % v37;
      // pto: %159, %160, %161
      ;
      int64_t v182 = v181 < v48 ? (int64_t) ((uint64_t) v181 + (uint64_t) v37) : v181;
      // pto: %162, %163, %164
      ;
      int64_t v183 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v182 * (uint64_t) v37) + (uint64_t) v180) % v47;
      // pto: %165, %166, %167
      ;
      int64_t v184 = v183 < v48 ? (int64_t) ((uint64_t) v183 + (uint64_t) v47) : v183;
      // pto: %168, %169
      ;
      int64_t v185 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v184 * (uint64_t) v39) + (uint64_t) v50);
      // pto: %170
      ;
      int64_t v186 = v185 < v48 ? v48 : v185;
      // pto: %signals__ssa_v1_signal_pview
      ;
      __gm__ int32_t* v187 = PTOAS__GLOBAL_TENSOR_DATA(v166);
      // pto: %signals__ssa_v1_signal_pview
      ;
      const int64_t v188 = 0;
      // pto: %signals__ssa_v1_signal_pview
      ;
      pto::Shape<1, 1, 1, 1, 1> v189 = pto::Shape<1, 1, 1, 1, 1>();
      // pto: %signals__ssa_v1_signal_pview
      ;
      pto::Stride<1, 1, 1, 1, 1> v190 = pto::Stride<1, 1, 1, 1, 1>();
      // pto: %signals__ssa_v1_signal_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v191 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v187 + (v188 + v186), v189, v190);
      pto::comm::WaitCmp v192 = pto::comm::WaitCmp::GE;
      pto::comm::TWAIT(v191, v177, v192);
    };
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
  }
  for (int64_t v193 = v167; v193 < v179; v193 += v51) {
    // pto: %172, %173
    ;
    int64_t v194 = (int64_t) ((uint64_t) (v193 / v37) * (uint64_t) v38);
    // pto: %174
    ;
    int64_t v195 = v193 % v37;
    // pto: %175, %176, %177
    ;
    int64_t v196 = v195 < v48 ? (int64_t) ((uint64_t) v195 + (uint64_t) v37) : v195;
    // pto: %178
    ;
    int64_t v197 = (int64_t) ((uint64_t) v196 * (uint64_t) v52);
    // pto: %179
    ;
    int64_t v198 = (int64_t) ((uint64_t) v17 - (uint64_t) v194);
    // pto: %180
    ;
    int64_t v199 = v198 < v38 ? v198 : v38;
    // pto: %oa_value__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v200 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v199, v52);
    // pto: %oa_value__ssa_v0
    ;
    uint64_t v201 = (uint64_t) v24;
    TASSIGN(v200, v201);
    // pto: %181
    ;
    int64_t v202 = v194 < v48 ? v48 : v194;
    // pto: %182
    ;
    int64_t v203 = v197 < v48 ? v48 : v197;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v204 = 0;
    // pto: %accum__ssa_v0_pview
    ;
    __gm__ float* v205 = PTOAS__GLOBAL_TENSOR_DATA(v147);
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v206 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v207 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    const int64_t v208 = 1;
    // pto: %accum__ssa_v0_pview
    ;
    int64_t v209 = v199 * v42;
    // pto: %accum__ssa_v0_pview
    ;
    int64_t v210 = v208 * v209;
    // pto: %accum__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v211 = pto::Shape<1, 1, 1, -1, 1024>(v206, v207, v208, v199, v52);
    // pto: %accum__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v212 = pto::Stride<-1, -1, -1, -1, -1>(v207 * v210, v210, v209, v42, v36);
    // pto: %accum__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v213 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v205 + (v204 + v202 * v42 + v203 * v36), v211, v212);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v200, v213);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %t__tmp_v3
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v199, v52);
    // pto: %t__tmp_v3
    ;
    uint64_t v215 = (uint64_t) v24;
    TASSIGN(v214, v215);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v216 = RoundMode::CAST_RINT;
    SaturationMode v217 = SaturationMode::ON;
    TCVT(v214, v200, v216, v217);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v218 = 0;
    // pto: %projected__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v219 = PTOAS__GLOBAL_TENSOR_DATA(v93);
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v220 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v221 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    const int64_t v222 = 1;
    // pto: %projected__ssa_v0_pview
    ;
    int64_t v223 = v199 * v42;
    // pto: %projected__ssa_v0_pview
    ;
    int64_t v224 = v222 * v223;
    // pto: %projected__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v225 = pto::Shape<1, 1, 1, -1, 1024>(v220, v221, v222, v199, v52);
    // pto: %projected__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v226 = pto::Stride<-1, -1, -1, -1, -1>(v221 * v224, v224, v223, v42, v36);
    // pto: %projected__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v227 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v219 + (v218 + v202 * v42 + v203 * v36), v225, v226);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v227, v214);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %186
  int64_t v228 = (int64_t) ((uint64_t) v168 + (uint64_t) v53);
  // pto: %187
  int64_t v229 = v228 < v48 ? v48 : v228;
  // pto: %188
  __gm__ int32_t* v230 = PTOAS__GLOBAL_TENSOR_DATA(v166);
  // pto: %188
  const int64_t v231 = 0;
  // pto: %188
  pto::Shape<1, 1, 1, 1, 1> v232 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %188
  pto::Stride<1, 1, 1, 1, 1> v233 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %188
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v234 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v230 + (v231 + v229), v232, v233);
  pto::comm::NotifyOp v235 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v234, v177, v235);
  // pto: %189, %190
  int64_t v236 = (int64_t) ((uint64_t) v17 + (uint64_t) v54) / v37;
  // pto: %191
  if (v167 < v236) {
    for (int64_t v237 = v48; v237 < v37; v237 += v36) {
      // pto: %192, %193, %194, %195
      ;
      int64_t v238 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v167 / v46) * (uint64_t) v37) + (uint64_t) v237) % v51;
      // pto: %196, %197, %198
      ;
      int64_t v239 = v238 < v48 ? (int64_t) ((uint64_t) v238 + (uint64_t) v51) : v238;
      // pto: %199, %200
      ;
      int64_t v240 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v239 * (uint64_t) v39) + (uint64_t) v55);
      // pto: %201
      ;
      int64_t v241 = v240 < v48 ? v48 : v240;
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      __gm__ int32_t* v242 = PTOAS__GLOBAL_TENSOR_DATA(v166);
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      const int64_t v243 = 0;
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      pto::Shape<1, 1, 1, 1, 1> v244 = pto::Shape<1, 1, 1, 1, 1>();
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      pto::Stride<1, 1, 1, 1, 1> v245 = pto::Stride<1, 1, 1, 1, 1>();
      // pto: %signals_v1__ssa_v0_signal_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v246 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v242 + (v243 + v241), v244, v245);
      pto::comm::WaitCmp v247 = pto::comm::WaitCmp::GE;
      pto::comm::TWAIT(v246, v177, v247);
    };
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
    dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
    pipe_barrier(PIPE_ALL);
    dsb(DSB_DDR);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v248 = v167; v248 < v236; v248 += v51) {
    // pto: %203
    ;
    int64_t v249 = (int64_t) ((uint64_t) v248 * (uint64_t) v37);
    // pto: %204
    ;
    int64_t v250 = (int64_t) ((uint64_t) v17 - (uint64_t) v249);
    // pto: %205
    ;
    int64_t v251 = v250 < v37 ? v250 : v37;
    // pto: %first_quant__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v252 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v52);
    // pto: %first_quant__ssa_v0
    ;
    uint64_t v253 = (uint64_t) v25;
    TASSIGN(v252, v253);
    // pto: %206
    ;
    int64_t v254 = v249 < v48 ? v48 : v249;
    // pto: %207
    ;
    const int64_t v255 = 0;
    // pto: %207
    ;
    __gm__ bfloat16_t* v256 = PTOAS__GLOBAL_TENSOR_DATA(v93);
    // pto: %207
    ;
    const int64_t v257 = 1;
    // pto: %207
    ;
    const int64_t v258 = 1;
    // pto: %207
    ;
    const int64_t v259 = 1;
    // pto: %207
    ;
    int64_t v260 = v251 * v42;
    // pto: %207
    ;
    int64_t v261 = v259 * v260;
    // pto: %207
    ;
    pto::Shape<1, 1, 1, -1, 1024> v262 = pto::Shape<1, 1, 1, -1, 1024>(v257, v258, v259, v251, v52);
    // pto: %207
    ;
    pto::Stride<-1, -1, -1, -1, -1> v263 = pto::Stride<-1, -1, -1, -1, -1>(v258 * v261, v261, v260, v42, v36);
    // pto: %207
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v264 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v256 + (v255 + v254 * v42 + v48 * v36), v262, v263);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v252, v264);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %t__tmp_v4
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v265 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v52);
    // pto: %t__tmp_v4
    ;
    uint64_t v266 = (uint64_t) v24;
    TASSIGN(v265, v266);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    RoundMode v267 = RoundMode::CAST_ROUND;
    SaturationMode v268 = SaturationMode::ON;
    TCVT(v265, v252, v267, v268);
    // pto: %first_abs__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v52);
    // pto: %first_abs__ssa_v0
    ;
    uint64_t v270 = (uint64_t) v24;
    TASSIGN(v269, v270);
    pipe_barrier(PIPE_V);
    TABS(v269, v265);
    // pto: %t__tmp_v5
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v271 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v52);
    // pto: %t__tmp_v5
    ;
    uint64_t v272 = (uint64_t) v25;
    TASSIGN(v271, v272);
    // pto: %amax__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v36);
    // pto: %amax__ssa_v0
    ;
    uint64_t v274 = (uint64_t) v26;
    TASSIGN(v273, v274);
    pipe_barrier(PIPE_V);
    TROWMAX(v273, v269, v271);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    for (int64_t v275 = v36; v275 < v37; v275 += v36) {
      // pto: %q_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v276 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v52);
      // pto: %q_bf16__ssa_v0
      ;
      uint64_t v277 = (uint64_t) v25;
      TASSIGN(v276, v277);
      // pto: %209
      ;
      int64_t v278 = (int64_t) ((uint64_t) v275 * (uint64_t) v52);
      // pto: %210
      ;
      int64_t v279 = v278 < v48 ? v48 : v278;
      // pto: %211
      ;
      const int64_t v280 = 0;
      // pto: %211
      ;
      __gm__ bfloat16_t* v281 = PTOAS__GLOBAL_TENSOR_DATA(v93);
      // pto: %211
      ;
      const int64_t v282 = 1;
      // pto: %211
      ;
      const int64_t v283 = 1;
      // pto: %211
      ;
      const int64_t v284 = 1;
      // pto: %211
      ;
      int64_t v285 = v251 * v42;
      // pto: %211
      ;
      int64_t v286 = v284 * v285;
      // pto: %211
      ;
      pto::Shape<1, 1, 1, -1, 1024> v287 = pto::Shape<1, 1, 1, -1, 1024>(v282, v283, v284, v251, v52);
      // pto: %211
      ;
      pto::Stride<-1, -1, -1, -1, -1> v288 = pto::Stride<-1, -1, -1, -1, -1>(v283 * v286, v286, v285, v42, v36);
      // pto: %211
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v289 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v281 + (v280 + v254 * v42 + v279 * v36), v287, v288);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v276, v289);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %q_fp32__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v52);
      // pto: %q_fp32__ssa_v0
      ;
      uint64_t v291 = (uint64_t) v24;
      TASSIGN(v290, v291);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      pipe_barrier(PIPE_V);
      RoundMode v292 = RoundMode::CAST_ROUND;
      SaturationMode v293 = SaturationMode::ON;
      TCVT(v290, v276, v292, v293);
      // pto: %t__tmp_v6
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v294 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v52);
      // pto: %t__tmp_v6
      ;
      uint64_t v295 = (uint64_t) v24;
      TASSIGN(v294, v295);
      pipe_barrier(PIPE_V);
      TABS(v294, v290);
      // pto: %t__tmp_v7
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v52);
      // pto: %t__tmp_v7
      ;
      uint64_t v297 = (uint64_t) v25;
      TASSIGN(v296, v297);
      // pto: %t__tmp_v8
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v36);
      // pto: %t__tmp_v8
      ;
      uint64_t v299 = (uint64_t) v27;
      TASSIGN(v298, v299);
      pipe_barrier(PIPE_V);
      TROWMAX(v298, v294, v296);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      // pto: %amax__rm_a0_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v300 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v251);
      // pto: %amax__rm_a0_tmp_v0
      ;
      uint64_t v301 = (uint64_t) v26;
      TASSIGN(v300, v301);
      // pto: %amax__rm_a1_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v302 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v251);
      // pto: %amax__rm_a1_tmp_v1
      ;
      uint64_t v303 = (uint64_t) v27;
      TASSIGN(v302, v303);
      // pto: %amax__row_major_tmp_v2
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v304 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v251);
      // pto: %amax__row_major_tmp_v2
      ;
      uint64_t v305 = (uint64_t) v24;
      TASSIGN(v304, v305);
      pipe_barrier(PIPE_V);
      TMAX(v304, v300, v302);
      // pto: %amax__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v36);
      // pto: %amax__ssa_v3
      ;
      uint64_t v307 = (uint64_t) v24;
      TASSIGN(v306, v307);
      // pto: %amax__ssa_v3_mv
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v308 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v36);
      // pto: %amax__ssa_v3_mv
      ;
      uint64_t v309 = (uint64_t) v26;
      TASSIGN(v308, v309);
      pipe_barrier(PIPE_V);
      TMOV(v308, v306);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    // pto: %dequant__rm_a0_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v310 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v251);
    // pto: %dequant__rm_a0_tmp_v3
    ;
    uint64_t v311 = (uint64_t) v26;
    TASSIGN(v310, v311);
    // pto: %dequant__row_major_tmp_v4
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v251);
    // pto: %dequant__row_major_tmp_v4
    ;
    uint64_t v313 = (uint64_t) v24;
    TASSIGN(v312, v313);
    pipe_barrier(PIPE_V);
    TMULS(v312, v310, v56);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %dequant__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v314 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v36);
    // pto: %dequant__ssa_v0
    ;
    uint64_t v315 = (uint64_t) v24;
    TASSIGN(v314, v315);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v316 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v251);
    // pto: %denominator__rm_a0_tmp_v5
    ;
    uint64_t v317 = (uint64_t) v26;
    TASSIGN(v316, v317);
    // pto: %denominator__row_major_tmp_v6
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v318 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v251);
    // pto: %denominator__row_major_tmp_v6
    ;
    uint64_t v319 = (uint64_t) v28;
    TASSIGN(v318, v319);
    TADDS(v318, v316, v57);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    // pto: %denominator__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v320 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v36);
    // pto: %denominator__ssa_v0
    ;
    uint64_t v321 = (uint64_t) v28;
    TASSIGN(v320, v321);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    for (int64_t v322 = v48; v322 < v251; v322 += v36) {
      // pto: %magnitude__ssa_v0
      ;
      float v323 = v320.GetValue(v322);
      // pto: %212
      ;
      bool v324 = v323 != v323 || v57 != v57;
      // pto: %212
      ;
      if ((v323 == v323 && v57 == v57) && v323 == v57) {
        v320.SetValue(v322, v58);
      };
    };
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    // pto: %t__rm_a0_tmp_v7
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v325 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v251);
    // pto: %t__rm_a0_tmp_v7
    ;
    uint64_t v326 = (uint64_t) v26;
    TASSIGN(v325, v326);
    // pto: %t__row_major_tmp_v8
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v327 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v251);
    // pto: %t__row_major_tmp_v8
    ;
    uint64_t v328 = (uint64_t) v29;
    TASSIGN(v327, v328);
    TMULS(v327, v325, v57);
    // pto: %t__tmp_v9
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v329 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v36);
    // pto: %t__tmp_v9
    ;
    uint64_t v330 = (uint64_t) v29;
    TASSIGN(v329, v330);
    // pto: %t__rm_a0_tmp_v9
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v331 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v251);
    // pto: %t__rm_a0_tmp_v9
    ;
    uint64_t v332 = (uint64_t) v29;
    TASSIGN(v331, v332);
    // pto: %t__row_major_tmp_v10
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v333 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v251);
    // pto: %t__row_major_tmp_v10
    ;
    uint64_t v334 = (uint64_t) v29;
    TASSIGN(v333, v334);
    pipe_barrier(PIPE_V);
    TADDS(v333, v331, v59);
    // pto: %t__tmp_v10
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v335 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v36);
    // pto: %t__tmp_v10
    ;
    uint64_t v336 = (uint64_t) v29;
    TASSIGN(v335, v336);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v337 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v251);
    // pto: %multiplier__rm_a0_tmp_v11
    ;
    uint64_t v338 = (uint64_t) v29;
    TASSIGN(v337, v338);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v339 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v251);
    // pto: %multiplier__rm_a1_tmp_v12
    ;
    uint64_t v340 = (uint64_t) v28;
    TASSIGN(v339, v340);
    // pto: %multiplier__row_major_tmp_v13
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v341 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v251);
    // pto: %multiplier__row_major_tmp_v13
    ;
    uint64_t v342 = (uint64_t) v30;
    TASSIGN(v341, v342);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    TDIV(v341, v337, v339);
    // pto: %multiplier__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v36);
    // pto: %multiplier__ssa_v0
    ;
    uint64_t v344 = (uint64_t) v30;
    TASSIGN(v343, v344);
    v314.SetValidShape(v251, v36);
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v345 = (int64_t) v17;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v346 = 0;
    // pto: %token_scale__ssa_v0_pview
    ;
    __gm__ float* v347 = PTOAS__GLOBAL_TENSOR_DATA(v111);
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v348 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v349 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    const int64_t v350 = 1;
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v351 = v251 * v36;
    // pto: %token_scale__ssa_v0_pview
    ;
    int64_t v352 = v350 * v351;
    // pto: %token_scale__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1> v353 = pto::Shape<1, 1, 1, -1, 1>(v348, v349, v350, v251, v36);
    // pto: %token_scale__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v354 = pto::Stride<-1, -1, -1, -1, -1>(v349 * v352, v352, v351, v36, v345);
    // pto: %token_scale__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v355 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v347 + (v346 + v254 * v36 + v48 * v345), v353, v354);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    TSTORE(v355, v314);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    for (int64_t v356 = v48; v356 < v37; v356 += v36) {
      // pto: %217
      ;
      int64_t v357 = (int64_t) ((uint64_t) v356 * (uint64_t) v52);
      // pto: %quant_bf16__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v358 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v52);
      // pto: %quant_bf16__ssa_v0
      ;
      uint64_t v359 = (uint64_t) v25;
      TASSIGN(v358, v359);
      // pto: %219
      ;
      int64_t v360 = v357 < v48 ? v48 : v357;
      // pto: %220
      ;
      const int64_t v361 = 0;
      // pto: %220
      ;
      __gm__ bfloat16_t* v362 = PTOAS__GLOBAL_TENSOR_DATA(v93);
      // pto: %220
      ;
      const int64_t v363 = 1;
      // pto: %220
      ;
      const int64_t v364 = 1;
      // pto: %220
      ;
      const int64_t v365 = 1;
      // pto: %220
      ;
      int64_t v366 = v251 * v42;
      // pto: %220
      ;
      int64_t v367 = v365 * v366;
      // pto: %220
      ;
      pto::Shape<1, 1, 1, -1, 1024> v368 = pto::Shape<1, 1, 1, -1, 1024>(v363, v364, v365, v251, v52);
      // pto: %220
      ;
      pto::Stride<-1, -1, -1, -1, -1> v369 = pto::Stride<-1, -1, -1, -1, -1>(v364 * v367, v367, v366, v42, v36);
      // pto: %220
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v370 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v362 + (v361 + v254 * v42 + v360 * v36), v368, v369);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      TLOAD(v358, v370);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %t__tmp_v12
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v371 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v52);
      // pto: %t__tmp_v12
      ;
      uint64_t v372 = (uint64_t) v24;
      TASSIGN(v371, v372);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      RoundMode v373 = RoundMode::CAST_ROUND;
      SaturationMode v374 = SaturationMode::ON;
      TCVT(v371, v358, v373, v374);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      // pto: %quant_scaled__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v375 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v52);
      // pto: %quant_scaled__ssa_v0
      ;
      uint64_t v376 = (uint64_t) v24;
      TASSIGN(v375, v376);
      pipe_barrier(PIPE_V);
      TROWEXPANDMUL(v375, v371, v343);
      // pto: %integer__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v377 = Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v52);
      // pto: %integer__ssa_v0
      ;
      uint64_t v378 = (uint64_t) v24;
      TASSIGN(v377, v378);
      pipe_barrier(PIPE_V);
      RoundMode v379 = RoundMode::CAST_RINT;
      SaturationMode v380 = SaturationMode::ON;
      TCVT(v377, v375, v379, v380);
      // pto: %half__ssa_v0
      ;
      Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v381 = Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v52);
      // pto: %half__ssa_v0
      ;
      uint64_t v382 = (uint64_t) v24;
      TASSIGN(v381, v382);
      pipe_barrier(PIPE_V);
      RoundMode v383 = RoundMode::CAST_ROUND;
      SaturationMode v384 = SaturationMode::ON;
      TCVT(v381, v377, v383, v384);
      // pto: %result__ssa_v0
      ;
      Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v385 = Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v251, v52);
      // pto: %result__ssa_v0
      ;
      uint64_t v386 = (uint64_t) v24;
      TASSIGN(v385, v386);
      pipe_barrier(PIPE_V);
      RoundMode v387 = RoundMode::CAST_TRUNC;
      SaturationMode v388 = SaturationMode::ON;
      TCVT(v385, v381, v387, v388);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      v385.SetValidShape(v251, v52);
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v389 = 0;
      // pto: %quantized__ssa_v0_pview
      ;
      __gm__ int8_t* v390 = PTOAS__GLOBAL_TENSOR_DATA(v102);
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v391 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v392 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      const int64_t v393 = 1;
      // pto: %quantized__ssa_v0_pview
      ;
      int64_t v394 = v251 * v42;
      // pto: %quantized__ssa_v0_pview
      ;
      int64_t v395 = v393 * v394;
      // pto: %quantized__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 1024> v396 = pto::Shape<1, 1, 1, -1, 1024>(v391, v392, v393, v251, v52);
      // pto: %quantized__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v397 = pto::Stride<-1, -1, -1, -1, -1>(v392 * v395, v395, v394, v42, v36);
      // pto: %quantized__ssa_v0_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v398 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v390 + (v389 + v254 * v42 + v360 * v36), v396, v397);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      TSTORE(v398, v385);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %224
  int64_t v399 = (int64_t) ((uint64_t) v168 + (uint64_t) v60);
  // pto: %225
  int64_t v400 = v399 < v48 ? v48 : v399;
  // pto: %226
  __gm__ int32_t* v401 = PTOAS__GLOBAL_TENSOR_DATA(v166);
  // pto: %226
  const int64_t v402 = 0;
  // pto: %226
  pto::Shape<1, 1, 1, 1, 1> v403 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %226
  pto::Stride<1, 1, 1, 1, 1> v404 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %226
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v405 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v401 + (v402 + v400), v403, v404);
  pto::comm::NotifyOp v406 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v405, v177, v406);
  // pto: %227
  int64_t v407 = v167 % v37;
  // pto: %228, %229, %230
  int64_t v408 = v407 < v48 ? (int64_t) ((uint64_t) v407 + (uint64_t) v37) : v407;
  // pto: %231
  int64_t v409 = (int64_t) ((uint64_t) v408 * (uint64_t) v40);
  // pto: %t__tmp_v14
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v410 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v40);
  // pto: %t__tmp_v14
  uint64_t v411 = (uint64_t) v25;
  TASSIGN(v410, v411);
  // pto: %232
  int64_t v412 = v409 < v48 ? v48 : v409;
  // pto: %wo_b_scale__ssa_v0_pview
  __gm__ float* v413 = PTOAS__GLOBAL_TENSOR_DATA(v84);
  // pto: %wo_b_scale__ssa_v0_pview
  const int64_t v414 = 0;
  // pto: %wo_b_scale__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 512> v415 = pto::Shape<1, 1, 1, 1, 512>();
  // pto: %wo_b_scale__ssa_v0_pview
  pto::Stride<512, 512, 512, 512, 1> v416 = pto::Stride<512, 512, 512, 512, 1>();
  // pto: %wo_b_scale__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v417 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v413 + (v414 + v412), v415, v416);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  TLOAD(v410, v417);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
  // pto: %channel__ssa_v0
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v418 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v40);
  // pto: %channel__ssa_v0
  uint64_t v419 = (uint64_t) v25;
  TASSIGN(v418, v419);
  // pto: %coefficient_one__ssa_v0
  Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v420 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v40);
  // pto: %coefficient_one__ssa_v0
  uint64_t v421 = (uint64_t) v24;
  TASSIGN(v420, v421);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  pipe_barrier(PIPE_V);
  TEXPANDS(v420, v58);
  // pto: %coefficient_channel__ssa_v0
  Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v422 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v40);
  // pto: %coefficient_channel__ssa_v0
  uint64_t v423 = (uint64_t) v24;
  TASSIGN(v422, v423);
  pipe_barrier(PIPE_V);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
  TCOLEXPANDMUL(v422, v420, v418);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  for (int64_t v424 = v48; v424 < v47; v424 += v36) {
    // pto: %233, %234
    ;
    int64_t v425 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v424 * (uint64_t) v39) + (uint64_t) v61);
    // pto: %235
    ;
    int64_t v426 = v425 < v48 ? v48 : v425;
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v427 = PTOAS__GLOBAL_TENSOR_DATA(v166);
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    const int64_t v428 = 0;
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v429 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v430 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v2__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v431 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v427 + (v428 + v426), v429, v430);
    pto::comm::WaitCmp v432 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v431, v177, v432);
  }
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  for (int64_t v433 = v167; v433 < v179; v433 += v51) {
    // pto: %238, %239
    ;
    int64_t v434 = (int64_t) ((uint64_t) (v433 / v37) * (uint64_t) v38);
    // pto: %240
    ;
    int64_t v435 = v433 % v37;
    // pto: %241, %242, %243
    ;
    int64_t v436 = v435 < v48 ? (int64_t) ((uint64_t) v435 + (uint64_t) v37) : v435;
    // pto: %244
    ;
    int64_t v437 = (int64_t) ((uint64_t) v436 * (uint64_t) v40);
    // pto: %245
    ;
    int64_t v438 = (int64_t) ((uint64_t) v17 - (uint64_t) v434);
    // pto: %246
    ;
    int64_t v439 = v438 < v38 ? v438 : v38;
    // pto: %ob_integer__ssa_v0
    ;
    Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v440 = Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v439, v40);
    // pto: %ob_integer__ssa_v0
    ;
    uint64_t v441 = (uint64_t) v25;
    TASSIGN(v440, v441);
    // pto: %247
    ;
    int64_t v442 = v434 < v48 ? v48 : v434;
    // pto: %248
    ;
    int64_t v443 = v437 < v48 ? v48 : v437;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v444 = 0;
    // pto: %integer_accum__ssa_v0_pview
    ;
    __gm__ int32_t* v445 = PTOAS__GLOBAL_TENSOR_DATA(v156);
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v446 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v447 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    const int64_t v448 = 1;
    // pto: %integer_accum__ssa_v0_pview
    ;
    int64_t v449 = v439 * v41;
    // pto: %integer_accum__ssa_v0_pview
    ;
    int64_t v450 = v448 * v449;
    // pto: %integer_accum__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v451 = pto::Shape<1, 1, 1, -1, 512>(v446, v447, v448, v439, v40);
    // pto: %integer_accum__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v452 = pto::Stride<-1, -1, -1, -1, -1>(v447 * v450, v450, v449, v41, v36);
    // pto: %integer_accum__ssa_v0_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v453 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v445 + (v444 + v442 * v41 + v443 * v36), v451, v452);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    TLOAD(v440, v453);
    // pto: %scale__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v454 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v439, v36);
    // pto: %scale__ssa_v0
    ;
    uint64_t v455 = (uint64_t) v31;
    TASSIGN(v454, v455);
    // pto: %250
    ;
    int64_t v456 = (int64_t) v17;
    // pto: %250
    ;
    const int64_t v457 = 0;
    // pto: %250
    ;
    __gm__ float* v458 = PTOAS__GLOBAL_TENSOR_DATA(v111);
    // pto: %250
    ;
    const int64_t v459 = 1;
    // pto: %250
    ;
    const int64_t v460 = 1;
    // pto: %250
    ;
    const int64_t v461 = 1;
    // pto: %250
    ;
    int64_t v462 = v439 * v36;
    // pto: %250
    ;
    int64_t v463 = v461 * v462;
    // pto: %250
    ;
    pto::Shape<1, 1, 1, -1, 1> v464 = pto::Shape<1, 1, 1, -1, 1>(v459, v460, v461, v439, v36);
    // pto: %250
    ;
    pto::Stride<-1, -1, -1, -1, -1> v465 = pto::Stride<-1, -1, -1, -1, -1>(v460 * v463, v463, v462, v36, v456);
    // pto: %250
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v466 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v458 + (v457 + v442 * v36 + v48 * v456), v464, v465);
    TLOAD(v454, v466);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    // pto: %coefficient__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v467 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v40);
    // pto: %coefficient__ssa_v0
    ;
    uint64_t v468 = (uint64_t) v26;
    TASSIGN(v467, v468);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    TROWEXPANDMUL(v467, v422, v454);
    // pto: %t__tmp_v15
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v469 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v439, v40);
    // pto: %t__tmp_v15
    ;
    uint64_t v470 = (uint64_t) v25;
    TASSIGN(v469, v470);
    RoundMode v471 = RoundMode::CAST_ROUND;
    SaturationMode v472 = SaturationMode::ON;
    TCVT(v469, v440, v471, v472);
    // pto: %ob_scaled__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v473 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v439, v40);
    // pto: %ob_scaled__ssa_v0
    ;
    uint64_t v474 = (uint64_t) v25;
    TASSIGN(v473, v474);
    pipe_barrier(PIPE_V);
    TMUL(v473, v469, v467);
    // pto: %t__tmp_v16
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v475 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v439, v40);
    // pto: %t__tmp_v16
    ;
    uint64_t v476 = (uint64_t) v25;
    TASSIGN(v475, v476);
    pipe_barrier(PIPE_V);
    RoundMode v477 = RoundMode::CAST_RINT;
    SaturationMode v478 = SaturationMode::ON;
    TCVT(v475, v473, v477, v478);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v479 = 0;
    // pto: %attended__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v480 = PTOAS__GLOBAL_TENSOR_DATA(v120);
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v481 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v482 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    const int64_t v483 = 1;
    // pto: %attended__ssa_v0_pview
    ;
    int64_t v484 = v439 * v41;
    // pto: %attended__ssa_v0_pview
    ;
    int64_t v485 = v483 * v484;
    // pto: %attended__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v486 = pto::Shape<1, 1, 1, -1, 512>(v481, v482, v483, v439, v40);
    // pto: %attended__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v487 = pto::Stride<-1, -1, -1, -1, -1>(v482 * v485, v485, v484, v41, v36);
    // pto: %attended__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v488 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v480 + (v479 + v442 * v41 + v443 * v36), v486, v487);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    TSTORE(v488, v475);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  pipe_barrier(PIPE_ALL);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %254
  int64_t v489 = (int64_t) ((uint64_t) v168 + (uint64_t) v62);
  // pto: %255
  int64_t v490 = v489 < v48 ? v48 : v489;
  // pto: %signals_v3__ssa_v0_signal_pview
  __gm__ int32_t* v491 = PTOAS__GLOBAL_TENSOR_DATA(v166);
  // pto: %signals_v3__ssa_v0_signal_pview
  const int64_t v492 = 0;
  // pto: %signals_v3__ssa_v0_signal_pview
  pto::Shape<1, 1, 1, 1, 1> v493 = pto::Shape<1, 1, 1, 1, 1>();
  // pto: %signals_v3__ssa_v0_signal_pview
  pto::Stride<1, 1, 1, 1, 1> v494 = pto::Stride<1, 1, 1, 1, 1>();
  // pto: %signals_v3__ssa_v0_signal_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v495 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v491 + (v492 + v490), v493, v494);
  pto::comm::NotifyOp v496 = pto::comm::NotifyOp::Set;
  pto::comm::TNOTIFY(v495, v177, v496);
  for (int64_t v497 = v47; v497 < v63; v497 += v36) {
    // pto: %256, %257
    ;
    int64_t v498 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v497 * (uint64_t) v39) + (uint64_t) v62);
    // pto: %258
    ;
    int64_t v499 = v498 < v48 ? v48 : v498;
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    __gm__ int32_t* v500 = PTOAS__GLOBAL_TENSOR_DATA(v166);
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    const int64_t v501 = 0;
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    pto::Shape<1, 1, 1, 1, 1> v502 = pto::Shape<1, 1, 1, 1, 1>();
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    pto::Stride<1, 1, 1, 1, 1> v503 = pto::Stride<1, 1, 1, 1, 1>();
    // pto: %signals_v4__ssa_v0_signal_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND> v504 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 1>, pto::Stride<1, 1, 1, 1, 1>, pto::Layout::ND>(v500 + (v501 + v499), v502, v503);
    pto::comm::WaitCmp v505 = pto::comm::WaitCmp::GE;
    pto::comm::TWAIT(v504, v177, v505);
  }
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %259, %260
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  for (int64_t v506 = v167; v506 < ((int64_t) ((uint64_t) v17 + (uint64_t) v64) / v44); v506 += v51) {
    // pto: %261
    ;
    int64_t v507 = (int64_t) ((uint64_t) v506 * (uint64_t) v44);
    // pto: %262
    ;
    int64_t v508 = (int64_t) ((uint64_t) v507 + (uint64_t) v44);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    for (int64_t v509 = v507; v509 < v508; v509 += v46) {
      // pto: %263
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      if (v509 < v17) {
        // pto: %264
        ;
        int64_t v510 = (int64_t) ((uint64_t) v509 * (uint64_t) v44);
        // pto: %post_scalar__tile
        ;
        float v511 = (v11)[v510];
        // pto: %266
        ;
        int64_t v512 = (int64_t) ((uint64_t) v509 * (uint64_t) v38);
        // pto: %comb_scalar_0__tile
        ;
        float v513 = (v12)[v512];
        // pto: %269, %comb_scalar_1__tile
        ;
        float v514 = (v12)[(int64_t) ((uint64_t) v512 + (uint64_t) v44)];
        // pto: %271, %comb_scalar_2__tile
        ;
        float v515 = (v12)[(int64_t) ((uint64_t) v512 + (uint64_t) v37)];
        // pto: %273, %comb_scalar_3__tile
        ;
        float v516 = (v12)[(int64_t) ((uint64_t) v512 + (uint64_t) v65)];
        // pto: %276, %274
        ;
        float v517 = (v11)[(int64_t) ((uint64_t) v510 + (uint64_t) v36)];
        // pto: %279, %277
        ;
        float v518 = (v12)[(int64_t) ((uint64_t) v512 + (uint64_t) v36)];
        // pto: %282, %280
        ;
        float v519 = (v12)[(int64_t) ((uint64_t) v512 + (uint64_t) v66)];
        // pto: %285, %283
        ;
        float v520 = (v12)[(int64_t) ((uint64_t) v512 + (uint64_t) v67)];
        // pto: %288, %286
        ;
        float v521 = (v12)[(int64_t) ((uint64_t) v512 + (uint64_t) v68)];
        // pto: %291, %289
        ;
        float v522 = (v11)[(int64_t) ((uint64_t) v510 + (uint64_t) v46)];
        // pto: %294, %292
        ;
        float v523 = (v12)[(int64_t) ((uint64_t) v512 + (uint64_t) v46)];
        // pto: %297, %295
        ;
        float v524 = (v12)[(int64_t) ((uint64_t) v512 + (uint64_t) v69)];
        // pto: %300, %298
        ;
        float v525 = (v12)[(int64_t) ((uint64_t) v512 + (uint64_t) v70)];
        // pto: %303, %301
        ;
        float v526 = (v12)[(int64_t) ((uint64_t) v512 + (uint64_t) v71)];
        // pto: %306, %304
        ;
        float v527 = (v11)[(int64_t) ((uint64_t) v510 + (uint64_t) v64)];
        // pto: %309, %307
        ;
        float v528 = (v12)[(int64_t) ((uint64_t) v512 + (uint64_t) v64)];
        // pto: %312, %310
        ;
        float v529 = (v12)[(int64_t) ((uint64_t) v512 + (uint64_t) v54)];
        // pto: %315, %313
        ;
        float v530 = (v12)[(int64_t) ((uint64_t) v512 + (uint64_t) v72)];
        // pto: %318, %316
        ;
        float v531 = (v12)[(int64_t) ((uint64_t) v512 + (uint64_t) v49)];
        // pto: %x_block__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v532 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %x_block__tile
        ;
        uint64_t v533 = (uint64_t) v32;
        TASSIGN(v532, v533);
        // pto: %319
        ;
        int64_t v534 = v509 < v48 ? v48 : v509;
        // pto: %x__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v535 = PTOAS__GLOBAL_TENSOR_DATA(v120);
        // pto: %x__ssa_v0_pview
        ;
        const int64_t v536 = 0;
        // pto: %x__ssa_v0_pview
        ;
        const int64_t v537 = 4096;
        // pto: %x__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v538 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %x__ssa_v0_pview
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v539 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %x__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v540 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v535 + (v536 + v534 * v537), v538, v539);
        TLOAD(v532, v540);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        // pto: %320
        ;
        int64_t v541 = (int64_t) ((uint64_t) v17 - (uint64_t) v509);
        // pto: %321
        ;
        int64_t v542 = v541 < v48 ? v48 : v541;
        // pto: %322
        ;
        int64_t v543 = v542 < v36 ? v542 : v36;
        // pto: %t__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v544 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %t__tile
        ;
        uint64_t v545 = (uint64_t) v25;
        TASSIGN(v544, v545);
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v546 = 0;
        // pto: %residual_flat__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v547 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v548 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v549 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        const int64_t v550 = 1;
        // pto: %residual_flat__ssa_v0_pview
        ;
        int64_t v551 = v543 * v43;
        // pto: %residual_flat__ssa_v0_pview
        ;
        int64_t v552 = v550 * v551;
        // pto: %residual_flat__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 4096> v553 = pto::Shape<1, 1, 1, -1, 4096>(v548, v549, v550, v543, v41);
        // pto: %residual_flat__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v554 = pto::Stride<-1, -1, -1, -1, -1>(v549 * v552, v552, v551, v43, v36);
        // pto: %residual_flat__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v555 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v547 + (v546 + v534 * v43 + v48 * v36), v553, v554);
        TLOAD(v544, v555);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        // pto: %0
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v556 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %0
        ;
        uint64_t v557 = (uint64_t) v30;
        TASSIGN(v556, v557);
        // pto: %334
        ;
        const int64_t v558 = 0;
        // pto: %334
        ;
        __gm__ bfloat16_t* v559 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %334
        ;
        const int64_t v560 = 1;
        // pto: %334
        ;
        const int64_t v561 = 1;
        // pto: %334
        ;
        const int64_t v562 = 1;
        // pto: %334
        ;
        int64_t v563 = v543 * v43;
        // pto: %334
        ;
        int64_t v564 = v562 * v563;
        // pto: %334
        ;
        pto::Shape<1, 1, 1, -1, 4096> v565 = pto::Shape<1, 1, 1, -1, 4096>(v560, v561, v562, v543, v41);
        // pto: %334
        ;
        pto::Stride<-1, -1, -1, -1, -1> v566 = pto::Stride<-1, -1, -1, -1, -1>(v561 * v564, v564, v563, v43, v36);
        // pto: %334
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v567 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v559 + (v558 + v534 * v43 + v41 * v36), v565, v566);
        TLOAD(v556, v567);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %1
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v568 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %1
        ;
        uint64_t v569 = (uint64_t) v26;
        TASSIGN(v568, v569);
        // pto: %342
        ;
        const int64_t v570 = 0;
        // pto: %342
        ;
        __gm__ bfloat16_t* v571 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %342
        ;
        const int64_t v572 = 1;
        // pto: %342
        ;
        const int64_t v573 = 1;
        // pto: %342
        ;
        const int64_t v574 = 1;
        // pto: %342
        ;
        int64_t v575 = v543 * v43;
        // pto: %342
        ;
        int64_t v576 = v574 * v575;
        // pto: %342
        ;
        pto::Shape<1, 1, 1, -1, 4096> v577 = pto::Shape<1, 1, 1, -1, 4096>(v572, v573, v574, v543, v41);
        // pto: %342
        ;
        pto::Stride<-1, -1, -1, -1, -1> v578 = pto::Stride<-1, -1, -1, -1, -1>(v573 * v576, v576, v575, v43, v36);
        // pto: %342
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v579 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v571 + (v570 + v534 * v43 + v42 * v36), v577, v578);
        TLOAD(v568, v579);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %2
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v580 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %2
        ;
        uint64_t v581 = (uint64_t) v33;
        TASSIGN(v580, v581);
        // pto: %350
        ;
        const int64_t v582 = 0;
        // pto: %350
        ;
        __gm__ bfloat16_t* v583 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %350
        ;
        const int64_t v584 = 1;
        // pto: %350
        ;
        const int64_t v585 = 1;
        // pto: %350
        ;
        const int64_t v586 = 1;
        // pto: %350
        ;
        int64_t v587 = v543 * v43;
        // pto: %350
        ;
        int64_t v588 = v586 * v587;
        // pto: %350
        ;
        pto::Shape<1, 1, 1, -1, 4096> v589 = pto::Shape<1, 1, 1, -1, 4096>(v584, v585, v586, v543, v41);
        // pto: %350
        ;
        pto::Stride<-1, -1, -1, -1, -1> v590 = pto::Stride<-1, -1, -1, -1, -1>(v585 * v588, v588, v587, v43, v36);
        // pto: %350
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v591 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v583 + (v582 + v534 * v43 + v73 * v36), v589, v590);
        TLOAD(v580, v591);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %x_f32__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v592 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %x_f32__tile
        ;
        uint64_t v593 = (uint64_t) v24;
        TASSIGN(v592, v593);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        RoundMode v594 = RoundMode::CAST_ROUND;
        SaturationMode v595 = SaturationMode::ON;
        TCVT(v592, v532, v594, v595);
        // pto: %res_0__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v596 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %res_0__tile
        ;
        uint64_t v597 = (uint64_t) v32;
        TASSIGN(v596, v597);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        RoundMode v598 = RoundMode::CAST_ROUND;
        SaturationMode v599 = SaturationMode::ON;
        TCVT(v596, v544, v598, v599);
        // pto: %res_1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v600 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %res_1__tile
        ;
        uint64_t v601 = (uint64_t) v25;
        TASSIGN(v600, v601);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v602 = RoundMode::CAST_ROUND;
        SaturationMode v603 = SaturationMode::ON;
        TCVT(v600, v556, v602, v603);
        // pto: %res_2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v604 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %res_2__tile
        ;
        uint64_t v605 = (uint64_t) v30;
        TASSIGN(v604, v605);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v606 = RoundMode::CAST_ROUND;
        SaturationMode v607 = SaturationMode::ON;
        TCVT(v604, v568, v606, v607);
        // pto: %res_3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v608 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %res_3__tile
        ;
        uint64_t v609 = (uint64_t) v26;
        TASSIGN(v608, v609);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v610 = RoundMode::CAST_ROUND;
        SaturationMode v611 = SaturationMode::ON;
        TCVT(v608, v580, v610, v611);
        // pto: %single_y__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v612 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %single_y__tile
        ;
        uint64_t v613 = (uint64_t) v33;
        TASSIGN(v612, v613);
        pipe_barrier(PIPE_V);
        TMULS(v612, v592, v511);
        // pto: %single_weighted_0__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v614 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %single_weighted_0__tile
        ;
        uint64_t v615 = (uint64_t) v31;
        TASSIGN(v614, v615);
        TMULS(v614, v596, v513);
        // pto: %single_y_v1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v616 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %single_y_v1__tile
        ;
        uint64_t v617 = (uint64_t) v33;
        TASSIGN(v616, v617);
        pipe_barrier(PIPE_V);
        TADD(v616, v612, v614);
        // pto: %single_weighted_1__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v618 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %single_weighted_1__tile
        ;
        uint64_t v619 = (uint64_t) v31;
        TASSIGN(v618, v619);
        pipe_barrier(PIPE_V);
        TMULS(v618, v600, v514);
        // pto: %single_y_v2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v620 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %single_y_v2__tile
        ;
        uint64_t v621 = (uint64_t) v33;
        TASSIGN(v620, v621);
        pipe_barrier(PIPE_V);
        TADD(v620, v616, v618);
        // pto: %single_weighted_2__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v622 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %single_weighted_2__tile
        ;
        uint64_t v623 = (uint64_t) v31;
        TASSIGN(v622, v623);
        pipe_barrier(PIPE_V);
        TMULS(v622, v604, v515);
        // pto: %single_y_v3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v624 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %single_y_v3__tile
        ;
        uint64_t v625 = (uint64_t) v33;
        TASSIGN(v624, v625);
        pipe_barrier(PIPE_V);
        TADD(v624, v620, v622);
        // pto: %single_weighted_3__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v626 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %single_weighted_3__tile
        ;
        uint64_t v627 = (uint64_t) v31;
        TASSIGN(v626, v627);
        pipe_barrier(PIPE_V);
        TMULS(v626, v608, v516);
        // pto: %single_y_v4__tile
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v628 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %single_y_v4__tile
        ;
        uint64_t v629 = (uint64_t) v33;
        TASSIGN(v628, v629);
        pipe_barrier(PIPE_V);
        TADD(v628, v624, v626);
        // pto: %single_result__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v630 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %single_result__tile
        ;
        uint64_t v631 = (uint64_t) v34;
        TASSIGN(v630, v631);
        pipe_barrier(PIPE_V);
        RoundMode v632 = RoundMode::CAST_RINT;
        SaturationMode v633 = SaturationMode::ON;
        TCVT(v630, v628, v632, v633);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        v630.SetValidShape(v36, v41);
        // pto: %4
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v634 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %4
        ;
        uint64_t v635 = (uint64_t) v33;
        TASSIGN(v634, v635);
        pipe_barrier(PIPE_V);
        TMULS(v634, v592, v517);
        // pto: %5
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v636 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %5
        ;
        uint64_t v637 = (uint64_t) v31;
        TASSIGN(v636, v637);
        TMULS(v636, v596, v518);
        // pto: %6
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v638 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %6
        ;
        uint64_t v639 = (uint64_t) v33;
        TASSIGN(v638, v639);
        pipe_barrier(PIPE_V);
        TADD(v638, v634, v636);
        // pto: %7
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v640 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %7
        ;
        uint64_t v641 = (uint64_t) v31;
        TASSIGN(v640, v641);
        pipe_barrier(PIPE_V);
        TMULS(v640, v600, v519);
        // pto: %8
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v642 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %8
        ;
        uint64_t v643 = (uint64_t) v33;
        TASSIGN(v642, v643);
        pipe_barrier(PIPE_V);
        TADD(v642, v638, v640);
        // pto: %9
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v644 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %9
        ;
        uint64_t v645 = (uint64_t) v31;
        TASSIGN(v644, v645);
        pipe_barrier(PIPE_V);
        TMULS(v644, v604, v520);
        // pto: %10
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v646 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %10
        ;
        uint64_t v647 = (uint64_t) v33;
        TASSIGN(v646, v647);
        pipe_barrier(PIPE_V);
        TADD(v646, v642, v644);
        // pto: %11
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v648 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %11
        ;
        uint64_t v649 = (uint64_t) v31;
        TASSIGN(v648, v649);
        pipe_barrier(PIPE_V);
        TMULS(v648, v608, v521);
        // pto: %12
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v650 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %12
        ;
        uint64_t v651 = (uint64_t) v33;
        TASSIGN(v650, v651);
        pipe_barrier(PIPE_V);
        TADD(v650, v646, v648);
        // pto: %13
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v652 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %13
        ;
        uint64_t v653 = (uint64_t) v35;
        TASSIGN(v652, v653);
        pipe_barrier(PIPE_V);
        RoundMode v654 = RoundMode::CAST_RINT;
        SaturationMode v655 = SaturationMode::ON;
        TCVT(v652, v650, v654, v655);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        v652.SetValidShape(v36, v41);
        // pto: %15
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v656 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %15
        ;
        uint64_t v657 = (uint64_t) v33;
        TASSIGN(v656, v657);
        pipe_barrier(PIPE_V);
        TMULS(v656, v592, v522);
        // pto: %16
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v658 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %16
        ;
        uint64_t v659 = (uint64_t) v31;
        TASSIGN(v658, v659);
        TMULS(v658, v596, v523);
        // pto: %17
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v660 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %17
        ;
        uint64_t v661 = (uint64_t) v33;
        TASSIGN(v660, v661);
        pipe_barrier(PIPE_V);
        TADD(v660, v656, v658);
        // pto: %18
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v662 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %18
        ;
        uint64_t v663 = (uint64_t) v31;
        TASSIGN(v662, v663);
        pipe_barrier(PIPE_V);
        TMULS(v662, v600, v524);
        // pto: %19
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v664 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %19
        ;
        uint64_t v665 = (uint64_t) v33;
        TASSIGN(v664, v665);
        pipe_barrier(PIPE_V);
        TADD(v664, v660, v662);
        // pto: %20
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v666 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %20
        ;
        uint64_t v667 = (uint64_t) v31;
        TASSIGN(v666, v667);
        pipe_barrier(PIPE_V);
        TMULS(v666, v604, v525);
        // pto: %21
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v668 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %21
        ;
        uint64_t v669 = (uint64_t) v33;
        TASSIGN(v668, v669);
        pipe_barrier(PIPE_V);
        TADD(v668, v664, v666);
        // pto: %22
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v670 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %22
        ;
        uint64_t v671 = (uint64_t) v31;
        TASSIGN(v670, v671);
        pipe_barrier(PIPE_V);
        TMULS(v670, v608, v526);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v672 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %23
        ;
        uint64_t v673 = (uint64_t) v33;
        TASSIGN(v672, v673);
        pipe_barrier(PIPE_V);
        TADD(v672, v668, v670);
        // pto: %24
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v674 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %24
        ;
        uint64_t v675 = (uint64_t) v33;
        TASSIGN(v674, v675);
        pipe_barrier(PIPE_V);
        RoundMode v676 = RoundMode::CAST_RINT;
        SaturationMode v677 = SaturationMode::ON;
        TCVT(v674, v672, v676, v677);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        v674.SetValidShape(v36, v41);
        // pto: %26
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v678 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %26
        ;
        uint64_t v679 = (uint64_t) v24;
        TASSIGN(v678, v679);
        TMULS(v678, v592, v527);
        // pto: %27
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v680 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %27
        ;
        uint64_t v681 = (uint64_t) v32;
        TASSIGN(v680, v681);
        TMULS(v680, v596, v528);
        // pto: %28
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v682 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %28
        ;
        uint64_t v683 = (uint64_t) v24;
        TASSIGN(v682, v683);
        pipe_barrier(PIPE_V);
        TADD(v682, v678, v680);
        // pto: %29
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v684 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %29
        ;
        uint64_t v685 = (uint64_t) v32;
        TASSIGN(v684, v685);
        pipe_barrier(PIPE_V);
        TMULS(v684, v600, v529);
        // pto: %30
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v686 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %30
        ;
        uint64_t v687 = (uint64_t) v24;
        TASSIGN(v686, v687);
        pipe_barrier(PIPE_V);
        TADD(v686, v682, v684);
        // pto: %31
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v688 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %31
        ;
        uint64_t v689 = (uint64_t) v32;
        TASSIGN(v688, v689);
        pipe_barrier(PIPE_V);
        TMULS(v688, v604, v530);
        // pto: %32
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v690 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %32
        ;
        uint64_t v691 = (uint64_t) v24;
        TASSIGN(v690, v691);
        pipe_barrier(PIPE_V);
        TADD(v690, v686, v688);
        // pto: %33
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v692 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v543, v41);
        // pto: %33
        ;
        uint64_t v693 = (uint64_t) v32;
        TASSIGN(v692, v693);
        pipe_barrier(PIPE_V);
        TMULS(v692, v608, v531);
        // pto: %34
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v694 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %34
        ;
        uint64_t v695 = (uint64_t) v24;
        TASSIGN(v694, v695);
        pipe_barrier(PIPE_V);
        TADD(v694, v690, v692);
        // pto: %35
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v696 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %35
        ;
        uint64_t v697 = (uint64_t) v24;
        TASSIGN(v696, v697);
        pipe_barrier(PIPE_V);
        RoundMode v698 = RoundMode::CAST_RINT;
        SaturationMode v699 = SaturationMode::ON;
        TCVT(v696, v694, v698, v699);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        v696.SetValidShape(v36, v41);
        // pto: %y_flat__iter_v3_pview
        ;
        __gm__ bfloat16_t* v700 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %y_flat__iter_v3_pview
        ;
        const int64_t v701 = 0;
        // pto: %y_flat__iter_v3_pview
        ;
        const int64_t v702 = 16384;
        // pto: %y_flat__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v703 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__iter_v3_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v704 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v705 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v700 + (v701 + v534 * v702), v703, v704);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        TSTORE(v705, v630);
        // pto: %y_flat__tile_pview
        ;
        __gm__ bfloat16_t* v706 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %y_flat__tile_pview
        ;
        const int64_t v707 = 4096;
        // pto: %y_flat__tile_pview
        ;
        const int64_t v708 = 16384;
        // pto: %y_flat__tile_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v709 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__tile_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v710 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__tile_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v711 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v706 + (v707 + v534 * v708), v709, v710);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        TSTORE(v711, v652);
        // pto: %416
        ;
        __gm__ bfloat16_t* v712 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %416
        ;
        const int64_t v713 = 8192;
        // pto: %416
        ;
        const int64_t v714 = 16384;
        // pto: %416
        ;
        pto::Shape<1, 1, 1, 1, 4096> v715 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %416
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v716 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %416
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v717 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v712 + (v713 + v534 * v714), v715, v716);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        TSTORE(v717, v674);
        // pto: %419
        ;
        __gm__ bfloat16_t* v718 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %419
        ;
        const int64_t v719 = 12288;
        // pto: %419
        ;
        const int64_t v720 = 16384;
        // pto: %419
        ;
        pto::Shape<1, 1, 1, 1, 4096> v721 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %419
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v722 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %419
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v723 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v718 + (v719 + v534 * v720), v721, v722);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        TSTORE(v723, v696);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %420
      ;
      int64_t v724 = (int64_t) ((uint64_t) v509 + (uint64_t) v36);
      // pto: %421
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
      if (v724 < v17) {
        // pto: %424
        ;
        int64_t v725 = (int64_t) ((uint64_t) v724 * (uint64_t) v44);
        // pto: %422
        ;
        float v726 = (v11)[v725];
        // pto: %428
        ;
        int64_t v727 = (int64_t) ((uint64_t) v724 * (uint64_t) v38);
        // pto: %426
        ;
        float v728 = (v12)[v727];
        // pto: %433, %430
        ;
        float v729 = (v12)[(int64_t) ((uint64_t) v727 + (uint64_t) v44)];
        // pto: %437, %434
        ;
        float v730 = (v12)[(int64_t) ((uint64_t) v727 + (uint64_t) v37)];
        // pto: %441, %438
        ;
        float v731 = (v12)[(int64_t) ((uint64_t) v727 + (uint64_t) v65)];
        // pto: %445, %442
        ;
        float v732 = (v11)[(int64_t) ((uint64_t) v725 + (uint64_t) v36)];
        // pto: %449, %446
        ;
        float v733 = (v12)[(int64_t) ((uint64_t) v727 + (uint64_t) v36)];
        // pto: %453, %450
        ;
        float v734 = (v12)[(int64_t) ((uint64_t) v727 + (uint64_t) v66)];
        // pto: %457, %454
        ;
        float v735 = (v12)[(int64_t) ((uint64_t) v727 + (uint64_t) v67)];
        // pto: %461, %458
        ;
        float v736 = (v12)[(int64_t) ((uint64_t) v727 + (uint64_t) v68)];
        // pto: %465, %462
        ;
        float v737 = (v11)[(int64_t) ((uint64_t) v725 + (uint64_t) v46)];
        // pto: %469, %466
        ;
        float v738 = (v12)[(int64_t) ((uint64_t) v727 + (uint64_t) v46)];
        // pto: %473, %470
        ;
        float v739 = (v12)[(int64_t) ((uint64_t) v727 + (uint64_t) v69)];
        // pto: %477, %474
        ;
        float v740 = (v12)[(int64_t) ((uint64_t) v727 + (uint64_t) v70)];
        // pto: %481, %478
        ;
        float v741 = (v12)[(int64_t) ((uint64_t) v727 + (uint64_t) v71)];
        // pto: %485, %482
        ;
        float v742 = (v11)[(int64_t) ((uint64_t) v725 + (uint64_t) v64)];
        // pto: %489, %486
        ;
        float v743 = (v12)[(int64_t) ((uint64_t) v727 + (uint64_t) v64)];
        // pto: %493, %490
        ;
        float v744 = (v12)[(int64_t) ((uint64_t) v727 + (uint64_t) v54)];
        // pto: %497, %494
        ;
        float v745 = (v12)[(int64_t) ((uint64_t) v727 + (uint64_t) v72)];
        // pto: %501, %498
        ;
        float v746 = (v12)[(int64_t) ((uint64_t) v727 + (uint64_t) v49)];
        // pto: %37
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v747 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %37
        ;
        uint64_t v748 = (uint64_t) v32;
        TASSIGN(v747, v748);
        // pto: %503
        ;
        int64_t v749 = v724 < v48 ? v48 : v724;
        // pto: %504
        ;
        __gm__ bfloat16_t* v750 = PTOAS__GLOBAL_TENSOR_DATA(v120);
        // pto: %504
        ;
        const int64_t v751 = 0;
        // pto: %504
        ;
        const int64_t v752 = 4096;
        // pto: %504
        ;
        pto::Shape<1, 1, 1, 1, 4096> v753 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %504
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v754 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %504
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v755 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v750 + (v751 + v749 * v752), v753, v754);
        TLOAD(v747, v755);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %505, %506
        ;
        int64_t v756 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v17 - (uint64_t) v509) + (uint64_t) v74);
        // pto: %507
        ;
        int64_t v757 = v756 < v48 ? v48 : v756;
        // pto: %508
        ;
        int64_t v758 = v757 < v36 ? v757 : v36;
        // pto: %38
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v759 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %38
        ;
        uint64_t v760 = (uint64_t) v25;
        TASSIGN(v759, v760);
        // pto: %515
        ;
        const int64_t v761 = 0;
        // pto: %515
        ;
        __gm__ bfloat16_t* v762 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %515
        ;
        const int64_t v763 = 1;
        // pto: %515
        ;
        const int64_t v764 = 1;
        // pto: %515
        ;
        const int64_t v765 = 1;
        // pto: %515
        ;
        int64_t v766 = v758 * v43;
        // pto: %515
        ;
        int64_t v767 = v765 * v766;
        // pto: %515
        ;
        pto::Shape<1, 1, 1, -1, 4096> v768 = pto::Shape<1, 1, 1, -1, 4096>(v763, v764, v765, v758, v41);
        // pto: %515
        ;
        pto::Stride<-1, -1, -1, -1, -1> v769 = pto::Stride<-1, -1, -1, -1, -1>(v764 * v767, v767, v766, v43, v36);
        // pto: %515
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v770 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v762 + (v761 + v749 * v43 + v48 * v36), v768, v769);
        TLOAD(v759, v770);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %39
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v771 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %39
        ;
        uint64_t v772 = (uint64_t) v30;
        TASSIGN(v771, v772);
        // pto: %526
        ;
        const int64_t v773 = 0;
        // pto: %526
        ;
        __gm__ bfloat16_t* v774 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %526
        ;
        const int64_t v775 = 1;
        // pto: %526
        ;
        const int64_t v776 = 1;
        // pto: %526
        ;
        const int64_t v777 = 1;
        // pto: %526
        ;
        int64_t v778 = v758 * v43;
        // pto: %526
        ;
        int64_t v779 = v777 * v778;
        // pto: %526
        ;
        pto::Shape<1, 1, 1, -1, 4096> v780 = pto::Shape<1, 1, 1, -1, 4096>(v775, v776, v777, v758, v41);
        // pto: %526
        ;
        pto::Stride<-1, -1, -1, -1, -1> v781 = pto::Stride<-1, -1, -1, -1, -1>(v776 * v779, v779, v778, v43, v36);
        // pto: %526
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v782 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v774 + (v773 + v749 * v43 + v41 * v36), v780, v781);
        TLOAD(v771, v782);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %40
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v783 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %40
        ;
        uint64_t v784 = (uint64_t) v26;
        TASSIGN(v783, v784);
        // pto: %537
        ;
        const int64_t v785 = 0;
        // pto: %537
        ;
        __gm__ bfloat16_t* v786 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %537
        ;
        const int64_t v787 = 1;
        // pto: %537
        ;
        const int64_t v788 = 1;
        // pto: %537
        ;
        const int64_t v789 = 1;
        // pto: %537
        ;
        int64_t v790 = v758 * v43;
        // pto: %537
        ;
        int64_t v791 = v789 * v790;
        // pto: %537
        ;
        pto::Shape<1, 1, 1, -1, 4096> v792 = pto::Shape<1, 1, 1, -1, 4096>(v787, v788, v789, v758, v41);
        // pto: %537
        ;
        pto::Stride<-1, -1, -1, -1, -1> v793 = pto::Stride<-1, -1, -1, -1, -1>(v788 * v791, v791, v790, v43, v36);
        // pto: %537
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v794 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v786 + (v785 + v749 * v43 + v42 * v36), v792, v793);
        TLOAD(v783, v794);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %41
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v795 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %41
        ;
        uint64_t v796 = (uint64_t) v33;
        TASSIGN(v795, v796);
        // pto: %548
        ;
        const int64_t v797 = 0;
        // pto: %548
        ;
        __gm__ bfloat16_t* v798 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %548
        ;
        const int64_t v799 = 1;
        // pto: %548
        ;
        const int64_t v800 = 1;
        // pto: %548
        ;
        const int64_t v801 = 1;
        // pto: %548
        ;
        int64_t v802 = v758 * v43;
        // pto: %548
        ;
        int64_t v803 = v801 * v802;
        // pto: %548
        ;
        pto::Shape<1, 1, 1, -1, 4096> v804 = pto::Shape<1, 1, 1, -1, 4096>(v799, v800, v801, v758, v41);
        // pto: %548
        ;
        pto::Stride<-1, -1, -1, -1, -1> v805 = pto::Stride<-1, -1, -1, -1, -1>(v800 * v803, v803, v802, v43, v36);
        // pto: %548
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v806 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v798 + (v797 + v749 * v43 + v73 * v36), v804, v805);
        TLOAD(v795, v806);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        // pto: %42
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v807 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %42
        ;
        uint64_t v808 = (uint64_t) v24;
        TASSIGN(v807, v808);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v809 = RoundMode::CAST_ROUND;
        SaturationMode v810 = SaturationMode::ON;
        TCVT(v807, v747, v809, v810);
        // pto: %43
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v811 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %43
        ;
        uint64_t v812 = (uint64_t) v32;
        TASSIGN(v811, v812);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v813 = RoundMode::CAST_ROUND;
        SaturationMode v814 = SaturationMode::ON;
        TCVT(v811, v759, v813, v814);
        // pto: %44
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v815 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %44
        ;
        uint64_t v816 = (uint64_t) v25;
        TASSIGN(v815, v816);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v817 = RoundMode::CAST_ROUND;
        SaturationMode v818 = SaturationMode::ON;
        TCVT(v815, v771, v817, v818);
        // pto: %45
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v819 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %45
        ;
        uint64_t v820 = (uint64_t) v30;
        TASSIGN(v819, v820);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        RoundMode v821 = RoundMode::CAST_ROUND;
        SaturationMode v822 = SaturationMode::ON;
        TCVT(v819, v783, v821, v822);
        // pto: %46
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v823 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %46
        ;
        uint64_t v824 = (uint64_t) v26;
        TASSIGN(v823, v824);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        RoundMode v825 = RoundMode::CAST_ROUND;
        SaturationMode v826 = SaturationMode::ON;
        TCVT(v823, v795, v825, v826);
        // pto: %47
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v827 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %47
        ;
        uint64_t v828 = (uint64_t) v33;
        TASSIGN(v827, v828);
        pipe_barrier(PIPE_V);
        TMULS(v827, v807, v726);
        // pto: %48
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v829 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %48
        ;
        uint64_t v830 = (uint64_t) v31;
        TASSIGN(v829, v830);
        TMULS(v829, v811, v728);
        // pto: %49
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v831 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %49
        ;
        uint64_t v832 = (uint64_t) v33;
        TASSIGN(v831, v832);
        pipe_barrier(PIPE_V);
        TADD(v831, v827, v829);
        // pto: %50
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v833 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %50
        ;
        uint64_t v834 = (uint64_t) v31;
        TASSIGN(v833, v834);
        pipe_barrier(PIPE_V);
        TMULS(v833, v815, v729);
        // pto: %51
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v835 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %51
        ;
        uint64_t v836 = (uint64_t) v33;
        TASSIGN(v835, v836);
        pipe_barrier(PIPE_V);
        TADD(v835, v831, v833);
        // pto: %52
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v837 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %52
        ;
        uint64_t v838 = (uint64_t) v31;
        TASSIGN(v837, v838);
        pipe_barrier(PIPE_V);
        TMULS(v837, v819, v730);
        // pto: %53
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v839 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %53
        ;
        uint64_t v840 = (uint64_t) v33;
        TASSIGN(v839, v840);
        pipe_barrier(PIPE_V);
        TADD(v839, v835, v837);
        // pto: %54
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v841 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %54
        ;
        uint64_t v842 = (uint64_t) v31;
        TASSIGN(v841, v842);
        pipe_barrier(PIPE_V);
        TMULS(v841, v823, v731);
        // pto: %55
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v843 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %55
        ;
        uint64_t v844 = (uint64_t) v33;
        TASSIGN(v843, v844);
        pipe_barrier(PIPE_V);
        TADD(v843, v839, v841);
        // pto: %56
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v845 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %56
        ;
        uint64_t v846 = (uint64_t) v34;
        TASSIGN(v845, v846);
        pipe_barrier(PIPE_V);
        RoundMode v847 = RoundMode::CAST_RINT;
        SaturationMode v848 = SaturationMode::ON;
        TCVT(v845, v843, v847, v848);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v845.SetValidShape(v36, v41);
        // pto: %58
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v849 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %58
        ;
        uint64_t v850 = (uint64_t) v33;
        TASSIGN(v849, v850);
        pipe_barrier(PIPE_V);
        TMULS(v849, v807, v732);
        // pto: %59
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v851 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %59
        ;
        uint64_t v852 = (uint64_t) v31;
        TASSIGN(v851, v852);
        TMULS(v851, v811, v733);
        // pto: %60
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v853 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %60
        ;
        uint64_t v854 = (uint64_t) v33;
        TASSIGN(v853, v854);
        pipe_barrier(PIPE_V);
        TADD(v853, v849, v851);
        // pto: %61
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v855 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %61
        ;
        uint64_t v856 = (uint64_t) v31;
        TASSIGN(v855, v856);
        pipe_barrier(PIPE_V);
        TMULS(v855, v815, v734);
        // pto: %62
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v857 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %62
        ;
        uint64_t v858 = (uint64_t) v33;
        TASSIGN(v857, v858);
        pipe_barrier(PIPE_V);
        TADD(v857, v853, v855);
        // pto: %63
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v859 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %63
        ;
        uint64_t v860 = (uint64_t) v31;
        TASSIGN(v859, v860);
        pipe_barrier(PIPE_V);
        TMULS(v859, v819, v735);
        // pto: %64
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v861 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %64
        ;
        uint64_t v862 = (uint64_t) v33;
        TASSIGN(v861, v862);
        pipe_barrier(PIPE_V);
        TADD(v861, v857, v859);
        // pto: %65
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v863 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %65
        ;
        uint64_t v864 = (uint64_t) v31;
        TASSIGN(v863, v864);
        pipe_barrier(PIPE_V);
        TMULS(v863, v823, v736);
        // pto: %66
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v865 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %66
        ;
        uint64_t v866 = (uint64_t) v33;
        TASSIGN(v865, v866);
        pipe_barrier(PIPE_V);
        TADD(v865, v861, v863);
        // pto: %67
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v867 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %67
        ;
        uint64_t v868 = (uint64_t) v35;
        TASSIGN(v867, v868);
        pipe_barrier(PIPE_V);
        RoundMode v869 = RoundMode::CAST_RINT;
        SaturationMode v870 = SaturationMode::ON;
        TCVT(v867, v865, v869, v870);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        v867.SetValidShape(v36, v41);
        // pto: %69
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v871 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %69
        ;
        uint64_t v872 = (uint64_t) v33;
        TASSIGN(v871, v872);
        pipe_barrier(PIPE_V);
        TMULS(v871, v807, v737);
        // pto: %70
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v873 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %70
        ;
        uint64_t v874 = (uint64_t) v31;
        TASSIGN(v873, v874);
        TMULS(v873, v811, v738);
        // pto: %71
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v875 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %71
        ;
        uint64_t v876 = (uint64_t) v33;
        TASSIGN(v875, v876);
        pipe_barrier(PIPE_V);
        TADD(v875, v871, v873);
        // pto: %72
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v877 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %72
        ;
        uint64_t v878 = (uint64_t) v31;
        TASSIGN(v877, v878);
        pipe_barrier(PIPE_V);
        TMULS(v877, v815, v739);
        // pto: %73
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v879 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %73
        ;
        uint64_t v880 = (uint64_t) v33;
        TASSIGN(v879, v880);
        pipe_barrier(PIPE_V);
        TADD(v879, v875, v877);
        // pto: %74
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v881 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %74
        ;
        uint64_t v882 = (uint64_t) v31;
        TASSIGN(v881, v882);
        pipe_barrier(PIPE_V);
        TMULS(v881, v819, v740);
        // pto: %75
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v883 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %75
        ;
        uint64_t v884 = (uint64_t) v33;
        TASSIGN(v883, v884);
        pipe_barrier(PIPE_V);
        TADD(v883, v879, v881);
        // pto: %76
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v885 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %76
        ;
        uint64_t v886 = (uint64_t) v31;
        TASSIGN(v885, v886);
        pipe_barrier(PIPE_V);
        TMULS(v885, v823, v741);
        // pto: %77
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v887 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %77
        ;
        uint64_t v888 = (uint64_t) v33;
        TASSIGN(v887, v888);
        pipe_barrier(PIPE_V);
        TADD(v887, v883, v885);
        // pto: %78
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v889 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %78
        ;
        uint64_t v890 = (uint64_t) v33;
        TASSIGN(v889, v890);
        pipe_barrier(PIPE_V);
        RoundMode v891 = RoundMode::CAST_RINT;
        SaturationMode v892 = SaturationMode::ON;
        TCVT(v889, v887, v891, v892);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        v889.SetValidShape(v36, v41);
        // pto: %80
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v893 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %80
        ;
        uint64_t v894 = (uint64_t) v24;
        TASSIGN(v893, v894);
        TMULS(v893, v807, v742);
        // pto: %81
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v895 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %81
        ;
        uint64_t v896 = (uint64_t) v32;
        TASSIGN(v895, v896);
        TMULS(v895, v811, v743);
        // pto: %82
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v897 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %82
        ;
        uint64_t v898 = (uint64_t) v24;
        TASSIGN(v897, v898);
        pipe_barrier(PIPE_V);
        TADD(v897, v893, v895);
        // pto: %83
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v899 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %83
        ;
        uint64_t v900 = (uint64_t) v32;
        TASSIGN(v899, v900);
        pipe_barrier(PIPE_V);
        TMULS(v899, v815, v744);
        // pto: %84
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v901 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %84
        ;
        uint64_t v902 = (uint64_t) v24;
        TASSIGN(v901, v902);
        pipe_barrier(PIPE_V);
        TADD(v901, v897, v899);
        // pto: %85
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v903 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %85
        ;
        uint64_t v904 = (uint64_t) v32;
        TASSIGN(v903, v904);
        pipe_barrier(PIPE_V);
        TMULS(v903, v819, v745);
        // pto: %86
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v905 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %86
        ;
        uint64_t v906 = (uint64_t) v24;
        TASSIGN(v905, v906);
        pipe_barrier(PIPE_V);
        TADD(v905, v901, v903);
        // pto: %87
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v907 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v758, v41);
        // pto: %87
        ;
        uint64_t v908 = (uint64_t) v32;
        TASSIGN(v907, v908);
        pipe_barrier(PIPE_V);
        TMULS(v907, v823, v746);
        // pto: %88
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v909 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %88
        ;
        uint64_t v910 = (uint64_t) v24;
        TASSIGN(v909, v910);
        pipe_barrier(PIPE_V);
        TADD(v909, v905, v907);
        // pto: %89
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v911 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %89
        ;
        uint64_t v912 = (uint64_t) v24;
        TASSIGN(v911, v912);
        pipe_barrier(PIPE_V);
        RoundMode v913 = RoundMode::CAST_RINT;
        SaturationMode v914 = SaturationMode::ON;
        TCVT(v911, v909, v913, v914);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        v911.SetValidShape(v36, v41);
        // pto: %y_flat__phi_v9_pview
        ;
        __gm__ bfloat16_t* v915 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %y_flat__phi_v9_pview
        ;
        const int64_t v916 = 0;
        // pto: %y_flat__phi_v9_pview
        ;
        const int64_t v917 = 16384;
        // pto: %y_flat__phi_v9_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v918 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__phi_v9_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v919 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__phi_v9_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v920 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v915 + (v916 + v749 * v917), v918, v919);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v920, v845);
        // pto: %635
        ;
        __gm__ bfloat16_t* v921 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %635
        ;
        const int64_t v922 = 4096;
        // pto: %635
        ;
        const int64_t v923 = 16384;
        // pto: %635
        ;
        pto::Shape<1, 1, 1, 1, 4096> v924 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %635
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v925 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %635
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v926 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v921 + (v922 + v749 * v923), v924, v925);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v926, v867);
        // pto: %639
        ;
        __gm__ bfloat16_t* v927 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %639
        ;
        const int64_t v928 = 8192;
        // pto: %639
        ;
        const int64_t v929 = 16384;
        // pto: %639
        ;
        pto::Shape<1, 1, 1, 1, 4096> v930 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %639
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v931 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %639
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v932 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v927 + (v928 + v749 * v929), v930, v931);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v932, v889);
        // pto: %643
        ;
        __gm__ bfloat16_t* v933 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %643
        ;
        const int64_t v934 = 12288;
        // pto: %643
        ;
        const int64_t v935 = 16384;
        // pto: %643
        ;
        pto::Shape<1, 1, 1, 1, 4096> v936 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %643
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v937 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %643
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v938 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v933 + (v934 + v749 * v935), v936, v937);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        TSTORE(v938, v911);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
    // pto: %644, %645, %646
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
    if ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v507 - (uint64_t) v508) + (uint64_t) v44) == v36) {
      // pto: %647
      ;
      if (v508 < v17) {
        // pto: %91
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v939 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %91
        ;
        uint64_t v940 = (uint64_t) v32;
        TASSIGN(v939, v940);
        // pto: %648
        ;
        int64_t v941 = v508 < v48 ? v48 : v508;
        // pto: %649
        ;
        __gm__ bfloat16_t* v942 = PTOAS__GLOBAL_TENSOR_DATA(v120);
        // pto: %649
        ;
        const int64_t v943 = 0;
        // pto: %649
        ;
        const int64_t v944 = 4096;
        // pto: %649
        ;
        pto::Shape<1, 1, 1, 1, 4096> v945 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %649
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v946 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %649
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v947 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v942 + (v943 + v941 * v944), v945, v946);
        TLOAD(v939, v947);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %92
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v948 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %92
        ;
        uint64_t v949 = (uint64_t) v24;
        TASSIGN(v948, v949);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v950 = RoundMode::CAST_ROUND;
        SaturationMode v951 = SaturationMode::ON;
        TCVT(v948, v939, v950, v951);
        // pto: %650
        ;
        int64_t v952 = (int64_t) ((uint64_t) v17 - (uint64_t) v508);
        // pto: %651
        ;
        int64_t v953 = v952 < v48 ? v48 : v952;
        // pto: %652
        ;
        int64_t v954 = v953 < v36 ? v953 : v36;
        // pto: %93
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v955 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %93
        ;
        uint64_t v956 = (uint64_t) v25;
        TASSIGN(v955, v956);
        // pto: %657
        ;
        const int64_t v957 = 0;
        // pto: %657
        ;
        __gm__ bfloat16_t* v958 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %657
        ;
        const int64_t v959 = 1;
        // pto: %657
        ;
        const int64_t v960 = 1;
        // pto: %657
        ;
        const int64_t v961 = 1;
        // pto: %657
        ;
        int64_t v962 = v954 * v43;
        // pto: %657
        ;
        int64_t v963 = v961 * v962;
        // pto: %657
        ;
        pto::Shape<1, 1, 1, -1, 4096> v964 = pto::Shape<1, 1, 1, -1, 4096>(v959, v960, v961, v954, v41);
        // pto: %657
        ;
        pto::Stride<-1, -1, -1, -1, -1> v965 = pto::Stride<-1, -1, -1, -1, -1>(v960 * v963, v963, v962, v43, v36);
        // pto: %657
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v966 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v958 + (v957 + v941 * v43 + v48 * v36), v964, v965);
        TLOAD(v955, v966);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %94
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v967 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %94
        ;
        uint64_t v968 = (uint64_t) v32;
        TASSIGN(v967, v968);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v969 = RoundMode::CAST_ROUND;
        SaturationMode v970 = SaturationMode::ON;
        TCVT(v967, v955, v969, v970);
        // pto: %95
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v971 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %95
        ;
        uint64_t v972 = (uint64_t) v30;
        TASSIGN(v971, v972);
        // pto: %668
        ;
        const int64_t v973 = 0;
        // pto: %668
        ;
        __gm__ bfloat16_t* v974 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %668
        ;
        const int64_t v975 = 1;
        // pto: %668
        ;
        const int64_t v976 = 1;
        // pto: %668
        ;
        const int64_t v977 = 1;
        // pto: %668
        ;
        int64_t v978 = v954 * v43;
        // pto: %668
        ;
        int64_t v979 = v977 * v978;
        // pto: %668
        ;
        pto::Shape<1, 1, 1, -1, 4096> v980 = pto::Shape<1, 1, 1, -1, 4096>(v975, v976, v977, v954, v41);
        // pto: %668
        ;
        pto::Stride<-1, -1, -1, -1, -1> v981 = pto::Stride<-1, -1, -1, -1, -1>(v976 * v979, v979, v978, v43, v36);
        // pto: %668
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v982 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v974 + (v973 + v941 * v43 + v41 * v36), v980, v981);
        TLOAD(v971, v982);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %96
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v983 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %96
        ;
        uint64_t v984 = (uint64_t) v25;
        TASSIGN(v983, v984);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v985 = RoundMode::CAST_ROUND;
        SaturationMode v986 = SaturationMode::ON;
        TCVT(v983, v971, v985, v986);
        // pto: %97
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v987 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %97
        ;
        uint64_t v988 = (uint64_t) v26;
        TASSIGN(v987, v988);
        // pto: %679
        ;
        const int64_t v989 = 0;
        // pto: %679
        ;
        __gm__ bfloat16_t* v990 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %679
        ;
        const int64_t v991 = 1;
        // pto: %679
        ;
        const int64_t v992 = 1;
        // pto: %679
        ;
        const int64_t v993 = 1;
        // pto: %679
        ;
        int64_t v994 = v954 * v43;
        // pto: %679
        ;
        int64_t v995 = v993 * v994;
        // pto: %679
        ;
        pto::Shape<1, 1, 1, -1, 4096> v996 = pto::Shape<1, 1, 1, -1, 4096>(v991, v992, v993, v954, v41);
        // pto: %679
        ;
        pto::Stride<-1, -1, -1, -1, -1> v997 = pto::Stride<-1, -1, -1, -1, -1>(v992 * v995, v995, v994, v43, v36);
        // pto: %679
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v998 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v990 + (v989 + v941 * v43 + v42 * v36), v996, v997);
        TLOAD(v987, v998);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %98
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v999 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %98
        ;
        uint64_t v1000 = (uint64_t) v30;
        TASSIGN(v999, v1000);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v1001 = RoundMode::CAST_ROUND;
        SaturationMode v1002 = SaturationMode::ON;
        TCVT(v999, v987, v1001, v1002);
        // pto: %99
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1003 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %99
        ;
        uint64_t v1004 = (uint64_t) v33;
        TASSIGN(v1003, v1004);
        // pto: %690
        ;
        const int64_t v1005 = 0;
        // pto: %690
        ;
        __gm__ bfloat16_t* v1006 = PTOAS__GLOBAL_TENSOR_DATA(v129);
        // pto: %690
        ;
        const int64_t v1007 = 1;
        // pto: %690
        ;
        const int64_t v1008 = 1;
        // pto: %690
        ;
        const int64_t v1009 = 1;
        // pto: %690
        ;
        int64_t v1010 = v954 * v43;
        // pto: %690
        ;
        int64_t v1011 = v1009 * v1010;
        // pto: %690
        ;
        pto::Shape<1, 1, 1, -1, 4096> v1012 = pto::Shape<1, 1, 1, -1, 4096>(v1007, v1008, v1009, v954, v41);
        // pto: %690
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1013 = pto::Stride<-1, -1, -1, -1, -1>(v1008 * v1011, v1011, v1010, v43, v36);
        // pto: %690
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1014 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1006 + (v1005 + v941 * v43 + v73 * v36), v1012, v1013);
        TLOAD(v1003, v1014);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %100
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1015 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %100
        ;
        uint64_t v1016 = (uint64_t) v26;
        TASSIGN(v1015, v1016);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        pipe_barrier(PIPE_V);
        RoundMode v1017 = RoundMode::CAST_ROUND;
        SaturationMode v1018 = SaturationMode::ON;
        TCVT(v1015, v1003, v1017, v1018);
        // pto: %695
        ;
        int64_t v1019 = (int64_t) ((uint64_t) v508 * (uint64_t) v44);
        // pto: %694
        ;
        float v1020 = (v11)[v1019];
        // pto: %101
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1021 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %101
        ;
        uint64_t v1022 = (uint64_t) v33;
        TASSIGN(v1021, v1022);
        pipe_barrier(PIPE_V);
        TMULS(v1021, v948, v1020);
        // pto: %698
        ;
        int64_t v1023 = (int64_t) ((uint64_t) v508 * (uint64_t) v38);
        // pto: %697
        ;
        float v1024 = (v12)[v1023];
        // pto: %102
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1025 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %102
        ;
        uint64_t v1026 = (uint64_t) v31;
        TASSIGN(v1025, v1026);
        TMULS(v1025, v967, v1024);
        // pto: %103
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1027 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %103
        ;
        uint64_t v1028 = (uint64_t) v33;
        TASSIGN(v1027, v1028);
        pipe_barrier(PIPE_V);
        TADD(v1027, v1021, v1025);
        // pto: %705, %703
        ;
        float v1029 = (v12)[(int64_t) ((uint64_t) v1023 + (uint64_t) v44)];
        // pto: %104
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1030 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %104
        ;
        uint64_t v1031 = (uint64_t) v31;
        TASSIGN(v1030, v1031);
        pipe_barrier(PIPE_V);
        TMULS(v1030, v983, v1029);
        // pto: %105
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1032 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %105
        ;
        uint64_t v1033 = (uint64_t) v33;
        TASSIGN(v1032, v1033);
        pipe_barrier(PIPE_V);
        TADD(v1032, v1027, v1030);
        // pto: %711, %709
        ;
        float v1034 = (v12)[(int64_t) ((uint64_t) v1023 + (uint64_t) v37)];
        // pto: %106
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1035 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %106
        ;
        uint64_t v1036 = (uint64_t) v31;
        TASSIGN(v1035, v1036);
        pipe_barrier(PIPE_V);
        TMULS(v1035, v999, v1034);
        // pto: %107
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1037 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %107
        ;
        uint64_t v1038 = (uint64_t) v33;
        TASSIGN(v1037, v1038);
        pipe_barrier(PIPE_V);
        TADD(v1037, v1032, v1035);
        // pto: %717, %715
        ;
        float v1039 = (v12)[(int64_t) ((uint64_t) v1023 + (uint64_t) v65)];
        // pto: %108
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1040 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %108
        ;
        uint64_t v1041 = (uint64_t) v31;
        TASSIGN(v1040, v1041);
        pipe_barrier(PIPE_V);
        TMULS(v1040, v1015, v1039);
        // pto: %109
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1042 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %109
        ;
        uint64_t v1043 = (uint64_t) v33;
        TASSIGN(v1042, v1043);
        pipe_barrier(PIPE_V);
        TADD(v1042, v1037, v1040);
        // pto: %110
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1044 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %110
        ;
        uint64_t v1045 = (uint64_t) v33;
        TASSIGN(v1044, v1045);
        pipe_barrier(PIPE_V);
        RoundMode v1046 = RoundMode::CAST_RINT;
        SaturationMode v1047 = SaturationMode::ON;
        TCVT(v1044, v1042, v1046, v1047);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1044.SetValidShape(v36, v41);
        // pto: %y_flat__rv_v4_main_pview
        ;
        __gm__ bfloat16_t* v1048 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %y_flat__rv_v4_main_pview
        ;
        const int64_t v1049 = 0;
        // pto: %y_flat__rv_v4_main_pview
        ;
        const int64_t v1050 = 16384;
        // pto: %y_flat__rv_v4_main_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1051 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %y_flat__rv_v4_main_pview
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1052 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %y_flat__rv_v4_main_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1053 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1048 + (v1049 + v941 * v1050), v1051, v1052);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1053, v1044);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        // pto: %725, %723
        ;
        float v1054 = (v11)[(int64_t) ((uint64_t) v1019 + (uint64_t) v36)];
        // pto: %112
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1055 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %112
        ;
        uint64_t v1056 = (uint64_t) v33;
        TASSIGN(v1055, v1056);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        TMULS(v1055, v948, v1054);
        // pto: %728, %726
        ;
        float v1057 = (v12)[(int64_t) ((uint64_t) v1023 + (uint64_t) v36)];
        // pto: %113
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1058 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %113
        ;
        uint64_t v1059 = (uint64_t) v31;
        TASSIGN(v1058, v1059);
        TMULS(v1058, v967, v1057);
        // pto: %114
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1060 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %114
        ;
        uint64_t v1061 = (uint64_t) v33;
        TASSIGN(v1060, v1061);
        pipe_barrier(PIPE_V);
        TADD(v1060, v1055, v1058);
        // pto: %734, %732
        ;
        float v1062 = (v12)[(int64_t) ((uint64_t) v1023 + (uint64_t) v66)];
        // pto: %115
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1063 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %115
        ;
        uint64_t v1064 = (uint64_t) v31;
        TASSIGN(v1063, v1064);
        pipe_barrier(PIPE_V);
        TMULS(v1063, v983, v1062);
        // pto: %116
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1065 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %116
        ;
        uint64_t v1066 = (uint64_t) v33;
        TASSIGN(v1065, v1066);
        pipe_barrier(PIPE_V);
        TADD(v1065, v1060, v1063);
        // pto: %740, %738
        ;
        float v1067 = (v12)[(int64_t) ((uint64_t) v1023 + (uint64_t) v67)];
        // pto: %117
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1068 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %117
        ;
        uint64_t v1069 = (uint64_t) v31;
        TASSIGN(v1068, v1069);
        pipe_barrier(PIPE_V);
        TMULS(v1068, v999, v1067);
        // pto: %118
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1070 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %118
        ;
        uint64_t v1071 = (uint64_t) v33;
        TASSIGN(v1070, v1071);
        pipe_barrier(PIPE_V);
        TADD(v1070, v1065, v1068);
        // pto: %746, %744
        ;
        float v1072 = (v12)[(int64_t) ((uint64_t) v1023 + (uint64_t) v68)];
        // pto: %119
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1073 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %119
        ;
        uint64_t v1074 = (uint64_t) v31;
        TASSIGN(v1073, v1074);
        pipe_barrier(PIPE_V);
        TMULS(v1073, v1015, v1072);
        // pto: %120
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1075 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %120
        ;
        uint64_t v1076 = (uint64_t) v33;
        TASSIGN(v1075, v1076);
        pipe_barrier(PIPE_V);
        TADD(v1075, v1070, v1073);
        // pto: %121
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1077 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %121
        ;
        uint64_t v1078 = (uint64_t) v33;
        TASSIGN(v1077, v1078);
        pipe_barrier(PIPE_V);
        RoundMode v1079 = RoundMode::CAST_RINT;
        SaturationMode v1080 = SaturationMode::ON;
        TCVT(v1077, v1075, v1079, v1080);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1077.SetValidShape(v36, v41);
        // pto: %752
        ;
        __gm__ bfloat16_t* v1081 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %752
        ;
        const int64_t v1082 = 4096;
        // pto: %752
        ;
        const int64_t v1083 = 16384;
        // pto: %752
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1084 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %752
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1085 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %752
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1086 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1081 + (v1082 + v941 * v1083), v1084, v1085);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1086, v1077);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        // pto: %755, %753
        ;
        float v1087 = (v11)[(int64_t) ((uint64_t) v1019 + (uint64_t) v46)];
        // pto: %123
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1088 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %123
        ;
        uint64_t v1089 = (uint64_t) v33;
        TASSIGN(v1088, v1089);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        TMULS(v1088, v948, v1087);
        // pto: %758, %756
        ;
        float v1090 = (v12)[(int64_t) ((uint64_t) v1023 + (uint64_t) v46)];
        // pto: %124
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1091 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %124
        ;
        uint64_t v1092 = (uint64_t) v31;
        TASSIGN(v1091, v1092);
        TMULS(v1091, v967, v1090);
        // pto: %125
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1093 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %125
        ;
        uint64_t v1094 = (uint64_t) v33;
        TASSIGN(v1093, v1094);
        pipe_barrier(PIPE_V);
        TADD(v1093, v1088, v1091);
        // pto: %764, %762
        ;
        float v1095 = (v12)[(int64_t) ((uint64_t) v1023 + (uint64_t) v69)];
        // pto: %126
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1096 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %126
        ;
        uint64_t v1097 = (uint64_t) v31;
        TASSIGN(v1096, v1097);
        pipe_barrier(PIPE_V);
        TMULS(v1096, v983, v1095);
        // pto: %127
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1098 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %127
        ;
        uint64_t v1099 = (uint64_t) v33;
        TASSIGN(v1098, v1099);
        pipe_barrier(PIPE_V);
        TADD(v1098, v1093, v1096);
        // pto: %770, %768
        ;
        float v1100 = (v12)[(int64_t) ((uint64_t) v1023 + (uint64_t) v70)];
        // pto: %128
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1101 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %128
        ;
        uint64_t v1102 = (uint64_t) v31;
        TASSIGN(v1101, v1102);
        pipe_barrier(PIPE_V);
        TMULS(v1101, v999, v1100);
        // pto: %129
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1103 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %129
        ;
        uint64_t v1104 = (uint64_t) v33;
        TASSIGN(v1103, v1104);
        pipe_barrier(PIPE_V);
        TADD(v1103, v1098, v1101);
        // pto: %776, %774
        ;
        float v1105 = (v12)[(int64_t) ((uint64_t) v1023 + (uint64_t) v71)];
        // pto: %130
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1106 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %130
        ;
        uint64_t v1107 = (uint64_t) v31;
        TASSIGN(v1106, v1107);
        pipe_barrier(PIPE_V);
        TMULS(v1106, v1015, v1105);
        // pto: %131
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1108 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %131
        ;
        uint64_t v1109 = (uint64_t) v33;
        TASSIGN(v1108, v1109);
        pipe_barrier(PIPE_V);
        TADD(v1108, v1103, v1106);
        // pto: %132
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1110 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %132
        ;
        uint64_t v1111 = (uint64_t) v33;
        TASSIGN(v1110, v1111);
        pipe_barrier(PIPE_V);
        RoundMode v1112 = RoundMode::CAST_RINT;
        SaturationMode v1113 = SaturationMode::ON;
        TCVT(v1110, v1108, v1112, v1113);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1110.SetValidShape(v36, v41);
        // pto: %782
        ;
        __gm__ bfloat16_t* v1114 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %782
        ;
        const int64_t v1115 = 8192;
        // pto: %782
        ;
        const int64_t v1116 = 16384;
        // pto: %782
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1117 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %782
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1118 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %782
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1119 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1114 + (v1115 + v941 * v1116), v1117, v1118);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1119, v1110);
        // pto: %785, %783
        ;
        float v1120 = (v11)[(int64_t) ((uint64_t) v1019 + (uint64_t) v64)];
        // pto: %134
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1121 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %134
        ;
        uint64_t v1122 = (uint64_t) v24;
        TASSIGN(v1121, v1122);
        TMULS(v1121, v948, v1120);
        // pto: %788, %786
        ;
        float v1123 = (v12)[(int64_t) ((uint64_t) v1023 + (uint64_t) v64)];
        // pto: %135
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1124 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %135
        ;
        uint64_t v1125 = (uint64_t) v32;
        TASSIGN(v1124, v1125);
        TMULS(v1124, v967, v1123);
        // pto: %136
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1126 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %136
        ;
        uint64_t v1127 = (uint64_t) v24;
        TASSIGN(v1126, v1127);
        pipe_barrier(PIPE_V);
        TADD(v1126, v1121, v1124);
        // pto: %794, %792
        ;
        float v1128 = (v12)[(int64_t) ((uint64_t) v1023 + (uint64_t) v54)];
        // pto: %137
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1129 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %137
        ;
        uint64_t v1130 = (uint64_t) v32;
        TASSIGN(v1129, v1130);
        pipe_barrier(PIPE_V);
        TMULS(v1129, v983, v1128);
        // pto: %138
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1131 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %138
        ;
        uint64_t v1132 = (uint64_t) v24;
        TASSIGN(v1131, v1132);
        pipe_barrier(PIPE_V);
        TADD(v1131, v1126, v1129);
        // pto: %800, %798
        ;
        float v1133 = (v12)[(int64_t) ((uint64_t) v1023 + (uint64_t) v72)];
        // pto: %139
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1134 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %139
        ;
        uint64_t v1135 = (uint64_t) v32;
        TASSIGN(v1134, v1135);
        pipe_barrier(PIPE_V);
        TMULS(v1134, v999, v1133);
        // pto: %140
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1136 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %140
        ;
        uint64_t v1137 = (uint64_t) v24;
        TASSIGN(v1136, v1137);
        pipe_barrier(PIPE_V);
        TADD(v1136, v1131, v1134);
        // pto: %806, %804
        ;
        float v1138 = (v12)[(int64_t) ((uint64_t) v1023 + (uint64_t) v49)];
        // pto: %141
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1139 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v954, v41);
        // pto: %141
        ;
        uint64_t v1140 = (uint64_t) v32;
        TASSIGN(v1139, v1140);
        pipe_barrier(PIPE_V);
        TMULS(v1139, v1015, v1138);
        // pto: %142
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1141 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %142
        ;
        uint64_t v1142 = (uint64_t) v24;
        TASSIGN(v1141, v1142);
        pipe_barrier(PIPE_V);
        TADD(v1141, v1136, v1139);
        // pto: %143
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1143 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v41);
        // pto: %143
        ;
        uint64_t v1144 = (uint64_t) v24;
        TASSIGN(v1143, v1144);
        pipe_barrier(PIPE_V);
        RoundMode v1145 = RoundMode::CAST_RINT;
        SaturationMode v1146 = SaturationMode::ON;
        TCVT(v1143, v1141, v1145, v1146);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1143.SetValidShape(v36, v41);
        // pto: %812
        ;
        __gm__ bfloat16_t* v1147 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %812
        ;
        const int64_t v1148 = 12288;
        // pto: %812
        ;
        const int64_t v1149 = 16384;
        // pto: %812
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1150 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %812
        ;
        pto::Stride<16384, 16384, 16384, 16384, 1> v1151 = pto::Stride<16384, 16384, 16384, 16384, 1>();
        // pto: %812
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v1152 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v1147 + (v1148 + v941 * v1149), v1150, v1151);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v1152, v1143);
      };
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  pipe_barrier(PIPE_ALL);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}