# QA168修复版八档L1准备独立审查

**PASS，仅准备与源身份审查，未发现设备前阻断。**

工具manifest全部匹配。绑定的3399源、77运行文件、43 base源、最终QA ea30与canonical编译aee6
均与已验收v2收据一致。移除旧SPMD overlay注入，四个实际模块必须来自新snapshot，
126/168常量及QA文件SHA强校验；没有降低为仅commit标签一致。

独立按源码切片核对：从NativeHalf开始的全部fixture/Native与PTO调用、A/B/ABA八边界、
真实FULL/raw、毒化恢复、guards、readonly、3次warm及5窗×1回放、L1时间计算均与旧助手逐字节相同，
唯一例外是结果中数学版本标签。ragged_fixture和preflight也与旧助手字节相同。没有改数学/SDK/编译器。

新run固定canonical SOURCE_ROOT，取消SPMD_EXPERIMENT，B28_ACTIVE=0并清理whole trace/probe字段。
source_identity拒绝canonical whole-helper目录污染sys.path/sitecustomize，并核实际import来源。
预检应在无NPU初始化下通过；父线程已报告实际成功，本审查未重复远端命令。

按CHECKLIST先128K/B28，再其余七档，首差停止，不混用旧失败版L1。
run.sh只运行一个case，内层750秒；外780秒由实际task-submit提交参数保障，
不是该脚本内部自行提交/排程。后续需按每项实际终态与raw收据复核。

口径保持完整PTO incore earliest→latest的L1跨度（含内部等待），不含所有CPU/Native producer外部耗时；
不是端到端graph延迟、Native性能或与用户截图的受控速度收益。
本轮仅全S6，不能增加ragged/整模型token资格。原结果不修改、新数据按新源身份单独保存。

本审查仅本地读源码/AST与SHA，无远端、NPU任务或源码修改。详细绑定见同名JSON。
