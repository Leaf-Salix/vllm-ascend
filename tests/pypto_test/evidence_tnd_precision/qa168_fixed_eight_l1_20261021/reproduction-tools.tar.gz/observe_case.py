"""One read-only observation of a submitted task; no background scheduler."""
import json
import re
import shlex
import subprocess
import sys
from datetime import datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parent
case=sys.argv[1]
assert re.fullmatch(r'fixed-l1-(8k|128k)-b[0-9]+-v1',case)
row=json.loads((ROOT/(case+'-submission.json')).read_text())
task=row['task_id'];assert re.fullmatch(r'task_[0-9_]+',task)
remote='/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/eight-l1-fixed-20261021-codex/results/'
code="import json;from pathlib import Path;p=Path("+repr(remote+case+'/result.json')+");r=json.loads(p.read_text()) if p.exists() else {};print(json.dumps({k:r.get(k) for k in ('complete','pass','error','failed_boundaries','timing_executed','l1')}))"
cmd=f'task-submit --status {task}; if test -f {remote}{case}-run.log; then tail -5 {remote}{case}-run.log; fi; python3 -c '+shlex.quote(code)
result=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','pto227',cmd],capture_output=True,text=True,timeout=60)
text=datetime.now().isoformat()+'\n'+result.stdout+result.stderr
with (ROOT/(case+'-observations.log')).open('a') as log:log.write(text+'\n')
print(text)
raise SystemExit(result.returncode)
