# QA168修复版八档L1最终独立复核

**PASS：完整八档、40个原始L1窗口及所有精度/身份门禁通过。**

| 配置 | 五窗中位L1 μs | 精度与身份 |
| --- | ---: | --- |
| 128K/B1 | 681.84 | A/B八边界逐位、canonical身份通过 |
| 128K/B4 | 854.80 | A/B八边界逐位、canonical身份通过 |
| 128K/B8 | 1027.92 | A/B八边界逐位、canonical身份通过 |
| 128K/B16 | 1435.24 | A/B八边界逐位、canonical身份通过 |
| 128K/B24 | 2014.42 | A/B八边界逐位、canonical身份通过 |
| 128K/B28 | 2300.18 | A/B八边界逐位、canonical身份通过 |
| 8K/B16 | 1211.70 | A/B八边界逐位、canonical身份通过 |
| 8K/B32 | 1787.24 | A/B八边界逐位、canonical身份通过 |

最终逐个重读8份原始包，不仅追加摘要：每窗按72core记录的最早incore到最晚end及实际Hz重算，
所有40窗、中位数、records/tasks计数与父recheck一致。B24五窗为
`2013.94,2014.42,2012.30,2030.48,2039.56 us`，中位2014.42。

每档完整77映射/3399/QA ea30/实际编译aee6/helper/无NPU预检身份正确，
实际64根、FULL/raw、TopK毒化、实时ABA、双方33guards、norm/order/readonly通过；A/B各8项外部边界均0差。
七个旧已通过档的Native hidden/positions、initial cache、output/state SHA均与旧原包完全一致，
B28旧首差未计时，不推算旧B28速度变化。

新recheck固定8档集合和唯一性，核实际编译/77/preflight身份；报告、复现和CPU交付器草稿无阻断。
最终交付验证器须等正式8包和工具归档就绪后实跑；此处仅静态审查，不冒称已运行尚未生成的交付包。

口径仍为单C4真实权重+合成hidden/history、全S6、完整PTO核内L1跨度；
不是新整模型token/性能、短queryFULL或混合1～6验收。旧→新是跨任务重测，
截图是非同卡/同工具链受控参照，不能把差额归因于本次算法收益。保留全部样本。

本审查未远端/设备，未修改封存helper。逐窗cycles/Hz/rawSHA及完整包身份见同名JSON。
