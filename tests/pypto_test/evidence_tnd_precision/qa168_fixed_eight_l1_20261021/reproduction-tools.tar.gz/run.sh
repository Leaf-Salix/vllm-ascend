#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
case_name=${1:?}; batch=${2:?}; history=${3:?}
[[ "$case_name" =~ ^[a-z0-9-]+$ && "$batch" =~ ^[0-9]+$ && "$history" =~ ^[0-9]+$ ]]
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/vector-mte2-20261019-codex/full-csa-live-staging-v2/env.sh"
export SOURCE_ROOT="/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/b28-precision-20261021-codex/whole-b28-qa168-v2/snapshot/source"
export PYTHONPATH="$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
unset SPMD_EXPERIMENT
export B28_ACTIVE=0
unset B28_OUTPUT B28_NATIVE ADMISSION_TRACE_DIR ADMISSION_REFERENCE FULL_PROBE_DIR FULL_PROBE_MODE
export TORCH_DEVICE_BACKEND_AUTOLOAD=0
exp="$base/eight-l1-fixed-20261021-codex"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE" PYTHONNOUSERSITE=1 HCCL_DETERMINISTIC=true
# Reuse the validated control cache; no source, runtime or SDK rebuild.
export PYPTO_PROG_BUILD_DIR="$base/spmd-baseline-20261020/build" PYPTO_CACHE_DIR="$base/spmd-baseline-20261020/cache"
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache CMAKE_BUILD_PARALLEL_LEVEL=4
out="$exp/results/$case_name"
test ! -e "$out"
mkdir -p "$exp/results"
python "$exp/preflight.py" > "$out-preflight.json"
export ASCEND_CACHE_PATH="$out-ascend-cache" ASCEND_PROCESS_LOG_PATH="$out-ascend-log" VLLM_CACHE_ROOT="$out-vllm-cache"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out-opp-env")
lengths=6
for ((i=1;i<batch;i++)); do lengths+=,6; done
ccache -s > "$out-ccache.log"
printf 'TASK_RUN_START %s\n' "$(date -Iseconds)"
trap 'printf "TASK_RUN_END %s\n" "$(date -Iseconds)"' EXIT
timeout 750s python "$exp/tools/probe_csa.py" --out "$out" --lengths "$lengths" --layer 4 --history "$history" > "$out-run.log" 2>&1
