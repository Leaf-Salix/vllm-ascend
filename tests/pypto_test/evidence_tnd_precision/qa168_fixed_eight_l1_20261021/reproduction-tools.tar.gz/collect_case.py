"""只归档本实验的文本/原始L1，排除编译树、权重与大型失败tensor。"""
import json
import re
import sys
import tarfile
from pathlib import Path
root=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/eight-l1-fixed-20261021-codex')
case=sys.argv[1]
assert re.fullmatch(r'[a-z0-9-]+',case)
out=root/'results'/case
report=json.loads((out/'result.json').read_text())
archive=root/'results'/(case+'-evidence.tar.gz')
assert not archive.exists()
files=[out/'result.json',out/'first-difference-summary.json']
files += [root/'results'/(case+suffix) for suffix in ['-run.log','-preflight.json','-ccache.log']]
files += list((out/'dfx').rglob('chip_swimlane_records.json'))
with tarfile.open(archive,'w:gz') as tar:
 for p in files:
  if p.is_file():tar.add(p,arcname=str(p.relative_to(root/'results')),recursive=False)
print(json.dumps({'archive':str(archive),'complete':report['complete'],'pass':report['pass'],
                  'l1':report.get('l1'),'error':report.get('error')}))
