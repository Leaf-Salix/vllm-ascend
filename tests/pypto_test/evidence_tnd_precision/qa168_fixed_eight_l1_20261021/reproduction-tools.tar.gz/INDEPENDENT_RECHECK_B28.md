# QA168修复版128K/B28首档独立复核

**PASS：单层S6完整CSA精度门禁及五窗原始L1复核通过；仅一档，不是八档全通过。**

已读原始tar，核actual canonical3399/77（完整77项映射）、QA ea30与编译aee6身份，
实际导入来自新snapshot，whole hook未加载，helper与preflight一致。
A/B各8外部边界diff=0；两臂FULL/raw、TopK毒化、实时A/B/A、33guards及readonly均通过，
实际PTO eligible、64Tensor单根且有真实调用。

五窗独立按全部72core最早incore至最晚end与原频率重算：
`2277.00, 2288.30, 2324.06, 2304.80, 2300.18 us`，median **2300.18 us**。
各窗24AIC+48AIV、单root boundary、无丢边界、记录和任务计数与原report一致。
warm3/5窗×1replay、reset在计时外、depgen关闭；数字与现recheck一致。

该L1为PTO核内跨度，不是全部CPU/CANN producer/end-to-end graph耗时。
未新增整模型token资格；截图仍是非受控参照；旧B28在精度门禁失败且未计时，不能算旧B28加速率。

新recheck对本例重算正确。已落实审查建议：固定8档(case/history/batch)集合与唯一性，
full_matrix必须等于完整预期集合；显式核TopK毒化恢复、33项guards、norm/order/readonly和77项完整映射。
本次独立B28还直接核对canonical编译身份，无B28数值阻断。其余七档仍待实际原包，不能提前算全矩阵通过。

只读本地原数据，无远端/NPU，未修改封存helper。详细cycles/Hz/rawSHA见同名JSON。
