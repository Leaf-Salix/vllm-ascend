"""Submit exactly one approved short case; never auto-retry an unknown outcome."""
import json
import re
import shlex
import subprocess
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REMOTE = '/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/eight-l1-fixed-20261021-codex'
BASE = '/data/pyptouser/yejia'

def command(case, batch, history):
    assert re.fullmatch(r'fixed-l1-(8k|128k)-b[0-9]+-v1', case)
    assert 1 <= batch <= 40 and history in (8192, 131072)
    args = ['task-submit', '--device', 'auto', '--device-num', '1', '--ptoas', '0.63', '--max-time', '780']
    env = {
        'PYTHONNOUSERSITE': '1',
        'ASCEND_HOME_PATH': BASE+'/vllm-cann92-main/env/Ascend/cann-9.2.0-beta.2',
        'PTOAS_ROOT': BASE+'/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/reference-env/bin',
        'CCACHE_DIR': BASE+'/vllm-cann901-csa-0251rc1/src/pypto/.ccache',
        'CMAKE_BUILD_PARALLEL_LEVEL': '4',
    }
    for key, value in env.items(): args += ['--env', key+'='+value]
    return shlex.join([*args, f'bash {REMOTE}/run.sh {case} {batch} {history}'])

if __name__ == '__main__':
    case, batch, history = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    log = ROOT/(case+'-submission.json')
    assert not log.exists(), 'Do not submit a second task after an unknown outcome'
    remote_command = command(case, batch, history)
    result = subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','pto227',remote_command], capture_output=True, text=True, timeout=60)
    ids = re.findall(r'task_[0-9_]+', result.stdout)
    row = dict(case=case,batch=batch,history=history,submitted=datetime.now().isoformat(),command=remote_command,returncode=result.returncode,stdout=result.stdout,stderr=result.stderr,task_id=ids[0] if len(ids)==1 else None)
    log.write_text(json.dumps(row,indent=2)+'\n')
    print(json.dumps(row,indent=2))
    assert result.returncode==0 and row['task_id'], 'Check queue before any retry'
