#!/usr/bin/env bash
set -euo pipefail
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/vector-mte2-20261019-codex/full-csa-live-staging-v2/env.sh"
export SOURCE_ROOT="/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/b28-precision-20261021-codex/whole-b28-qa168-v2/snapshot/source"
export PYTHONPATH="$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
unset SPMD_EXPERIMENT
export B28_ACTIVE=0
unset B28_OUTPUT B28_NATIVE ADMISSION_TRACE_DIR ADMISSION_REFERENCE FULL_PROBE_DIR FULL_PROBE_MODE
export TORCH_DEVICE_BACKEND_AUTOLOAD=0
exp="$base/eight-l1-fixed-20261021-codex"
export ASCEND_RT_VISIBLE_DEVICES='' PYTHONNOUSERSITE=1 HCCL_DETERMINISTIC=true
# Reuse the validated control cache; no source, runtime or SDK rebuild.
export PYPTO_PROG_BUILD_DIR="$base/spmd-baseline-20261020/build" PYPTO_CACHE_DIR="$base/spmd-baseline-20261020/cache"
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache CMAKE_BUILD_PARALLEL_LEVEL=4
timeout 90s python "$exp/preflight.py"
