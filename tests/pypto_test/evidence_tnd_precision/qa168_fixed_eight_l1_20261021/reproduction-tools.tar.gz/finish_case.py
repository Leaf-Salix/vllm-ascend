"""Collect one completed case, its scheduler receipt and original L1 evidence."""
import json
import re
import shlex
import subprocess
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REMOTE='/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/eight-l1-fixed-20261021-codex'
case=sys.argv[1]
assert re.fullmatch(r'fixed-l1-(8k|128k)-b[0-9]+-v1',case)
submission=json.loads((ROOT/(case+'-submission.json')).read_text())
task=submission['task_id'];assert re.fullmatch(r'task_[0-9_]+',task)
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','pto227']
def remote(command):
    return subprocess.run([*ssh,command],text=True,capture_output=True,check=True,timeout=60).stdout
status=remote('task-submit --status '+task).strip()
assert status=='completed (exit=0)',status
log=remote('task-submit --log '+task)
(ROOT/(case+'-final-status.json')).write_text(json.dumps(dict(task=task,status=status,log=log),indent=2)+'\n')
archive=case+'-evidence.tar.gz'
remote('test -f '+shlex.quote(REMOTE+'/results/'+archive)+' || python3 '+shlex.quote(REMOTE+'/collect_case.py')+' '+shlex.quote(case))
subprocess.run(['/opt/homebrew/bin/rsync','-av','--exclude=._*','--exclude=.DS_Store','-e','ssh -o BatchMode=yes -o ConnectTimeout=15','pto227:'+REMOTE+'/results/'+archive,str(ROOT)+'/'],check=True,timeout=60)
with (ROOT/'RECHECK.log').open('w') as output:
    subprocess.run([sys.executable,str(ROOT/'recheck.py')],stdout=output,check=True,timeout=30)
summary=json.loads((ROOT/'RECHECK.json').read_text())
print(json.dumps([row for row in summary['cases'] if row['case']==case],indent=2))
