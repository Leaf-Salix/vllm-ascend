"""直接重算每档原始L1和逐位门禁；不导入NPU。"""
import hashlib
import json
import statistics
import tarfile
from pathlib import Path

root=Path(__file__).resolve().parent
manifest=json.loads((root/'tools/manifest.json').read_text())
expected = {(f'fixed-l1-128k-b{b}-v1',131072,b) for b in (1,4,8,16,24,28)}
expected.update((f'fixed-l1-8k-b{b}-v1',8192,b) for b in (16,32))
seen=set()
receipt_path=root/'canonical-compile-receipt.json'
receipt_sha=hashlib.sha256(receipt_path.read_bytes()).hexdigest()
assert receipt_sha=='aee68650cb6d1bcdf54752d7b641defc3faf2b2e2f2a2112af2c0503eb81b45e'
receipt=json.loads(receipt_path.read_text())
assert all(receipt[k] for k in ('compiled','kernel_abi_pass','orchestration_compiled','prepare_compiled'))
assert receipt['npu_initialized_after'] is False
expected_runtime=json.loads((root/'EXPECTED_RUNTIME77.json').read_text())
assert hashlib.sha256((root/'EXPECTED_RUNTIME77.json').read_bytes()).hexdigest()=='e0b25682cfd924f27021d85ceb025f9b08db354b4c780faa91b0724b5e91108b'
results=[]
failures=[]
for path in sorted(root.glob('*-evidence.tar.gz')):
    with tarfile.open(path) as tar:
        members=[m for m in tar if m.isfile()]
        assert len({m.name for m in members})==len(members)
        data={m.name:tar.extractfile(m).read() for m in members}
    name=next(k for k in data if k.endswith('/result.json'))
    case=name.split('/')[0]
    r=json.loads(data[name])
    identity=(case,r['history'],len(r['lengths']))
    assert identity in expected and identity not in seen, identity
    seen.add(identity)
    assert r['complete'] and r['pass']
    assert r['canonical_compile_receipt_sha256']==r['compile_receipt_sha256']==receipt_sha
    assert r['formal_math_commit']=='ad06a423bc889ca1730a726303845625df29d91d'
    assert r['qa_sha256']=='ea30b2dec9bba1dc7fc0ae5d6a947a88c5eb4ef471b3291307e4524448a06e80'
    assert r['source_manifest_sha256']=='48ee0351ebd554c2d52c93d28ff7aa4be357cf6636a4325d247f64a1f2671539'
    assert len(r['runtime77'])==77 and r['runtime77']==expected_runtime
    assert r['helper_sha']==manifest
    assert r['candidate_sources']==json.loads((root/'FORMAL_CANDIDATE_SOURCES.json').read_text())
    assert r['layer']==4 and set(r['lengths'])=={6}
    assert r['true_tokens']==r['physical_graph_tokens']==6*len(r['lengths'])
    assert r['per_request_padding']==0
    assert r['DFX']['level']==1 and not r['DFX']['enable_dep_gen']
    assert r['DFX']['warmup']==3 and r['DFX']['replays_per_window']==1
    assert len(r['DFX']['windows'])==5
    assert r['protocol']['deterministic_level']==1 and not r['protocol']['wait_backoff']
    for section in ('comparisons','B_comparisons'):
        checks=r[section]['candidate']
        assert len(checks)==8 and all(v['bit_equal'] for v in checks.values())
    for arm in ('native','candidate'):
        g=r['graphs'][arm]
        assert g['actual_acl_graph'] and g['fullgraph'] and g['compiled_raw_equal'] and g['live_input_ABA']
        assert g['topk_poison_replay_restored']
        assert len(g['guards'])==33 and all(v['status']=='PASS' for v in g['guards'].values())
    schema=r['graphs']['candidate']['root_schema']
    assert schema.startswith('dsv4_csa_tnd_precision_spmd_overlap::attention(')
    assert schema.split(' -> ')[0].count('Tensor')==64
    assert r['graphs']['candidate']['pto_dispatch_calls']>0
    assert r['packet_checks']['readonly_after_replay']
    assert all(r['packet_checks']['norm_byte_equal'].values())
    assert len(r['packet_checks']['order_byte_equal'])==33 and all(r['packet_checks']['order_byte_equal'].values())
    values=[]
    for i,window in enumerate(r['DFX']['windows']):
        stem=f'{case}/dfx/'+(f'window_{i}/' if i else '')
        raw=json.loads(data[stem+'chip_swimlane_records.json'])
        meta=raw['metadata'];rows=raw['aicore_tasks']
        assert raw['chip_swimlane_level']==1 and meta['clock_freq_hz']>0
        assert meta['core_types']==['aic']*24+['aiv']*48
        assert meta['dropped_run_boundaries']==0 and len(meta['run_boundaries'])==1
        assert {x[0] for x in rows}==set(range(72))
        assert all(len(x)==6 and 0<x[3]<=x[4] for x in rows)
        span=(max(x[4] for x in rows)-min(x[3] for x in rows))*1e6/meta['clock_freq_hz']
        assert span==window['incore_span_us']
        assert len(rows)==window['records'] and len({x[1] for x in rows})==window['tasks']
        values.append(span)
    assert len(values)==5
    assert values==r['l1']['samples_us'] and statistics.median(values)==r['l1']['median_us']
    preflight_raw=data[case+'-preflight.json'].decode()
    decoder=json.JSONDecoder()
    preflight=None
    for i,c in enumerate(preflight_raw):
        if c=='{':
            try:
                obj,_=decoder.raw_decode(preflight_raw[i:])
                if 'npu_initialized' in obj:preflight=obj;break
            except json.JSONDecodeError:pass
    assert preflight is not None and not preflight['npu_initialized']
    for key in ('source_manifest_sha256','source_file_count','source_root','tested_sources','runtime77','canonical_compile_receipt_sha256','qa_sha256','formal_math_commit'):
        assert preflight['source'][key]==r[key],key
    results.append({'case':case,'history':r['history'],'batch':len(r['lengths']),
                    'L1_samples_us':values,'L1_median_us':statistics.median(values),
                    'A_and_B_all_8_boundaries_bit_equal':True,'root_tensors':64,
                    'pass':True,'archive_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
output={'available_successful_evidence_pass':bool(results),'full_matrix_pass':seen==expected,'expected_cases':8,'validated_cases':len(results),'retrieved_cases':len(results)+len(failures),'failed_cases':failures,'scope':'Saved single-layer graph states and raw hardware L1, not new whole-model token validation','cases':results}
(root/'RECHECK.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(output,ensure_ascii=False,indent=2))
