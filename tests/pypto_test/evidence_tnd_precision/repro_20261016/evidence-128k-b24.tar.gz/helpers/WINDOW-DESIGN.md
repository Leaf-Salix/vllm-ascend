# 生成窗口与完成后空跑的区分

初次Native1所有rank有78个有效forward(0..77)，跨rank前缀逐字段一致。rank2随后1个idle，其余2个idle；都actual0、keys空、query bounds[0]、新入场/完成/抢占空、DP padded向量全6。源代码是客户端等待全部generate完成后再发end_observation RPC；各进程RPC处理时间不同，使生成结束后的dummy尾长度不同。不能丢弃生成期间任何idle。

拟修复诊断边界：

1. 原始trace和outer完整保留、不可覆盖。CPU根据全部16rank活跃标记取最后任一rank有实际token的全局轮数end=78；所有rank须完整覆盖该前缀，逐轮DP向量仍严格对齐。
2. 仅end之后允许空尾，要求inactive/actual0、keys/query/input/position/seq为空、无new/finished/preempt事件，FULL6、DP全6；尾部完整输入必须与本rank首个空尾相同（仅forward/execute_index可变）。输出必须384×192齐全、零抢占，不能靠少生成通过。
3. 从原始Native1导出独立generation reference（78轮prefix+完整来源SHA+tail审计）；新任务在线逐轮比较prefix，超出reference时仍记录raw tail且只准许已审计的空尾原型。出现active、新请求或其它变化立即停止；不加条件通信、不改变scheduler/model调用。
4. full_probe仅在generation prefix执行before/after；模型原函数在空尾照常执行，不比较已经无输出请求的收尾dummy。trace finish明确raw/window/tail counts，完整性要求所有reference轮都匹配。
5. Native2模块/outer每轮仍与原始Native1的generation prefix保真比较；CSA只有Native重复资格PASS后才提交。审计保留raw_count/tail_count，明确结论是完整生成窗口，不把原始79/80写成全部一样。

不会放宽生成期间的任何入场、输入、metadata或模块差异。原Native1/helper SHA仍留存；如复用它，必须显式记录诊断helper修订前后身份，并确认只修结束后dummy的窗口处理。
