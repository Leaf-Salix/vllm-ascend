"""CPU tests for exact boundary evidence and complete-reference gating."""
import json
import tempfile
import unittest
from pathlib import Path

import torch

from full_probe import load_reference, tensor_digest, tree_digest
from capture_boundaries import copy_boundary


class EvidenceTest(unittest.TestCase):
    def test_reused_graph_clips_larger_profile_without_python_guards(self):
        destination = torch.full((144, 4), float('nan'), dtype=torch.bfloat16)
        stamp = torch.full((2,), -1, dtype=torch.int64)
        epoch = torch.tensor([7], dtype=torch.int64)
        source = torch.arange(21 * 4, dtype=torch.float32).reshape(21, 4).bfloat16()
        invocations = []

        def backend(graph, example_inputs):
            def execute(*args):
                invocations.append((graph, args))
                return graph.forward(*args)
            return execute

        def operation(value):
            copy_boundary(destination, stamp, value, epoch, 144)
            return destination

        compiled = torch.compile(operation, backend=backend, fullgraph=True, dynamic=True)
        torch._dynamo.mark_dynamic(source, 0, min=2, max=1000)
        compiled(source)
        self.assertEqual(len(invocations), 1)
        graph, arguments = invocations[0]
        self.assertTrue(any(value is source for value in arguments))
        self.assertEqual(sum(isinstance(value, int) and value == 21 for value in arguments), 1)
        for count in (6, 21, 144, 400):
            value = torch.arange(count * 4, dtype=torch.float32).reshape(count, 4).bfloat16()
            args = tuple(value if arg is source else count if isinstance(arg, int) and arg == 21
                         else arg for arg in arguments)
            destination.fill_(float('nan'))
            stamp.fill_(-1)
            # Invoke the captured graph directly, as vLLM does; no Python guard.
            graph.forward(*args)
            rows = min(count, 144)
            self.assertTrue(torch.equal(destination[:rows], value[:rows]))
            self.assertTrue(torch.isnan(destination[rows:]).all())
            self.assertEqual(stamp.tolist(), [7, count])

    def test_bf16_one_bit_difference_is_detected(self):
        value = torch.tensor([[1.0, -2.0], [3.0, 4.0]], dtype=torch.bfloat16)
        other = value.clone()
        self.assertEqual(tensor_digest(value, 2), tensor_digest(other, 2))
        other.view(torch.int16)[0, 0] += 1
        self.assertNotEqual(tensor_digest(value, 2), tensor_digest(other, 2))

    def test_only_actual_rows_but_all_aux_features_are_compared(self):
        value = torch.zeros((3, 4), dtype=torch.bfloat16)
        other = value.clone()
        other[2, 0] = 9
        self.assertEqual(tensor_digest(value, 2), tensor_digest(other, 2))
        self.assertNotEqual(tensor_digest(value, 3), tensor_digest(other, 3))
        expected = tree_digest((value, [value.clone()]), 2)
        aux = value.clone()
        aux[0, 0] = 1
        self.assertNotEqual(expected, tree_digest((value, [aux]), 2))

    def test_invalid_output_shape_or_tree_is_rejected(self):
        with self.assertRaises(ValueError):
            tensor_digest(torch.zeros((1, 4)), 2)
        with self.assertRaises(TypeError):
            tree_digest({'unexpected': torch.ones(2)}, 2)

    def test_reference_must_be_nonempty_complete_and_counted(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'outer.jsonl').write_text('')
            audit = root / 'complete.json'
            audit.write_text(json.dumps({'complete': True, 'records': 0}))
            with self.assertRaises(ValueError):
                load_reference(root, 'outer.jsonl')
            (root / 'outer.jsonl').write_text('{"forward_index": 0}\n')
            audit.write_text(json.dumps({'complete': False, 'records': 1}))
            with self.assertRaises(ValueError):
                load_reference(root, 'outer.jsonl')
            audit.write_text(json.dumps({'complete': True, 'records': 2}))
            with self.assertRaises(ValueError):
                load_reference(root, 'outer.jsonl')
            audit.write_text(json.dumps({'complete': True, 'records': 1}))
            self.assertEqual(load_reference(root, 'outer.jsonl'), [{'forward_index': 0}])


if __name__ == '__main__':
    unittest.main(verbosity=2)
