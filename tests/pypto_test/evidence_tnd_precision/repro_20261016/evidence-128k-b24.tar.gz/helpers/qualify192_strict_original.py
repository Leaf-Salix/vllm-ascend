"""Qualify complete192-token cohorts using actual joint round counts."""
import argparse
import hashlib
import json
import re
from pathlib import Path

from audit_alignment import audit


COMMON = ('attention', 'variant', 'bank', 'batch', 'snapshot', 'snapshot_manifest',
          'production_git_commit', 'decode_tokens', 'event_work_mode',
          'num_gpu_blocks_override', 'gpu_memory_utilization', 'source_manifest_sha256',
          'official_static_cache_sha256', 'bank_plan_sha256',
          'runtime_package_manifest_sha256', 'runtime_package',
          'bootstrap_sha256', 'full_probe_sha256', 'witness_sha256')


def read_rows(root, name, mode, count):
    folder = root/'full-probe'
    complete = json.loads((folder/'complete.json').read_text())
    records = [json.loads(line) for line in (folder/name).read_text().splitlines()]
    if (not complete['complete'] or complete['mode'] != mode
            or len(records) != complete['records'] or len(records) < count
            or (mode == 'witness' and len(records) != count)):
        raise ValueError('Incomplete FULL witness/control')
    if any(row['forward_index'] != index or row['actual_tokens'] != 0
           for index,row in enumerate(records[count:], count)):
        raise ValueError('Only verified empty control suffix may lie outside generation window')
    return records[:count]


def source_identity(config):
    manifest_path = Path(config['snapshot_manifest'])
    if (manifest_path.parent/'source').resolve() != Path(config['snapshot']).resolve():
        raise ValueError('Source snapshot is not bound to manifest')
    if hashlib.sha256(manifest_path.read_bytes()).hexdigest() != config['source_manifest_sha256']:
        raise ValueError('Source manifest differs from tested task')
    manifest = json.loads(manifest_path.read_text())
    for filename, digest in manifest['files'].items():
        if hashlib.sha256((Path(config['snapshot'])/filename).read_bytes()).hexdigest() != digest:
            raise ValueError('Snapshot changed since testing: '+filename)


def qualify(left_root, right_root, phase):
    if left_root.resolve() == right_root.resolve():
        raise ValueError('Independent result directories required')
    left, left_trace, left_outputs, left_acceptance, left_observed = audit(left_root)
    right, right_trace, right_outputs, right_acceptance, right_observed = audit(right_root)
    if left['backend'] != 'native' or right['backend'] != ('native' if phase == 'native' else 'pto'):
        raise ValueError('Incorrect experiment arm')
    if any(left[key] != right[key] for key in COMMON):
        raise ValueError('Common experiment identity differs')
    job=Path(__file__).resolve().parent
    transition=json.loads((job/'diagnostic-window-transition.json').read_text())
    before=transition['admission_trace_before_sha256']
    after=transition['admission_trace_after_sha256']
    if (hashlib.sha256((job/transition['old_file']).read_bytes()).hexdigest()!=before
            or hashlib.sha256((job/transition['new_file']).read_bytes()).hexdigest()!=after
            or right['trace_helper_sha256']!=after
            or left['trace_helper_sha256']!=(before if phase=='native' else after)):
        raise ValueError('Unqualified diagnostic revision')
    if right['generation_window_sha256']!=hashlib.sha256((job/'generation_window.py').read_bytes()).hexdigest():
        raise ValueError('Wrong generation-window helper')
    reference=job/'native1-generation-reference'
    if hashlib.sha256((reference/'manifest.json').read_bytes()).hexdigest()!=right['generation_reference_manifest_sha256']:
        raise ValueError('Derived generation reference identity differs')
    binding=json.loads((reference/'manifest.json').read_text())
    raw=Path(binding['raw_source'])
    for name,digest in binding['source_sha256'].items():
        if hashlib.sha256((raw/name).read_bytes()).hexdigest()!=digest:
            raise ValueError('Raw control source changed')
    for name,digest in binding['derived_sha256'].items():
        if hashlib.sha256((reference/name).read_bytes()).hexdigest()!=digest:
            raise ValueError('Derived generation reference changed')
    source_identity(left)
    source_identity(right)
    if left_trace != right_trace or left_outputs != right_outputs or left_acceptance != right_acceptance:
        raise ValueError('Actual joint inputs or complete tokens/acceptance events differ')
    count = len(left_trace[0])
    left_mode = 'control' if phase == 'native' else 'witness'
    left_outer = read_rows(left_root, 'outer.jsonl', left_mode, count)
    right_outer = read_rows(right_root, 'outer.jsonl', 'witness', count)
    right_stages = read_rows(right_root, 'stages.jsonl', 'witness', count)
    if left_outer != right_outer:
        raise ValueError('Target hidden/aux/MTP residual differs')
    if phase == 'csa' and right_stages != read_rows(left_root, 'stages.jsonl', 'witness', count):
        raise ValueError('CSA boundary digest differs')
    boundaries = 0
    for step, stage in enumerate(right_stages):
        rows = left_trace[0][step]['actual_tokens']
        if (right_outer[step]['forward_index'] != step or right_outer[step]['actual_tokens'] != rows
                or stage['forward_index'] != step or stage['actual_tokens'] != rows
                or set(stage['layers']) != {str(i) for i in range(43)}):
            raise ValueError('Witness/actual round or layer coverage differs')
        if phase == 'native':
            payload = right_root/'full-probe'/f'step{step:03d}.pt'
            if not payload.is_file() or payload.stat().st_size == 0:
                raise ValueError('Missing Native raw tensor snapshot')
        for index, fields in stage['layers'].items():
            expected = {'input', 'output', 'positions'}
            if int(index) in range(2, 43, 2):
                expected.update(('normed', 'heads', 'oproj', 'attention_half'))
            if set(fields) != expected:
                raise ValueError('Incomplete boundary set')
            for name, digest in fields.items():
                width = {'positions':1, 'normed':4096, 'heads':32768, 'oproj':4096}.get(name,16384)
                dtype = 'torch.int64' if name == 'positions' else 'torch.bfloat16'
                if (digest['shape'] != [rows,width] or digest['dtype'] != dtype
                        or re.fullmatch('[0-9a-f]{64}',digest['sha256']) is None):
                    raise ValueError('Invalid boundary digest')
            boundaries += len(fields)
    return {'pass':True, 'phase':phase, 'records':count, 'inputs_equal_all16ranks':True,
            'complete_tokens_and_acceptance_equal_all16ranks':True,
            'rank0_outer_hidden_aux_mtp_bit_equal':True,
            'rank0_boundary_records':boundaries, 'rank0_csa_layers':21,
            'rank0_modules_bit_equal':phase=='csa',
            'source_manifest_sha256':right['source_manifest_sha256'],
            'production_git_commit':right['production_git_commit'],'diagnostic_transition':transition,'generation_reference_manifest_sha256':right['generation_reference_manifest_sha256'],
            'acceptance':{k:v for k,v in right_acceptance.items() if k!='requests'},
            'left_observed':left_observed, 'right_observed':right_observed,
            'scope':'fixed128K bank; B24 submitted, actual concurrency recorded;192 output tokens; rank0 float witnesses only; no performance'}


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('phase',choices=('native','csa'))
    parser.add_argument('left',type=Path)
    parser.add_argument('right',type=Path)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    report=qualify(args.left,args.right,args.phase)
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('acceptance','left_observed','right_observed')}))
