"""Separate numerical qualification from the unchanged default strict READY gate."""
import json
from pathlib import Path
from qualify192 import qualify

job = Path(__file__).resolve().parent
results = Path('/data/pyptouser/yejia/lc128')
left = results/'retest192-native2-b24000'
right = results/'retest192-precision-b24000'
try:
    qualify(left, right, 'csa')
except ValueError as error:
    if str(error) != 'rank0: READY reuse failed':
        raise
    strict = {'pass': False, 'error': str(error),
              'scope': 'Default strict qualification includes warm READY reuse; retained as failed.'}
else:
    raise ValueError('Unexpected READY result; investigate before reporting')
(job/'csa-strict-qualification-failed.json').write_text(json.dumps(strict, indent=2)+'\n')
report = qualify(left, right, 'csa', require_ready_reuse=False)
report['scope'] += '; numerical qualification only; strict READY reuse failed, not a performance result'
report['strict_ready_reuse_pass'] = False
cache_stats = []
for rank in range(16):
    raw = json.loads((right/f'rank{rank}.mixed.json').read_text())
    stats = raw['observation'][0]['pypto_cache_stats']
    if any(stats[key] != 0 for key in ('bypasses', 'invalid_entries', 'storage_errors', 'forced_rebuilds')):
        raise ValueError(f'rank{rank}: cache error/bypass')
    cache_stats.append({'rank': rank, 'stats': stats})
report['cache_stats_from_raw_observations'] = cache_stats
report['cache_error_counters_zero_all16'] = True
(job/'csa-numerics-qualified.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('left_observed','right_observed','cache_stats_from_raw_observations','acceptance','diagnostic_transition')}))
