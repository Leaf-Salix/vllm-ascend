"""Archive only small diagnostic evidence; exclude tensor/model/cache payloads."""
import argparse,hashlib,io,json,subprocess,tarfile
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--phase',choices=('native','final'),required=True)
parser.add_argument('--tag', default='20261016')
args=parser.parse_args()
job=Path(__file__).resolve().parent
base=job.parent
results=Path('/data/pyptouser/yejia/lc128')
labels=['retest192-native1-b24000','retest192-native2-b24000']
tasks=['task_20261016_091954_247756916995','task_20261016_093935_324666725855']
if args.phase=='final':
    labels.append('retest192-precision-b24000')
    tasks.append('task_20261016_095631_393947426780')
files={}
def add(path,name):
    if path.is_file():
        if path.stat().st_size>64*1024**2:
            raise ValueError('Unexpected large evidence: '+str(path))
        files[name]=path
for label in labels:
    root=results/label
    for path in root.iterdir():
        if path.suffix in ('.json','.jsonl','.log'):
            add(path,f'results/{label}/{path.name}')
    for subdir in ('input-trace','full-probe'):
        for path in (root/subdir).rglob('*'):
            if path.suffix in ('.json','.jsonl'):
                add(path,f'results/{label}/{path.relative_to(root)}')
for path in job.rglob('*'):
    if path.suffix in ('.py','.sh','.md','.json','.jsonl'):
        add(path,f'helpers/{path.relative_to(job)}')
source_job=base/'root-fix-20261016'
add(source_job/'manifest.json','source/manifest.json')
add(source_job/'env.sh','source/env.sh')
add(source_job/'preflight.py','source/preflight.py')
production='vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision/decode_indexer.py'
add(source_job/'source'/production,'source/'+production)
old=base/'low-acceptance-20261010'
add(old/'runtime-package/manifest.json','runtime/manifest.json')
add(old/'official-static-cache/metadata.json','runtime/official-static-metadata.json')
add(base/'low-acceptance-128k-b24-20261014/banks/fixed131072/plan.json','bank/plan.json')
manifest={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in sorted(files.items())}
statuses={}
for task in tasks:
    process=subprocess.run(['task-submit','--status',task],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=25,check=True)
    statuses[task]=process.stdout
archive=job/f'{args.phase}-small-evidence-{args.tag}.tar.gz'
if archive.exists():
    raise FileExistsError('Do not overwrite an evidence archive')
with tarfile.open(archive,'w:gz') as bundle:
    for name,path in sorted(files.items()):
        bundle.add(path,arcname=name,recursive=False)
    for name,value in (('evidence-manifest.json',manifest),('task-statuses.json',statuses)):
        data=(json.dumps(value,indent=2)+'\n').encode()
        info=tarfile.TarInfo(name)
        info.size=len(data)
        bundle.addfile(info,io.BytesIO(data))
print(json.dumps({'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'files':len(files)}))
