"""Audit complete fixed-capacity runs and exact active target input traces."""
import argparse
import json
import re
from pathlib import Path


def audit(root):
    requested = json.loads((root / 'configuration.json').read_text())
    if requested['num_gpu_blocks_override'] != 24000 or requested['decode_tokens'] != 192:
        raise ValueError('Wrong fixed-capacity diagnostic configuration')
    from low_acceptance_20261001.mixed import collect
    from low_acceptance_20261001.reference import extract
    acceptance = collect(root, Path(requested['bank']), 24, 192)
    if acceptance['errors'] or acceptance['total_preemptions'] != 0:
        raise ValueError(f'Invalid output/events or preemption: {acceptance}')
    from admission_trace import validate_joint
    traces, observed = [], []
    for rank in range(16):
        report = json.loads((root / f'input-trace/rank{rank}.audit.json').read_text())
        rows = [json.loads(x) for x in (root / f'input-trace/rank{rank}.trace.jsonl').read_text().splitlines()]
        if (not rows or not report['complete'] or report['first_difference'] or report['records'] != len(rows) or not report.get('armed_after_dp_barrier')):
            raise ValueError(f'rank{rank}: empty/incomplete/failed input trace')
        for row in rows:
            lengths = row['query_lengths']
            if (len(row['keys']) != len(lengths) or sum(lengths) != row['actual_tokens']
                    or len(row['positions']) != row['actual_tokens'] or len(row['input_ids']) != row['actual_tokens']
                    or row['preempted_keys'] or row['query_bounds'][-1] != row['actual_tokens']
                    or len(row['padded_input_ids']) != row['padded_tokens']
                    or len(row['padded_positions']) != row['padded_tokens']):
                raise ValueError(f'rank{rank}: invalid active input record')
        log = (root / f'rank{rank}.log').read_text(errors='replace')
        overrides = re.findall(r'Overriding num_gpu_blocks=\d+ with num_gpu_blocks_override=(\d+)', log)
        if not overrides or any(int(x) != 24000 for x in overrides):
            raise ValueError(f'rank{rank}: actual capacity override missing/wrong')
        data = json.loads((root / f'rank{rank}.mixed.json').read_text())
        for worker in data['worker_runtime_config']:
            if (worker['deterministic_level'] != 1 or not worker['torch_deterministic']
                    or worker['hccl_deterministic'] != 'true' or worker['dynamic_eplb']
                    or worker['cann_event_work_mode'] != 1):
                raise ValueError(f'rank{rank}: actual determinism/EPLB/event configuration differs')
        cache_records = re.findall(r'OFFICIAL_STATIC_CACHE packages=(\d+) metadata_sha=([0-9a-f]+)', log)
        if (not cache_records or any(int(count) != 13 or digest != requested['official_static_cache_sha256']
                                     for count, digest in cache_records)
                or 'OFFICIAL_STATIC_RESELECT success=1' not in log
                or 'reselect_static_kernel failed' in log or 'execute op_compiler' in log):
            raise ValueError(f'rank{rank}: official static cache reuse not verified')
        observation = data['observation'][0]
        if observation['model_forward_counts'].get('FULL_tokens144', 0) <= 0:
            raise ValueError(f'rank{rank}: no actual FULL144 replay')
        for worker in data['attention_implementations']:
            csa = [x for x in worker if x['kind'] == 'csa']
            hca = [x for x in worker if x['kind'] == 'hca']
            if len(csa) != 21 or len(hca) != 20 or any(x['implementation'] != 'native' for x in hca):
                raise ValueError(f'rank{rank}: incorrect layer selection')
            required = 'pto' if requested['backend'] == 'pto' else 'native'
            if any(x['implementation'] != required for x in csa):
                raise ValueError(f'rank{rank}: incorrect CSA selection')
            if required == 'pto' and any(not x['runtime_class'].endswith('.deepseek_v4_flash_csa_tnd_precision.service') for x in csa):
                raise ValueError(f'rank{rank}: wrong PTO variant')
        if requested['backend'] == 'pto':
            stats = observation['pypto_cache_stats']
            if stats['ready_hits'] <= 0 or any(stats[k] != 0 for k in ('generation_builds', 'binary_builds', 'bypasses', 'invalid_entries', 'storage_errors', 'forced_rebuilds')):
                raise ValueError(f'rank{rank}: READY reuse failed')
        traces.append([{k: v for k, v in row.items() if k != 'execute_index'} for row in rows])
        observed.append({'rank': rank, 'records': len(rows),
                         'observed_peak_requests': max(len(row['keys']) for row in rows),
                         'dp_metadata_present_all_records': all(row['dp_tokens_across_ranks'] is not None for row in rows),
                         'actual_full144': observation['model_forward_counts']['FULL_tokens144']})
    validate_joint(traces)
    return requested, traces, extract(root), acceptance, observed


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('left', type=Path)
    parser.add_argument('--right', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    config, traces, rows, acceptance, observed = audit(args.left)
    result = {'pass': True, 'left': str(args.left), 'left_acceptance': {k: v for k, v in acceptance.items() if k != 'requests'}, 'left_observed': observed}
    if args.right:
        if args.left.resolve() == args.right.resolve():
            raise ValueError('Independent result directories required')
        other, other_traces, other_rows, other_acceptance, other_observed = audit(args.right)
        common = lambda c: {k: v for k, v in c.items() if k not in ('backend', 'trace_reference')}
        result['common_configuration_equal'] = common(config) == common(other)
        result['input_traces_equal_per_rank'] = [a == b for a, b in zip(traces, other_traces)]
        result['requests_and_outputs_equal'] = rows == other_rows
        result['right_observed'] = other_observed
        result['right_acceptance'] = {k: v for k, v in other_acceptance.items() if k != 'requests'}
        result['pass'] = result['common_configuration_equal'] and all(result['input_traces_equal_per_rank']) and result['requests_and_outputs_equal']
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False))
    raise SystemExit(0 if result['pass'] else 1)
