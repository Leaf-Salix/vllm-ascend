"""Private diagnostic: record actual target inputs without changing model math."""
import json
from pathlib import Path


def allocation_plan(config):
    tensors = sorted([{'size': int(t.size), 'shared_by': sorted(t.shared_by)}
                      for t in config.kv_cache_tensors], key=lambda t: t['shared_by'])
    upper = sum(t['size'] + 2 * 1024**2 for t in tensors)
    return {'num_blocks': int(config.num_blocks), 'tensors': tensors,
            'aligned_allocation_upper_bytes': upper}


def validate_joint(traces, world=16):
    """All ranks must cover the same target/MoE forward rounds, idle included."""
    if len(traces) != world or not traces[0] or any(len(rows) != len(traces[0]) for rows in traces):
        raise ValueError('Joint trace ranks/round counts differ or are empty')
    for step, entries in enumerate(zip(*traces)):
        vector = entries[0]['dp_tokens_across_ranks']
        if vector is None or len(vector) != world:
            raise ValueError('Missing joint DP vector')
        for rank, row in enumerate(entries):
            if (row['rank'] != rank or row['forward_index'] != step
                    or row['dp_tokens_across_ranks'] != vector
                    or row['padded_tokens'] != vector[rank]):
                raise ValueError(f'Joint DP round mismatch: round={step}, rank={rank}')
    return len(traces[0])


def install(observer, directory, reference=None):
    from vllm.forward_context import get_forward_context

    runner = observer.model_runner
    rank = observer.vllm_config.parallel_config.data_parallel_rank
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    config = runner.kv_cache_config
    capacity = allocation_plan(config)
    expected = None
    if reference:
        expected = [json.loads(line) for line in
                    (Path(reference) / f'rank{rank}.trace.jsonl').read_text().splitlines()]
        audit = json.loads((Path(reference) / f'rank{rank}.audit.json').read_text())
        if (not expected or not audit.get('complete') or audit.get('first_difference')
                or audit.get('records') != len(expected) or not audit.get('armed_after_dp_barrier')):
            raise RuntimeError('Reference input trace is empty, incomplete or failed')
        if audit.get('capacity') != capacity:
            raise RuntimeError('Actual Native/PTO KV allocation plans differ')
    trace = (directory / f'rank{rank}.trace.jsonl').open('x', buffering=1)
    execute_origin, forward_origin = runner.execute_model, runner._model_forward
    state = {'scheduler': None, 'execute_index': -1, 'forward_index': 0, 'keys': {},
             'matched': 0, 'failed': False, 'armed': False, 'active_forwards': 0}

    def key(rid):
        if rid not in state['keys']:
            raise RuntimeError(f'Unmapped request ID: {rid}')
        return state['keys'][rid]

    def execute(scheduled, *args, **kwargs):
        if state['failed']:
            raise RuntimeError('INPUT_TRACE_STOPPED after the first difference')
        state['execute_index'] += 1
        for req in scheduled.scheduled_new_reqs:
            params = req.sampling_params.extra_args
            offline = params['kv_transfer_params']['offline_key']
            if req.req_id in state['keys'] and state['keys'][req.req_id] != offline:
                raise RuntimeError('Request key changed')
            state['keys'][req.req_id] = offline
        state['scheduler'] = scheduled
        try:
            return execute_origin(scheduled, *args, **kwargs)
        finally:
            state['scheduler'] = None

    def arm():
        if state['armed']:
            raise RuntimeError('Input trace already armed')
        state['armed'] = True

    runner._admission_trace_arm = arm
    runner._admission_trace_current = None

    def forward(padded, input_ids=None, positions=None, *args, **kwargs):
        if state['failed']:
            raise RuntimeError('INPUT_TRACE_STOPPED after the first difference')
        context = get_forward_context()
        scheduled = state['scheduler']
        if context.capturing or not state['armed']:
            return forward_origin(padded, input_ids, positions, *args, **kwargs)
        active = scheduled is not None and scheduled.total_num_scheduled_tokens > 0
        n = scheduled.total_num_scheduled_tokens if active else 0
        rows, bounds, lengths = [], [0], []
        if input_ids is None or positions is None or input_ids.ndim != 1 or positions.ndim != 1:
            raise RuntimeError('Diagnostic requires real one-dimensional device inputs')
        if active:
            rows = list(runner.input_batch.req_ids[:runner.input_batch.num_reqs])
            if set(rows) != set(scheduled.num_scheduled_tokens):
                raise RuntimeError('Actual input batch differs from scheduler request set')
            metadata = next((m for m in (context.attn_metadata or {}).values()
                             if getattr(getattr(m, 'decode', None), 'query_start_loc_cpu', None) is not None), None)
            if metadata is None:
                raise RuntimeError('Missing actual DSA decode metadata')
            req = metadata.decode
            count = getattr(req, 'num_reqs_actual', None)
            count = metadata.num_decodes if count is None else count
            bounds = req.query_start_loc_cpu[:count + 1].tolist()
            if count != len(rows) or bounds[0] != 0 or bounds[-1] != n:
                raise RuntimeError(f'Input order/query bounds inconsistent: {count}, {len(rows)}, {bounds}, {n}')
            lengths = req.seq_lens[:count].detach().cpu().tolist()
            state['active_forwards'] += 1
        dp = getattr(context, 'dp_metadata', None)
        dp_tokens = getattr(dp, 'num_tokens_across_dp_cpu', None)
        world = observer.vllm_config.parallel_config.data_parallel_size
        dp_tokens = None if dp_tokens is None else dp_tokens.tolist()
        if dp_tokens is None or len(dp_tokens) != world or dp_tokens[rank] != int(padded):
            raise RuntimeError('Missing/inconsistent joint DP token vector')
        record = {
            'rank': rank, 'execute_index': state['execute_index'],
            'forward_index': state['forward_index'], 'active': active, 'graph_mode': context.cudagraph_runtime_mode.name,
            'padded_tokens': int(padded), 'actual_tokens': n,
            'dp_tokens_across_ranks': dp_tokens,
            'keys': [key(rid) for rid in rows], 'query_bounds': bounds,
            'query_lengths': [b - a for a, b in zip(bounds, bounds[1:])],
            'scheduled_tokens': [scheduled.num_scheduled_tokens[rid] for rid in rows],
            'input_ids': input_ids[:n].detach().cpu().tolist(),
            'positions': positions[:n].detach().cpu().tolist(),
            'seq_lens': lengths,
            'padded_input_ids': input_ids[:int(padded)].detach().cpu().tolist(),
            'padded_positions': positions[:int(padded)].detach().cpu().tolist(),
            'new_keys': [] if scheduled is None else [key(x.req_id) for x in scheduled.scheduled_new_reqs],
            'finished_keys': [] if scheduled is None else sorted(key(rid) for rid in scheduled.finished_req_ids),
            'preempted_keys': [] if scheduled is None else sorted(key(rid) for rid in (scheduled.preempted_req_ids or ())),
        }
        trace.write(json.dumps(record, ensure_ascii=False) + '\n')
        index = state['forward_index']
        state['forward_index'] += 1
        if expected is not None:
            before = expected[index] if index < len(expected) else {}
            # Armed after the existing paused/enqueued DP barrier. Include idle
            # forwards; audit also requires identical per-round DP vectors and
            # record counts across all ranks. execute_index is only local metadata.
            fields = sorted((set(record) | set(before)) - {'execute_index'})
            changed = [name for name in fields if record.get(name) != before.get(name)]
            if changed:
                state['failed'] = True
                failure = {'rank': rank, 'forward_index': index, 'fields': changed,
                           'expected': before, 'actual': record}
                with (directory / f'rank{rank}.STOP.json').open('x') as stop:
                    stop.write(json.dumps(failure, indent=2) + '\n')
                raise RuntimeError(f'INPUT_TRACE_FIRST_DIFFERENCE rank={rank} forward={index} fields={changed}')
            state['matched'] += 1
        runner._admission_trace_current = record
        try:
            before = getattr(runner, '_diagnostic_before_forward', None)
            if before is not None:
                before(record)
            result = forward_origin(padded, input_ids, positions, *args, **kwargs)
            after = getattr(runner, '_diagnostic_after_forward', None)
            if after is not None:
                after(record, result)
            return result
        except BaseException:
            state['failed'] = True
            raise
        finally:
            runner._admission_trace_current = None

    runner.execute_model, runner._model_forward = execute, forward

    def finish():
        runner.execute_model, runner._model_forward = execute_origin, forward_origin
        del runner._admission_trace_arm
        del runner._admission_trace_current
        trace.close()
        complete = state['armed'] and not state['failed'] and state['active_forwards'] > 0 and (expected is None or len(expected) == state['forward_index'])
        report = {'rank': rank, 'capacity': capacity, 'records': state['forward_index'], 'matched_records': state['matched'],
                  'reference_records': None if expected is None else len(expected),
                  'active_forwards': state['active_forwards'], 'armed_after_dp_barrier': state['armed'],
                  'complete': complete, 'first_difference': state['failed'],
                  'scope': 'all target forwards after paused/enqueued DP barrier, including idle; joint audit required; actual device inputs; no performance measurement'}
        (directory / f'rank{rank}.audit.json').write_text(json.dumps(report, indent=2) + '\n')
        if not complete or state['failed']:
            raise RuntimeError('Input trace is incomplete or differs from reference')
        return report

    observer._admission_trace_finish = finish
