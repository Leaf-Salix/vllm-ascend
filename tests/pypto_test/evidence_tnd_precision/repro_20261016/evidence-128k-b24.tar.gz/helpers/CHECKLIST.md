# 2026-10-16 128K/B24、192 token入场对齐复测

- 用户授权：先确认Native独立重复，再对齐实际入场比较CSA；首差停止定位；每项不超过15分钟。
- 本地分支dev/pypto-dsv4-csa-nalinaly-tnd-20261008-codex，数学源码cbc810c8afab47c2425068049440424f014dcde3。
- 复用227 root-fix-20261016/source（冻结a9基线+已提交单文件Indexer修复）；生产源码SHA与本地commit逐文件核对。remote harness仍为已记录的冻结诊断移植，不伪称整个目录是Git checkout。
- 冻结fixed131072 bank、TP1 DP=EP16、每rank24问题、192 token，24000 KV blocks；FULL[6,144]；确定性level1/HCCL true/atomic0/NZ2/EPLB off。
- 任务顺序：Native1 control → Native2 witness(逐步对Native1输入/outer门禁) → 独立资格审计 → CSA witness(逐步同输入、模块/outer门禁)。不预交后续任务。
- 所有NPU任务task-submit --max-time780；每项独立输出目录；提交后持续在当前会话观察，约5min查询一次，不创建调度。
- Native witness保留rank0所有有效行模块原值供首差定位；预计几十GiB，已确认/data有6.8TiB可用。模型/大tensor/编译缓存不加入Git。
- 本地：python3 -S语法编译；复用admission/full_probe的CPU单测；独立方案与审计复核。
- 远端：先无设备预检实际导入、manifest、工具链、CANN/ATB和probe；不重装框架、不重新编译SDK。
- 资格：16rank完整trace/DP轮次、完整73728 token/接受事件、零抢占、实际并发；Native保真通过后比较rank0全层边界；CSA必须READY命中且无生成/编译/bypass。
- 结果写项目测试MD及结构化JSON，增量pre-commit后commit/push；首差则保留原值和来源、停止扩大配置。

## 执行记录

- 09:18无设备预检通过：实际Torch2.10.0、Torch-NPU2.10.0.post2、vLLM0.25.1、CANN9.2beta2/ATB9.2、私有PyPTO工具链和75权重分片；入场10项+FULL证据5项CPU测试通过。
- 09:19:54提交Native1：task_20261016_091954_247756916995；16卡、max780；out=/data/pyptouser/yejia/lc128/retest192-native1-b24000。命令为task-submit --ptoas0.63 --deviceauto --device-num16 --max-time780 --env PYTHONNOUSERSITE=1后运行本目录run-case.sh native-control。
- 提交前独立复核：三臂192及新reference正确；审计须按本次实际轮数，不引用旧qualify_full.py。
- 新qualify192.py独立审查无阻塞：192完整token/events/确定接受统计，按实际trace轮数验证43层stage/outer；source manifest与snapshot及各文件SHA绑定。Native phase审计PASS之前不提交CSA。
- Native1约09:26:32完成exit0(提交至清理约6m38)，原始rank0=80轮、rank2=79轮，其余80；所有rank有效窗口78轮、其中FULL144为73轮、实际峰值21。初始strict joint审计拒绝轮数差异，未提交后续任务。
- 首差定位在观测结束：mixed.py等待全部生成客户端完成后才异步RPC end_observation；raw后缀仅无活请求的FULL6 dummy。所有原始文件保留。
- 诊断窗口修复：从全部16rank推导global最后active+1，保留内部idle；结束后empty tail逐字段/原型验证并保留raw，只跳诊断回调、原模型照常执行。新6项CPU正/负控制及原10项通过。独立方案review允许复用Native1，不需重跑。
- 纯CPU派生generation reference通过：78轮，384请求、73728token、平均接受3.8264033264、零抢占；原始tail counts=[2,2,1,2,2,2,2,2,2,2,2,2,2,2,2,2]。derived manifest SHA347b452c4eed32897b54bd05305a317708fbea987ffeab1ad1ac1461f9153dac，记录全部raw和derived文件SHA，不覆盖原始80轮complete。
- 窗口修订最终独立复核无阻塞：old/new helper SHA及不变probe身份核验通过，原始/派生证据均绑定。没有修改数学源码、scheduler或model调用。
- 09:39:35提交Native2：task_20261016_093935_324666725855，16卡、max780，out=/data/pyptouser/yejia/lc128/retest192-native2-b24000；输入参考与outer参考来自带SHA的Native1 generation reference。
- 09:42左右Native2仍pending：当前16卡不齐，仅6卡空闲；未占卡，不把排队时间算运行时间。不联系其它线程，不创建调度。
- 09:47检查Native2已running并占16卡，实际约1分钟；此前仅排队，未超运行预算。继续观察，后续CSA仍未提交。
- Native2约09:46启动、09:54:18结束exit0，实际约8分钟；raw rank0 79轮，generation 78轮，empty tail单独严格审计。
- qualify192.py native独立资格PASS：16rank完整generation输入/73728 tokens/事件/接受统计均相同；rank0 target hidden/aux/MTP逐bit一致，Native witness 43层/21CSA共16614边界与78原值文件完备；原始和派生SHA及old→new诊断身份门禁通过。
- CSA task_20261016_095631_393947426780于09:56:31提交；10:12:30检查已running约12秒，实际启动约10:12:18，之前约16分钟仅排队。max780约束执行时间，不按Done汇总的提交至结束时长判定占卡时间。
- Native正式记录已commit/push 89e90b10a；生产数学源码仍cbc810。当前只等待/监控此CSA任务，不增加其它配置。
- CSA于约10:12:18运行、10:20:35结束exit0，实际约8m17；Done汇总24m09含约16min排队。78轮在线输入、stage与outer无首差。所有本线程NPU任务已结束。
- 最终默认strict资格失败于READY：所有rank ready_hits0，rank9首次generation/binary各1、16.533138189s，其余无编译；bypass/invalid/storage/forced均0。原始严格失败保留，不为获取cachehit另占NPU。
- 新增独立CPU数值审计，保留default require_ready_reuse=True；单独明确False检查所有其它原门禁。数值PASS：all16实际输入、73728token/完整接受事件、rank0 78轮outer和16614模块边界bitexact，零抢占。不得将其称为strictREADY资格通过。
- CPU产物身份PASS：重算冻结精度入口的persistent source和当前工具链identity，与实际READY manifest一致；206产物文件SHA验证；ABI Simpler a54c0509。specialization来源实际manifest/ABI，未独立重新specialize，不推测首次miss原因。
