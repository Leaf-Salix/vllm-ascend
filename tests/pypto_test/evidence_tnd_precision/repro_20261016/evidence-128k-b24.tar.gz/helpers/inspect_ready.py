"""Read cache statistics without changing precision or qualification gates."""
import json
from pathlib import Path
root=Path('/data/pyptouser/yejia/lc128/retest192-precision-b24000')
records=[]
for rank in range(16):
    data=json.loads((root/f'rank{rank}.mixed.json').read_text())
    records.append({'rank':rank,'stats':data['observation'][0]['pypto_cache_stats'],
                    'runtime_identity':data['observation'][0].get('pypto_runtime_identity')})
report={'strict_ready_reuse_pass':False,'per_rank':records,
        'online_witness_complete':json.loads((root/'full-probe/complete.json').read_text())}
(root/'ready-inspection.json').write_text(json.dumps(report,indent=2)+'\n')
for record in records:
    print(json.dumps({'rank':record['rank'],'stats':record['stats']}))
