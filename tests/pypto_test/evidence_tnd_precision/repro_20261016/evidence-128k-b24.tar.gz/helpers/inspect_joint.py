"""Read-only inspection of first joint trace qualification failure."""
import json
from pathlib import Path
root=Path('/data/pyptouser/yejia/lc128/retest192-native1-b24000')
summary=[]
traces=[]
for rank in range(16):
    rows=[json.loads(s) for s in (root/f'input-trace/rank{rank}.trace.jsonl').read_text().splitlines()]
    audit=json.loads((root/f'input-trace/rank{rank}.audit.json').read_text())
    data=json.loads((root/f'rank{rank}.mixed.json').read_text())
    def compact(row):
        return {k:row[k] for k in ('forward_index','execute_index','active','actual_tokens','padded_tokens','dp_tokens_across_ranks','keys')}
    summary.append({'rank':rank,'count':len(rows),'active':sum(r['active'] for r in rows),
                    'first':[compact(r) for r in rows[:3]],'last':[compact(r) for r in rows[-3:]],
                    'audit':audit,'output_lengths':[len(r['output_token_ids']) for r in data['requests']]})
    traces.append(rows)
(root/'joint-inspection.json').write_text(json.dumps(summary,indent=2)+'\n')
for r in summary:
    print(json.dumps({k:r[k] for k in ('rank','count','active','first','last')}))
reference=traces[0]
for rank,rows in enumerate(traces[1:],1):
    for index,(a,b) in enumerate(zip(reference,rows)):
        keys=('dp_tokens_across_ranks','actual_tokens','keys','input_ids','positions','seq_lens','query_bounds')
        changed=[key for key in keys if a[key]!=b[key]]
        if changed:
            print('FIRST_CROSS_RANK',rank,index,changed)
            break
    else:
        print('PREFIX_CROSS_RANK',rank,min(len(reference),len(rows)))
