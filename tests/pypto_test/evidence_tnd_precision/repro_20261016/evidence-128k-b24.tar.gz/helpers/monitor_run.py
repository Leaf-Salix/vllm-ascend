"""Read progress of one explicitly selected diagnostic output directory."""
import argparse,json
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('label')
args=parser.parse_args()
if args.label not in ('retest192-native1-b24000','retest192-native2-b24000','retest192-precision-b24000'):
    raise ValueError('Explicit diagnostic output only')
root=Path('/data/pyptouser/yejia/lc128')/args.label
report={}
log=root/'rank0.log'
if log.is_file():
    report['last_log_lines']=log.read_text(errors='replace').splitlines()[-4:]
trace=root/'input-trace/rank0.trace.jsonl'
if trace.is_file():
    report['rank0_raw_forward_records']=len(trace.read_text().splitlines())
for name in ('full-probe/STOP.json','full-probe/complete.json','input-trace/rank0.STOP.json'):
    path=root/name
    if path.is_file():
        report[name]=json.loads(path.read_text())
print(json.dumps(report))
