"""Read progress of one explicitly selected diagnostic output directory."""
import argparse,json
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('label')
args=parser.parse_args()
if args.label not in ('plan8k-native1-b22000','plan8k-native2-b22000','plan8k-precision-b22000'):
    raise ValueError('Explicit diagnostic output only')
root=Path('/data/pyptouser/yejia/lc128')/args.label
report={}
log=root/'rank0.log'
if log.is_file():
    report['last_log_lines']=[line[:350] for line in log.read_text(errors='replace').splitlines()[-4:]]
trace=root/'input-trace/rank0.trace.jsonl'
if trace.is_file():
    report['rank0_raw_forward_records']=len(trace.read_text().splitlines())
for name in ('full-probe/STOP.json','full-probe/complete.json','input-trace/rank0.STOP.json'):
    path=root/name
    if path.is_file():
        report[name]=json.loads(path.read_text())
stops = {}
for path in (root/'input-trace').glob('rank*.STOP.json'):
    stops[path.name] = json.loads(path.read_text())
if stops:
    report['all_rank_input_stops'] = stops
failures = {}
for rank in range(16):
    path = root/f'rank{rank}.log'
    if path.is_file():
        lines = path.read_text(errors='replace').splitlines()
        error = next((i for i,line in enumerate(lines) if any(term in line for term in ('Traceback (most recent call last)', 'FULL_PROBE_FIRST_DIFFERENCE', 'INPUT_TRACE_FIRST_DIFFERENCE', 'Unsafe KV allocation plan'))), None)
        if error is not None:
            failures[str(rank)] = [line[:500] for line in lines[error:error+8]]
if failures:
    report['worker_failures'] = failures
print(json.dumps(report))
