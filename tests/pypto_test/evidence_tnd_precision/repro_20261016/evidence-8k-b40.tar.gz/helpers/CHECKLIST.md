# 2026-10-16 8K/B40：共同22000 blocks重测

- 前序24000 blocks：Native两次通过，CSA在生成前被2GiB剩余显存门禁拦下，exit1；不记为精度失败或通过。
- 所有前序文件与结果保留，新目录、新输出，不覆盖。
- 按karpathy-guidelines做最小诊断调整：只将三臂共同KV容量24000改22000；源码、SDK、真实bank、40题、192token、图档[6,240]、见证容量240均不变。
- 原生mem_utils.memory_profiling前后已gc/empty_cache，因此不重复清缓存，不放松21GiB计划/2GiB剩余门禁。
- 三臂重新运行：Native控制→派生生成窗口→Native witness→全16rank输入/token/events重复通过→CSA；不跨不同容量拼接对照。
- 以实际入场轨迹/并发为准；两臂共同容量完全相同；第一差异即停，单任务max-time780。
- 先无设备预检/CPU回归/独立复核，再提交；每次约5min监控，不开schedule。
- 最终结果独立review、写项目MD/JSON、pre-commit后签名commit/push leaf。

- 独立方案复核通过：22000预计upper20,134,406,144bytes，仍逐rank实际检查；40请求逻辑页保守估算10840，混合cache以实际配置为准。
- 13:09无设备预检PASS：路径/SDK/工具链准确，5+10+6项CPU回归通过，40题chat suffix/bank headers完全匹配。
- 13:09:47提交Native控制task_20261016_130947_40242198337；max780，未预提交Native2或CSA。
- Native1于13:16:02完成模型执行，最终exit0（实际约6min）。CPU审计PASS：640请求/122880token、51生成轮，raw55×15/52×1，tail4×15/1×1均保留；新参考manifest SHA d1682907e0ad4fc8fe46eda419ca046617921619337c1c029b3dcb95807c2713。
- 13:16:36提交Native2 task_20261016_131636_170271863，max780，未提交CSA。
- Native2于13:26:20结束，exit0，实际约9min44s。全16rank51轮输入/122880token/完整事件一致；rank0 outer逐bit相同，Native2保存10863模块边界黄金（Native1无内部stage，不称已比较内部全tensor）。
- 13:27:30提交CSA task_20261016_132730_25928429019，max780；同22000容量、同51轮Native参考/黄金，未改数学源码。
- CSA于13:35:36完成，exit0（约8min06s）；未触发首差。51轮有效生成与Native完全相同，CSA raw54×15/52×1，完成后空尾3×15/1×1另行严格校验；不把不同空尾说成原始调度全程相同。
- 无设备数值资格PASS：全16rank输入/122880实际token/完整事件/统计完全一致，40种题0差异，跨DP0/600；rank0 outer与10863边界全部bitexact，21CSA服务与图选择检查PASS，20HCA保持Native。
- 平均接受3.7035909920876446，0..5直方图1696/2432/2816/2592/2240/14512；零抢占，峰40。
- strict READY资格仍FAIL：allready_hits0，rank15 generation/binary各1、build15.753796322s，其他rank等待；所有bypass/invalid/storage/forced为0。单独保留严格失败，不将其改写成缓存通过，不为缓存复用另占卡重跑。
- CPU产物身份核验：本次binary manifest唯一定位READY，冻结源码/toolchain/ABI重算匹配，206项READY哈希与实际任务构建206项全部匹配（门禁收紧为全部存在，非仅>=100）。specialization来自实际manifest，未独立重specialize。
- 所有本线程NPU任务已结束；准备最终原始证据独立复核、MD/JSON与commit/push。
