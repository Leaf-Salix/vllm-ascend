"""CPU-only source/toolchain and immutable READY artifact identity check."""
import hashlib
import json
import os
from pathlib import Path

from pypto._cache_config import capture_cache_config
from pypto._identity import digest_record, fingerprint_extra_sources
from pypto.jit._toolchain import capture_toolchain
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.decode_csa import decode_csa_tp1_layer_test

job = Path(__file__).resolve().parent
cache = job.parent/'low-acceptance-20261010/jit-cache-package/artifacts'
build = Path('/data/pyptouser/yejia/lc128/plan8k-precision-b22000/build/pypto-build-9lqsb8r6')
binary_digest = hashlib.sha256((build/'binary_manifest.json').read_bytes()).hexdigest()
candidates = [p.parent for p in cache.glob('*/*/*/ready/binary_manifest.json')
              if hashlib.sha256(p.read_bytes()).hexdigest() == binary_digest]
if len(candidates) != 1:
    raise ValueError('Task binary manifest must identify exactly one READY artifact')
ready = candidates[0]
manifest = json.loads((ready/'artifact_manifest.json').read_text())
config = capture_cache_config(None)
extra = fingerprint_extra_sources(config.extra_source_paths, config.extra_fingerprint)
source = decode_csa_tp1_layer_test._persistent_source_digest()
expected_source = digest_record((source, extra.digest))
identity = capture_toolchain('a2a3', 'tensormap_and_ringbuffer')
# Same identity record serializer used by ArtifactKey; inspect rather than assume fields.
from pypto.jit._artifact_manifest import ArtifactKey
expected = ArtifactKey(identity, expected_source, manifest['components']['specialization']).record()
if expected != manifest['components']:
    raise ValueError(json.dumps({'expected': expected, 'actual': manifest['components']}))
for item in manifest['files']:
    path = ready/item['path']
    if path.stat().st_size != item['size'] or hashlib.sha256(path.read_bytes()).hexdigest() != item['sha256']:
        raise ValueError('Artifact corruption: '+item['path'])
meta = json.loads((ready/'compiled_meta.json').read_text())
if meta['kernel_abi']['simpler_revision'] != 'a54c0509552b01e13fb0960e23ce409a01b5024f':
    raise ValueError('Unexpected Simpler ABI')
shared = {}
for item in manifest['files']:
    candidate = build/item['path']
    if candidate.is_file():
        digest = hashlib.sha256(candidate.read_bytes()).hexdigest()
        if digest != item['sha256']:
            raise ValueError('Task build/artifact differs: '+str(candidate))
        shared[item['path']] = digest
if len(shared) != len(manifest['files']) or 'compiled_meta.json' not in shared or 'binary_manifest.json' not in shared:
    raise ValueError('Task build binding incomplete')
proof = {'task_build_directory': str(build), 'task_build_shared_files_sha256': shared, 'pass': True, 'scope': 'CPU recomputed frozen precision JIT source and toolchain identity; full artifact content hashes; specialization recorded from actual immutable manifest, not independently re-specialized',
         'artifact_path': str(ready), 'artifact_key': manifest['key'],
         'components': manifest['components'], 'recomputed_source_digest': source,
         'extra_source_digest': extra.digest, 'files_verified': len(manifest['files']),
         'simpler_revision': meta['kernel_abi']['simpler_revision'],
         'abi_params': meta['kernel_abi']['params'],
         'metadata_sha256': {name: hashlib.sha256((ready/name).read_bytes()).hexdigest() for name in ('artifact_manifest.json','binary_manifest.json','compiled_meta.json')},
         'environment': {k: os.environ.get(k) for k in ('PTOAS_ROOT','ASCEND_HOME_PATH','VLLM_ASCEND_ENABLE_NZ','PYPTO_CACHE_DIR')}}
folder = job/'artifact-proof'
folder.mkdir(exist_ok=True)
for name in ('artifact_manifest.json','binary_manifest.json','compiled_meta.json'):
    (folder/name).write_bytes((ready/name).read_bytes())
(job/'artifact-identity-qualified.json').write_text(json.dumps(proof, indent=2)+'\n')
print(json.dumps({k:v for k,v in proof.items() if k not in ('abi_params','components','task_build_shared_files_sha256')}))
