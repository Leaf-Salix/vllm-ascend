#!/usr/bin/env bash
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/root-fix-20261016/env.sh"
export PYTHONPATH="$base/plan-align8k-b22000-20261016:$PYTHONPATH"
