"""Check all 16 workers selected the precision CSA graph at the tested buckets."""
import argparse
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('root', type=Path)
parser.add_argument('--bucket', type=int, required=True)
parser.add_argument('--first-tokens', type=int, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
expected = {f'model.layers.{i}.self_attn.attn' for i in range(2,43,2)}
reports = []
for rank in range(16):
    data = json.loads((args.root/f'rank{rank}.mixed.json').read_text())
    obs = data['observation'][0]
    if set(obs['target_layer_names']) != expected or set(obs['capture_time_selection']) != expected:
        raise ValueError('Incomplete 21-layer CSA selection records')
    for name,counts in obs['capture_time_selection'].items():
        if any(counts.get(f'pto_tokens{tokens}',0) < 1 for tokens in (6,args.bucket,args.first_tokens)):
            raise ValueError(f'rank{rank}/{name}: missing actual PTO selection')
    identity = obs['pypto_runtime_identity']
    runtime = json.loads((args.root/'configuration.json').read_text())['runtime_package']
    if identity['package'] != str(Path(runtime)/'pypto/__init__.py') or str(Path(runtime)/'pypto') not in identity['core']:
        raise ValueError('PTO runtime package identity mismatch')
    if obs['model_forward_counts'].get(f'FULL_tokens{args.bucket}',0) < 1:
        raise ValueError('No actual FULL replay')
    for worker in data['attention_implementations']:
        csa = [x for x in worker if x['kind']=='csa']
        hca = [x for x in worker if x['kind']=='hca']
        if len(csa)!=21 or len(hca)!=20 or any(x['implementation']!='native' for x in hca):
            raise ValueError('Wrong HCA selection')
        if any(x['implementation']!='pto' or not x['runtime_class'].endswith('.deepseek_v4_flash_csa_tnd_precision.service') for x in csa):
            raise ValueError('Wrong CSA variant')
    reports.append({'rank':rank,'csa_selected_layers':len(expected),'tested_bucket':args.bucket,
                    'full_replays':obs['model_forward_counts'][f'FULL_tokens{args.bucket}'],
                    'capture_time_selection':obs['capture_time_selection']})
report={'pass':True,'ranks':reports,'scope':'Native observer eligibility counter during warmup/capture/Python execution, plus actual model FULL replay and source/runtime identity; not a per-layer runtime replay hook counter'}
args.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'pass':True,'ranks':16,'csa_layers_per_rank':21,'bucket':args.bucket,'scope':report['scope']}))
