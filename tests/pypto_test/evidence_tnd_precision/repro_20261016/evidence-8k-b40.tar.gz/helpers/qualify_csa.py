"""Numerical qualification with explicit independent strict READY result."""
import json
import re
import subprocess
import sys
from pathlib import Path
from qualify192 import qualify

job = Path(__file__).resolve().parent
base = Path('/data/pyptouser/yejia/lc128')
left, right = base/'plan8k-native2-b22000', base/'plan8k-precision-b22000'
try:
    result = qualify(left, right, 'csa')
    strict = {'pass':True,'scope':'default strict qualification including READY reuse'}
except ValueError as error:
    if re.fullmatch(r'rank\d+: READY reuse failed',str(error)) is None:
        raise
    strict = {'pass':False,'error':str(error),'scope':'default strict qualification including READY reuse; retained as failed'}
    result = qualify(left, right, 'csa', require_ready_reuse=False)
(job/'csa-strict-qualification.json').write_text(json.dumps(strict,indent=2)+'\n')
cache = []
for rank in range(16):
    data = json.loads((right/f'rank{rank}.mixed.json').read_text())
    stats = data['observation'][0]['pypto_cache_stats']
    if any(stats[k]!=0 for k in ('bypasses','invalid_entries','storage_errors','forced_rebuilds')):
        raise ValueError(f'rank{rank}: cache errors/bypasses')
    cache.append({'rank':rank,'stats':stats})
subprocess.run([sys.executable,str(job/'audit_selection.py'),str(right),'--bucket','240','--first-tokens','40','--output',str(job/'selection8k-qualified.json')],check=True)
result['strict_ready_reuse_pass'] = strict['pass']
result['cache_stats_from_raw_observations'] = cache
result['cache_error_counters_zero_all16'] = True
result['all16_precision_csa_graph_selection_pass'] = True
result['scope'] += '; rank0 float witnesses only; no performance; strict READY result reported separately'
(job/'csa-numerics-qualified.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('cache_stats_from_raw_observations','left_observed','right_observed','acceptance')}))
