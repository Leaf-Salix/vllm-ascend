"""Report original token IDs, request/event changes and DP replicas separately."""
import argparse
import json
from pathlib import Path

from low_acceptance_20261001.reference import extract

parser = argparse.ArgumentParser()
parser.add_argument('left', type=Path)
parser.add_argument('right', type=Path)
parser.add_argument('--output', required=True, type=Path)
args = parser.parse_args()
left, right = extract(args.left), extract(args.right)
if [(r['rank'],r['key']) for r in left] != [(r['rank'],r['key']) for r in right]:
    raise ValueError('Request identities differ')
logical_output, logical_stats, logical_events = set(), set(), set()
changed_tokens = changed_requests = changed_stats = changed_events = 0
first = None
for a,b in zip(left,right,strict=True):
    if len(a['tokens']) != 192 or len(b['tokens']) != 192:
        raise ValueError('Incomplete output')
    differences = [i for i,(x,y) in enumerate(zip(a['tokens'],b['tokens'],strict=True)) if x!=y]
    if differences:
        changed_tokens += len(differences)
        changed_requests += 1
        logical_output.add(a['key'])
        if first is None or differences[0]+1 < first['token_position_1based']:
            first = {'rank':a['rank'],'key':a['key'],'token_position_1based':differences[0]+1}
    if any(a[k]!=b[k] for k in ('drafts','proposed','accepted','histogram')):
        changed_stats += 1
        logical_stats.add(a['key'])
    if a['events'] != b['events']:
        changed_events += 1
        logical_events.add(a['key'])

def cross_dp(rows):
    rank0 = {r['key']:r for r in rows if r['rank']==0}
    result = {'compared_replica_requests':len(rows)-len(rank0),'output_different':0,'events_different':0,'stats_different':0}
    for row in rows:
        if row['rank']==0:continue
        base = rank0[row['key']]
        result['output_different'] += row['tokens'] != base['tokens']
        result['events_different'] += row['events'] != base['events']
        result['stats_different'] += any(row[k]!=base[k] for k in ('drafts','proposed','accepted','histogram'))
    return result

report = {'left':str(args.left),'right':str(args.right),'replica_requests':len(left),
          'distinct_questions':len({r['key'] for r in left}),'tokens_per_request':192,'output_token_positions':192*len(left),
          'different_token_positions':changed_tokens,'different_output_replica_requests':changed_requests,
          'different_stats_replica_requests':changed_stats,'different_events_replica_requests':changed_events,
          'different_output_questions':len(logical_output),'different_stats_questions':len(logical_stats),'different_events_questions':len(logical_events),
          'first_token_difference':first,'left_cross_dp':cross_dp(left),'right_cross_dp':cross_dp(right)}
args.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
