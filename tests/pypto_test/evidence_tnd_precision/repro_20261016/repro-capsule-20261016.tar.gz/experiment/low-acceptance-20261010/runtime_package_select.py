"""Use a complete private PyPTO package through ordinary filesystem imports."""
import hashlib
import json
import os
from pathlib import Path
import sys
from importlib.machinery import PathFinder

ROOT = Path(os.environ['LOW_ACCEPTANCE_RUNTIME_PACKAGE']).resolve()
PACKAGE = ROOT/'pypto'
MANIFEST = ROOT/'manifest.json'
assert ROOT.stat().st_uid == os.getuid() and not ROOT.is_symlink()
assert 'pypto' not in sys.modules, 'Select the private package before any framework import'
data = json.loads(MANIFEST.read_text())
for relative, digest in data['files'].items():
    path = ROOT/relative
    assert path.resolve().is_relative_to(PACKAGE) and not path.is_symlink(), relative
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, relative

class PackageFinder:
    @staticmethod
    def find_spec(fullname, path=None, target=None):
        if fullname != 'pypto' and not fullname.startswith('pypto.'):
            return None
        roots = [str(ROOT)] if fullname == 'pypto' else path
        if fullname != 'pypto':
            assert roots and all(Path(p).resolve().is_relative_to(PACKAGE) for p in roots)
        spec = PathFinder.find_spec(fullname, roots)
        if spec is None:
            raise ImportError(f'Missing private PyPTO module: {fullname}')
        if spec.origin:
            assert Path(spec.origin).resolve().is_relative_to(PACKAGE), spec.origin
        return spec

sys.meta_path.insert(0, PackageFinder)
