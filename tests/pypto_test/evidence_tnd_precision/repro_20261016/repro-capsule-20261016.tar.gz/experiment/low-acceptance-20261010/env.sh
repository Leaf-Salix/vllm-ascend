#!/usr/bin/env bash
export SOURCE_ROOT=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/low-acceptance-20261010/source
source /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/bin/env.sh
export PYTHONPATH=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/low-acceptance-20261010:$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH
export PTO_CSA_VARIANT=tnd_precision HCCL_DETERMINISTIC=true
export VLLM_ASCEND_PTO_CSA_ATOMIC_ADD=0 PTO_CSA_RUNTIME=tensormap_and_ringbuffer
export LOCAL_WORLD_SIZE=16 OMP_NUM_THREADS=10 OMP_PROC_BIND=false
if [[ -n ${LOW_ACCEPTANCE_RUNTIME_PACKAGE:-} ]]; then
  export PYPTO_CACHE=1 PYTHONDONTWRITEBYTECODE=1
  export PYPTO_CACHE_DIR=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/low-acceptance-20261010/jit-cache-package
fi
