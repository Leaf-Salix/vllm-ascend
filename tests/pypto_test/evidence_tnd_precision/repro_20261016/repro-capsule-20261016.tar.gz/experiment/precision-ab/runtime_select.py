"""Reuse a complete, already-built PyPTO/Simpler pair without installing packages."""
import sys
from pathlib import Path
from importlib.machinery import PathFinder

WORK = Path('/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3')
SOURCE = WORK / 'pypto-reference'
SITE = WORK / 'reference-env/lib/python3.12/site-packages'

class RuntimeFinder:
    @staticmethod
    def find_spec(fullname, path=None, target=None):
        roots = {'pypto': SOURCE / 'python', 'simpler': SOURCE / 'runtime/python',
                 'simpler_setup': SOURCE / 'runtime', '_task_interface': SITE,
                 'pypto.pypto_core': SITE / 'pypto', 'pypto._torch_npu': SITE / 'pypto'}
        if fullname in roots:
            return PathFinder.find_spec(fullname, [str(roots[fullname])])
        if fullname.startswith(('pypto.', 'simpler.', 'simpler_setup.')):
            return PathFinder.find_spec(fullname, path)
        return None

sys.meta_path.insert(0, RuntimeFinder)
