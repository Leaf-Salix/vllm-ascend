#!/usr/bin/env bash
root=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1
unset PYTHONPATH LD_LIBRARY_PATH LD_PRELOAD ASCEND_HOME_PATH
set +u
source "$root/env/Ascend/cann-9.0.1/set_env.sh"
source "$root/env/Ascend/nnal/atb/set_env.sh" --cxx_abi=1
set -u
export PATH="$root/env/bin:/usr/local/ptoas/0.63/bin:$PATH"
export PTOAS_ROOT=/usr/local/ptoas/0.63/bin
export PYTHONNOUSERSITE=1 TORCH_DEVICE_BACKEND_AUTOLOAD=0
export PYTHONPATH="$root/src/vllm-ascend:$root/src/vllm:$root/env/lib/python3.12/site-packages:${PYTHONPATH:-}"
export LD_LIBRARY_PATH="$root/env/lib/python3.12/site-packages/torch/lib:$root/env/lib/python3.12/site-packages/torch_npu/lib:${LD_LIBRARY_PATH:-}"
export TMPDIR="$root/tmp" PIP_CACHE_DIR="$root/cache/pip" XDG_CACHE_HOME="$root/cache/xdg"
export CMAKE_BUILD_PARALLEL_LEVEL=4 MAX_JOBS=4 SOC_VERSION=ascend910_9392
export PIP_INDEX_URL=https://mirrors.huaweicloud.com/repository/pypi/simple
export PIP_EXTRA_INDEX_URL=https://mirrors.huaweicloud.com/ascend/repos/pypi
unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY ALL_PROXY all_proxy
