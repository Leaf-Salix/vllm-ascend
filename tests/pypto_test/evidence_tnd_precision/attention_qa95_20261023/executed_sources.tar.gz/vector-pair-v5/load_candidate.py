"""Native pair检查共享读取单因素与已验收组合版；不修改共享原模块。"""
import importlib,importlib.util,sys,json,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent
C='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_combined'
S='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd'
def load(name,path):
    if name in sys.modules:return sys.modules[name]
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec)
    sys.modules[name]=m;spec.loader.exec_module(m);return m
def entry_for(arm):
    proof=json.loads((HERE/'SOURCE.json').read_text())
    for rel,sha in proof['candidates'].items():assert hashlib.sha256((HERE/rel).read_bytes()).hexdigest()==sha,rel
    if arm=='baseline':arm='h3'
    assert arm in ('h3','combo3','vector')
    if arm in ('h3','combo3','vector'):
        load(S+'.gap_h3_cube',HERE/'h3_cube.py')
        load(C+'.gap_h3_prefix',HERE/'h3_prefix.py')
    if arm in ('combo2',):
        load('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.gap_checked_sparse',HERE/'checked_sparse.py')
    if arm in ('combo3','vector'):
        load('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.gap_'+arm+'_sparse',HERE/(arm+'_sparse.py'))
    return load(C+'.gap_'+arm+'_root',HERE/(arm+'_root.py')).decode_csa_tp1_layer_test

def operators_for(arm):
    namespace_arm='h3' if arm=='baseline' else arm
    import pypto.torch
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.native_adapter import CSAOperators
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_prepack.native_adapter import PrepackedWorkspace
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_prepack.prefix import prepack_fixed_hc_weight
    op=pypto.torch.register(entry_for(arm),'csa_gap_'+namespace_arm+'::attention')
    prepare=pypto.torch.register(prepack_fixed_hc_weight,'csa_gap_'+namespace_arm+'::prepare')
    return CSAOperators(op,PrepackedWorkspace(prepare))
