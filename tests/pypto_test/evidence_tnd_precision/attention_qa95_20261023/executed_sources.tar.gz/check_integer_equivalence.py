"""直接执行两个 DSL 的 Scalar AST，核验 Native pair 地址契约。无框架/设备。"""

import ast
import copy
import json
import random
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
BASE = HERE.parents[1] / "vllm-ascend-nalinaly-tnd-20261008-codex"
ORIGINAL = BASE / "vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision/decode_sparse_attn_csa.py"
CANDIDATE = HERE / "checked/checked_sparse.py"


class Table:
    def __init__(self, rows, width=None):
        self.rows = rows
        self.shape = (len(rows), len(rows[0]) if rows else width)

    def read(self, index):
        if len(index) == 1:
            assert 0 <= index[0] < self.shape[0], index
            return self.rows[index[0]][0]
        row, column = index
        assert 0 <= row < self.shape[0] and 0 <= column < self.shape[1], index
        return self.rows[row][column]


class ScalarPL:
    INT32 = "int32"
    INDEX = "index"
    tensor = SimpleNamespace(dim=lambda x, axis: x.shape[axis])
    range = staticmethod(range)

    @staticmethod
    def cast(value, dtype):
        value = int(value)
        return ((value + 2**31) % 2**32 - 2**31) if dtype == "int32" else value

    @staticmethod
    def read(table, index):
        return table.read(index)

    @staticmethod
    def write(table, index, value):
        row, column = index
        table.rows[row][column] = value


def executable(path):
    tree = ast.parse(path.read_text())
    helpers = []
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in (
            "checked_compressed_index", "native_compressed_pair_swap"
        ):
            node = copy.deepcopy(node)
            node.decorator_list = []
            for arg in node.args.args:
                arg.annotation = None
            helpers.append(node)
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "sparse_attn_csa")
    loop = next(node for node in ast.walk(function) if isinstance(node, ast.For) and isinstance(node.target, ast.Name) and node.target.id == "checked_t")
    wrapper = ast.parse("def run(position_ids, token_request, seq_lens, cmp_block_table, idx_topk, cmp_sparse_indices):\n    checked_t = 0\n").body[0]
    wrapper.body.extend(copy.deepcopy(loop.body))
    module = ast.fix_missing_locations(ast.Module(body=helpers + [wrapper], type_ignores=[]))
    env = dict(pl=ScalarPL, BLOCK_SIZE=32, HEAD_DIM=512, KV_ELEMENT_BYTES=2,
               KV_PAIR_MAX_STRIDE_BYTES=2**31 - 1, COMPRESS_RATIO=4, IDX_TOPK=2)
    exec(compile(module, str(path), "exec"), env)
    return env["run"]


def main():
    old, new = executable(ORIGINAL), executable(CANDIDATE)
    rng = random.Random(1024)
    cases = []
    # Invalid request/seq/page, duplicate/final index, INT32/INDEX boundary,
    # physical pair sorting and exact stride overflow fallback.
    for limit in (0, 1, 2, 31, 32, 33, 511, 512, 262144, 2**31):
        for request in (-1, 0, 1):
            for length in (0, 1):
                for first, second in ((-1, -1), (-2, 0), (0, 0), (1, 0), (limit - 1, 0), (limit, 0), (2**31 - 1, 0)):
                    for pages in ((0, 1), (1, 0), (-1, 0), (65536, 0), (65537, 0)):
                        cases.append((limit, request, length, first, second, list(pages)))
    for _ in range(10000):
        limit = rng.randrange(1, 2048)
        cases.append((limit, 0, rng.choice((0, 1, 1, 1)), rng.randrange(-2, limit + 3),
                      rng.randrange(-2, limit + 3), [rng.choice((-1, 0, 1, 65536, 65537)) for _ in range(rng.randrange(1, 65))]))
    for index, (limit, request, length, first, second, pages) in enumerate(cases):
        args = (Table([[limit * 4 - 1]]), Table([[request]]),
                SimpleNamespace(shape=(1,), read=lambda idx: length if idx == [0] else (_ for _ in ()).throw(AssertionError(idx))),
                Table([pages]), Table([[first, second]]))
        left, right = Table([[99, 99]]), Table([[99, 99]])
        old(*args, left)
        new(*args, right)
        assert left.rows == right.rows, (index, cases[index], left.rows, right.rows)
    result = {"pass": True, "cases": len(cases), "method": "execute original and candidate scalar AST; bounds-check every table read; explicit INT32 cast wrapping", "device_execution": False}
    (HERE / "checked/INTEGER_EQUIVALENCE.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
