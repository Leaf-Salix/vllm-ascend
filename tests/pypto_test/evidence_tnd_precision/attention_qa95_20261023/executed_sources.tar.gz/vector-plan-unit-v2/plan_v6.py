# Copyright (c) PyPTO Contributors.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# -----------------------------------------------------------------------------------------------------------

"""CSA integration dependency adapted from pypto-lib 205255b4/decode_sparse_attn_csa.py."""

import pypto.language as pl

from .config import (
    BLOCK_SIZE,
    DECODE_BATCH,
    DECODE_SEQ,
    KV_ORI_BLOCK_NUM,
    TP,
)
from .config import (
    FLASH as M,
)
from .layout import COMPRESSED_TABLE_COLUMNS_DYN, ORIGINAL_TABLE_COLUMNS_DYN

if BLOCK_SIZE != 32:
    raise ValueError("Vector pair-plan requires the Native 32-row page contract")

B_DYN = pl.dynamic("B_DYN")  # per-request axis (block tables)

T_DYN = pl.dynamic("T_DYN")  # Packed token axis, including graph capacity rows.

ORI_BLOCK_NUM_DYN = pl.dynamic("ORI_BLOCK_NUM_DYN")

CMP_BLOCK_NUM_DYN = pl.dynamic("CMP_BLOCK_NUM_DYN")

B = DECODE_BATCH // TP

S = DECODE_SEQ

T = B * S

D = M.hidden_size

H = M.num_attention_heads

HEAD_DIM = M.head_dim

ROPE_DIM = M.qk_rope_head_dim

NOPE_DIM = M.nope_head_dim

WIN = M.sliding_window

MAX_SEQ_LEN = M.max_position_embeddings

IDX_TOPK = M.index_topk

CMP_TOPK = IDX_TOPK

SOFTMAX_SCALE = M.softmax_scale

O_LORA = M.o_lora_rank

O_GROUPS = M.o_groups

HEADS_PER_GROUP = H // O_GROUPS

O_GROUP_IN = HEADS_PER_GROUP * HEAD_DIM

COMPRESS_RATIO = 4

COMPRESS_RATIO_INV = 1.0 / COMPRESS_RATIO

CSA_CMP_GE_BIAS = 1.0  # raw + 1, folded for the ge clamp

NEG_INF = -1.0e20

ORI_MAX_BLOCKS = (MAX_SEQ_LEN + BLOCK_SIZE - 1) // BLOCK_SIZE

ORI_BLOCK_NUM = KV_ORI_BLOCK_NUM

CMP_MAX_BLOCKS = (MAX_SEQ_LEN // COMPRESS_RATIO + BLOCK_SIZE - 1) // BLOCK_SIZE

H_TILE = 16

MERGE_WORKERS = 48

QK_KV_READY_EVENT = 0

QK_SCORE_READY_EVENT = 1

QK_PROB_READY_EVENT = 2

QK_PV_READY_EVENT = 3

# Native A3 softmax rounds probabilities after each 512-candidate update.
# Cube transfers remain smaller so Q and KV fit in A3 L1 together.
ATTN_K_TILE = 512

ATTN_CUBE_KV_TILE = 128

SOFTMAX_HEAD_TILE = 8

NUM_QK_CORES = 24  # qk_pv dispatch lanes

CSA_PLAN_WORKERS = 16  # csa_slots_build_valid_qk_plan token-tile lanes

T_PAD = ((T + 16 - 1) // 16) * 16  # Cube M floor

ATTENTION_PUBLISH_WORKERS = 48

ATTENTION_PUBLISH_T_TILE = 4

LOCAL_O_GROUPS = O_GROUPS // TP

GROUP_T_PAD = TP * T_PAD

ATTENTION_WINDOW_ROWS = LOCAL_O_GROUPS * GROUP_T_PAD

PUBLISH_GROUPS = H_TILE // HEADS_PER_GROUP

# 每块正好一个请求：上游 e68e091 把 RoPE 行块绑定到 S，S=6 时 t_dim=batch*S 整除，
# 不再有尾块。原值 8 与 S 无关，batch*6 常不是 8 的倍数，每轮都要处理残块。
ROPE_CS_T_TILE = S
ROPE_CS_WORKERS = 16

TOPK = WIN + CMP_TOPK

SPARSE_BLOCKS = 1 + (CMP_TOPK + ATTN_K_TILE - 1) // ATTN_K_TILE

MASK_LINE_ELEMS = 64 // 4

VALID_BLOCK_MASK_COLS = ((SPARSE_BLOCKS + MASK_LINE_ELEMS - 1) // MASK_LINE_ELEMS) * MASK_LINE_ELEMS

PADDED_TOPK = SPARSE_BLOCKS * ATTN_K_TILE

KV_PAIR_MAX_STRIDE_BYTES = (1 << 31) - 1
KV_ELEMENT_BYTES = 2  # This CSA path requires Native BF16 KV.

SWA_TILE_WIN_ROWS = min(ATTN_K_TILE, WIN)

SWA_RUNS = (min(ATTN_CUBE_KV_TILE, WIN) + 2 * (BLOCK_SIZE - 1)) // BLOCK_SIZE

BIAS_T_TILE = min(T, 8)

if T % BIAS_T_TILE != 0:
    raise ValueError("CSA token capacity must contain complete bias tiles")

if H_TILE % HEADS_PER_GROUP != 0:
    raise ValueError(f"CSA head tile {H_TILE} must contain complete output groups")

if PUBLISH_GROUPS != 2:
    raise ValueError("CSA TP1 merge requires exactly two output groups per head tile")

if O_GROUPS % TP != 0:
    raise ValueError(f"output groups {O_GROUPS} must be divisible by TP size {TP}")

if LOCAL_O_GROUPS % PUBLISH_GROUPS != 0:
    raise ValueError("local output groups must contain complete CSA publish tiles")

if T % ATTENTION_PUBLISH_T_TILE != 0:
    raise ValueError("local token capacity must contain complete attention publish tiles")


@pl.jit.inline(auto_scope=False)
def checked_compressed_index(
    candidate: pl.Scalar[pl.INT32],
    request: pl.Scalar[pl.INT32],
    position: pl.Scalar[pl.INDEX],
    seq_lens: pl.Tensor[[B_DYN], pl.INT32],
    table: pl.Tensor[[B_DYN, COMPRESSED_TABLE_COLUMNS_DYN], pl.INT32],
):
    checked = pl.cast(-1, pl.INT32)
    if request >= 0 and request < pl.tensor.dim(seq_lens, 0):
        if pl.read(seq_lens, [request]) > 0:
            if candidate >= 0 and candidate < (position + 1) // COMPRESS_RATIO:
                column = candidate // BLOCK_SIZE
                if column < pl.tensor.dim(table, 1):
                    if pl.read(table, [request, column]) >= 0:
                        checked = candidate
    return checked


@pl.jit.inline(auto_scope=False)
def native_compressed_pair_swap(
    first: pl.Scalar[pl.INT32],
    second: pl.Scalar[pl.INT32],
    request: pl.Scalar[pl.INT32],
    limit: pl.Scalar[pl.INDEX],
    table: pl.Tensor[[B_DYN, COMPRESSED_TABLE_COLUMNS_DYN], pl.INT32],
):
    # Native SCFA CopyInKv merges a pair from the lower physical address.
    # Its overflow/duplicate/final-index fallback preserves input slot order.
    swap = pl.cast(0, pl.INT32)
    first_index = pl.cast(first, pl.INDEX)
    second_index = pl.cast(second, pl.INDEX)
    if first >= 0 and second >= 0:
        if first_index + 1 < limit and second_index + 1 < limit:
            first_page = pl.cast(pl.read(table, [request, first_index // BLOCK_SIZE]), pl.INDEX)
            second_page = pl.cast(pl.read(table, [request, second_index // BLOCK_SIZE]), pl.INDEX)
            first_row = first_page * BLOCK_SIZE + first_index % BLOCK_SIZE
            second_row = second_page * BLOCK_SIZE + second_index % BLOCK_SIZE
            if first_row > second_row:
                stride_bytes = (first_row - second_row - 1) * HEAD_DIM * KV_ELEMENT_BYTES
                if stride_bytes < KV_PAIR_MAX_STRIDE_BYTES:
                    swap = pl.cast(1, pl.INT32)
    return swap


@pl.jit.inline(auto_scope=False)
def vector_native_pair_indices(
    raw: pl.Tile[[1, IDX_TOPK], pl.INT32],
    pages: pl.Tile[[1, IDX_TOPK], pl.INT32],
    columns: pl.Tile[[1, IDX_TOPK], pl.INT32],
    column_count: pl.Scalar[pl.INT32],
    limit: pl.Scalar[pl.INT32],
):
    # Preconditions: 0<=limit<=INT32_MAX, 0<columns<=2048,
    # selected nonnegative pages<2**24. All address arithmetic stays INT32;
    # row differences fit signed32 and the byte-stride comparison is exact.
    scratch=pl.create_tile([1,16],dtype=pl.UINT32)
    missing=pl.tile.full([1,IDX_TOPK],dtype=pl.INT32,value=-1)
    checked=pl.tile.sel(pl.tile.cmps(pl.cast(raw,pl.FP32),0.0,cmp_type=5),raw,missing,scratch)
    checked=pl.tile.sel(pl.tile.cmps(pl.cast(pl.tile.adds(pl.tile.maximums(raw,0),pl.cast(-limit,pl.INT32)),pl.FP32),0.0,cmp_type=2),checked,missing,scratch)
    checked=pl.tile.sel(pl.tile.cmps(pl.cast(pl.tile.adds(columns,pl.cast(-column_count,pl.INT32)),pl.FP32),0.0,cmp_type=2),checked,missing,scratch)
    checked=pl.tile.sel(pl.tile.cmps(pl.cast(pages,pl.FP32),0.0,cmp_type=5),checked,missing,scratch)
    safe_raw=pl.tile.maximums(raw,0)
    physical=pl.tile.add(pl.tile.shls(pl.tile.maximums(pages,0),5),pl.tile.sub(safe_raw,pl.tile.shls(pl.tile.shrs(safe_raw,5),5)))
    pair_columns=pl.tile.muls(pl.tile.ci(0,[1,IDX_TOPK//2],dtype=pl.INT32),2)
    odd_columns=pl.tile.adds(pair_columns,1)
    gather_tmp=pl.create_tile([1,IDX_TOPK//2],dtype=pl.INT32)
    first=pl.tile.gather(checked,pair_columns,gather_tmp)
    second=pl.tile.gather(checked,odd_columns,gather_tmp)
    first_row=pl.tile.gather(physical,pair_columns,gather_tmp)
    second_row=pl.tile.gather(physical,odd_columns,gather_tmp)
    difference=pl.tile.sub(first_row,second_row)
    zero=pl.tile.full([1,IDX_TOPK//2],dtype=pl.INT32,value=0)
    swap=pl.tile.full([1,IDX_TOPK//2],dtype=pl.INT32,value=1)
    swap=pl.tile.sel(pl.tile.cmps(pl.cast(first,pl.FP32),0.0,cmp_type=5),swap,zero,scratch)
    swap=pl.tile.sel(pl.tile.cmps(pl.cast(second,pl.FP32),0.0,cmp_type=5),swap,zero,scratch)
    swap=pl.tile.sel(pl.tile.cmps(pl.cast(pl.tile.adds(first,pl.cast(1-limit,pl.INT32)),pl.FP32),0.0,cmp_type=2),swap,zero,scratch)
    swap=pl.tile.sel(pl.tile.cmps(pl.cast(pl.tile.adds(second,pl.cast(1-limit,pl.INT32)),pl.FP32),0.0,cmp_type=2),swap,zero,scratch)
    swap=pl.tile.sel(pl.tile.cmps(pl.cast(difference,pl.FP32),0.0,cmp_type=4),swap,zero,scratch)
    # (difference-1)*1024 < INT32_MAX, without a potentially overflowing mul.
    swap=pl.tile.sel(pl.tile.cmps(pl.cast(difference,pl.FP32),2097152.0,cmp_type=3),swap,zero,scratch)
    output_columns=pl.tile.ci(0,[1,IDX_TOPK],dtype=pl.INT32)
    pair_ids=pl.tile.shrs(output_columns,1)
    output_tmp=pl.create_tile([1,IDX_TOPK],dtype=pl.INT32)
    duplicate_swap=pl.tile.gather(swap,pair_ids,output_tmp)
    offset=pl.tile.sub(pl.tile.full([1,IDX_TOPK],dtype=pl.INT32,value=1),pl.tile.muls(pl.tile.sub(output_columns,pl.tile.shls(pl.tile.shrs(output_columns,1),1)),2))
    order=pl.tile.add(output_columns,pl.tile.mul(duplicate_swap,offset))
    return pl.tile.gather(checked,order,output_tmp)



@pl.jit
def plan(idx_topk: pl.Tensor[[T_DYN, IDX_TOPK], pl.INT32], position_ids: pl.Tensor[[T_DYN, 1], pl.INT64], seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], cmp_block_table: pl.Tensor[[B_DYN, COMPRESSED_TABLE_COLUMNS_DYN], pl.INT32], cmp_sparse_indices: pl.InOut[pl.Tensor[[T_DYN, IDX_TOPK], pl.INT32]]):
    idx_topk.bind_dynamic(0, T_DYN)
    position_ids.bind_dynamic(0, T_DYN)
    seq_lens.bind_dynamic(0, B_DYN)
    token_request.bind_dynamic(0, T_DYN)
    cmp_block_table.bind_dynamic(0, B_DYN)
    cmp_block_table.bind_dynamic(1, COMPRESSED_TABLE_COLUMNS_DYN)
    cmp_sparse_indices.bind_dynamic(0, T_DYN)
    t_dim = pl.tensor.dim(idx_topk, 0)
    with pl.spmd(48, name_hint='csa_checked_indices') as checked_tid:
        checked_worker = pl.tile.get_block_idx()
        for checked_t in pl.range(checked_worker, t_dim, 48):
            c_position = pl.cast(pl.read(position_ids, [checked_t, 0]), pl.INDEX)
            c_request = pl.read(token_request, [checked_t])
            if c_request >= 0 and c_request < pl.tensor.dim(seq_lens, 0):
                if pl.read(seq_lens, [c_request]) > 0:
                    c_limit = (c_position + 1) // COMPRESS_RATIO
                    c_vector_done = pl.cast(0, pl.INT32)
                    c_columns = pl.tensor.dim(cmp_block_table, 1)
                    if c_limit >= 0 and c_limit <= 2147483647 and (c_columns > 0) and (c_columns <= 2048):
                        c_raw_tile = pl.load(idx_topk, [checked_t, 0], [1, IDX_TOPK])
                        c_safe_raw = pl.tile.maximums(c_raw_tile, 0)
                        c_raw_columns = pl.tile.shrs(c_safe_raw, 5)
                        c_safe_columns = pl.tile.minimums(c_raw_columns, pl.cast(c_columns - 1, pl.INT32))
                        c_table_tile = pl.load(cmp_block_table, [c_request, 0], [1, 2048], valid_shape=[1, c_columns])
                        c_page_tile = pl.tile.gather(c_table_tile, c_safe_columns, pl.create_tile([1, IDX_TOPK], dtype=pl.INT32))
                        c_pages_f32 = pl.cast(c_page_tile, pl.FP32)
                        c_max_pages = pl.row_max(pl.reshape(c_pages_f32, [8, IDX_TOPK // 8]), pl.create_tile([8, IDX_TOPK // 8], dtype=pl.FP32))
                        c_pages_safe = pl.cast(1, pl.INT32)
                        for c_page_part in pl.range(8):
                            if pl.read(c_max_pages, [c_page_part, 0]) >= 16777216.0:
                                c_pages_safe = pl.cast(0, pl.INT32)
                        if c_pages_safe > 0:
                            c_reordered = vector_native_pair_indices(c_raw_tile, c_page_tile, c_raw_columns, pl.cast(c_columns, pl.INT32), pl.cast(c_limit, pl.INT32))
                            pl.store(c_reordered, [checked_t, 0], cmp_sparse_indices)
                            c_vector_done = pl.cast(1, pl.INT32)
                    if c_vector_done == 0:
                        c_scalar_output = pl.tile.full([1, IDX_TOPK], dtype=pl.INT32, value=-1)
                        for c_pair in pl.range(IDX_TOPK // 2):
                            c_slot = c_pair * 2
                            c_first = pl.read(idx_topk, [checked_t, c_slot])
                            c_second = pl.read(idx_topk, [checked_t, c_slot + 1])
                            c_first_page = pl.cast(-1, pl.INT32)
                            c_second_page = pl.cast(-1, pl.INT32)
                            if c_first >= 0 and c_first < c_limit:
                                c_first_col = c_first // BLOCK_SIZE
                                if c_first_col < pl.tensor.dim(cmp_block_table, 1):
                                    c_first_page = pl.read(cmp_block_table, [c_request, c_first_col])
                            if c_second >= 0 and c_second < c_limit:
                                c_second_col = c_second // BLOCK_SIZE
                                if c_second_col < pl.tensor.dim(cmp_block_table, 1):
                                    c_second_page = pl.read(cmp_block_table, [c_request, c_second_col])
                            if c_first_page < 0:
                                c_first = pl.cast(-1, pl.INT32)
                            if c_second_page < 0:
                                c_second = pl.cast(-1, pl.INT32)
                            c_first_index = pl.cast(c_first, pl.INDEX)
                            c_second_index = pl.cast(c_second, pl.INDEX)
                            c_swap = pl.cast(0, pl.INT32)
                            if c_first >= 0 and c_second >= 0:
                                if c_first_index + 1 < c_limit and c_second_index + 1 < c_limit:
                                    c_first_row = pl.cast(c_first_page, pl.INDEX) * BLOCK_SIZE + c_first_index % BLOCK_SIZE
                                    c_second_row = pl.cast(c_second_page, pl.INDEX) * BLOCK_SIZE + c_second_index % BLOCK_SIZE
                                    if c_first_row > c_second_row:
                                        c_stride = (c_first_row - c_second_row - 1) * HEAD_DIM * KV_ELEMENT_BYTES
                                        if c_stride < KV_PAIR_MAX_STRIDE_BYTES:
                                            c_swap = pl.cast(1, pl.INT32)
                            if c_swap > 0:
                                pl.tile.write(c_scalar_output, [0, c_slot], c_second)
                                pl.tile.write(c_scalar_output, [0, c_slot + 1], c_first)
                            else:
                                pl.tile.write(c_scalar_output, [0, c_slot], c_first)
                                pl.tile.write(c_scalar_output, [0, c_slot + 1], c_second)
                        pl.store(c_scalar_output, [checked_t, 0], cmp_sparse_indices)
                else:
                    c_inactive = pl.tile.full([1, IDX_TOPK], dtype=pl.INT32, value=-1)
                    pl.store(c_inactive, [checked_t, 0], cmp_sparse_indices)
            else:
                c_missing = pl.tile.full([1, IDX_TOPK], dtype=pl.INT32, value=-1)
                pl.store(c_missing, [checked_t, 0], cmp_sparse_indices)
    return cmp_sparse_indices
