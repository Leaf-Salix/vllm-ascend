import importlib.util,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
P='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.'
def entry(arm):
 name=P+'plan_'+arm
 if name not in sys.modules:
  spec=importlib.util.spec_from_file_location(name,ROOT/('plan_'+arm+'.py'));m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m)
 return sys.modules[name].plan
