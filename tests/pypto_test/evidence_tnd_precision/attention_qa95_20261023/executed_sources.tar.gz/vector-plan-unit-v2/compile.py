import bind,json,hashlib,os
from pathlib import Path
import torch_npu
from load import entry
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program
from pypto.runtime._kernel_artifact import KernelArtifact
r=Path(__file__).resolve().parent
record={'pass':False,'no_npu':True,'source':bind.IDENTITY,'helper_manifest_sha256':hashlib.sha256((r/'manifest.json').read_bytes()).hexdigest(),'sdk':json.loads(Path(os.environ['PREFLIGHT_RECEIPT']).read_text()),'arms':{}}
for arm in ('v5','v6'):
 p=entry(arm).specialize();abi=kernel_abi_for_program(p,platform='a2a3',runtime='tensormap_and_ringbuffer');assert len(abi.parameters)==6
 o=r/('cpu-'+arm);assert not o.exists()
 _compile_impl(p,output_dir=str(o),platform='a2a3',_kernel_abi=abi);a=KernelArtifact(o,abi);a.load()
 record['arms'][arm]={'root_tensors':6,'artifact_identity':a.identity().hex()}
assert not torch_npu.npu.is_initialized();record['pass']=True
(r/'compile-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
