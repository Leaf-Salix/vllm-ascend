"""Planner only. Actual failed TopK plus explicitly reconstructed/synthetic metadata."""
import bind,json,hashlib,os
from pathlib import Path
import torch,torch_npu,pypto.torch
from load import entry
r=Path(__file__).resolve().parent
receipt=json.loads((r/'compile-receipt.json').read_text())
assert receipt['pass'] and receipt['no_npu'] and receipt['source']==bind.IDENTITY
assert receipt['helper_manifest_sha256']==hashlib.sha256((r/'manifest.json').read_bytes()).hexdigest()
assert receipt['sdk']==json.loads(Path(os.environ['PREFLIGHT_RECEIPT']).read_text())
out=r/'results'/os.environ['PLAN_LABEL'];assert not out.exists();out.mkdir(parents=True)
record={'complete':False,'pass':False,'scope':'Six-tensor planner unit only; failed actual TopK with reconstructed table, plus synthetic predicates; no full CSA/token/performance claim','cases':{},'helper_manifest_sha256':receipt['helper_manifest_sha256']}
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
def exact(a,b):return a.shape==b.shape and a.dtype==b.dtype and torch.equal(a.contiguous().view(torch.uint8),b.contiguous().view(torch.uint8))
def oracle(raw,positions,lens,requests,table):
 result=torch.full_like(raw,-1)
 for t,row in enumerate(raw.tolist()):
  req=int(requests[t]);limit=(int(positions[t,0])+1)//4
  if not 0<=req<len(lens) or int(lens[req])<=0:continue
  for pair in range(256):
   values=[];pages=[]
   for index in row[pair*2:pair*2+2]:
    page=int(table[req,index//32]) if 0<=index<limit and index//32<table.shape[1] else -1
    values.append(index if page>=0 else -1);pages.append(page)
   a,b=values
   if a>=0 and b>=0 and a+1<limit and b+1<limit:
    first=pages[0]*32+a%32;second=pages[1]*32+b%32
    if first>second and (first-second-1)*1024<2**31-1:values.reverse()
   result[t,pair*2:pair*2+2]=torch.tensor(values,dtype=torch.int32)
 return result
save()
try:
 torch.set_num_threads(4);torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1)
 assert os.environ['ASCEND_RT_VISIBLE_DEVICES']==os.environ['TASK_DEVICE'] and os.environ['TASK_DEVICE'].isdigit()
 torch.npu.set_device(0);pypto.torch.init()
 ops={arm:pypto.torch.register(entry(arm),'csa_plan_unit::'+arm) for arm in ('v5','v6')}
 failure=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-module-gap-20261023-codex/vector-pair-v5/results/vector-pair-8k-b32-v5/first-difference.pt')
 data=torch.load(failure,map_location='cpu',mmap=True,weights_only=True)
 raw=data['states']['vector']['idx_topk'];assert raw.shape==(192,512)
 positions=data['inputs']['vector']['positions'].reshape(192,1)
 columns=(8192+6+32*4-1)//(32*4)+1
 table=torch.tensor([[1+req*columns+(columns-1-col)%columns for col in range(columns)] for req in range(32)],dtype=torch.int32)
 actual=(raw,positions,torch.full((32,),8198,dtype=torch.int32),torch.arange(192,dtype=torch.int32)//6,table)
 gen=torch.Generator().manual_seed(2048)
 synthetic_raw=torch.randint(-10,2200,(64,512),generator=gen,dtype=torch.int32)
 synthetic_raw[:,:16]=torch.tensor([-2**31,-1,0,1,31,32,33,511,512,2047,2048,2**31-1,65,66,131,132])
 limits=torch.tensor(([0,1,2,31,32,33,511,512,2048,2**31-1]*7)[:64],dtype=torch.int64)
 synthetic_pos=torch.clamp(limits*4-1,min=0).reshape(64,1)
 table2=torch.randint(0,2000,(64,66),generator=gen,dtype=torch.int32);table2[:,0]=-1
 table2[::7,1]=2**24;table2[::11,2]=2**31-1
 lens=torch.ones(64,dtype=torch.int32);lens[::13]=0
 req=torch.arange(64,dtype=torch.int32);req[::17]=-1
 # Exact stride boundary differences 2097151/2097152/2097153, all eligible.
 synthetic_raw[1,:6]=torch.tensor([32,1,32,0,33,0],dtype=torch.int32)
 synthetic_pos[1,0]=99999*4-1;table2[1,0]=0;table2[1,1]=65536
 synthetic=(synthetic_raw,synthetic_pos,lens,req,table2)
 for label,cpu in [('failed-topk-reconstructed-table',actual),('synthetic-edge',synthetic)]:
  expected=oracle(*cpu);inputs=[value.npu() for value in cpu]
  owners={arm:torch.full((cpu[0].shape[0]+16,512),12345,device='npu',dtype=torch.int32) for arm in ops}
  outputs={arm:value[8:-8] for arm,value in owners.items()}
  graphs={}
  with torch.inference_mode():
   for arm,op in ops.items():op(*inputs,outputs[arm])
   torch.npu.synchronize()
   for arm,value in outputs.items():
    diff=value.cpu()!=expected
    record['cases'].setdefault(label,{})[arm]={'eager_exact':exact(value.cpu(),expected),'eager_different':int(diff.sum()),'first':diff.nonzero()[:8].tolist()}
   save();assert record['cases'][label]['v6']['eager_exact'],'STOP: v6 planner mismatch eager'
   stream=torch.npu.Stream();stream.wait_stream(torch.npu.current_stream())
   with torch.npu.stream(stream):
    for arm,op in ops.items():
     graph=torch.npu.NPUGraph()
     with torch.npu.graph(graph,stream=stream):op(*inputs,outputs[arm])
     graphs[arm]=graph
    torch.npu.synchronize()
    for repeat in range(3):
     for value in outputs.values():value.fill_(-123456)
     for graph in graphs.values():graph.replay()
     torch.npu.synchronize()
     for arm,value in outputs.items():
      equal=exact(value.cpu(),expected)
      record['cases'][label][arm].setdefault('graph_replays',[]).append(equal)
      assert bool((owners[arm][:8]==12345).all()) and bool((owners[arm][-8:]==12345).all())
      if arm=='v6':assert equal,'STOP: v6 planner graph difference'
     assert all(exact(a.cpu(),b) for a,b in zip(inputs,cpu,strict=True)),'readonly input modified'
     save()
 record.update(complete=True,pass_=True);record['pass']=record.pop('pass_');save()
except Exception as exc:record['error']=repr(exc);save();raise
print('PLAN_UNIT',record['pass'],flush=True)
