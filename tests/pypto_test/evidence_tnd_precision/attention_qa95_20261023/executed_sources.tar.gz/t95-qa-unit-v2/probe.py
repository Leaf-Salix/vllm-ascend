"""M95 QA only: qualify real Native FULL oracle, then old/candidate raw graphs."""
import bind
import hashlib,json,os,time
from pathlib import Path
import torch,torch_npu,pypto.torch
import qa_entries
from safetensors import safe_open
from torch.nn import functional as F
HERE=Path(__file__).resolve().parent
HOOK=bind.HOOK/'results/t95-q-stage-v2'
report=json.loads((HOOK/'result.json').read_text())
assert report['complete'] and report['pass'] and report['first_different_stage']=='qa'
assert report['readonly_packets_unchanged'] and report['extended_order_prefix_exact']
assert all(all(c.values()) for c in report['observation_matches_unmodified'].values())
receipt=json.loads((HERE/'compile-receipt.json').read_text())
assert receipt['pass'] and not receipt['npu_initialized'] and set(receipt['arms'])=={'base','packet'}
assert receipt['source']==bind.IDENTITY
assert receipt['helper_manifest_sha256']==hashlib.sha256((HERE/'manifest.json').read_bytes()).hexdigest()
assert receipt['sdk']==json.loads(Path(os.environ['PREFLIGHT_RECEIPT']).read_text())
out=HERE/'results'/os.environ['QA_LABEL'];assert not out.exists();out.mkdir(parents=True)
record={'complete':False,'pass':False,'scope':'M95,N1024,K4096 QA only; raw full QA-root NPUGraph, not vLLM FULL or token acceptance',
        'source':bind.IDENTITY,'helper_manifest_sha256':hashlib.sha256((HERE/'manifest.json').read_bytes()).hexdigest(),
        'observer_result_sha256':hashlib.sha256((HOOK/'result.json').read_bytes()).hexdigest(),'checks':{},'cases':{}}
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
def exact(a,b):return a.shape==b.shape and a.dtype==b.dtype and torch.equal(a.contiguous().view(torch.uint8),b.contiguous().view(torch.uint8))
def metric(a,b):
    neq=a!=b
    return {'bit_equal':exact(a,b),'different':int(neq.sum()),'max_abs':float((a.float()-b.float()).abs().max()),'first_coordinates':neq.nonzero()[:8].tolist()}
def host(a):return torch_npu.npu_format_cast(a,2).cpu().contiguous()
def det():
    assert torch.are_deterministic_algorithms_enabled()
    assert torch_npu._C._npu_get_deterministic_level()==1
save()
try:
    stages=torch.load(HOOK/'native-stages.pt',map_location='cpu',weights_only=True)
    pto_stages=torch.load(HOOK/'pto-stages.pt',map_location='cpu',weights_only=True)
    assert stages['normed'].shape==(95,4096) and stages['qa'].shape==(95,1024)
    checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
    key='layers.4.attn.wq_a.weight'
    index=json.loads((checkpoint/'quant_model_weights.safetensors.index.json').read_text())['weight_map']
    with safe_open(checkpoint/index[key],framework='pt',device='cpu') as reader:weight_cpu=reader.get_tensor(key)
    assert weight_cpu.shape==(1024,4096) and weight_cpu.dtype==torch.bfloat16
    record['weight']={'key':key,'shard':index[key],'sha256':hashlib.sha256(weight_cpu.view(torch.uint8).numpy().tobytes()).hexdigest()}
    torch.set_num_threads(4);torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1)
    torch.npu.set_device(0);torch.npu.config.allow_internal_format=True;torch.npu.set_compile_mode(jit_compile=False)
    assert os.environ['TASK_DEVICE'].isdigit() and os.environ['ASCEND_RT_VISIBLE_DEVICES']==os.environ['TASK_DEVICE']
    det();weight=torch_npu.npu_format_cast(weight_cpu.npu(),29)
    assert torch_npu.get_npu_format(weight)==29 and exact(host(weight),weight_cpu)
    x_owner=torch.full((127,4096),37.,device='npu',dtype=torch.bfloat16);x=x_owner[16:111]
    x.copy_(stages['normed'])
    with torch.inference_mode():native=host(F.linear(x,weight));repeat=host(F.linear(x,weight))
    record['checks']['standalone_native_full95_exact']=exact(native,stages['qa'])
    record['checks']['standalone_native_repeat_exact']=exact(native,repeat);save()
    assert all(record['checks'].values()),'STOP: Native standalone did not reproduce all actual FULL95 QA; candidate comparison unqualified'
    pypto.torch.init()
    ops={arm:pypto.torch.register(getattr(qa_entries,'qa_'+arm+'_test'),'csa_t95_qa::'+arm) for arm in ('base','packet')}
    owners={arm:torch.full((128,1024),37.,device='npu',dtype=torch.float32) for arm in ops}
    outputs={arm:v[16:112] for arm,v in owners.items()}
    expected_input=stages['normed']
    def guards():
        assert exact(x.cpu(),expected_input)
        assert bool((x_owner[:16]==37).all()) and bool((x_owner[111:]==37).all())
        assert all(bool((v[:16]==37).all()) and bool((v[112:]==37).all()) for v in owners.values())
        assert exact(host(weight),weight_cpu)
    def collect():
        guards();result={arm:value[:95].cpu().bfloat16() for arm,value in outputs.items()}
        assert all(bool(torch.isfinite(t).all()) for t in result.values());return result
    with torch.inference_mode():
        for arm,op in ops.items():op(x,weight,outputs[arm])
        torch.npu.synchronize();eager=collect()
        assert exact(eager['base'][[86,87]].float(),pto_stages['qa']),'base does not reproduce actual H3 QA observation'
        record['checks']['base_observed_two_rows_exact']=True
        record['eager']={arm:metric(value,native) for arm,value in eager.items()};save()
        assert exact(eager['packet'],native),'STOP: packet candidate fails actual95 eager; no expansion'
        stream=torch.npu.Stream();stream.wait_stream(torch.npu.current_stream());graphs={}
        with torch.npu.stream(stream):
            for arm,op in ops.items():
                graph=torch.npu.NPUGraph()
                with torch.npu.graph(graph,stream=stream):op(x,weight,outputs[arm])
                graphs[arm]=graph
            torch.npu.synchronize();captured=collect()
            assert all(exact(captured[arm],eager[arm]) for arm in ops)
            seeds={}
            for seed in (73001,73002):
                gen=torch.Generator(device='cpu').manual_seed(seed)
                seeds[seed]=(torch.randn((95,4096),generator=gen)*.25).bfloat16()
            for step,key in enumerate(('actual',73001,'actual',73002,'actual')):
                det();expected_input=stages['normed'] if key=='actual' else seeds[key];x.copy_(expected_input)
                gold=host(F.linear(x,weight));again=host(F.linear(x,weight))
                assert exact(gold,again)
                if key=='actual':assert exact(gold,stages['qa'])
                for value in outputs.values():value.fill_(float('nan'))
                for graph in graphs.values():graph.replay()
                torch.npu.synchronize();actual=collect()
                for value in outputs.values():value.fill_(float('nan'))
                for graph in graphs.values():graph.replay()
                torch.npu.synchronize();repeated=collect()
                assert all(exact(actual[arm],repeated[arm]) for arm in ops),'poisoned graph repeat differs'
                record['cases'][str(step)]={'input':str(key),'metrics':{arm:metric(value,gold) for arm,value in actual.items()},'guards':True,'poisoned_repeat_exact':True}
                save();assert exact(actual['packet'],gold),'STOP: candidate graph first difference at '+str(key)
            record.update(complete=True,pass_=True);record['pass']=record.pop('pass_');save()
except Exception as exc:
    record['error']=repr(exc);save();raise
print('T95_QA_UNIT',record['pass'],flush=True)
