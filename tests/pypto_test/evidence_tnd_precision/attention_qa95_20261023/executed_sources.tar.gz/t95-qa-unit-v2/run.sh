#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?}"
QA_LABEL=${1:?};shift
[[ "$QA_LABEL" =~ ^[a-z0-9-]+$ ]]
if (( $# ));then [[ "$#" == 2 && "$1" == --device && "$2" == "$TASK_DEVICE" ]] || exit 2;fi
export QA_LABEL
r=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$r/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE" PREFLIGHT_RECEIPT="$r/$QA_LABEL-sdk.json"
printf 'TASK_RUN_START %s\n' "$(date -Iseconds)"
trap 'printf "TASK_RUN_END %s\n" "$(date -Iseconds)"' EXIT
ccache -s
timeout --signal=TERM --kill-after=15s 750s python "$r/probe.py" > "$r/$QA_LABEL-run.log" 2>&1
