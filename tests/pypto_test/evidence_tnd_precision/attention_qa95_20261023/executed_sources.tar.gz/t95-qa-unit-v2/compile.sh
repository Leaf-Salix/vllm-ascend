#!/usr/bin/env bash
set -euo pipefail
r=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$r/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="" PREFLIGHT_RECEIPT="$r/compile-sdk.json"
ccache -s
timeout 700s python "$r/compile.py" > "$r/compile.log" 2>&1
