"""Private QA-only A/B: existing base vs existing packet helper, no route edit."""
import pypto.language as pl
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.qkv_proj_rope import (
    BF16_WEIGHT_LAYOUT, D, Q_LORA, QPROJ_MM_T_DYN, T_DYN, q_proj_qa,
)
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.qkv_precision126 import q_proj_qa_126


@pl.jit
def qa_base_test(
    x: pl.Tensor[[T_DYN, D], pl.BF16],
    w: pl.Tensor[[Q_LORA, D], pl.BF16, BF16_WEIGHT_LAYOUT],
    output: pl.InOut[pl.Tensor[[QPROJ_MM_T_DYN, Q_LORA], pl.FP32]],
):
    x.bind_dynamic(0, T_DYN)
    output.bind_dynamic(0, QPROJ_MM_T_DYN)
    rows = pl.tensor.dim(x, 0)
    q_proj_qa(x, w, output, 0, rows)
    return output


@pl.jit
def qa_packet_test(
    x: pl.Tensor[[T_DYN, D], pl.BF16],
    w: pl.Tensor[[Q_LORA, D], pl.BF16, BF16_WEIGHT_LAYOUT],
    output: pl.InOut[pl.Tensor[[QPROJ_MM_T_DYN, Q_LORA], pl.FP32]],
):
    x.bind_dynamic(0, T_DYN)
    output.bind_dynamic(0, QPROJ_MM_T_DYN)
    rows = pl.tensor.dim(x, 0)
    q_proj_qa_126(x, w, output, 0, rows)
    return output
