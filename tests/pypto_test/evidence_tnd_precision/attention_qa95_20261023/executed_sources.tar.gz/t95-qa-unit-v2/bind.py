"""Bind the unchanged SDK and source snapshot used by the completed observer."""
import hashlib,json,os,runpy,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
HOOK=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-module-gap-20261023-codex/t95-hook-v2')
for name,digest in json.loads((HERE/'manifest.json').read_text()).items():
    assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==digest,name
sys.path.insert(0,str(HOOK))
runpy.run_path(str(HOOK/'sdk_bind.py'),run_name='__sdk_preflight__')
from source_identity import source_identity
IDENTITY=source_identity()
import torch_npu
assert not torch_npu.npu.is_initialized()
