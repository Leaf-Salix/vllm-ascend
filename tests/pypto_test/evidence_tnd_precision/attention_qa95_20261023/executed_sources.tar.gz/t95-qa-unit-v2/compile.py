"""Compile both complete QA roots and artifacts with NPU hidden."""
import bind
import json,hashlib,os
from pathlib import Path
import torch_npu
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program
from pypto.runtime._kernel_artifact import KernelArtifact
import qa_entries
root=Path(__file__).resolve().parent
record={'pass':False,'device_execution':False,'source':bind.IDENTITY,'helper_manifest_sha256':hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),'sdk':json.loads(Path(os.environ['PREFLIGHT_RECEIPT']).read_text()),'arms':{}}
for arm in ('base','packet'):
    entry=getattr(qa_entries,'qa_'+arm+'_test')
    program=entry.specialize()
    abi=kernel_abi_for_program(program,platform='a2a3',runtime='tensormap_and_ringbuffer')
    assert len(abi.parameters)==3
    out=root/('cpu-'+arm);assert not out.exists()
    _compile_impl(program,output_dir=str(out),platform='a2a3',_kernel_abi=abi)
    artifact=KernelArtifact(out,abi);artifact.load()
    record['arms'][arm]={'root_tensors':3,'artifact_identity':artifact.identity().hex()}
assert not torch_npu.npu.is_initialized()
record.update(pass_=True,npu_initialized=False)
record['pass']=record.pop('pass_')
(root/'compile-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
