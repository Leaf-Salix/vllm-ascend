import importlib,importlib.util,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
def load(name,filename):
    if name in sys.modules:return sys.modules[name]
    spec=importlib.util.spec_from_file_location(name,HERE/filename)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
def entry_for(arm):
    assert arm=='probe'
    load('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.t95_qkv','t95_qkv.py')
    return load('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_combined.t95_root','t95_root.py').decode_csa_tp1_layer_test
def operators_for(arm):
    import pypto.torch
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_combined.native_adapter import CSAOperators
    base=CSAOperators.register()
    op=pypto.torch.register(entry_for('probe'),'csa_t95_probe::attention')
    return type(base)(op,base.workspace)
