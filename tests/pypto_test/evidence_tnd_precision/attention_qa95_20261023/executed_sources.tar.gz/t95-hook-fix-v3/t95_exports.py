import pypto.language as pl
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.qkv_proj_rope import T_DYN,QPROJ_MM_T_DYN

@pl.jit.inline(auto_scope=False)
def export_normed(source: pl.Tensor[[T_DYN,4096],pl.BF16],packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    with pl.spmd(8,name_hint="debug_normed"):
        for block in pl.range(pl.tile.get_block_idx(),32,8):
            row=86+block//16
            col=(block%16)*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,4096-col)])
            widened=pl.cast(tile,pl.FP32)
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            pl.store(pl.set_validshape(bits,1,pl.min(256,4096-col)),[0,2816+block*256],packet2)

@pl.jit.inline(auto_scope=False)
def export_qa(source: pl.Tensor[[QPROJ_MM_T_DYN,1024],pl.FP32],packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    with pl.spmd(8,name_hint="debug_qa"):
        for block in pl.range(pl.tile.get_block_idx(),8,8):
            row=86+block//4
            col=(block%4)*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,1024-col)])
            widened=pl.cast(pl.cast(tile,pl.BF16,mode="rint"),pl.FP32)
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            pl.store(pl.set_validshape(bits,1,pl.min(256,1024-col)),[0,11264+block*256],packet2)

@pl.jit.inline(auto_scope=False)
def export_qr(source: pl.Tensor[[T_DYN,1024],pl.INT8],packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    with pl.spmd(8,name_hint="debug_qr"):
        for block in pl.range(pl.tile.get_block_idx(),8,8):
            row=86+block//4
            col=(block%4)*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,1024-col)])
            widened=pl.cast(pl.cast(tile,pl.FP16),pl.FP32)
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            pl.store(pl.set_validshape(bits,1,pl.min(256,1024-col)),[0,13568+block*256],packet2)

@pl.jit.inline(auto_scope=False)
def export_qr_scale(source: pl.Tensor[[T_DYN,1],pl.FP32],packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    flat=pl.reshape(source,[1,95])
    with pl.spmd(2,name_hint="debug_qr_scale"):
        row=86+pl.tile.get_block_idx()
        value=pl.load(flat,[0,row],[1,8])
        bits=pl.tile.reinterpret_view(value,pl.INT32)
        pl.store(pl.set_validshape(bits,1,1),[0,15872+pl.tile.get_block_idx()*256],packet2)

@pl.jit.inline(auto_scope=False)
def export_q(source: pl.Tensor[[T_DYN,32768],pl.BF16],packet: pl.InOut[pl.Tensor[[1048576],pl.INT32]]):
    packet2=pl.reshape(packet,[1,1048576])
    with pl.spmd(8,name_hint="debug_q"):
        for block in pl.range(pl.tile.get_block_idx(),256,8):
            row=86+block//128
            col=(block%128)*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,32768-col)])
            widened=pl.cast(tile,pl.FP32)
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            pl.store(pl.set_validshape(bits,1,pl.min(256,32768-col)),[0,16640+block*256],packet2)
