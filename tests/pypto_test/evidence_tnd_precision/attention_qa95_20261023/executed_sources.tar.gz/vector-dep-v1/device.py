from pathlib import Path
import hashlib,json,runpy,sys
root=Path(__file__).resolve().parent
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==value for name,value in json.loads((root/'manifest.json').read_text()).items())
base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-module-gap-20261023-codex/vector-pair-v7')
assert hashlib.sha256((base/'probe_perf.py').read_bytes()).hexdigest()=='9a93e5f9513ddcfba42dcf1d8def948335817511504ca465e228d1293ae7a00d'
sys.path.insert(0,str(base))
runpy.run_path(str(base/'sdk_bind.py'),run_name='__sdk_preflight__')
text=(root/'derived_probe.py').read_text()
assert hashlib.sha256(text.encode()).hexdigest()=='9cf692f0f61be42dbd2892334f1fb64f7d8d5de96e0a89999aaebc040cac7f83'
exec(compile(text,str(base/'probe_perf.py'),'exec'),{'__name__':'__main__','__file__':str(base/'probe_perf.py')})
