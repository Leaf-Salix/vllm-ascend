# T168 QA交付文档与整模型归档独立复核

**内容审查通过；最终封包SHA刷新及最新版verify重跑待完成。**

主报告与证据README准确限定：真实完整模型、固定8K bank前28请求，
16rank×warm192+192共172032个Native/PTO token位置一致，事件及采集输入/入场协议一致。
没有扩大到新128K/性能、任意prompt或所有内部浮点张量逐bit资格。

已独立验证132+132份原始文本、31文件封存helper及其原audit/mixed/generation_window身份，
并在前序审查逐对象重算Native READY与PTO audit一致。正式verify确实解包原audit子进程重算，
不只相信摘要PASS。此前用workspace Python3.11实跑正式verify返回PASS_SAVED_REAL_MODEL_8K_B28。
系统Python3.9不支持原审计器zip(strict=)，初次该环境调用失败；README已明确>=3.10，推荐3.11。

## 已纠正的实质问题

1. 原31文件包含compile-receipt，若复制进新job会触发编译器fresh断言。
   README现明确只复制其余30文件、实际新路径编译生成新receipt，再重封31manifest。
2. 全Native/PTO×16rank×2轮共64个窗口逐行复核：每窗53active，
   首次1NONE（全S1，真实/物理T28），随后52FULL（全S6，物理168）。
   主报告、README和新版verify均已纠正“全部FULL”“首S1补到168”的早期汇总解释。
   本轮不证明S1短query FULL、同一步混合1与6或2～5行；33次真实T168 FULL仍成立。

实际import/新snapshot、3399/77、canonical编译、helper、CPU bank/hook、Native gold及PTO审计
复现顺序齐备；不允许复用旧收据/删除旧结果或绕过首差与身份门禁。

## 封包最后一步

本次主线程更新RESULTS并新增图模式校验后，最新版verify实跑暂时在外层
SHA256.json的RESULTS身份检查停止。此为仍在重封过程的摘要SHA未刷新，非数值失败。
最终加入本review后，应重封text-tools、刷新外层SHA256.json，使用Python>=3.10
再执行最新版verify；保留原始两个raw包与31helper身份不变。完成前不宣称“最终包重算通过”。

审查无远端/NPU、无正式或封存文件修改。详细绑定和当前封包待项见FINAL_REVIEW.json；
图模式逐窗口证据见ACTUAL_GRAPH_SCOPE.json。
