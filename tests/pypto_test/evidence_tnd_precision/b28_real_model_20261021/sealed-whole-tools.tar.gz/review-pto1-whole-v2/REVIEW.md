# PTO1 真整模型8K/B28独立复核

**PASS：本配置真实整模型172032个Native/PTO token位置零差异，接受事件与采集输入/入场轨迹一致。**

原始PTO tar逐成员验证解包文本；封存`audit.py`纯CPU独立重算，完整对象与实际`audit.json`一致。
Native READY仍为cbe9e109…，gold防改清单通过；同一新source/helper/compile资格未变化。

- 全16rank，两轮warm192+192，172032个token位置全部一致；接受事件一致，零抢占。
- 每rank每轮33次真实28活跃/T168/FULL168前向；每rank每轮采集53条活跃生成记录。
- 全21CSA的实际运行类为正式overlap service、单根namespace/64参，6与168均有warm和capture；
  全20HCA仍Native。HC-pre/Norm/WKV/Indexer权重/O-proj/HC-post的完整PTO模块资格记录通过。
- Native与PTO的source/helper配置一致；采集输入/入场轨迹严格比较，仅原审计器既有execute_index例外，
  未增加归一化或宽松比较。未将CPU轨迹相同夸大为所有GPU模型输入逐bit观测证明。

## 验收范围

完整75分片模型，fixed8192 bank前28请求，TP1/DP=EP16、确定性greedy、EPLB关闭。
本轮所有rank实际query length只出现1与6，没有2～5行，不能称真实整模型已覆盖任意混合1～6。
真实token数范围12～168，不等于所有T或padding模式均已验证。
这不是新增128K、性能或任意prompt/seed的通用资格，也不是所有层内部张量逐bit证明。

提交至完成含排队；本审查没有独立scheduler占卡边界，不把21:15pending至21:30completed
全部算作占卡。实际任务符合调度780秒上限由主线程收据另记，不从CLI总耗时推导。

只读本机重算，未远端/设备、未修改封存或正式文件。详细SHA、计数与实际query范围见REVIEW.json。
