# Native1 真整模型B28独立复核

**PASS，仅Native自身重复一致；PTO对拍尚待结果。**

本地从原始tar逐成员SHA验证解包文本，使用封存`audit.py`纯CPU重新审计，
完整重算对象与原`READY_GOLD.json`逐项一致；gold文件清单各SHA全部复核。

- 全16 rank，warm192+正式192，共172032条记录token；两轮86016对位置完全一致。
- 接受事件与完整生成窗口入场/输入轨迹严格一致，未做input_id归一化；零抢占。
- 每rank每轮33个真实28活跃/T168/FULL168前向，DP联合token向量一致；不是仅有168 bucket。
- 新canonical3399源/77运行/31helper/编译收据/gold身份一致；原SDK、新snapshot，Native覆盖全部41个注意力层。

本轮Native结果不代表PTO候选通过，也未增加性能资格。PTO任务仍需各自原始结果、
逐token/事件/轨迹及真PTO覆盖审计；不得从Native重复通过推断PTO。
提交至完成总时长包含排队，本审查没有独立占卡起止收据，不把队列显示近3小时报告为占卡3小时。

本审查未连接227、未初始化NPU或修改封存文件。完整重算与SHA见同目录JSON。
