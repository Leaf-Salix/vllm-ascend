from pathlib import Path
import hashlib,json,runpy,sys
here=Path(__file__).resolve().parent
assert all(hashlib.sha256((here/k).read_bytes()).hexdigest()==v for k,v in json.loads((here/'manifest.json').read_text()).items())
base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-gap-20261026-codex/physical-gather-v3')
assert hashlib.sha256((base/'probe_perf.py').read_bytes()).hexdigest()=='4e29fd2d36ec90e7fc97e16b87195338c5a726ecad5e16ad96c2fcc453c44e2a'
sys.path.insert(0,str(base));runpy.run_path(str(base/'sdk_bind.py'),run_name='__sdk_preflight__')
text=(here/'derived_probe.py').read_text()
assert hashlib.sha256(text.encode()).hexdigest()=='77a6d8a072f7daed59c25bcf3355699913a776b743487fab4c334cf4d3a75e04'
exec(compile(text,str(base/'probe_perf.py'),'exec'),{'__name__':'__main__','__file__':str(base/'probe_perf.py')})
