import importlib.util,sys,json,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent
C='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_combined'
S='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd'
def load(name,path):
 if name in sys.modules:return sys.modules[name]
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def entry_for(arm):
 assert arm in ('baseline','candidate')
 proof=json.loads((HERE/'SOURCE.json').read_text())
 for name,sha in proof['candidates'].items():assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==sha,name
 load(S+'.gap_h3_cube',HERE/'h3_cube.py');load(C+'.gap_h3_prefix',HERE/'h3_prefix.py')
 load('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.gap_'+arm+'_sparse',HERE/(arm+'_sparse.py'))
 return load(C+'.gap_'+arm+'_root',HERE/(arm+'_root.py')).decode_csa_tp1_layer_test
def operators_for(arm):
 import pypto.torch
 from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.native_adapter import CSAOperators
 from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_prepack.native_adapter import PrepackedWorkspace
 from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_prepack.prefix import prepack_fixed_hc_weight
 op=pypto.torch.register(entry_for(arm),'csa_physical_'+arm+'::attention')
 prepare=pypto.torch.register(prepack_fixed_hc_weight,'csa_physical_'+arm+'::prepare')
 return CSAOperators(op,PrepackedWorkspace(prepare))
