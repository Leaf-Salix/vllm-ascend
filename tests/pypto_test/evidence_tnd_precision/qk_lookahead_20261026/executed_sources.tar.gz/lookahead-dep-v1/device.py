from pathlib import Path
import hashlib,json,runpy,sys
here=Path(__file__).resolve().parent
assert all(hashlib.sha256((here/k).read_bytes()).hexdigest()==v for k,v in json.loads((here/'manifest.json').read_text()).items())
base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-gap-20261026-codex/lookahead-v1')
assert hashlib.sha256((base/'probe_perf.py').read_bytes()).hexdigest()=='fd5fd4fd859aafe5a29c2de862f8ef24dcdc71a270d58f1c7c688f682f51c29f'
sys.path.insert(0,str(base));runpy.run_path(str(base/'sdk_bind.py'),run_name='__sdk_preflight__')
text=(here/'derived_probe.py').read_text()
assert hashlib.sha256(text.encode()).hexdigest()=='62834401f01056d0ab74b47546667d87d30d18568dc1f2fb2cdb738ece0b08f4'
exec(compile(text,str(base/'probe_perf.py'),'exec'),{'__name__':'__main__','__file__':str(base/'probe_perf.py')})
