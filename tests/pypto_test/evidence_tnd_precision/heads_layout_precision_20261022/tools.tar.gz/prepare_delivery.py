"""Archive the precision supplement without changing the accepted operator."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]/'vllm-ascend-nalinaly-tnd-20261008-codex'
DEST=REPO/'tests/pypto_test/evidence_tnd_precision/heads_layout_precision_20261022'
case='heads-precision-128k-b24-v1'
result=json.loads((HERE/'RECHECK.json').read_text())
assert result['pass'] and result['accuracy_executed'] and not result['new_performance_measurement']
DEST.mkdir(exist_ok=False)
shutil.copy2(HERE/'REPORT.md',REPO/'tests/pypto_test/DSV4_FLASH_CSA_TND_HEADS_LAYOUT_PRECISION_20261022.md')
for name in (case+'-evidence.tar.gz','RECHECK.json','INDEPENDENT_REVIEW.md'):
    shutil.copy2(HERE/name,DEST/name)
shutil.copy2(HERE/'verify_delivery.py',DEST/'verify.py')
with tarfile.open(DEST/'tools.tar.gz','w:gz') as archive:
    for p in sorted(HERE.iterdir()):
        if p.is_file() and (p.suffix in ('.py','.sh','.json') or p.name.endswith('-final-status.txt')):
            archive.add(p,arcname=p.name,recursive=False)
(DEST/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n'
    for p in sorted(DEST.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print(DEST)
