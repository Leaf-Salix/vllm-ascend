"""Check the actual precision result, helper identity and replay qualifications."""
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
case=sys.argv[1]
evidence=HERE/('evidence-'+case)
r=json.loads((evidence/'results'/case/'result.json').read_text())
assert r['complete'] is True and r['pass'] is True
assert r['accuracy_executed'] is True and r['timing_executed'] is False
assert r['history']==131072 and r['lengths']==[6]*24 and r['true_tokens']==144
assert r['physical_graph_tokens']==144 and r['per_request_padding']==0
assert r['prior_no_device_compile_pass'] is True
assert r['acceptance_arms']==['frozen','direct','packed']
manifest=(evidence/'manifest.json').read_bytes()
assert hashlib.sha256(manifest).hexdigest()==r['manifest_sha256']
assert json.loads(manifest)==r['helper_sha']
for name,digest in r['helper_sha'].items():
    assert hashlib.sha256((evidence/name).read_bytes()).hexdigest()==digest,name
proof=json.loads((evidence/'SOURCE.json').read_text())
assert proof==r['isolated_candidates']
for name,digest in proof['candidates'].items():assert hashlib.sha256((evidence/name).read_bytes()).hexdigest()==digest
for arm in ('direct','packed'):
    receipt=json.loads((evidence/('compile-'+arm+'-receipt.json')).read_text())
    assert receipt['pass'] and receipt['device_execution'] is False
    assert receipt['candidate_source_sha256']==hashlib.sha256((evidence/'SOURCE.json').read_bytes()).hexdigest()
    assert receipt['source']['qa_sha256']==r['qa_sha256']
assert set(r['graphs'])=={'native','frozen','direct','packed'}
assert set(r['comparisons'])==set(r['B_comparisons'])=={'frozen','direct','packed'}
for arm in ('native','frozen','direct','packed'):
    graph=r['graphs'][arm]
    for flag in ('actual_acl_graph','fullgraph','compiled_raw_equal','topk_poison_replay_restored','live_input_ABA'):
        assert graph[flag] is True,(arm,flag)
    assert graph['true_tokens']==graph['graph_tokens']==144
    assert len(graph['guards'])==33 and all(g['status']=='PASS' for g in graph['guards'].values())
    assert len(r['replay_checks'][arm])==3
    for repeat,row in enumerate(r['replay_checks'][arm]):
        assert row['repeat']==repeat and row['all_eight_exact'] is True
        assert len(row['guards'])==33 and all(g['status']=='PASS' for g in row['guards'].values())
    if arm!='native':
        assert r['entry'][arm]['eligible'] and r['entry'][arm]['route']=='PTO'
        assert graph['pto_dispatch_calls']>0 and graph['root_schema'].split(' -> ')[0].count('Tensor')==64
        for kind in ('comparisons','B_comparisons'):
            assert len(r[kind][arm])==8
            assert all(m['bit_equal'] and m['different_elements']==0 and m['max_abs']==0
                       for m in r[kind][arm].values())
summary={'case':case,'pass':True,'history':131072,'B':24,'T':144,'graph':'FULL raw',
         'acceptance_arms':['frozen','direct','packed'],'A_B_native_comparisons':48,
         'additional_replays':12,'additional_exact_state_checks':96,'accuracy_executed':True,
         'new_performance_measurement':False,'candidate_sources':proof['candidates'],
         'scope':'single layer 4 real weights, synthetic hidden/history; not whole-model tokens'}
(HERE/'RECHECK.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
