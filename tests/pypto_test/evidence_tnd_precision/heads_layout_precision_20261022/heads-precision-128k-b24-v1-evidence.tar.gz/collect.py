"""Collect only finished task logs and textual timing evidence, never weights."""
import json
import re
import shlex
import subprocess
import sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
REMOTE='/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/heads-precision-20261022-codex'
case=sys.argv[1]
assert re.fullmatch(r'heads-precision-(8k|128k)-b[0-9]+-v[0-9]+',case)
task=json.loads((HERE/(case+'-submission.json')).read_text())['task_id']
assert re.fullmatch(r'task_[0-9_]+',task)
def ssh(command):
    result=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','pto227',command],capture_output=True,text=True,timeout=60)
    assert result.returncode==0,result.stderr
    return result.stdout
status=ssh('task-submit --status '+task)
assert 'completed' in status, status
(HERE/(case+'-final-status.txt')).write_text(status+ssh('task-submit --log '+task))
code="""import tarfile
from pathlib import Path
root=Path(REMOTE)
paths=list((root/'results'/CASE).rglob('*.json'))
paths += [root/'results'/(CASE+'-run.log'),root/'results'/(CASE+'-preflight.json')]
paths += [p for p in root.iterdir() if p.suffix in ('.py','.sh','.json')]
for arm in ():
    paths += list((root/('compiled-'+arm)/'orchestration').glob('*.cpp'))
with tarfile.open(root/(CASE+'-evidence.tar.gz'),'w:gz') as tar:
    for p in sorted(set(paths)):
        if p.is_file():tar.add(p,arcname=p.relative_to(root),recursive=False)
print(len(paths))
""".replace('REMOTE',repr(REMOTE)).replace('CASE',repr(case))
print(ssh('python3 -c '+shlex.quote(code)))
subprocess.run(['/opt/homebrew/bin/rsync','-az','pto227:'+REMOTE+'/'+case+'-evidence.tar.gz',str(HERE)+'/'],check=True,timeout=120)
target=HERE/('evidence-'+case)
target.mkdir(exist_ok=False)
import tarfile
with tarfile.open(HERE/(case+'-evidence.tar.gz')) as tar:tar.extractall(target,filter='data')
print(target)
