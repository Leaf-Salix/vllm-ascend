#!/usr/bin/env bash
set -euo pipefail
heads_precision_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$heads_precision_root/env.sh"
export ASCEND_RT_VISIBLE_DEVICES=''
timeout 90s python "$heads_precision_root/preflight.py"
