"""Reuse sealed layout candidates; validate without a performance threshold."""
import ast
import hashlib
import json
from pathlib import Path
import shutil

HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'dsv4-heads-perf-20261022'
ACCEPTED=HERE.parent/'dsv4-tnd-fixed-eight-l1-20261021/tools/probe_csa.py'
names=('binding.json','source_identity.py','ragged_fixture.py','SOURCE.json','load_candidate.py',
       'heads_direct_root.py','heads_direct_sparse.py','heads_packed_root.py','heads_packed_oproj.py',
       'compile-direct-receipt.json','compile-packed-receipt.json','env.sh','preflight.py')
for name in names:shutil.copy2(OLD/name,HERE/name)
s=ACCEPTED.read_text()
s=s.replace('"""8K真实权重、Native/TND完整CSA FULL图验收；首差停止。"""',
            '"""既有Heads布局候选的精度补验；逐arm首差停止，无性能门槛。"""')
s=s.replace("'candidate_experiment':'accepted-Native-SK0-vs-QA168-fixed-precision-overlap'",
            "'candidate_experiment':'sealed heads direct and packed precision acceptance'")
s=s.replace('enable_chip_swimlane=1','enable_chip_swimlane=0')
s=s.replace('from source_identity import source_identity',
            'from source_identity import source_identity\nfrom load_candidate import operators_for')
s=s.replace('source_record=source_identity()', '''source_record=source_identity()
proof=json.loads((ROOT/'SOURCE.json').read_text())
report['isolated_candidates']=proof
report['acceptance_request']='user accepted small performance gain; no performance threshold'
report['timing_executed']=False
report['accuracy_executed']=True
report['replay_checks']={}
for compile_arm in ('direct','packed'):
    receipt=json.loads((ROOT/('compile-'+compile_arm+'-receipt.json')).read_text())
    assert receipt['pass'] and receipt['device_execution'] is False and receipt['source']==source_record
    assert receipt['candidate_source_sha256']==hashlib.sha256((ROOT/'SOURCE.json').read_bytes()).hexdigest()
report['prior_no_device_compile_pass']=True''')
s=s.replace("for arm in ('native','candidate'):","for arm in ('native','frozen','direct','packed'):")
s=s.replace("operators=(SerialOperators if arm=='serial' else CSAOperators).register()",'operators=operators_for(arm)')
s=s.replace("runtime=(SerialRuntime if arm=='serial' else CSAServiceRuntime)(layer.self_attn,operators,40,layer)",
            'runtime=CSAServiceRuntime(layer.self_attn,operators,40,layer)')
s=s.replace("expected_namespace=('dsv4_csa_tnd_precision_spmd_bf16layout::attention' if arm=='serial' else 'dsv4_csa_tnd_precision_spmd_overlap::attention')",
            "expected_namespace={'frozen':'dsv4_csa_tnd_precision_spmd_overlap::attention','direct':'heads_direct_perf::attention','packed':'heads_packed_perf::attention'}[arm]")
needle="        save()\n        print('ARM_PASS',arm,flush=True)"
assert s.count(needle)==1
s=s.replace(needle,'''        repeat_checks=[]
        for repeat in range(3):
            restore(f);output.fill_(float('nan'));topk.fill_(-12345)
            graph.replay();torch.npu.synchronize()
            repeated=collect_state(f,output,topk)
            assert all(exact(v,actual[n]) for n,v in repeated.items()),(arm,repeat,'replay state drift')
            repeat_guards=guard_checks(f)
            assert all(g['status']=='PASS' for g in repeat_guards.values()),(arm,repeat,'replay guards')
            if runtime is not None:
                assert all(exact(v.cpu(),packet_snapshots[k]) for k,v in readonly_packets.items()),(arm,repeat,'readonly packet')
            repeat_checks.append({'repeat':repeat,'all_eight_exact':True,'guards':repeat_guards})
        report['replay_checks'][arm]=repeat_checks
        save()
        print('ARM_PASS',arm,flush=True)''')
begin=s.index('    def restore_readonly(fixture):')
end=s.index('except Exception as exc:',begin)
s=s[:begin]+'''    report['cross_bucket_scope']='Native vs frozen/direct/packed full CSA; S6 precision supplement'
    report['acceptance_arms']=['frozen','direct','packed']
    report['complete']=report['pass']=True
    save()
'''+s[end:]
ast.parse(s)
(HERE/'probe_precision.py').write_text(s)
manifest={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in (*names,'probe_precision.py','run.sh')}
(HERE/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'candidates_unchanged':all((HERE/n).read_bytes()==(OLD/n).read_bytes() for n in names),
                  'helper_sha256':hashlib.sha256((HERE/'probe_precision.py').read_bytes()).hexdigest()},indent=2))
