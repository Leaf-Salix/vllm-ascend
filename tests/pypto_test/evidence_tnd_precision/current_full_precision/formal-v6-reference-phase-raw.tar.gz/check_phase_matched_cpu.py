"""CPU mutation checks using copied actual V6 JSON, never new NPU evidence."""

import copy
import json
from pathlib import Path
import shutil
import subprocess
import sys

job = Path(__file__).resolve().parent
root = job / "CPU_PHASE_MUTATION_FIXTURE_NOT_NPU"
root.mkdir()
actual = Path("/data/pyptouser/yejia/lc128/perf-overnight-formal-v6-128k-pto-20261019")
shutil.copyfile(actual / "configuration.json", root / "configuration.json")
for rank in range(16):
    shutil.copyfile(
        actual / f"rank{rank}.real_perf.json", root / f"rank{rank}.real_perf.json"
    )
command = [
    sys.executable,
    str(job / "independent128k_phase_matched.py"),
    "--root",
    str(root),
    "--identity",
    "CPU_PHASE_MUTATION_FIXTURE_NOT_NPU",
    "--repeats",
    "3",
    "--expected-source-manifest",
    "6d9656de4580ba5f768881c417f3093a7744808ac6518c594e9db881971e7ab2",
    "--candidate-math",
    str(job.parent / "whole-formal-v6/candidate-math.json"),
]
checks = []


def run(name, success):
    result = subprocess.run(command, capture_output=True, text=True)
    assert (result.returncode == 0) == success, (name, result.stderr[-1500:])
    checks.append(
        {
            "case": name,
            "expected_success": success,
            "actual_exit": result.returncode,
            "error_tail": result.stderr[-600:] if not success else "",
        }
    )


run("unmodified_copy_of_actual_three_rounds", True)
file = root / "rank0.real_perf.json"
original = json.loads(file.read_text())
for name in [
    "first_phase_input_0_to_negative1",
    "repeated_phase2_input_negative1_to0",
    "repeated_phase3_input_negative1_to0",
    "non_input_geometry_changed",
    "missing_final_round",
    "final_round_output_token_changed",
]:
    raw = copy.deepcopy(original)
    if name.startswith("first_phase"):
        assert raw["rounds"][0]["timing"][0]["metadata"][12]["input_ids_cpu"][110] == 0
        raw["rounds"][0]["timing"][0]["metadata"][12]["input_ids_cpu"][110] = -1
    elif name.startswith("repeated_phase"):
        i = 1 if "phase2" in name else 2
        assert raw["rounds"][i]["timing"][0]["metadata"][12]["input_ids_cpu"][110] == -1
        raw["rounds"][i]["timing"][0]["metadata"][12]["input_ids_cpu"][110] = 0
    elif name == "non_input_geometry_changed":
        raw["rounds"][1]["timing"][0]["metadata"][12]["positions_cpu"][110] += 1
    elif name == "missing_final_round":
        raw["rounds"].pop()
    else:
        raw["rounds"][2]["requests"][0]["output_token_ids"][0] += 1
    file.write_text(json.dumps(raw))
    run(name, False)
file.write_text(json.dumps(original))
record = {
    "pass": True,
    "CPU_mutation_test_only_not_new_NPU": True,
    "normalization_used": False,
    "checks": checks,
}
(job / "phase-fixture-results.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
