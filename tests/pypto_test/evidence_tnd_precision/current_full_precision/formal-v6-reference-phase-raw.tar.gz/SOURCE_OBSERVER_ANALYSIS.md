# 128K CPU input observer 与阶段配对证据

## 已直接核实的源码路径

冻结whole source manifest为6d9656de…，其中`vllm_ascend/worker/model_runner_v1.py`实际SHA为`3ea8bda3074aee8d8c288ac2576c68153d32f6619abcb779024cbf392069dfef`，与下载副本和manifest记录逐字一致。实际V6 helper的`perf_probe.py` SHA为`b0ac4159b41592dee164766d8a1fc3d3be40a653fcff7c05b8a6b3801b38b586`；它与历史V4 observer相同。

- `perf_probe.py:65`记录`runner.input_ids.cpu[:tokens].tolist()`，没有记录传给`_model_forward(padded, input_ids, positions,...)`的`input_ids`参数，也没有D2H复制实际GPU输入。
- Ascend runner `model_runner_v1.py:924`先将CPU input batch索引进`self.input_ids.cpu`，1000调用继承的`_prepare_input_ids`。
- 实际环境继承的vLLM `gpu_model_runner.py` SHA为`6c92ded8468f44d6df863a617ce588f132fa6df7031feecc0cc421702a41610e`。1738起的`_prepare_input_ids`区分普通CPU→GPU复制和异步GPU来源；后者在GPU侧从previous sampled token和draft token scatter，CPU buffer可能没有这些最终token。
- Ascend runner 1282起`_sanitize_placeholder_input_ids_for_forward`只有在scheduler的spec token映射非空且含`PLACEHOLDER_TOKEN_ID`时才执行GPU `masked_fill_(...,0)`，不回写CPU buffer。调用在1994，先于2059的`_model_forward`。
- vLLM `_preprocess`的3557行文本模型分支实际使用`self.input_ids.gpu[:num_input_tokens]`，Ascend runner随后把该参数传给model forward；observer却读取另一个CPU buffer。

因此CPU observer不是实际GPU参数的逐字节见证，即使索引位于actual126 token窗口内也是如此。本次日志没有保存完整scheduler spec token值、每步GPU scatter索引或实际GPU input_ids，**不能证明每个差异位置确实进入masked_fill，也不能宣称GPU输入字节一致**。源码表明可能存在不同CPU/GPU准备路径，但不能据此确定本次差异的唯一异步写入根因。

## 原严格失败和完整配对结果

原冻结审计要求所有candidate measured轮都对Native历史第1轮。它在rank0、candidate第2轮、step12、CPU索引110..113首先失败（candidate=-1，Native=0）。所有位置均在actual126行窗口内，不属于graph144的尾部padding。该失败日志和旧脚本保留，不覆盖为PASS。

独立逐rank/step穷举结果：

| candidate measured | Native measured | 完整metadata不同的行/320 | CPU不同元素 |
| --- | --- | ---: | ---: |
| 1 | 1 | 0 | 0 |
| 1 | 2 | 96 | 416 |
| 2 | 1 | 96 | 416 |
| 2 | 2 | 0 | 0 |
| 3 | 1 | 96 | 416 |
| 3 | 2 | 0 | 0 |

同phase所选pair全部字段（包括input_ids）仅排除process-local call计数，逐字相同；没有normalize或省略input_ids。不同phase只出现0/-1观察差异，其他工作负载几何精确。完整832个candidate2/3对Native1的位置保存在`all-first-reference-differences.json`；独立review还保存全部六pair完整差异。

经独立review后使用固定规则：candidate iteration1→Native iteration1；candidate iteration2/3→Native iteration2。选择只依赖measured iteration编号，不搜索“最接近”的参考，也不根据数据动态挑选。称为first/repeated measured阶段，不声称cold/init/首次capture因果。

所有16rank warmup加3轮192-token实测独立核验：294,912个输出token、61,568个接受事件逐项等于Native黄金结果，零抢占。这些输出事实单独记录，不能替代失败的原all-to-first CPU门禁；新的phase门禁则对正确参照阶段重新执行全部相同字段比较。新CPU负例进一步证明同phase任意0↔-1改动仍失败。
