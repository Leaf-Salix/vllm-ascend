"""Independent read-only CPU audit; run with server Python, without NPU imports."""

import hashlib
import json
import math
import statistics
from pathlib import Path
from audit_identity import arguments, formal_identity

args = arguments("128k")
root = args.root
policy_path = Path(__file__).parent / "phase-policy.json"
policy = json.loads(policy_path.read_text())
assert policy["candidate_to_native_iteration"] == {"1": 1, "2": 2, "3": 2}
assert policy["excluded_metadata_fields"] == ["call"]
native = Path("/data/pyptouser/yejia/lc128/perf-single-dsl-128k-native-20261018-v2")
native128 = Path("/data/pyptouser/yejia/lc128/perf-single-dsl-128k-native-20261018-v2")


def load(p):
    return json.loads(Path(p).read_text())


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


config = load(root / "configuration.json")
reference_config = load(native / "configuration.json")
assert (
    config["case"] == "128k"
    and config["batch"] == 24
    and config["repeats"] == args.repeats
)
assert (
    config["capture_sizes"] == [6, 144] and config["active_requests_for_timing"] == 21
)
assert config["decode_tokens"] == config["warmup_tokens"] == 192
assert config["single_pto_entry"] and config["handwritten_cpp"] is False
for field in (
    "bank_plan_sha256",
    "runtime_manifest_sha256",
    "bank",
    "blocks",
    "capture_sizes",
    "batch",
    "decode_tokens",
    "warmup_tokens",
    "static_metadata_sha256",
):
    assert config[field] == reference_config[field], field
assert not list(root.glob("**/*STOP.json"))
assert sha(config["snapshot_manifest"]) == config["source_manifest_sha256"]
source_files = load(config["snapshot_manifest"])["files"]
for name, digest in source_files.items():
    assert sha(Path(config["snapshot"]) / name) == digest, name
identity = formal_identity(config, args)
job = Path(config["snapshot"]).parents[1]
assert sha(job / "helper-manifest.json") == config["helper_manifest_sha256"]
for name, digest in load(job / "helper-manifest.json")["files"].items():
    assert sha(job / name) == digest, name


def geometry(rows):
    # Keep input_ids_cpu when present; only process-local execution call numbers
    # may differ between historical repeated Native windows.
    return [
        {k: v for k, v in row.items() if k not in ("call", "input_ids_cpu")}
        for row in rows
    ]


total_tokens = total_events = 0
input_ids_observation_differences = []
phase_matched_all_metadata_except_call_equal = True
candidate_reports, native_reports = [], []
for rank in range(16):
    data = load(root / f"rank{rank}.real_perf.json")
    control = load(native / f"rank{rank}.real_perf.json")
    assert data["rank"] == rank and data["batch"] == 24 and data["backend"] == "pto"
    assert (
        data["variant"] == "tnd_full_precision" and len(data["rounds"]) == args.repeats
    )
    assert len(data["implementations"]) == len(data["worker_runtime_config"]) == 1
    runtime = data["worker_runtime_config"][0]
    assert runtime["deterministic_level"] == 1 and runtime["torch_deterministic"]
    assert runtime["hccl_deterministic"] == "true" and not runtime["dynamic_eplb"]
    assert runtime["cann_event_work_mode"] == 1
    implementations = data["implementations"][0]
    csa = [v for v in implementations if v["kind"] == "csa"]
    hca = [v for v in implementations if v["kind"] == "hca"]
    assert len(csa) == 21 and all(v["implementation"] == "pto" for v in csa)
    assert len(hca) == 20 and all(v["implementation"] == "native" for v in hca)
    gold_root = Path(config["gold"])
    gold = {
        r["key"]: r["output_token_ids"]
        for r in load(gold_root / f"rank{rank}.mixed.json")["requests"]
    }
    event_gold = {
        r["key"]: r["events"]
        for r in (
            json.loads(line)
            for line in (gold_root / f"request_stats_rank{rank}.jsonl")
            .read_text()
            .splitlines()
        )
    }
    assert len(gold) == len(event_gold) == 24
    for request_list in [
        data["warmup"]["requests"],
        *(record["requests"] for record in data["rounds"]),
    ]:
        assert len(request_list) == 24 and {r["key"] for r in request_list} == set(gold)
        for request in request_list:
            assert request["preemptions"] == 0
            assert len(request["output_token_ids"]) == 192
            assert request["output_token_ids"] == gold[request["key"]]
            assert request["events"] == event_gold[request["key"]]
            total_tokens += len(request["output_token_ids"])
            total_events += len(request["events"])
    assert [record["iteration"] for record in data["rounds"]] == list(
        range(1, args.repeats + 1)
    )
    assert [record["iteration"] for record in control["rounds"]] == [1, 2]
    for candidate_round in data["rounds"]:
        reference_iteration = 1 if candidate_round["iteration"] == 1 else 2
        assert (
            len(candidate_round["timing"])
            == len(candidate_round["identity_before"])
            == 1
        )
        timing = candidate_round["timing"][0]
        assert timing["sufficient"] and timing["measured_steps"] == 20
        assert len(timing["metadata"]) == len(timing["forward"]["samples_us"]) == 20
        assert len(timing["cycle"]["samples_us"]) == 19
        qualification = timing["identity"]["static_full_qualification"]
        assert qualification["ready"] and qualification["actual_reselections"] == 1
        assert qualification["validated_reuses"] > 0
        assert qualification["metadata_sha256"] == config["static_metadata_sha256"]
        assert qualification["root_abi_tensors"] == 62
        assert (
            qualification["root_namespace"] == "dsv4_csa_tnd_full_precision::attention"
        )
        expected_layers = {f"model.layers.{i}.self_attn.attn" for i in range(2, 43, 2)}
        assert set(qualification["single_root_counts"]) == expected_layers
        for counts in qualification["single_root_counts"].values():
            for bucket in (6, 144):
                assert (
                    counts[str(bucket)]["warmup"] > 0
                    and counts[str(bucket)]["capture"] > 0
                )
        assert set(timing["identity"]["capture_time_selection"]) == expected_layers
        for counts in timing["identity"]["capture_time_selection"].values():
            assert all(counts.get(f"pto_tokens{n}", 0) > 0 for n in (6, 21, 144))
        for metadata in timing["metadata"]:
            assert (
                metadata["requests"] == 21
                and metadata["actual_tokens"] == 126
                and metadata["padded_tokens"] == 144
            )
            assert (
                metadata["graph_mode"] == "FULL" and metadata["dp_tokens"] == [144] * 16
            )
        assert control["rounds"][0]["iteration"] == 1
        for native_round in control["rounds"]:
            assert len(native_round["timing"][0]["metadata"]) == 20
            for step, (left, right) in enumerate(
                zip(timing["metadata"], native_round["timing"][0]["metadata"])
            ):
                assert (
                    len(left["input_ids_cpu"])
                    == len(right["input_ids_cpu"])
                    == left["actual_tokens"]
                    == right["actual_tokens"]
                )
                differences = [
                    (i, a, b)
                    for i, (a, b) in enumerate(
                        zip(left["input_ids_cpu"], right["input_ids_cpu"])
                    )
                    if a != b
                ]
                assert all({a, b} == {0, -1} for _, a, b in differences), (
                    rank,
                    step,
                    "CPU observer differs beyond known zero/negative sentinel",
                )
                if native_round["iteration"] == reference_iteration:
                    assert {k: v for k, v in left.items() if k != "call"} == {
                        k: v for k, v in right.items() if k != "call"
                    }, (
                        rank,
                        candidate_round["iteration"],
                        step,
                        differences[:4],
                        "Phase-matched Native window full CPU geometry",
                    )
                if differences:
                    input_ids_observation_differences.append(
                        {
                            "rank": rank,
                            "candidate_round": candidate_round["iteration"],
                            "Native_round": native_round["iteration"],
                            "step": step,
                            "different_elements": len(differences),
                            "known_0_negative1_sentinel_only": True,
                            "actual_tokens": left["actual_tokens"],
                            "examples": differences[:4],
                        }
                    )
                    if native_round["iteration"] == reference_iteration:
                        phase_matched_all_metadata_except_call_equal = False
            assert geometry(timing["metadata"]) == geometry(
                native_round["timing"][0]["metadata"]
            )
            assert {
                r["key"]: r["output_token_ids"] for r in native_round["requests"]
            } == gold
            assert {
                r["key"]: r["events"] for r in native_round["requests"]
            } == event_gold
        before = candidate_round["identity_before"][0]["cache_stats"]
        after = timing["identity"]["cache_stats"]
        for field in (
            "generation_builds",
            "binary_builds",
            "bypasses",
            "invalid_entries",
            "storage_errors",
            "forced_rebuilds",
        ):
            assert before[field] == after[field], field
            if field in (
                "bypasses",
                "invalid_entries",
                "storage_errors",
                "forced_rebuilds",
            ):
                assert before[field] == after[field] == 0, field
    candidate_reports.append(data)
    native_reports.append(control)


def max_rank_mean(reports, kind="forward"):
    values = []
    for round_id in range(len(reports[0]["rounds"])):
        samples = [
            r["rounds"][round_id]["timing"][0][kind]["samples_us"] for r in reports
        ]
        width = len(samples[0])
        assert width == (20 if kind == "forward" else 19) and all(
            len(v) == width and all(math.isfinite(x) and x > 0 for x in v)
            for v in samples
        )
        values.extend(
            max(rank_values[i] for rank_values in samples) for i in range(width)
        )
    return statistics.mean(values)


assert phase_matched_all_metadata_except_call_equal
candidate_us = max_rank_mean(candidate_reports)
native_us = max_rank_mean(native_reports)
result = {
    "pass": True,
    "reference_phase_policy": policy,
    "reference_phase_policy_sha256": sha(policy_path),
    "auditor_sha256": sha(Path(__file__)),
    **identity,
    "root": str(root),
    "tokens_equal_native": total_tokens,
    "accept_events_equal_native": total_events,
    "zero_preemptions": True,
    "real_ranks": 16,
    "candidate_rounds_audited": args.repeats,
    "CSA_layers_per_worker": 21,
    "HCA_native_layers_per_worker": 20,
    "single_root_tensors": 62,
    "buckets": [6, 144],
    "submitted_requests": 24,
    "active_requests_in_measured_window": 21,
    "all16_all_native_rounds_workload_geometry_equal": True,
    "Native_reference_rounds": len(native_reports[0]["rounds"]),
    "geometry_fields_include": ["keys", "query_bounds", "positions_cpu", "dp_tokens"],
    "all_candidate_rounds_vs_phase_matched_native_window_all_CPU_metadata_except_call_equal": phase_matched_all_metadata_except_call_equal,
    "input_ids_cpu_is_CPU_observer_not_actual_GPU_argument": True,
    "input_ids_cpu_observation_differences": input_ids_observation_differences,
    "later_Native_window_differences_restricted_to_known_CPU_0_negative1_sentinels": True,
    "sentinel_differences_do_not_prove_GPU_padding_or_actual_GPU_input_equality": True,
    "source_files_rehashed": len(source_files),
    "target_forward_ms": candidate_us / 1000,
    "target_cycle_ms": max_rank_mean(candidate_reports, "cycle") / 1000,
    "Native_historical_cycle_ms": max_rank_mean(native_reports, "cycle") / 1000,
    "Native_historical_forward_ms": native_us / 1000,
    "candidate_over_native": candidate_us / native_us,
    "Native_128k_perf_root": str(native),
    "Native_128k_exists": (native128 / "rank15.real_perf.json").exists(),
    "scope": "Complete saved tokens/events and measured CPU workload geometry; not all internal tensor hooks; historical timings, no new Native2.",
}
print(json.dumps(result, indent=2))
