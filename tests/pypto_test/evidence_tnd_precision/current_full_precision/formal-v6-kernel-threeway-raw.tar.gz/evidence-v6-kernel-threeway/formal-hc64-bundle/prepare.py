"""仅在reports生成HC两文件原子bundle；不修改正式checkout。"""
import ast
import hashlib
import json
from pathlib import Path
import textwrap
HERE=Path(__file__).resolve().parent;R=HERE.parent
FULL='vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision'
base=R/'whole-formal-v4/patch'/FULL/'hc_pre.py'
private=R/'math/hc-linear-m64-probe-v3/candidate_hc.py'
panel=R/'math/hc-linear-m64-probe-v3/candidate_panel.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(base)=='8173df7f776aec90aa773a6a3dc1459bfec11241fabb0f60788d5edc12066491'
assert sha(private)=='bc08bb3c5477f8d6d56755acc2309332c7680bc820ca38214367333be0d63822'
assert sha(panel)=='f2b1ce10540509ba0237d2926b0d4b26c1a308c77aa38a12cee307da621ccb52'
fn=lambda t:next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='hc_pre_gates_from_rms')
old=base.read_text();tree=ast.parse(old);f=fn(tree);branch=next(n for n in f.body if isinstance(n,ast.If) and ast.unparse(n.test)=='t_dim < PANEL_MIN_TOKENS')
newf=fn(ast.parse(private.read_text()));i=next(i for i,n in enumerate(newf.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='mixes_partials' for t in n.targets));j=next(i for i,n in enumerate(newf.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='mixes_raw' for t in n.targets))
block=newf.body[i+1:j]
assert ast.unparse(block[0].targets[0])=='panel64_packed_weight'
lines=old.splitlines(keepends=True);prefix=''.join(lines[:branch.lineno-1]);suffix=''.join(lines[branch.end_lineno:]);importline='from .hc_pre_panel import hcpre_linear_panel\n';assert prefix.count(importline)==1
prefix=prefix.replace(importline,'')
body=textwrap.indent(ast.unparse(ast.Module(body=block,type_ignores=[])),'    ')+'\n'
patch=HERE/'patch'/FULL;patch.mkdir(parents=True,exist_ok=True)
(patch/'hc_pre.py').write_text(prefix+body+suffix)
(patch/'hc_pre_panel.py').write_bytes(panel.read_bytes())
(HERE/'source-inputs.json').write_text(json.dumps({'base_hc':{'path':str(base.relative_to(R)),'sha256':sha(base)},'private_HC':{'path':str(private.relative_to(R)),'sha256':sha(private)},'private_panel':{'path':str(panel.relative_to(R)),'sha256':sha(panel)},'only_replaced_original_if_lines':[branch.lineno,branch.end_lineno],'removed_unused_import':importline.strip(),'old_before_after_bytes_preserved_except_unused_import':True,'old_scalar_public_alias_retained':True,'T6_hardware_pending':True},indent=2)+'\n')
print('REPORT_ONLY_HC_TWO_FILE_PREPARED')
