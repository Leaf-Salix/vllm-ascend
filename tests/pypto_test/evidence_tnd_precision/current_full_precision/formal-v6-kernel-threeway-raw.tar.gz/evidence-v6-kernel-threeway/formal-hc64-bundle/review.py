"""独立核对两文件bundle数学、非改区字节与public scalar入口；不执行设备。"""
import ast
import hashlib
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent;R=HERE.parent
FULL='vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision'
base=R/'whole-formal-v4/patch'/FULL/'hc_pre.py';private=R/'math/hc-linear-m64-probe-v3/candidate_hc.py';target=HERE/'patch'/FULL/'hc_pre.py'
old=base.read_text();new=target.read_text();oldtree=ast.parse(old);newtree=ast.parse(new);ptree=ast.parse(private.read_text())
dump=lambda n:ast.dump(n,include_attributes=False)
funcs=lambda t:{n.name:n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
basef,newf,pf=funcs(oldtree),funcs(newtree),funcs(ptree)
name='hc_pre_gates_from_rms';assert dump(newf[name])==dump(pf[name]),'new formal gates differs from tested bc08'
assert set(basef)==set(newf)
for k,v in basef.items():
 if k!=name:assert dump(v)==dump(newf[k]),k+' changed from formal V4'
branch=next(n for n in basef[name].body if isinstance(n,ast.If) and ast.unparse(n.test)=='t_dim < PANEL_MIN_TOKENS')
lines=old.splitlines(keepends=True);prefix=''.join(lines[:branch.lineno-1]).replace('from .hc_pre_panel import hcpre_linear_panel\n','');suffix=''.join(lines[branch.end_lineno:])
assert new.startswith(prefix),'original before-block bytes/comments changed'
assert new.endswith(suffix),'original after-block bytes/comments changed'
assert 'from .hc_pre_panel import hcpre_linear_panel' not in new
assert 'hcpre_linear_test = pl.jit(_hcpre_linear_dsl)' in new
panel=ast.parse((HERE/'patch'/FULL/'hc_pre_panel.py').read_text());source=ast.parse((R/'math/hc-linear-m64-probe-v3/candidate_panel.py').read_text());assert dump(panel)==dump(source),'panel math changed beyond formatting'
# Module-level constants and aliases remain V4; only one now-unused import removed.
nonfn=lambda t:[n for n in t.body if not isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.ImportFrom))]
assert list(map(dump,nonfn(newtree)))==list(map(dump,nonfn(oldtree)))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r={'source_AST_pass':True,'device_accepted':False,'T6_receipt_pending':not (HERE/'private-HW-receipts.json').exists(),'private_HC_three_shapes_HW_pass':(HERE/'private-HW-receipts.json').exists(),'production_repo_touched':False,'base_formal_hc_sha256':sha(base),'tested_private_hc_sha256':sha(private),'formal_gates_function_AST_exact_tested_bc08':True,'all_other_formal_V4_functions_AST_exact':True,'before_and_after_original_bytes_comments_exact_except_unused_import':True,'public_scalar_test_alias_original_V4':True,'squaregroup4_and_PANEL_MIN1_preserved':True,'panel_AST_exact_f2b':True,'atomic_two_file_math':{FULL+'/hc_pre.py':sha(target),FULL+'/hc_pre_panel.py':sha(HERE/'patch'/FULL/'hc_pre_panel.py')},'scope':'T1..256 eligibility; source conversion only; no new device run implied'}
(HERE/'AST_BYTE_REVIEW.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
