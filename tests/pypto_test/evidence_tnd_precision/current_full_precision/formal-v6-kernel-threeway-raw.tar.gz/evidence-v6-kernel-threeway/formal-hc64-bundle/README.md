# HC M64 两文件原子转换包

仅reports封包，不改生产repo。`patch`恰好两个文件，需作为同一bundle使用。

- 以正式V4 `hc_pre.py` 8173…为底，只替换 `hc_pre_gates_from_rms` 中 `mixes_partials`创建后的原if调用区域，插入已测private bc08…的panel64实际body，截止 `mixes_raw`之前；删除未使用panelimport。
- 替换区前后原始字节、原注释全部保留；所有其他函数和public scalar test alias保持V4原样，square-group4与PANEL_MIN1保留。
- 正式panel只是private f2b…的Ruff格式化，没有改数值、布局或K顺序。
- `AST_BYTE_REVIEW.json`逐项证明上述关系。已通过Ruff检查/格式，未改SDK。

主线程已确认private HC三档T144/T240/T6各27项Native门禁通过；此转换包自身尚未跑正式设备门禁。最终V6 source需重新冻结43文件与完整manifest，执行自身单层门禁和真实8K/128K验收，不能用private收据替代最终源执行。
