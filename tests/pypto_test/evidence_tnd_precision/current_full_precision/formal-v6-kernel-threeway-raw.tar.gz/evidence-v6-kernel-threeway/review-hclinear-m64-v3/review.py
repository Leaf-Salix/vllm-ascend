"""Independent v3 full HC caller generated scope/tail review; no compile/NPU."""
from pathlib import Path
import ast,hashlib,json,re
P=Path(__file__).resolve().parent;B=P.parent/'math/hc-linear-m64-probe-v3';G=B/'generated-review/candidate_full';dump=lambda n:ast.dump(n,include_attributes=False)
assert hashlib.sha256((B/'candidate_hc.py').read_bytes()).hexdigest()=='bc08bb3c5477f8d6d56755acc2309332c7680bc820ca38214367333be0d63822'
a=ast.parse((B/'reference_v4_hc.py').read_text());b=ast.parse((B/'candidate_hc.py').read_text());af={n.name:n for n in a.body if isinstance(n,ast.FunctionDef)};bf={n.name:n for n in b.body if isinstance(n,ast.FunctionDef)};assert set(af)==set(bf)
for name in af:
 if name!='hc_pre_gates_from_rms':assert dump(af[name])==dump(bf[name]),name
assert dump(af['_hcpre_linear_dsl'])==dump(bf['_hcpre_linear_dsl'])
s=(G/'orchestration/_hc_pre_test.cpp').read_text();alloc=s.index('const Tensor& mixes_partials_inline1638_inline1833 = alloc_4.get_ref(0);');branch=s.index('if ((64 <= t_dim_inline1671_inline1870))',s.index('Tensor mixes_partials_inline1638_inline1833__phi_v3'))
assert alloc<branch
assert s.count('add_output(mixes_partials_inline1638_inline1833);')==2
assert s.count('mixes_partials_inline1638_inline1833__phi_v3 = mixes_partials_inline1638_inline1833;')==2
assert 'params_t7.add_input(mixes_partials_inline1638_inline1833__phi_v3);' in s
p=G/'kernels/aic/hcpre_bf16_half_exact8_m64.cpp';c=p.read_text();assert 'v82.SetValidShape(v52, v12);' in c and 'TSTORE(v122, v82);' in c
assert 'v52 = v51 < v14 ? v51 : v14;' in c
assert 'Shape<1, 1, 1, -1, 32>(v115, v116, v117, v52, v12)' in c
assert 'wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);' in c
result={'pass':True,'NPU_executed':False,'full_HC_parent_partials_alloc_before_branch':True,'M16_M64_same_Out_phi_descriptor_consumed_reduce_after_scope_exit':True,'valid48_M64_tail_not_cross_split':True,'all_other_V4_HC_functions_AST_unchanged':True,'V4_square_group4_and_short_MIN1_preserved':True,'original_scalar_DSL_function_and_alias_definition_preserved':True,'formal_packaging_must_remove_final_private_panel_test_alias_like_V4':True,'scope':'static full-HC generated proof only; HW144/240/6 still required'}
(P/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
