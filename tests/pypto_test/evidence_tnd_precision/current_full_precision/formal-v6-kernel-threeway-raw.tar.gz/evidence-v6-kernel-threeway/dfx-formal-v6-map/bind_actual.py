"""Bind independently reviewed V6 trace to a successful actual live capture."""
from pathlib import Path
import argparse,json,hashlib
p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--reference',type=Path,default=Path(__file__).parent/'reference-token-map.json');p.add_argument('--review',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads(a.reference.read_text());v=json.loads(a.review.read_text());assert v['pass'] is True and v['reference_map_sha256']==sha(a.reference),'independent exact reference review required'
r=json.loads((a.run/'result.json').read_text());assert r['complete'] is True and r['pass'] is True and r['lengths']==[6]*40 and r['true_tokens']==240 and r['layer']==4 and r['history']==8191
assert r['variant_manifest_sha256']=='6d9656de4580ba5f768881c417f3093a7744808ac6518c594e9db881971e7ab2';assert r['timing_executed'] is False and r['dfx']['windows']==3 and r['dfx']['level']==4 and r['dfx']['dependency_generation'] is False
artifact=a.run/'current-artifact';d=json.loads((artifact/'artifact.json').read_text())
for k,n in [('config_sha256','kernel_config.py'),('orchestration_sha256','orchestration.cpp')]:assert m[k]==d[k]==sha(artifact/n),(k,'actual capture differs: must review actual source and regenerate trace, never force acceptance')
m.update(complete=True,reference_only_before_live_capture=False,review_status='PASS',independent_review_sha256=sha(a.review),actual_result_sha256=sha(a.run/'result.json'),actual_artifact_sha256=sha(artifact/'artifact.json'))
a.out.write_text(json.dumps(m,indent=2)+'\n');print('V6_MAP_BOUND_TO_ACTUAL; next strict analyzer must verify all three windows tokens/core/count')
