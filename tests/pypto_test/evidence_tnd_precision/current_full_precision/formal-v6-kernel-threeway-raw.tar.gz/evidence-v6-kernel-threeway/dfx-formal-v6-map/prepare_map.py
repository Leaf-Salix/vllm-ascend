"""Reference V6 B40 executed alloc/submit trace, not captured DFX acceptance."""
from pathlib import Path
import ast,re,json,hashlib
P=Path(__file__).resolve().parent;G=P.parent/'formal-v6-generated-review/full';s=(G/'orchestration/_full_csa_tnd.cpp').read_text();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
kernels=ast.literal_eval(next(n.value for n in ast.parse((G/'kernel_config.py').read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='KERNELS' for t in n.targets)));byid={k['func_id']:k for k in kernels}
# Each event below is independently taken from this V6 orchestration, including
# every executed allocation and dependency-only dummy. Ring counters persist
# across sequential scopes of the same depth. No V4 token identifiers are read.
trace={0:['a0','a1',17,18],1:['a2','a3',0,'a4','a5','a6',1,2,'a7',3,'a8',4,5,'a9',7,8,9,10,11,'a10',13,14,'a11',15,16,'a12','a13','d0','a14','a15',19,'d1','d2',27,'d3',28,29,30,31,32,33,34,35,36,37,38,39,57,'a26','a27','a28',58,59,'a29','a30','a31',60,61,62,'a32',*[64]*8,66,67,'a33',69,70,71],2:['a16',20,21,22,'a17',23,24,'a18',25,26,'a19',40,41,'a20',42,43,'d4',44,45,'a23',50,51,63],3:[55]}
# T=240, padded T=240, B=40; grid values from actual launch expressions.
# query-derived units: ceil(T/8)=30, ceil(T/16)=15, ceil(T/32)=8.
grid={0:240,1:90,2:30,3:64,4:240,5:88,7:15,8:16,9:30,10:30,11:240,13:64,14:15,15:60,16:15,17:1,18:16,19:30,20:1,21:32,22:16,23:24,24:48,25:15,26:8,27:8,28:24,29:40,30:40,31:15,32:24,33:40,34:40,35:40,36:2,37:1,38:5,39:1,40:24,41:48,42:24,43:48,44:15,45:1,50:40,51:24,55:48,57:1,58:48,59:32,60:24,61:16,62:48,63:48,64:8,66:120,67:30,69:128,70:120,71:60}
entries={};events=[]
for ring,seq in trace.items():
 for local,item in enumerate(seq):
  if isinstance(item,str):
   if item[0]=='a':pattern=r'TaskOutputTensors alloc_'+item[1:]+r' = alloc_tensors\('
   else:pattern=r'TaskOutputTensors phase_fence_barrier_'+item[1:]+r'_outs = rt_submit_dummy_task\('
   m=re.search(pattern,s);assert m,item
   events.append({'token':f'{ring}:{local}','event':item,'source_line':s[:m.start()].count('\n')+1});continue
  pattern=r'(?:TaskOutputTensors task_'+str(item)+r'_outs = )?rt_submit_(aic_task|aiv_task|task)\((\w+), params_t'+str(item)+r'\);'
  found=list(re.finditer(pattern,s));assert len(found)==1,(item,len(found));m=found[0];arg=m.group(2)
  if arg.startswith('mixed_'):
   mm=re.search(r'MixedKernels '+arg+r' = \{(\d+), (\d+), (\d+)\};',s);assert mm;ids=list(map(int,mm.groups()));funcids=list(dict.fromkeys(ids));counts={}
   for f in ids:counts[byid[f]['core_type']]=counts.get(byid[f]['core_type'],0)+grid[item]
  else:funcids=[int(arg)];counts={byid[int(arg)]['core_type']:grid[item]}
  line=s[:m.start()].count('\n')+1;entries[f'{ring}:{local}']={'func_ids':funcids,'expected_executions':counts,'source_lines':[line]};events.append({'token':f'{ring}:{local}','event':'task'+str(item),'func_ids':funcids,'grid':grid[item],'source_line':line})
result={'complete':False,'reference_only_before_live_capture':True,'derivation':'reviewed actual current alloc/submit order with executed branches','config_sha256':sha(G/'kernel_config.py'),'orchestration_sha256':sha(G/'orchestration/_full_csa_tnd.cpp'),'case':{'T':240,'B':40,'S':6,'history':8191,'actual_seq_len':8197,'max_topk_cache_len':2049,'short_request_groups':40,'short_pair_groups':120,'short_request_waves':2,'short_pair_waves':5,'selected_score_branch':'request40 because40>=24 and2*24<=5*10','selected_merge':'single-leaf because2049<=8192','HC_square_group':4,'HC_linear_M':64,'Oproj_seed_groups':8,'checked_workers':48,'slots_workers':32},'entries':entries,'trace':events}
(P/'reference-token-map.json').write_text(json.dumps(result,indent=2)+'\n');print('REFERENCE_ONLY',len(entries),'tokens; needs independent review and live artifact SHA before complete')
