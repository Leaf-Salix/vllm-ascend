# 三窗DFX草稿清单

- [x] 新目录；不改V4/生产/SDK。
- [x] Native与候选门禁AST对照V4不变；fixture原字节。
- [x] T240/B40/S6/L4/8191固定；level4、dep-gen关闭、三窗。
- [x] 去掉正式计时与成功后大cache witness持久化。
- [x] 只读已注册live artifact；映射绑定实际当前orch/config SHA。
- [x] 未知token、core/count/代码SHA错误时拒绝命名统计。
- [x] Python py_compile、shell bash -n、CPU AST检查。
- [ ] 主线程将来安排单卡小NPU采集（本助手作者不提交）。
- [ ] 从采集的当前实际alloc/submit路径重建并review token map。
- [ ] 命名分析三窗全部通过；正式延迟另跑无DFX。

227纯CPU环境/API预检已通过：当前V4 root63b5717470ed3b690e4d984435685ee1b2afcdc87e24652776efe6d71be4cdeb，私有KernelRegistration/Worker registry读取接口存在；未初始化Worker或执行NPU。独立reference_probe_v4.py保存原门禁供离线AST复核，禁止把该参考脚本当采集入口。
