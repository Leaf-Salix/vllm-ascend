"""CPU AST guard-equivalence/synthetic artifact tests; never import NPU packages."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import subprocess
import sys
HERE=Path(__file__).resolve().parent
reference=HERE/'reference_probe_v4.py'
old=ast.parse(reference.read_text());new=ast.parse((HERE/'probe_dfx.py').read_text())
dump=lambda n:ast.dump(n,include_attributes=False)
for name in ('NativeHalf','PTOHalf','RequirePTO'):
 get=lambda t:next(n for n in t.body if isinstance(n,ast.ClassDef) and n.name==name)
 assert dump(get(old))==dump(get(new)),name
for name in ('save','exact','metric'):
 get=lambda t:next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name==name)
 assert dump(get(old))==dump(get(new)),name
getloop=lambda t:next(n for n in ast.walk(t) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='arm' and isinstance(n.iter,ast.Tuple))
b,c=getloop(old),getloop(new)
assert ast.literal_eval(c.iter)==('native','candidate')
bi=next(i for i,n in enumerate(b.body) if isinstance(n,ast.FunctionDef) and n.name=='context')
ci=next(i for i,n in enumerate(c.body) if isinstance(n,ast.FunctionDef) and n.name=='context')
# The only pre-context change is how the explicit candidate root gets imported
# and registered; fixture construction/Native initial-state identity unchanged.
assert [dump(n) for n in b.body[:bi-1]]==[dump(n) for n in c.body[:ci-1]]
class Namespace(ast.NodeTransformer):
 def visit_Assign(self,n):
  if any(isinstance(t,ast.Name) and t.id=='expected_namespace' for t in n.targets):n.value=ast.Constant('PROFILE_NAMESPACE')
  return self.generic_visit(n)
def is_snapshot(n):
 return isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and n.value.func.attr=='save' and isinstance(n.value.func.value,ast.Name) and n.value.func.value.id=='torch'
assert [dump(Namespace().visit(copy.deepcopy(n))) for n in b.body[bi:] if not is_snapshot(n)]==[dump(Namespace().visit(copy.deepcopy(n))) for n in c.body[ci:]],'Native/output/cache/ABA/guard capture gate drift'
assert hashlib.sha256((HERE/'ragged_fixture.py').read_bytes()).hexdigest()=='e20e16fd15843afe330e79b101307782c2883bc6ecb276952fe0dcee48fb7aca'
assert 'enable_chip_swimlane=4, enable_dep_gen=False' in (HERE/'probe_dfx.py').read_text()
assert "for window in range(3):" in (HERE/'probe_dfx.py').read_text()
assert 'torch.npu.Event' not in (HERE/'probe_dfx.py').read_text()
assert 'elapsed_time' not in (HERE/'probe_dfx.py').read_text()
assert "report['timing_executed']=False" in (HERE/'probe_dfx.py').read_text()
result={'pass':True,'scope':'CPU/AST only; DFX helper has not run NPU','gate_reference_sha256':hashlib.sha256(reference.read_bytes()).hexdigest(),'numerical_gate_AST_unchanged':True,'fixture_bytes_unchanged':True,'only_native_and_candidate_arms':True,'three_windows_level4_depgen_false':True,'formal_timing_removed':True}
(HERE/'cpu-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
