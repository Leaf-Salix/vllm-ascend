"""Read actual prepared Worker artifact metadata; never compile or launch."""
import ast
import hashlib
import json
from pathlib import Path
import shutil


def capture_actual_artifact(destination):
    from pypto.runtime.kernel.context import get_process_kernel_state
    state=get_process_kernel_state()
    # Freeze read-side registry only. This does not call ensure_callable/prepare,
    # JIT compile, or any Worker submission API.
    with state._condition:
        registrations=list(state._registrations.values())
    found=[]
    for registration in registrations:
        directory=Path(registration.artifact.output_dir)
        configs=list(directory.rglob('kernel_config.py'))
        for config in configs:
            node=next((n for n in ast.parse(config.read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='KERNELS' for t in n.targets)),None)
            if node is None:continue
            kernels=ast.literal_eval(node.value)
            names={k['name'] for k in kernels}
            if not {'hc_post','comb_sinkhorn','csa_checked_indices','csa_slots_build_valid_qk_plan'}.issubset(names):continue
            sources=list((config.parent/'orchestration').glob('*.cpp'))
            if len(sources)!=1:continue
            source=sources[0]
            found.append({'artifact_dir':str(directory),'config':config,'orchestration':source,'kernel_count':len(kernels),
                          'config_sha256':hashlib.sha256(config.read_bytes()).hexdigest(),'orchestration_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
                          'prepared_identity':registration.identity.hex()})
    assert found,'No actually prepared complete CSA artifact found; never guess from old build paths'
    identities={(r['config_sha256'],r['orchestration_sha256']) for r in found}
    assert len(identities)==1, 'Multiple different CSA artifacts prepared; require explicit live-handle attribution'
    destination=Path(destination);destination.mkdir()
    current=found[0]
    shutil.copyfile(current['config'],destination/'kernel_config.py')
    shutil.copyfile(current['orchestration'],destination/'orchestration.cpp')
    result={k:v for k,v in current.items() if k not in ('config','orchestration')}
    result['all_prepared_identities']=[r['prepared_identity'] for r in found]
    result['mapping_status']='UNMAPPED until reviewed current alloc/submit token map is supplied'
    (destination/'artifact.json').write_text(json.dumps(result,indent=2)+'\n')
    return result
