#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit must allocate a card}"
: "${DFX_VARIANT_DIR:?explicit frozen variant directory}"
: "${DFX_VARIANT_ENV:?explicit frozen variant env.sh}"
: "${DFX_EXPECTED_VARIANT_MANIFEST_SHA:?must pin the selected variant manifest}"
dfx_helper=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$DFX_VARIANT_ENV"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE" PYTHONNOUSERSITE=1
export PYTHONPATH="$dfx_helper:$PYTHONPATH"
export PYPTO_PROG_BUILD_DIR="$dfx_helper/build" PYPTO_CACHE_DIR="$dfx_helper/cache"
out="$dfx_helper/results/${1:?new run label}"
mkdir -p "$dfx_helper/results"
mkdir "$out"
export ASCEND_CACHE_PATH="$out/ascend-cache" ASCEND_PROCESS_LOG_PATH="$out/ascend"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
ccache -s > "$out/ccache.log"
python "$dfx_helper/preflight.py" > "$out/preflight.log" 2>&1
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out/opp_env")
export VLLM_CACHE_ROOT="$out/vllm-cache"
lengths=$(python -c 'print(",".join(["6"]*40))')
python "$dfx_helper/probe_dfx.py" --out "$out/data" --lengths "$lengths" --layer 4 --history 8191 --root-module "${DFX_ROOT_MODULE:-candidate_csa}" --root-symbol "${DFX_ROOT_SYMBOL:-decode_csa_tp1_layer_test}" > "$out/run.log" 2>&1
python "$dfx_helper/inventory_mapping.py" --artifact "$out/data/current-artifact" --out "$out/mapping-inventory.json"
