"""Emit source callsite inventory only; never guess runtime ring/local IDs."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
p=argparse.ArgumentParser();p.add_argument('--artifact',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
config=a.artifact/'kernel_config.py';source=a.artifact/'orchestration.cpp'
node=next(n for n in ast.parse(config.read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='KERNELS' for t in n.targets))
kernels=ast.literal_eval(node.value);calls=[]
for i,line in enumerate(source.read_text().splitlines(),1):
 if any(s in line for s in ('alloc_tensors(','rt_submit_','SIMPLER_SCOPE()','if (','for (')):
  calls.append({'line':i,'source':line.strip()})
result={'complete':False,'purpose':'Reviewer computes executed current alloc/submit ring-local IDs; do not use old DFX IDs',
 'config_sha256':hashlib.sha256(config.read_bytes()).hexdigest(),'orchestration_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'kernels':kernels,'callsites':calls,
 'required_map_schema':{'complete':True,'derivation':'reviewed actual current alloc/submit order with executed branches','config_sha256':'same as this inventory','orchestration_sha256':'same as this inventory','entries':{'ring:local':{'func_ids':['actual func_id or mixed aic/aiv pair'],'expected_executions':{'aic':'actual grid count if present','aiv':'actual grid count if present'},'source_lines':['current alloc/submit derivation evidence']}}}}
a.out.write_text(json.dumps(result,indent=2)+'\n');print('CURRENT_CALLSITE_INVENTORY_READY: mapping still requires review')
