#!/usr/bin/env bash
export DFX_VARIANT_DIR=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overnight-20261019/whole-formal-v6/snapshot/source
export DFX_VARIANT_ENV=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overnight-20261019/formal-csa-v6/env.sh
export DFX_EXPECTED_VARIANT_MANIFEST=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overnight-20261019/whole-formal-v6/snapshot/manifest.json
export DFX_EXPECTED_VARIANT_MANIFEST_SHA=6d9656de4580ba5f768881c417f3093a7744808ac6518c594e9db881971e7ab2
export DFX_ROOT_MODULE=vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.decode_csa
export DFX_ROOT_SYMBOL=decode_csa_tp1_layer_test
