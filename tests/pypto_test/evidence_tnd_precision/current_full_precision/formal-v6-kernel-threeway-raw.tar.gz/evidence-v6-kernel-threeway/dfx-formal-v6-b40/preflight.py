"""Device-free provenance/environment checks for the optional DFX draft."""
import hashlib
import importlib
import inspect
import json
import os
from pathlib import Path
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,digest in json.loads((HERE/'manifest.json').read_text()).items():assert sha(HERE/n)==digest,n
variant=Path(os.environ['DFX_VARIANT_DIR']);manifest=Path(os.environ['DFX_EXPECTED_VARIANT_MANIFEST'])
assert sha(manifest)==os.environ['DFX_EXPECTED_VARIANT_MANIFEST_SHA']
records=json.loads(manifest.read_text());records=records.get('files',records)
for n,digest in records.items():assert sha(variant/n)==digest,n
for n in ('torch','torch_npu','pypto','simpler','vllm_ascend'):
 m=importlib.import_module(n);print('MODULE',n,getattr(m,'__version__',None),m.__file__,flush=True)
 if n=='pypto':assert Path(m.__file__).resolve().is_relative_to(Path(os.environ['LOW_ACCEPTANCE_RUNTIME_PACKAGE']).resolve()/'pypto')
 if n=='simpler':assert Path(m.__file__).resolve().is_relative_to(Path(os.environ.get('DFX_EXPECTED_SIMPLER_ROOT','/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/python/simpler')).resolve())
 if n=='vllm_ascend':assert Path(m.__file__).resolve().is_relative_to(Path(os.environ['SOURCE_ROOT']).resolve())
for n in ('PTOAS_ROOT','ASCEND_HOME_PATH','ATB_HOME_PATH','CCACHE_DIR'):
 assert os.environ.get(n),n
 print('ENV',n,os.environ[n],flush=True)
assert os.environ['HCCL_DETERMINISTIC']=='true'
from pypto.runtime.kernel.context import get_process_kernel_state
from pypto.runtime.kernel.callable import KernelRegistration
state=get_process_kernel_state();assert hasattr(state,'_condition') and hasattr(state,'_registrations')
assert 'artifact' in KernelRegistration.__dataclass_fields__
module=importlib.import_module(os.environ.get('DFX_ROOT_MODULE','candidate_csa'))
root=getattr(module,os.environ.get('DFX_ROOT_SYMBOL','decode_csa_tp1_layer_test'))
assert len(root.param_names)==62
root_file=Path(module.__file__).resolve();assert root_file.is_relative_to(variant.resolve())
root_key=root_file.relative_to(variant.resolve()).as_posix();assert root_key in records and sha(root_file)==records[root_key]
print('ROOT',module.__file__,sha(root_file),flush=True)
print('PREFLIGHT_PASS_NO_DEVICE_WORK',flush=True)
