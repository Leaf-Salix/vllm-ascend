# V6 B40：完整 CSA 三窗 DFX

本助手固定最终四项 V6 的同一 source snapshot，不修改源码，不创建新的数学 root。只准备/无设备预检；设备采集由主线程另交单卡任务。

```bash
bash "$EXP/dfx-formal-v6-b40/run-pinned-v6.sh" final-b40-v6
```

每任务 max-time780，wrapper 内部750秒。真实 L4 权重、固定合成 hidden、history8191、B40/T240/S6；先 Native/PTO FULL graph 对拍八个输出/cache边界，以及 B 输入、ABA、poison、guard。TND 发现首差立刻停止。通过后仅采 candidate 三次 raw graph replay，level4，dep-gen=false；不统计正式延迟，不把 DFX span 当无插桩性能。

源 snapshot manifest：`6d9656de4580ba5f768881c417f3093a7744808ac6518c594e9db881971e7ab2`；root62；数学 manifest `a10789d99c63a65eb181ae054d2312cd70771cde0944db65fc95c11c4aafcb02`。固定身份由 `pin-v6.sh`、`PINNED_V6.json` 记录。

## 实际映射门禁

采集时 `capture_artifact.py` 从实际 live Worker 的注册记录取得 artifact，保存实际 config/orchestration 和 SHA。`inventory_mapping.py` 只生成实际源码清单，不声称已完成 token 映射。

采集后必须核对本次 artifact；V6 参考生成物 SHA 仅用于对照，不能替代实际 artifact。按本次 B40/短 history 分支和循环推导 ring token、func_id、grid 和执行数量；不可复用旧 V4 token-map。完整覆盖后再用 `analyze_dfx.py` 验证三窗全部实际 token/core/count。任一未映射或次数不符就停止发布模块名结论。

输出：`results/final-b40-v6/data/current-artifact` 与三窗 DFX 原始记录。正式延迟由独立 `threeway-formal-v6` 无 DFX runner 给出。
