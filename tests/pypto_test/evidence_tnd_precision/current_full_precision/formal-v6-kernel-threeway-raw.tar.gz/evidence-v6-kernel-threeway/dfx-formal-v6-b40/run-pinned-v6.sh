#!/usr/bin/env bash
set -euo pipefail
here=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "$here/pin-v6.sh"
timeout --signal=TERM --kill-after=15s 750s bash "$here/run-dfx.sh" "$@"
