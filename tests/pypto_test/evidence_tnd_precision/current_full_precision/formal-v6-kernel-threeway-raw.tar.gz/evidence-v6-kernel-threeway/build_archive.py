"""白名单文本证据归档：不接受 tensor、模型、二进制或旧 V4 archive。"""
from pathlib import Path
import hashlib,json,shutil,tarfile,gzip,io
P=Path(__file__).resolve().parent;R=P.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
allowed={'.json','.py','.md','.txt','.log','.sh','.cpp','.h','.hpp','.patch'}
selections=['formal-v6-package','formal-v6-bindings','formal-v6-repo-apply','formal-v6-generated-review/full','review-formal-v6','review-formal-v6-independent','review-hclinear-m64-v3','review-hybrid192-v3','formal-hc64-bundle','threeway-formal-v6','threeway-v6-b40-result.json','csa-checked48','csa-kv-reuse2-v2','math/oproj-woa-hybrid192-v3','math/oproj-woa-hybrid192-probe','math/hc-linear-m64-probe-v3','dfx-formal-v6-b40','dfx-formal-v6-map','review-dfx-formal-v6-map','review-v6-code-and-report/threeway-wrapper-review.json']
# Copy only explicitly selected evidence paths, then enforce UTF-8 text and no
# links. Do not recursively select whole reports/workspace or any model root.
payload=P/'payload';assert not payload.exists(),'frozen package: use a new version/directory'
payload.mkdir();records={};excluded=[]
for rel in selections:
 root=R/rel;assert root.exists(),rel
 for src in ([root] if root.is_file() else sorted(root.rglob('*'))):
  if not src.is_file():continue
  name=src.relative_to(R)
  if src.is_symlink():raise AssertionError(('symlink not allowed',src))
  if '__pycache__' in src.parts or src.suffix.lower() not in allowed or src.name.startswith('._') or src.name=='.DS_Store':excluded.append(str(name));continue
  assert not any(x.endswith(('.tar','.gz','.zip','.safetensors','.pt','.npy','.elf','.so','.bin')) for x in src.parts),name
  data=src.read_bytes();data.decode('utf-8');assert b'\x00' not in data,('binary masquerading as text',name)
  target=payload/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);records[str(name)]={'sha256':sha(target),'bytes':len(data)}
# Actual final runtime 43-source copies are explicit .py-only inputs.
binding=json.loads((R/'formal-v6-bindings/binding.json').read_text());assert len(binding['tested_sources'])==43
for rel,digest in binding['tested_sources'].items():
 src=P/'runtime-source43'/rel;assert src.suffix=='.py' and sha(src)==digest;data=src.read_bytes();data.decode('utf-8');target=payload/'runtime-source43'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);records[str(target.relative_to(payload))]={'sha256':digest,'bytes':len(data)}
# Bind all twelve qualified single-factor raw results to the frozen selection.
selection=json.loads((R/'formal-v6-package/selection.json').read_text());cases=[]
for option,items in selection['accepted_evidence'].items():
 assert selection['options'][option]
 for item in items:
  src=R/item['report_relative_path'];raw=json.loads(src.read_text());assert sha(src)==item['sha256'] and raw['complete'] is True and raw['pass'] is True
  assert item['report_relative_path'] in records
  cases.append({'option':option,'tokens':item['tokens'],'path':item['report_relative_path'],'sha256':item['sha256'],'complete':True,'pass':True})
assert len(cases)==12
(P/'SINGLE_FACTOR_REVIEW.json').write_text(json.dumps({'pass':True,'scope':'12 actual completed per-factor raw results matched frozen accepted selection; source/helper math and Native gates are in each harness/raw evidence','cases':cases},indent=2)+'\n')
for name in ('README.md','review_threeway.py','THREEWAY_INDEPENDENT_REVIEW.json','SINGLE_FACTOR_REVIEW.json','build_archive.py','runtime43-files.txt'):
 src=P/name;data=src.read_bytes();data.decode('utf-8');target=payload/name;target.write_bytes(data);records[name]={'sha256':sha(target),'bytes':len(data)}
manifest={'scope':'V6 four-factor kernel and controlled threeway evidence, plus DFX preparation only; whole-model results are separate','no_models_tensors_binaries':True,'old_V4_archive_repacked':False,'whitelist_extensions':sorted(allowed),'files':records,'file_count':len(records),'total_uncompressed_bytes':sum(x['bytes'] for x in records.values()),'excluded_non_whitelist_count':len(excluded),'source_manifest_sha256':binding['source_manifest_sha256']}
(payload/'ARCHIVE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=R/'evidence-v6-kernel-threeway-pre-dfx-20261019.tar.gz';assert not archive.exists()
with archive.open('wb') as stream:
 with gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as compressed:
  with tarfile.open(mode='w',fileobj=compressed,format=tarfile.PAX_FORMAT) as tar:
   for src in sorted(payload.rglob('*')):
    if not src.is_file():continue
    data=src.read_bytes();info=tarfile.TarInfo('evidence-v6-kernel-threeway/'+src.relative_to(payload).as_posix());info.size=len(data);info.mode=0o644;info.uid=info.gid=0;info.mtime=0;tar.addfile(info,io.BytesIO(data))
# Read back every member; no reliance on filename whitelist alone.
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert all(m.isfile() and not m.issym() and '..' not in Path(m.name).parts and Path(m.name).suffix.lower() in allowed for m in members)
 for member in members:
  rel=Path(member.name).relative_to('evidence-v6-kernel-threeway').as_posix();data=tar.extractfile(member).read();data.decode('utf-8')
  if rel!='ARCHIVE_MANIFEST.json':assert hashlib.sha256(data).hexdigest()==records[rel]['sha256']
summary={'archive':str(archive),'sha256':sha(archive),'archive_bytes':archive.stat().st_size,'payload_files':len(records),'payload_bytes':manifest['total_uncompressed_bytes'],'whitelist_readback_pass':True,'NPU_executed_by_packager':False,'DFX_results_included':False};(P/'ARCHIVE_READY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
