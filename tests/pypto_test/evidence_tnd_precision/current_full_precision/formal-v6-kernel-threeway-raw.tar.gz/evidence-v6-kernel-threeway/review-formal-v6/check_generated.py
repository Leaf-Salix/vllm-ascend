"""Final four-option actual generated integration proof; no compile or device."""
from pathlib import Path
import re,json,hashlib
R=Path(__file__).resolve().parent.parent
A=R/'formal-v5-generated-review/full/kernels'
B=R/'formal-v6-generated-review/full/kernels'
def core(p):
 s=p.read_text();a=s.index('static __aicore__ void ');z=s.index('\nextern "C"',a)
 return re.sub(r'\s+','',re.sub(r'//[^\n]*','',s[a:z]))
unchanged=[];changed=[];removed=[]
for p in A.rglob('*.cpp'):
 q=B/p.relative_to(A)
 if not q.exists():removed.append(str(p.relative_to(A)))
 elif core(p)==core(q):unchanged.append(str(p.relative_to(A)))
 else:changed.append(str(p.relative_to(A)))
assert len(unchanged)==74
assert all(n in unchanged for n in ('aic/qk_pv_aic.cpp','aiv/qk_pv_aiv.cpp','aiv/csa_checked_indices.cpp'))
accepted=R/'math/hc-linear-m64-probe-v3/generated-review/candidate_full/kernels'
hc=['aic/hcpre_bf16_half_exact8_m64.cpp','aic/hcpre_bf16_half_exact8.cpp','aiv/hcpre_input_panel.cpp','aiv/hcpre_hf32_weight.cpp']
assert all(core(accepted/n)==core(B/n) for n in hc)
s=(R/'formal-v6-generated-review/full/orchestration/_full_csa_tnd.cpp').read_text()
assert '.expected_arg_count = 62' in s
assert s.index('const Tensor& mixes_partials_inline8250 = alloc_7.get_ref(0);')<s.index('if ((64 <= t_dim_inline8221))')
assert s.count('add_output(mixes_partials_inline8250);')==2
assert s.count('mixes_partials_inline8250__phi_v3 = mixes_partials_inline8250;')==2
assert s.index('params_t7.add_input(mixes_partials_inline8250__phi_v3);')>s.index('mixes_partials_inline8250__phi_v3 = mixes_partials_inline8250;',s.index('} else {',s.index('// Spmd hcpre_bf16_half_exact8_m64')))
q=(B/'aic/hcpre_bf16_half_exact8_m64.cpp').read_text();assert 'v82.SetValidShape(v52, v12);' in q and 'TSTORE(v122, v82);' in q
assert 'int64_t v52 = v51 < v14 ? v51 : v14;' in q
# Other 74 core bodies are byte-equivalent after comment/whitespace removal,
# including all O-proj routing cores, fused Norm, both Sparse cores and checked48.
# Full root descriptor scopes and dynamic dimensions require separate reviewer check.
out={'pass':True,'NPU_executed':False,'root_ABI':62,'unchanged_actual_kernel_bodies_from_V5':unchanged,'changed':changed,'removed':removed,'HC_four_actual_kernels_exact_accepted_v3':hc,'HC_parent_partials_descriptor_same_for_both_branches':True,'HC_reduce_consumes_same_descriptor_after_branch_scope':True,'HC_M64_partial_valid_tail_preserved':True,'source_sha256':hashlib.sha256((R/'formal-v6-package/candidate-math.json').read_bytes()).hexdigest(),'scope':'actual generated integration static proof, not new hardware acceptance'}
(Path(__file__).parent/'results.json').write_text(json.dumps(out,indent=2)+'\n')
print('FORMAL_V6_ACTUAL_GENERATED_PASS',len(unchanged),'unchanged; accepted HC four cores exact')
