"""从V6实际源码独立重建scope计数与B40执行路径，不导入作者map生成器。"""
import ast
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
H = Path(__file__).resolve().parent
R = H.parent
G = R / 'formal-v6-generated-review/full'
source = (G / 'orchestration/_full_csa_tnd.cpp').read_text()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
reference = R / 'dfx-formal-v6-map/reference-token-map.json'
m = json.loads(reference.read_text())
assert m['complete'] is False
# T240 selects HC64, WKV64N32, short-request score, single-leaf, seed256, WO-B64.
# Exclusions are from the actual branch conditions, not the reference trace.
exclude_tasks = {6,12,46,47,48,49,52,53,54,56,65,68}
exclude_allocs = {21,22,24,25}
expected_grids = {
0:240,1:90,2:30,3:64,4:240,5:88,7:15,8:16,9:30,10:30,11:240,
13:64,14:15,15:60,16:15,17:1,18:16,19:30,20:1,21:32,22:16,23:24,24:48,
25:15,26:8,27:8,28:24,29:40,30:40,31:15,32:24,33:40,34:40,35:40,
36:2,37:1,38:5,39:1,40:24,41:48,42:24,43:48,44:15,45:1,50:40,51:24,
55:48,57:1,58:48,59:32,60:24,61:16,62:48,63:48,64:8,66:120,67:30,
69:128,70:120,71:60}
# The source distinguishes params_t task indices from actual func_id values.
tree = ast.parse((G / 'kernel_config.py').read_text())
kernels = next(ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id=='KERNELS' for t in n.targets))
byid = {k['func_id']:k for k in kernels}
# Scan lexical braces; only SIMPLER_SCOPE opens a ring. If/for/array braces do not.
# Sequential sibling scopes reuse their depth's counter.
stack, counters, trace, entries = [], Counter(), [], {}
for line_number, raw in enumerate(source.splitlines(), 1):
    line = re.sub(r'//.*', '', raw)
    ring = sum(stack)
    kind, index = None, None
    alloc = re.search(r'TaskOutputTensors alloc_(\d+) = alloc_tensors\(', line)
    dummy = re.search(r'TaskOutputTensors phase_fence_barrier_(\d+)_outs = rt_submit_dummy_task\(', line)
    task = re.search(r'rt_submit_(aic_task|aiv_task|task)\((\w+), params_t(\d+)\);', line)
    if alloc and int(alloc[1]) not in exclude_allocs: kind,index='a',int(alloc[1])
    elif dummy: kind,index='d',int(dummy[1])
    elif task and int(task[3]) not in exclude_tasks: kind,index='task',int(task[3])
    if kind:
        for _ in range(8 if (kind,index)==('task',64) else 1):
            token=f'{ring}:{counters[ring]}'
            counters[ring]+=1
            event={'token':token,'event':kind+str(index),'source_line':line_number}
            if kind=='task':
                arg=task[2]
                if arg.startswith('mixed_'):
                    mixed=re.search(r'MixedKernels '+arg+r' = \{(\d+), (\d+), (\d+)\};',source)
                    ids=list(map(int,mixed.groups()))
                else: ids=[int(arg)]
                counts=Counter()
                for f in ids: counts[byid[f]['core_type']]+=expected_grids[index]
                event.update(func_ids=list(dict.fromkeys(ids)),grid=expected_grids[index])
                entries[token]={'func_ids':event['func_ids'],'expected_executions':dict(counts),'source_lines':[line_number]}
            trace.append(event)
    for char_index,char in enumerate(line):
        if char=='{':stack.append(bool(re.search(r'SIMPLER_SCOPE\(\)\s*$',line[:char_index])))
        elif char=='}':
            assert stack,(line_number,line)
            stack.pop()
assert not stack
assert len(entries)==67 and len(trace)==102
assert entries==m['entries'],'reference kernel/count/ring mismatch'
sortkey=lambda item:tuple(map(int,item['token'].split(':')))
assert sorted(trace,key=sortkey)==sorted(m['trace'],key=sortkey),'reference per-ring alloc/dummy/submit ordering mismatch'
assert m['config_sha256']==sha(G/'kernel_config.py') and m['orchestration_sha256']==sha(G/'orchestration/_full_csa_tnd.cpp')
# Independently check case routing and launch facts which caused prior map mistakes.
assert (40*((6+1)//2),40*((6+5)//6))==(120,40)
assert (40+23)//24*24 <= (120+23)//24*10
assert (8191+6)//4==2049 and 2049<=8192
assert 'int64_t token_tiles_inline1545 = ((t_dim_inline1550 + 3) / 4);' in source
assert (240+3)//4==expected_grids[71]==60
assert entries['1:12']['func_ids']==[5]
assert entries['1:56']['func_ids']==[65,66]
assert all(entries[f'1:{i}']['func_ids']==[70] for i in range(60,68))
result={'pass':True,'reference_map_sha256':sha(reference),'reference_only':True,'actual_capture_bound':False,'NPU_submitted':False,'reference_kernel_entries':67,'reference_alloc_dummy_submit_events':102,'lexical_scope_and_counter_trace_independently_rebuilt':True,'B40_actual_branch_review':True,'grid71_HCpost_corrected_30_to60':True,'config_sha256':sha(G/'kernel_config.py'),'orchestration_sha256':sha(G/'orchestration/_full_csa_tnd.cpp'),'selected_source_grid_table':expected_grids,'limits':'Reference review only; complete must stay false until live current-artifact has exact config/orch SHA and successful actual Native/TND gates, then strict analyzer checks all three windows/core counts. No DFX timing is treated as production replay latency.'}
(H/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='selected_source_grid_table'},indent=2))
