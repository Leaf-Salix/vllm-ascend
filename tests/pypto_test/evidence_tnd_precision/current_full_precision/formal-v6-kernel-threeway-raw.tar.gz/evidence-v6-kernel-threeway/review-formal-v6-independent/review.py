"""独立核对最终V6源和实际生成核心；不编译、不执行NPU。"""
import ast
import hashlib
import json
import re
from pathlib import Path
H = Path(__file__).resolve().parent
R = H.parent
G5 = R / 'formal-v5-generated-review/full'
G6 = R / 'formal-v6-generated-review/full'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def literal(p, name):
    for n in ast.parse(p.read_text()).body:
        if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in n.targets):
            return ast.literal_eval(n.value)
    raise AssertionError(name)

def functions(p):
    s = p.read_text()
    out = {}
    for m in re.finditer(r'static __aicore__ (?:inline )?void\s+(\w+)\([^\n]*\)\s*\{', s):
        i, depth = m.end(), 1
        while depth:
            depth += (s[i] == '{') - (s[i] == '}')
            i += 1
        body = re.sub(r'/\*.*?\*/|//[^\n]*', '', s[m.start():i], flags=re.S)
        out[m.group(1)] = re.sub(r'\s+', '', body)
    assert out, p
    return out

k5 = {n['name']: n for n in literal(G5 / 'kernel_config.py', 'KERNELS')}
k6 = literal(G6 / 'kernel_config.py', 'KERNELS')
assert len(k6) == 78
same, changed = [], []
for n in k6:
    if n['name'] in k5:
        (same if functions(G5 / k5[n['name']]['source']) == functions(G6 / n['source']) else changed).append(n['name'])
assert len(same) == 74
assert set(changed) == {'hcpre_hf32_weight', 'hcpre_input_panel', 'hcpre_bf16_half_exact8'}
private = R / 'math/hc-linear-m64-probe-v3/generated-review/candidate_full'
for name in ['hcpre_hf32_weight', 'hcpre_input_panel', 'hcpre_bf16_half_exact8', 'hcpre_bf16_half_exact8_m64']:
    n = next(x for x in k6 if x['name'] == name)
    assert functions(G6 / n['source']) == functions(private / n['source']), name
assert len(literal(G6 / 'kernel_config.py', 'ORCHESTRATION')['signature']) == 62
m5 = json.loads((R / 'formal-v5-package/candidate-math.json').read_text())
m6 = json.loads((R / 'formal-v6-package/candidate-math.json').read_text())
assert m5.keys() == m6.keys()
changed_src = [p for p in m6 if m5[p] != m6[p]]
assert set(changed_src) == {'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision/' + p for p in ['hc_pre.py', 'hc_pre_panel.py']}
for p in m6:
    actual = R / 'formal-v6-package/patch' / p
    assert sha(actual) == m6[p]
    if p in changed_src:
        assert actual.read_bytes() == (R / 'formal-hc64-bundle/patch' / p).read_bytes()
    else:
        assert actual.read_bytes() == (R / 'formal-v5-package/patch' / p).read_bytes()
orch = (G6 / 'orchestration/_full_csa_tnd.cpp').read_text()
for s in ['alloc_7 = alloc_tensors(mixes_partials_inline8250_ci)',
          'params_t5.add_output(mixes_partials_inline8250)',
          'params_t6.add_output(mixes_partials_inline8250)',
          'params_t7.add_input(mixes_partials_inline8250__phi_v3)',
          'params_t58.launch_spec.set_block_num(48)',
          'params_t59.launch_spec.set_block_num(32)',
          'params_t59_deps[params_t59_deps_count++] = checked_tid_inline5810',
          'params_t60_deps[params_t60_deps_count++] = qk_plan_tid_inline5839',
          'if ((192 <= rows_inline1467))',
          'params_t64.add_output(accum_inline1531)',
          'params_t65.add_output(accum_inline1531)',
          'params_t66.add_input(accum_inline1531__phi_v21)']:
    assert s in orch, s
hc = (G6 / 'kernels/aic/hcpre_bf16_half_exact8_m64.cpp').read_text()
assert 'v82.SetValidShape(v52, v12)' in hc
assert '(v115, v116, v117, v52, v12)' in hc
assert 'TSTORE(v122, v82)' in hc
qk = (G6 / 'kernels/aic/qk_pv_aic.cpp').read_text()
for s in ['const int64_t v37 = 393216', 'const int64_t v40 = 458752',
          'v150 = static_cast<uint16_t>(v127)', 'v159 = static_cast<uint16_t>(v127)']:
    assert s in qk
checked = (G6 / 'kernels/aiv/csa_checked_indices.cpp').read_text()
assert 'v26 += v18' in checked and 'const int64_t v18 = 48' in checked
assert 'dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE)' in checked
result = {
    'review_pass': True, 'blocking_findings': [], 'NPU_executed_by_reviewer': False,
    'compile_executed_by_reviewer': False, 'root_ABI': 62,
    'math_manifest_sha256': sha(R / 'formal-v6-package/candidate-math.json'),
    'actual_orchestration_sha256': sha(G6 / 'orchestration/_full_csa_tnd.cpp'),
    'actual_kernel_config_sha256': sha(G6 / 'kernel_config.py'),
    'actual_kernel_count': 78,
    '74_nonHC_core_function_bodies_exact_V5': same,
    'four_HC_core_function_bodies_exact_private_HC_v3': True,
    'only_two_HC_sources_changed_vs_V5_and_exact_surgical_bundle': changed_src,
    'HC_scope': 'Common parent alloc_7 precedes M64/M16 branch; both branches pass the same GM descriptor to Out and phi; reduce takes that phi before scope exit. Packed inputs/weights are true IN dependencies. No L0C value crosses branches.',
    'HC_tail': 'v52=min(64,padded_tokens-row) is used for L0A valid rows, L0C valid rows, SetValidShape and GM store shape. T240 final panel stores 48 valid rows; split row stride remains t_linear*32.',
    'Sparse': 'Checked48 flushes complete data cache before return; planner32 explicitly waits checked TaskId, mixed QK/PV waits planner. Both accepted source blocks are preserved unchanged from V5. QK dynamic slot offsets survive into both TEXTRACT right-column operands.',
    'L1_intervals_bytes': {'KV': [0,393216], 'Q': [393216,458752], 'probability': [458752,475136]},
    'L1_total_KiB': 464,
    'Sparse_fences': 'Current direct core bodies are exact V5 and accepted KV-reuse private core: event2 prevents QK load overwriting active extract; event4 protects PV scratch, event1 protects next QK overwrite. Retained slots1/2 survive through PVparts2/3.',
    'Oproj_scope': 'rows>=192 high seed path and lower-T V4 path share parent accum [rows+127,8192]; each branch local L0C stores directly GM. BF16 round follows common phi, then unchanged quant; WO-B parent [rows+63,4096] and dequant preserved. Both direct cores and all downstream cores exact V5.',
    'limits': 'This is independent source/physical review, not final V6 hardware qualification or whole-model precision/performance evidence. Existing private hardware receipts do not substitute final source-identity-bound runs.'
}
(H / 'results.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({k:v for k,v in result.items() if k!='74_nonHC_core_function_bodies_exact_V5'}, indent=2, ensure_ascii=False))
