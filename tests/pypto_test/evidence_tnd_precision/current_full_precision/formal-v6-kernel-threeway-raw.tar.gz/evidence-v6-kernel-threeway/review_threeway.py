"""Independent evidence audit; no device, no model/tensor loading."""
from pathlib import Path
import hashlib,json,statistics,math
P=Path(__file__).resolve().parent;R=P.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=R/'threeway-v6-b40-result.json';d=json.loads(p.read_text());b=json.loads((R/'formal-v6-bindings/binding.json').read_text());v=d['variant_identity'];expected='6d9656de4580ba5f768881c417f3093a7744808ac6518c594e9db881971e7ab2'
assert d['complete'] is True and d['pass'] is True and d['DFX'] is False and d['depgen'] is False
assert d['true_tokens']==d['physical_graph_tokens']==240 and d['lengths']==[6]*40 and d['per_request_padding']==0
assert v['expected_manifest_sha256']==b['source_manifest_sha256']==expected
assert v['variant_dir']==v['runtime_source_root']==b['source_root']
assert v['root_abi_count']==d['root_abi']['tnd']['count']==62 and len(v['root_param_names'])==62
assert v['root_file']==v['variant_dir']+'/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision/decode_csa.py'
assert v['root_sha256']==b['tested_sources']['vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision/decode_csa.py']
assert len(b['tested_sources'])==43
for rel,h in b['tested_sources'].items():assert sha(P/'runtime-source43'/rel)==h
assert v['helper_manifest_sha256']==sha(R/'threeway-formal-v6/manifest.json')=='b4227c86eb4135a4a76e9e2ec44a1047d308b793847a679c95afa6340834c5f0'
assert v['variant_env_sha256']==json.loads((R/'formal-v6-bindings/manifest.json').read_text())['env.sh']
assert v['nal_commit']==d['bsh_commit']=='a919f11942d93627441c8fa694e310dcbd1c671b' and v['nal_files']==38 and d['root_abi']['bsh']['count']==57
assert d['SK']==0 and d['NZ']==2 and d['determinism']=={'torch_algorithms':True,'npu_requested_level':1,'HCCL_DETERMINISTIC':True,'atomic':0}
assert d['static']['actual_reselect_count']==1 and d['static']['metadata_sha256']=='863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
assert len(d['comparisons']['tnd'])==8 and all(x['bit_equal'] and x['different_elements']==0 and x['max_abs']==0 for x in d['comparisons']['tnd'].values())
assert all(x==0 for x in d['fallback_calls'].values())
for arm in ('native','tnd','bsh'):
 g=d['graphs'][arm];assert all(g[x] is True for x in ('actual_acl_graph','fullgraph','compiled_raw_equal','topk_poison_replay_restored','live_input_ABA'))
 assert g['options']['super_kernel_optimize'] is False and g['options']['force_eager'] is False
 assert g['true_tokens']==g['graph_tokens']==240
 assert all(x['status']=='PASS' for x in g['guards'].values())
 if arm!='native':assert d['entry'][arm]['eligible'] and d['routes'][arm]['eager_PTO_calls']>0 and d['routes'][arm]['capture_PTO_calls']>0 and d['routes'][arm]['Native_fallback_calls']==0 and d['routes'][arm]['is_hbg'] is False
 x=d['timing_us'][arm];assert len(x['samples'])==d['timing_rounds']==8 and d['timing_iters']==20
 assert all(math.isfinite(t) and t>0 for t in x['samples'])
 assert x['min']==min(x['samples']) and x['max']==max(x['samples']) and abs(x['mean']-statistics.mean(x['samples']))<1e-10
prior=R/'evidence-v4-tuning/raw-results/threeway-parameterized/csa-results/formal-v4-b40/data/result.json';old=json.loads(prior.read_text());now=d['timing_us'];past=old['timing_us']
result={'pass':True,'NPU_executed_by_this_audit':False,'raw_result_sha256':sha(p),'source_manifest_sha256':expected,'runtime43_each_sha_match_binding':True,'raw_result_43_provenance':'result pins and validates full3365 manifest; independent43 binding/source copies checked transitively, not a claim that result redundantly enumerates all43','helper_manifest_sha256':v['helper_manifest_sha256'],'root_ABI':62,'Nal_ABI':57,'TND_vs_Native_all_eight_boundaries_bit_equal':True,'Nal_precision_only_recorded':d['comparisons']['bsh']['x_out'],'all_graph_route_and_timing_gates_pass':True,'timing':now,'TND_over_Nal':now['tnd']['mean']/now['bsh']['mean'],'TND_over_Native':now['tnd']['mean']/now['native']['mean'],'prior_V4_reference_not_repackaged':{'report_path':str(prior.relative_to(R)),'sha256':sha(prior),'means_us':{a:x['mean'] for a,x in past.items()}},'V4_to_V6':{'TND_latency_drop_percent':100*(1-now['tnd']['mean']/past['tnd']['mean']),'V6_max_below_V4_min':now['tnd']['max']<past['tnd']['min'],'Native_drift_percent':100*(now['native']['mean']/past['native']['mean']-1),'Nal_drift_percent':100*(now['bsh']['mean']/past['bsh']['mean']-1),'qualification':'separate tasks each8 rounds, not a strictly paired same-task A/B'}}
(P/'THREEWAY_INDEPENDENT_REVIEW.json').write_text(json.dumps(result,indent=2)+'\n');print('V6_THREEWAY_INDEPENDENT_PASS 43-source/ABI62/8bitboundaries/FULL/route/8x20')
