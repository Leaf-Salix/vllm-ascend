# V6：四项单因素、三方性能与实际生成物证据

本包冻结最终四项组合的内核证据，不包含整模型结果；整模型 8K/128K 三轮 192-token 的验收由独立主报告给出。

- V6 使用同一私有 source snapshot，完整 manifest 为 `6d9656de4580ba5f768881c417f3093a7744808ac6518c594e9db881971e7ab2`；43 个 runtime 源文件及各 SHA 独立保存。
- 四项是 checked48、O-proj hybrid192、KV reuse2-v2、HC M64。共 12 个已完成单因素 raw result 由 selection 精确绑定。
- 最终完整 root 62 参数，实际 GCC 与 78 核 CCEC 通过，74 个核体与 V5 不变，HC 四个核体与已硬件验收的 v3 相同。独立实际代码审查报告均保留。
- 三方 B40/T240、history8191、L4 真实权重、固定合成 hidden，FULL graph / SK0 / NZ2 / 确定性，同卡 8×20 次交错测量，无 DFX。
- Native 为 1393.111 µs；TND 为 2391.330 µs；Nal 性能版 a919f119 为 1272.611 µs。TND 八个外部边界逐 bit 一致；Nal 精度误差仅记录。
- TND 仍为 Nal 的约 1.879 倍、Native 的约 1.716 倍，不能称已追平。
- 相比前一轮正式 V4 的 2669.736 µs，TND 下降约 10.43%；两轮各八组且区间不重叠。它们来自不同任务，不能称严格同任务 paired A/B。旧 V4 完整 archive 没有重复打包，旧 raw 的路径和 SHA 只作为外部引用。
- DFX 仅包含已预检 wrapper 与参考映射/独立审查，还没有真实三窗采集结果。参考 map 保持 complete=false；采集后必须匹配 live artifact 双 SHA、通过 Native/TND 门禁和全部 token/core/grid 计数，才能用于模块热点结论。

## 复现入口

在已分配的 NPU 小任务中：

```bash
bash "$EXP/threeway-formal-v6/run-pinned-v6.sh" final-b40-v6 40 --timing-iters 20
bash "$EXP/dfx-formal-v6-b40/run-pinned-v6.sh" final-b40-v6
```

每个任务 max-time780，内部750秒。使用新的 label，避免覆盖已有结果。正式无插桩延迟与 DFX 必须分开。

`build_archive.py` 只选择明确目录，允许 JSON/Python/Markdown/文本日志/脚本/实际生成 C++ 源码；逐文件 UTF-8 解码并检查 NUL。拒绝符号链接、tensor、模型、ELF/SO 等二进制，tar 回读再次校验每个文件的 SHA。整个源码树、SDK、旧 V4 archive 和模型目录均不在选择范围。
