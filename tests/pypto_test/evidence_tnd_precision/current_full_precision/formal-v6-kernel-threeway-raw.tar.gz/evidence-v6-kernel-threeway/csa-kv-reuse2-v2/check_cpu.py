"""Only KV L1 residency changes; exact original numerical AST after normalization."""
import ast,copy,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent;V=P.parent/'csa-combo-v4';dump=lambda n:ast.dump(n,include_attributes=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=ast.parse((P/'baseline_sparse.py').read_text());c=ast.parse((P/'candidate_sparse.py').read_text())
def target_name(n):
 return n.targets[0].id if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) else None
class Restore(ast.NodeTransformer):
 def visit_Assign(self,n):
  name=target_name(n)
  if name in ('qk_slot_row','pv_slot_row','qk_l1_t','qk_kv_t'):return None
  if name=='qk_l1':return None
  if name=='qk_scores':
   return ast.parse('qk_kv=pl.load(kv_transfer,[qk_kv_base+qk_col,0],[ATTN_CUBE_KV_TILE,HEAD_DIM],target_memory=pl.MemorySpace.Mat)\nqk_scores=pl.matmul(qk_q,pl.tile.transpose_view(qk_kv),out_dtype=pl.FP32)').body
  if name in ('qk_kv','pv_kv'):
   col='qk_col' if name=='qk_kv' else 'pv_col'
   return ast.parse(f'{name}=pl.load(kv_transfer,[qk_kv_base+{col},0],[ATTN_CUBE_KV_TILE,HEAD_DIM],target_memory=pl.MemorySpace.Mat)').body[0]
  return self.generic_visit(n)
 def visit_If(self,n):
  if dump(n.test)==dump(ast.parse('pv_part<2',mode='eval').body):
   assert len(n.body)==1 and target_name(n.body[0])=='qk_l1' and not n.orelse
   return None
  return self.generic_visit(n)
r=Restore().visit(copy.deepcopy(c));assert dump(r)==dump(b),'arithmetic/reduction/round/event or any other statements changed'
assert sha(P/'baseline_sparse.py')==sha(V/'candidate_sparse.py')
for n in ('candidate_hc.py','optimized_hc.py','candidate_panel.py','candidate_norm.py','candidate_wkv.py','candidate_o_proj.py','wide_heads.py','ragged_fixture.py'):
 assert sha(P/n)==sha(V/n),n
root=ast.parse((P/'candidate_csa.py').read_text());baseline=ast.parse((P/'baseline_csa.py').read_text())
for n in ast.walk(baseline):
 if isinstance(n,ast.ImportFrom) and n.module=='baseline_sparse':n.module='candidate_sparse'
assert dump(root)==dump(baseline) and len(next(n for n in root.body if isinstance(n,ast.FunctionDef) and n.name=='_full_csa_tnd').args.args)==62
# Token/core/valid-block-independent proof: sequential QK and PV see identical KV parts.
for t in range(1,257):
 for core in range(24):
  for token in range(core,t,24):
   for valid in (False,True):
    slots=[None]*3
    if valid:
     for part in range(4):
      slot=max(part-1,0);slots[slot]=(token,part)
      assert slots[slot]==(token,part)
     assert slots[1:]==[(token,2),(token,3)]
     for part in range(4):
      slot=max(part-1,0)
      if part<2:slots[slot]=(token,part)
      assert slots[slot]==(token,part)
result={'pass':True,'NPU_executed':False,'all_T1to256_cache_sequence_valid':True,'arithmetic_and_all_event_AST_unchanged':True,'root_ABI':62,'L1_logical_bytes':{'Q':65536,'KV_three128_panels':393216,'probability128':16384,'sum':475136,'capacity':524288},'saved_KV_GM_to_L1_bytes_per_token_per_valid512_block':262144,'limitation':'actual CCEC resource allocation and overwrite barriers still require inspection'}
(P/'cpu-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
