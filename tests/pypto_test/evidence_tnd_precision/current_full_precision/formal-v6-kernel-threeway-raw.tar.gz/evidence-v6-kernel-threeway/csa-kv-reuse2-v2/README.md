# 末两个K128 KV L1复用单因素

baseline为当前V4完整精度组合。candidate只改变sparse QK/PV内部KV的L1驻留；K512 max/exp/实际K归约树、CAST_ROUND、四段K128 FP32 PV累加、online更新及全部跨核event保持原样。对外仍62tensor，真实TND不变。

## 容量与依赖证明

一个384×512 BF16 L1 tile分三个128行槽：QK part0/1都用slot0，part2/3分别slot1/2；PV part0/1重新载入slot0，part2/3直接消费保留slot1/2。同一有效K512块内，所有QK在所有PV之前，故后两槽已写且不会被scratch覆写。无效块两侧都跳过；下一块/下一token从QK重新写入，旧值不参与。

Q64KiB+KV三槽384KiB+概率16KiB=464KiB，小于512KiB L1。L0A/B/C形状、K顺序和原数学不变，AIV UB不变。每token每有效K512块省256KiB GM→L1，KV总搬运由1024KiB降为768KiB。不能从搬运量推定延迟收益。

`check_cpu.py`将KV驻留调度还原后，完整sparse AST与V4一致；CPU逐T1..256验证24核各token的槽写读时序。实际CCEC还必须确认L1真实峰值、不产生额外副本、MTE1消费后MTE2才覆写slot0，以及双核event归属不变。编译失败时先修现有DSL，不改SDK。

## 测试顺序

先做无设备GCC/CCEC与生成代码审查。主线程再依次单卡B4/S6、混合1..6(T21)、T240、T144。Native/基准/候选逐bit、ABA/poison和cache guards沿用原harness；首差即停。每项外部max780秒、内部750秒。没有NPU结果前不作数值/收益声明。

## v2现有DSL修正

v1虽然CCEC通过，实际QK generated中slice后transpose丢了动态row offset，未提交NPU。v2先transpose完整L1 carrier，再按列slice，参考既有合法DSL形态。数学不变；实际offset传递必须重新检查，不以编译通过替代正确性。

## v2实际生成审查通过

两root真实GCC通过，changed AIC/AIV CCEC分别205,776B与610,928B。实际L1精确为KV[0,393216)、Q[393216,458752)、prob[458752,475136)，总464KiB，没有复制完整KV或额外L1 owner。QK两路Right TEXTRACT的列offset均携带slotrow；PV的Right TEXTRACT行offset为slotrow+K。原MTE1→MTE2覆盖fence存在，slot0旧消费后才重装，slot1/2到PV末两片前保留。Vector核心去注释/空白后与baseline指令逐字节一致。`review_generated.py`保存可复核断言。

仅v2可进入硬件门禁，v1因slice后transpose丢offset未验收。此处尚未执行NPU，不能声称实际精度/速度通过。主线程入口`run-csa.sh LABEL LENGTHS 4 8191`，先B4/S6即`6,6,6,6`，再`1,2,3,4,5,6`，通过再T240/T144；每任务max780秒。
