# KV L1复用验收

- [x] 独立目录；正式代码/SDK/V4不改。
- [x] 原K512数学和所有event AST一致；外部62ABI。
- [x] T1..256 token/core/slot生命周期CPU验证。
- [x] 实际root GCC+变动mixed两核CCEC。
- [x] 实际L1峰值与slot0覆盖barrier、slot1/2存活审查。
- [ ] 主线程B4/S6、mixed21、T240、T144首差停止逐bit/性能门禁。
