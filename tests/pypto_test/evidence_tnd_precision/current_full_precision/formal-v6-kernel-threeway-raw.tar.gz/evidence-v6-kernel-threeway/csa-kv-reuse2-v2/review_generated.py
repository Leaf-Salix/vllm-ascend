"""Review actual current full-carrier offsets, memory map and Vector math identity."""
import re,json,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent
p=P/'generated-review/candidate/kernels/aic/qk_pv_aic.cpp';s=p.read_text();cube=s[s.index('static __aicore__ void qk_pv_aic('):s.index('static __aicore__ void qk_pv_aiv(')]
assert 'const int64_t v37 = 393216;' in cube and 'const int64_t v40 = 458752;' in cube
assert 'uint64_t v111 = (uint64_t) v37;' in cube,'Q base changed'
assert 'Tile<TileType::Mat, bfloat16_t, 512, 384,' in cube
assert 'uint16_t v150 = static_cast<uint16_t>(v127);' in cube and 'TEXTRACT(v147, v138, v149, v150);' in cube
assert 'uint16_t v159 = static_cast<uint16_t>(v127);' in cube and 'TEXTRACT(v156, v138, v158, v159);' in cube
assert 'if (v172 < v50)' in cube,'PV conditional reload no longer only part0/1'
# The large L1 carrier's physical0 base; no live duplicate/hidden 512K copy.
for tile,addr in [('v99','v100'),('v101','v102'),('v107','v108')]:
 assert f'uint64_t {addr} = (uint64_t) v36;' in cube and f'TASSIGN({tile}, {addr});' in cube
assert 'wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);' in cube
assert 'set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);' in cube
assert 'wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);' in cube
assert 'set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);' in cube
assert 'int64_t v204 = (int64_t) ((uint64_t) v197 + (uint64_t) v186);' in cube
# C++ dynamic variable names can differ in wrapper comments, but AIV core body must be byte-equivalent after comment/space removal.
def vector(arm):
 text=(P/f'generated-review/{arm}/kernels/aiv/qk_pv_aiv.cpp').read_text();a=text.index('static __aicore__ void qk_pv_aiv(');z=text.index('\nextern "C"',a)
 text=re.sub(r'//[^\n]*','',text[a:z]);return re.sub(r'\s+','',text)
assert vector('baseline')==vector('candidate'),'AIV gather/softmax/round/online core instructions changed'
result={'pass':True,'NPU_executed':False,'L1_actual_bytes':475136,'L1_capacity':524288,'L1_map':{'KV':[0,393216],'Q':[393216,458752],'probability':[458752,475136]},'QK_dynamic_slot_column_propagated_into_both_Right_TEXTRACTs':True,'PV_dynamic_slot_row_propagated':True,'scratch_overwrite_MTE1_to_MTE2_fences_present':True,'Vector_core_normalized_instruction_identity':True,'cpp_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'limitation':'static codegen review; hardware validation pending'}
(P/'generated-review-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
