"""Actual no-device root GCC and changed mixed QK/PV CCEC; never NPU."""
import hashlib,importlib,json,shutil
from pathlib import Path
from pypto.runtime import RunConfig
from pypto.runtime.kernel_compiler import KernelCompiler
P=Path(__file__).resolve().parent;ISA='/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/build/pto-isa';compiler=KernelCompiler('a2a3');results=[]
for arm in ('baseline','candidate'):
 root=importlib.import_module(arm+'_csa').decode_csa_tp1_layer_test;assert len(root.param_names)==62
 program=root.compile(config=RunConfig(platform='a2a3'));out=Path(program.output_dir);print('CHECKED48_GENERATED',arm,out,flush=True)
 orch=list((out/'orchestration').glob('*.cpp'));assert len(orch)==1
 build=P/'precompile'/arm;build.mkdir(parents=True,exist_ok=True)
 binary=compiler.compile_orchestration('tensormap_and_ringbuffer',str(orch[0]),build_dir=str(build));(build/'orchestration.so').write_bytes(binary);print('CHECKED48_GCC_PASS',arm,len(binary),flush=True)
 dest=P/'generated-review'/arm;shutil.copytree(out/'orchestration',dest/'orchestration',dirs_exist_ok=True);shutil.copytree(out/'kernels',dest/'kernels',dirs_exist_ok=True)
 compiled=[]
 if arm=='candidate':
  selected=[f for f in out.glob('kernels/*/*.cpp') if f.stem in ('csa_checked_indices',)];assert len(selected)==1
  for f in selected:
   binary=compiler.compile_incore(str(f),core_type=f.parent.name,pto_isa_root=ISA,runtime_name='tensormap_and_ringbuffer',build_dir=str(build));(build/(f.stem+'.elf')).write_bytes(binary)
   compiled.append({'name':f.name,'bytes':len(binary),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()});print('CHECKED48_CCEC_PASS',f.name,len(binary),flush=True)
 results.append({'arm':arm,'output_dir':str(out),'root_arguments':62,'GCC_bytes':len((build/'orchestration.so').read_bytes()),'CCEC':compiled})
(P/'compile-results.json').write_text(json.dumps({'NPU_executed':False,'results':results},indent=2)+'\n')
