# checked48清单

- [x] 新私有目录，V4/生产/SDK保留。
- [x] per-row整数AST、slots_plan和其余math原样。
- [x] T1..256恰好覆盖各row一次、row cacheline独占。
- [x] 真实GCC、checked核CCEC与生成代码复核。
- [ ] 主线程逐bit/稳定收益门禁。
