"""Actual generated checked Scalar rows, flush, plan identity and dependencies."""
from pathlib import Path
import re,json,hashlib
P=Path(__file__).resolve().parent
root=next((P/'generated-review/candidate/orchestration').glob('*.cpp')).read_text()
assert 'params_t59.launch_spec.set_block_num(48);' in root
assert 'params_t60.launch_spec.set_block_num(32);' in root
assert 'params_t60_deps[params_t60_deps_count++] = checked_tid_' in root
assert 'params_t61_deps[params_t61_deps_count++] = qk_plan_tid_' in root
p=P/'generated-review/candidate/kernels/aiv/csa_checked_indices.cpp';s=p.read_text()
assert 'const int64_t v18 = 48;' in s
assert 'for (int64_t v26 = (int64_t) v12; v26 < v11; v26 += v18)' in s
assert s.count('dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE)')==2
assert 'TCMP' not in s
paths=[P/f'generated-review/{arm}/kernels/aiv/csa_slots_build_valid_qk_plan.cpp' for arm in ('baseline','candidate')]
def core(p):
 s=p.read_text();a=s.index('static __aicore__ void csa_slots_build_valid_qk_plan(');z=s.index('\nextern "C"',a)
 s=re.sub(r'//[^\n]*','',s[a:z]);return re.sub(r'\s+','',s)
assert core(paths[0])==core(paths[1]),'independent slots planner instructions changed'
result={'pass':True,'NPU_executed':False,'checked_grid48_stride48':True,'Scalar_data_cache_flush_preserved':True,'slots_plan32_stride256_same_normalized_core':True,'checked_plan_qk_dependencies_preserved':True,'cmp_output_base_alignment_at_least64_bytes':True,'row_stride_bytes':2048,'cpp_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(P/'generated-review-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
