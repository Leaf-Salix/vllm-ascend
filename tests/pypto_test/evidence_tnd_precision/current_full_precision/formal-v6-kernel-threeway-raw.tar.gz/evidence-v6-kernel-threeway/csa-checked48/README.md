# checked-only 48worker单因素

baseline为V4固定32worker、每worker8query块；candidate只将Scalar checked_indices改为48worker、每次1query、stride48。slots_plan保持原32worker和8query块，QK/PV及所有其它数学完全原样。没有SDK或正式源码更改。

当前DFX确认芯片48个AIV、24个AIC，checked属于Scalar-only AIV核。T240从30个活跃worker×8query改为48×5query；T21从3个活跃worker改为21个各1query。单row内256对索引的验证/swap/写入顺序保持原AST，改变的只是独立row分工。

每row输出512个INT32，共2048B，runtime数据allocation至少64B对齐，因此不同worker写不同cacheline。Scalar flush仍在任务退出，checked→plan→QK依赖不变；没有把Scalar/V同任务通信冒充flush。输入只读，无跨row缓存状态。

CPU遍历T1..256证明原/新均恰好覆盖每行一次，并核对per-row数学AST字节义等价。root外部仍62tensor。先做实际GCC和checked核CCEC/生成代码审查，再由主线程以Native/基准/候选做B4S6、mixed21、T240、T144单因素逐bit/性能；发现首差停止。任务不超过15min，max780/内部750。当前没有NPU收益声明。

## 无设备门禁完成

actual orchestration GCC原/新均通过；changed checked CCEC 47,096B。`review_generated.py`确认真实checked grid48/stride48、ENTIRE_DATA_CACHE flush保留、slots planner核心去注释指令与baseline完全相同、checked→plan→QK依赖保留。独立reviewer检查源码row时序及cacheline独占，未见阻断。NPU仍未提交。

提交入口为`bash "$job/run-csa.sh" LABEL LENGTHS 4 8191`。先`1,2,3,4,5,6`(T21)，通过后40个6(T240)及24个6(T144)，每项max780秒。baseline为当前V4，固定32×8；candidate只有checked48×1，其余相同。
