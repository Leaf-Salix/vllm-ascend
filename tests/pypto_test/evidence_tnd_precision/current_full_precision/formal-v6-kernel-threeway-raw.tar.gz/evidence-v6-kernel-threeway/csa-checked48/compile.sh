#!/usr/bin/env bash
set -euo pipefail
source /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overnight-20261019/csa-checked48/env.sh
export ASCEND_RT_VISIBLE_DEVICES="" TORCH_DEVICE_BACKEND_AUTOLOAD=0 CMAKE_BUILD_PARALLEL_LEVEL=4
ccache -s
python "$job/check_cpu.py"
python "$job/preflight.py"
python "$job/compile.py"
