"""Check only independent row assignment changed; per-row integer AST identical."""
import ast,copy,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent;V=P.parent/'csa-combo-v4';dump=lambda n:ast.dump(ast.Module(body=n,type_ignores=[]) if isinstance(n,list) else n,include_attributes=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=ast.parse((P/'baseline_sparse.py').read_text());c=ast.parse((P/'candidate_sparse.py').read_text())
def checked(tree):
 return next(n for n in ast.walk(tree) if isinstance(n,ast.With) and any(isinstance(i.context_expr,ast.Call) and any(k.arg=='name_hint' and isinstance(k.value,ast.Constant) and k.value.value=='csa_checked_indices' for k in i.context_expr.keywords) for i in n.items))
bc,cc=checked(b),checked(c);assert dump(bc.body[1].body[0].body[1:])==dump(cc.body[1].body),'per-row integer math/read/write changed'
assert dump(cc.body[1].iter)==dump(ast.parse('pl.range(checked_worker,t_dim,48)',mode='eval').body)
assert isinstance(cc.items[0].context_expr.args[0],ast.Constant) and cc.items[0].context_expr.args[0].value==48
replacement=copy.deepcopy(bc);r=copy.deepcopy(c)
class Restore(ast.NodeTransformer):
 def visit_With(self,n):
  if dump(n)==dump(cc):return replacement
  return self.generic_visit(n)
r=Restore().visit(r);assert dump(r)==dump(b),'another numeric/planner/event factor changed'
assert sha(P/'baseline_sparse.py')==sha(V/'candidate_sparse.py')
for n in ('candidate_hc.py','optimized_hc.py','candidate_panel.py','candidate_norm.py','candidate_wkv.py','candidate_o_proj.py','wide_heads.py','ragged_fixture.py'):
 assert sha(P/n)==sha(V/n),n
root=ast.parse((P/'candidate_csa.py').read_text());base=ast.parse((P/'baseline_csa.py').read_text())
for n in ast.walk(base):
 if isinstance(n,ast.ImportFrom) and n.module=='baseline_sparse':n.module='candidate_sparse'
assert dump(root)==dump(base)
records=[]
for t in range(1,257):
 old=[]
 for worker in range(32):
  for start in range(worker*8,t,256):old.extend(range(start,min(start+8,t)))
 new=[r for worker in range(48) for r in range(worker,t,48)]
 assert len(old)==t==len(new) and sorted(old)==sorted(new)==list(range(t))
 assert 512*4%64==0
 records.append({'T':t,'active_old':min((t+7)//8,32),'active_new':min(t,48),'max_rows_old':min(t,8),'max_rows_new':(t+47)//48})
result={'pass':True,'NPU_executed':False,'per_row_integer_AST_same':True,'only_checked_task_partition_changed':True,'physical_AIV48_confirmed_from_DFX_metadata':True,'all_T1to256_unique_full_row_cover':True,'cmp_row_stride_bytes':2048,'Scalar_exit_flush_and_checked_plan_dependency_unchanged':True,'records':records}
(P/'cpu-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='records'},indent=2))
