"""五档真实校准metadata覆盖；只检查harness，candidate数学不得改动。"""
import ast
import hashlib
import json
import runpy
from pathlib import Path
HERE=Path(__file__).resolve().parent
assert hashlib.sha256((HERE/'candidate_o_proj.py').read_bytes()).hexdigest()=='a0ddb5470ea1950d985038bcfe5ba9669c4106d04d89b2513bdd5d827b9794d9'
base=ast.parse((HERE.parent/'oproj-wob-m64-probe/probe.py').read_text())
new=ast.parse((HERE/'probe.py').read_text())
# Exact common Native reference and stage/guard checking functions are preserved.
for name in ('check','guards','reference','check_outputs'):
    get=lambda t:next(n for n in ast.walk(t) if isinstance(n,ast.FunctionDef) and n.name==name)
    assert ast.dump(get(base),include_attributes=False)==ast.dump(get(new),include_attributes=False),name
s=(HERE/'probe.py').read_text()
assert 'choices=(6,21,40,144,240)' in s
assert 'assert rows == 240' not in s and 'range(1,15)' not in s
assert 'T144_Native_start252_V4_M128_covered' in s
assert 'equal_start249_preserved_Korder_bit_gate' in s
workspace=HERE.parents[3]
d=runpy.run_path(str(workspace/'vllm-ascend-nalinaly-tnd-20261008-codex/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision/oproj_order_data.py'))
records=[]
for T in (6,21,40,144,240):
    mode=int(d['OPROJ_TOKEN_MODES'][T-1]);plane=d['OPROJ_TILE_STARTS'][mode];tiles=(T+15)//16
    fast=narrow=high252=0;starts=set()
    for first_rb in range(0,tiles,8):
        peers=min(8,tiles-first_rb)
        for g in range(8):
            for b in range(8):
                first=max(int(plane[first_rb][g][b]),0);starts.add(first)
                same=all(max(int(plane[rb][g][b]),0)==first for rb in range(first_rb,first_rb+peers))
                eligible=T>16 and same and (T<192 or first<=240)
                fast+=int(eligible);narrow+=0 if eligible else peers
                if first==252:
                    assert eligible;high252+=1
    if T==144:assert high252>0 and narrow==0 and fast==128
    if T==6:assert fast==0 and narrow==64
    if T==240:assert fast==128 and narrow==0
    records.append({'T':T,'mode':mode,'starts':sorted(starts),'M128_fast_contexts':fast,'M16_fallback_tiles':narrow,'start252_V4_M128_contexts':high252,'last_M16_valid_rows':T-(tiles-1)*16})
result={'pass':True,'candidate_math_sha256':'a0ddb5470ea1950d985038bcfe5ba9669c4106d04d89b2513bdd5d827b9794d9','scope':'harness geometry and unchanged Native/stage helpers, not hardware precision','calibration':records}
(HERE/'harness-cpu-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
