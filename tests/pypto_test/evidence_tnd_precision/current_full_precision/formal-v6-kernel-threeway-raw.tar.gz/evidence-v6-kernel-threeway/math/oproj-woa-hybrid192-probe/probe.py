"""真实L4权重/已保存heads：Native、WO-B64基线与WO-A Hybrid192逐阶段首差即停。"""
import argparse
import contextlib
import hashlib
import json
import os
from pathlib import Path
import statistics
import time

import torch
import torch_npu
import pypto.torch
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from vllm_ascend.utils import enable_custom_op
from dsv4_csa_single_layer import make_layer
from dsv4_csa_native_case import native_session

import baseline_o_proj
import candidate_o_proj

BASE = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
META_SHA = '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
FIXTURE_SHA = '5b873509016a7419abf5639a808da58950eb2d3d3bd332c00ed8625e00174481'
ORDER_SHA = '2c6ed88f69024a894543228a818cc5e7a4081ffacbceebb9fec5452a2b187686'
STAGES = ('oa', 'qi', 'scale', 'output')
parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--tokens', type=int, choices=(6,21,40,144,240), required=True)
parser.add_argument('--device', type=int)
parser.add_argument('--timing-rounds', type=int, default=0)
parser.add_argument('--timing-iters', type=int, default=10)
args = parser.parse_args()
assert 0 <= args.timing_rounds <= 20 and 1 <= args.timing_iters <= 100
args.out.mkdir()
started = time.monotonic()
report = {'pass': False, 'complete': False, 'layer': 4, 'tokens': args.tokens,
          'scope': 'same real L4 weights and saved heads; Native vs qualified WO-A M128 + WO-B M64 vs Hybrid192 (V4 for T<192, M128 seedK256 for T>=192) + same WO-B M64, not full CSA or whole-model token acceptance',
          'task_device': os.environ['TASK_DEVICE'], 'comparisons': [], 'timings': [], 'completed_phases': []}
heads = None


def save():
    (args.out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')


def host(value):
    torch.npu.synchronize()
    if value.device.type != 'cpu' and torch_npu.get_npu_format(value) not in (0, 2):
        value = torch_npu.npu_format_cast(value, 2)
    return value.detach().cpu().contiguous()


def tensor_sha(value):
    return hashlib.sha256(host(value).view(torch.uint8).numpy().tobytes()).hexdigest()


def check(label, actual, expected):
    actual, expected = host(actual), host(expected)
    assert actual.shape == expected.shape and actual.dtype == expected.dtype, label
    if expected.is_floating_point():
        assert bool(torch.isfinite(expected).all()), label + ' reference nonfinite'
    bits_type = {1: torch.int8, 2: torch.int16, 4: torch.int32}[actual.element_size()]
    diff = actual.view(bits_type) != expected.view(bits_type)
    result = {'label': label, 'bit_equal': not bool(diff.any()), 'different_elements': int(diff.sum()),
              'max_abs': float((actual.float() - expected.float()).abs().max()),
              'first_coordinates': diff.nonzero()[:8].tolist()}
    if actual.is_floating_point() and not bool(torch.isfinite(actual).all()):
        result['nonfinite_actual_elements'] = int((~torch.isfinite(actual)).sum())
        result['max_abs'] = 'nonfinite'
    report['comparisons'].append(result)
    save()
    if not result['bit_equal']:
        result['first_values'] = [{'index': index, 'actual': str(actual[tuple(index)].item()),
                                   'expected': expected[tuple(index)].item()} for index in result['first_coordinates']]
        save()
        torch.save({'stage': label, 'heads': host(heads) if heads is not None else None,
                    'actual': actual, 'expected': expected}, args.out / 'first-difference.pt')
        raise RuntimeError('FIRST_BIT_DIFFERENCE ' + label)


def check_time():
    assert time.monotonic() - started < 690, 'Split remaining cases into another <=15 minute task'


torch.npu.set_device(0)
torch.npu.config.allow_internal_format = True
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
current_platform.pre_register_and_update()
assert enable_custom_op()
checkpoint = Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config = EngineArgs(model=str(checkpoint), tokenizer_mode='deepseek_v4', trust_remote_code=True,
    tensor_parallel_size=1, dtype='bfloat16', quantization='ascend', hf_overrides={'sliding_window':128},
    max_model_len=16384, max_num_seqs=40, max_num_batched_tokens=256, enable_prefix_caching=False,
    enforce_eager=False, block_size=32,
    speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},
    additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,
        'fuse_norm_quant':True,'align_decode_capture_sizes':False},'enable_cpu_binding':False,
        'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()

save()
stack = contextlib.ExitStack()
try:
    stack.enter_context(native_session(config, 0))
    with torch.inference_mode():
        pypto.torch.init(device=0, platform='a2a3', runtime='tensormap_and_ringbuffer')
        layer, details = make_layer(config, checkpoint, torch.device('npu:0'), 4)
        report['weight_details'] = details
        impl = layer.self_attn.dsa_attn.dsa_attn.impl
        fixture_dir = Path('/data/pyptouser/yejia/lc128/retest192-native2-b24000/full-probe')
        fixture_path = fixture_dir / 'step074.pt'
        assert hashlib.sha256(fixture_path.read_bytes()).hexdigest() == FIXTURE_SHA
        fixture = torch.load(fixture_path, map_location='cpu', weights_only=True)[4]
        stage_record = json.loads((fixture_dir / 'stages.jsonl').read_text().splitlines()[74])['layers']['4']
        for key in ('heads', 'oproj'):
            assert tensor_sha(fixture[key]) == stage_record[key]['sha256']
        report['fixture'] = {'path': str(fixture_path), 'sha256': FIXTURE_SHA, 'layer': 4,
                             'saved_heads_sha256': stage_record['heads']['sha256'],
                             'saved_output_sha256': stage_record['oproj']['sha256']}
        torch.npu.set_compile_mode(jit_compile=False)
        from npugraph_ex._acl_concrete_graph import static_kernel
        static_kernel.compile_static_kernel(lambda: None)
        assert len(static_kernel._installed_run_pkgs) == 13
        assert hashlib.sha256((Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE']) / 'metadata.json').read_bytes()).hexdigest() == META_SHA
        report['static'] = {'installed_packages': 13, 'metadata_sha256': META_SHA}
        from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.native_adapter import prepare_weights
        prepared = prepare_weights(layer.self_attn, None, layer)
        wa, wb, ws = (prepared[key] for key in ('wo_a', 'wo_b', 'wo_b_scale'))
        weight_hashes = [tensor_sha(value) for value in (wa, wb, ws)]
        report['weight_hashes'] = weight_hashes
        order_path = BASE / 'wkv-production-oproj-20261017/oproj-order-map-v1.json'
        assert hashlib.sha256(order_path.read_bytes()).hexdigest() == ORDER_SHA
        orders = json.loads(order_path.read_text())
        assert orders['k_block'] == 16 and orders['column_unit'] == 128 and orders['order_family'] == 'ascending_cyclic_256'
        assert orders['native_metadata_sha256'] == META_SHA
        report['order_sha256'] = ORDER_SHA
        ops = {name: pypto.torch.register(module.o_proj_test, 'precision_oproj_woa_seed256v3_20261019::' + name)
               for name, module in (('baseline', baseline_o_proj), ('candidate', candidate_o_proj))}
        report['source_hashes'] = {name: hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()
                                  for name, module in (('baseline', baseline_o_proj), ('candidate', candidate_o_proj))}
        real_heads = fixture['heads'].reshape(6, 32768)

        def alloc(rows, columns, dtype):
            sentinel = 0.0625 if dtype.is_floating_point else 37
            owner = torch.full((rows + 16, columns), sentinel, dtype=dtype, device='npu')
            return owner, owner[8:-8]

        def make_outputs(rows):
            definitions = ((8192, torch.bfloat16), (8192, torch.int8), (1, torch.float32), (4096, torch.bfloat16))
            pairs = [alloc(rows, columns, dtype) for columns, dtype in definitions]
            return [owner for owner, _ in pairs], [value for _, value in pairs]

        def poison(values):
            for value in values:
                value.fill_(float('nan') if value.is_floating_point() else -77)

        def guards(label, owners):
            for index, owner in enumerate(owners):
                sentinel = 0.0625 if owner.is_floating_point() else 37
                edges = torch.cat((host(owner[:8]), host(owner[-8:])))
                expected = torch.full_like(edges, sentinel)
                check(label + '_guard_' + str(index), edges, expected)

        # Before new T values, prove same Native component can reproduce archived whole-model output.
        heads = real_heads.to('npu')
        archived_output = torch.empty((6, 4096), dtype=torch.bfloat16, device='npu')
        impl._forward_o_proj(heads.view(6, 64, 512), archived_output)
        check('Native_saved_L4_T6_fidelity', archived_output, fixture['oproj'])
        check_time()

        rows = args.tokens
        initial = real_heads.repeat(((rows + 5) // 6, 1))[:rows].clone()
        input_owner, heads = alloc(rows, 32768, torch.bfloat16)
        heads.copy_(initial.to('npu'))
        from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision import oproj_order_data as order_data
        order_data_path=Path(order_data.__file__).resolve()
        assert order_data_path.is_relative_to(Path(os.environ['SOURCE_ROOT']).resolve())
        assert order_data.NATIVE_OPROJ_ORDER_MAP_SHA256==ORDER_SHA
        order_mode=int(order_data.OPROJ_TOKEN_MODES[rows-1])
        all_order=torch.tensor(order_data.OPROJ_TILE_STARTS[order_mode],dtype=torch.int32)
        assert list(all_order.shape)==[16,8,8]
        raw_order=all_order[:(rows+15)//16].clone()
        crosschecked=[]
        for selected_rows in (6,144,240):
            selected_mode=int(order_data.OPROJ_TOKEN_MODES[selected_rows-1])
            selected=torch.tensor(order_data.OPROJ_TILE_STARTS[selected_mode],dtype=torch.int32)[:(selected_rows+15)//16]
            assert torch.equal(selected,torch.tensor(orders['selected'][str(selected_rows)],dtype=torch.int32)),('order table crosscheck',selected_rows)
            crosschecked.append(selected_rows)
        report['order_calibration']={'source':str(order_data_path),'source_sha256':hashlib.sha256(order_data_path.read_bytes()).hexdigest(),'Native_metadata_sha256':META_SHA,'map_sha256':ORDER_SHA,'mode':order_mode,'all_T_table_used':True,'crosschecked_original_selected_T':crosschecked}

        assert list(raw_order.shape) == [(rows + 15) // 16, 8, 8]
        assert bool(((raw_order >= 0) & (raw_order < 256)).all())
        order_cpu = torch.zeros((16, 8, 8), dtype=torch.int32)
        order_cpu[:raw_order.shape[0]] = raw_order
        order = order_cpu.to('npu')
        report['order_starts'] = sorted(raw_order.unique().tolist())
        route=[]
        for first_rb in range(0,(rows+15)//16,8):
            peers=min(8,(rows+15)//16-first_rb)
            for group in range(8):
                for block in range(8):
                    first=max(int(raw_order[first_rb,group,block]),0)
                    same=all(max(int(raw_order[rb,group,block]),0)==first for rb in range(first_rb,first_rb+peers))
                    fast=rows>16 and same and (rows<192 or first<=240)
                    route.append({'first_rb':first_rb,'group':group,'block':block,'start':first,'peers':peers,'same_start':same,'M128_active':fast,'seedK256_M128':fast and rows>=192,'M16_fallback':not fast})
        report['Native_order_routing']={'selected_helper':'seed256' if rows>=192 else 'V4','contexts':route,'M128_fast_contexts':sum(v['M128_active'] for v in route),'M16_fallback_contexts':sum(v['M16_fallback'] for v in route),'M16_fallback_tiles':sum(v['peers'] for v in route if v['M16_fallback']),'tail_rows_in_last_M16':rows-((rows-1)//16)*16,'true_rows':rows,'internal_accum_capacity_rows':rows+127,'WO_B_path':'M16' if rows<=16 else 'M64'}
        if rows==144:
            assert 252 in report['order_starts'],'expected Native T144 start252 missing'
            high=[v for v in route if v['start']==252]
            assert high and all(v['M128_active'] and not v['M16_fallback'] for v in high)
            assert sum(v['M16_fallback'] for v in route)==0,'T144 V4 was wrongly sent to M16'
            report['T144_Native_start252_V4_M128_covered']=len(high)

        owners, outputs, graphs = {}, {}, {}
        for name in ops:
            owners[name], outputs[name] = make_outputs(rows)
        native_owner, native_output = alloc(rows, 4096, torch.bfloat16)

        def native():
            return impl._forward_o_proj(heads.view(rows, 64, 512), native_output)

        def call(name):
            ops[name](heads, wa, wb, ws, order, *outputs[name])

        def reference(value, label):
            heads.copy_(value.to('npu'))
            native()
            unhooked = native_output.clone()
            observed = {}
            bmm_original = torch_npu.npu_transpose_batchmatmul
            quant_original = torch_npu.npu_dynamic_quant
            calls = {'oa': 0, 'quant': 0}
            def bmm(*values, **kwargs):
                result = bmm_original(*values, **kwargs)
                calls['oa'] += 1
                observed['oa'] = result.clone().reshape(rows, 8192)
                return result
            def quant(*values, **kwargs):
                result = quant_original(*values, **kwargs)
                calls['quant'] += 1
                observed['qi'] = result[0].clone().reshape(rows, 8192)
                observed['scale'] = result[1].clone().reshape(rows, 1)
                return result
            torch_npu.npu_transpose_batchmatmul = bmm
            torch_npu.npu_dynamic_quant = quant
            try:
                native()
            finally:
                torch_npu.npu_transpose_batchmatmul = bmm_original
                torch_npu.npu_dynamic_quant = quant_original
            assert calls == {'oa': 1, 'quant': 1}, calls
            check(label + '_Native_hook_fidelity', native_output, unhooked)
            observed['output'] = native_output.clone()
            return {key: host(observed[key]) for key in STAGES}

        def check_outputs(label, name, reference_values):
            for key, value in zip(STAGES, outputs[name]):
                check(label + '_' + name + '_' + key, value, reference_values[key])
            guards(label + '_' + name, owners[name])

        ref_a = reference(initial, 'A')
        for name in ops:
            call(name)
            check_outputs('eager_A', name, ref_a)
            graph = torch.npu.NPUGraph()
            with torch.npu.graph(graph):
                call(name)
            graphs[name] = graph
        native()
        native_graph = torch.npu.NPUGraph()
        with torch.npu.graph(native_graph):
            native()
        graphs['native'] = native_graph

        for phase, value in (('A', initial), ('B', torch.roll(initial, 1, 1)), ('A_restored', initial),
                             ('zero', torch.zeros_like(initial)), ('tiny', initial * 2**-40), ('small', initial * 2**-20)):
            check_time()
            ref = ref_a if phase in ('A', 'A_restored') else reference(value, phase)
            heads.copy_(value.to('npu'))
            native_output.fill_(float('nan'))
            native_graph.replay()
            check(phase + '_Native_unhooked_graph', native_output, ref['output'])
            guards(phase + '_Native', [native_owner])
            for name in ops:
                poison(outputs[name])
                graphs[name].replay()
                check_outputs('graph_' + phase, name, ref)
                # Direct old/new stage equality is explicit, in addition to both vs Native.
                if name == 'candidate':
                    for key, actual, old in zip(STAGES, outputs[name], outputs['baseline']):
                        check(phase + '_candidate_vs_baseline_' + key, actual, old)
            check(phase + '_heads_unchanged', heads, value)
            check(phase + '_order_unchanged', order, order_cpu)
            guards(phase + '_input', [input_owner])
            assert weight_hashes == [tensor_sha(weight) for weight in (wa, wb, ws)], 'weights mutated'
            report['completed_phases'].append(phase)
            save()

        # Force unequal M16 starts without changing pointers or recapturing.
        # Native has its own fixed rotation, so only same-input qualified M128/WO-B64 baseline PTO is gold here.
        if rows > 16:
            forced_order = order_cpu.clone()
            for rb in range((rows + 15) // 16):
                if rb % 8 == 1:
                    forced_order[rb] = (forced_order[rb] + 1) % 256
            assert not torch.equal(forced_order, order_cpu)
            order.copy_(forced_order.to('npu'))
            report['forced_unequal_starts'] = {'ran': True, 'gold': 'same-input qualified M128/WO-B64 baseline, same overridden start',
                'changed_descriptor_elements': int((forced_order != order_cpu).sum()), 'phases': []}
            for phase, value in (('A', initial), ('B', torch.roll(initial, 1, 1)), ('A_restored', initial)):
                check_time()
                heads.copy_(value.to('npu'))
                poison(outputs['baseline'])
                call('baseline')
                gold = {key: host(output) for key, output in zip(STAGES, outputs['baseline'])}
                poison(outputs['baseline'])
                graphs['baseline'].replay()
                check_outputs('forced_'+phase+'_old_graph_fidelity', 'baseline', gold)
                poison(outputs['candidate'])
                call('candidate')
                check_outputs('forced_'+phase+'_eager', 'candidate', gold)
                poison(outputs['candidate'])
                graphs['candidate'].replay()
                check_outputs('forced_'+phase+'_graph', 'candidate', gold)
                check('forced_'+phase+'_heads_unchanged', heads, value)
                check('forced_'+phase+'_order_unchanged', order, forced_order)
                guards('forced_'+phase+'_input', [input_owner])
                assert weight_hashes == [tensor_sha(weight) for weight in (wa, wb, ws)], 'weights mutated'
                report['forced_unequal_starts']['phases'].append(phase)
                save()
            order.copy_(order_cpu.to('npu'))
            heads.copy_(initial.to('npu'))
            native_graph.replay()
            check('after_forced_restore_Native', native_output, ref_a['output'])
            for name in ops:
                poison(outputs[name])
                graphs[name].replay()
                check_outputs('after_forced_restore', name, ref_a)
            check('after_forced_restore_order', order, order_cpu)
        else:
            report['forced_unequal_starts'] = {'ran': False, 'reason': 'one valid M16 tile; no unequal start exists inside an M128 panel'}

        # Equal starts >240: seed256 must use M16; V4 keeps its original wide path. Both preserve K order.
        high_order = torch.full_like(order_cpu, 249)
        order.copy_(high_order.to('npu'))
        heads.copy_(initial.to('npu'))
        poison(outputs['baseline']);call('baseline')
        high_gold = {key: host(output) for key, output in zip(STAGES, outputs['baseline'])}
        poison(outputs['candidate']);graphs['candidate'].replay()
        check_outputs('equal_start249_preserved_Korder', 'candidate', high_gold)
        check('equal_start249_order_unchanged', order, high_order)
        guards('equal_start249_input', [input_owner])
        assert weight_hashes == [tensor_sha(weight) for weight in (wa, wb, ws)], 'weights mutated'
        order.copy_(order_cpu.to('npu'));heads.copy_(initial.to('npu'))
        for name in ops:
            poison(outputs[name]);graphs[name].replay()
            check_outputs('after_start249_restore', name, ref_a)
        report['equal_start249_preserved_Korder_bit_gate'] = True
        report['equal_start249_route'] = 'seed256 M16 fallback' if rows>=192 else ('V4 M128' if rows>16 else 'V4 M16')

        if args.timing_rounds:
            heads.copy_(initial.to('npu'))
            timing = {name: [] for name in graphs}
            for repeat in range(args.timing_rounds):
                check_time()
                names = ('native', 'baseline', 'candidate') if repeat % 2 == 0 else ('candidate', 'baseline', 'native')
                for name in names:
                    begin, end = torch.npu.Event(enable_timing=True), torch.npu.Event(enable_timing=True)
                    begin.record()
                    for _ in range(args.timing_iters):
                        graphs[name].replay()
                    end.record()
                    torch.npu.synchronize()
                    timing[name].append(begin.elapsed_time(end) * 1000 / args.timing_iters)
            report['timings'] = {name: {'us': values, 'min_us': min(values), 'mean_us': statistics.mean(values),
                                       'max_us': max(values)} for name, values in timing.items()}
            native_graph.replay()
            check('after_timing_Native_output', native_output, ref_a['output'])
            for name in ops:
                graphs[name].replay()
                check_outputs('after_timing', name, ref_a)
            guards('after_timing_Native', [native_owner])
            guards('after_timing_input', [input_owner])
            check('after_timing_heads_unchanged', heads, initial)
            check('after_timing_order_unchanged', order, order_cpu)
            assert weight_hashes == [tensor_sha(weight) for weight in (wa, wb, ws)], 'weights mutated after timing'

        report.update(complete=True, **{'pass': True, 'wall_seconds': time.monotonic() - started})
        save()
        print('OPROJ_PACKET_REAL_WEIGHT_PASS', rows, json.dumps(report), flush=True)
except Exception as error:
    report['error'] = repr(error)
    report['wall_seconds'] = time.monotonic() - started
    save()
    raise
finally:
    stack.close()
