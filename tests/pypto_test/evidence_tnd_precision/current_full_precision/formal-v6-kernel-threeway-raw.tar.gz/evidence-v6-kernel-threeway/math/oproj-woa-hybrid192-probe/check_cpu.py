"""真实dispatch/helper AST、全T地址/K序、两原实现canonical对照；无设备。"""
import ast
import copy
import hashlib
import json
import runpy
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
parse=lambda n:ast.parse((HERE/n).read_text())
dump=lambda x:ast.dump(x,include_attributes=False)
getfn=lambda tree,name:next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
group=lambda fn:next(n for n in fn.body if isinstance(n,ast.For) and ast.unparse(n.target)=='group')
b=parse('baseline_o_proj.py');s=parse('seed_reference.py');c=parse('candidate_o_proj.py')
assert hashlib.sha256((HERE/'baseline_o_proj.py').read_bytes()).hexdigest()=='81a08a22f056433718152c238e83f0ead622fd88b6b2d381f0a2058ad208762c'
assert hashlib.sha256((HERE/'seed_reference.py').read_bytes()).hexdigest()=='85de7ca6415d2adec8de6a88458200a9a47a0da9d820a40533c03f8f3fccd663'
root=getfn(c,'_o_proj_test');base=getfn(b,'_o_proj_test')
dispatch=next(n for n in root.body if isinstance(n,ast.If) and ast.unparse(n.test)=='rows >= 192')
class Unrename(ast.NodeTransformer):
 def __init__(self,prefix):self.prefix=prefix
 def visit_Name(self,n):
  if n.id.startswith(self.prefix):n.id=n.id[len(self.prefix):]
  return n
assert dump(Unrename('v4_').visit(copy.deepcopy(dispatch.orelse[0])))==dump(group(base))
assert dump(Unrename('seed_').visit(copy.deepcopy(dispatch.body[0])))==dump(group(getfn(s,'_o_proj_test')))
normalized=copy.deepcopy(root);idx=next(i for i,n in enumerate(normalized.body) if isinstance(n,ast.If) and ast.unparse(n.test)=='rows >= 192');normalized.body[idx]=copy.deepcopy(group(base))
assert dump(normalized)==dump(base),'outside WO-A dispatch changed'
source=ast.parse((HERE.parent/'oproj-woa-seed256-probe-v3/check_cpu.py').read_text())
classes=[n for n in source.body if isinstance(n,ast.ClassDef) and n.name in ('Weight','Trace')]
ns={};exec(compile(ast.fix_missing_locations(ast.Module(body=classes,type_ignores=[])),'Trace_definitions','exec'),ns)
Trace=ns['Trace'];ns.update(pl=Trace,heads=object(),wo_a=ns['Weight']())
prefix=[n for n in root.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('row_tiles','accum') for t in n.targets)]
trace=ast.FunctionDef(name='trace',args=ast.arguments(posonlyargs=[],args=[ast.arg(arg=x) for x in ('rows','start')],kwonlyargs=[],kw_defaults=[],defaults=[]),body=prefix+[dispatch,ast.Return(value=ast.Name(id='accum',ctx=ast.Load()))],decorator_list=[])
exec(compile(ast.fix_missing_locations(ast.Module(body=[trace],type_ignores=[])),'actual_hybrid_dispatch','exec'),ns)
workspace=HERE.parents[3];data=runpy.run_path(str(workspace/'vllm-ascend-nalinaly-tnd-20261008-codex/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision/oproj_order_data.py'))
records=[];count=0
def verify(T,plane):
 Trace.rows=T;Trace.wide=Trace.narrow=0
 out=ns['trace'](T,plane)
 assert len(out['values'])==((T+15)//16)*64
 for (rb,g,b),seq in out['values'].items():
  first=max(int(plane[rb,g,b]),0)
  assert seq==[(first+i)%256 for i in range(256)]
 return Trace.wide,Trace.narrow,len(out['values'])
for T in range(1,257):
 plane=np.array(data['OPROJ_TILE_STARTS'][data['OPROJ_TOKEN_MODES'][T-1]],dtype=np.int32)
 w,n,k=verify(T,plane);count+=k
 if T==144:assert w==128 and n==0,'V4 T144 was wrongly sent to M16'
 if T in (6,21,40,144,191,192,240,256):records.append({'T':T,'entry':'seed256' if T>=192 else 'V4','M128':w,'M16':n})
for T in (6,144,191,192,240,256):
 for first in range(256):verify(T,np.full((16,8,8),first,dtype=np.int32))
 for peer in range(1,min(16,(T+15)//16)):
  plane=np.zeros((16,8,8),dtype=np.int32);plane[peer]=1;verify(T,plane)
 verify(T,-np.arange(1,16*8*8+1,dtype=np.int32).reshape(16,8,8))
result={'pass':True,'NPU_executed':False,'outer_dispatch_threshold':192,'baseline_helper_group_AST_exact':True,'seed_helper_group_AST_exact':True,'root_outside_dispatch_AST_exact':True,'parent_accum_allocations':1,'actual_dispatch_and_helpers_executed':True,'all_T1_to256_and_K16_sequences_pass':True,'all256starts_on_six_boundary_T_pass':True,'formal_output_contexts':count,'selected':records,'candidate_sha256':hashlib.sha256((HERE/'candidate_o_proj.py').read_bytes()).hexdigest()}
(HERE/'cpu-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
