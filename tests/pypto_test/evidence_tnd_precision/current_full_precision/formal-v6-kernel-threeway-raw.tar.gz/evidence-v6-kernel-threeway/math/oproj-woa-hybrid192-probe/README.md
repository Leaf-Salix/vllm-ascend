# Hybrid192 WO-A 强对拍

候选数学逐字复制已GCC/CCEC通过的hybrid192-v3（a0ddb547…），本目录只准备独立NPU helper，不改冻结数学或正式源码、不提交任务、不重编全部数学。

沿用seed-v3通用五档真实L4权重/保存T6 heads（其他T重复截取）和冻结全T Native起点表，四阶段Native逐bit、ABA/zero/tiny/small、poison、输入/权重/起点只读、尾guard、强制不均匀起点和公共249恢复验证均保留。

T144应保持V4 M128，包括真实start252；不是seed版M16回退。T240进入seed256。公共249在T144仍V4 M128、在T240为seed M16，均与同输入旧PTO比较，恢复后再对Native。

由主线程决定提交时：`bash run.sh LABEL 144`，通过后另任务`bash run.sh LABEL 240`；每任务max-time780，内部timeout750，支持TASK_DEVICE和附加--device，首差停止。本目录没有实际硬件结果。
