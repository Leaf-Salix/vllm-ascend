"""只读检查正式源、私有SDK、固定环境、候选/基准和所有helper身份。"""
import ast
import hashlib
import importlib
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
root = Path(os.environ['SOURCE_ROOT']).resolve()
source_manifest = json.loads((root.parent / 'manifest.json').read_text())
for name, sha in source_manifest['files'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == sha, name
helper_manifest = json.loads((HERE / 'sha256sums.json').read_text())['files']
for name, sha in helper_manifest.items():
    assert hashlib.sha256((HERE / name).read_bytes()).hexdigest() == sha, name
for name in ('torch', 'torch_npu', 'vllm', 'vllm_ascend', 'pypto', 'simpler', 'npugraph_ex'):
    module = importlib.import_module(name)
    path = Path(module.__file__).resolve()
    print('MODULE', name, getattr(module, '__version__', None), str(path), flush=True)
    if name == 'vllm_ascend':
        assert path.is_relative_to(root)
    if name == 'pypto':
        assert path.is_relative_to(Path(os.environ['LOW_ACCEPTANCE_RUNTIME_PACKAGE']).resolve() / 'pypto')
    if name == 'simpler':
        assert path.is_relative_to(Path('/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/python/simpler').resolve())
for name in ('PTOAS_ROOT', 'ASCEND_HOME_PATH', 'ATB_HOME_PATH', 'CCACHE_DIR'):
    assert os.environ.get(name), name
    print('ENV', name, os.environ[name], flush=True)
assert os.environ['PYTHONNOUSERSITE'] == '1' and os.environ['HCCL_DETERMINISTIC'] == 'true'
from pypto.jit._toolchain import capture_toolchain
assert capture_toolchain('a2a3', 'tensormap_and_ringbuffer').usable
meta = Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE']) / 'metadata.json'
assert hashlib.sha256(meta.read_bytes()).hexdigest() == '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
formal = root / 'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision/o_proj.py'
assert hashlib.sha256(formal.read_bytes()).hexdigest() == '82f5593c55aa1fab9590ab180d9bc59ce9ceec47261528a08024c82ab311c764'
assert hashlib.sha256((HERE / 'baseline_o_proj.py').read_bytes()).hexdigest() == '81a08a22f056433718152c238e83f0ead622fd88b6b2d381f0a2058ad208762c'
assert hashlib.sha256((HERE / 'candidate_o_proj.py').read_bytes()).hexdigest() == 'a0ddb5470ea1950d985038bcfe5ba9669c4106d04d89b2513bdd5d827b9794d9'
import baseline_o_proj
import candidate_o_proj
for module in (baseline_o_proj, candidate_o_proj):
    assert Path(module.__file__).resolve().parent == HERE
    assert module.o_proj_test.param_names == baseline_o_proj.o_proj_test.param_names
print('PREFLIGHT_PASS', 'source_files', len(source_manifest['files']), 'helpers', len(helper_manifest), flush=True)
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision import oproj_order_data as order_data
assert Path(order_data.__file__).resolve().is_relative_to(root)
order_path=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/wkv-production-oproj-20261017/oproj-order-map-v1.json')
assert hashlib.sha256(order_path.read_bytes()).hexdigest()==order_data.NATIVE_OPROJ_ORDER_MAP_SHA256=='2c6ed88f69024a894543228a818cc5e7a4081ffacbceebb9fec5452a2b187686'
orders=json.loads(order_path.read_text())
for T in (6,144,240):
    mode=int(order_data.OPROJ_TOKEN_MODES[T-1])
    actual=[list(map(list,row)) for row in order_data.OPROJ_TILE_STARTS[mode][:(T+15)//16]]
    assert actual==orders['selected'][str(T)],('formal calibration vs original selected',T)
assert any(252 in group for row in order_data.OPROJ_TILE_STARTS[order_data.OPROJ_TOKEN_MODES[143]][:9] for group in row)
print('OPROJ_ALL_T_CALIBRATION_PASS',hashlib.sha256(Path(order_data.__file__).read_bytes()).hexdigest(),'originalT6/144/240crosschecked; T21/40fromsamefrozenallTtable; T144start252present',flush=True)
