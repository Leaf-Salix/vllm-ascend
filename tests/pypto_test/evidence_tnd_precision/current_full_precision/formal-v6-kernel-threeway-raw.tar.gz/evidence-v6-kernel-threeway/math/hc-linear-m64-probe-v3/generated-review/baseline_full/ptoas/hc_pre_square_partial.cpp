#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void hc_pre_square_partial(__gm__ float* v1, __gm__ float* v2, int64_t v3, int64_t v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int32_t v9, int32_t v10) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v11 = 64;
  // pto: %c0_i64
  const int64_t v12 = 0;
  // pto: %c2048_i64
  const int64_t v13 = 2048;
  // pto: %c16_index
  const int64_t v14 = 16;
  // pto: %c1_index
  const int64_t v15 = 1;
  // pto: %c16384_index
  const int64_t v16 = 16384;
  // pto: %c0_index
  const int64_t v17 = 0;
  // pto: %c22_index
  const int64_t v18 = 22;
  // pto: %c768_index
  const int64_t v19 = 768;
  // pto: %c32_index
  const int64_t v20 = 32;
  // pto: %c2_index
  const int64_t v21 = 2;
  // pto: %cn1_index
  const int64_t v22 = -1;
  // pto: %52
  int64_t v23 = (int64_t) ((uint64_t) v7 * (uint64_t) v18);
  // pto: %sq_partials_inline792__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %sq_partials_inline792__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %sq_partials_inline792__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %sq_partials_inline792__ssa_v0_view
  int64_t v27 = v23 * v14;
  // pto: %sq_partials_inline792__ssa_v0_view
  int64_t v28 = v26 * v27;
  // pto: %sq_partials_inline792__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v29 = pto::Shape<1, 1, 1, -1, -1>(v24, v25, v26, v23, v14);
  // pto: %sq_partials_inline792__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v30 = pto::Stride<-1, -1, -1, -1, -1>(v25 * v28, v28, v27, v14, v15);
  // pto: %sq_partials_inline792__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v31 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v29, v30);
  // pto: %x_flat_inline771__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %x_flat_inline771__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %x_flat_inline771__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %x_flat_inline771__ssa_v0_view
  int64_t v35 = (int64_t) v8;
  // pto: %x_flat_inline771__ssa_v0_view
  int64_t v36 = v35 * v16;
  // pto: %x_flat_inline771__ssa_v0_view
  int64_t v37 = v34 * v36;
  // pto: %x_flat_inline771__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v38 = pto::Shape<1, 1, 1, -1, -1>(v32, v33, v34, v35, v16);
  // pto: %x_flat_inline771__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v39 = pto::Stride<-1, -1, -1, -1, -1>(v33 * v37, v37, v36, v16, v15);
  // pto: %x_flat_inline771__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v40 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v38, v39);
  // pto: %native_sq_acc_inline806__rv_v2
  Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v41 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v14, v14);
  // pto: %native_sq_acc_inline806__rv_v2
  uint64_t v42 = (uint64_t) v12;
  TASSIGN(v41, v42);
  // pto: %sq_unit_inline762__ssa_v0
  int64_t v43 = (int64_t) v9;
  // pto: %11, %12
  int64_t v44 = (int64_t) ((uint64_t) (v43 / v3) * (uint64_t) v14);
  // pto: %13, %14
  int64_t v45 = (int64_t) ((uint64_t) (v43 % v3) * (uint64_t) v4);
  // pto: %15
  int64_t v46 = (int64_t) ((uint64_t) v8 - (uint64_t) v44);
  // pto: %16
  int64_t v47 = v46 < v14 ? v46 : v14;
  // pto: %17
  int64_t v48 = (int64_t) ((uint64_t) v18 - (uint64_t) v45);
  // pto: %18
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  for (int64_t v49 = v17; v49 < (v4 < v48 ? v4 : v48); v49 += v15) {
    // pto: %19
    ;
    int64_t v50 = (int64_t) ((uint64_t) v45 + (uint64_t) v49);
    // pto: %20
    ;
    int64_t v51 = (int64_t) ((uint64_t) v50 * (uint64_t) v19);
    // pto: %21
    ;
    int64_t v52 = (int64_t) ((uint64_t) v16 - (uint64_t) v51);
    // pto: %22
    ;
    int64_t v53 = v52 < v19 ? v52 : v19;
    // pto: %23
    ;
    int64_t v54 = v53 / v20;
    // pto: %native_sq_acc_inline806__tile
    ;
    Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v55 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v14, v14);
    // pto: %native_sq_acc_inline806__tile
    ;
    uint64_t v56 = (uint64_t) v12;
    TASSIGN(v55, v56);
    // pto: %24
    ;
    int64_t v57 = v54 / v21;
    // pto: %25
    ;
    int64_t v58 = (int64_t) ((uint64_t) v57 * (uint64_t) v21);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    for (int64_t v59 = v17; v59 < v58; v59 += v21) {
      // pto: %27
      ;
      int64_t v60 = (int64_t) ((uint64_t) v59 * (uint64_t) v20);
      // pto: %28
      ;
      int64_t v61 = (int64_t) ((uint64_t) v51 + (uint64_t) v60);
      // pto: %32, %31
      ;
      int64_t v62 = (int64_t) ((uint64_t) v51 + (uint64_t) ((int64_t) (uint64_t) v60 + (uint64_t) v20));
      // pto: %sq_lhs_inline795__tile
      ;
      Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v63 = Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v20);
      // pto: %sq_lhs_inline795__tile
      ;
      uint64_t v64 = (uint64_t) v12;
      TASSIGN(v63, v64);
      // pto: %33
      ;
      int64_t v65 = v44 < v17 ? v17 : v44;
      // pto: %34
      ;
      int64_t v66 = v61 < v17 ? v17 : v61;
      // pto: %x_flat_inline771__ssa_v0_pview
      ;
      const int64_t v67 = 0;
      // pto: %x_flat_inline771__ssa_v0_pview
      ;
      __gm__ float* v68 = PTOAS__GLOBAL_TENSOR_DATA(v40);
      // pto: %x_flat_inline771__ssa_v0_pview
      ;
      const int64_t v69 = 1;
      // pto: %x_flat_inline771__ssa_v0_pview
      ;
      const int64_t v70 = 1;
      // pto: %x_flat_inline771__ssa_v0_pview
      ;
      const int64_t v71 = 1;
      // pto: %x_flat_inline771__ssa_v0_pview
      ;
      int64_t v72 = v47 * v16;
      // pto: %x_flat_inline771__ssa_v0_pview
      ;
      int64_t v73 = v71 * v72;
      // pto: %x_flat_inline771__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 32> v74 = pto::Shape<1, 1, 1, -1, 32>(v69, v70, v71, v47, v20);
      // pto: %x_flat_inline771__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v75 = pto::Stride<-1, -1, -1, -1, -1>(v70 * v73, v73, v72, v16, v15);
      // pto: %x_flat_inline771__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v76 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v68 + (v67 + v65 * v16 + v66 * v15), v74, v75);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v63, v76);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v77 = Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v20);
      // pto: %0
      ;
      uint64_t v78 = (uint64_t) v13;
      TASSIGN(v77, v78);
      // pto: %36
      ;
      int64_t v79 = v62 < v17 ? v17 : v62;
      // pto: %37
      ;
      const int64_t v80 = 0;
      // pto: %37
      ;
      __gm__ float* v81 = PTOAS__GLOBAL_TENSOR_DATA(v40);
      // pto: %37
      ;
      const int64_t v82 = 1;
      // pto: %37
      ;
      const int64_t v83 = 1;
      // pto: %37
      ;
      const int64_t v84 = 1;
      // pto: %37
      ;
      int64_t v85 = v47 * v16;
      // pto: %37
      ;
      int64_t v86 = v84 * v85;
      // pto: %37
      ;
      pto::Shape<1, 1, 1, -1, 32> v87 = pto::Shape<1, 1, 1, -1, 32>(v82, v83, v84, v47, v20);
      // pto: %37
      ;
      pto::Stride<-1, -1, -1, -1, -1> v88 = pto::Stride<-1, -1, -1, -1, -1>(v83 * v86, v86, v85, v16, v15);
      // pto: %37
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v89 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v81 + (v80 + v65 * v16 + v79 * v15), v87, v88);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v77, v89);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %sq_lhs_inline795__tile_t
      ;
      Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v47);
      // pto: %sq_lhs_inline795__tile_t
      ;
      uint64_t v91 = (uint64_t) v12;
      TASSIGN(v90, v91);
      // pto: %sq_lhs_inline795__tile_Left
      ;
      Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v20);
      // pto: %sq_lhs_inline795__tile_Left
      ;
      uint64_t v93 = (uint64_t) v12;
      TASSIGN(v92, v93);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TMOV(v92, v63);
      // pto: %sq_lhs_inline795__tile_t_Right
      ;
      Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v47);
      // pto: %sq_lhs_inline795__tile_t_Right
      ;
      uint64_t v95 = (uint64_t) v12;
      TASSIGN(v94, v95);
      TMOV(v94, v90);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %38
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (v59 == v17) {
        pipe_barrier(PIPE_M);
        TMATMUL(v55, v92, v94);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v55, v55, v92, v94);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %2
      ;
      Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v47);
      // pto: %2
      ;
      uint64_t v97 = (uint64_t) v13;
      TASSIGN(v96, v97);
      // pto: %3
      ;
      Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v20);
      // pto: %3
      ;
      uint64_t v99 = (uint64_t) v13;
      TASSIGN(v98, v99);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TMOV(v98, v77);
      // pto: %4
      ;
      Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v47);
      // pto: %4
      ;
      uint64_t v101 = (uint64_t) v13;
      TASSIGN(v100, v101);
      TMOV(v100, v96);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      // pto: %39
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      if (v59 == v22) {
        pipe_barrier(PIPE_M);
        TMATMUL(v55, v98, v100);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v55, v55, v98, v100);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    // pto: %40, %41
    ;
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    if ((int64_t) ((uint64_t) v54 - (uint64_t) v58) == v15) {
      // pto: %44
      ;
      int64_t v102 = (int64_t) ((uint64_t) v51 + (uint64_t) ((int64_t) (uint64_t) v57 * (uint64_t) v11));
      // pto: %6
      ;
      Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v20);
      // pto: %6
      ;
      uint64_t v104 = (uint64_t) v12;
      TASSIGN(v103, v104);
      // pto: %45
      ;
      int64_t v105 = v44 < v17 ? v17 : v44;
      // pto: %46
      ;
      int64_t v106 = v102 < v17 ? v17 : v102;
      // pto: %47
      ;
      const int64_t v107 = 0;
      // pto: %47
      ;
      __gm__ float* v108 = PTOAS__GLOBAL_TENSOR_DATA(v40);
      // pto: %47
      ;
      const int64_t v109 = 1;
      // pto: %47
      ;
      const int64_t v110 = 1;
      // pto: %47
      ;
      const int64_t v111 = 1;
      // pto: %47
      ;
      int64_t v112 = v47 * v16;
      // pto: %47
      ;
      int64_t v113 = v111 * v112;
      // pto: %47
      ;
      pto::Shape<1, 1, 1, -1, 32> v114 = pto::Shape<1, 1, 1, -1, 32>(v109, v110, v111, v47, v20);
      // pto: %47
      ;
      pto::Stride<-1, -1, -1, -1, -1> v115 = pto::Stride<-1, -1, -1, -1, -1>(v110 * v113, v113, v112, v16, v15);
      // pto: %47
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v116 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v108 + (v107 + v105 * v16 + v106 * v15), v114, v115);
      TLOAD(v103, v116);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %7
      ;
      Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v47);
      // pto: %7
      ;
      uint64_t v118 = (uint64_t) v12;
      TASSIGN(v117, v118);
      // pto: %8
      ;
      Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v119 = Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v20);
      // pto: %8
      ;
      uint64_t v120 = (uint64_t) v12;
      TASSIGN(v119, v120);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      TMOV(v119, v103);
      // pto: %9
      ;
      Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v47);
      // pto: %9
      ;
      uint64_t v122 = (uint64_t) v12;
      TASSIGN(v121, v122);
      TMOV(v121, v117);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      // pto: %48
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      if (v58 == v17) {
        pipe_barrier(PIPE_M);
        TMATMUL(v55, v119, v121);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v55, v55, v119, v121);
      };
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %49, %50
    ;
    int64_t v123 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v50 * (uint64_t) v7) + (uint64_t) v44);
    // pto: %51
    ;
    int64_t v124 = v123 < v17 ? v17 : v123;
    // pto: %sq_partials_inline792__iter_v1_pview
    ;
    __gm__ float* v125 = PTOAS__GLOBAL_TENSOR_DATA(v31);
    // pto: %sq_partials_inline792__iter_v1_pview
    ;
    const int64_t v126 = 0;
    // pto: %sq_partials_inline792__iter_v1_pview
    ;
    const int64_t v127 = 16;
    // pto: %sq_partials_inline792__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 16> v128 = pto::Shape<1, 1, 1, 16, 16>();
    // pto: %sq_partials_inline792__iter_v1_pview
    ;
    pto::Stride<256, 256, 256, 16, 1> v129 = pto::Stride<256, 256, 256, 16, 1>();
    // pto: %sq_partials_inline792__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<256, 256, 256, 16, 1>, pto::Layout::ND> v130 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<256, 256, 256, 16, 1>, pto::Layout::ND>(v125 + (v126 + v124 * v127), v128, v129);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v130, v41);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}