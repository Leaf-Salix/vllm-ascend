"""门禁观测与正式HC体/数学源身份一致；不执行设备。"""
import ast
import copy
import json
import hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent
parse=lambda name:ast.parse((HERE/name).read_text())
dump=lambda node:ast.dump(node,include_attributes=False)

def validate():
    assert hashlib.sha256((HERE/'baseline_panel.py').read_bytes()).hexdigest()=='4f2703ca7686b3bbdfba0a86201a00cdc4eef96d1b93cd81c8e67acd39120593'
    assert hashlib.sha256((HERE/'candidate_panel.py').read_bytes()).hexdigest()=='f2b1ce10540509ba0237d2926b0d4b26c1a308c77aa38a12cee307da621ccb52'
    base=(HERE/'baseline_hc.py').read_text();new=(HERE/'candidate_hc.py').read_text();v4=(HERE/'reference_v4_hc.py').read_text()
    assert hashlib.sha256(v4.encode()).hexdigest()=='941345c3696fb670cc31a438de3b2d52f07be273012743fe4f8734b6b6cabdd9'
    assert base.replace('from baseline_panel import','from candidate_panel import')==v4
    expected=ast.parse(v4)
    panel=parse('candidate_panel.py');pf=next(n for n in panel.body if isinstance(n,ast.FunctionDef))
    assert ast.unparse(pf.body[2])=='tokens = pl.tensor.dim(flat, 0)'
    assert ast.unparse(pf.body[3])=='padded_tokens = pl.tensor.dim(partials, 0) // LINEAR_OK'
    mapping=json.loads((HERE/'inline-mapping.json').read_text())['mapping']
    class Rename(ast.NodeTransformer):
        def visit_Name(self,node):
            if node.id in mapping:node.id=mapping[node.id]
            return node
    actual_body=[Rename().visit(copy.deepcopy(n)) for n in pf.body[4:-1]]
    hf=next(n for n in expected.body if isinstance(n,ast.FunctionDef) and n.name=='hc_pre_gates_from_rms')
    idx=next(i for i,n in enumerate(hf.body) if isinstance(n,ast.If) and ast.unparse(n.test)=='t_dim < PANEL_MIN_TOKENS')
    hf.body[idx:idx+1]=actual_body
    ast.fix_missing_locations(expected)
    assert dump(expected)==dump(ast.parse(new)),'actual V4 plus exact mapped f2b panel body differs'
    assert 'PANEL_MIN_TOKENS = 1' in base
    for arm in ('baseline','candidate'):
        hc=parse(arm+'_hc.py');square=parse(arm+'_square.py')
        pick=lambda tree:next(n for n in ast.walk(tree) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='sq_unit')
        assert dump(pick(hc))==dump(pick(square)),arm+' standalone Gram is not the real HC body'
        imports=[n for n in hc.body if isinstance(n,ast.ImportFrom) and n.module==arm+'_panel']
        assert len(imports)==2 and [x.names[0].name for x in imports]==['hcpre_linear_panel','_hcpre_linear_panel']
    old=ast.parse((HERE/'reference_probe_hc.py').read_text())
    new=parse('probe_hc.py')
    # Actual Native op and raw-byte checker/stage helpers remain unchanged.
    for name in ('native','check','exact','snapshot'):
        get=lambda tree:next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name==name)
        assert dump(get(old))==dump(get(new)),name
    print('GATE_CPU_PASS frozen f2b math; both top/bottom imports; real Gram AST; Native and exact checker unchanged',flush=True)
if __name__=='__main__':validate()
