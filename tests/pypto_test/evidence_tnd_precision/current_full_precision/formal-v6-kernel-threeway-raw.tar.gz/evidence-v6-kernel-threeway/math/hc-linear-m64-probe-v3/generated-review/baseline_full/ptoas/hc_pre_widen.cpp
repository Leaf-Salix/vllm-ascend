#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void hc_pre_widen(__gm__ float* v1, __gm__ bfloat16_t* v2, int64_t v3, int32_t v4, int32_t v5) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v6 = 0;
  // pto: %c1024_i64
  const int64_t v7 = 1024;
  // pto: %c2048_i64
  const int64_t v8 = 2048;
  // pto: %c4096_i64
  const int64_t v9 = 4096;
  // pto: %c16384_index
  const int64_t v10 = 16384;
  // pto: %c1_index
  const int64_t v11 = 1;
  // pto: %c0_index
  const int64_t v12 = 0;
  // pto: %c32_index
  const int64_t v13 = 32;
  // pto: %c2_index
  const int64_t v14 = 2;
  // pto: %c512_index
  const int64_t v15 = 512;
  // pto: %wide_flat__ssa_v0_view
  const int64_t v16 = 1;
  // pto: %wide_flat__ssa_v0_view
  const int64_t v17 = 1;
  // pto: %wide_flat__ssa_v0_view
  const int64_t v18 = 1;
  // pto: %wide_flat__ssa_v0_view
  int64_t v19 = (int64_t) v3;
  // pto: %wide_flat__ssa_v0_view
  int64_t v20 = v19 * v10;
  // pto: %wide_flat__ssa_v0_view
  int64_t v21 = v18 * v20;
  // pto: %wide_flat__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v22 = pto::Shape<1, 1, 1, -1, -1>(v16, v17, v18, v19, v10);
  // pto: %wide_flat__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v23 = pto::Stride<-1, -1, -1, -1, -1>(v17 * v21, v21, v20, v10, v11);
  // pto: %wide_flat__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v24 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v22, v23);
  // pto: %flat__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %flat__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %flat__ssa_v0_view
  const int64_t v27 = 1;
  // pto: %flat__ssa_v0_view
  int64_t v28 = (int64_t) v3;
  // pto: %flat__ssa_v0_view
  int64_t v29 = v28 * v10;
  // pto: %flat__ssa_v0_view
  int64_t v30 = v27 * v29;
  // pto: %flat__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v31 = pto::Shape<1, 1, 1, -1, -1>(v25, v26, v27, v28, v10);
  // pto: %flat__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v32 = pto::Stride<-1, -1, -1, -1, -1>(v26 * v30, v30, v29, v10, v11);
  // pto: %flat__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v33 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v31, v32);
  // pto: %row__ssa_v0
  int64_t v34 = (int64_t) v4;
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  for (int64_t v35 = v12; v35 < v13; v35 += v14) {
    // pto: %2
    ;
    int64_t v36 = (int64_t) ((uint64_t) v35 * (uint64_t) v15);
    // pto: %4
    ;
    int64_t v37 = (int64_t) ((uint64_t) v36 + (uint64_t) v15);
    // pto: %t__tile
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v38 = Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v15);
    // pto: %t__tile
    ;
    uint64_t v39 = (uint64_t) v6;
    TASSIGN(v38, v39);
    // pto: %5
    ;
    int64_t v40 = v34 < v12 ? v12 : v34;
    // pto: %6
    ;
    int64_t v41 = v36 < v12 ? v12 : v36;
    // pto: %flat__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v42 = PTOAS__GLOBAL_TENSOR_DATA(v33);
    // pto: %flat__ssa_v0_pview
    ;
    const int64_t v43 = 0;
    // pto: %flat__ssa_v0_pview
    ;
    const int64_t v44 = 16384;
    // pto: %flat__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 512> v45 = pto::Shape<1, 1, 1, 1, 512>();
    // pto: %flat__ssa_v0_pview
    ;
    pto::Stride<16384, 16384, 16384, 16384, 1> v46 = pto::Stride<16384, 16384, 16384, 16384, 1>();
    // pto: %flat__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v47 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v42 + (v43 + v40 * v44 + v41), v45, v46);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v38, v47);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %0
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v48 = Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v15);
    // pto: %0
    ;
    uint64_t v49 = (uint64_t) v7;
    TASSIGN(v48, v49);
    // pto: %8
    ;
    int64_t v50 = v37 < v12 ? v12 : v37;
    // pto: %9
    ;
    __gm__ bfloat16_t* v51 = PTOAS__GLOBAL_TENSOR_DATA(v33);
    // pto: %9
    ;
    const int64_t v52 = 0;
    // pto: %9
    ;
    const int64_t v53 = 16384;
    // pto: %9
    ;
    pto::Shape<1, 1, 1, 1, 512> v54 = pto::Shape<1, 1, 1, 1, 512>();
    // pto: %9
    ;
    pto::Stride<16384, 16384, 16384, 16384, 1> v55 = pto::Stride<16384, 16384, 16384, 16384, 1>();
    // pto: %9
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v56 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v51 + (v52 + v40 * v53 + v50), v54, v55);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    TLOAD(v48, v56);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %value__tile
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v57 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v15);
    // pto: %value__tile
    ;
    uint64_t v58 = (uint64_t) v8;
    TASSIGN(v57, v58);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    RoundMode v59 = RoundMode::CAST_ROUND;
    SaturationMode v60 = SaturationMode::ON;
    TCVT(v57, v38, v59, v60);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %wide_flat__iter_v1_pview
    ;
    __gm__ float* v61 = PTOAS__GLOBAL_TENSOR_DATA(v24);
    // pto: %wide_flat__iter_v1_pview
    ;
    const int64_t v62 = 0;
    // pto: %wide_flat__iter_v1_pview
    ;
    const int64_t v63 = 16384;
    // pto: %wide_flat__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 1, 512> v64 = pto::Shape<1, 1, 1, 1, 512>();
    // pto: %wide_flat__iter_v1_pview
    ;
    pto::Stride<16384, 16384, 16384, 16384, 1> v65 = pto::Stride<16384, 16384, 16384, 16384, 1>();
    // pto: %wide_flat__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v66 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v61 + (v62 + v40 * v63 + v41), v64, v65);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v66, v57);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    // pto: %1
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v15);
    // pto: %1
    ;
    uint64_t v68 = (uint64_t) v9;
    TASSIGN(v67, v68);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    RoundMode v69 = RoundMode::CAST_ROUND;
    SaturationMode v70 = SaturationMode::ON;
    TCVT(v67, v48, v69, v70);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %wide_flat__tile_pview
    ;
    __gm__ float* v71 = PTOAS__GLOBAL_TENSOR_DATA(v24);
    // pto: %wide_flat__tile_pview
    ;
    const int64_t v72 = 0;
    // pto: %wide_flat__tile_pview
    ;
    const int64_t v73 = 16384;
    // pto: %wide_flat__tile_pview
    ;
    pto::Shape<1, 1, 1, 1, 512> v74 = pto::Shape<1, 1, 1, 1, 512>();
    // pto: %wide_flat__tile_pview
    ;
    pto::Stride<16384, 16384, 16384, 16384, 1> v75 = pto::Stride<16384, 16384, 16384, 16384, 1>();
    // pto: %wide_flat__tile_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v76 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v71 + (v72 + v40 * v73 + v50), v74, v75);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v76, v67);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}