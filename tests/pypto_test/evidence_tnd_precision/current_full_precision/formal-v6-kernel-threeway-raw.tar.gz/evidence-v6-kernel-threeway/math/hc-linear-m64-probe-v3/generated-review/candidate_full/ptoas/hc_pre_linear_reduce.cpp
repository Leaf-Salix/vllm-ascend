#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void hc_pre_linear_reduce(__gm__ float* v1, __gm__ float* v2, int64_t v3, int64_t v4, int32_t v5, int32_t v6) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v7 = 0;
  // pto: %c2048_i64
  const int64_t v8 = 2048;
  // pto: %c32_index
  const int64_t v9 = 32;
  // pto: %c1_index
  const int64_t v10 = 1;
  // pto: %c16_index
  const int64_t v11 = 16;
  // pto: %c0_index
  const int64_t v12 = 0;
  // pto: %c22_index
  const int64_t v13 = 22;
  // pto: %8
  int64_t v14 = (int64_t) ((uint64_t) v4 * (uint64_t) v13);
  // pto: %mixes_partials_inline1638_inline1833__phi_v3_view
  const int64_t v15 = 1;
  // pto: %mixes_partials_inline1638_inline1833__phi_v3_view
  const int64_t v16 = 1;
  // pto: %mixes_partials_inline1638_inline1833__phi_v3_view
  const int64_t v17 = 1;
  // pto: %mixes_partials_inline1638_inline1833__phi_v3_view
  int64_t v18 = v14 * v9;
  // pto: %mixes_partials_inline1638_inline1833__phi_v3_view
  int64_t v19 = v17 * v18;
  // pto: %mixes_partials_inline1638_inline1833__phi_v3_view
  pto::Shape<1, 1, 1, -1, -1> v20 = pto::Shape<1, 1, 1, -1, -1>(v15, v16, v17, v14, v9);
  // pto: %mixes_partials_inline1638_inline1833__phi_v3_view
  pto::Stride<-1, -1, -1, -1, -1> v21 = pto::Stride<-1, -1, -1, -1, -1>(v16 * v19, v19, v18, v9, v10);
  // pto: %mixes_partials_inline1638_inline1833__phi_v3_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v22 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v20, v21);
  // pto: %mixes_raw_inline1634_inline1880__ssa_v0_view
  const int64_t v23 = 1;
  // pto: %mixes_raw_inline1634_inline1880__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %mixes_raw_inline1634_inline1880__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %mixes_raw_inline1634_inline1880__ssa_v0_view
  int64_t v26 = (int64_t) v4;
  // pto: %mixes_raw_inline1634_inline1880__ssa_v0_view
  int64_t v27 = v26 * v9;
  // pto: %mixes_raw_inline1634_inline1880__ssa_v0_view
  int64_t v28 = v25 * v27;
  // pto: %mixes_raw_inline1634_inline1880__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v29 = pto::Shape<1, 1, 1, -1, -1>(v23, v24, v25, v26, v9);
  // pto: %mixes_raw_inline1634_inline1880__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v30 = pto::Stride<-1, -1, -1, -1, -1>(v24 * v28, v28, v27, v9, v10);
  // pto: %mixes_raw_inline1634_inline1880__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v31 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v29, v30);
  // pto: %linear_block_inline1636_inline1818__ssa_v0, %1
  int64_t v32 = (int64_t) ((uint64_t) ((int64_t) v5) * (uint64_t) v11);
  // pto: %mixes_total_inline1622_inline1806__tile
  Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v33 = Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v9);
  // pto: %mixes_total_inline1622_inline1806__tile
  uint64_t v34 = (uint64_t) v7;
  TASSIGN(v33, v34);
  // pto: %2
  int64_t v35 = v32 < v12 ? v12 : v32;
  // pto: %mixes_partials_inline1638_inline1833__phi_v3_pview
  __gm__ float* v36 = PTOAS__GLOBAL_TENSOR_DATA(v22);
  // pto: %mixes_partials_inline1638_inline1833__phi_v3_pview
  const int64_t v37 = 0;
  // pto: %mixes_partials_inline1638_inline1833__phi_v3_pview
  const int64_t v38 = 32;
  // pto: %mixes_partials_inline1638_inline1833__phi_v3_pview
  pto::Shape<1, 1, 1, 16, 32> v39 = pto::Shape<1, 1, 1, 16, 32>();
  // pto: %mixes_partials_inline1638_inline1833__phi_v3_pview
  pto::Stride<512, 512, 512, 32, 1> v40 = pto::Stride<512, 512, 512, 32, 1>();
  // pto: %mixes_partials_inline1638_inline1833__phi_v3_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v41 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v36 + (v37 + v35 * v38), v39, v40);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  TLOAD(v33, v41);
  set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
  for (int64_t v42 = v10; v42 < v13; v42 += v10) {
    // pto: %3, %4
    ;
    int64_t v43 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v42 * (uint64_t) v4) + (uint64_t) v32);
    // pto: %partial_tile_inline1593_inline1936__tile
    ;
    Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v44 = Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v9);
    // pto: %partial_tile_inline1593_inline1936__tile
    ;
    uint64_t v45 = (uint64_t) v8;
    TASSIGN(v44, v45);
    // pto: %5
    ;
    int64_t v46 = v43 < v12 ? v12 : v43;
    // pto: %6
    ;
    __gm__ float* v47 = PTOAS__GLOBAL_TENSOR_DATA(v22);
    // pto: %6
    ;
    const int64_t v48 = 0;
    // pto: %6
    ;
    const int64_t v49 = 32;
    // pto: %6
    ;
    pto::Shape<1, 1, 1, 16, 32> v50 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %6
    ;
    pto::Stride<512, 512, 512, 32, 1> v51 = pto::Stride<512, 512, 512, 32, 1>();
    // pto: %6
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v52 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v47 + (v48 + v46 * v49), v50, v51);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v44, v52);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %0
    ;
    Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v53 = Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v9);
    // pto: %0
    ;
    uint64_t v54 = (uint64_t) v7;
    TASSIGN(v53, v54);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TADD(v53, v33, v44);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %mixes_raw_inline1634_inline1880__ssa_v0_pview
  __gm__ float* v55 = PTOAS__GLOBAL_TENSOR_DATA(v31);
  // pto: %mixes_raw_inline1634_inline1880__ssa_v0_pview
  const int64_t v56 = 0;
  // pto: %mixes_raw_inline1634_inline1880__ssa_v0_pview
  const int64_t v57 = 32;
  // pto: %mixes_raw_inline1634_inline1880__ssa_v0_pview
  pto::Shape<1, 1, 1, 16, 32> v58 = pto::Shape<1, 1, 1, 16, 32>();
  // pto: %mixes_raw_inline1634_inline1880__ssa_v0_pview
  pto::Stride<512, 512, 512, 32, 1> v59 = pto::Stride<512, 512, 512, 32, 1>();
  // pto: %mixes_raw_inline1634_inline1880__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v60 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v55 + (v56 + v35 * v57), v58, v59);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
  TSTORE(v60, v33);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}