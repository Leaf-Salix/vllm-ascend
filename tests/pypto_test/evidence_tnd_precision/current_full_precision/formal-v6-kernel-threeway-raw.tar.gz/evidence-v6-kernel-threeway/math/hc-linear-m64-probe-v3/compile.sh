#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="" TORCH_DEVICE_BACKEND_AUTOLOAD=0
export CMAKE_BUILD_PARALLEL_LEVEL=4 MAX_JOBS=4
ccache -s
python "$job/preflight.py"
python "$job/compile.py"
ccache -s
