#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void hc_pre_native_rms(__gm__ float* v1, __gm__ float* v2, int64_t v3, int64_t v4, int32_t v5, int32_t v6) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c32_i64
  const int64_t v7 = 32;
  // pto: %c800_i64
  const int64_t v8 = 800;
  // pto: %c832_i64
  const int64_t v9 = 832;
  // pto: %c0_i64
  const int64_t v10 = 0;
  // pto: %c16_index
  const int64_t v11 = 16;
  // pto: %c1_index
  const int64_t v12 = 1;
  // pto: %c8_index
  const int64_t v13 = 8;
  // pto: %c192_index
  const int64_t v14 = 192;
  // pto: %c0_i32
  const int32_t v15 = 0;
  // pto: %c16_i32
  const int32_t v16 = 16;
  // pto: %c0_index
  const int64_t v17 = 0;
  // pto: %c22_index
  const int64_t v18 = 22;
  // pto: %cst_12
  const float v19 = 6.10351563E-5f;
  // pto: %cst_13
  const float v20 = 9.99999997E-7f;
  // pto: %cst_14
  const float v21 = 1.0f;
  // pto: %15
  int64_t v22 = (int64_t) ((uint64_t) v4 * (uint64_t) v18);
  // pto: %sq_partials_inline1846__rv_v2_view
  const int64_t v23 = 1;
  // pto: %sq_partials_inline1846__rv_v2_view
  const int64_t v24 = 1;
  // pto: %sq_partials_inline1846__rv_v2_view
  const int64_t v25 = 1;
  // pto: %sq_partials_inline1846__rv_v2_view
  int64_t v26 = v22 * v11;
  // pto: %sq_partials_inline1846__rv_v2_view
  int64_t v27 = v25 * v26;
  // pto: %sq_partials_inline1846__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v28 = pto::Shape<1, 1, 1, -1, -1>(v23, v24, v25, v22, v11);
  // pto: %sq_partials_inline1846__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v29 = pto::Stride<-1, -1, -1, -1, -1>(v24 * v27, v27, v26, v11, v12);
  // pto: %sq_partials_inline1846__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v30 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v28, v29);
  // pto: %inv_rms_inline1799__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %inv_rms_inline1799__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %inv_rms_inline1799__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %inv_rms_inline1799__ssa_v0_view
  int64_t v34 = (int64_t) v4;
  // pto: %inv_rms_inline1799__ssa_v0_view
  int64_t v35 = v34 * v12;
  // pto: %inv_rms_inline1799__ssa_v0_view
  int64_t v36 = v33 * v35;
  // pto: %inv_rms_inline1799__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v37 = pto::Shape<1, 1, 1, -1, -1>(v31, v32, v33, v34, v12);
  // pto: %inv_rms_inline1799__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v38 = pto::Stride<-1, -1, -1, -1, -1>(v32 * v36, v36, v35, v12, (int64_t) v4);
  // pto: %inv_rms_inline1799__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v39 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v2, v37, v38);
  // pto: %rms_block_inline1883__ssa_v0, %4
  int64_t v40 = (int64_t) ((uint64_t) ((int64_t) v5) * (uint64_t) v13);
  // pto: %rms_lanes_inline1887__ci_tmp_v0
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v41 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v14);
  // pto: %rms_lanes_inline1887__ci_tmp_v0
  uint64_t v42 = (uint64_t) v7;
  TASSIGN(v41, v42);
  // pto: %rms_lanes_inline1887__tile
  Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v43 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v13);
  // pto: %rms_lanes_inline1887__tile
  uint64_t v44 = (uint64_t) v8;
  TASSIGN(v43, v44);
  // pto: %ci_tmp_view
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v45;
  TRESHAPE(v45, v41);
  // pto: %ci_dst_view
  Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v46;
  TRESHAPE(v46, v43);
  TCI<Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v46, v15, v45);
  // pto: %rms_rows_inline1857__tile
  Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v47 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v13);
  // pto: %rms_rows_inline1857__tile
  uint64_t v48 = (uint64_t) v7;
  TASSIGN(v47, v48);
  // pto: %5
  int32_t v49 = (int32_t) v40;
  pipe_barrier(PIPE_V);
  TADDS(v47, v43, v49);
  // pto: %rms_local_inline1821__tile
  Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v50 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v13);
  // pto: %rms_local_inline1821__tile
  uint64_t v51 = (uint64_t) v8;
  TASSIGN(v50, v51);
  // pto: %6, %7
  int32_t v52 = (int32_t) (v40 % v11);
  pipe_barrier(PIPE_V);
  TADDS(v50, v43, v52);
  // pto: %t__tile
  Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v53 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v13);
  // pto: %t__tile
  uint64_t v54 = (uint64_t) v7;
  TASSIGN(v53, v54);
  TMULS(v53, v47, v16);
  // pto: %rms_index_inline1861__tile
  Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v55 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v13);
  // pto: %rms_index_inline1861__tile
  uint64_t v56 = (uint64_t) v7;
  TASSIGN(v55, v56);
  pipe_barrier(PIPE_V);
  TADD(v55, v53, v50);
  set_flag(PIPE_V, PIPE_S, EVENT_ID1);
  // pto: %rms_total_inline1910__tile
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v57 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v13);
  // pto: %rms_total_inline1910__tile
  uint64_t v58 = (uint64_t) v8;
  TASSIGN(v57, v58);
  // pto: %sq_partials_inline1846__rv_v2_pview
  const int64_t v59 = 0;
  // pto: %sq_partials_inline1846__rv_v2_pview
  __gm__ float* v60 = PTOAS__GLOBAL_TENSOR_DATA(v30);
  // pto: %sq_partials_inline1846__rv_v2_pview
  const int64_t v61 = 1;
  // pto: %sq_partials_inline1846__rv_v2_pview
  const int64_t v62 = 1;
  // pto: %sq_partials_inline1846__rv_v2_pview
  const int64_t v63 = 1;
  // pto: %sq_partials_inline1846__rv_v2_pview
  int64_t v64 = v22 * v11;
  // pto: %sq_partials_inline1846__rv_v2_pview
  int64_t v65 = v63 * v64;
  // pto: %sq_partials_inline1846__rv_v2_pview
  pto::Shape<1, 1, 1, -1, 16> v66 = pto::Shape<1, 1, 1, -1, 16>(v61, v62, v63, v22, v11);
  // pto: %sq_partials_inline1846__rv_v2_pview
  pto::Stride<-1, -1, -1, -1, -1> v67 = pto::Stride<-1, -1, -1, -1, -1>(v62 * v65, v65, v64, v11, v12);
  // pto: %sq_partials_inline1846__rv_v2_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v68 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v60 + (v59 + v17 * v11 + v17 * v12), v66, v67);
  wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
  MGATHER<pto::Coalesce::Elem>(v57, v68, v55);
  set_flag(PIPE_S, PIPE_V, EVENT_ID2);
  for (int64_t v69 = v12; v69 < v18; v69 += v12) {
    // pto: %rms_part_index_inline1798__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v70 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v13);
    // pto: %rms_part_index_inline1798__tile
    ;
    uint64_t v71 = (uint64_t) v9;
    TASSIGN(v70, v71);
    // pto: %9, %10, %11
    ;
    int32_t v72 = (int32_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v69 * (uint64_t) v4) * (uint64_t) v11);
    pipe_barrier(PIPE_V);
    TADDS(v70, v55, v72);
    set_flag(PIPE_V, PIPE_S, EVENT_ID2);
    // pto: %rms_value_inline1825__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v73 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v13);
    // pto: %rms_value_inline1825__tile
    ;
    uint64_t v74 = (uint64_t) v10;
    TASSIGN(v73, v74);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID2);
    MGATHER<pto::Coalesce::Elem>(v73, v68, v70);
    set_flag(PIPE_S, PIPE_V, EVENT_ID1);
    // pto: %0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v13);
    // pto: %0
    ;
    uint64_t v76 = (uint64_t) v8;
    TASSIGN(v75, v76);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
    TADD(v75, v57, v73);
  }
  // pto: %1
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v77 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v13);
  // pto: %1
  uint64_t v78 = (uint64_t) v7;
  TASSIGN(v77, v78);
  pipe_barrier(PIPE_V);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID2);
  TMULS(v77, v57, v19);
  // pto: %rms_variance_inline1823__tile
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v79 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v13);
  // pto: %rms_variance_inline1823__tile
  uint64_t v80 = (uint64_t) v7;
  TASSIGN(v79, v80);
  pipe_barrier(PIPE_V);
  TADDS(v79, v77, v20);
  // pto: %rms_root_inline1901__tile
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v81 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v13);
  // pto: %rms_root_inline1901__tile
  uint64_t v82 = (uint64_t) v7;
  TASSIGN(v81, v82);
  pipe_barrier(PIPE_V);
  TSQRT(v81, v79);
  // pto: %2
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v83 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v13);
  // pto: %2
  uint64_t v84 = (uint64_t) v8;
  TASSIGN(v83, v84);
  TEXPANDS(v83, v21);
  // pto: %native_inverse_inline1848__tile
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v85 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v13);
  // pto: %native_inverse_inline1848__tile
  uint64_t v86 = (uint64_t) v7;
  TASSIGN(v85, v86);
  pipe_barrier(PIPE_V);
  TDIV(v85, v83, v81);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %3
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v12);
  // pto: %3
  uint64_t v88 = (uint64_t) v7;
  TASSIGN(v87, v88);
  // pto: %14
  int64_t v89 = v40 < v17 ? v17 : v40;
  // pto: %inv_rms_inline1799__ssa_v0_pview
  int64_t v90 = (int64_t) v4;
  // pto: %inv_rms_inline1799__ssa_v0_pview
  const int64_t v91 = 0;
  // pto: %inv_rms_inline1799__ssa_v0_pview
  __gm__ float* v92 = PTOAS__GLOBAL_TENSOR_DATA(v39);
  // pto: %inv_rms_inline1799__ssa_v0_pview
  const int64_t v93 = 1;
  // pto: %inv_rms_inline1799__ssa_v0_pview
  const int64_t v94 = 1;
  // pto: %inv_rms_inline1799__ssa_v0_pview
  const int64_t v95 = 1;
  // pto: %inv_rms_inline1799__ssa_v0_pview
  int64_t v96 = v13 * v12;
  // pto: %inv_rms_inline1799__ssa_v0_pview
  int64_t v97 = v95 * v96;
  // pto: %inv_rms_inline1799__ssa_v0_pview
  pto::Shape<1, 1, 1, 8, 1> v98 = pto::Shape<1, 1, 1, 8, 1>(v93, v94, v95, v13, v12);
  // pto: %inv_rms_inline1799__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v99 = pto::Stride<-1, -1, -1, -1, -1>(v94 * v97, v97, v96, v12, v90);
  // pto: %inv_rms_inline1799__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v100 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v92 + (v91 + v89 * v12 + v17 * v90), v98, v99);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v100, v87);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}