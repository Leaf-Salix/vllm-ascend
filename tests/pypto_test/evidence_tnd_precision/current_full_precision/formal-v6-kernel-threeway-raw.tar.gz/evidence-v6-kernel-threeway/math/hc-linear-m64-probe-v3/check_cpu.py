"""执行真实DSL编排AST的地址/K16轨迹，验证所有T和split物理尾边界。"""
import ast
import copy
import hashlib
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
b=ast.parse((HERE/'baseline_panel.py').read_text());c=ast.parse((HERE/'candidate_panel.py').read_text())
f=lambda t:next(n for n in t.body if isinstance(n,ast.FunctionDef))
dump=lambda x:ast.dump(x,include_attributes=False)
bf=f(b);cf=f(c);assert isinstance(cf.body[-2],ast.If)
normal=copy.deepcopy(cf);normal.body[-2]=normal.body[-2].orelse[0]
assert dump(normal)==dump(bf),'producer/layout/ABI or old path changed'
assert ast.unparse(cf.body[-2].test)=='tokens >= 64'
class View:
 def __init__(self,kind,shape,offset,valid=None):self.kind=kind;self.shape=shape;self.offset=offset;self.valid=valid or shape
class Acc:
 def __init__(self,shape):self.shape=shape;self.row=0;self.valid=shape[0];self.seq=[]
class PL:
 FP32='fp32'
 @staticmethod
 def spmd(n,**kw):return range(n)
 range=staticmethod(range);min=staticmethod(min)
 @staticmethod
 def create_tensor(shape,**kw):return Acc(shape)
 @staticmethod
 def slice(source,shape,offset,valid_shape=None):
  out=View(source,shape,offset,valid_shape)
  if source=='flat':assert offset[0]>=0 and offset[0]+out.valid[0]<=PL.padded and offset[1]+shape[1]<=32768
  else:assert source=='weight' and offset[0]+shape[0]<=32768
  return out
 @staticmethod
 def matmul(x,w,**kw):
  a=Acc([x.shape[0],32]);return PL.matmul_acc(a,x,w,init_cond=True)
 @staticmethod
 def matmul_acc(a,x,w,init_cond=False):
  assert x.offset[1]==w.offset[0] and x.shape[1]==w.shape[0]==128
  if init_cond:a.seq=[]
  a.seq.extend(range(x.offset[1]//16,x.offset[1]//16+8));a.row=x.offset[0];a.valid=x.valid[0];return a
 @staticmethod
 def set_validshape(a,m,n):assert 0<m<=a.shape[0] and n==32;a.valid=m;return a
 @staticmethod
 def assemble(dst,a,offset):
  base,col=offset;split=base//PL.padded
  assert col==0 and base%PL.padded==a.row
  assert a.row+a.valid<=PL.padded,'cross-split store'
  for i in range(a.valid):
   key=(split,a.row+i);assert key not in dst;dst[key]=list(a.seq)
  return dst
PL.tensor=PL
ns={'pl':PL,'LINEAR_OK':22,'LINEAR_K_PER_SPLIT':768,'HC_DIM':16384,'MIX_PAD':32,'packed_flat':'flat','packed_weight':'weight'}
for name,node in [('baseline',bf.body[-2]),('candidate',cf.body[-2])]:
 args=ast.arguments(posonlyargs=[],args=[ast.arg(arg=x) for x in ('tokens','padded_tokens','partials')],kwonlyargs=[],kw_defaults=[],defaults=[])
 fn=ast.FunctionDef(name=name,args=args,body=[node,ast.Return(value=ast.Name(id='partials',ctx=ast.Load()))],decorator_list=[])
 exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),name,'exec'),ns)
records=[]
for T in range(1,257):
 PL.padded=(T+15)//16*16
 old=ns['baseline'](T,PL.padded,{})
 new=ns['candidate'](T,PL.padded,{})
 assert old==new and len(new)==22*PL.padded
 for (split,row),seq in new.items():
  count=min(768,16384-split*768)//64
  assert seq==list(range(split*96,split*96+count*8))
 if T in (6,21,40,63,64,144,192,240,256):records.append({'T':T,'physical_padded16':PL.padded,'path':'M64' if T>=64 else 'oldM16','tasks':22*((PL.padded+63)//64 if T>=64 else PL.padded//16),'last_store_valid':(PL.padded-1)%64+1 if T>=64 else 16})
result={'pass':True,'hardware_executed':False,'all_T1_to256_actual_AST_K16_order_exact':True,'all_padded16_rows_exact':True,'no_cross_split_store':True,'all_producers_unchanged_AST':True,'consumer_stride_unchanged':True,'selected':records,'baseline_sha256':hashlib.sha256((HERE/'baseline_panel.py').read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256((HERE/'candidate_panel.py').read_bytes()).hexdigest()}
(HERE/'cpu-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
