from pathlib import Path
from simpler.task_interface import ArgDirection as _D
_ROOT_DIR = Path(__file__).parent
KERNELS = [{'func_id': 0, 'name': 'hc_pre_widen', 'source': 'kernels/aiv/hc_pre_widen.cpp', 'core_type': 'aiv', 'signature': ['OUT', 'IN']}, {'func_id': 1, 'name': 'hc_pre_square_partial', 'source': 'kernels/aic/hc_pre_square_partial.cpp', 'core_type': 'aic', 'signature': ['OUT', 'IN']}, {'func_id': 2, 'name': 'hc_pre_native_rms', 'source': 'kernels/aiv/hc_pre_native_rms.cpp', 'core_type': 'aiv', 'signature': ['IN', 'OUT']}, {'func_id': 3, 'name': 'hcpre_hf32_weight', 'source': 'kernels/aiv/hcpre_hf32_weight.cpp', 'core_type': 'aiv', 'signature': ['IN', 'OUT']}, {'func_id': 4, 'name': 'hcpre_input_panel', 'source': 'kernels/aiv/hcpre_input_panel.cpp', 'core_type': 'aiv', 'signature': ['IN', 'OUT']}, {'func_id': 5, 'name': 'hcpre_bf16_half_exact8_m64', 'source': 'kernels/aic/hcpre_bf16_half_exact8_m64.cpp', 'core_type': 'aic', 'signature': ['IN', 'IN', 'OUT']}, {'func_id': 6, 'name': 'hcpre_bf16_half_exact8', 'source': 'kernels/aic/hcpre_bf16_half_exact8.cpp', 'core_type': 'aic', 'signature': ['IN', 'IN', 'OUT']}, {'func_id': 7, 'name': 'hc_pre_linear_reduce', 'source': 'kernels/aiv/hc_pre_linear_reduce.cpp', 'core_type': 'aiv', 'signature': ['IN', 'OUT']}, {'func_id': 8, 'name': 'split_pre_post', 'source': 'kernels/aiv/split_pre_post.cpp', 'core_type': 'aiv', 'signature': ['IN', 'OUT', 'INOUT', 'OUT', 'IN', 'IN', 'IN']}, {'func_id': 9, 'name': 'comb_sinkhorn', 'source': 'kernels/aiv/comb_sinkhorn.cpp', 'core_type': 'aiv', 'signature': ['IN', 'IN', 'IN', 'IN', 'OUT', 'INOUT']}, {'func_id': 10, 'name': 'mix_x', 'source': 'kernels/aiv/mix_x.cpp', 'core_type': 'aiv', 'signature': ['IN', 'OUT', 'INOUT', 'IN']}]
ORCHESTRATION = {'source': 'orchestration/_hc_pre_test.cpp', 'function_name': 'aicpu_orchestration_entry', 'signature': ['IN', 'IN', 'IN', 'IN', 'OUT', 'OUT', 'OUT']}
RUNTIME_CONFIG = {'runtime': 'tensormap_and_ringbuffer', 'aicpu_thread_num': 0}
for _entry in [*KERNELS, ORCHESTRATION]:
    _entry['source'] = str(_ROOT_DIR / _entry['source'])
    _entry['signature'] = [getattr(_D, s) for s in _entry['signature']]
    if 'extra_include_dirs' in _entry:
        _entry['extra_include_dirs'] = [
            str(_ROOT_DIR / p) for p in _entry['extra_include_dirs']]
