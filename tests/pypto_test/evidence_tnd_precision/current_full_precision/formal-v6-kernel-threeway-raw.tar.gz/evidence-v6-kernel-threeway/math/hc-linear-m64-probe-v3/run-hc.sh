#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
source "$(dirname "${BASH_SOURCE[0]}")/env.sh"
label="${1:?result label required}"
tokens="${2:?tokens required}"
shift 2
[[ "$label" =~ ^[A-Za-z0-9_.-]+$ ]]
[[ "$tokens" == 6 || "$tokens" == 144 || "$tokens" == 240 ]]
# task-submit may append --device; TASK_DEVICE owns physical device selection.
scheduler_device=""
while (( $# )); do
  case "$1" in
    --device) scheduler_device="${2:?missing --device value}"; shift 2 ;;
    --device=*) scheduler_device="${1#--device=}"; shift ;;
    *) echo "Unexpected argument: $1" >&2; exit 2 ;;
  esac
done
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
out="$job/results/$label"
mkdir -p "$job/results"
mkdir "$out"
printf 'TASK_DEVICE=%s\nSCHEDULER_DEVICE=%s\nTOKENS=%s\n' "$TASK_DEVICE" "$scheduler_device" "$tokens" > "$out/device-selection.log"
ccache -s > "$out/ccache.log"
export ASCEND_CACHE_PATH="$out/ascend-cache" ASCEND_PROCESS_LOG_PATH="$out/ascend"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
export HC_PROBE_OUT="$out" HC_PROBE_TOKENS="$tokens"
# Submit with task timeout780s. This covers preflight + HC full/linear/square gate in750s.
timeout --signal=TERM --kill-after=15s 750s bash -c '
  set -e
  python "$job/preflight.py" > "$HC_PROBE_OUT/preflight.log" 2>&1
  python "$job/probe_hc.py" --out "$HC_PROBE_OUT/data" --tokens "$HC_PROBE_TOKENS" > "$HC_PROBE_OUT/run.log" 2>&1
'
