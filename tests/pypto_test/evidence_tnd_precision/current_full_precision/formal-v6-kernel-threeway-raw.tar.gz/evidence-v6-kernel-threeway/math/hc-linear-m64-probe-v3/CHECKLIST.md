# 清单

- [x] f2b独立数学字节保留。
- [ ] 实际V4基底/只删无效外层scalar路由/Gram AST及公共scalar函数不变。
- [ ] 完整HC两根和linear两根的真实GCC/全部CCEC。
- [ ] actual partials父级绑定、完整依赖/有效48行复核。
- [ ] 上传无设备预检。
- [ ] NPU T144→T240→T6（不自行提交）。
