#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void hcpre_hf32_weight_0(__gm__ float* v1, __gm__ bfloat16_t* v2, int32_t v3, int32_t v4) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v5 = 64;
  // pto: %c0_i64
  const int64_t v6 = 0;
  // pto: %c32768_i64
  const int64_t v7 = 32768;
  // pto: %c65536_i64
  const int64_t v8 = 65536;
  // pto: %c24_index
  const int64_t v9 = 24;
  // pto: %c16384_index
  const int64_t v10 = 16384;
  // pto: %c1_index
  const int64_t v11 = 1;
  // pto: %c32768_index
  const int64_t v12 = 32768;
  // pto: %c32_index
  const int64_t v13 = 32;
  // pto: %c256_index
  const int64_t v14 = 256;
  // pto: %c0_index
  const int64_t v15 = 0;
  // pto: %cst_10
  const float v16 = 0.0f;
  // pto: %c2048_i32
  const int32_t v17 = 2048;
  // pto: %cn4096_i32
  const int32_t v18 = -4096;
  // pto: %cn65536_i32
  const int32_t v19 = -65536;
  // pto: %c512_index
  const int64_t v20 = 512;
  // pto: %cst_15
  const bfloat16_t v21 = 0.0f;
  // pto: %c8_index
  const int64_t v22 = 8;
  // pto: %c16_index
  const int64_t v23 = 16;
  // pto: %hc_fn__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %hc_fn__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %hc_fn__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %hc_fn__ssa_v0_view
  int64_t v27 = v9 * v10;
  // pto: %hc_fn__ssa_v0_view
  int64_t v28 = v26 * v27;
  // pto: %hc_fn__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v29 = pto::Shape<1, 1, 1, -1, -1>(v24, v25, v26, v9, v10);
  // pto: %hc_fn__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v30 = pto::Stride<-1, -1, -1, -1, -1>(v25 * v28, v28, v27, v10, v11);
  // pto: %hc_fn__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v31 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v29, v30);
  // pto: %packed_weight_inline1497__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %packed_weight_inline1497__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %packed_weight_inline1497__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %packed_weight_inline1497__ssa_v0_view
  int64_t v35 = v12 * v13;
  // pto: %packed_weight_inline1497__ssa_v0_view
  int64_t v36 = v34 * v35;
  // pto: %packed_weight_inline1497__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v37 = pto::Shape<1, 1, 1, -1, -1>(v32, v33, v34, v12, v13);
  // pto: %packed_weight_inline1497__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v38 = pto::Stride<-1, -1, -1, -1, -1>(v33 * v36, v36, v35, v13, v11);
  // pto: %packed_weight_inline1497__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v39 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v37, v38);
  // pto: %block_inline1496__ssa_v0
  int64_t v40 = (int64_t) v3;
  // pto: %raw_inline1490__ssa_v0
  Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v41 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v9, v14);
  // pto: %raw_inline1490__ssa_v0
  uint64_t v42 = (uint64_t) v6;
  TASSIGN(v41, v42);
  // pto: %0
  int64_t v43 = (int64_t) ((uint64_t) v40 * (uint64_t) v14);
  // pto: %1
  int64_t v44 = v43 < v15 ? v15 : v43;
  // pto: %hc_fn__ssa_v0_pview
  __gm__ float* v45 = PTOAS__GLOBAL_TENSOR_DATA(v31);
  // pto: %hc_fn__ssa_v0_pview
  const int64_t v46 = 0;
  // pto: %hc_fn__ssa_v0_pview
  pto::Shape<1, 1, 1, 24, 256> v47 = pto::Shape<1, 1, 1, 24, 256>();
  // pto: %hc_fn__ssa_v0_pview
  pto::Stride<393216, 393216, 393216, 16384, 1> v48 = pto::Stride<393216, 393216, 393216, 16384, 1>();
  // pto: %hc_fn__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 24, 256>, pto::Stride<393216, 393216, 393216, 16384, 1>, pto::Layout::ND> v49 = GlobalTensor<float, pto::Shape<1, 1, 1, 24, 256>, pto::Stride<393216, 393216, 393216, 16384, 1>, pto::Layout::ND>(v45 + (v46 + v44), v47, v48);
  TLOAD(v41, v49);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %transpose_tmp
  Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v50 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v14);
  // pto: %transpose_tmp
  uint64_t v51 = (uint64_t) v7;
  TASSIGN(v50, v51);
  // pto: %transposed_inline1489__ssa_v0
  Tile<TileType::Vec, float, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v52 = Tile<TileType::Vec, float, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
  // pto: %transposed_inline1489__ssa_v0
  uint64_t v53 = (uint64_t) v8;
  TASSIGN(v52, v53);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  TTRANS(v52, v41, v50);
  set_flag(PIPE_V, PIPE_S, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
  for (int64_t v54 = v9; v54 < v13; v54 += v11) {
    for (int64_t v55 = v15; v55 < v14; v55 += v11) {
      // pto: %flat_offset_mul, %flat_offset
      ;
      int64_t v56 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v55 * (uint64_t) v13) + (uint64_t) v54);
      v52.SetValue(v56, v16);
    };
  }
  set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  v52.SetValidShape(v14, v13);
  // pto: %bits_inline1498__ssa_v0
  Tile<TileType::Vec, int32_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v57 = Tile<TileType::Vec, int32_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
  // pto: %bits_inline1498__ssa_v0
  uint64_t v58 = (uint64_t) v8;
  TASSIGN(v57, v58);
  // pto: %t__tmp_v147
  Tile<TileType::Vec, int32_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v59 = Tile<TileType::Vec, int32_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
  // pto: %t__tmp_v147
  uint64_t v60 = (uint64_t) v6;
  TASSIGN(v59, v60);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
  pipe_barrier(PIPE_V);
  TADDS(v59, v57, v17);
  // pto: %t__tmp_v148
  Tile<TileType::Vec, int32_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v61 = Tile<TileType::Vec, int32_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
  // pto: %t__tmp_v148
  uint64_t v62 = (uint64_t) v7;
  TASSIGN(v61, v62);
  TEXPANDS(v61, v18);
  // pto: %t__tmp_v149
  Tile<TileType::Vec, int32_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v63 = Tile<TileType::Vec, int32_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
  // pto: %t__tmp_v149
  uint64_t v64 = (uint64_t) v6;
  TASSIGN(v63, v64);
  pipe_barrier(PIPE_V);
  TAND(v63, v59, v61);
  // pto: %converted_inline1486__ssa_v0
  Tile<TileType::Vec, float, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v65 = Tile<TileType::Vec, float, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
  // pto: %converted_inline1486__ssa_v0
  uint64_t v66 = (uint64_t) v6;
  TASSIGN(v65, v66);
  // pto: %t__tmp_v150
  Tile<TileType::Vec, int32_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Vec, int32_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
  // pto: %t__tmp_v150
  uint64_t v68 = (uint64_t) v6;
  TASSIGN(v67, v68);
  // pto: %t__tmp_v151
  Tile<TileType::Vec, int32_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v69 = Tile<TileType::Vec, int32_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
  // pto: %t__tmp_v151
  uint64_t v70 = (uint64_t) v7;
  TASSIGN(v69, v70);
  pipe_barrier(PIPE_V);
  TEXPANDS(v69, v19);
  // pto: %hi_bits_inline1518__ssa_v0
  Tile<TileType::Vec, int32_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v71 = Tile<TileType::Vec, int32_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
  // pto: %hi_bits_inline1518__ssa_v0
  uint64_t v72 = (uint64_t) v7;
  TASSIGN(v71, v72);
  pipe_barrier(PIPE_V);
  TAND(v71, v67, v69);
  // pto: %hi_fp32_inline1494__ssa_v0
  Tile<TileType::Vec, float, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v73 = Tile<TileType::Vec, float, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
  // pto: %hi_fp32_inline1494__ssa_v0
  uint64_t v74 = (uint64_t) v7;
  TASSIGN(v73, v74);
  // pto: %lo_fp32_inline1519__ssa_v0
  Tile<TileType::Vec, float, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Vec, float, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
  // pto: %lo_fp32_inline1519__ssa_v0
  uint64_t v76 = (uint64_t) v6;
  TASSIGN(v75, v76);
  pipe_barrier(PIPE_V);
  TSUB(v75, v65, v73);
  // pto: %hi_bf16_inline1503__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v77 = Tile<TileType::Vec, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
  // pto: %hi_bf16_inline1503__ssa_v0
  uint64_t v78 = (uint64_t) v7;
  TASSIGN(v77, v78);
  pipe_barrier(PIPE_V);
  RoundMode v79 = RoundMode::CAST_ROUND;
  SaturationMode v80 = SaturationMode::ON;
  TCVT(v77, v73, v79, v80);
  // pto: %lo_bf16_inline1502__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v81 = Tile<TileType::Vec, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v13);
  // pto: %lo_bf16_inline1502__ssa_v0
  uint64_t v82 = (uint64_t) v8;
  TASSIGN(v81, v82);
  RoundMode v83 = RoundMode::CAST_ROUND;
  SaturationMode v84 = SaturationMode::ON;
  TCVT(v81, v75, v83, v84);
  // pto: %packed_block_inline1509__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 512, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v85 = Tile<TileType::Vec, bfloat16_t, 512, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v13);
  // pto: %packed_block_inline1509__ssa_v0
  uint64_t v86 = (uint64_t) v6;
  TASSIGN(v85, v86);
  pipe_barrier(PIPE_V);
  TEXPANDS(v85, v21);
  for (int64_t v87 = v15; v87 < v13; v87 += v11) {
    // pto: %high8_inline1506__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Vec, bfloat16_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v13);
    // pto: %high8_inline1506__ssa_v0
    ;
    uint64_t v89 = (uint64_t) v7;
    TASSIGN(v88, v89);
    // pto: %2, %slice_view
    ;
    int64_t v90 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v87 * (uint64_t) v22) * (uint64_t) v5);
    // pto: %slice_view
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 32, BLayout::RowMajor, 8, 32, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v91;
    // pto: %slice_view
    ;
    uint64_t v92 = (uint64_t) ((int64_t) (uint64_t) v90 + (uint64_t) v7);
    TASSIGN(v91, v92);
    // pto: %low8_inline1504__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Vec, bfloat16_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v13);
    // pto: %low8_inline1504__ssa_v0
    ;
    uint64_t v94 = (uint64_t) v8;
    TASSIGN(v93, v94);
    // pto: %4
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 32, BLayout::RowMajor, 8, 32, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v95;
    // pto: %4
    ;
    uint64_t v96 = (uint64_t) ((int64_t) (uint64_t) v90 + (uint64_t) v8);
    TASSIGN(v95, v96);
    // pto: %5
    ;
    int64_t v97 = (int64_t) ((uint64_t) v87 * (uint64_t) v23);
    // pto: %assemble_view
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 32, BLayout::RowMajor, 8, 32, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98;
    // pto: %assemble_view
    ;
    uint64_t v99 = (uint64_t) ((int64_t) (uint64_t) v97 * (uint64_t) v5);
    TASSIGN(v98, v99);
    pipe_barrier(PIPE_V);
    TMOV(v98, v91);
    // pto: %8
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 32, BLayout::RowMajor, 8, 32, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v100;
    // pto: %7, %8
    ;
    uint64_t v101 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v97 + (uint64_t) v22) * (uint64_t) v5);
    TASSIGN(v100, v101);
    pipe_barrier(PIPE_V);
    TMOV(v100, v95);
  }
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %9
  int64_t v102 = (int64_t) ((uint64_t) v40 * (uint64_t) v20);
  // pto: %10
  int64_t v103 = v102 < v15 ? v15 : v102;
  // pto: %packed_weight_inline1497__ssa_v0_pview
  __gm__ bfloat16_t* v104 = PTOAS__GLOBAL_TENSOR_DATA(v39);
  // pto: %packed_weight_inline1497__ssa_v0_pview
  const int64_t v105 = 0;
  // pto: %packed_weight_inline1497__ssa_v0_pview
  const int64_t v106 = 32;
  // pto: %packed_weight_inline1497__ssa_v0_pview
  pto::Shape<1, 1, 1, 512, 32> v107 = pto::Shape<1, 1, 1, 512, 32>();
  // pto: %packed_weight_inline1497__ssa_v0_pview
  pto::Stride<16384, 16384, 16384, 32, 1> v108 = pto::Stride<16384, 16384, 16384, 32, 1>();
  // pto: %packed_weight_inline1497__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 512, 32>, pto::Stride<16384, 16384, 16384, 32, 1>, pto::Layout::ND> v109 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 512, 32>, pto::Stride<16384, 16384, 16384, 32, 1>, pto::Layout::ND>(v104 + (v105 + v103 * v106), v107, v108);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v109, v85);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}