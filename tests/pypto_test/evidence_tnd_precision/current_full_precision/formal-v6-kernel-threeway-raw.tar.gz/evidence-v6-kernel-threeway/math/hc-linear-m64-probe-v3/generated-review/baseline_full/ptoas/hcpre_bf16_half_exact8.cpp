#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void hcpre_bf16_half_exact8(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ float* v3, int64_t v4, int64_t v5, int64_t v6, int32_t v7, int32_t v8) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v9 = 0;
  // pto: %c4096_i64
  const int64_t v10 = 4096;
  // pto: %c32768_index
  const int64_t v11 = 32768;
  // pto: %c1_index
  const int64_t v12 = 1;
  // pto: %c32_index
  const int64_t v13 = 32;
  // pto: %c16_index
  const int64_t v14 = 16;
  // pto: %c16384_index
  const int64_t v15 = 16384;
  // pto: %c768_index
  const int64_t v16 = 768;
  // pto: %c64_index
  const int64_t v17 = 64;
  // pto: %c0_index
  const int64_t v18 = 0;
  // pto: %c1536_index
  const int64_t v19 = 1536;
  // pto: %c128_index
  const int64_t v20 = 128;
  // pto: %c22_index
  const int64_t v21 = 22;
  // pto: %packed_flat_inline1512__ssa_v0_view
  const int64_t v22 = 1;
  // pto: %packed_flat_inline1512__ssa_v0_view
  const int64_t v23 = 1;
  // pto: %packed_flat_inline1512__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %packed_flat_inline1512__ssa_v0_view
  int64_t v25 = (int64_t) v5;
  // pto: %packed_flat_inline1512__ssa_v0_view
  int64_t v26 = v25 * v11;
  // pto: %packed_flat_inline1512__ssa_v0_view
  int64_t v27 = v24 * v26;
  // pto: %packed_flat_inline1512__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v28 = pto::Shape<1, 1, 1, -1, -1>(v22, v23, v24, v25, v11);
  // pto: %packed_flat_inline1512__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v29 = pto::Stride<-1, -1, -1, -1, -1>(v23 * v27, v27, v26, v11, v12);
  // pto: %packed_flat_inline1512__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v30 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v28, v29);
  // pto: %packed_weight_inline1497__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %packed_weight_inline1497__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %packed_weight_inline1497__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %packed_weight_inline1497__ssa_v0_view
  int64_t v34 = v11 * v13;
  // pto: %packed_weight_inline1497__ssa_v0_view
  int64_t v35 = v33 * v34;
  // pto: %packed_weight_inline1497__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v36 = pto::Shape<1, 1, 1, -1, -1>(v31, v32, v33, v11, v13);
  // pto: %packed_weight_inline1497__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v37 = pto::Stride<-1, -1, -1, -1, -1>(v32 * v35, v35, v34, v13, v12);
  // pto: %packed_weight_inline1497__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v38 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v36, v37);
  // pto: %20
  int64_t v39 = (int64_t) ((uint64_t) v6 * (uint64_t) v21);
  // pto: %mixes_partials_inline341_inline747__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %mixes_partials_inline341_inline747__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %mixes_partials_inline341_inline747__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %mixes_partials_inline341_inline747__ssa_v0_view
  int64_t v43 = v39 * v13;
  // pto: %mixes_partials_inline341_inline747__ssa_v0_view
  int64_t v44 = v42 * v43;
  // pto: %mixes_partials_inline341_inline747__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v45 = pto::Shape<1, 1, 1, -1, -1>(v40, v41, v42, v39, v13);
  // pto: %mixes_partials_inline341_inline747__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v41 * v44, v44, v43, v13, v12);
  // pto: %mixes_partials_inline341_inline747__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v47 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v45, v46);
  // pto: %unit_inline1479__ssa_v0
  int64_t v48 = (int64_t) v7;
  // pto: %1
  int64_t v49 = v5 / v14;
  // pto: %2
  int64_t v50 = v48 / v49;
  // pto: %4, %5
  int64_t v51 = (int64_t) ((uint64_t) (v48 % v49) * (uint64_t) v14);
  // pto: %7, %6
  int64_t v52 = (int64_t) ((uint64_t) v15 - (uint64_t) ((int64_t) (uint64_t) v50 * (uint64_t) v16));
  // pto: %8
  int64_t v53 = v52 < v16 ? v52 : v16;
  // pto: %9
  // pto: %accumulator_inline1491__tile
  Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v54 = Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v14, v13);
  // pto: %accumulator_inline1491__tile
  uint64_t v55 = (uint64_t) v9;
  TASSIGN(v54, v55);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t v56 = v18; v56 < (v53 / v17); v56 += v12) {
    // pto: %10, %12, %11
    ;
    int64_t v57 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v50 * (uint64_t) v19) + (uint64_t) ((int64_t) (uint64_t) v56 * (uint64_t) v20));
    // pto: %x16_inline1517__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v20);
    // pto: %x16_inline1517__tile
    ;
    uint64_t v59 = (uint64_t) v9;
    TASSIGN(v58, v59);
    // pto: %13
    ;
    int64_t v60 = v51 < v18 ? v18 : v51;
    // pto: %14
    ;
    int64_t v61 = v57 < v18 ? v18 : v57;
    // pto: %packed_flat_inline1512__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v62 = PTOAS__GLOBAL_TENSOR_DATA(v30);
    // pto: %packed_flat_inline1512__ssa_v0_pview
    ;
    const int64_t v63 = 0;
    // pto: %packed_flat_inline1512__ssa_v0_pview
    ;
    const int64_t v64 = 32768;
    // pto: %packed_flat_inline1512__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 16, 128> v65 = pto::Shape<1, 1, 1, 16, 128>();
    // pto: %packed_flat_inline1512__ssa_v0_pview
    ;
    pto::Stride<524288, 524288, 524288, 32768, 1> v66 = pto::Stride<524288, 524288, 524288, 32768, 1>();
    // pto: %packed_flat_inline1512__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND> v67 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND>(v62 + (v63 + v60 * v64 + v61), v65, v66);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v58, v67);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %w16_inline1495__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v68 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v20, v13);
    // pto: %w16_inline1495__tile
    ;
    uint64_t v69 = (uint64_t) v10;
    TASSIGN(v68, v69);
    // pto: %packed_weight_inline1497__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v70 = PTOAS__GLOBAL_TENSOR_DATA(v38);
    // pto: %packed_weight_inline1497__ssa_v0_pview
    ;
    const int64_t v71 = 0;
    // pto: %packed_weight_inline1497__ssa_v0_pview
    ;
    const int64_t v72 = 32;
    // pto: %packed_weight_inline1497__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 128, 32> v73 = pto::Shape<1, 1, 1, 128, 32>();
    // pto: %packed_weight_inline1497__ssa_v0_pview
    ;
    pto::Stride<4096, 4096, 4096, 32, 1> v74 = pto::Stride<4096, 4096, 4096, 32, 1>();
    // pto: %packed_weight_inline1497__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v75 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v70 + (v71 + v61 * v72), v73, v74);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v68, v75);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    // pto: %x16_inline1517__tile_Left
    ;
    Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v76 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v20);
    // pto: %x16_inline1517__tile_Left
    ;
    uint64_t v77 = (uint64_t) v9;
    TASSIGN(v76, v77);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    TMOV(v76, v58);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    // pto: %w16_inline1495__tile_Right
    ;
    Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v13);
    // pto: %w16_inline1495__tile_Right
    ;
    uint64_t v79 = (uint64_t) v9;
    TASSIGN(v78, v79);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    TMOV(v78, v68);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    // pto: %16
    ;
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    if (v56 == v18) {
      TMATMUL(v54, v76, v78);
    } else {
      TMATMUL_ACC(v54, v54, v76, v78);
    };
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  }
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  // pto: %17, %18
  int64_t v80 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v50 * (uint64_t) v5) + (uint64_t) v51);
  // pto: %19
  int64_t v81 = v80 < v18 ? v18 : v80;
  // pto: %mixes_partials_inline341_inline747__ssa_v0_pview
  __gm__ float* v82 = PTOAS__GLOBAL_TENSOR_DATA(v47);
  // pto: %mixes_partials_inline341_inline747__ssa_v0_pview
  const int64_t v83 = 0;
  // pto: %mixes_partials_inline341_inline747__ssa_v0_pview
  const int64_t v84 = 32;
  // pto: %mixes_partials_inline341_inline747__ssa_v0_pview
  pto::Shape<1, 1, 1, 16, 32> v85 = pto::Shape<1, 1, 1, 16, 32>();
  // pto: %mixes_partials_inline341_inline747__ssa_v0_pview
  pto::Stride<512, 512, 512, 32, 1> v86 = pto::Stride<512, 512, 512, 32, 1>();
  // pto: %mixes_partials_inline341_inline747__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v87 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v82 + (v83 + v81 * v84), v85, v86);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE(v87, v54);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}