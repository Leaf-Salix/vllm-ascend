#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void hcpre_hf32_weight(__gm__ float* v1, __gm__ float* v2, int32_t v3, int32_t v4) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v5 = 0;
  // pto: %c4096_i64
  const int64_t v6 = 4096;
  // pto: %c8192_i64
  const int64_t v7 = 8192;
  // pto: %c24_index
  const int64_t v8 = 24;
  // pto: %c16384_index
  const int64_t v9 = 16384;
  // pto: %c1_index
  const int64_t v10 = 1;
  // pto: %c32_index
  const int64_t v11 = 32;
  // pto: %c0_index
  const int64_t v12 = 0;
  // pto: %c2048_i32
  const int32_t v13 = 2048;
  // pto: %cn4096_i32
  const int32_t v14 = -4096;
  // pto: %cst_10
  const float v15 = 0.0f;
  // pto: %hc_fn__ssa_v0_view
  const int64_t v16 = 1;
  // pto: %hc_fn__ssa_v0_view
  const int64_t v17 = 1;
  // pto: %hc_fn__ssa_v0_view
  const int64_t v18 = 1;
  // pto: %hc_fn__ssa_v0_view
  int64_t v19 = v8 * v9;
  // pto: %hc_fn__ssa_v0_view
  int64_t v20 = v18 * v19;
  // pto: %hc_fn__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v21 = pto::Shape<1, 1, 1, -1, -1>(v16, v17, v18, v8, v9);
  // pto: %hc_fn__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v22 = pto::Stride<-1, -1, -1, -1, -1>(v17 * v20, v20, v19, v9, v10);
  // pto: %hc_fn__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v23 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v21, v22);
  // pto: %rounded_weight_inline1473__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %rounded_weight_inline1473__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %rounded_weight_inline1473__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %rounded_weight_inline1473__ssa_v0_view
  int64_t v27 = v9 * v11;
  // pto: %rounded_weight_inline1473__ssa_v0_view
  int64_t v28 = v26 * v27;
  // pto: %rounded_weight_inline1473__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v29 = pto::Shape<1, 1, 1, -1, -1>(v24, v25, v26, v9, v11);
  // pto: %rounded_weight_inline1473__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v30 = pto::Stride<-1, -1, -1, -1, -1>(v25 * v28, v28, v27, v11, v10);
  // pto: %rounded_weight_inline1473__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v31 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v29, v30);
  // pto: %raw_inline1366__ssa_v0
  Tile<TileType::Vec, float, 32, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v32 = Tile<TileType::Vec, float, 32, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v8, v11);
  // pto: %raw_inline1366__ssa_v0
  uint64_t v33 = (uint64_t) v5;
  TASSIGN(v32, v33);
  // pto: %block_inline1369__ssa_v0, %0
  int64_t v34 = (int64_t) ((uint64_t) ((int64_t) v3) * (uint64_t) v11);
  // pto: %1
  int64_t v35 = v34 < v12 ? v12 : v34;
  // pto: %hc_fn__ssa_v0_pview
  __gm__ float* v36 = PTOAS__GLOBAL_TENSOR_DATA(v23);
  // pto: %hc_fn__ssa_v0_pview
  const int64_t v37 = 0;
  // pto: %hc_fn__ssa_v0_pview
  pto::Shape<1, 1, 1, 24, 32> v38 = pto::Shape<1, 1, 1, 24, 32>();
  // pto: %hc_fn__ssa_v0_pview
  pto::Stride<393216, 393216, 393216, 16384, 1> v39 = pto::Stride<393216, 393216, 393216, 16384, 1>();
  // pto: %hc_fn__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 24, 32>, pto::Stride<393216, 393216, 393216, 16384, 1>, pto::Layout::ND> v40 = GlobalTensor<float, pto::Shape<1, 1, 1, 24, 32>, pto::Stride<393216, 393216, 393216, 16384, 1>, pto::Layout::ND>(v36 + (v37 + v35), v38, v39);
  TLOAD(v32, v40);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %transpose_tmp
  Tile<TileType::Vec, float, 32, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v41 = Tile<TileType::Vec, float, 32, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v11);
  // pto: %transpose_tmp
  uint64_t v42 = (uint64_t) v6;
  TASSIGN(v41, v42);
  // pto: %transposed_inline1374__ssa_v0
  Tile<TileType::Vec, float, 32, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v43 = Tile<TileType::Vec, float, 32, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v11);
  // pto: %transposed_inline1374__ssa_v0
  uint64_t v44 = (uint64_t) v7;
  TASSIGN(v43, v44);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  TTRANS(v43, v32, v41);
  // pto: %bits_inline1350__ssa_v0
  Tile<TileType::Vec, int32_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v45 = Tile<TileType::Vec, int32_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v11);
  // pto: %bits_inline1350__ssa_v0
  uint64_t v46 = (uint64_t) v7;
  TASSIGN(v45, v46);
  // pto: %t__tmp_v6
  Tile<TileType::Vec, int32_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v47 = Tile<TileType::Vec, int32_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v11);
  // pto: %t__tmp_v6
  uint64_t v48 = (uint64_t) v5;
  TASSIGN(v47, v48);
  pipe_barrier(PIPE_V);
  TADDS(v47, v45, v13);
  // pto: %t__tmp_v7
  Tile<TileType::Vec, int32_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v49 = Tile<TileType::Vec, int32_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v11);
  // pto: %t__tmp_v7
  uint64_t v50 = (uint64_t) v6;
  TASSIGN(v49, v50);
  TEXPANDS(v49, v14);
  // pto: %t__tmp_v8
  Tile<TileType::Vec, int32_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v51 = Tile<TileType::Vec, int32_t, 32, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v11);
  // pto: %t__tmp_v8
  uint64_t v52 = (uint64_t) v5;
  TASSIGN(v51, v52);
  pipe_barrier(PIPE_V);
  TAND(v51, v47, v49);
  set_flag(PIPE_V, PIPE_S, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %converted_inline1353__ssa_v0
  Tile<TileType::Vec, float, 32, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v53 = Tile<TileType::Vec, float, 32, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v11, v11);
  // pto: %converted_inline1353__ssa_v0
  uint64_t v54 = (uint64_t) v5;
  TASSIGN(v53, v54);
  wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
  for (int64_t v55 = v8; v55 < v11; v55 += v10) {
    for (int64_t v56 = v12; v56 < v11; v56 += v10) {
      // pto: %flat_offset_mul, %flat_offset
      ;
      int64_t v57 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v56 * (uint64_t) v11) + (uint64_t) v55);
      v53.SetValue(v57, v15);
    };
  }
  set_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
  v53.SetValidShape(v11, v11);
  // pto: %rounded_weight_inline1473__ssa_v0_pview
  __gm__ float* v58 = PTOAS__GLOBAL_TENSOR_DATA(v31);
  // pto: %rounded_weight_inline1473__ssa_v0_pview
  const int64_t v59 = 0;
  // pto: %rounded_weight_inline1473__ssa_v0_pview
  const int64_t v60 = 32;
  // pto: %rounded_weight_inline1473__ssa_v0_pview
  pto::Shape<1, 1, 1, 32, 32> v61 = pto::Shape<1, 1, 1, 32, 32>();
  // pto: %rounded_weight_inline1473__ssa_v0_pview
  pto::Stride<1024, 1024, 1024, 32, 1> v62 = pto::Stride<1024, 1024, 1024, 32, 1>();
  // pto: %rounded_weight_inline1473__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 32, 32>, pto::Stride<1024, 1024, 1024, 32, 1>, pto::Layout::ND> v63 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 32>, pto::Stride<1024, 1024, 1024, 32, 1>, pto::Layout::ND>(v58 + (v59 + v35 * v60), v61, v62);
  wait_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v63, v53);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}