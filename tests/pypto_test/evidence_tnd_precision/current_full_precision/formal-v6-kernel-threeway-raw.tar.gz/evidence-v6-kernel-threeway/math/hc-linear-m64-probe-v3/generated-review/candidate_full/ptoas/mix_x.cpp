#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void mix_x(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, __gm__ float* v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int32_t v9, int32_t v10) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v11 = 12544;
  const int64_t v12 = 8448;
  const int64_t v13 = 4352;
  // pto: %c41216_i64
  const int64_t v14 = 41216;
  // pto: %c49408_i64
  const int64_t v15 = 49408;
  // pto: %c40960_i64
  const int64_t v16 = 40960;
  // pto: %c40992_i64
  const int64_t v17 = 40992;
  // pto: %c41024_i64
  const int64_t v18 = 41024;
  // pto: %c41056_i64
  const int64_t v19 = 41056;
  // pto: %c57600_i64
  const int64_t v20 = 57600;
  // pto: %c0_i64
  const int64_t v21 = 0;
  // pto: %c8192_i64
  const int64_t v22 = 8192;
  // pto: %c16384_i64
  const int64_t v23 = 16384;
  // pto: %c24576_i64
  const int64_t v24 = 24576;
  // pto: %c32768_i64
  const int64_t v25 = 32768;
  // pto: %c8_index
  const int64_t v26 = 8;
  // pto: %c1_index
  const int64_t v27 = 1;
  // pto: %c4096_index
  const int64_t v28 = 4096;
  // pto: %c16384_index
  const int64_t v29 = 16384;
  // pto: %c0_index
  const int64_t v30 = 0;
  // pto: %c2_index
  const int64_t v31 = 2;
  // pto: %c16_index
  const int64_t v32 = 16;
  // pto: %c256_index
  const int64_t v33 = 256;
  // pto: %c8192_index
  const int64_t v34 = 8192;
  // pto: %c12288_index
  const int64_t v35 = 12288;
  // pto: %pre_val_store_inline1701__rv_v2_view
  const int64_t v36 = 1;
  // pto: %pre_val_store_inline1701__rv_v2_view
  const int64_t v37 = 1;
  // pto: %pre_val_store_inline1701__rv_v2_view
  const int64_t v38 = 1;
  // pto: %pre_val_store_inline1701__rv_v2_view
  int64_t v39 = (int64_t) v6;
  // pto: %pre_val_store_inline1701__rv_v2_view
  int64_t v40 = v39 * v26;
  // pto: %pre_val_store_inline1701__rv_v2_view
  int64_t v41 = v38 * v40;
  // pto: %pre_val_store_inline1701__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v42 = pto::Shape<1, 1, 1, -1, -1>(v36, v37, v38, v39, v26);
  // pto: %pre_val_store_inline1701__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v43 = pto::Stride<-1, -1, -1, -1, -1>(v37 * v41, v41, v40, v26, v27);
  // pto: %pre_val_store_inline1701__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v44 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v42, v43);
  // pto: %x_mixed__ssa_v0_view
  const int64_t v45 = 1;
  // pto: %x_mixed__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %x_mixed__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %x_mixed__ssa_v0_view
  int64_t v48 = (int64_t) v7;
  // pto: %x_mixed__ssa_v0_view
  int64_t v49 = v48 * v28;
  // pto: %x_mixed__ssa_v0_view
  int64_t v50 = v47 * v49;
  // pto: %x_mixed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v51 = pto::Shape<1, 1, 1, -1, -1>(v45, v46, v47, v48, v28);
  // pto: %x_mixed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v52 = pto::Stride<-1, -1, -1, -1, -1>(v46 * v50, v50, v49, v28, v27);
  // pto: %x_mixed__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v53 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v51, v52);
  // pto: %x_mixed_tail_store_inline1704__ssa_v0_view
  const int64_t v54 = 1;
  // pto: %x_mixed_tail_store_inline1704__ssa_v0_view
  const int64_t v55 = 1;
  // pto: %x_mixed_tail_store_inline1704__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %x_mixed_tail_store_inline1704__ssa_v0_view
  int64_t v57 = v26 * v28;
  // pto: %x_mixed_tail_store_inline1704__ssa_v0_view
  int64_t v58 = v56 * v57;
  // pto: %x_mixed_tail_store_inline1704__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v59 = pto::Shape<1, 1, 1, -1, -1>(v54, v55, v56, v26, v28);
  // pto: %x_mixed_tail_store_inline1704__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v60 = pto::Stride<-1, -1, -1, -1, -1>(v55 * v58, v58, v57, v28, v27);
  // pto: %x_mixed_tail_store_inline1704__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v61 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v59, v60);
  // pto: %x_flat_inline1702__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %x_flat_inline1702__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %x_flat_inline1702__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %x_flat_inline1702__ssa_v0_view
  int64_t v65 = (int64_t) v8;
  // pto: %x_flat_inline1702__ssa_v0_view
  int64_t v66 = v65 * v29;
  // pto: %x_flat_inline1702__ssa_v0_view
  int64_t v67 = v64 * v66;
  // pto: %x_flat_inline1702__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v68 = pto::Shape<1, 1, 1, -1, -1>(v62, v63, v64, v65, v29);
  // pto: %x_flat_inline1702__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v69 = pto::Stride<-1, -1, -1, -1, -1>(v63 * v67, v67, v66, v29, v27);
  // pto: %x_flat_inline1702__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v70 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v68, v69);
  // pto: %blk_inline1708__ssa_v0, %19
  int64_t v71 = (int64_t) ((uint64_t) ((int64_t) v9) * (uint64_t) v26);
  // pto: %20
  int64_t v72 = (int64_t) ((uint64_t) v8 - (uint64_t) v71);
  // pto: %21
  int64_t v73 = v72 < v26 ? v72 : v26;
  // pto: %t__tile
  Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v74 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v26);
  // pto: %t__tile
  uint64_t v75 = (uint64_t) v14;
  TASSIGN(v74, v75);
  // pto: %22
  int64_t v76 = v71 < v30 ? v30 : v71;
  // pto: %pre_val_store_inline1701__rv_v2_pview
  __gm__ float* v77 = PTOAS__GLOBAL_TENSOR_DATA(v44);
  // pto: %pre_val_store_inline1701__rv_v2_pview
  const int64_t v78 = 0;
  // pto: %pre_val_store_inline1701__rv_v2_pview
  const int64_t v79 = 8;
  // pto: %pre_val_store_inline1701__rv_v2_pview
  pto::Shape<1, 1, 1, 8, 8> v80 = pto::Shape<1, 1, 1, 8, 8>();
  // pto: %pre_val_store_inline1701__rv_v2_pview
  pto::Stride<64, 64, 64, 8, 1> v81 = pto::Stride<64, 64, 64, 8, 1>();
  // pto: %pre_val_store_inline1701__rv_v2_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<64, 64, 64, 8, 1>, pto::Layout::ND> v82 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<64, 64, 64, 8, 1>, pto::Layout::ND>(v77 + (v78 + v76 * v79), v80, v81);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  TLOAD(v74, v82);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %transpose_tmp
  Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v83 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v26);
  // pto: %transpose_tmp
  uint64_t v84 = (uint64_t) v15;
  TASSIGN(v83, v84);
  // pto: %pre_tile_t_inline1711__tile
  Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v85 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v26);
  // pto: %pre_tile_t_inline1711__tile
  uint64_t v86 = (uint64_t) v16;
  TASSIGN(v85, v86);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  TTRANS(v85, v74, v83);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %0
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v26);
  // pto: %0
  uint64_t v88 = (uint64_t) v16;
  TASSIGN(v87, v88);
  // pto: %pre0_inline1716__tile
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v89 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v27);
  // pto: %pre0_inline1716__tile
  uint64_t v90 = (uint64_t) v16;
  TASSIGN(v89, v90);
  // pto: %1
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v91 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v26);
  // pto: %1
  uint64_t v92 = (uint64_t) v17;
  TASSIGN(v91, v92);
  // pto: %pre1_inline1714__tile
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v27);
  // pto: %pre1_inline1714__tile
  uint64_t v94 = (uint64_t) v17;
  TASSIGN(v93, v94);
  // pto: %2
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v26);
  // pto: %2
  uint64_t v96 = (uint64_t) v18;
  TASSIGN(v95, v96);
  // pto: %pre2_inline1697__tile
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v27);
  // pto: %pre2_inline1697__tile
  uint64_t v98 = (uint64_t) v18;
  TASSIGN(v97, v98);
  // pto: %3
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v27, v26);
  // pto: %3
  uint64_t v100 = (uint64_t) v19;
  TASSIGN(v99, v100);
  // pto: %pre3_inline1696__tile
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v27);
  // pto: %pre3_inline1696__tile
  uint64_t v102 = (uint64_t) v19;
  TASSIGN(v101, v102);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v103 = v30; v103 < v32; v103 += v31) {
    // pto: %26
    ;
    int64_t v104 = (int64_t) ((uint64_t) v103 * (uint64_t) v33);
    // pto: %28
    ;
    int64_t v105 = (int64_t) ((uint64_t) v104 + (uint64_t) v33);
    // pto: %x0_inline1695__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %x0_inline1695__tile
    ;
    uint64_t v107 = (uint64_t) v14;
    TASSIGN(v106, v107);
    // pto: %30
    ;
    int64_t v108 = v104 < v30 ? v30 : v104;
    // pto: %x_flat_inline1702__ssa_v0_pview
    ;
    const int64_t v109 = 0;
    // pto: %x_flat_inline1702__ssa_v0_pview
    ;
    __gm__ float* v110 = PTOAS__GLOBAL_TENSOR_DATA(v70);
    // pto: %x_flat_inline1702__ssa_v0_pview
    ;
    const int64_t v111 = 1;
    // pto: %x_flat_inline1702__ssa_v0_pview
    ;
    const int64_t v112 = 1;
    // pto: %x_flat_inline1702__ssa_v0_pview
    ;
    const int64_t v113 = 1;
    // pto: %x_flat_inline1702__ssa_v0_pview
    ;
    int64_t v114 = v73 * v29;
    // pto: %x_flat_inline1702__ssa_v0_pview
    ;
    int64_t v115 = v113 * v114;
    // pto: %x_flat_inline1702__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 256> v116 = pto::Shape<1, 1, 1, -1, 256>(v111, v112, v113, v73, v33);
    // pto: %x_flat_inline1702__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v117 = pto::Stride<-1, -1, -1, -1, -1>(v112 * v115, v115, v114, v29, v27);
    // pto: %x_flat_inline1702__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v118 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v110 + (v109 + v76 * v29 + v108 * v27), v116, v117);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    TLOAD(v106, v118);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %x1_inline1691__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v119 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %x1_inline1691__tile
    ;
    uint64_t v120 = (uint64_t) v15;
    TASSIGN(v119, v120);
    // pto: %32
    ;
    int64_t v121 = (int64_t) ((uint64_t) v104 + (uint64_t) v28);
    // pto: %33
    ;
    int64_t v122 = v121 < v30 ? v30 : v121;
    // pto: %34
    ;
    const int64_t v123 = 0;
    // pto: %34
    ;
    __gm__ float* v124 = PTOAS__GLOBAL_TENSOR_DATA(v70);
    // pto: %34
    ;
    const int64_t v125 = 1;
    // pto: %34
    ;
    const int64_t v126 = 1;
    // pto: %34
    ;
    const int64_t v127 = 1;
    // pto: %34
    ;
    int64_t v128 = v73 * v29;
    // pto: %34
    ;
    int64_t v129 = v127 * v128;
    // pto: %34
    ;
    pto::Shape<1, 1, 1, -1, 256> v130 = pto::Shape<1, 1, 1, -1, 256>(v125, v126, v127, v73, v33);
    // pto: %34
    ;
    pto::Stride<-1, -1, -1, -1, -1> v131 = pto::Stride<-1, -1, -1, -1, -1>(v126 * v129, v129, v128, v29, v27);
    // pto: %34
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v132 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v124 + (v123 + v76 * v29 + v122 * v27), v130, v131);
    TLOAD(v119, v132);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %x2_inline1698__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %x2_inline1698__tile
    ;
    uint64_t v134 = (uint64_t) v20;
    TASSIGN(v133, v134);
    // pto: %36
    ;
    int64_t v135 = (int64_t) ((uint64_t) v104 + (uint64_t) v34);
    // pto: %37
    ;
    int64_t v136 = v135 < v30 ? v30 : v135;
    // pto: %38
    ;
    const int64_t v137 = 0;
    // pto: %38
    ;
    __gm__ float* v138 = PTOAS__GLOBAL_TENSOR_DATA(v70);
    // pto: %38
    ;
    const int64_t v139 = 1;
    // pto: %38
    ;
    const int64_t v140 = 1;
    // pto: %38
    ;
    const int64_t v141 = 1;
    // pto: %38
    ;
    int64_t v142 = v73 * v29;
    // pto: %38
    ;
    int64_t v143 = v141 * v142;
    // pto: %38
    ;
    pto::Shape<1, 1, 1, -1, 256> v144 = pto::Shape<1, 1, 1, -1, 256>(v139, v140, v141, v73, v33);
    // pto: %38
    ;
    pto::Stride<-1, -1, -1, -1, -1> v145 = pto::Stride<-1, -1, -1, -1, -1>(v140 * v143, v143, v142, v29, v27);
    // pto: %38
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v146 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v138 + (v137 + v76 * v29 + v136 * v27), v144, v145);
    TLOAD(v133, v146);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    // pto: %x3_inline1715__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %x3_inline1715__tile
    ;
    uint64_t v148 = (uint64_t) v21;
    TASSIGN(v147, v148);
    // pto: %40
    ;
    int64_t v149 = (int64_t) ((uint64_t) v104 + (uint64_t) v35);
    // pto: %41
    ;
    int64_t v150 = v149 < v30 ? v30 : v149;
    // pto: %42
    ;
    const int64_t v151 = 0;
    // pto: %42
    ;
    __gm__ float* v152 = PTOAS__GLOBAL_TENSOR_DATA(v70);
    // pto: %42
    ;
    const int64_t v153 = 1;
    // pto: %42
    ;
    const int64_t v154 = 1;
    // pto: %42
    ;
    const int64_t v155 = 1;
    // pto: %42
    ;
    int64_t v156 = v73 * v29;
    // pto: %42
    ;
    int64_t v157 = v155 * v156;
    // pto: %42
    ;
    pto::Shape<1, 1, 1, -1, 256> v158 = pto::Shape<1, 1, 1, -1, 256>(v153, v154, v155, v73, v33);
    // pto: %42
    ;
    pto::Stride<-1, -1, -1, -1, -1> v159 = pto::Stride<-1, -1, -1, -1, -1>(v154 * v157, v157, v156, v29, v27);
    // pto: %42
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v160 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v152 + (v151 + v76 * v29 + v150 * v27), v158, v159);
    TLOAD(v147, v160);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    // pto: %4
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %4
    ;
    uint64_t v162 = (uint64_t) v22;
    TASSIGN(v161, v162);
    // pto: %44
    ;
    int64_t v163 = v105 < v30 ? v30 : v105;
    // pto: %45
    ;
    const int64_t v164 = 0;
    // pto: %45
    ;
    __gm__ float* v165 = PTOAS__GLOBAL_TENSOR_DATA(v70);
    // pto: %45
    ;
    const int64_t v166 = 1;
    // pto: %45
    ;
    const int64_t v167 = 1;
    // pto: %45
    ;
    const int64_t v168 = 1;
    // pto: %45
    ;
    int64_t v169 = v73 * v29;
    // pto: %45
    ;
    int64_t v170 = v168 * v169;
    // pto: %45
    ;
    pto::Shape<1, 1, 1, -1, 256> v171 = pto::Shape<1, 1, 1, -1, 256>(v166, v167, v168, v73, v33);
    // pto: %45
    ;
    pto::Stride<-1, -1, -1, -1, -1> v172 = pto::Stride<-1, -1, -1, -1, -1>(v167 * v170, v170, v169, v29, v27);
    // pto: %45
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v173 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v165 + (v164 + v76 * v29 + v163 * v27), v171, v172);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    TLOAD(v161, v173);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    // pto: %5
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %5
    ;
    uint64_t v175 = (uint64_t) v23;
    TASSIGN(v174, v175);
    int64_t v176 = (int64_t) ((uint64_t) v104 + (uint64_t) v13);
    // pto: %48
    ;
    int64_t v177 = v176 < v30 ? v30 : v176;
    // pto: %49
    ;
    const int64_t v178 = 0;
    // pto: %49
    ;
    __gm__ float* v179 = PTOAS__GLOBAL_TENSOR_DATA(v70);
    // pto: %49
    ;
    const int64_t v180 = 1;
    // pto: %49
    ;
    const int64_t v181 = 1;
    // pto: %49
    ;
    const int64_t v182 = 1;
    // pto: %49
    ;
    int64_t v183 = v73 * v29;
    // pto: %49
    ;
    int64_t v184 = v182 * v183;
    // pto: %49
    ;
    pto::Shape<1, 1, 1, -1, 256> v185 = pto::Shape<1, 1, 1, -1, 256>(v180, v181, v182, v73, v33);
    // pto: %49
    ;
    pto::Stride<-1, -1, -1, -1, -1> v186 = pto::Stride<-1, -1, -1, -1, -1>(v181 * v184, v184, v183, v29, v27);
    // pto: %49
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v187 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v179 + (v178 + v76 * v29 + v177 * v27), v185, v186);
    TLOAD(v174, v187);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    // pto: %6
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v188 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %6
    ;
    uint64_t v189 = (uint64_t) v24;
    TASSIGN(v188, v189);
    int64_t v190 = (int64_t) ((uint64_t) v104 + (uint64_t) v12);
    // pto: %52
    ;
    int64_t v191 = v190 < v30 ? v30 : v190;
    // pto: %53
    ;
    const int64_t v192 = 0;
    // pto: %53
    ;
    __gm__ float* v193 = PTOAS__GLOBAL_TENSOR_DATA(v70);
    // pto: %53
    ;
    const int64_t v194 = 1;
    // pto: %53
    ;
    const int64_t v195 = 1;
    // pto: %53
    ;
    const int64_t v196 = 1;
    // pto: %53
    ;
    int64_t v197 = v73 * v29;
    // pto: %53
    ;
    int64_t v198 = v196 * v197;
    // pto: %53
    ;
    pto::Shape<1, 1, 1, -1, 256> v199 = pto::Shape<1, 1, 1, -1, 256>(v194, v195, v196, v73, v33);
    // pto: %53
    ;
    pto::Stride<-1, -1, -1, -1, -1> v200 = pto::Stride<-1, -1, -1, -1, -1>(v195 * v198, v198, v197, v29, v27);
    // pto: %53
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v201 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v193 + (v192 + v76 * v29 + v191 * v27), v199, v200);
    TLOAD(v188, v201);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    // pto: %7
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v202 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %7
    ;
    uint64_t v203 = (uint64_t) v25;
    TASSIGN(v202, v203);
    int64_t v204 = (int64_t) ((uint64_t) v104 + (uint64_t) v11);
    // pto: %56
    ;
    int64_t v205 = v204 < v30 ? v30 : v204;
    // pto: %57
    ;
    const int64_t v206 = 0;
    // pto: %57
    ;
    __gm__ float* v207 = PTOAS__GLOBAL_TENSOR_DATA(v70);
    // pto: %57
    ;
    const int64_t v208 = 1;
    // pto: %57
    ;
    const int64_t v209 = 1;
    // pto: %57
    ;
    const int64_t v210 = 1;
    // pto: %57
    ;
    int64_t v211 = v73 * v29;
    // pto: %57
    ;
    int64_t v212 = v210 * v211;
    // pto: %57
    ;
    pto::Shape<1, 1, 1, -1, 256> v213 = pto::Shape<1, 1, 1, -1, 256>(v208, v209, v210, v73, v33);
    // pto: %57
    ;
    pto::Stride<-1, -1, -1, -1, -1> v214 = pto::Stride<-1, -1, -1, -1, -1>(v209 * v212, v212, v211, v29, v27);
    // pto: %57
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v215 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v207 + (v206 + v76 * v29 + v205 * v27), v213, v214);
    TLOAD(v202, v215);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %y0_inline1712__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %y0_inline1712__tile
    ;
    uint64_t v217 = (uint64_t) v14;
    TASSIGN(v216, v217);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TROWEXPANDMUL(v216, v106, v89);
    // pto: %y1_inline1692__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %y1_inline1692__tile
    ;
    uint64_t v219 = (uint64_t) v15;
    TASSIGN(v218, v219);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    TROWEXPANDMUL(v218, v119, v93);
    // pto: %y2_inline1690__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %y2_inline1690__tile
    ;
    uint64_t v221 = (uint64_t) v20;
    TASSIGN(v220, v221);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
    TROWEXPANDMUL(v220, v133, v97);
    // pto: %y3_inline1703__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %y3_inline1703__tile
    ;
    uint64_t v223 = (uint64_t) v21;
    TASSIGN(v222, v223);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    TROWEXPANDMUL(v222, v147, v101);
    // pto: %8
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %8
    ;
    uint64_t v225 = (uint64_t) v14;
    TASSIGN(v224, v225);
    pipe_barrier(PIPE_V);
    TADD(v224, v216, v218);
    // pto: %9
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v226 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %9
    ;
    uint64_t v227 = (uint64_t) v14;
    TASSIGN(v226, v227);
    pipe_barrier(PIPE_V);
    TADD(v226, v224, v220);
    // pto: %y_tile_inline1707__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v228 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %y_tile_inline1707__tile
    ;
    uint64_t v229 = (uint64_t) v14;
    TASSIGN(v228, v229);
    pipe_barrier(PIPE_V);
    TADD(v228, v226, v222);
    // pto: %y_bf16_inline1694__tile
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v230 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %y_bf16_inline1694__tile
    ;
    uint64_t v231 = (uint64_t) v14;
    TASSIGN(v230, v231);
    pipe_barrier(PIPE_V);
    RoundMode v232 = RoundMode::CAST_RINT;
    SaturationMode v233 = SaturationMode::ON;
    TCVT(v230, v228, v232, v233);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %58
    ;
    bool v234 = v73 == v26;
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    if (v234) {
      // pto: %x_mixed__iter_v1_pview
      ;
      const int64_t v235 = 0;
      // pto: %x_mixed__iter_v1_pview
      ;
      __gm__ bfloat16_t* v236 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %x_mixed__iter_v1_pview
      ;
      const int64_t v237 = 1;
      // pto: %x_mixed__iter_v1_pview
      ;
      const int64_t v238 = 1;
      // pto: %x_mixed__iter_v1_pview
      ;
      const int64_t v239 = 1;
      // pto: %x_mixed__iter_v1_pview
      ;
      int64_t v240 = v73 * v28;
      // pto: %x_mixed__iter_v1_pview
      ;
      int64_t v241 = v239 * v240;
      // pto: %x_mixed__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, -1, 256> v242 = pto::Shape<1, 1, 1, -1, 256>(v237, v238, v239, v73, v33);
      // pto: %x_mixed__iter_v1_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v243 = pto::Stride<-1, -1, -1, -1, -1>(v238 * v241, v241, v240, v28, v27);
      // pto: %x_mixed__iter_v1_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v244 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v236 + (v235 + v76 * v28 + v108 * v27), v242, v243);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v244, v230);
    } else {
      // pto: %x_mixed_tail_store_inline1704__iter_v1_pview
      ;
      const int64_t v245 = 0;
      // pto: %x_mixed_tail_store_inline1704__iter_v1_pview
      ;
      __gm__ bfloat16_t* v246 = PTOAS__GLOBAL_TENSOR_DATA(v61);
      // pto: %x_mixed_tail_store_inline1704__iter_v1_pview
      ;
      const int64_t v247 = 1;
      // pto: %x_mixed_tail_store_inline1704__iter_v1_pview
      ;
      const int64_t v248 = 1;
      // pto: %x_mixed_tail_store_inline1704__iter_v1_pview
      ;
      const int64_t v249 = 1;
      // pto: %x_mixed_tail_store_inline1704__iter_v1_pview
      ;
      int64_t v250 = v73 * v28;
      // pto: %x_mixed_tail_store_inline1704__iter_v1_pview
      ;
      int64_t v251 = v249 * v250;
      // pto: %x_mixed_tail_store_inline1704__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, -1, 256> v252 = pto::Shape<1, 1, 1, -1, 256>(v247, v248, v249, v73, v33);
      // pto: %x_mixed_tail_store_inline1704__iter_v1_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v253 = pto::Stride<-1, -1, -1, -1, -1>(v248 * v251, v251, v250, v28, v27);
      // pto: %x_mixed_tail_store_inline1704__iter_v1_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v254 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v246 + (v245 + v30 * v28 + v108 * v27), v252, v253);
      TSTORE(v254, v230);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      // pto: %y_out_inline1689__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
      // pto: %y_out_inline1689__ssa_v0
      ;
      uint64_t v256 = (uint64_t) v14;
      TASSIGN(v255, v256);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      TLOAD(v255, v254);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
      // pto: %65
      ;
      const int64_t v257 = 0;
      // pto: %65
      ;
      __gm__ bfloat16_t* v258 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %65
      ;
      const int64_t v259 = 1;
      // pto: %65
      ;
      const int64_t v260 = 1;
      // pto: %65
      ;
      const int64_t v261 = 1;
      // pto: %65
      ;
      int64_t v262 = v73 * v28;
      // pto: %65
      ;
      int64_t v263 = v261 * v262;
      // pto: %65
      ;
      pto::Shape<1, 1, 1, -1, 256> v264 = pto::Shape<1, 1, 1, -1, 256>(v259, v260, v261, v73, v33);
      // pto: %65
      ;
      pto::Stride<-1, -1, -1, -1, -1> v265 = pto::Stride<-1, -1, -1, -1, -1>(v260 * v263, v263, v262, v28, v27);
      // pto: %65
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v266 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v258 + (v257 + v76 * v28 + v108 * v27), v264, v265);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
      TSTORE(v266, v255);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    // pto: %10
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v267 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %10
    ;
    uint64_t v268 = (uint64_t) v22;
    TASSIGN(v267, v268);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    TROWEXPANDMUL(v267, v161, v89);
    // pto: %11
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %11
    ;
    uint64_t v270 = (uint64_t) v23;
    TASSIGN(v269, v270);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    TROWEXPANDMUL(v269, v174, v93);
    // pto: %12
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v271 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %12
    ;
    uint64_t v272 = (uint64_t) v24;
    TASSIGN(v271, v272);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    TROWEXPANDMUL(v271, v188, v97);
    // pto: %13
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %13
    ;
    uint64_t v274 = (uint64_t) v25;
    TASSIGN(v273, v274);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TROWEXPANDMUL(v273, v202, v101);
    // pto: %14
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %14
    ;
    uint64_t v276 = (uint64_t) v22;
    TASSIGN(v275, v276);
    pipe_barrier(PIPE_V);
    TADD(v275, v267, v269);
    // pto: %15
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %15
    ;
    uint64_t v278 = (uint64_t) v22;
    TASSIGN(v277, v278);
    pipe_barrier(PIPE_V);
    TADD(v277, v275, v271);
    // pto: %16
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %16
    ;
    uint64_t v280 = (uint64_t) v22;
    TASSIGN(v279, v280);
    pipe_barrier(PIPE_V);
    TADD(v279, v277, v273);
    // pto: %17
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
    // pto: %17
    ;
    uint64_t v282 = (uint64_t) v22;
    TASSIGN(v281, v282);
    pipe_barrier(PIPE_V);
    RoundMode v283 = RoundMode::CAST_RINT;
    SaturationMode v284 = SaturationMode::ON;
    TCVT(v281, v279, v283, v284);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    if (v234) {
      // pto: %x_mixed__phi_v4_pview
      ;
      const int64_t v285 = 0;
      // pto: %x_mixed__phi_v4_pview
      ;
      __gm__ bfloat16_t* v286 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %x_mixed__phi_v4_pview
      ;
      const int64_t v287 = 1;
      // pto: %x_mixed__phi_v4_pview
      ;
      const int64_t v288 = 1;
      // pto: %x_mixed__phi_v4_pview
      ;
      const int64_t v289 = 1;
      // pto: %x_mixed__phi_v4_pview
      ;
      int64_t v290 = v73 * v28;
      // pto: %x_mixed__phi_v4_pview
      ;
      int64_t v291 = v289 * v290;
      // pto: %x_mixed__phi_v4_pview
      ;
      pto::Shape<1, 1, 1, -1, 256> v292 = pto::Shape<1, 1, 1, -1, 256>(v287, v288, v289, v73, v33);
      // pto: %x_mixed__phi_v4_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v293 = pto::Stride<-1, -1, -1, -1, -1>(v288 * v291, v291, v290, v28, v27);
      // pto: %x_mixed__phi_v4_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v294 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v286 + (v285 + v76 * v28 + v163 * v27), v292, v293);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v294, v281);
    } else {
      // pto: %x_mixed_tail_store_inline1704__phi_v4_pview
      ;
      const int64_t v295 = 0;
      // pto: %x_mixed_tail_store_inline1704__phi_v4_pview
      ;
      __gm__ bfloat16_t* v296 = PTOAS__GLOBAL_TENSOR_DATA(v61);
      // pto: %x_mixed_tail_store_inline1704__phi_v4_pview
      ;
      const int64_t v297 = 1;
      // pto: %x_mixed_tail_store_inline1704__phi_v4_pview
      ;
      const int64_t v298 = 1;
      // pto: %x_mixed_tail_store_inline1704__phi_v4_pview
      ;
      const int64_t v299 = 1;
      // pto: %x_mixed_tail_store_inline1704__phi_v4_pview
      ;
      int64_t v300 = v73 * v28;
      // pto: %x_mixed_tail_store_inline1704__phi_v4_pview
      ;
      int64_t v301 = v299 * v300;
      // pto: %x_mixed_tail_store_inline1704__phi_v4_pview
      ;
      pto::Shape<1, 1, 1, -1, 256> v302 = pto::Shape<1, 1, 1, -1, 256>(v297, v298, v299, v73, v33);
      // pto: %x_mixed_tail_store_inline1704__phi_v4_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v303 = pto::Stride<-1, -1, -1, -1, -1>(v298 * v301, v301, v300, v28, v27);
      // pto: %x_mixed_tail_store_inline1704__phi_v4_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v304 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v296 + (v295 + v30 * v28 + v163 * v27), v302, v303);
      TSTORE(v304, v281);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      // pto: %18
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v33);
      // pto: %18
      ;
      uint64_t v306 = (uint64_t) v22;
      TASSIGN(v305, v306);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      TLOAD(v305, v304);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
      // pto: %76
      ;
      const int64_t v307 = 0;
      // pto: %76
      ;
      __gm__ bfloat16_t* v308 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %76
      ;
      const int64_t v309 = 1;
      // pto: %76
      ;
      const int64_t v310 = 1;
      // pto: %76
      ;
      const int64_t v311 = 1;
      // pto: %76
      ;
      int64_t v312 = v73 * v28;
      // pto: %76
      ;
      int64_t v313 = v311 * v312;
      // pto: %76
      ;
      pto::Shape<1, 1, 1, -1, 256> v314 = pto::Shape<1, 1, 1, -1, 256>(v309, v310, v311, v73, v33);
      // pto: %76
      ;
      pto::Stride<-1, -1, -1, -1, -1> v315 = pto::Stride<-1, -1, -1, -1, -1>(v310 * v313, v313, v312, v28, v27);
      // pto: %76
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v316 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v308 + (v307 + v76 * v28 + v163 * v27), v314, v315);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
      TSTORE(v316, v305);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}