#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_b_dequant(__gm__ int32_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ bfloat16_t* v4, int64_t v5, int64_t v6, int32_t v7, int32_t v8) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v9 = 0;
  // pto: %c32768_i64
  const int64_t v10 = 32768;
  // pto: %c34816_i64
  const int64_t v11 = 34816;
  // pto: %c34880_i64
  const int64_t v12 = 34880;
  // pto: %c4096_index
  const int64_t v13 = 4096;
  // pto: %c1_index
  const int64_t v14 = 1;
  // pto: %c8_index
  const int64_t v15 = 8;
  // pto: %c16_index
  const int64_t v16 = 16;
  // pto: %c512_index
  const int64_t v17 = 512;
  // pto: %c0_index
  const int64_t v18 = 0;
  // pto: %cst_10
  const float v19 = 1.0f;
  // pto: %c63_index
  const int64_t v20 = 63;
  // pto: %12
  int64_t v21 = (int64_t) ((uint64_t) v6 + (uint64_t) v20);
  // pto: %integer_accum__phi_v3_view
  const int64_t v22 = 1;
  // pto: %integer_accum__phi_v3_view
  const int64_t v23 = 1;
  // pto: %integer_accum__phi_v3_view
  const int64_t v24 = 1;
  // pto: %integer_accum__phi_v3_view
  int64_t v25 = v21 * v13;
  // pto: %integer_accum__phi_v3_view
  int64_t v26 = v24 * v25;
  // pto: %integer_accum__phi_v3_view
  pto::Shape<1, 1, 1, -1, -1> v27 = pto::Shape<1, 1, 1, -1, -1>(v22, v23, v24, v21, v13);
  // pto: %integer_accum__phi_v3_view
  pto::Stride<-1, -1, -1, -1, -1> v28 = pto::Stride<-1, -1, -1, -1, -1>(v23 * v26, v26, v25, v13, v14);
  // pto: %integer_accum__phi_v3_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v29 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v27, v28);
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v30 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v34 = v13 * v14;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v35 = v33 * v34;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v36 = v32 * v35;
  // pto: %wo_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v37 = pto::Shape<1, 1, 1, 1, -1>(v30, v31, v32, v33, v13);
  // pto: %wo_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v38 = pto::Stride<-1, -1, -1, -1, -1>(v31 * v36, v36, v35, v34, v14);
  // pto: %wo_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v39 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v37, v38);
  // pto: %token_scale__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %token_scale__ssa_v0_view
  int64_t v43 = (int64_t) v6;
  // pto: %token_scale__ssa_v0_view
  int64_t v44 = v43 * v14;
  // pto: %token_scale__ssa_v0_view
  int64_t v45 = v42 * v44;
  // pto: %token_scale__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v46 = pto::Shape<1, 1, 1, -1, -1>(v40, v41, v42, v43, v14);
  // pto: %token_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v47 = pto::Stride<-1, -1, -1, -1, -1>(v41 * v45, v45, v44, v14, (int64_t) v6);
  // pto: %token_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v48 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v3, v46, v47);
  // pto: %output__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %output__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %output__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %output__ssa_v0_view
  int64_t v52 = (int64_t) v6;
  // pto: %output__ssa_v0_view
  int64_t v53 = v52 * v13;
  // pto: %output__ssa_v0_view
  int64_t v54 = v51 * v53;
  // pto: %output__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v55 = pto::Shape<1, 1, 1, -1, -1>(v49, v50, v51, v52, v13);
  // pto: %output__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v56 = pto::Stride<-1, -1, -1, -1, -1>(v50 * v54, v54, v53, v13, v14);
  // pto: %output__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v57 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v55, v56);
  // pto: %block__ssa_v0
  int64_t v58 = (int64_t) v7;
  // pto: %0, %1
  int64_t v59 = (int64_t) ((uint64_t) (v58 / v15) * (uint64_t) v16);
  // pto: %2, %3
  int64_t v60 = (int64_t) ((uint64_t) (v58 % v15) * (uint64_t) v17);
  // pto: %4
  int64_t v61 = (int64_t) ((uint64_t) v6 - (uint64_t) v59);
  // pto: %5
  int64_t v62 = v61 < v16 ? v61 : v16;
  // pto: %ob_integer__ssa_v0
  Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v63 = Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v17);
  // pto: %ob_integer__ssa_v0
  uint64_t v64 = (uint64_t) v9;
  TASSIGN(v63, v64);
  // pto: %6
  int64_t v65 = v59 < v18 ? v18 : v59;
  // pto: %7
  int64_t v66 = v60 < v18 ? v18 : v60;
  // pto: %integer_accum__phi_v3_pview
  const int64_t v67 = 0;
  // pto: %integer_accum__phi_v3_pview
  __gm__ int32_t* v68 = PTOAS__GLOBAL_TENSOR_DATA(v29);
  // pto: %integer_accum__phi_v3_pview
  const int64_t v69 = 1;
  // pto: %integer_accum__phi_v3_pview
  const int64_t v70 = 1;
  // pto: %integer_accum__phi_v3_pview
  const int64_t v71 = 1;
  // pto: %integer_accum__phi_v3_pview
  int64_t v72 = v62 * v13;
  // pto: %integer_accum__phi_v3_pview
  int64_t v73 = v71 * v72;
  // pto: %integer_accum__phi_v3_pview
  pto::Shape<1, 1, 1, -1, 512> v74 = pto::Shape<1, 1, 1, -1, 512>(v69, v70, v71, v62, v17);
  // pto: %integer_accum__phi_v3_pview
  pto::Stride<-1, -1, -1, -1, -1> v75 = pto::Stride<-1, -1, -1, -1, -1>(v70 * v73, v73, v72, v13, v14);
  // pto: %integer_accum__phi_v3_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v76 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v68 + (v67 + v65 * v13 + v66 * v14), v74, v75);
  TLOAD(v63, v76);
  // pto: %t__tmp_v20
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v77 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v17);
  // pto: %t__tmp_v20
  uint64_t v78 = (uint64_t) v10;
  TASSIGN(v77, v78);
  // pto: %wo_b_scale__ssa_v0_pview
  __gm__ float* v79 = PTOAS__GLOBAL_TENSOR_DATA(v39);
  // pto: %wo_b_scale__ssa_v0_pview
  const int64_t v80 = 0;
  // pto: %wo_b_scale__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 512> v81 = pto::Shape<1, 1, 1, 1, 512>();
  // pto: %wo_b_scale__ssa_v0_pview
  pto::Stride<512, 512, 512, 512, 1> v82 = pto::Stride<512, 512, 512, 512, 1>();
  // pto: %wo_b_scale__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v83 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v79 + (v80 + v66), v81, v82);
  TLOAD(v77, v83);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %channel__ssa_v0
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v84 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v17);
  // pto: %channel__ssa_v0
  uint64_t v85 = (uint64_t) v10;
  TASSIGN(v84, v85);
  // pto: %scale__ssa_v0
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v86 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v14);
  // pto: %scale__ssa_v0
  uint64_t v87 = (uint64_t) v11;
  TASSIGN(v86, v87);
  // pto: %token_scale__ssa_v0_pview
  int64_t v88 = (int64_t) v6;
  // pto: %token_scale__ssa_v0_pview
  const int64_t v89 = 0;
  // pto: %token_scale__ssa_v0_pview
  __gm__ float* v90 = PTOAS__GLOBAL_TENSOR_DATA(v48);
  // pto: %token_scale__ssa_v0_pview
  const int64_t v91 = 1;
  // pto: %token_scale__ssa_v0_pview
  const int64_t v92 = 1;
  // pto: %token_scale__ssa_v0_pview
  const int64_t v93 = 1;
  // pto: %token_scale__ssa_v0_pview
  int64_t v94 = v62 * v14;
  // pto: %token_scale__ssa_v0_pview
  int64_t v95 = v93 * v94;
  // pto: %token_scale__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 1> v96 = pto::Shape<1, 1, 1, -1, 1>(v91, v92, v93, v62, v14);
  // pto: %token_scale__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v97 = pto::Stride<-1, -1, -1, -1, -1>(v92 * v95, v95, v94, v14, v88);
  // pto: %token_scale__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v98 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v90 + (v89 + v65 * v14 + v18 * v88), v96, v97);
  TLOAD(v86, v98);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  // pto: %coefficient_one__ssa_v0
  Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v17);
  // pto: %coefficient_one__ssa_v0
  uint64_t v100 = (uint64_t) v12;
  TASSIGN(v99, v100);
  TEXPANDS(v99, v19);
  // pto: %coefficient_channel__ssa_v0
  Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v17);
  // pto: %coefficient_channel__ssa_v0
  uint64_t v102 = (uint64_t) v12;
  TASSIGN(v101, v102);
  pipe_barrier(PIPE_V);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  TCOLEXPANDMUL(v101, v99, v84);
  // pto: %coefficient__ssa_v0
  Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v16, v17);
  // pto: %coefficient__ssa_v0
  uint64_t v104 = (uint64_t) v12;
  TASSIGN(v103, v104);
  pipe_barrier(PIPE_V);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  TROWEXPANDMUL(v103, v101, v86);
  // pto: %t__tmp_v21
  Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v105 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v17);
  // pto: %t__tmp_v21
  uint64_t v106 = (uint64_t) v9;
  TASSIGN(v105, v106);
  RoundMode v107 = RoundMode::CAST_ROUND;
  SaturationMode v108 = SaturationMode::ON;
  TCVT(v105, v63, v107, v108);
  // pto: %ob_scaled__ssa_v0
  Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v17);
  // pto: %ob_scaled__ssa_v0
  uint64_t v110 = (uint64_t) v9;
  TASSIGN(v109, v110);
  pipe_barrier(PIPE_V);
  TMUL(v109, v105, v103);
  // pto: %t__tmp_v22
  Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v17);
  // pto: %t__tmp_v22
  uint64_t v112 = (uint64_t) v9;
  TASSIGN(v111, v112);
  pipe_barrier(PIPE_V);
  RoundMode v113 = RoundMode::CAST_RINT;
  SaturationMode v114 = SaturationMode::ON;
  TCVT(v111, v109, v113, v114);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %output__ssa_v0_pview
  const int64_t v115 = 0;
  // pto: %output__ssa_v0_pview
  __gm__ bfloat16_t* v116 = PTOAS__GLOBAL_TENSOR_DATA(v57);
  // pto: %output__ssa_v0_pview
  const int64_t v117 = 1;
  // pto: %output__ssa_v0_pview
  const int64_t v118 = 1;
  // pto: %output__ssa_v0_pview
  const int64_t v119 = 1;
  // pto: %output__ssa_v0_pview
  int64_t v120 = v62 * v13;
  // pto: %output__ssa_v0_pview
  int64_t v121 = v119 * v120;
  // pto: %output__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 512> v122 = pto::Shape<1, 1, 1, -1, 512>(v117, v118, v119, v62, v17);
  // pto: %output__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v123 = pto::Stride<-1, -1, -1, -1, -1>(v118 * v121, v121, v120, v13, v14);
  // pto: %output__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v124 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v116 + (v115 + v65 * v13 + v66 * v14), v122, v123);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v124, v111);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}