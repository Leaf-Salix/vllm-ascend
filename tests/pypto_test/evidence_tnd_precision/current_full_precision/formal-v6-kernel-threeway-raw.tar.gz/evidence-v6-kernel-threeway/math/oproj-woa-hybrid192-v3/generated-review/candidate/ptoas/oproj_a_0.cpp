#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_a_0(__gm__ float* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int32_t v9, int32_t v10) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c196608_i64
  const int64_t v11 = 196608;
  // pto: %c0_i64
  const int64_t v12 = 0;
  // pto: %c32768_i64
  const int64_t v13 = 32768;
  // pto: %c65536_i64
  const int64_t v14 = 65536;
  // pto: %c131072_i64
  const int64_t v15 = 131072;
  // pto: %c8192_index
  const int64_t v16 = 8192;
  // pto: %c1_index
  const int64_t v17 = 1;
  // pto: %c16_index
  const int64_t v18 = 16;
  // pto: %c8_index
  const int64_t v19 = 8;
  // pto: %c32768_index
  const int64_t v20 = 32768;
  const int64_t v21 = 64;
  // pto: %c256_index
  const int64_t v22 = 256;
  // pto: %c4194304_index
  const int64_t v23 = 4194304;
  // pto: %c65536_index
  const int64_t v24 = 65536;
  const int64_t v25 = 128;
  // pto: %c0_index
  const int64_t v26 = 0;
  // pto: %c7_index
  const int64_t v27 = 7;
  // pto: %c2_index
  const int64_t v28 = 2;
  // pto: %c3_index
  const int64_t v29 = 3;
  // pto: %c4_index
  const int64_t v30 = 4;
  // pto: %c5_index
  const int64_t v31 = 5;
  // pto: %c6_index
  const int64_t v32 = 6;
  // pto: %c4096_index
  const int64_t v33 = 4096;
  // pto: %c14_index
  const int64_t v34 = 14;
  // pto: %c240_index
  const int64_t v35 = 240;
  // pto: %c225_index
  const int64_t v36 = 225;
  // pto: %c241_index
  const int64_t v37 = 241;
  // pto: %c1024_index
  const int64_t v38 = 1024;
  // pto: %c127_index
  const int64_t v39 = 127;
  // pto: %307
  int64_t v40 = (int64_t) ((uint64_t) v8 + (uint64_t) v39);
  // pto: %accum__iter_v11_view
  const int64_t v41 = 1;
  // pto: %accum__iter_v11_view
  const int64_t v42 = 1;
  // pto: %accum__iter_v11_view
  const int64_t v43 = 1;
  // pto: %accum__iter_v11_view
  int64_t v44 = v40 * v16;
  // pto: %accum__iter_v11_view
  int64_t v45 = v43 * v44;
  // pto: %accum__iter_v11_view
  pto::Shape<1, 1, 1, -1, -1> v46 = pto::Shape<1, 1, 1, -1, -1>(v41, v42, v43, v40, v16);
  // pto: %accum__iter_v11_view
  pto::Stride<-1, -1, -1, -1, -1> v47 = pto::Stride<-1, -1, -1, -1, -1>(v42 * v45, v45, v44, v16, v17);
  // pto: %accum__iter_v11_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v48 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v46, v47);
  // pto: %heads__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v52 = (int64_t) v8;
  // pto: %heads__ssa_v0_view
  int64_t v53 = v52 * v20;
  // pto: %heads__ssa_v0_view
  int64_t v54 = v51 * v53;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v55 = pto::Shape<1, 1, 1, -1, -1>(v49, v50, v51, v52, v20);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v56 = pto::Stride<-1, -1, -1, -1, -1>(v50 * v54, v54, v53, v20, v17);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v57 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v55, v56);
  // pto: %wo_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v58 = pto::Shape<-1, -1, -1, -1, -1>(v19, v21, v22, v18, v18);
  // pto: %wo_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v59 = pto::Stride<-1, -1, -1, -1, -1>(v23, v24, v22, v18, v17);
  // pto: %wo_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v60 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v4, v58, v59);
  // pto: %v4_wide_acc__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v61 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v25, v25);
  // pto: %v4_wide_acc__phi_v7
  uint64_t v62 = (uint64_t) v12;
  TASSIGN(v61, v62);
  // pto: %178
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v63 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v25, v25);
  // pto: %178
  uint64_t v64 = (uint64_t) v12;
  TASSIGN(v63, v64);
  // pto: %210
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v65 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v25, v25);
  // pto: %210
  uint64_t v66 = (uint64_t) v12;
  TASSIGN(v65, v66);
  // pto: %v4_narrow_acc__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v18, v25);
  // pto: %v4_narrow_acc__phi_v7
  uint64_t v68 = (uint64_t) v12;
  TASSIGN(v67, v68);
  // pto: %v4_block__ssa_v0
  int64_t v69 = (int64_t) v9;
  // pto: %38
  int64_t v70 = (int64_t) ((uint64_t) v69 * (uint64_t) v25);
  // pto: %39, %40
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  for (int64_t v71 = v26; v71 < ((int64_t) ((uint64_t) v5 + (uint64_t) v27) / v19); v71 += v17) {
    // pto: %41
    ;
    int64_t v72 = (int64_t) ((uint64_t) v71 * (uint64_t) v19);
    // pto: %flat_offset, %42, %43, %t__tile
    ;
    int32_t v73 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v71 * (uint64_t) v21) + (uint64_t) v6) * (uint64_t) v19) + (uint64_t) v69)];
    // pto: %44
    ;
    int64_t v74 = (int64_t) v73;
    // pto: %45
    ;
    int64_t v75 = v74 < v26 ? v26 : v74;
    // pto: %46
    ;
    int64_t v76 = (int64_t) ((uint64_t) v72 + (uint64_t) v17);
    // pto: %47
    ;
    // pto: %v4_same_start__phi_v3
    ;
    int64_t v77;
    if (v76 < v5) {
      // pto: %50, %51, %52, %53, %48
      ;
      int32_t v78 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v76 * (uint64_t) v19) + (uint64_t) v6) * (uint64_t) v19) + (uint64_t) v69)];
      // pto: %54
      ;
      int64_t v79 = (int64_t) v78;
      // pto: %55
      ;
      int64_t v80 = v79 < v26 ? v26 : v79;
      // pto: %56, %v4_same_start__phi_v2
      ;
      v77 = v80 != v75 ? v26 : v17;
    } else {
      v77 = v17;
    };
    // pto: %57
    ;
    int64_t v81 = (int64_t) ((uint64_t) v72 + (uint64_t) v28);
    // pto: %58
    ;
    // pto: %v4_same_start__phi_v6
    ;
    int64_t v82;
    if (v81 < v5) {
      // pto: %61, %62, %63, %64, %59
      ;
      int32_t v83 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v81 * (uint64_t) v19) + (uint64_t) v6) * (uint64_t) v19) + (uint64_t) v69)];
      // pto: %65
      ;
      int64_t v84 = (int64_t) v83;
      // pto: %66
      ;
      int64_t v85 = v84 < v26 ? v26 : v84;
      // pto: %67, %v4_same_start__phi_v5
      ;
      int64_t v86 = v85 != v75 ? v26 : v77;
      v82 = v86;
    } else {
      v82 = v77;
    };
    // pto: %68
    ;
    int64_t v87 = (int64_t) ((uint64_t) v72 + (uint64_t) v29);
    // pto: %69
    ;
    // pto: %v4_same_start__phi_v9
    ;
    int64_t v88;
    if (v87 < v5) {
      // pto: %72, %73, %74, %75, %70
      ;
      int32_t v89 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v87 * (uint64_t) v19) + (uint64_t) v6) * (uint64_t) v19) + (uint64_t) v69)];
      // pto: %76
      ;
      int64_t v90 = (int64_t) v89;
      // pto: %77
      ;
      int64_t v91 = v90 < v26 ? v26 : v90;
      // pto: %78, %v4_same_start__phi_v8
      ;
      int64_t v92 = v91 != v75 ? v26 : v82;
      v88 = v92;
    } else {
      v88 = v82;
    };
    // pto: %79
    ;
    int64_t v93 = (int64_t) ((uint64_t) v72 + (uint64_t) v30);
    // pto: %80
    ;
    // pto: %v4_same_start__phi_v12
    ;
    int64_t v94;
    if (v93 < v5) {
      // pto: %83, %84, %85, %86, %81
      ;
      int32_t v95 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v93 * (uint64_t) v19) + (uint64_t) v6) * (uint64_t) v19) + (uint64_t) v69)];
      // pto: %87
      ;
      int64_t v96 = (int64_t) v95;
      // pto: %88
      ;
      int64_t v97 = v96 < v26 ? v26 : v96;
      // pto: %89, %v4_same_start__phi_v11
      ;
      int64_t v98 = v97 != v75 ? v26 : v88;
      v94 = v98;
    } else {
      v94 = v88;
    };
    // pto: %90
    ;
    int64_t v99 = (int64_t) ((uint64_t) v72 + (uint64_t) v31);
    // pto: %91
    ;
    // pto: %v4_same_start__phi_v15
    ;
    int64_t v100;
    if (v99 < v5) {
      // pto: %94, %95, %96, %97, %92
      ;
      int32_t v101 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v99 * (uint64_t) v19) + (uint64_t) v6) * (uint64_t) v19) + (uint64_t) v69)];
      // pto: %98
      ;
      int64_t v102 = (int64_t) v101;
      // pto: %99
      ;
      int64_t v103 = v102 < v26 ? v26 : v102;
      // pto: %100, %v4_same_start__phi_v14
      ;
      int64_t v104 = v103 != v75 ? v26 : v94;
      v100 = v104;
    } else {
      v100 = v94;
    };
    // pto: %101
    ;
    int64_t v105 = (int64_t) ((uint64_t) v72 + (uint64_t) v32);
    // pto: %102
    ;
    // pto: %v4_same_start__phi_v18
    ;
    int64_t v106;
    if (v105 < v5) {
      // pto: %105, %106, %107, %108, %103
      ;
      int32_t v107 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v105 * (uint64_t) v19) + (uint64_t) v6) * (uint64_t) v19) + (uint64_t) v69)];
      // pto: %109
      ;
      int64_t v108 = (int64_t) v107;
      // pto: %110
      ;
      int64_t v109 = v108 < v26 ? v26 : v108;
      // pto: %111, %v4_same_start__phi_v17
      ;
      int64_t v110 = v109 != v75 ? v26 : v100;
      v106 = v110;
    } else {
      v106 = v100;
    };
    // pto: %112
    ;
    int64_t v111 = (int64_t) ((uint64_t) v72 + (uint64_t) v27);
    // pto: %113
    ;
    // pto: %v4_same_start__phi_v21
    ;
    int64_t v112;
    if (v111 < v5) {
      // pto: %116, %117, %118, %119, %114
      ;
      int32_t v113 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v111 * (uint64_t) v19) + (uint64_t) v6) * (uint64_t) v19) + (uint64_t) v69)];
      // pto: %120
      ;
      int64_t v114 = (int64_t) v113;
      // pto: %121
      ;
      int64_t v115 = v114 < v26 ? v26 : v114;
      // pto: %122, %v4_same_start__phi_v20
      ;
      int64_t v116 = v115 != v75 ? v26 : v106;
      v112 = v116;
    } else {
      v112 = v106;
    };
    // pto: %123, %v4_same_start__phi_v23
    ;
    int64_t v117 = v8 <= v18 ? v26 : v112;
    // pto: %124
    ;
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    if (v117 == v17) {
      int64_t v118 = (int64_t) ((uint64_t) v71 * (uint64_t) v25);
      // pto: %126
      ;
      int64_t v119 = (int64_t) ((uint64_t) v8 - (uint64_t) v118);
      // pto: %127
      ;
      int64_t v120 = v119 < v25 ? v119 : v25;
      // pto: %128, %129
      ;
      int64_t v121 = (int64_t) ((uint64_t) (v75 % v22) * (uint64_t) v18);
      // pto: %v4_wide_seed_x__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v120, v18);
      // pto: %v4_wide_seed_x__tile
      ;
      uint64_t v123 = (uint64_t) v11;
      TASSIGN(v122, v123);
      // pto: %130
      ;
      int64_t v124 = v118 < v26 ? v26 : v118;
      // pto: %131
      ;
      int64_t v125 = (int64_t) ((uint64_t) v6 * (uint64_t) v33);
      // pto: %132
      ;
      int64_t v126 = (int64_t) ((uint64_t) v125 + (uint64_t) v121);
      // pto: %133
      ;
      int64_t v127 = v126 < v26 ? v26 : v126;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v128 = 0;
      // pto: %heads__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v129 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v130 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v131 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v132 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      int64_t v133 = v120 * v20;
      // pto: %heads__ssa_v0_pview
      ;
      int64_t v134 = v132 * v133;
      // pto: %heads__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 16> v135 = pto::Shape<1, 1, 1, -1, 16>(v130, v131, v132, v120, v18);
      // pto: %heads__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v136 = pto::Stride<-1, -1, -1, -1, -1>(v131 * v134, v134, v133, v20, v17);
      // pto: %heads__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v137 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v129 + (v128 + v124 * v20 + v127 * v17), v135, v136);
      TLOAD(v122, v137);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %v4_wide_seed_w__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
      // pto: %v4_wide_seed_w__tile
      ;
      uint64_t v139 = (uint64_t) v12;
      TASSIGN(v138, v139);
      // pto: %134
      ;
      int64_t v140 = v6 < v26 ? v26 : v6;
      // pto: %135
      ;
      int64_t v141 = v70 / v18;
      // pto: %136
      ;
      int64_t v142 = v141 < v26 ? v26 : v141;
      // pto: %137
      ;
      int64_t v143 = v121 / v18;
      // pto: %138
      ;
      int64_t v144 = v143 < v26 ? v26 : v143;
      // pto: %wo_a__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v145 = PTOAS__GLOBAL_TENSOR_DATA(v60);
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v146 = 0;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v147 = 4194304;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v148 = 65536;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v149 = 256;
      // pto: %wo_a__ssa_v0_pview
      ;
      pto::Shape<1, 8, 1, 16, 16> v150 = pto::Shape<1, 8, 1, 16, 16>();
      // pto: %wo_a__ssa_v0_pview
      ;
      pto::Stride<4194304, 65536, 256, 16, 1> v151 = pto::Stride<4194304, 65536, 256, 16, 1>();
      // pto: %wo_a__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v152 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v145 + ((v146 + v140 * v147) + v142 * v148 + v144 * v149), v150, v151);
      TLOAD(v138, v152);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %lhs_slice_0_textract
      ;
      Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v153 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v120, v18);
      // pto: %lhs_slice_0_textract
      ;
      uint64_t v154 = (uint64_t) v12;
      TASSIGN(v153, v154);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      uint16_t v155 = static_cast<uint16_t>(v26);
      uint16_t v156 = static_cast<uint16_t>(v26);
      TEXTRACT(v153, v122, v155, v156);
      // pto: %rhs_slice_0_textract
      ;
      Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
      // pto: %rhs_slice_0_textract
      ;
      uint64_t v158 = (uint64_t) v12;
      TASSIGN(v157, v158);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      uint16_t v159 = static_cast<uint16_t>(v26);
      uint16_t v160 = static_cast<uint16_t>(v26);
      TEXTRACT(v157, v138, v159, v160);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %v4_wide_acc__tile
      ;
      Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v161 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v120, v25);
      // pto: %v4_wide_acc__tile
      ;
      uint64_t v162 = (uint64_t) v12;
      TASSIGN(v161, v162);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      TMATMUL(v161, v153, v157);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      for (int64_t v163 = v26; v163 < v34; v163 += v28) {
        // pto: %139
        ;
        int64_t v164 = (int64_t) ((uint64_t) v163 * (uint64_t) v18);
        // pto: %140, %141, %142
        ;
        int64_t v165 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v75 + (uint64_t) v164) + (uint64_t) v17) % v22;
        // pto: %145, %144, %146, %147
        ;
        int64_t v166 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v75 + (uint64_t) ((int64_t) (uint64_t) v164 + (uint64_t) v18)) + (uint64_t) v17) % v22;
        // pto: %148
        ;
        // pto: %149
        ;
        int64_t v167 = v120 < v25 ? v120 : v25;
        v61.SetValidShape(v167, v25);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        if (v165 <= v35) {
          // pto: %150
          ;
          int64_t v168 = (int64_t) ((uint64_t) v165 * (uint64_t) v18);
          // pto: %v4_wide_packet_x__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v120, v22);
          // pto: %v4_wide_packet_x__tile
          ;
          uint64_t v170 = (uint64_t) v11;
          TASSIGN(v169, v170);
          // pto: %153
          ;
          int64_t v171 = (int64_t) ((uint64_t) v125 + (uint64_t) v168);
          // pto: %154
          ;
          int64_t v172 = v171 < v26 ? v26 : v171;
          // pto: %155
          ;
          const int64_t v173 = 0;
          // pto: %155
          ;
          __gm__ bfloat16_t* v174 = PTOAS__GLOBAL_TENSOR_DATA(v57);
          // pto: %155
          ;
          const int64_t v175 = 1;
          // pto: %155
          ;
          const int64_t v176 = 1;
          // pto: %155
          ;
          const int64_t v177 = 1;
          // pto: %155
          ;
          int64_t v178 = v120 * v20;
          // pto: %155
          ;
          int64_t v179 = v177 * v178;
          // pto: %155
          ;
          pto::Shape<1, 1, 1, -1, 256> v180 = pto::Shape<1, 1, 1, -1, 256>(v175, v176, v177, v120, v22);
          // pto: %155
          ;
          pto::Stride<-1, -1, -1, -1, -1> v181 = pto::Stride<-1, -1, -1, -1, -1>(v176 * v179, v179, v178, v20, v17);
          // pto: %155
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v182 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v174 + (v173 + v124 * v20 + v172 * v17), v180, v181);
          TLOAD(v169, v182);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          // pto: %v4_wide_packet_w__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v22, v25);
          // pto: %v4_wide_packet_w__tile
          ;
          uint64_t v184 = (uint64_t) v12;
          TASSIGN(v183, v184);
          // pto: %159
          ;
          int64_t v185 = v168 / v18;
          // pto: %160
          ;
          int64_t v186 = v185 < v26 ? v26 : v185;
          // pto: %161
          ;
          __gm__ bfloat16_t* v187 = PTOAS__GLOBAL_TENSOR_DATA(v60);
          // pto: %161
          ;
          const int64_t v188 = 0;
          // pto: %161
          ;
          const int64_t v189 = 4194304;
          // pto: %161
          ;
          const int64_t v190 = 65536;
          // pto: %161
          ;
          const int64_t v191 = 256;
          // pto: %161
          ;
          pto::Shape<1, 8, 16, 16, 16> v192 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %161
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v193 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %161
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v194 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v187 + ((v188 + v140 * v189) + v142 * v190 + v186 * v191), v192, v193);
          TLOAD(v183, v194);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
          // pto: %v4_wide_acc__iter_v1_l0_a
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v195 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v120, v25);
          // pto: %v4_wide_acc__iter_v1_l0_a
          ;
          uint64_t v196 = (uint64_t) v12;
          TASSIGN(v195, v196);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          uint16_t v197 = static_cast<uint16_t>(v26);
          uint16_t v198 = static_cast<uint16_t>(v26);
          TEXTRACT(v195, v169, v197, v198);
          // pto: %v4_wide_acc__iter_v1_l0_b
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v25);
          // pto: %v4_wide_acc__iter_v1_l0_b
          ;
          uint64_t v200 = (uint64_t) v12;
          TASSIGN(v199, v200);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
          uint16_t v201 = static_cast<uint16_t>(v26);
          uint16_t v202 = static_cast<uint16_t>(v26);
          TEXTRACT(v199, v183, v201, v202);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          // pto: %0
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v203 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v120, v25);
          // pto: %0
          ;
          uint64_t v204 = (uint64_t) v13;
          TASSIGN(v203, v204);
          uint16_t v205 = static_cast<uint16_t>(v26);
          uint16_t v206 = static_cast<uint16_t>(v25);
          TEXTRACT(v203, v169, v205, v206);
          // pto: %1
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v25);
          // pto: %1
          ;
          uint64_t v208 = (uint64_t) v13;
          TASSIGN(v207, v208);
          uint16_t v209 = static_cast<uint16_t>(v25);
          uint16_t v210 = static_cast<uint16_t>(v26);
          TEXTRACT(v207, v183, v209, v210);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v161, v161, v195, v199);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
          TMATMUL_ACC(v161, v161, v203, v207);
        } else {
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
          for (int64_t v211 = v26; v211 < v18; v211 += v17) {
            // pto: %162, %163, %164
            ;
            int64_t v212 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v165 + (uint64_t) v211) % v22) * (uint64_t) v18);
            // pto: %v4_wide_wrap_x__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v120, v18);
            // pto: %v4_wide_wrap_x__tile
            ;
            uint64_t v214 = (uint64_t) v11;
            TASSIGN(v213, v214);
            // pto: %167
            ;
            int64_t v215 = (int64_t) ((uint64_t) v125 + (uint64_t) v212);
            // pto: %168
            ;
            int64_t v216 = v215 < v26 ? v26 : v215;
            // pto: %169
            ;
            const int64_t v217 = 0;
            // pto: %169
            ;
            __gm__ bfloat16_t* v218 = PTOAS__GLOBAL_TENSOR_DATA(v57);
            // pto: %169
            ;
            const int64_t v219 = 1;
            // pto: %169
            ;
            const int64_t v220 = 1;
            // pto: %169
            ;
            const int64_t v221 = 1;
            // pto: %169
            ;
            int64_t v222 = v120 * v20;
            // pto: %169
            ;
            int64_t v223 = v221 * v222;
            // pto: %169
            ;
            pto::Shape<1, 1, 1, -1, 16> v224 = pto::Shape<1, 1, 1, -1, 16>(v219, v220, v221, v120, v18);
            // pto: %169
            ;
            pto::Stride<-1, -1, -1, -1, -1> v225 = pto::Stride<-1, -1, -1, -1, -1>(v220 * v223, v223, v222, v20, v17);
            // pto: %169
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v226 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v218 + (v217 + v124 * v20 + v216 * v17), v224, v225);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            TLOAD(v213, v226);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
            // pto: %v4_wide_wrap_w__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
            // pto: %v4_wide_wrap_w__tile
            ;
            uint64_t v228 = (uint64_t) v12;
            TASSIGN(v227, v228);
            // pto: %173
            ;
            int64_t v229 = v212 / v18;
            // pto: %174
            ;
            int64_t v230 = v229 < v26 ? v26 : v229;
            // pto: %175
            ;
            __gm__ bfloat16_t* v231 = PTOAS__GLOBAL_TENSOR_DATA(v60);
            // pto: %175
            ;
            const int64_t v232 = 0;
            // pto: %175
            ;
            const int64_t v233 = 4194304;
            // pto: %175
            ;
            const int64_t v234 = 65536;
            // pto: %175
            ;
            const int64_t v235 = 256;
            // pto: %175
            ;
            pto::Shape<1, 8, 1, 16, 16> v236 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %175
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v237 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %175
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v238 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v231 + ((v232 + v140 * v233) + v142 * v234 + v230 * v235), v236, v237);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            TLOAD(v227, v238);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
            // pto: %3
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v239 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v120, v18);
            // pto: %3
            ;
            uint64_t v240 = (uint64_t) v12;
            TASSIGN(v239, v240);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
            uint16_t v241 = static_cast<uint16_t>(v26);
            uint16_t v242 = static_cast<uint16_t>(v26);
            TEXTRACT(v239, v213, v241, v242);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            // pto: %4
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
            // pto: %4
            ;
            uint64_t v244 = (uint64_t) v12;
            TASSIGN(v243, v244);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
            uint16_t v245 = static_cast<uint16_t>(v26);
            uint16_t v246 = static_cast<uint16_t>(v26);
            TEXTRACT(v243, v227, v245, v246);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v161, v161, v239, v243);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        };
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        // pto: %176
        ;
        v63.SetValidShape(v167, v25);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        if (v166 <= v35) {
          // pto: %179
          ;
          int64_t v247 = (int64_t) ((uint64_t) v166 * (uint64_t) v18);
          // pto: %5
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v248 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v120, v22);
          // pto: %5
          ;
          uint64_t v249 = (uint64_t) v14;
          TASSIGN(v248, v249);
          // pto: %182
          ;
          int64_t v250 = (int64_t) ((uint64_t) v125 + (uint64_t) v247);
          // pto: %183
          ;
          int64_t v251 = v250 < v26 ? v26 : v250;
          // pto: %184
          ;
          const int64_t v252 = 0;
          // pto: %184
          ;
          __gm__ bfloat16_t* v253 = PTOAS__GLOBAL_TENSOR_DATA(v57);
          // pto: %184
          ;
          const int64_t v254 = 1;
          // pto: %184
          ;
          const int64_t v255 = 1;
          // pto: %184
          ;
          const int64_t v256 = 1;
          // pto: %184
          ;
          int64_t v257 = v120 * v20;
          // pto: %184
          ;
          int64_t v258 = v256 * v257;
          // pto: %184
          ;
          pto::Shape<1, 1, 1, -1, 256> v259 = pto::Shape<1, 1, 1, -1, 256>(v254, v255, v256, v120, v22);
          // pto: %184
          ;
          pto::Stride<-1, -1, -1, -1, -1> v260 = pto::Stride<-1, -1, -1, -1, -1>(v255 * v258, v258, v257, v20, v17);
          // pto: %184
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v261 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v253 + (v252 + v124 * v20 + v251 * v17), v259, v260);
          TLOAD(v248, v261);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
          // pto: %6
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v262 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v22, v25);
          // pto: %6
          ;
          uint64_t v263 = (uint64_t) v15;
          TASSIGN(v262, v263);
          // pto: %188
          ;
          int64_t v264 = v247 / v18;
          // pto: %189
          ;
          int64_t v265 = v264 < v26 ? v26 : v264;
          // pto: %190
          ;
          __gm__ bfloat16_t* v266 = PTOAS__GLOBAL_TENSOR_DATA(v60);
          // pto: %190
          ;
          const int64_t v267 = 0;
          // pto: %190
          ;
          const int64_t v268 = 4194304;
          // pto: %190
          ;
          const int64_t v269 = 65536;
          // pto: %190
          ;
          const int64_t v270 = 256;
          // pto: %190
          ;
          pto::Shape<1, 8, 16, 16, 16> v271 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %190
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v272 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %190
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v273 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v266 + ((v267 + v140 * v268) + v142 * v269 + v265 * v270), v271, v272);
          TLOAD(v262, v273);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
          // pto: %7
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v274 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v120, v25);
          // pto: %7
          ;
          uint64_t v275 = (uint64_t) v12;
          TASSIGN(v274, v275);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
          uint16_t v276 = static_cast<uint16_t>(v26);
          uint16_t v277 = static_cast<uint16_t>(v26);
          TEXTRACT(v274, v248, v276, v277);
          // pto: %8
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v278 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v25);
          // pto: %8
          ;
          uint64_t v279 = (uint64_t) v12;
          TASSIGN(v278, v279);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
          uint16_t v280 = static_cast<uint16_t>(v26);
          uint16_t v281 = static_cast<uint16_t>(v26);
          TEXTRACT(v278, v262, v280, v281);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
          // pto: %9
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v282 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v120, v25);
          // pto: %9
          ;
          uint64_t v283 = (uint64_t) v13;
          TASSIGN(v282, v283);
          uint16_t v284 = static_cast<uint16_t>(v26);
          uint16_t v285 = static_cast<uint16_t>(v25);
          TEXTRACT(v282, v248, v284, v285);
          // pto: %10
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v25);
          // pto: %10
          ;
          uint64_t v287 = (uint64_t) v13;
          TASSIGN(v286, v287);
          uint16_t v288 = static_cast<uint16_t>(v25);
          uint16_t v289 = static_cast<uint16_t>(v26);
          TEXTRACT(v286, v262, v288, v289);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v61, v61, v274, v278);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          TMATMUL_ACC(v61, v61, v282, v286);
        } else {
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
          for (int64_t v290 = v26; v290 < v18; v290 += v17) {
            // pto: %192, %193, %194
            ;
            int64_t v291 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v166 + (uint64_t) v290) % v22) * (uint64_t) v18);
            // pto: %13
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v292 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v120, v18);
            // pto: %13
            ;
            uint64_t v293 = (uint64_t) v14;
            TASSIGN(v292, v293);
            // pto: %197
            ;
            int64_t v294 = (int64_t) ((uint64_t) v125 + (uint64_t) v291);
            // pto: %198
            ;
            int64_t v295 = v294 < v26 ? v26 : v294;
            // pto: %199
            ;
            const int64_t v296 = 0;
            // pto: %199
            ;
            __gm__ bfloat16_t* v297 = PTOAS__GLOBAL_TENSOR_DATA(v57);
            // pto: %199
            ;
            const int64_t v298 = 1;
            // pto: %199
            ;
            const int64_t v299 = 1;
            // pto: %199
            ;
            const int64_t v300 = 1;
            // pto: %199
            ;
            int64_t v301 = v120 * v20;
            // pto: %199
            ;
            int64_t v302 = v300 * v301;
            // pto: %199
            ;
            pto::Shape<1, 1, 1, -1, 16> v303 = pto::Shape<1, 1, 1, -1, 16>(v298, v299, v300, v120, v18);
            // pto: %199
            ;
            pto::Stride<-1, -1, -1, -1, -1> v304 = pto::Stride<-1, -1, -1, -1, -1>(v299 * v302, v302, v301, v20, v17);
            // pto: %199
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v305 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v297 + (v296 + v124 * v20 + v295 * v17), v303, v304);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
            TLOAD(v292, v305);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %14
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
            // pto: %14
            ;
            uint64_t v307 = (uint64_t) v15;
            TASSIGN(v306, v307);
            // pto: %203
            ;
            int64_t v308 = v291 / v18;
            // pto: %204
            ;
            int64_t v309 = v308 < v26 ? v26 : v308;
            // pto: %205
            ;
            __gm__ bfloat16_t* v310 = PTOAS__GLOBAL_TENSOR_DATA(v60);
            // pto: %205
            ;
            const int64_t v311 = 0;
            // pto: %205
            ;
            const int64_t v312 = 4194304;
            // pto: %205
            ;
            const int64_t v313 = 65536;
            // pto: %205
            ;
            const int64_t v314 = 256;
            // pto: %205
            ;
            pto::Shape<1, 8, 1, 16, 16> v315 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %205
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v316 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %205
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v317 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v310 + ((v311 + v140 * v312) + v142 * v313 + v309 * v314), v315, v316);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
            TLOAD(v306, v317);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %15
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v318 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v120, v18);
            // pto: %15
            ;
            uint64_t v319 = (uint64_t) v12;
            TASSIGN(v318, v319);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
            uint16_t v320 = static_cast<uint16_t>(v26);
            uint16_t v321 = static_cast<uint16_t>(v26);
            TEXTRACT(v318, v292, v320, v321);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
            // pto: %16
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v322 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
            // pto: %16
            ;
            uint64_t v323 = (uint64_t) v12;
            TASSIGN(v322, v323);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v324 = static_cast<uint16_t>(v26);
            uint16_t v325 = static_cast<uint16_t>(v26);
            TEXTRACT(v322, v306, v324, v325);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v61, v61, v318, v322);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        };
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      // pto: %206, %207
      ;
      int64_t v326 = (int64_t) ((uint64_t) v75 + (uint64_t) v36) % v22;
      // pto: %208
      ;
      // pto: %209
      ;
      int64_t v327 = v120 < v25 ? v120 : v25;
      v65.SetValidShape(v327, v25);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      if (v326 <= v35) {
        // pto: %211
        ;
        int64_t v328 = (int64_t) ((uint64_t) v326 * (uint64_t) v18);
        // pto: %18
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v329 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v120, v22);
        // pto: %18
        ;
        uint64_t v330 = (uint64_t) v11;
        TASSIGN(v329, v330);
        // pto: %214
        ;
        int64_t v331 = (int64_t) ((uint64_t) v125 + (uint64_t) v328);
        // pto: %215
        ;
        int64_t v332 = v331 < v26 ? v26 : v331;
        // pto: %216
        ;
        const int64_t v333 = 0;
        // pto: %216
        ;
        __gm__ bfloat16_t* v334 = PTOAS__GLOBAL_TENSOR_DATA(v57);
        // pto: %216
        ;
        const int64_t v335 = 1;
        // pto: %216
        ;
        const int64_t v336 = 1;
        // pto: %216
        ;
        const int64_t v337 = 1;
        // pto: %216
        ;
        int64_t v338 = v120 * v20;
        // pto: %216
        ;
        int64_t v339 = v337 * v338;
        // pto: %216
        ;
        pto::Shape<1, 1, 1, -1, 256> v340 = pto::Shape<1, 1, 1, -1, 256>(v335, v336, v337, v120, v22);
        // pto: %216
        ;
        pto::Stride<-1, -1, -1, -1, -1> v341 = pto::Stride<-1, -1, -1, -1, -1>(v336 * v339, v339, v338, v20, v17);
        // pto: %216
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v342 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v334 + (v333 + v124 * v20 + v332 * v17), v340, v341);
        TLOAD(v329, v342);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %19
        ;
        Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v22, v25);
        // pto: %19
        ;
        uint64_t v344 = (uint64_t) v12;
        TASSIGN(v343, v344);
        // pto: %220
        ;
        int64_t v345 = v328 / v18;
        // pto: %221
        ;
        int64_t v346 = v345 < v26 ? v26 : v345;
        // pto: %222
        ;
        __gm__ bfloat16_t* v347 = PTOAS__GLOBAL_TENSOR_DATA(v60);
        // pto: %222
        ;
        const int64_t v348 = 0;
        // pto: %222
        ;
        const int64_t v349 = 4194304;
        // pto: %222
        ;
        const int64_t v350 = 65536;
        // pto: %222
        ;
        const int64_t v351 = 256;
        // pto: %222
        ;
        pto::Shape<1, 8, 16, 16, 16> v352 = pto::Shape<1, 8, 16, 16, 16>();
        // pto: %222
        ;
        pto::Stride<4194304, 65536, 256, 16, 1> v353 = pto::Stride<4194304, 65536, 256, 16, 1>();
        // pto: %222
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v354 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v347 + ((v348 + v140 * v349) + v142 * v350 + v346 * v351), v352, v353);
        TLOAD(v343, v354);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %20
        ;
        Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v355 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v120, v25);
        // pto: %20
        ;
        uint64_t v356 = (uint64_t) v12;
        TASSIGN(v355, v356);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        uint16_t v357 = static_cast<uint16_t>(v26);
        uint16_t v358 = static_cast<uint16_t>(v26);
        TEXTRACT(v355, v329, v357, v358);
        // pto: %21
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v359 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v25);
        // pto: %21
        ;
        uint64_t v360 = (uint64_t) v12;
        TASSIGN(v359, v360);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v361 = static_cast<uint16_t>(v26);
        uint16_t v362 = static_cast<uint16_t>(v26);
        TEXTRACT(v359, v343, v361, v362);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        // pto: %22
        ;
        Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v363 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v120, v25);
        // pto: %22
        ;
        uint64_t v364 = (uint64_t) v13;
        TASSIGN(v363, v364);
        uint16_t v365 = static_cast<uint16_t>(v26);
        uint16_t v366 = static_cast<uint16_t>(v25);
        TEXTRACT(v363, v329, v365, v366);
        // pto: %23
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v367 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v25);
        // pto: %23
        ;
        uint64_t v368 = (uint64_t) v13;
        TASSIGN(v367, v368);
        uint16_t v369 = static_cast<uint16_t>(v25);
        uint16_t v370 = static_cast<uint16_t>(v26);
        TEXTRACT(v367, v343, v369, v370);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v161, v161, v355, v359);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        TMATMUL_ACC(v161, v161, v363, v367);
      } else {
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        for (int64_t v371 = v26; v371 < v18; v371 += v17) {
          // pto: %224, %225, %226
          ;
          int64_t v372 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v326 + (uint64_t) v371) % v22) * (uint64_t) v18);
          // pto: %26
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v373 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v120, v18);
          // pto: %26
          ;
          uint64_t v374 = (uint64_t) v11;
          TASSIGN(v373, v374);
          // pto: %229
          ;
          int64_t v375 = (int64_t) ((uint64_t) v125 + (uint64_t) v372);
          // pto: %230
          ;
          int64_t v376 = v375 < v26 ? v26 : v375;
          // pto: %231
          ;
          const int64_t v377 = 0;
          // pto: %231
          ;
          __gm__ bfloat16_t* v378 = PTOAS__GLOBAL_TENSOR_DATA(v57);
          // pto: %231
          ;
          const int64_t v379 = 1;
          // pto: %231
          ;
          const int64_t v380 = 1;
          // pto: %231
          ;
          const int64_t v381 = 1;
          // pto: %231
          ;
          int64_t v382 = v120 * v20;
          // pto: %231
          ;
          int64_t v383 = v381 * v382;
          // pto: %231
          ;
          pto::Shape<1, 1, 1, -1, 16> v384 = pto::Shape<1, 1, 1, -1, 16>(v379, v380, v381, v120, v18);
          // pto: %231
          ;
          pto::Stride<-1, -1, -1, -1, -1> v385 = pto::Stride<-1, -1, -1, -1, -1>(v380 * v383, v383, v382, v20, v17);
          // pto: %231
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v386 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v378 + (v377 + v124 * v20 + v376 * v17), v384, v385);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          TLOAD(v373, v386);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %27
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v387 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
          // pto: %27
          ;
          uint64_t v388 = (uint64_t) v12;
          TASSIGN(v387, v388);
          // pto: %235
          ;
          int64_t v389 = v372 / v18;
          // pto: %236
          ;
          int64_t v390 = v389 < v26 ? v26 : v389;
          // pto: %237
          ;
          __gm__ bfloat16_t* v391 = PTOAS__GLOBAL_TENSOR_DATA(v60);
          // pto: %237
          ;
          const int64_t v392 = 0;
          // pto: %237
          ;
          const int64_t v393 = 4194304;
          // pto: %237
          ;
          const int64_t v394 = 65536;
          // pto: %237
          ;
          const int64_t v395 = 256;
          // pto: %237
          ;
          pto::Shape<1, 8, 1, 16, 16> v396 = pto::Shape<1, 8, 1, 16, 16>();
          // pto: %237
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v397 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %237
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v398 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v391 + ((v392 + v140 * v393) + v142 * v394 + v390 * v395), v396, v397);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          TLOAD(v387, v398);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %28
          ;
          Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v399 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v120, v18);
          // pto: %28
          ;
          uint64_t v400 = (uint64_t) v12;
          TASSIGN(v399, v400);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          uint16_t v401 = static_cast<uint16_t>(v26);
          uint16_t v402 = static_cast<uint16_t>(v26);
          TEXTRACT(v399, v373, v401, v402);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %29
          ;
          Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v403 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
          // pto: %29
          ;
          uint64_t v404 = (uint64_t) v12;
          TASSIGN(v403, v404);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v405 = static_cast<uint16_t>(v26);
          uint16_t v406 = static_cast<uint16_t>(v26);
          TEXTRACT(v403, v387, v405, v406);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v161, v161, v399, v403);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        };
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %v4_wide_acc__rv_v2
      ;
      Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v407 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v120, v25);
      // pto: %v4_wide_acc__rv_v2
      ;
      uint64_t v408 = (uint64_t) v12;
      TASSIGN(v407, v408);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      for (int64_t v409 = v37; v409 < v22; v409 += v17) {
        // pto: %238, %239, %240
        ;
        int64_t v410 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v75 + (uint64_t) v409) % v22) * (uint64_t) v18);
        // pto: %v4_wide_tail_x__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v411 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v120, v18);
        // pto: %v4_wide_tail_x__tile
        ;
        uint64_t v412 = (uint64_t) v11;
        TASSIGN(v411, v412);
        // pto: %243
        ;
        int64_t v413 = (int64_t) ((uint64_t) v125 + (uint64_t) v410);
        // pto: %244
        ;
        int64_t v414 = v413 < v26 ? v26 : v413;
        // pto: %245
        ;
        const int64_t v415 = 0;
        // pto: %245
        ;
        __gm__ bfloat16_t* v416 = PTOAS__GLOBAL_TENSOR_DATA(v57);
        // pto: %245
        ;
        const int64_t v417 = 1;
        // pto: %245
        ;
        const int64_t v418 = 1;
        // pto: %245
        ;
        const int64_t v419 = 1;
        // pto: %245
        ;
        int64_t v420 = v120 * v20;
        // pto: %245
        ;
        int64_t v421 = v419 * v420;
        // pto: %245
        ;
        pto::Shape<1, 1, 1, -1, 16> v422 = pto::Shape<1, 1, 1, -1, 16>(v417, v418, v419, v120, v18);
        // pto: %245
        ;
        pto::Stride<-1, -1, -1, -1, -1> v423 = pto::Stride<-1, -1, -1, -1, -1>(v418 * v421, v421, v420, v20, v17);
        // pto: %245
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v424 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v416 + (v415 + v124 * v20 + v414 * v17), v422, v423);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v411, v424);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %v4_wide_tail_w__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v425 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
        // pto: %v4_wide_tail_w__tile
        ;
        uint64_t v426 = (uint64_t) v12;
        TASSIGN(v425, v426);
        // pto: %249
        ;
        int64_t v427 = v410 / v18;
        // pto: %250
        ;
        int64_t v428 = v427 < v26 ? v26 : v427;
        // pto: %251
        ;
        __gm__ bfloat16_t* v429 = PTOAS__GLOBAL_TENSOR_DATA(v60);
        // pto: %251
        ;
        const int64_t v430 = 0;
        // pto: %251
        ;
        const int64_t v431 = 4194304;
        // pto: %251
        ;
        const int64_t v432 = 65536;
        // pto: %251
        ;
        const int64_t v433 = 256;
        // pto: %251
        ;
        pto::Shape<1, 8, 1, 16, 16> v434 = pto::Shape<1, 8, 1, 16, 16>();
        // pto: %251
        ;
        pto::Stride<4194304, 65536, 256, 16, 1> v435 = pto::Stride<4194304, 65536, 256, 16, 1>();
        // pto: %251
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v436 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v429 + ((v430 + v140 * v431) + v142 * v432 + v428 * v433), v434, v435);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        TLOAD(v425, v436);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %31
        ;
        Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v437 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v120, v18);
        // pto: %31
        ;
        uint64_t v438 = (uint64_t) v12;
        TASSIGN(v437, v438);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v439 = static_cast<uint16_t>(v26);
        uint16_t v440 = static_cast<uint16_t>(v26);
        TEXTRACT(v437, v411, v439, v440);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        // pto: %32
        ;
        Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v441 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
        // pto: %32
        ;
        uint64_t v442 = (uint64_t) v12;
        TASSIGN(v441, v442);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v443 = static_cast<uint16_t>(v26);
        uint16_t v444 = static_cast<uint16_t>(v26);
        TEXTRACT(v441, v425, v443, v444);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v407, v407, v437, v441);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      // pto: %253, %254
      ;
      int64_t v445 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v38) + (uint64_t) v70);
      // pto: %255
      ;
      int64_t v446 = v445 < v26 ? v26 : v445;
      // pto: %accum__iter_v13_pview
      ;
      const int64_t v447 = 0;
      // pto: %accum__iter_v13_pview
      ;
      __gm__ float* v448 = PTOAS__GLOBAL_TENSOR_DATA(v48);
      // pto: %accum__iter_v13_pview
      ;
      const int64_t v449 = 1;
      // pto: %accum__iter_v13_pview
      ;
      const int64_t v450 = 1;
      // pto: %accum__iter_v13_pview
      ;
      const int64_t v451 = 1;
      // pto: %accum__iter_v13_pview
      ;
      int64_t v452 = v120 * v16;
      // pto: %accum__iter_v13_pview
      ;
      int64_t v453 = v451 * v452;
      // pto: %accum__iter_v13_pview
      ;
      pto::Shape<1, 1, 1, -1, 128> v454 = pto::Shape<1, 1, 1, -1, 128>(v449, v450, v451, v120, v25);
      // pto: %accum__iter_v13_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v455 = pto::Stride<-1, -1, -1, -1, -1>(v450 * v453, v453, v452, v16, v17);
      // pto: %accum__iter_v13_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v456 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v448 + (v447 + v124 * v16 + v446 * v17), v454, v455);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      TSTORE(v456, v407);
    } else {
      for (int64_t v457 = v26; v457 < v19; v457 += v17) {
        // pto: %256
        ;
        int64_t v458 = (int64_t) ((uint64_t) v72 + (uint64_t) v457);
        // pto: %257
        ;
        if (v458 < v5) {
          // pto: %258
          ;
          int64_t v459 = (int64_t) ((uint64_t) v458 * (uint64_t) v18);
          // pto: %259
          ;
          int64_t v460 = (int64_t) ((uint64_t) v8 - (uint64_t) v459);
          // pto: %260
          ;
          int64_t v461 = v460 < v18 ? v460 : v18;
          // pto: %262, %263, %264, %265, %261
          ;
          int32_t v462 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v458 * (uint64_t) v19) + (uint64_t) v6) * (uint64_t) v19) + (uint64_t) v69)];
          // pto: %266
          ;
          int64_t v463 = (int64_t) v462;
          // pto: %267
          ;
          int64_t v464 = v463 < v26 ? v26 : v463;
          // pto: %v4_narrow_acc__tile
          ;
          Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v465 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v18, v25);
          // pto: %v4_narrow_acc__tile
          ;
          uint64_t v466 = (uint64_t) v12;
          TASSIGN(v465, v466);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          for (int64_t v467 = v26; v467 < v18; v467 += v17) {
            // pto: %268
            ;
            int64_t v468 = (int64_t) ((uint64_t) v467 * (uint64_t) v18);
            // pto: %269, %270
            ;
            int64_t v469 = (int64_t) ((uint64_t) v464 + (uint64_t) v468) % v22;
            // pto: %271
            ;
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            if (v469 <= v35) {
              // pto: %272
              ;
              int64_t v470 = (int64_t) ((uint64_t) v469 * (uint64_t) v18);
              // pto: %v4_narrow_packet_x__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v471 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v461, v22);
              // pto: %v4_narrow_packet_x__tile
              ;
              uint64_t v472 = (uint64_t) v12;
              TASSIGN(v471, v472);
              // pto: %273
              ;
              int64_t v473 = v459 < v26 ? v26 : v459;
              // pto: %274, %275
              ;
              int64_t v474 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v33) + (uint64_t) v470);
              // pto: %276
              ;
              int64_t v475 = v474 < v26 ? v26 : v474;
              // pto: %277
              ;
              const int64_t v476 = 0;
              // pto: %277
              ;
              __gm__ bfloat16_t* v477 = PTOAS__GLOBAL_TENSOR_DATA(v57);
              // pto: %277
              ;
              const int64_t v478 = 1;
              // pto: %277
              ;
              const int64_t v479 = 1;
              // pto: %277
              ;
              const int64_t v480 = 1;
              // pto: %277
              ;
              int64_t v481 = v461 * v20;
              // pto: %277
              ;
              int64_t v482 = v480 * v481;
              // pto: %277
              ;
              pto::Shape<1, 1, 1, -1, 256> v483 = pto::Shape<1, 1, 1, -1, 256>(v478, v479, v480, v461, v22);
              // pto: %277
              ;
              pto::Stride<-1, -1, -1, -1, -1> v484 = pto::Stride<-1, -1, -1, -1, -1>(v479 * v482, v482, v481, v20, v17);
              // pto: %277
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v485 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v477 + (v476 + v473 * v20 + v475 * v17), v483, v484);
              TLOAD(v471, v485);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %v4_narrow_packet_w__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v486 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v22, v25);
              // pto: %v4_narrow_packet_w__tile
              ;
              uint64_t v487 = (uint64_t) v11;
              TASSIGN(v486, v487);
              // pto: %278
              ;
              int64_t v488 = v6 < v26 ? v26 : v6;
              // pto: %279
              ;
              int64_t v489 = v70 / v18;
              // pto: %280
              ;
              int64_t v490 = v489 < v26 ? v26 : v489;
              // pto: %281
              ;
              int64_t v491 = v470 / v18;
              // pto: %282
              ;
              int64_t v492 = v491 < v26 ? v26 : v491;
              // pto: %283
              ;
              __gm__ bfloat16_t* v493 = PTOAS__GLOBAL_TENSOR_DATA(v60);
              // pto: %283
              ;
              const int64_t v494 = 0;
              // pto: %283
              ;
              const int64_t v495 = 4194304;
              // pto: %283
              ;
              const int64_t v496 = 65536;
              // pto: %283
              ;
              const int64_t v497 = 256;
              // pto: %283
              ;
              pto::Shape<1, 8, 16, 16, 16> v498 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %283
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v499 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %283
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v500 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v493 + ((v494 + v488 * v495) + v490 * v496 + v492 * v497), v498, v499);
              TLOAD(v486, v500);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %v4_narrow_acc__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v501 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v461, v25);
              // pto: %v4_narrow_acc__iter_v1_l0_a
              ;
              uint64_t v502 = (uint64_t) v12;
              TASSIGN(v501, v502);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              uint16_t v503 = static_cast<uint16_t>(v26);
              uint16_t v504 = static_cast<uint16_t>(v26);
              TEXTRACT(v501, v471, v503, v504);
              // pto: %v4_narrow_acc__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v505 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v25);
              // pto: %v4_narrow_acc__iter_v1_l0_b
              ;
              uint64_t v506 = (uint64_t) v12;
              TASSIGN(v505, v506);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v507 = static_cast<uint16_t>(v26);
              uint16_t v508 = static_cast<uint16_t>(v26);
              TEXTRACT(v505, v486, v507, v508);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              // pto: %33
              ;
              Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v509 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v461, v25);
              // pto: %33
              ;
              uint64_t v510 = (uint64_t) v13;
              TASSIGN(v509, v510);
              uint16_t v511 = static_cast<uint16_t>(v26);
              uint16_t v512 = static_cast<uint16_t>(v25);
              TEXTRACT(v509, v471, v511, v512);
              // pto: %34
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v513 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v25);
              // pto: %34
              ;
              uint64_t v514 = (uint64_t) v13;
              TASSIGN(v513, v514);
              uint16_t v515 = static_cast<uint16_t>(v25);
              uint16_t v516 = static_cast<uint16_t>(v26);
              TEXTRACT(v513, v486, v515, v516);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              // pto: %284
              ;
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              if (v467 == v26) {
                pipe_barrier(PIPE_M);
                TMATMUL(v465, v501, v505);
              } else {
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v465, v465, v501, v505);
              };
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              TMATMUL_ACC(v465, v465, v509, v513);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              for (int64_t v517 = v26; v517 < v18; v517 += v17) {
                // pto: %285, %286, %287
                ;
                int64_t v518 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v469 + (uint64_t) v517) % v22) * (uint64_t) v18);
                // pto: %v4_narrow_wrap_x__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v519 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v461, v18);
                // pto: %v4_narrow_wrap_x__tile
                ;
                uint64_t v520 = (uint64_t) v12;
                TASSIGN(v519, v520);
                // pto: %288
                ;
                int64_t v521 = v459 < v26 ? v26 : v459;
                // pto: %289, %290
                ;
                int64_t v522 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v33) + (uint64_t) v518);
                // pto: %291
                ;
                int64_t v523 = v522 < v26 ? v26 : v522;
                // pto: %292
                ;
                const int64_t v524 = 0;
                // pto: %292
                ;
                __gm__ bfloat16_t* v525 = PTOAS__GLOBAL_TENSOR_DATA(v57);
                // pto: %292
                ;
                const int64_t v526 = 1;
                // pto: %292
                ;
                const int64_t v527 = 1;
                // pto: %292
                ;
                const int64_t v528 = 1;
                // pto: %292
                ;
                int64_t v529 = v461 * v20;
                // pto: %292
                ;
                int64_t v530 = v528 * v529;
                // pto: %292
                ;
                pto::Shape<1, 1, 1, -1, 16> v531 = pto::Shape<1, 1, 1, -1, 16>(v526, v527, v528, v461, v18);
                // pto: %292
                ;
                pto::Stride<-1, -1, -1, -1, -1> v532 = pto::Stride<-1, -1, -1, -1, -1>(v527 * v530, v530, v529, v20, v17);
                // pto: %292
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v533 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v525 + (v524 + v521 * v20 + v523 * v17), v531, v532);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                TLOAD(v519, v533);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %v4_narrow_wrap_w__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v534 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
                // pto: %v4_narrow_wrap_w__tile
                ;
                uint64_t v535 = (uint64_t) v11;
                TASSIGN(v534, v535);
                // pto: %293
                ;
                int64_t v536 = v6 < v26 ? v26 : v6;
                // pto: %294
                ;
                int64_t v537 = v70 / v18;
                // pto: %295
                ;
                int64_t v538 = v537 < v26 ? v26 : v537;
                // pto: %296
                ;
                int64_t v539 = v518 / v18;
                // pto: %297
                ;
                int64_t v540 = v539 < v26 ? v26 : v539;
                // pto: %298
                ;
                __gm__ bfloat16_t* v541 = PTOAS__GLOBAL_TENSOR_DATA(v60);
                // pto: %298
                ;
                const int64_t v542 = 0;
                // pto: %298
                ;
                const int64_t v543 = 4194304;
                // pto: %298
                ;
                const int64_t v544 = 65536;
                // pto: %298
                ;
                const int64_t v545 = 256;
                // pto: %298
                ;
                pto::Shape<1, 8, 1, 16, 16> v546 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %298
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v547 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %298
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v548 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v541 + ((v542 + v536 * v543) + v538 * v544 + v540 * v545), v546, v547);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v534, v548);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %36
                ;
                Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v549 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v461, v18);
                // pto: %36
                ;
                uint64_t v550 = (uint64_t) v12;
                TASSIGN(v549, v550);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                uint16_t v551 = static_cast<uint16_t>(v26);
                uint16_t v552 = static_cast<uint16_t>(v26);
                TEXTRACT(v549, v519, v551, v552);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                // pto: %37
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v553 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
                // pto: %37
                ;
                uint64_t v554 = (uint64_t) v12;
                TASSIGN(v553, v554);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v555 = static_cast<uint16_t>(v26);
                uint16_t v556 = static_cast<uint16_t>(v26);
                TEXTRACT(v553, v534, v555, v556);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                // pto: %300, %301
                ;
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                if ((int64_t) ((uint64_t) v468 + (uint64_t) v517) == v26) {
                  pipe_barrier(PIPE_M);
                  TMATMUL(v465, v549, v553);
                } else {
                  pipe_barrier(PIPE_M);
                  TMATMUL_ACC(v465, v465, v549, v553);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          // pto: %303
          ;
          int64_t v557 = v459 < v26 ? v26 : v459;
          // pto: %304, %305
          ;
          int64_t v558 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v38) + (uint64_t) v70);
          // pto: %306
          ;
          int64_t v559 = v558 < v26 ? v26 : v558;
          // pto: %accum__iter_v16_pview
          ;
          __gm__ float* v560 = PTOAS__GLOBAL_TENSOR_DATA(v48);
          // pto: %accum__iter_v16_pview
          ;
          const int64_t v561 = 0;
          // pto: %accum__iter_v16_pview
          ;
          const int64_t v562 = 8192;
          // pto: %accum__iter_v16_pview
          ;
          pto::Shape<1, 1, 1, 16, 128> v563 = pto::Shape<1, 1, 1, 16, 128>();
          // pto: %accum__iter_v16_pview
          ;
          pto::Stride<131072, 131072, 131072, 8192, 1> v564 = pto::Stride<131072, 131072, 131072, 8192, 1>();
          // pto: %accum__iter_v16_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v565 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v560 + (v561 + v557 * v562 + v559), v563, v564);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          pipe_barrier(PIPE_FIX);
          TSTORE(v565, v465);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        };
      };
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}