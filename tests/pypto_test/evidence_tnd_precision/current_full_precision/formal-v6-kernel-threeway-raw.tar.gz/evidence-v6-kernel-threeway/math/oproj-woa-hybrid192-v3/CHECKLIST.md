# 验证清单

- [x] 全 T1…256、真实 group AST、完整 K16 次序、尾行/回退检查。
- [x] helper 循环与各自冻结来源 AST 一致。
- [ ] 227 无设备身份预检。
- [ ] 真实 orchestration GCC 与全部 CCEC。
- [ ] 生成代码共同父 GM / 分支内 L0C 审查。
- [ ] NPU 精度和性能（本轮不提交）。
