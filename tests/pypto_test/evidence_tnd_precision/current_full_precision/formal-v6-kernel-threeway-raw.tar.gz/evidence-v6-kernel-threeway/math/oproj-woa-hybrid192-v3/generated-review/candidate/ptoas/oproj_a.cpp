#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_a(__gm__ float* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int32_t v9, int32_t v10) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c131072_i64
  const int64_t v11 = 131072;
  // pto: %c196608_i64
  const int64_t v12 = 196608;
  // pto: %c0_i64
  const int64_t v13 = 0;
  // pto: %c32768_i64
  const int64_t v14 = 32768;
  // pto: %c65536_i64
  const int64_t v15 = 65536;
  // pto: %c8192_index
  const int64_t v16 = 8192;
  // pto: %c1_index
  const int64_t v17 = 1;
  // pto: %c16_index
  const int64_t v18 = 16;
  // pto: %c8_index
  const int64_t v19 = 8;
  // pto: %c32768_index
  const int64_t v20 = 32768;
  const int64_t v21 = 64;
  // pto: %c256_index
  const int64_t v22 = 256;
  // pto: %c4194304_index
  const int64_t v23 = 4194304;
  // pto: %c65536_index
  const int64_t v24 = 65536;
  const int64_t v25 = 128;
  // pto: %c0_index
  const int64_t v26 = 0;
  // pto: %c7_index
  const int64_t v27 = 7;
  // pto: %c2_index
  const int64_t v28 = 2;
  // pto: %c3_index
  const int64_t v29 = 3;
  // pto: %c4_index
  const int64_t v30 = 4;
  // pto: %c5_index
  const int64_t v31 = 5;
  // pto: %c6_index
  const int64_t v32 = 6;
  // pto: %c240_index
  const int64_t v33 = 240;
  // pto: %c4096_index
  const int64_t v34 = 4096;
  // pto: %c15_index
  const int64_t v35 = 15;
  // pto: %c1024_index
  const int64_t v36 = 1024;
  // pto: %c127_index
  const int64_t v37 = 127;
  // pto: %289
  int64_t v38 = (int64_t) ((uint64_t) v8 + (uint64_t) v37);
  // pto: %accum__iter_v1_view
  const int64_t v39 = 1;
  // pto: %accum__iter_v1_view
  const int64_t v40 = 1;
  // pto: %accum__iter_v1_view
  const int64_t v41 = 1;
  // pto: %accum__iter_v1_view
  int64_t v42 = v38 * v16;
  // pto: %accum__iter_v1_view
  int64_t v43 = v41 * v42;
  // pto: %accum__iter_v1_view
  pto::Shape<1, 1, 1, -1, -1> v44 = pto::Shape<1, 1, 1, -1, -1>(v39, v40, v41, v38, v16);
  // pto: %accum__iter_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v45 = pto::Stride<-1, -1, -1, -1, -1>(v40 * v43, v43, v42, v16, v17);
  // pto: %accum__iter_v1_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v46 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v44, v45);
  // pto: %heads__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v50 = (int64_t) v8;
  // pto: %heads__ssa_v0_view
  int64_t v51 = v50 * v20;
  // pto: %heads__ssa_v0_view
  int64_t v52 = v49 * v51;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v47, v48, v49, v50, v20);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v48 * v52, v52, v51, v20, v17);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v53, v54);
  // pto: %wo_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v56 = pto::Shape<-1, -1, -1, -1, -1>(v19, v21, v22, v18, v18);
  // pto: %wo_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v57 = pto::Stride<-1, -1, -1, -1, -1>(v23, v24, v22, v18, v17);
  // pto: %wo_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v58 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v4, v56, v57);
  // pto: %seed_fast_acc__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v59 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v25, v25);
  // pto: %seed_fast_acc__phi_v7
  uint64_t v60 = (uint64_t) v13;
  TASSIGN(v59, v60);
  // pto: %174
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v61 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v25, v25);
  // pto: %174
  uint64_t v62 = (uint64_t) v13;
  TASSIGN(v61, v62);
  // pto: %206
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v63 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v25, v25);
  // pto: %206
  uint64_t v64 = (uint64_t) v13;
  TASSIGN(v63, v64);
  // pto: %seed_narrow_acc__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v65 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v18, v25);
  // pto: %seed_narrow_acc__phi_v7
  uint64_t v66 = (uint64_t) v13;
  TASSIGN(v65, v66);
  // pto: %seed_block__ssa_v0
  int64_t v67 = (int64_t) v9;
  // pto: %37
  int64_t v68 = (int64_t) ((uint64_t) v67 * (uint64_t) v25);
  // pto: %38, %39
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  for (int64_t v69 = v26; v69 < ((int64_t) ((uint64_t) v5 + (uint64_t) v27) / v19); v69 += v17) {
    // pto: %40
    ;
    int64_t v70 = (int64_t) ((uint64_t) v69 * (uint64_t) v19);
    // pto: %flat_offset, %41, %42, %t__tile
    ;
    int32_t v71 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v69 * (uint64_t) v21) + (uint64_t) v6) * (uint64_t) v19) + (uint64_t) v67)];
    // pto: %43
    ;
    int64_t v72 = (int64_t) v71;
    // pto: %44
    ;
    int64_t v73 = v72 < v26 ? v26 : v72;
    // pto: %45
    ;
    int64_t v74 = (int64_t) ((uint64_t) v70 + (uint64_t) v17);
    // pto: %46
    ;
    // pto: %seed_same_start__phi_v3
    ;
    int64_t v75;
    if (v74 < v5) {
      // pto: %49, %50, %51, %52, %47
      ;
      int32_t v76 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v74 * (uint64_t) v19) + (uint64_t) v6) * (uint64_t) v19) + (uint64_t) v67)];
      // pto: %53
      ;
      int64_t v77 = (int64_t) v76;
      // pto: %54
      ;
      int64_t v78 = v77 < v26 ? v26 : v77;
      // pto: %55, %seed_same_start__phi_v2
      ;
      v75 = v78 != v73 ? v26 : v17;
    } else {
      v75 = v17;
    };
    // pto: %56
    ;
    int64_t v79 = (int64_t) ((uint64_t) v70 + (uint64_t) v28);
    // pto: %57
    ;
    // pto: %seed_same_start__phi_v6
    ;
    int64_t v80;
    if (v79 < v5) {
      // pto: %60, %61, %62, %63, %58
      ;
      int32_t v81 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v79 * (uint64_t) v19) + (uint64_t) v6) * (uint64_t) v19) + (uint64_t) v67)];
      // pto: %64
      ;
      int64_t v82 = (int64_t) v81;
      // pto: %65
      ;
      int64_t v83 = v82 < v26 ? v26 : v82;
      // pto: %66, %seed_same_start__phi_v5
      ;
      int64_t v84 = v83 != v73 ? v26 : v75;
      v80 = v84;
    } else {
      v80 = v75;
    };
    // pto: %67
    ;
    int64_t v85 = (int64_t) ((uint64_t) v70 + (uint64_t) v29);
    // pto: %68
    ;
    // pto: %seed_same_start__phi_v9
    ;
    int64_t v86;
    if (v85 < v5) {
      // pto: %71, %72, %73, %74, %69
      ;
      int32_t v87 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v85 * (uint64_t) v19) + (uint64_t) v6) * (uint64_t) v19) + (uint64_t) v67)];
      // pto: %75
      ;
      int64_t v88 = (int64_t) v87;
      // pto: %76
      ;
      int64_t v89 = v88 < v26 ? v26 : v88;
      // pto: %77, %seed_same_start__phi_v8
      ;
      int64_t v90 = v89 != v73 ? v26 : v80;
      v86 = v90;
    } else {
      v86 = v80;
    };
    // pto: %78
    ;
    int64_t v91 = (int64_t) ((uint64_t) v70 + (uint64_t) v30);
    // pto: %79
    ;
    // pto: %seed_same_start__phi_v12
    ;
    int64_t v92;
    if (v91 < v5) {
      // pto: %82, %83, %84, %85, %80
      ;
      int32_t v93 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v91 * (uint64_t) v19) + (uint64_t) v6) * (uint64_t) v19) + (uint64_t) v67)];
      // pto: %86
      ;
      int64_t v94 = (int64_t) v93;
      // pto: %87
      ;
      int64_t v95 = v94 < v26 ? v26 : v94;
      // pto: %88, %seed_same_start__phi_v11
      ;
      int64_t v96 = v95 != v73 ? v26 : v86;
      v92 = v96;
    } else {
      v92 = v86;
    };
    // pto: %89
    ;
    int64_t v97 = (int64_t) ((uint64_t) v70 + (uint64_t) v31);
    // pto: %90
    ;
    // pto: %seed_same_start__phi_v15
    ;
    int64_t v98;
    if (v97 < v5) {
      // pto: %93, %94, %95, %96, %91
      ;
      int32_t v99 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v97 * (uint64_t) v19) + (uint64_t) v6) * (uint64_t) v19) + (uint64_t) v67)];
      // pto: %97
      ;
      int64_t v100 = (int64_t) v99;
      // pto: %98
      ;
      int64_t v101 = v100 < v26 ? v26 : v100;
      // pto: %99, %seed_same_start__phi_v14
      ;
      int64_t v102 = v101 != v73 ? v26 : v92;
      v98 = v102;
    } else {
      v98 = v92;
    };
    // pto: %100
    ;
    int64_t v103 = (int64_t) ((uint64_t) v70 + (uint64_t) v32);
    // pto: %101
    ;
    // pto: %seed_same_start__phi_v18
    ;
    int64_t v104;
    if (v103 < v5) {
      // pto: %104, %105, %106, %107, %102
      ;
      int32_t v105 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v103 * (uint64_t) v19) + (uint64_t) v6) * (uint64_t) v19) + (uint64_t) v67)];
      // pto: %108
      ;
      int64_t v106 = (int64_t) v105;
      // pto: %109
      ;
      int64_t v107 = v106 < v26 ? v26 : v106;
      // pto: %110, %seed_same_start__phi_v17
      ;
      int64_t v108 = v107 != v73 ? v26 : v98;
      v104 = v108;
    } else {
      v104 = v98;
    };
    // pto: %111
    ;
    int64_t v109 = (int64_t) ((uint64_t) v70 + (uint64_t) v27);
    // pto: %112
    ;
    // pto: %seed_same_start__phi_v21
    ;
    int64_t v110;
    if (v109 < v5) {
      // pto: %115, %116, %117, %118, %113
      ;
      int32_t v111 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v109 * (uint64_t) v19) + (uint64_t) v6) * (uint64_t) v19) + (uint64_t) v67)];
      // pto: %119
      ;
      int64_t v112 = (int64_t) v111;
      // pto: %120
      ;
      int64_t v113 = v112 < v26 ? v26 : v112;
      // pto: %121, %seed_same_start__phi_v20
      ;
      int64_t v114 = v113 != v73 ? v26 : v104;
      v110 = v114;
    } else {
      v110 = v104;
    };
    // pto: %122, %seed_same_start__phi_v25
    ;
    int64_t v115 = v73 > v33 ? v26 : v110;
    // pto: %123
    ;
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    if (v115 == v17) {
      int64_t v116 = (int64_t) ((uint64_t) v69 * (uint64_t) v25);
      // pto: %125
      ;
      int64_t v117 = (int64_t) ((uint64_t) v8 - (uint64_t) v116);
      // pto: %126
      ;
      int64_t v118 = v117 < v25 ? v117 : v25;
      // pto: %127
      ;
      int64_t v119 = (int64_t) ((uint64_t) v73 * (uint64_t) v18);
      // pto: %seed_fast_seed_x__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v118, v22);
      // pto: %seed_fast_seed_x__tile
      ;
      uint64_t v121 = (uint64_t) v11;
      TASSIGN(v120, v121);
      // pto: %128
      ;
      int64_t v122 = v116 < v26 ? v26 : v116;
      // pto: %129
      ;
      int64_t v123 = (int64_t) ((uint64_t) v6 * (uint64_t) v34);
      // pto: %130
      ;
      int64_t v124 = (int64_t) ((uint64_t) v123 + (uint64_t) v119);
      // pto: %131
      ;
      int64_t v125 = v124 < v26 ? v26 : v124;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v126 = 0;
      // pto: %heads__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v127 = PTOAS__GLOBAL_TENSOR_DATA(v55);
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v128 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v129 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v130 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      int64_t v131 = v118 * v20;
      // pto: %heads__ssa_v0_pview
      ;
      int64_t v132 = v130 * v131;
      // pto: %heads__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 256> v133 = pto::Shape<1, 1, 1, -1, 256>(v128, v129, v130, v118, v22);
      // pto: %heads__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v134 = pto::Stride<-1, -1, -1, -1, -1>(v129 * v132, v132, v131, v20, v17);
      // pto: %heads__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v135 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v127 + (v126 + v122 * v20 + v125 * v17), v133, v134);
      TLOAD(v120, v135);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %seed_fast_seed_w__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v22, v25);
      // pto: %seed_fast_seed_w__tile
      ;
      uint64_t v137 = (uint64_t) v12;
      TASSIGN(v136, v137);
      // pto: %132
      ;
      int64_t v138 = v6 < v26 ? v26 : v6;
      // pto: %133
      ;
      int64_t v139 = v68 / v18;
      // pto: %134
      ;
      int64_t v140 = v139 < v26 ? v26 : v139;
      // pto: %135
      ;
      int64_t v141 = v119 / v18;
      // pto: %136
      ;
      int64_t v142 = v141 < v26 ? v26 : v141;
      // pto: %wo_a__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v143 = PTOAS__GLOBAL_TENSOR_DATA(v58);
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v144 = 0;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v145 = 4194304;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v146 = 65536;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v147 = 256;
      // pto: %wo_a__ssa_v0_pview
      ;
      pto::Shape<1, 8, 16, 16, 16> v148 = pto::Shape<1, 8, 16, 16, 16>();
      // pto: %wo_a__ssa_v0_pview
      ;
      pto::Stride<4194304, 65536, 256, 16, 1> v149 = pto::Stride<4194304, 65536, 256, 16, 1>();
      // pto: %wo_a__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v150 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v143 + ((v144 + v138 * v145) + v140 * v146 + v142 * v147), v148, v149);
      TLOAD(v136, v150);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %seed_fast_acc__tile_l0_init_storage
      ;
      Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v151 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v25, v25);
      // pto: %seed_fast_acc__tile_l0_init_storage
      ;
      uint64_t v152 = (uint64_t) v13;
      TASSIGN(v151, v152);
      v151.SetValidShape(v118, v25);
      // pto: %seed_fast_acc__tile_l0_a
      ;
      Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v153 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v118, v25);
      // pto: %seed_fast_acc__tile_l0_a
      ;
      uint64_t v154 = (uint64_t) v13;
      TASSIGN(v153, v154);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      uint16_t v155 = static_cast<uint16_t>(v26);
      uint16_t v156 = static_cast<uint16_t>(v26);
      TEXTRACT(v153, v120, v155, v156);
      // pto: %seed_fast_acc__tile_l0_b
      ;
      Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v25);
      // pto: %seed_fast_acc__tile_l0_b
      ;
      uint64_t v158 = (uint64_t) v14;
      TASSIGN(v157, v158);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      uint16_t v159 = static_cast<uint16_t>(v26);
      uint16_t v160 = static_cast<uint16_t>(v26);
      TEXTRACT(v157, v136, v159, v160);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v161 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v118, v25);
      // pto: %0
      ;
      uint64_t v162 = (uint64_t) v14;
      TASSIGN(v161, v162);
      uint16_t v163 = static_cast<uint16_t>(v26);
      uint16_t v164 = static_cast<uint16_t>(v25);
      TEXTRACT(v161, v120, v163, v164);
      // pto: %1
      ;
      Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v25);
      // pto: %1
      ;
      uint64_t v166 = (uint64_t) v13;
      TASSIGN(v165, v166);
      uint16_t v167 = static_cast<uint16_t>(v25);
      uint16_t v168 = static_cast<uint16_t>(v26);
      TEXTRACT(v165, v136, v167, v168);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      TMATMUL(v151, v153, v157);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v151, v151, v161, v165);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      for (int64_t v169 = v17; v169 < v35; v169 += v28) {
        // pto: %137
        ;
        int64_t v170 = (int64_t) ((uint64_t) v169 * (uint64_t) v18);
        // pto: %138, %139
        ;
        int64_t v171 = (int64_t) ((uint64_t) v73 + (uint64_t) v170) % v22;
        // pto: %142, %141, %143
        ;
        int64_t v172 = (int64_t) ((uint64_t) v73 + (uint64_t) ((int64_t) (uint64_t) v170 + (uint64_t) v18)) % v22;
        // pto: %144
        ;
        // pto: %145
        ;
        int64_t v173 = v118 < v25 ? v118 : v25;
        v59.SetValidShape(v173, v25);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        if (v171 <= v33) {
          // pto: %146
          ;
          int64_t v174 = (int64_t) ((uint64_t) v171 * (uint64_t) v18);
          // pto: %seed_fast_packet_x__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v118, v22);
          // pto: %seed_fast_packet_x__tile
          ;
          uint64_t v176 = (uint64_t) v11;
          TASSIGN(v175, v176);
          // pto: %149
          ;
          int64_t v177 = (int64_t) ((uint64_t) v123 + (uint64_t) v174);
          // pto: %150
          ;
          int64_t v178 = v177 < v26 ? v26 : v177;
          // pto: %151
          ;
          const int64_t v179 = 0;
          // pto: %151
          ;
          __gm__ bfloat16_t* v180 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %151
          ;
          const int64_t v181 = 1;
          // pto: %151
          ;
          const int64_t v182 = 1;
          // pto: %151
          ;
          const int64_t v183 = 1;
          // pto: %151
          ;
          int64_t v184 = v118 * v20;
          // pto: %151
          ;
          int64_t v185 = v183 * v184;
          // pto: %151
          ;
          pto::Shape<1, 1, 1, -1, 256> v186 = pto::Shape<1, 1, 1, -1, 256>(v181, v182, v183, v118, v22);
          // pto: %151
          ;
          pto::Stride<-1, -1, -1, -1, -1> v187 = pto::Stride<-1, -1, -1, -1, -1>(v182 * v185, v185, v184, v20, v17);
          // pto: %151
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v188 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v180 + (v179 + v122 * v20 + v178 * v17), v186, v187);
          TLOAD(v175, v188);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          // pto: %seed_fast_packet_w__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v189 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v22, v25);
          // pto: %seed_fast_packet_w__tile
          ;
          uint64_t v190 = (uint64_t) v12;
          TASSIGN(v189, v190);
          // pto: %155
          ;
          int64_t v191 = v174 / v18;
          // pto: %156
          ;
          int64_t v192 = v191 < v26 ? v26 : v191;
          // pto: %157
          ;
          __gm__ bfloat16_t* v193 = PTOAS__GLOBAL_TENSOR_DATA(v58);
          // pto: %157
          ;
          const int64_t v194 = 0;
          // pto: %157
          ;
          const int64_t v195 = 4194304;
          // pto: %157
          ;
          const int64_t v196 = 65536;
          // pto: %157
          ;
          const int64_t v197 = 256;
          // pto: %157
          ;
          pto::Shape<1, 8, 16, 16, 16> v198 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %157
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v199 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %157
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v200 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v193 + ((v194 + v138 * v195) + v140 * v196 + v192 * v197), v198, v199);
          TLOAD(v189, v200);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
          // pto: %seed_fast_acc__iter_v1_l0_a
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v201 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v118, v25);
          // pto: %seed_fast_acc__iter_v1_l0_a
          ;
          uint64_t v202 = (uint64_t) v13;
          TASSIGN(v201, v202);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          uint16_t v203 = static_cast<uint16_t>(v26);
          uint16_t v204 = static_cast<uint16_t>(v26);
          TEXTRACT(v201, v175, v203, v204);
          // pto: %seed_fast_acc__iter_v1_l0_b
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v25);
          // pto: %seed_fast_acc__iter_v1_l0_b
          ;
          uint64_t v206 = (uint64_t) v14;
          TASSIGN(v205, v206);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
          uint16_t v207 = static_cast<uint16_t>(v26);
          uint16_t v208 = static_cast<uint16_t>(v26);
          TEXTRACT(v205, v189, v207, v208);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
          // pto: %3
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v209 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v118, v25);
          // pto: %3
          ;
          uint64_t v210 = (uint64_t) v14;
          TASSIGN(v209, v210);
          uint16_t v211 = static_cast<uint16_t>(v26);
          uint16_t v212 = static_cast<uint16_t>(v25);
          TEXTRACT(v209, v175, v211, v212);
          // pto: %4
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v25);
          // pto: %4
          ;
          uint64_t v214 = (uint64_t) v13;
          TASSIGN(v213, v214);
          uint16_t v215 = static_cast<uint16_t>(v25);
          uint16_t v216 = static_cast<uint16_t>(v26);
          TEXTRACT(v213, v189, v215, v216);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v151, v151, v201, v205);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
          TMATMUL_ACC(v151, v151, v209, v213);
        } else {
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
          for (int64_t v217 = v26; v217 < v18; v217 += v17) {
            // pto: %158, %159, %160
            ;
            int64_t v218 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v171 + (uint64_t) v217) % v22) * (uint64_t) v18);
            // pto: %seed_fast_wrap_x__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v219 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v118, v18);
            // pto: %seed_fast_wrap_x__tile
            ;
            uint64_t v220 = (uint64_t) v11;
            TASSIGN(v219, v220);
            // pto: %163
            ;
            int64_t v221 = (int64_t) ((uint64_t) v123 + (uint64_t) v218);
            // pto: %164
            ;
            int64_t v222 = v221 < v26 ? v26 : v221;
            // pto: %165
            ;
            const int64_t v223 = 0;
            // pto: %165
            ;
            __gm__ bfloat16_t* v224 = PTOAS__GLOBAL_TENSOR_DATA(v55);
            // pto: %165
            ;
            const int64_t v225 = 1;
            // pto: %165
            ;
            const int64_t v226 = 1;
            // pto: %165
            ;
            const int64_t v227 = 1;
            // pto: %165
            ;
            int64_t v228 = v118 * v20;
            // pto: %165
            ;
            int64_t v229 = v227 * v228;
            // pto: %165
            ;
            pto::Shape<1, 1, 1, -1, 16> v230 = pto::Shape<1, 1, 1, -1, 16>(v225, v226, v227, v118, v18);
            // pto: %165
            ;
            pto::Stride<-1, -1, -1, -1, -1> v231 = pto::Stride<-1, -1, -1, -1, -1>(v226 * v229, v229, v228, v20, v17);
            // pto: %165
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v232 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v224 + (v223 + v122 * v20 + v222 * v17), v230, v231);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            TLOAD(v219, v232);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
            // pto: %seed_fast_wrap_w__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
            // pto: %seed_fast_wrap_w__tile
            ;
            uint64_t v234 = (uint64_t) v12;
            TASSIGN(v233, v234);
            // pto: %169
            ;
            int64_t v235 = v218 / v18;
            // pto: %170
            ;
            int64_t v236 = v235 < v26 ? v26 : v235;
            // pto: %171
            ;
            __gm__ bfloat16_t* v237 = PTOAS__GLOBAL_TENSOR_DATA(v58);
            // pto: %171
            ;
            const int64_t v238 = 0;
            // pto: %171
            ;
            const int64_t v239 = 4194304;
            // pto: %171
            ;
            const int64_t v240 = 65536;
            // pto: %171
            ;
            const int64_t v241 = 256;
            // pto: %171
            ;
            pto::Shape<1, 8, 1, 16, 16> v242 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %171
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v243 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %171
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v244 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v237 + ((v238 + v138 * v239) + v140 * v240 + v236 * v241), v242, v243);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            TLOAD(v233, v244);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
            // pto: %lhs_slice_0_textract
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v245 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v118, v18);
            // pto: %lhs_slice_0_textract
            ;
            uint64_t v246 = (uint64_t) v13;
            TASSIGN(v245, v246);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
            uint16_t v247 = static_cast<uint16_t>(v26);
            uint16_t v248 = static_cast<uint16_t>(v26);
            TEXTRACT(v245, v219, v247, v248);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            // pto: %rhs_slice_0_textract
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v249 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
            // pto: %rhs_slice_0_textract
            ;
            uint64_t v250 = (uint64_t) v14;
            TASSIGN(v249, v250);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
            uint16_t v251 = static_cast<uint16_t>(v26);
            uint16_t v252 = static_cast<uint16_t>(v26);
            TEXTRACT(v249, v233, v251, v252);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v151, v151, v245, v249);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        };
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        // pto: %172
        ;
        v61.SetValidShape(v173, v25);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        if (v172 <= v33) {
          // pto: %175
          ;
          int64_t v253 = (int64_t) ((uint64_t) v172 * (uint64_t) v18);
          // pto: %6
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v254 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v118, v22);
          // pto: %6
          ;
          uint64_t v255 = (uint64_t) v13;
          TASSIGN(v254, v255);
          // pto: %178
          ;
          int64_t v256 = (int64_t) ((uint64_t) v123 + (uint64_t) v253);
          // pto: %179
          ;
          int64_t v257 = v256 < v26 ? v26 : v256;
          // pto: %180
          ;
          const int64_t v258 = 0;
          // pto: %180
          ;
          __gm__ bfloat16_t* v259 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %180
          ;
          const int64_t v260 = 1;
          // pto: %180
          ;
          const int64_t v261 = 1;
          // pto: %180
          ;
          const int64_t v262 = 1;
          // pto: %180
          ;
          int64_t v263 = v118 * v20;
          // pto: %180
          ;
          int64_t v264 = v262 * v263;
          // pto: %180
          ;
          pto::Shape<1, 1, 1, -1, 256> v265 = pto::Shape<1, 1, 1, -1, 256>(v260, v261, v262, v118, v22);
          // pto: %180
          ;
          pto::Stride<-1, -1, -1, -1, -1> v266 = pto::Stride<-1, -1, -1, -1, -1>(v261 * v264, v264, v263, v20, v17);
          // pto: %180
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v267 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v259 + (v258 + v122 * v20 + v257 * v17), v265, v266);
          TLOAD(v254, v267);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
          // pto: %7
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v268 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v22, v25);
          // pto: %7
          ;
          uint64_t v269 = (uint64_t) v15;
          TASSIGN(v268, v269);
          // pto: %184
          ;
          int64_t v270 = v253 / v18;
          // pto: %185
          ;
          int64_t v271 = v270 < v26 ? v26 : v270;
          // pto: %186
          ;
          __gm__ bfloat16_t* v272 = PTOAS__GLOBAL_TENSOR_DATA(v58);
          // pto: %186
          ;
          const int64_t v273 = 0;
          // pto: %186
          ;
          const int64_t v274 = 4194304;
          // pto: %186
          ;
          const int64_t v275 = 65536;
          // pto: %186
          ;
          const int64_t v276 = 256;
          // pto: %186
          ;
          pto::Shape<1, 8, 16, 16, 16> v277 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %186
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v278 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %186
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v279 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v272 + ((v273 + v138 * v274) + v140 * v275 + v271 * v276), v277, v278);
          TLOAD(v268, v279);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
          // pto: %8
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v280 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v118, v25);
          // pto: %8
          ;
          uint64_t v281 = (uint64_t) v13;
          TASSIGN(v280, v281);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
          uint16_t v282 = static_cast<uint16_t>(v26);
          uint16_t v283 = static_cast<uint16_t>(v26);
          TEXTRACT(v280, v254, v282, v283);
          // pto: %9
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v284 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v25);
          // pto: %9
          ;
          uint64_t v285 = (uint64_t) v14;
          TASSIGN(v284, v285);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
          uint16_t v286 = static_cast<uint16_t>(v26);
          uint16_t v287 = static_cast<uint16_t>(v26);
          TEXTRACT(v284, v268, v286, v287);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          // pto: %10
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v288 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v118, v25);
          // pto: %10
          ;
          uint64_t v289 = (uint64_t) v14;
          TASSIGN(v288, v289);
          uint16_t v290 = static_cast<uint16_t>(v26);
          uint16_t v291 = static_cast<uint16_t>(v25);
          TEXTRACT(v288, v254, v290, v291);
          // pto: %11
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v292 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v25);
          // pto: %11
          ;
          uint64_t v293 = (uint64_t) v13;
          TASSIGN(v292, v293);
          uint16_t v294 = static_cast<uint16_t>(v25);
          uint16_t v295 = static_cast<uint16_t>(v26);
          TEXTRACT(v292, v268, v294, v295);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v59, v59, v280, v284);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
          TMATMUL_ACC(v59, v59, v288, v292);
        } else {
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
          for (int64_t v296 = v26; v296 < v18; v296 += v17) {
            // pto: %188, %189, %190
            ;
            int64_t v297 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v172 + (uint64_t) v296) % v22) * (uint64_t) v18);
            // pto: %14
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v118, v18);
            // pto: %14
            ;
            uint64_t v299 = (uint64_t) v13;
            TASSIGN(v298, v299);
            // pto: %193
            ;
            int64_t v300 = (int64_t) ((uint64_t) v123 + (uint64_t) v297);
            // pto: %194
            ;
            int64_t v301 = v300 < v26 ? v26 : v300;
            // pto: %195
            ;
            const int64_t v302 = 0;
            // pto: %195
            ;
            __gm__ bfloat16_t* v303 = PTOAS__GLOBAL_TENSOR_DATA(v55);
            // pto: %195
            ;
            const int64_t v304 = 1;
            // pto: %195
            ;
            const int64_t v305 = 1;
            // pto: %195
            ;
            const int64_t v306 = 1;
            // pto: %195
            ;
            int64_t v307 = v118 * v20;
            // pto: %195
            ;
            int64_t v308 = v306 * v307;
            // pto: %195
            ;
            pto::Shape<1, 1, 1, -1, 16> v309 = pto::Shape<1, 1, 1, -1, 16>(v304, v305, v306, v118, v18);
            // pto: %195
            ;
            pto::Stride<-1, -1, -1, -1, -1> v310 = pto::Stride<-1, -1, -1, -1, -1>(v305 * v308, v308, v307, v20, v17);
            // pto: %195
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v311 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v303 + (v302 + v122 * v20 + v301 * v17), v309, v310);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
            TLOAD(v298, v311);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %15
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
            // pto: %15
            ;
            uint64_t v313 = (uint64_t) v15;
            TASSIGN(v312, v313);
            // pto: %199
            ;
            int64_t v314 = v297 / v18;
            // pto: %200
            ;
            int64_t v315 = v314 < v26 ? v26 : v314;
            // pto: %201
            ;
            __gm__ bfloat16_t* v316 = PTOAS__GLOBAL_TENSOR_DATA(v58);
            // pto: %201
            ;
            const int64_t v317 = 0;
            // pto: %201
            ;
            const int64_t v318 = 4194304;
            // pto: %201
            ;
            const int64_t v319 = 65536;
            // pto: %201
            ;
            const int64_t v320 = 256;
            // pto: %201
            ;
            pto::Shape<1, 8, 1, 16, 16> v321 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %201
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v322 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %201
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v323 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v316 + ((v317 + v138 * v318) + v140 * v319 + v315 * v320), v321, v322);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
            TLOAD(v312, v323);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %16
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v324 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v118, v18);
            // pto: %16
            ;
            uint64_t v325 = (uint64_t) v13;
            TASSIGN(v324, v325);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
            uint16_t v326 = static_cast<uint16_t>(v26);
            uint16_t v327 = static_cast<uint16_t>(v26);
            TEXTRACT(v324, v298, v326, v327);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
            // pto: %17
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
            // pto: %17
            ;
            uint64_t v329 = (uint64_t) v14;
            TASSIGN(v328, v329);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v330 = static_cast<uint16_t>(v26);
            uint16_t v331 = static_cast<uint16_t>(v26);
            TEXTRACT(v328, v312, v330, v331);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v59, v59, v324, v328);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        };
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      // pto: %202, %203
      ;
      int64_t v332 = (int64_t) ((uint64_t) v73 + (uint64_t) v33) % v22;
      // pto: %204
      ;
      // pto: %205
      ;
      int64_t v333 = v118 < v25 ? v118 : v25;
      v63.SetValidShape(v333, v25);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      if (v332 <= v33) {
        // pto: %207
        ;
        int64_t v334 = (int64_t) ((uint64_t) v332 * (uint64_t) v18);
        // pto: %19
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v335 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v118, v22);
        // pto: %19
        ;
        uint64_t v336 = (uint64_t) v11;
        TASSIGN(v335, v336);
        // pto: %210
        ;
        int64_t v337 = (int64_t) ((uint64_t) v123 + (uint64_t) v334);
        // pto: %211
        ;
        int64_t v338 = v337 < v26 ? v26 : v337;
        // pto: %212
        ;
        const int64_t v339 = 0;
        // pto: %212
        ;
        __gm__ bfloat16_t* v340 = PTOAS__GLOBAL_TENSOR_DATA(v55);
        // pto: %212
        ;
        const int64_t v341 = 1;
        // pto: %212
        ;
        const int64_t v342 = 1;
        // pto: %212
        ;
        const int64_t v343 = 1;
        // pto: %212
        ;
        int64_t v344 = v118 * v20;
        // pto: %212
        ;
        int64_t v345 = v343 * v344;
        // pto: %212
        ;
        pto::Shape<1, 1, 1, -1, 256> v346 = pto::Shape<1, 1, 1, -1, 256>(v341, v342, v343, v118, v22);
        // pto: %212
        ;
        pto::Stride<-1, -1, -1, -1, -1> v347 = pto::Stride<-1, -1, -1, -1, -1>(v342 * v345, v345, v344, v20, v17);
        // pto: %212
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v348 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v340 + (v339 + v122 * v20 + v338 * v17), v346, v347);
        TLOAD(v335, v348);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %20
        ;
        Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v349 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v22, v25);
        // pto: %20
        ;
        uint64_t v350 = (uint64_t) v12;
        TASSIGN(v349, v350);
        // pto: %216
        ;
        int64_t v351 = v334 / v18;
        // pto: %217
        ;
        int64_t v352 = v351 < v26 ? v26 : v351;
        // pto: %218
        ;
        __gm__ bfloat16_t* v353 = PTOAS__GLOBAL_TENSOR_DATA(v58);
        // pto: %218
        ;
        const int64_t v354 = 0;
        // pto: %218
        ;
        const int64_t v355 = 4194304;
        // pto: %218
        ;
        const int64_t v356 = 65536;
        // pto: %218
        ;
        const int64_t v357 = 256;
        // pto: %218
        ;
        pto::Shape<1, 8, 16, 16, 16> v358 = pto::Shape<1, 8, 16, 16, 16>();
        // pto: %218
        ;
        pto::Stride<4194304, 65536, 256, 16, 1> v359 = pto::Stride<4194304, 65536, 256, 16, 1>();
        // pto: %218
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v360 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v353 + ((v354 + v138 * v355) + v140 * v356 + v352 * v357), v358, v359);
        TLOAD(v349, v360);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %21
        ;
        Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v361 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v118, v25);
        // pto: %21
        ;
        uint64_t v362 = (uint64_t) v13;
        TASSIGN(v361, v362);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        uint16_t v363 = static_cast<uint16_t>(v26);
        uint16_t v364 = static_cast<uint16_t>(v26);
        TEXTRACT(v361, v335, v363, v364);
        // pto: %22
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v365 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v25);
        // pto: %22
        ;
        uint64_t v366 = (uint64_t) v14;
        TASSIGN(v365, v366);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v367 = static_cast<uint16_t>(v26);
        uint16_t v368 = static_cast<uint16_t>(v26);
        TEXTRACT(v365, v349, v367, v368);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %23
        ;
        Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v369 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v118, v25);
        // pto: %23
        ;
        uint64_t v370 = (uint64_t) v14;
        TASSIGN(v369, v370);
        uint16_t v371 = static_cast<uint16_t>(v26);
        uint16_t v372 = static_cast<uint16_t>(v25);
        TEXTRACT(v369, v335, v371, v372);
        // pto: %24
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v373 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v25);
        // pto: %24
        ;
        uint64_t v374 = (uint64_t) v13;
        TASSIGN(v373, v374);
        uint16_t v375 = static_cast<uint16_t>(v25);
        uint16_t v376 = static_cast<uint16_t>(v26);
        TEXTRACT(v373, v349, v375, v376);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v151, v151, v361, v365);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v151, v151, v369, v373);
      } else {
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        for (int64_t v377 = v26; v377 < v18; v377 += v17) {
          // pto: %220, %221, %222
          ;
          int64_t v378 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v332 + (uint64_t) v377) % v22) * (uint64_t) v18);
          // pto: %27
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v379 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v118, v18);
          // pto: %27
          ;
          uint64_t v380 = (uint64_t) v11;
          TASSIGN(v379, v380);
          // pto: %225
          ;
          int64_t v381 = (int64_t) ((uint64_t) v123 + (uint64_t) v378);
          // pto: %226
          ;
          int64_t v382 = v381 < v26 ? v26 : v381;
          // pto: %227
          ;
          const int64_t v383 = 0;
          // pto: %227
          ;
          __gm__ bfloat16_t* v384 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %227
          ;
          const int64_t v385 = 1;
          // pto: %227
          ;
          const int64_t v386 = 1;
          // pto: %227
          ;
          const int64_t v387 = 1;
          // pto: %227
          ;
          int64_t v388 = v118 * v20;
          // pto: %227
          ;
          int64_t v389 = v387 * v388;
          // pto: %227
          ;
          pto::Shape<1, 1, 1, -1, 16> v390 = pto::Shape<1, 1, 1, -1, 16>(v385, v386, v387, v118, v18);
          // pto: %227
          ;
          pto::Stride<-1, -1, -1, -1, -1> v391 = pto::Stride<-1, -1, -1, -1, -1>(v386 * v389, v389, v388, v20, v17);
          // pto: %227
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v392 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v384 + (v383 + v122 * v20 + v382 * v17), v390, v391);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          TLOAD(v379, v392);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %28
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v393 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
          // pto: %28
          ;
          uint64_t v394 = (uint64_t) v12;
          TASSIGN(v393, v394);
          // pto: %231
          ;
          int64_t v395 = v378 / v18;
          // pto: %232
          ;
          int64_t v396 = v395 < v26 ? v26 : v395;
          // pto: %233
          ;
          __gm__ bfloat16_t* v397 = PTOAS__GLOBAL_TENSOR_DATA(v58);
          // pto: %233
          ;
          const int64_t v398 = 0;
          // pto: %233
          ;
          const int64_t v399 = 4194304;
          // pto: %233
          ;
          const int64_t v400 = 65536;
          // pto: %233
          ;
          const int64_t v401 = 256;
          // pto: %233
          ;
          pto::Shape<1, 8, 1, 16, 16> v402 = pto::Shape<1, 8, 1, 16, 16>();
          // pto: %233
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v403 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %233
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v404 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v397 + ((v398 + v138 * v399) + v140 * v400 + v396 * v401), v402, v403);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          TLOAD(v393, v404);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %29
          ;
          Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v405 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v118, v18);
          // pto: %29
          ;
          uint64_t v406 = (uint64_t) v13;
          TASSIGN(v405, v406);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          uint16_t v407 = static_cast<uint16_t>(v26);
          uint16_t v408 = static_cast<uint16_t>(v26);
          TEXTRACT(v405, v379, v407, v408);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %30
          ;
          Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v409 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
          // pto: %30
          ;
          uint64_t v410 = (uint64_t) v14;
          TASSIGN(v409, v410);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v411 = static_cast<uint16_t>(v26);
          uint16_t v412 = static_cast<uint16_t>(v26);
          TEXTRACT(v409, v393, v411, v412);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v151, v151, v405, v409);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        };
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      };
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      // pto: %seed_fast_acc__rv_v2
      ;
      Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v413 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v118, v25);
      // pto: %seed_fast_acc__rv_v2
      ;
      uint64_t v414 = (uint64_t) v13;
      TASSIGN(v413, v414);
      // pto: %235, %236
      ;
      int64_t v415 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v36) + (uint64_t) v68);
      // pto: %237
      ;
      int64_t v416 = v415 < v26 ? v26 : v415;
      // pto: %accum__iter_v3_pview
      ;
      const int64_t v417 = 0;
      // pto: %accum__iter_v3_pview
      ;
      __gm__ float* v418 = PTOAS__GLOBAL_TENSOR_DATA(v46);
      // pto: %accum__iter_v3_pview
      ;
      const int64_t v419 = 1;
      // pto: %accum__iter_v3_pview
      ;
      const int64_t v420 = 1;
      // pto: %accum__iter_v3_pview
      ;
      const int64_t v421 = 1;
      // pto: %accum__iter_v3_pview
      ;
      int64_t v422 = v118 * v16;
      // pto: %accum__iter_v3_pview
      ;
      int64_t v423 = v421 * v422;
      // pto: %accum__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, -1, 128> v424 = pto::Shape<1, 1, 1, -1, 128>(v419, v420, v421, v118, v25);
      // pto: %accum__iter_v3_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v425 = pto::Stride<-1, -1, -1, -1, -1>(v420 * v423, v423, v422, v16, v17);
      // pto: %accum__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v426 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v418 + (v417 + v122 * v16 + v416 * v17), v424, v425);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      TSTORE(v426, v413);
    } else {
      for (int64_t v427 = v26; v427 < v19; v427 += v17) {
        // pto: %238
        ;
        int64_t v428 = (int64_t) ((uint64_t) v70 + (uint64_t) v427);
        // pto: %239
        ;
        if (v428 < v5) {
          // pto: %240
          ;
          int64_t v429 = (int64_t) ((uint64_t) v428 * (uint64_t) v18);
          // pto: %241
          ;
          int64_t v430 = (int64_t) ((uint64_t) v8 - (uint64_t) v429);
          // pto: %242
          ;
          int64_t v431 = v430 < v18 ? v430 : v18;
          // pto: %244, %245, %246, %247, %243
          ;
          int32_t v432 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v428 * (uint64_t) v19) + (uint64_t) v6) * (uint64_t) v19) + (uint64_t) v67)];
          // pto: %248
          ;
          int64_t v433 = (int64_t) v432;
          // pto: %249
          ;
          int64_t v434 = v433 < v26 ? v26 : v433;
          // pto: %seed_narrow_acc__tile
          ;
          Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v435 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v18, v25);
          // pto: %seed_narrow_acc__tile
          ;
          uint64_t v436 = (uint64_t) v13;
          TASSIGN(v435, v436);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          for (int64_t v437 = v26; v437 < v18; v437 += v17) {
            // pto: %250
            ;
            int64_t v438 = (int64_t) ((uint64_t) v437 * (uint64_t) v18);
            // pto: %251, %252
            ;
            int64_t v439 = (int64_t) ((uint64_t) v434 + (uint64_t) v438) % v22;
            // pto: %253
            ;
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            if (v439 <= v33) {
              // pto: %254
              ;
              int64_t v440 = (int64_t) ((uint64_t) v439 * (uint64_t) v18);
              // pto: %seed_narrow_packet_x__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v441 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v431, v22);
              // pto: %seed_narrow_packet_x__tile
              ;
              uint64_t v442 = (uint64_t) v12;
              TASSIGN(v441, v442);
              // pto: %255
              ;
              int64_t v443 = v429 < v26 ? v26 : v429;
              // pto: %256, %257
              ;
              int64_t v444 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v34) + (uint64_t) v440);
              // pto: %258
              ;
              int64_t v445 = v444 < v26 ? v26 : v444;
              // pto: %259
              ;
              const int64_t v446 = 0;
              // pto: %259
              ;
              __gm__ bfloat16_t* v447 = PTOAS__GLOBAL_TENSOR_DATA(v55);
              // pto: %259
              ;
              const int64_t v448 = 1;
              // pto: %259
              ;
              const int64_t v449 = 1;
              // pto: %259
              ;
              const int64_t v450 = 1;
              // pto: %259
              ;
              int64_t v451 = v431 * v20;
              // pto: %259
              ;
              int64_t v452 = v450 * v451;
              // pto: %259
              ;
              pto::Shape<1, 1, 1, -1, 256> v453 = pto::Shape<1, 1, 1, -1, 256>(v448, v449, v450, v431, v22);
              // pto: %259
              ;
              pto::Stride<-1, -1, -1, -1, -1> v454 = pto::Stride<-1, -1, -1, -1, -1>(v449 * v452, v452, v451, v20, v17);
              // pto: %259
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v455 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v447 + (v446 + v443 * v20 + v445 * v17), v453, v454);
              TLOAD(v441, v455);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %seed_narrow_packet_w__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v456 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v22, v25);
              // pto: %seed_narrow_packet_w__tile
              ;
              uint64_t v457 = (uint64_t) v11;
              TASSIGN(v456, v457);
              // pto: %260
              ;
              int64_t v458 = v6 < v26 ? v26 : v6;
              // pto: %261
              ;
              int64_t v459 = v68 / v18;
              // pto: %262
              ;
              int64_t v460 = v459 < v26 ? v26 : v459;
              // pto: %263
              ;
              int64_t v461 = v440 / v18;
              // pto: %264
              ;
              int64_t v462 = v461 < v26 ? v26 : v461;
              // pto: %265
              ;
              __gm__ bfloat16_t* v463 = PTOAS__GLOBAL_TENSOR_DATA(v58);
              // pto: %265
              ;
              const int64_t v464 = 0;
              // pto: %265
              ;
              const int64_t v465 = 4194304;
              // pto: %265
              ;
              const int64_t v466 = 65536;
              // pto: %265
              ;
              const int64_t v467 = 256;
              // pto: %265
              ;
              pto::Shape<1, 8, 16, 16, 16> v468 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %265
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v469 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %265
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v470 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v463 + ((v464 + v458 * v465) + v460 * v466 + v462 * v467), v468, v469);
              TLOAD(v456, v470);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %seed_narrow_acc__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v471 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v431, v25);
              // pto: %seed_narrow_acc__iter_v1_l0_a
              ;
              uint64_t v472 = (uint64_t) v13;
              TASSIGN(v471, v472);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              uint16_t v473 = static_cast<uint16_t>(v26);
              uint16_t v474 = static_cast<uint16_t>(v26);
              TEXTRACT(v471, v441, v473, v474);
              // pto: %seed_narrow_acc__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v475 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v25);
              // pto: %seed_narrow_acc__iter_v1_l0_b
              ;
              uint64_t v476 = (uint64_t) v14;
              TASSIGN(v475, v476);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v477 = static_cast<uint16_t>(v26);
              uint16_t v478 = static_cast<uint16_t>(v26);
              TEXTRACT(v475, v456, v477, v478);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              // pto: %32
              ;
              Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v479 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v431, v25);
              // pto: %32
              ;
              uint64_t v480 = (uint64_t) v14;
              TASSIGN(v479, v480);
              uint16_t v481 = static_cast<uint16_t>(v26);
              uint16_t v482 = static_cast<uint16_t>(v25);
              TEXTRACT(v479, v441, v481, v482);
              // pto: %33
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v483 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v25, v25);
              // pto: %33
              ;
              uint64_t v484 = (uint64_t) v13;
              TASSIGN(v483, v484);
              uint16_t v485 = static_cast<uint16_t>(v25);
              uint16_t v486 = static_cast<uint16_t>(v26);
              TEXTRACT(v483, v456, v485, v486);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              // pto: %266
              ;
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              if (v437 == v26) {
                pipe_barrier(PIPE_M);
                TMATMUL(v435, v471, v475);
              } else {
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v435, v435, v471, v475);
              };
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              TMATMUL_ACC(v435, v435, v479, v483);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              for (int64_t v487 = v26; v487 < v18; v487 += v17) {
                // pto: %267, %268, %269
                ;
                int64_t v488 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v439 + (uint64_t) v487) % v22) * (uint64_t) v18);
                // pto: %seed_narrow_wrap_x__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v489 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v431, v18);
                // pto: %seed_narrow_wrap_x__tile
                ;
                uint64_t v490 = (uint64_t) v12;
                TASSIGN(v489, v490);
                // pto: %270
                ;
                int64_t v491 = v429 < v26 ? v26 : v429;
                // pto: %271, %272
                ;
                int64_t v492 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v34) + (uint64_t) v488);
                // pto: %273
                ;
                int64_t v493 = v492 < v26 ? v26 : v492;
                // pto: %274
                ;
                const int64_t v494 = 0;
                // pto: %274
                ;
                __gm__ bfloat16_t* v495 = PTOAS__GLOBAL_TENSOR_DATA(v55);
                // pto: %274
                ;
                const int64_t v496 = 1;
                // pto: %274
                ;
                const int64_t v497 = 1;
                // pto: %274
                ;
                const int64_t v498 = 1;
                // pto: %274
                ;
                int64_t v499 = v431 * v20;
                // pto: %274
                ;
                int64_t v500 = v498 * v499;
                // pto: %274
                ;
                pto::Shape<1, 1, 1, -1, 16> v501 = pto::Shape<1, 1, 1, -1, 16>(v496, v497, v498, v431, v18);
                // pto: %274
                ;
                pto::Stride<-1, -1, -1, -1, -1> v502 = pto::Stride<-1, -1, -1, -1, -1>(v497 * v500, v500, v499, v20, v17);
                // pto: %274
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v503 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v495 + (v494 + v491 * v20 + v493 * v17), v501, v502);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                TLOAD(v489, v503);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %seed_narrow_wrap_w__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v504 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
                // pto: %seed_narrow_wrap_w__tile
                ;
                uint64_t v505 = (uint64_t) v11;
                TASSIGN(v504, v505);
                // pto: %275
                ;
                int64_t v506 = v6 < v26 ? v26 : v6;
                // pto: %276
                ;
                int64_t v507 = v68 / v18;
                // pto: %277
                ;
                int64_t v508 = v507 < v26 ? v26 : v507;
                // pto: %278
                ;
                int64_t v509 = v488 / v18;
                // pto: %279
                ;
                int64_t v510 = v509 < v26 ? v26 : v509;
                // pto: %280
                ;
                __gm__ bfloat16_t* v511 = PTOAS__GLOBAL_TENSOR_DATA(v58);
                // pto: %280
                ;
                const int64_t v512 = 0;
                // pto: %280
                ;
                const int64_t v513 = 4194304;
                // pto: %280
                ;
                const int64_t v514 = 65536;
                // pto: %280
                ;
                const int64_t v515 = 256;
                // pto: %280
                ;
                pto::Shape<1, 8, 1, 16, 16> v516 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %280
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v517 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %280
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v518 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v511 + ((v512 + v506 * v513) + v508 * v514 + v510 * v515), v516, v517);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v504, v518);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %35
                ;
                Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v519 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v431, v18);
                // pto: %35
                ;
                uint64_t v520 = (uint64_t) v13;
                TASSIGN(v519, v520);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                uint16_t v521 = static_cast<uint16_t>(v26);
                uint16_t v522 = static_cast<uint16_t>(v26);
                TEXTRACT(v519, v489, v521, v522);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                // pto: %36
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v523 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v25);
                // pto: %36
                ;
                uint64_t v524 = (uint64_t) v14;
                TASSIGN(v523, v524);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v525 = static_cast<uint16_t>(v26);
                uint16_t v526 = static_cast<uint16_t>(v26);
                TEXTRACT(v523, v504, v525, v526);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                // pto: %282, %283
                ;
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                if ((int64_t) ((uint64_t) v438 + (uint64_t) v487) == v26) {
                  pipe_barrier(PIPE_M);
                  TMATMUL(v435, v519, v523);
                } else {
                  pipe_barrier(PIPE_M);
                  TMATMUL_ACC(v435, v435, v519, v523);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          // pto: %285
          ;
          int64_t v527 = v429 < v26 ? v26 : v429;
          // pto: %286, %287
          ;
          int64_t v528 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v36) + (uint64_t) v68);
          // pto: %288
          ;
          int64_t v529 = v528 < v26 ? v26 : v528;
          // pto: %accum__iter_v6_pview
          ;
          __gm__ float* v530 = PTOAS__GLOBAL_TENSOR_DATA(v46);
          // pto: %accum__iter_v6_pview
          ;
          const int64_t v531 = 0;
          // pto: %accum__iter_v6_pview
          ;
          const int64_t v532 = 8192;
          // pto: %accum__iter_v6_pview
          ;
          pto::Shape<1, 1, 1, 16, 128> v533 = pto::Shape<1, 1, 1, 16, 128>();
          // pto: %accum__iter_v6_pview
          ;
          pto::Stride<131072, 131072, 131072, 8192, 1> v534 = pto::Stride<131072, 131072, 131072, 8192, 1>();
          // pto: %accum__iter_v6_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v535 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v530 + (v531 + v527 * v532 + v529), v533, v534);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          pipe_barrier(PIPE_FIX);
          TSTORE(v535, v435);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        };
      };
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}