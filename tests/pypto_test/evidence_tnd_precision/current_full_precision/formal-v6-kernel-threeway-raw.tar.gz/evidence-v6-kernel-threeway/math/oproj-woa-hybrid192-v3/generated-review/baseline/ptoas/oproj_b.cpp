#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_b(__gm__ int8_t* v1, __gm__ int8_t* v2, __gm__ int32_t* v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v8 = 0;
  // pto: %c8192_i64
  const int64_t v9 = 8192;
  // pto: %c4096_i64
  const int64_t v10 = 4096;
  // pto: %c32768_i64
  const int64_t v11 = 32768;
  // pto: %c8192_index
  const int64_t v12 = 8192;
  // pto: %c1_index
  const int64_t v13 = 1;
  // pto: %c128_index
  const int64_t v14 = 128;
  // pto: %c512_index
  const int64_t v15 = 512;
  // pto: %c16_index
  const int64_t v16 = 16;
  // pto: %c32_index
  const int64_t v17 = 32;
  // pto: %c33554432_index
  const int64_t v18 = 33554432;
  // pto: %c262144_index
  const int64_t v19 = 262144;
  // pto: %c4096_index
  const int64_t v20 = 4096;
  // pto: %c0_index
  const int64_t v21 = 0;
  // pto: %c256_index
  const int64_t v22 = 256;
  // pto: %c63_index
  const int64_t v23 = 63;
  // pto: %quantized__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v27 = (int64_t) v5;
  // pto: %quantized__ssa_v0_view
  int64_t v28 = v27 * v12;
  // pto: %quantized__ssa_v0_view
  int64_t v29 = v26 * v28;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v30 = pto::Shape<1, 1, 1, -1, -1>(v24, v25, v26, v27, v12);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v31 = pto::Stride<-1, -1, -1, -1, -1>(v25 * v29, v29, v28, v12, v13);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v32 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v30, v31);
  // pto: %wo_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v33 = pto::Shape<-1, -1, -1, -1, -1>(v13, v14, v15, v16, v17);
  // pto: %wo_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v34 = pto::Stride<-1, -1, -1, -1, -1>(v18, v19, v15, v17, v13);
  // pto: %wo_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v35 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v33, v34);
  // pto: %20
  int64_t v36 = (int64_t) ((uint64_t) v5 + (uint64_t) v23);
  // pto: %integer_accum__ssa_v0_view
  const int64_t v37 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %integer_accum__ssa_v0_view
  int64_t v40 = v36 * v20;
  // pto: %integer_accum__ssa_v0_view
  int64_t v41 = v39 * v40;
  // pto: %integer_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v42 = pto::Shape<1, 1, 1, -1, -1>(v37, v38, v39, v36, v20);
  // pto: %integer_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v43 = pto::Stride<-1, -1, -1, -1, -1>(v38 * v41, v41, v40, v20, v13);
  // pto: %integer_accum__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v44 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v42, v43);
  // pto: %block__ssa_v0
  int64_t v45 = (int64_t) v6;
  // pto: %3, %4
  int64_t v46 = (int64_t) ((uint64_t) (v45 / v17) * (uint64_t) v16);
  // pto: %5, %6
  int64_t v47 = (int64_t) ((uint64_t) (v45 % v17) * (uint64_t) v14);
  // pto: %7
  int64_t v48 = (int64_t) ((uint64_t) v5 - (uint64_t) v46);
  // pto: %b_acc__tile
  Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v49 = Tile<TileType::Acc, int32_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v16, v14);
  // pto: %b_acc__tile
  uint64_t v50 = (uint64_t) v8;
  TASSIGN(v49, v50);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  for (int64_t v51 = v21; v51 < v16; v51 += v13) {
    // pto: %8
    ;
    int64_t v52 = (int64_t) ((uint64_t) v51 * (uint64_t) v15);
    // pto: %b_input__tile
    ;
    Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v53 = Tile<TileType::Mat, int8_t, 16, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v48, v15);
    // pto: %b_input__tile
    ;
    uint64_t v54 = (uint64_t) v8;
    TASSIGN(v53, v54);
    // pto: %9
    ;
    int64_t v55 = v46 < v21 ? v21 : v46;
    // pto: %10
    ;
    int64_t v56 = v52 < v21 ? v21 : v52;
    // pto: %quantized__ssa_v0_pview
    ;
    const int64_t v57 = 0;
    // pto: %quantized__ssa_v0_pview
    ;
    __gm__ int8_t* v58 = PTOAS__GLOBAL_TENSOR_DATA(v32);
    // pto: %quantized__ssa_v0_pview
    ;
    const int64_t v59 = 1;
    // pto: %quantized__ssa_v0_pview
    ;
    const int64_t v60 = 1;
    // pto: %quantized__ssa_v0_pview
    ;
    const int64_t v61 = 1;
    // pto: %quantized__ssa_v0_pview
    ;
    int64_t v62 = v48 * v12;
    // pto: %quantized__ssa_v0_pview
    ;
    int64_t v63 = v61 * v62;
    // pto: %quantized__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v64 = pto::Shape<1, 1, 1, -1, 512>(v59, v60, v61, v48, v15);
    // pto: %quantized__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v65 = pto::Stride<-1, -1, -1, -1, -1>(v60 * v63, v63, v62, v12, v13);
    // pto: %quantized__ssa_v0_pview
    ;
    GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v66 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v58 + (v57 + v55 * v12 + v56 * v13), v64, v65);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v53, v66);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %b_weight__tile
    ;
    Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v14);
    // pto: %b_weight__tile
    ;
    uint64_t v68 = (uint64_t) v9;
    TASSIGN(v67, v68);
    // pto: %11
    ;
    int64_t v69 = v47 / v17;
    // pto: %12
    ;
    int64_t v70 = v69 < v21 ? v21 : v69;
    // pto: %13
    ;
    int64_t v71 = v52 / v16;
    // pto: %14
    ;
    int64_t v72 = v71 < v21 ? v21 : v71;
    // pto: %wo_b__ssa_v0_pview
    ;
    __gm__ int8_t* v73 = PTOAS__GLOBAL_TENSOR_DATA(v35);
    // pto: %wo_b__ssa_v0_pview
    ;
    const int64_t v74 = 0;
    // pto: %wo_b__ssa_v0_pview
    ;
    const int64_t v75 = 262144;
    // pto: %wo_b__ssa_v0_pview
    ;
    const int64_t v76 = 512;
    // pto: %wo_b__ssa_v0_pview
    ;
    pto::Shape<1, 4, 32, 16, 32> v77 = pto::Shape<1, 4, 32, 16, 32>();
    // pto: %wo_b__ssa_v0_pview
    ;
    pto::Stride<33554432, 262144, 512, 32, 1> v78 = pto::Stride<33554432, 262144, 512, 32, 1>();
    // pto: %wo_b__ssa_v0_pview
    ;
    GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v79 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v73 + (v74 + v70 * v75 + v72 * v76), v77, v78);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v67, v79);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    // pto: %15
    ;
    int64_t v80 = v48 < v16 ? v48 : v16;
    // pto: %b_acc__tile_l0_a
    ;
    Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v81 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v80, v22);
    // pto: %b_acc__tile_l0_a
    ;
    uint64_t v82 = (uint64_t) v8;
    TASSIGN(v81, v82);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    uint16_t v83 = static_cast<uint16_t>(v21);
    uint16_t v84 = static_cast<uint16_t>(v21);
    TEXTRACT(v81, v53, v83, v84);
    // pto: %b_acc__tile_l0_b
    ;
    Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v85 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v22, v14);
    // pto: %b_acc__tile_l0_b
    ;
    uint64_t v86 = (uint64_t) v8;
    TASSIGN(v85, v86);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    uint16_t v87 = static_cast<uint16_t>(v21);
    uint16_t v88 = static_cast<uint16_t>(v21);
    TEXTRACT(v85, v67, v87, v88);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    // pto: %0
    ;
    Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v89 = Tile<TileType::Left, int8_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v80, v22);
    // pto: %0
    ;
    uint64_t v90 = (uint64_t) v10;
    TASSIGN(v89, v90);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    uint16_t v91 = static_cast<uint16_t>(v21);
    uint16_t v92 = static_cast<uint16_t>(v22);
    TEXTRACT(v89, v53, v91, v92);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    // pto: %1
    ;
    Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v22, v14);
    // pto: %1
    ;
    uint64_t v94 = (uint64_t) v11;
    TASSIGN(v93, v94);
    uint16_t v95 = static_cast<uint16_t>(v22);
    uint16_t v96 = static_cast<uint16_t>(v21);
    TEXTRACT(v93, v67, v95, v96);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
    // pto: %17
    ;
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    if (v51 == v21) {
      pipe_barrier(PIPE_M);
      TMATMUL(v49, v81, v85);
    } else {
      pipe_barrier(PIPE_M);
      TMATMUL_ACC(v49, v49, v81, v85);
    };
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    pipe_barrier(PIPE_M);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
    TMATMUL_ACC(v49, v49, v89, v93);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  }
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  // pto: %18
  int64_t v97 = v46 < v21 ? v21 : v46;
  // pto: %19
  int64_t v98 = v47 < v21 ? v21 : v47;
  // pto: %integer_accum__ssa_v0_pview
  __gm__ int32_t* v99 = PTOAS__GLOBAL_TENSOR_DATA(v44);
  // pto: %integer_accum__ssa_v0_pview
  const int64_t v100 = 0;
  // pto: %integer_accum__ssa_v0_pview
  const int64_t v101 = 4096;
  // pto: %integer_accum__ssa_v0_pview
  pto::Shape<1, 1, 1, 16, 128> v102 = pto::Shape<1, 1, 1, 16, 128>();
  // pto: %integer_accum__ssa_v0_pview
  pto::Stride<65536, 65536, 65536, 4096, 1> v103 = pto::Stride<65536, 65536, 65536, 4096, 1>();
  // pto: %integer_accum__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v104 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v99 + (v100 + v97 * v101 + v98), v102, v103);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE(v104, v49);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}