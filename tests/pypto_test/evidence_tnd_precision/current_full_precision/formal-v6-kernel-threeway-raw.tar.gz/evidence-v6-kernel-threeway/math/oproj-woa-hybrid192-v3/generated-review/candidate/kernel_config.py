from pathlib import Path
from simpler.task_interface import ArgDirection as _D
_ROOT_DIR = Path(__file__).parent
KERNELS = [{'func_id': 0, 'name': 'oproj_a', 'source': 'kernels/aic/oproj_a.cpp', 'core_type': 'aic', 'signature': ['OUT', 'IN', 'IN', 'IN']}, {'func_id': 1, 'name': 'oproj_a_0', 'source': 'kernels/aic/oproj_a_0.cpp', 'core_type': 'aic', 'signature': ['OUT', 'IN', 'IN', 'IN']}, {'func_id': 2, 'name': 'oproj_a_bf16', 'source': 'kernels/aiv/oproj_a_bf16.cpp', 'core_type': 'aiv', 'signature': ['IN', 'OUT']}, {'func_id': 3, 'name': 'oproj_quant', 'source': 'kernels/aiv/oproj_quant.cpp', 'core_type': 'aiv', 'signature': ['IN', 'OUT', 'OUT']}, {'func_id': 4, 'name': 'oproj_b', 'source': 'kernels/aic/oproj_b.cpp', 'core_type': 'aic', 'signature': ['IN', 'IN', 'OUT']}, {'func_id': 5, 'name': 'oproj_b64', 'source': 'kernels/aic/oproj_b64.cpp', 'core_type': 'aic', 'signature': ['IN', 'IN', 'OUT']}, {'func_id': 6, 'name': 'oproj_b_dequant', 'source': 'kernels/aiv/oproj_b_dequant.cpp', 'core_type': 'aiv', 'signature': ['IN', 'IN', 'IN', 'OUT']}]
ORCHESTRATION = {'source': 'orchestration/_o_proj_test.cpp', 'function_name': 'aicpu_orchestration_entry', 'signature': ['IN', 'IN', 'IN', 'IN', 'IN', 'OUT', 'OUT', 'OUT', 'OUT']}
RUNTIME_CONFIG = {'runtime': 'tensormap_and_ringbuffer', 'aicpu_thread_num': 0}
for _entry in [*KERNELS, ORCHESTRATION]:
    _entry['source'] = str(_ROOT_DIR / _entry['source'])
    _entry['signature'] = [getattr(_D, s) for s in _entry['signature']]
    if 'extra_include_dirs' in _entry:
        _entry['extra_include_dirs'] = [
            str(_ROOT_DIR / p) for p in _entry['extra_include_dirs']]
