#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_quant(__gm__ bfloat16_t* v1, __gm__ float* v2, __gm__ int8_t* v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c32800_i64
  const int64_t v8 = 32800;
  // pto: %c32_i64
  const int64_t v9 = 32;
  // pto: %c65568_i64
  const int64_t v10 = 65568;
  // pto: %c0_i64
  const int64_t v11 = 0;
  // pto: %c8192_index
  const int64_t v12 = 8192;
  // pto: %c1_index
  const int64_t v13 = 1;
  // pto: %c8_index
  const int64_t v14 = 8;
  // pto: %c1024_index
  const int64_t v15 = 1024;
  // pto: %c0_index
  const int64_t v16 = 0;
  // pto: %cst_9
  const float v17 = 0.00787401571f;
  // pto: %cst_10
  const float v18 = 0.0f;
  // pto: %cst_11
  const float v19 = 1.0f;
  // pto: %cst_12
  const float v20 = 127.0f;
  // pto: %projected__ssa_v0_view
  const int64_t v21 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v22 = 1;
  // pto: %projected__ssa_v0_view
  const int64_t v23 = 1;
  // pto: %projected__ssa_v0_view
  int64_t v24 = (int64_t) v5;
  // pto: %projected__ssa_v0_view
  int64_t v25 = v24 * v12;
  // pto: %projected__ssa_v0_view
  int64_t v26 = v23 * v25;
  // pto: %projected__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v27 = pto::Shape<1, 1, 1, -1, -1>(v21, v22, v23, v24, v12);
  // pto: %projected__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v28 = pto::Stride<-1, -1, -1, -1, -1>(v22 * v26, v26, v25, v12, v13);
  // pto: %projected__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v29 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v27, v28);
  // pto: %token_scale__ssa_v0_view
  const int64_t v30 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %token_scale__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %token_scale__ssa_v0_view
  int64_t v33 = (int64_t) v5;
  // pto: %token_scale__ssa_v0_view
  int64_t v34 = v33 * v13;
  // pto: %token_scale__ssa_v0_view
  int64_t v35 = v32 * v34;
  // pto: %token_scale__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v36 = pto::Shape<1, 1, 1, -1, -1>(v30, v31, v32, v33, v13);
  // pto: %token_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v37 = pto::Stride<-1, -1, -1, -1, -1>(v31 * v35, v35, v34, v13, (int64_t) v5);
  // pto: %token_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v38 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v2, v36, v37);
  // pto: %quantized__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v42 = (int64_t) v5;
  // pto: %quantized__ssa_v0_view
  int64_t v43 = v42 * v12;
  // pto: %quantized__ssa_v0_view
  int64_t v44 = v41 * v43;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v45 = pto::Shape<1, 1, 1, -1, -1>(v39, v40, v41, v42, v12);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v40 * v44, v44, v43, v12, v13);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v47 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v45, v46);
  // pto: %block__ssa_v0, %0
  int64_t v48 = (int64_t) ((uint64_t) ((int64_t) v6) * (uint64_t) v14);
  // pto: %1
  int64_t v49 = (int64_t) ((uint64_t) v5 - (uint64_t) v48);
  // pto: %2
  int64_t v50 = v49 < v14 ? v49 : v14;
  // pto: %first_quant__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v51 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
  // pto: %first_quant__ssa_v0
  uint64_t v52 = (uint64_t) v8;
  TASSIGN(v51, v52);
  // pto: %3
  int64_t v53 = v48 < v16 ? v16 : v48;
  // pto: %projected__ssa_v0_pview
  const int64_t v54 = 0;
  // pto: %projected__ssa_v0_pview
  __gm__ bfloat16_t* v55 = PTOAS__GLOBAL_TENSOR_DATA(v29);
  // pto: %projected__ssa_v0_pview
  const int64_t v56 = 1;
  // pto: %projected__ssa_v0_pview
  const int64_t v57 = 1;
  // pto: %projected__ssa_v0_pview
  const int64_t v58 = 1;
  // pto: %projected__ssa_v0_pview
  int64_t v59 = v50 * v12;
  // pto: %projected__ssa_v0_pview
  int64_t v60 = v58 * v59;
  // pto: %projected__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 1024> v61 = pto::Shape<1, 1, 1, -1, 1024>(v56, v57, v58, v50, v15);
  // pto: %projected__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v62 = pto::Stride<-1, -1, -1, -1, -1>(v57 * v60, v60, v59, v12, v13);
  // pto: %projected__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v63 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v55 + (v54 + v53 * v12 + v16 * v13), v61, v62);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  TLOAD(v51, v63);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %t__tmp_v19
  Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v64 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
  // pto: %t__tmp_v19
  uint64_t v65 = (uint64_t) v9;
  TASSIGN(v64, v65);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  RoundMode v66 = RoundMode::CAST_ROUND;
  SaturationMode v67 = SaturationMode::ON;
  TCVT(v64, v51, v66, v67);
  // pto: %first_abs__ssa_v0
  Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v68 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
  // pto: %first_abs__ssa_v0
  uint64_t v69 = (uint64_t) v9;
  TASSIGN(v68, v69);
  pipe_barrier(PIPE_V);
  TABS(v68, v64);
  // pto: %t__tmp_v20
  Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v70 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v15);
  // pto: %t__tmp_v20
  uint64_t v71 = (uint64_t) v8;
  TASSIGN(v70, v71);
  // pto: %amax__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v72 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v13);
  // pto: %amax__ssa_v0
  uint64_t v73 = (uint64_t) v10;
  TASSIGN(v72, v73);
  pipe_barrier(PIPE_V);
  TROWMAX(v72, v68, v70);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v74 = v13; v74 < v14; v74 += v13) {
    // pto: %q_bf16__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %q_bf16__ssa_v0
    ;
    uint64_t v76 = (uint64_t) v8;
    TASSIGN(v75, v76);
    // pto: %5
    ;
    int64_t v77 = (int64_t) ((uint64_t) v74 * (uint64_t) v15);
    // pto: %6
    ;
    int64_t v78 = v77 < v16 ? v16 : v77;
    // pto: %7
    ;
    const int64_t v79 = 0;
    // pto: %7
    ;
    __gm__ bfloat16_t* v80 = PTOAS__GLOBAL_TENSOR_DATA(v29);
    // pto: %7
    ;
    const int64_t v81 = 1;
    // pto: %7
    ;
    const int64_t v82 = 1;
    // pto: %7
    ;
    const int64_t v83 = 1;
    // pto: %7
    ;
    int64_t v84 = v50 * v12;
    // pto: %7
    ;
    int64_t v85 = v83 * v84;
    // pto: %7
    ;
    pto::Shape<1, 1, 1, -1, 1024> v86 = pto::Shape<1, 1, 1, -1, 1024>(v81, v82, v83, v50, v15);
    // pto: %7
    ;
    pto::Stride<-1, -1, -1, -1, -1> v87 = pto::Stride<-1, -1, -1, -1, -1>(v82 * v85, v85, v84, v12, v13);
    // pto: %7
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v88 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v80 + (v79 + v53 * v12 + v78 * v13), v86, v87);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    TLOAD(v75, v88);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %q_fp32__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v89 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %q_fp32__ssa_v0
    ;
    uint64_t v90 = (uint64_t) v9;
    TASSIGN(v89, v90);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    pipe_barrier(PIPE_V);
    RoundMode v91 = RoundMode::CAST_ROUND;
    SaturationMode v92 = SaturationMode::ON;
    TCVT(v89, v75, v91, v92);
    // pto: %t__tmp_v21
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %t__tmp_v21
    ;
    uint64_t v94 = (uint64_t) v9;
    TASSIGN(v93, v94);
    pipe_barrier(PIPE_V);
    TABS(v93, v89);
    // pto: %t__tmp_v22
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v14, v15);
    // pto: %t__tmp_v22
    ;
    uint64_t v96 = (uint64_t) v8;
    TASSIGN(v95, v96);
    // pto: %t__tmp_v23
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v13);
    // pto: %t__tmp_v23
    ;
    uint64_t v98 = (uint64_t) v11;
    TASSIGN(v97, v98);
    pipe_barrier(PIPE_V);
    TROWMAX(v97, v93, v95);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    // pto: %amax__rm_a0_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
    // pto: %amax__rm_a0_tmp_v0
    ;
    uint64_t v100 = (uint64_t) v10;
    TASSIGN(v99, v100);
    // pto: %amax__rm_a1_tmp_v1
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
    // pto: %amax__rm_a1_tmp_v1
    ;
    uint64_t v102 = (uint64_t) v11;
    TASSIGN(v101, v102);
    // pto: %amax__row_major_tmp_v2
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
    // pto: %amax__row_major_tmp_v2
    ;
    uint64_t v104 = (uint64_t) v9;
    TASSIGN(v103, v104);
    pipe_barrier(PIPE_V);
    TMAX(v103, v99, v101);
    // pto: %amax__ssa_v3
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v105 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v13);
    // pto: %amax__ssa_v3
    ;
    uint64_t v106 = (uint64_t) v9;
    TASSIGN(v105, v106);
    // pto: %amax__ssa_v3_mv
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v107 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v13);
    // pto: %amax__ssa_v3_mv
    ;
    uint64_t v108 = (uint64_t) v10;
    TASSIGN(v107, v108);
    pipe_barrier(PIPE_V);
    TMOV(v107, v105);
  }
  // pto: %dequant__rm_a0_tmp_v3
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %dequant__rm_a0_tmp_v3
  uint64_t v110 = (uint64_t) v10;
  TASSIGN(v109, v110);
  // pto: %dequant__row_major_tmp_v4
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %dequant__row_major_tmp_v4
  uint64_t v112 = (uint64_t) v9;
  TASSIGN(v111, v112);
  pipe_barrier(PIPE_V);
  TMULS(v111, v109, v17);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %dequant__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v13);
  // pto: %dequant__ssa_v0
  uint64_t v114 = (uint64_t) v9;
  TASSIGN(v113, v114);
  // pto: %denominator__rm_a0_tmp_v5
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %denominator__rm_a0_tmp_v5
  uint64_t v116 = (uint64_t) v10;
  TASSIGN(v115, v116);
  // pto: %denominator__row_major_tmp_v6
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %denominator__row_major_tmp_v6
  uint64_t v118 = (uint64_t) v8;
  TASSIGN(v117, v118);
  TADDS(v117, v115, v18);
  set_flag(PIPE_V, PIPE_S, EVENT_ID0);
  // pto: %denominator__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v119 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v13);
  // pto: %denominator__ssa_v0
  uint64_t v120 = (uint64_t) v8;
  TASSIGN(v119, v120);
  wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
  for (int64_t v121 = v16; v121 < v50; v121 += v13) {
    // pto: %magnitude__ssa_v0
    ;
    float v122 = v119.GetValue(v121);
    // pto: %8
    ;
    bool v123 = v122 != v122 || v18 != v18;
    // pto: %8
    ;
    if ((v122 == v122 && v18 == v18) && v122 == v18) {
      v119.SetValue(v121, v19);
    };
  }
  set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  set_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
  // pto: %t__rm_a0_tmp_v7
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %t__rm_a0_tmp_v7
  uint64_t v125 = (uint64_t) v10;
  TASSIGN(v124, v125);
  // pto: %t__row_major_tmp_v8
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v126 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %t__row_major_tmp_v8
  uint64_t v127 = (uint64_t) v10;
  TASSIGN(v126, v127);
  pipe_barrier(PIPE_V);
  TMULS(v126, v124, v18);
  // pto: %t__tmp_v24
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v128 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v13);
  // pto: %t__tmp_v24
  uint64_t v129 = (uint64_t) v10;
  TASSIGN(v128, v129);
  // pto: %t__rm_a0_tmp_v9
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %t__rm_a0_tmp_v9
  uint64_t v131 = (uint64_t) v10;
  TASSIGN(v130, v131);
  // pto: %t__row_major_tmp_v10
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %t__row_major_tmp_v10
  uint64_t v133 = (uint64_t) v10;
  TASSIGN(v132, v133);
  pipe_barrier(PIPE_V);
  TADDS(v132, v130, v20);
  // pto: %t__tmp_v25
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v13);
  // pto: %t__tmp_v25
  uint64_t v135 = (uint64_t) v10;
  TASSIGN(v134, v135);
  // pto: %multiplier__rm_a0_tmp_v11
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %multiplier__rm_a0_tmp_v11
  uint64_t v137 = (uint64_t) v10;
  TASSIGN(v136, v137);
  // pto: %multiplier__rm_a1_tmp_v12
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %multiplier__rm_a1_tmp_v12
  uint64_t v139 = (uint64_t) v8;
  TASSIGN(v138, v139);
  // pto: %multiplier__row_major_tmp_v13
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v140 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v13, v50);
  // pto: %multiplier__row_major_tmp_v13
  uint64_t v141 = (uint64_t) v10;
  TASSIGN(v140, v141);
  pipe_barrier(PIPE_V);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
  TDIV(v140, v136, v138);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  // pto: %multiplier__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v142 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v13);
  // pto: %multiplier__ssa_v0
  uint64_t v143 = (uint64_t) v10;
  TASSIGN(v142, v143);
  v113.SetValidShape(v50, v13);
  // pto: %token_scale__ssa_v0_pview
  int64_t v144 = (int64_t) v5;
  // pto: %token_scale__ssa_v0_pview
  const int64_t v145 = 0;
  // pto: %token_scale__ssa_v0_pview
  __gm__ float* v146 = PTOAS__GLOBAL_TENSOR_DATA(v38);
  // pto: %token_scale__ssa_v0_pview
  const int64_t v147 = 1;
  // pto: %token_scale__ssa_v0_pview
  const int64_t v148 = 1;
  // pto: %token_scale__ssa_v0_pview
  const int64_t v149 = 1;
  // pto: %token_scale__ssa_v0_pview
  int64_t v150 = v50 * v13;
  // pto: %token_scale__ssa_v0_pview
  int64_t v151 = v149 * v150;
  // pto: %token_scale__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 1> v152 = pto::Shape<1, 1, 1, -1, 1>(v147, v148, v149, v50, v13);
  // pto: %token_scale__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v153 = pto::Stride<-1, -1, -1, -1, -1>(v148 * v151, v151, v150, v13, v144);
  // pto: %token_scale__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v154 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v146 + (v145 + v53 * v13 + v16 * v144), v152, v153);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v154, v113);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t v155 = v16; v155 < v14; v155 += v13) {
    // pto: %13
    ;
    int64_t v156 = (int64_t) ((uint64_t) v155 * (uint64_t) v15);
    // pto: %quant_bf16__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %quant_bf16__ssa_v0
    ;
    uint64_t v158 = (uint64_t) v8;
    TASSIGN(v157, v158);
    // pto: %15
    ;
    int64_t v159 = v156 < v16 ? v16 : v156;
    // pto: %16
    ;
    const int64_t v160 = 0;
    // pto: %16
    ;
    __gm__ bfloat16_t* v161 = PTOAS__GLOBAL_TENSOR_DATA(v29);
    // pto: %16
    ;
    const int64_t v162 = 1;
    // pto: %16
    ;
    const int64_t v163 = 1;
    // pto: %16
    ;
    const int64_t v164 = 1;
    // pto: %16
    ;
    int64_t v165 = v50 * v12;
    // pto: %16
    ;
    int64_t v166 = v164 * v165;
    // pto: %16
    ;
    pto::Shape<1, 1, 1, -1, 1024> v167 = pto::Shape<1, 1, 1, -1, 1024>(v162, v163, v164, v50, v15);
    // pto: %16
    ;
    pto::Stride<-1, -1, -1, -1, -1> v168 = pto::Stride<-1, -1, -1, -1, -1>(v163 * v166, v166, v165, v12, v13);
    // pto: %16
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v169 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v161 + (v160 + v53 * v12 + v159 * v13), v167, v168);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    TLOAD(v157, v169);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %t__tmp_v27
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v170 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %t__tmp_v27
    ;
    uint64_t v171 = (uint64_t) v9;
    TASSIGN(v170, v171);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    RoundMode v172 = RoundMode::CAST_ROUND;
    SaturationMode v173 = SaturationMode::ON;
    TCVT(v170, v157, v172, v173);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    // pto: %quant_scaled__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %quant_scaled__ssa_v0
    ;
    uint64_t v175 = (uint64_t) v9;
    TASSIGN(v174, v175);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v174, v170, v142);
    // pto: %integer__ssa_v0
    ;
    Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v176 = Tile<TileType::Vec, int32_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %integer__ssa_v0
    ;
    uint64_t v177 = (uint64_t) v9;
    TASSIGN(v176, v177);
    pipe_barrier(PIPE_V);
    RoundMode v178 = RoundMode::CAST_RINT;
    SaturationMode v179 = SaturationMode::ON;
    TCVT(v176, v174, v178, v179);
    // pto: %half__ssa_v0
    ;
    Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v180 = Tile<TileType::Vec, half, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %half__ssa_v0
    ;
    uint64_t v181 = (uint64_t) v9;
    TASSIGN(v180, v181);
    pipe_barrier(PIPE_V);
    RoundMode v182 = RoundMode::CAST_ROUND;
    SaturationMode v183 = SaturationMode::ON;
    TCVT(v180, v176, v182, v183);
    // pto: %result__ssa_v0
    ;
    Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Vec, int8_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %result__ssa_v0
    ;
    uint64_t v185 = (uint64_t) v9;
    TASSIGN(v184, v185);
    pipe_barrier(PIPE_V);
    RoundMode v186 = RoundMode::CAST_TRUNC;
    SaturationMode v187 = SaturationMode::ON;
    TCVT(v184, v180, v186, v187);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    v184.SetValidShape(v50, v15);
    // pto: %quantized__ssa_v0_pview
    ;
    const int64_t v188 = 0;
    // pto: %quantized__ssa_v0_pview
    ;
    __gm__ int8_t* v189 = PTOAS__GLOBAL_TENSOR_DATA(v47);
    // pto: %quantized__ssa_v0_pview
    ;
    const int64_t v190 = 1;
    // pto: %quantized__ssa_v0_pview
    ;
    const int64_t v191 = 1;
    // pto: %quantized__ssa_v0_pview
    ;
    const int64_t v192 = 1;
    // pto: %quantized__ssa_v0_pview
    ;
    int64_t v193 = v50 * v12;
    // pto: %quantized__ssa_v0_pview
    ;
    int64_t v194 = v192 * v193;
    // pto: %quantized__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1024> v195 = pto::Shape<1, 1, 1, -1, 1024>(v190, v191, v192, v50, v15);
    // pto: %quantized__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v196 = pto::Stride<-1, -1, -1, -1, -1>(v191 * v194, v194, v193, v12, v13);
    // pto: %quantized__ssa_v0_pview
    ;
    GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v197 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v189 + (v188 + v53 * v12 + v159 * v13), v195, v196);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    TSTORE(v197, v184);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}