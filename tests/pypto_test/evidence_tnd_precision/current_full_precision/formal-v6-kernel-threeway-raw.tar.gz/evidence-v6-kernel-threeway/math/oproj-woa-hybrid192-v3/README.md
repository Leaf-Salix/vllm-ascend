# WO-A V5：192 行阈值候选 v3

v1/v2 独立helper的动态Out维度被现有DSL ConvertToSSA作用域检查拒绝，原源和日志保留。v3使用已验收V3b形式：共同父级accum + orchestration if内两份独立SPMD，局部变量alpha重命名，消除helper动态绑定和L0C跨分支phi。无SDK修改。

T≥192使用seed256；T<192保持V4的M128/M16选择。两分支分别与81a08、85de group循环alpha等价。公开根其余AST完全一致，所有K16累加顺序和BF16/量化边界不改。CPU覆盖T1…256及256起点/负值/不均匀回退，T144仍M128而非强制M16。

父级FP32 accum仍[T+127,8192]；分支内仅L0C局部tile，写回GM后统一量化和WO-B。无设备编译命令bash compile.sh，设备隐藏，实际GCC及全部CCEC。尚未提交NPU，不能据此宣称硬件精度或性能收益。
