#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_b64(__gm__ int8_t* v1, __gm__ int8_t* v2, __gm__ int32_t* v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v8 = 0;
  // pto: %c32768_i64
  const int64_t v9 = 32768;
  // pto: %c16384_i64
  const int64_t v10 = 16384;
  // pto: %c8192_index
  const int64_t v11 = 8192;
  // pto: %c1_index
  const int64_t v12 = 1;
  // pto: %c128_index
  const int64_t v13 = 128;
  // pto: %c512_index
  const int64_t v14 = 512;
  // pto: %c16_index
  const int64_t v15 = 16;
  // pto: %c32_index
  const int64_t v16 = 32;
  // pto: %c33554432_index
  const int64_t v17 = 33554432;
  // pto: %c262144_index
  const int64_t v18 = 262144;
  // pto: %c4096_index
  const int64_t v19 = 4096;
  // pto: %c64_index
  const int64_t v20 = 64;
  // pto: %c0_index
  const int64_t v21 = 0;
  // pto: %c256_index
  const int64_t v22 = 256;
  // pto: %c63_index
  const int64_t v23 = 63;
  // pto: %quantized__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %quantized__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %quantized__ssa_v0_view
  int64_t v27 = (int64_t) v5;
  // pto: %quantized__ssa_v0_view
  int64_t v28 = v27 * v11;
  // pto: %quantized__ssa_v0_view
  int64_t v29 = v26 * v28;
  // pto: %quantized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v30 = pto::Shape<1, 1, 1, -1, -1>(v24, v25, v26, v27, v11);
  // pto: %quantized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v31 = pto::Stride<-1, -1, -1, -1, -1>(v25 * v29, v29, v28, v11, v12);
  // pto: %quantized__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v32 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v30, v31);
  // pto: %wo_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v33 = pto::Shape<-1, -1, -1, -1, -1>(v12, v13, v14, v15, v16);
  // pto: %wo_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v34 = pto::Stride<-1, -1, -1, -1, -1>(v17, v18, v14, v16, v12);
  // pto: %wo_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v35 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v33, v34);
  // pto: %29
  int64_t v36 = (int64_t) ((uint64_t) v5 + (uint64_t) v23);
  // pto: %integer_accum__ssa_v0_view
  const int64_t v37 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %integer_accum__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %integer_accum__ssa_v0_view
  int64_t v40 = v36 * v19;
  // pto: %integer_accum__ssa_v0_view
  int64_t v41 = v39 * v40;
  // pto: %integer_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v42 = pto::Shape<1, 1, 1, -1, -1>(v37, v38, v39, v36, v19);
  // pto: %integer_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v43 = pto::Stride<-1, -1, -1, -1, -1>(v38 * v41, v41, v40, v19, v12);
  // pto: %integer_accum__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v44 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v42, v43);
  // pto: %wide_block__ssa_v0
  int64_t v45 = (int64_t) v6;
  // pto: %9, %10
  int64_t v46 = (int64_t) ((uint64_t) (v45 / v16) * (uint64_t) v20);
  // pto: %11, %12
  int64_t v47 = (int64_t) ((uint64_t) (v45 % v16) * (uint64_t) v13);
  // pto: %13
  int64_t v48 = (int64_t) ((uint64_t) v5 - (uint64_t) v46);
  // pto: %14
  int64_t v49 = v48 < v20 ? v48 : v20;
  // pto: %wide_first_input__tile
  Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v50 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v49, v14);
  // pto: %wide_first_input__tile
  uint64_t v51 = (uint64_t) v8;
  TASSIGN(v50, v51);
  // pto: %15
  int64_t v52 = v46 < v21 ? v21 : v46;
  // pto: %quantized__ssa_v0_pview
  const int64_t v53 = 0;
  // pto: %quantized__ssa_v0_pview
  __gm__ int8_t* v54 = PTOAS__GLOBAL_TENSOR_DATA(v32);
  // pto: %quantized__ssa_v0_pview
  const int64_t v55 = 1;
  // pto: %quantized__ssa_v0_pview
  const int64_t v56 = 1;
  // pto: %quantized__ssa_v0_pview
  const int64_t v57 = 1;
  // pto: %quantized__ssa_v0_pview
  int64_t v58 = v49 * v11;
  // pto: %quantized__ssa_v0_pview
  int64_t v59 = v57 * v58;
  // pto: %quantized__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 512> v60 = pto::Shape<1, 1, 1, -1, 512>(v55, v56, v57, v49, v14);
  // pto: %quantized__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v61 = pto::Stride<-1, -1, -1, -1, -1>(v56 * v59, v59, v58, v11, v12);
  // pto: %quantized__ssa_v0_pview
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v62 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v54 + (v53 + v52 * v11 + v21 * v12), v60, v61);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  TLOAD(v50, v62);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  // pto: %wide_first_weight__tile
  Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v63 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v13);
  // pto: %wide_first_weight__tile
  uint64_t v64 = (uint64_t) v9;
  TASSIGN(v63, v64);
  // pto: %16
  int64_t v65 = v47 / v16;
  // pto: %17
  int64_t v66 = v65 < v21 ? v21 : v65;
  // pto: %wo_b__ssa_v0_pview
  __gm__ int8_t* v67 = PTOAS__GLOBAL_TENSOR_DATA(v35);
  // pto: %wo_b__ssa_v0_pview
  const int64_t v68 = 0;
  // pto: %wo_b__ssa_v0_pview
  const int64_t v69 = 262144;
  // pto: %wo_b__ssa_v0_pview
  pto::Shape<1, 4, 32, 16, 32> v70 = pto::Shape<1, 4, 32, 16, 32>();
  // pto: %wo_b__ssa_v0_pview
  pto::Stride<33554432, 262144, 512, 32, 1> v71 = pto::Stride<33554432, 262144, 512, 32, 1>();
  // pto: %wo_b__ssa_v0_pview
  GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v72 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v67 + (v68 + v66 * v69), v70, v71);
  TLOAD(v63, v72);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
  // pto: %wide_b_acc__tile_l0_init_storage
  Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v73 = Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v20, v13);
  // pto: %wide_b_acc__tile_l0_init_storage
  uint64_t v74 = (uint64_t) v8;
  TASSIGN(v73, v74);
  v73.SetValidShape(v49, v13);
  // pto: %wide_b_acc__tile_l0_a
  Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v75 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v49, v22);
  // pto: %wide_b_acc__tile_l0_a
  uint64_t v76 = (uint64_t) v8;
  TASSIGN(v75, v76);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  uint16_t v77 = static_cast<uint16_t>(v21);
  uint16_t v78 = static_cast<uint16_t>(v21);
  TEXTRACT(v75, v50, v77, v78);
  // pto: %wide_b_acc__tile_l0_b
  Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v79 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v22, v13);
  // pto: %wide_b_acc__tile_l0_b
  uint64_t v80 = (uint64_t) v8;
  TASSIGN(v79, v80);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
  uint16_t v81 = static_cast<uint16_t>(v21);
  uint16_t v82 = static_cast<uint16_t>(v21);
  TEXTRACT(v79, v63, v81, v82);
  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
  // pto: %0
  Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v83 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v49, v22);
  // pto: %0
  uint64_t v84 = (uint64_t) v10;
  TASSIGN(v83, v84);
  uint16_t v85 = static_cast<uint16_t>(v21);
  uint16_t v86 = static_cast<uint16_t>(v22);
  TEXTRACT(v83, v50, v85, v86);
  // pto: %1
  Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v22, v13);
  // pto: %1
  uint64_t v88 = (uint64_t) v9;
  TASSIGN(v87, v88);
  uint16_t v89 = static_cast<uint16_t>(v22);
  uint16_t v90 = static_cast<uint16_t>(v21);
  TEXTRACT(v87, v63, v89, v90);
  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
  TMATMUL(v73, v75, v79);
  pipe_barrier(PIPE_M);
  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
  TMATMUL_ACC(v73, v73, v83, v87);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t v91 = v12; v91 < v15; v91 += v12) {
    // pto: %18
    ;
    int64_t v92 = (int64_t) ((uint64_t) v91 * (uint64_t) v14);
    // pto: %wide_b_input__tile
    ;
    Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v49, v14);
    // pto: %wide_b_input__tile
    ;
    uint64_t v94 = (uint64_t) v8;
    TASSIGN(v93, v94);
    // pto: %20
    ;
    int64_t v95 = v92 < v21 ? v21 : v92;
    // pto: %21
    ;
    const int64_t v96 = 0;
    // pto: %21
    ;
    __gm__ int8_t* v97 = PTOAS__GLOBAL_TENSOR_DATA(v32);
    // pto: %21
    ;
    const int64_t v98 = 1;
    // pto: %21
    ;
    const int64_t v99 = 1;
    // pto: %21
    ;
    const int64_t v100 = 1;
    // pto: %21
    ;
    int64_t v101 = v49 * v11;
    // pto: %21
    ;
    int64_t v102 = v100 * v101;
    // pto: %21
    ;
    pto::Shape<1, 1, 1, -1, 512> v103 = pto::Shape<1, 1, 1, -1, 512>(v98, v99, v100, v49, v14);
    // pto: %21
    ;
    pto::Stride<-1, -1, -1, -1, -1> v104 = pto::Stride<-1, -1, -1, -1, -1>(v99 * v102, v102, v101, v11, v12);
    // pto: %21
    ;
    GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v105 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v97 + (v96 + v52 * v11 + v95 * v12), v103, v104);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v93, v105);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    // pto: %wide_b_weight__tile
    ;
    Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v13);
    // pto: %wide_b_weight__tile
    ;
    uint64_t v107 = (uint64_t) v9;
    TASSIGN(v106, v107);
    // pto: %24
    ;
    int64_t v108 = v92 / v15;
    // pto: %25
    ;
    int64_t v109 = v108 < v21 ? v21 : v108;
    // pto: %26
    ;
    __gm__ int8_t* v110 = PTOAS__GLOBAL_TENSOR_DATA(v35);
    // pto: %26
    ;
    const int64_t v111 = 0;
    // pto: %26
    ;
    const int64_t v112 = 262144;
    // pto: %26
    ;
    const int64_t v113 = 512;
    // pto: %26
    ;
    pto::Shape<1, 4, 32, 16, 32> v114 = pto::Shape<1, 4, 32, 16, 32>();
    // pto: %26
    ;
    pto::Stride<33554432, 262144, 512, 32, 1> v115 = pto::Stride<33554432, 262144, 512, 32, 1>();
    // pto: %26
    ;
    GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v116 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v110 + (v111 + v66 * v112 + v109 * v113), v114, v115);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    TLOAD(v106, v116);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    // pto: %3
    ;
    Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v117 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v49, v22);
    // pto: %3
    ;
    uint64_t v118 = (uint64_t) v8;
    TASSIGN(v117, v118);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    uint16_t v119 = static_cast<uint16_t>(v21);
    uint16_t v120 = static_cast<uint16_t>(v21);
    TEXTRACT(v117, v93, v119, v120);
    // pto: %4
    ;
    Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v22, v13);
    // pto: %4
    ;
    uint64_t v122 = (uint64_t) v8;
    TASSIGN(v121, v122);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    uint16_t v123 = static_cast<uint16_t>(v21);
    uint16_t v124 = static_cast<uint16_t>(v21);
    TEXTRACT(v121, v106, v123, v124);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
    // pto: %5
    ;
    Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v125 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v49, v22);
    // pto: %5
    ;
    uint64_t v126 = (uint64_t) v10;
    TASSIGN(v125, v126);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    uint16_t v127 = static_cast<uint16_t>(v21);
    uint16_t v128 = static_cast<uint16_t>(v22);
    TEXTRACT(v125, v93, v127, v128);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    // pto: %6
    ;
    Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v22, v13);
    // pto: %6
    ;
    uint64_t v130 = (uint64_t) v9;
    TASSIGN(v129, v130);
    uint16_t v131 = static_cast<uint16_t>(v22);
    uint16_t v132 = static_cast<uint16_t>(v21);
    TEXTRACT(v129, v106, v131, v132);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
    pipe_barrier(PIPE_M);
    TMATMUL_ACC(v73, v73, v117, v121);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    pipe_barrier(PIPE_M);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
    TMATMUL_ACC(v73, v73, v125, v129);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  }
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  // pto: %28
  int64_t v133 = v47 < v21 ? v21 : v47;
  // pto: %integer_accum__ssa_v0_pview
  const int64_t v134 = 0;
  // pto: %integer_accum__ssa_v0_pview
  __gm__ int32_t* v135 = PTOAS__GLOBAL_TENSOR_DATA(v44);
  // pto: %integer_accum__ssa_v0_pview
  const int64_t v136 = 1;
  // pto: %integer_accum__ssa_v0_pview
  const int64_t v137 = 1;
  // pto: %integer_accum__ssa_v0_pview
  const int64_t v138 = 1;
  // pto: %integer_accum__ssa_v0_pview
  int64_t v139 = v49 * v19;
  // pto: %integer_accum__ssa_v0_pview
  int64_t v140 = v138 * v139;
  // pto: %integer_accum__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 128> v141 = pto::Shape<1, 1, 1, -1, 128>(v136, v137, v138, v49, v13);
  // pto: %integer_accum__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v142 = pto::Stride<-1, -1, -1, -1, -1>(v137 * v140, v140, v139, v19, v12);
  // pto: %integer_accum__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v143 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v135 + (v134 + v52 * v19 + v133 * v12), v141, v142);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE(v143, v73);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}