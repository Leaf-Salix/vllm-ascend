#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qr_hadamard_matmul(__gm__ bfloat16_t* v1, __gm__ float* v2, __gm__ bfloat16_t* v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v8 = 0;
  // pto: %c32768_i64
  const int64_t v9 = 32768;
  // pto: %c128_index
  const int64_t v10 = 128;
  // pto: %c1_index
  const int64_t v11 = 1;
  // pto: %c27648_index
  const int64_t v12 = 27648;
  // pto: %c0_index
  const int64_t v13 = 0;
  // pto: %c64_index
  const int64_t v14 = 64;
  // pto: %c24_index
  const int64_t v15 = 24;
  // pto: %hadamard_idx__ssa_v0_view
  const int64_t v16 = 1;
  // pto: %hadamard_idx__ssa_v0_view
  const int64_t v17 = 1;
  // pto: %hadamard_idx__ssa_v0_view
  const int64_t v18 = 1;
  // pto: %hadamard_idx__ssa_v0_view
  int64_t v19 = v10 * v10;
  // pto: %hadamard_idx__ssa_v0_view
  int64_t v20 = v18 * v19;
  // pto: %hadamard_idx__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v21 = pto::Shape<1, 1, 1, -1, -1>(v16, v17, v18, v10, v10);
  // pto: %hadamard_idx__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v22 = pto::Stride<-1, -1, -1, -1, -1>(v17 * v20, v20, v19, v10, v11);
  // pto: %hadamard_idx__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v23 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v21, v22);
  // pto: %qh_acc_gm_inline1160_inline5575__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %qh_acc_gm_inline1160_inline5575__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %qh_acc_gm_inline1160_inline5575__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %qh_acc_gm_inline1160_inline5575__ssa_v0_view
  int64_t v27 = (int64_t) v5;
  // pto: %qh_acc_gm_inline1160_inline5575__ssa_v0_view
  int64_t v28 = v27 * v10;
  // pto: %qh_acc_gm_inline1160_inline5575__ssa_v0_view
  int64_t v29 = v26 * v28;
  // pto: %qh_acc_gm_inline1160_inline5575__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v30 = pto::Shape<1, 1, 1, -1, -1>(v24, v25, v26, v27, v10);
  // pto: %qh_acc_gm_inline1160_inline5575__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v31 = pto::Stride<-1, -1, -1, -1, -1>(v25 * v29, v29, v28, v10, v11);
  // pto: %qh_acc_gm_inline1160_inline5575__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v32 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v30, v31);
  // pto: %qr_bf16_inline5593__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %qr_bf16_inline5593__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %qr_bf16_inline5593__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %qr_bf16_inline5593__ssa_v0_view
  int64_t v36 = v12 * v10;
  // pto: %qr_bf16_inline5593__ssa_v0_view
  int64_t v37 = v35 * v36;
  // pto: %qr_bf16_inline5593__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v38 = pto::Shape<1, 1, 1, -1, -1>(v33, v34, v35, v12, v10);
  // pto: %qr_bf16_inline5593__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v39 = pto::Stride<-1, -1, -1, -1, -1>(v34 * v37, v37, v36, v10, v11);
  // pto: %qr_bf16_inline5593__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v40 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v38, v39);
  // pto: %qh_worker_inline1157_inline5630__ssa_v0
  // pto: %qh_hadamard_inline1156_inline5641__tile
  Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v41 = Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v10, v10);
  // pto: %qh_hadamard_inline1156_inline5641__tile
  uint64_t v42 = (uint64_t) v8;
  TASSIGN(v41, v42);
  // pto: %hadamard_idx__ssa_v0_pview
  __gm__ bfloat16_t* v43 = PTOAS__GLOBAL_TENSOR_DATA(v23);
  // pto: %hadamard_idx__ssa_v0_pview
  pto::Shape<1, 1, 1, 128, 128> v44 = pto::Shape<1, 1, 1, 128, 128>();
  // pto: %hadamard_idx__ssa_v0_pview
  pto::Stride<16384, 16384, 16384, 128, 1> v45 = pto::Stride<16384, 16384, 16384, 128, 1>();
  // pto: %hadamard_idx__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 128>, pto::Stride<16384, 16384, 16384, 128, 1>, pto::Layout::ND> v46 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 128>, pto::Stride<16384, 16384, 16384, 128, 1>, pto::Layout::ND>(v43, v44, v45);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  TLOAD(v41, v46);
  // pto: %0
  for (int64_t v47 = (int64_t) v6; v47 < (v5 / v14); v47 += v15) {
    // pto: %1
    ;
    int64_t v48 = (int64_t) ((uint64_t) v47 * (uint64_t) v14);
    // pto: %t__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v49 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %t__tile
    ;
    uint64_t v50 = (uint64_t) v9;
    TASSIGN(v49, v50);
    // pto: %2
    ;
    int64_t v51 = v48 < v13 ? v13 : v48;
    // pto: %qr_bf16_inline5593__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v52 = PTOAS__GLOBAL_TENSOR_DATA(v40);
    // pto: %qr_bf16_inline5593__ssa_v0_pview
    ;
    const int64_t v53 = 0;
    // pto: %qr_bf16_inline5593__ssa_v0_pview
    ;
    const int64_t v54 = 128;
    // pto: %qr_bf16_inline5593__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 64, 128> v55 = pto::Shape<1, 1, 1, 64, 128>();
    // pto: %qr_bf16_inline5593__ssa_v0_pview
    ;
    pto::Stride<8192, 8192, 8192, 128, 1> v56 = pto::Stride<8192, 8192, 8192, 128, 1>();
    // pto: %qr_bf16_inline5593__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND> v57 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND>(v52 + (v53 + v51 * v54), v55, v56);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v49, v57);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %t__tile_Left
    ;
    Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %t__tile_Left
    ;
    uint64_t v59 = (uint64_t) v8;
    TASSIGN(v58, v59);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    TMOV(v58, v49);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    // pto: %qh_hadamard_inline1156_inline5641__tile_Right
    ;
    Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v60 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v10, v10);
    // pto: %qh_hadamard_inline1156_inline5641__tile_Right
    ;
    uint64_t v61 = (uint64_t) v8;
    TASSIGN(v60, v61);
    TMOV(v60, v41);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    // pto: %qh_acc_inline1150_inline5571__tile
    ;
    Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v62 = Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v14, v10);
    // pto: %qh_acc_inline1150_inline5571__tile
    ;
    uint64_t v63 = (uint64_t) v8;
    TASSIGN(v62, v63);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    TMATMUL(v62, v58, v60);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %qh_acc_gm_inline1160_inline5575__iter_v1_pview
    ;
    __gm__ float* v64 = PTOAS__GLOBAL_TENSOR_DATA(v32);
    // pto: %qh_acc_gm_inline1160_inline5575__iter_v1_pview
    ;
    const int64_t v65 = 0;
    // pto: %qh_acc_gm_inline1160_inline5575__iter_v1_pview
    ;
    const int64_t v66 = 128;
    // pto: %qh_acc_gm_inline1160_inline5575__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 64, 128> v67 = pto::Shape<1, 1, 1, 64, 128>();
    // pto: %qh_acc_gm_inline1160_inline5575__iter_v1_pview
    ;
    pto::Stride<8192, 8192, 8192, 128, 1> v68 = pto::Stride<8192, 8192, 8192, 128, 1>();
    // pto: %qh_acc_gm_inline1160_inline5575__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND> v69 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND>(v64 + (v65 + v51 * v66), v67, v68);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    TSTORE(v69, v62);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}