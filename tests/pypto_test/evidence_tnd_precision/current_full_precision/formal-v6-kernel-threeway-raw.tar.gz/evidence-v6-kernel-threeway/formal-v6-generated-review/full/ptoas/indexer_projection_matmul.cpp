#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_projection_matmul(__gm__ int32_t* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, __gm__ float* v4, int64_t v5, int64_t v6, int64_t v7, int32_t v8, int32_t v9) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v10 = 0;
  // pto: %c8192_i64
  const int64_t v11 = 8192;
  // pto: %c16_index
  const int64_t v12 = 16;
  // pto: %c4_index
  const int64_t v13 = 4;
  // pto: %c1_index
  const int64_t v14 = 1;
  // pto: %c4096_index
  const int64_t v15 = 4096;
  // pto: %c64_index
  const int64_t v16 = 64;
  // pto: %c0_index
  const int64_t v17 = 0;
  // pto: %c256_index
  const int64_t v18 = 256;
  // pto: %normed__ssa_v0_view
  const int64_t v19 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v20 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v21 = 1;
  // pto: %normed__ssa_v0_view
  int64_t v22 = (int64_t) v6;
  // pto: %normed__ssa_v0_view
  int64_t v23 = v22 * v15;
  // pto: %normed__ssa_v0_view
  int64_t v24 = v21 * v23;
  // pto: %normed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v25 = pto::Shape<1, 1, 1, -1, -1>(v19, v20, v21, v22, v15);
  // pto: %normed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v26 = pto::Stride<-1, -1, -1, -1, -1>(v20 * v24, v24, v23, v15, v14);
  // pto: %normed__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v27 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v25, v26);
  // pto: %weights_proj__ssa_v0_view
  const int64_t v28 = 1;
  // pto: %weights_proj__ssa_v0_view
  const int64_t v29 = 1;
  // pto: %weights_proj__ssa_v0_view
  const int64_t v30 = 1;
  // pto: %weights_proj__ssa_v0_view
  int64_t v31 = v16 * v15;
  // pto: %weights_proj__ssa_v0_view
  int64_t v32 = v30 * v31;
  // pto: %weights_proj__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v33 = pto::Shape<1, 1, 1, -1, -1>(v28, v29, v30, v16, v15);
  // pto: %weights_proj__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v34 = pto::Stride<-1, -1, -1, -1, -1>(v29 * v32, v32, v31, v15, v14);
  // pto: %weights_proj__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v35 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v33, v34);
  // pto: %19
  int64_t v36 = (int64_t) ((uint64_t) v7 * (uint64_t) v12);
  // pto: %accum_inline1306__ssa_v0_view
  const int64_t v37 = 1;
  // pto: %accum_inline1306__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %accum_inline1306__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %accum_inline1306__ssa_v0_view
  int64_t v40 = v36 * v16;
  // pto: %accum_inline1306__ssa_v0_view
  int64_t v41 = v39 * v40;
  // pto: %accum_inline1306__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v42 = pto::Shape<1, 1, 1, -1, -1>(v37, v38, v39, v36, v16);
  // pto: %accum_inline1306__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v43 = pto::Stride<-1, -1, -1, -1, -1>(v38 * v41, v41, v40, v16, v14);
  // pto: %accum_inline1306__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v44 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v42, v43);
  // pto: %worker_inline1309__ssa_v0
  int64_t v45 = (int64_t) v8;
  // pto: %1
  int64_t v46 = v45 / v13;
  // pto: %2
  int64_t v47 = v45 % v13;
  // pto: %3
  int64_t v48 = (int64_t) ((uint64_t) v46 * (uint64_t) v12);
  // pto: %4
  int64_t v49 = (int64_t) ((uint64_t) v47 * (uint64_t) v12);
  // pto: %5
  int64_t v50 = (int64_t) ((uint64_t) v5 - (uint64_t) v48);
  // pto: %6
  int64_t v51 = v50 < v12 ? v50 : v12;
  // pto: %tile_inline1308__tile
  Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v52 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v12, v12);
  // pto: %tile_inline1308__tile
  uint64_t v53 = (uint64_t) v10;
  TASSIGN(v52, v53);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t v54 = v17; v54 < v12; v54 += v14) {
    // pto: %flat_offset_mul, %flat_offset, %7, %8, %k_block_inline1316__tile
    ;
    int32_t v55 = (v1)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v46 * (uint64_t) v13) + (uint64_t) v47) * (uint64_t) v12) + (uint64_t) v54)];
    // pto: %9
    ;
    int64_t v56 = (int64_t) v55;
    // pto: %10
    ;
    int64_t v57 = v56 < v17 ? v17 : v56;
    // pto: %11
    ;
    int64_t v58 = (int64_t) ((uint64_t) v57 * (uint64_t) v18);
    // pto: %a_inline1301__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v59 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v18);
    // pto: %a_inline1301__tile
    ;
    uint64_t v60 = (uint64_t) v10;
    TASSIGN(v59, v60);
    // pto: %12
    ;
    int64_t v61 = v48 < v17 ? v17 : v48;
    // pto: %13
    ;
    int64_t v62 = v58 < v17 ? v17 : v58;
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v63 = 0;
    // pto: %normed__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v64 = PTOAS__GLOBAL_TENSOR_DATA(v27);
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v65 = 1;
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v66 = 1;
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v67 = 1;
    // pto: %normed__ssa_v0_pview
    ;
    int64_t v68 = v51 * v15;
    // pto: %normed__ssa_v0_pview
    ;
    int64_t v69 = v67 * v68;
    // pto: %normed__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 256> v70 = pto::Shape<1, 1, 1, -1, 256>(v65, v66, v67, v51, v18);
    // pto: %normed__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v71 = pto::Stride<-1, -1, -1, -1, -1>(v66 * v69, v69, v68, v15, v14);
    // pto: %normed__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v72 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v64 + (v63 + v61 * v15 + v62 * v14), v70, v71);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v59, v72);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %b_inline1300__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v73 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v12, v18);
    // pto: %b_inline1300__tile
    ;
    uint64_t v74 = (uint64_t) v11;
    TASSIGN(v73, v74);
    // pto: %14
    ;
    int64_t v75 = v49 < v17 ? v17 : v49;
    // pto: %weights_proj__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v76 = PTOAS__GLOBAL_TENSOR_DATA(v35);
    // pto: %weights_proj__ssa_v0_pview
    ;
    const int64_t v77 = 0;
    // pto: %weights_proj__ssa_v0_pview
    ;
    const int64_t v78 = 4096;
    // pto: %weights_proj__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 16, 256> v79 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %weights_proj__ssa_v0_pview
    ;
    pto::Stride<65536, 65536, 65536, 4096, 1> v80 = pto::Stride<65536, 65536, 65536, 4096, 1>();
    // pto: %weights_proj__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v81 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v76 + (v77 + v75 * v78 + v62), v79, v80);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v73, v81);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    // pto: %b_inline1300__tile_t
    ;
    Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v82 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v12);
    // pto: %b_inline1300__tile_t
    ;
    uint64_t v83 = (uint64_t) v11;
    TASSIGN(v82, v83);
    // pto: %a_inline1301__tile_Left
    ;
    Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v84 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v18);
    // pto: %a_inline1301__tile_Left
    ;
    uint64_t v85 = (uint64_t) v10;
    TASSIGN(v84, v85);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    TMOV(v84, v59);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    // pto: %b_inline1300__tile_t_Right
    ;
    Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v86 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v12);
    // pto: %b_inline1300__tile_t_Right
    ;
    uint64_t v87 = (uint64_t) v10;
    TASSIGN(v86, v87);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    TMOV(v86, v82);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    // pto: %16
    ;
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    if (v54 == v17) {
      TMATMUL(v52, v84, v86);
    } else {
      TMATMUL_ACC(v52, v52, v84, v86);
    };
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  }
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  // pto: %17
  int64_t v88 = v48 < v17 ? v17 : v48;
  // pto: %18
  int64_t v89 = v49 < v17 ? v17 : v49;
  // pto: %accum_inline1306__ssa_v0_pview
  __gm__ float* v90 = PTOAS__GLOBAL_TENSOR_DATA(v44);
  // pto: %accum_inline1306__ssa_v0_pview
  const int64_t v91 = 0;
  // pto: %accum_inline1306__ssa_v0_pview
  const int64_t v92 = 64;
  // pto: %accum_inline1306__ssa_v0_pview
  pto::Shape<1, 1, 1, 16, 16> v93 = pto::Shape<1, 1, 1, 16, 16>();
  // pto: %accum_inline1306__ssa_v0_pview
  pto::Stride<1024, 1024, 1024, 64, 1> v94 = pto::Stride<1024, 1024, 1024, 64, 1>();
  // pto: %accum_inline1306__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND> v95 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND>(v90 + (v91 + v88 * v92 + v89), v93, v94);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE(v95, v52);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}