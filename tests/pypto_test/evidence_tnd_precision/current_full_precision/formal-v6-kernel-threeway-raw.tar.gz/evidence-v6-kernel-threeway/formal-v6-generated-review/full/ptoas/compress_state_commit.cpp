#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void compress_state_commit(__gm__ float* v1, __gm__ int32_t* v2, __gm__ int32_t* v3, __gm__ int64_t* v4, __gm__ float* v5, __gm__ float* v6, __gm__ float* v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int64_t v12, int64_t v13, int32_t v14, int32_t v15) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v16 = 0;
  // pto: %c4096_i64
  const int64_t v17 = 4096;
  // pto: %c1_index
  const int64_t v18 = 1;
  // pto: %c2_index
  const int64_t v19 = 2;
  // pto: %c384_index
  const int64_t v20 = 384;
  // pto: %c1024_index
  const int64_t v21 = 1024;
  // pto: %c4_index
  const int64_t v22 = 4;
  // pto: %c0_index
  const int64_t v23 = 0;
  // pto: %c2048_index
  const int64_t v24 = 2048;
  // pto: %c4_i64
  const int64_t v25 = 4;
  // pto: %compress_state__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %compress_state__ssa_v0_view
  const int64_t v27 = 1;
  // pto: %compress_state__ssa_v0_view
  const int64_t v28 = 1;
  // pto: %compress_state__ssa_v0_view
  int64_t v29 = (int64_t) v10;
  // pto: %compress_state__ssa_v0_view
  int64_t v30 = (int64_t) v11;
  // pto: %compress_state__ssa_v0_view
  int64_t v31 = v29 * v30;
  // pto: %compress_state__ssa_v0_view
  int64_t v32 = v28 * v31;
  // pto: %compress_state__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v33 = pto::Shape<1, 1, 1, -1, -1>(v26, v27, v28, v29, (int64_t) v11);
  // pto: %compress_state__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v34 = pto::Stride<-1, -1, -1, -1, -1>(v27 * v32, v32, v31, v30, v18);
  // pto: %compress_state__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v35 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v33, v34);
  // pto: %cmp4_kv_proj_pad_inline5346__ssa_v0_view
  const int64_t v36 = 1;
  // pto: %cmp4_kv_proj_pad_inline5346__ssa_v0_view
  const int64_t v37 = 1;
  // pto: %cmp4_kv_proj_pad_inline5346__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %cmp4_kv_proj_pad_inline5346__ssa_v0_view
  int64_t v39 = v20 * v21;
  // pto: %cmp4_kv_proj_pad_inline5346__ssa_v0_view
  int64_t v40 = v38 * v39;
  // pto: %cmp4_kv_proj_pad_inline5346__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v41 = pto::Shape<1, 1, 1, -1, -1>(v36, v37, v38, v20, v21);
  // pto: %cmp4_kv_proj_pad_inline5346__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v42 = pto::Stride<-1, -1, -1, -1, -1>(v37 * v40, v40, v39, v21, v18);
  // pto: %cmp4_kv_proj_pad_inline5346__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v43 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v41, v42);
  // pto: %cmp4_score_proj_pad_inline5339__ssa_v0_view
  const int64_t v44 = 1;
  // pto: %cmp4_score_proj_pad_inline5339__ssa_v0_view
  const int64_t v45 = 1;
  // pto: %cmp4_score_proj_pad_inline5339__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %cmp4_score_proj_pad_inline5339__ssa_v0_view
  int64_t v47 = v20 * v21;
  // pto: %cmp4_score_proj_pad_inline5339__ssa_v0_view
  int64_t v48 = v46 * v47;
  // pto: %cmp4_score_proj_pad_inline5339__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v49 = pto::Shape<1, 1, 1, -1, -1>(v44, v45, v46, v20, v21);
  // pto: %cmp4_score_proj_pad_inline5339__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v50 = pto::Stride<-1, -1, -1, -1, -1>(v45 * v48, v48, v47, v21, v18);
  // pto: %cmp4_score_proj_pad_inline5339__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v51 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v49, v50);
  // pto: %cmp_ape__ssa_v0_view
  const int64_t v52 = 1;
  // pto: %cmp_ape__ssa_v0_view
  const int64_t v53 = 1;
  // pto: %cmp_ape__ssa_v0_view
  const int64_t v54 = 1;
  // pto: %cmp_ape__ssa_v0_view
  int64_t v55 = v22 * v21;
  // pto: %cmp_ape__ssa_v0_view
  int64_t v56 = v54 * v55;
  // pto: %cmp_ape__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v57 = pto::Shape<1, 1, 1, -1, -1>(v52, v53, v54, v22, v21);
  // pto: %cmp_ape__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v58 = pto::Stride<-1, -1, -1, -1, -1>(v53 * v56, v56, v55, v21, v18);
  // pto: %cmp_ape__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v59 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v57, v58);
  // pto: %commit_worker_inline5365__ssa_v0
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v60 = (int64_t) v14; v60 < v8; v60 += v9) {
    // pto: %3
    ;
    int32_t v61 = (v2)[v60];
    // pto: %4
    ;
    // pto: %6, %5
    ;
    int32_t v62 = (v2)[(int64_t) ((uint64_t) v60 + (uint64_t) v18)];
    // pto: %7
    ;
    for (int64_t v63 = (int64_t) v61; v63 < ((int64_t) v62); v63 += v18) {
      // pto: %flat_offset_mul
      ;
      int64_t v64 = (int64_t) ((uint64_t) v63 * (uint64_t) v19);
      // pto: %state_page_inline5327__tile
      ;
      int32_t v65 = (v3)[v64];
      // pto: %9, %state_offset_inline5324__tile
      ;
      int32_t v66 = (v3)[(int64_t) ((uint64_t) v64 + (uint64_t) v18)];
      // pto: %10
      ;
      int64_t v67 = (int64_t) v65;
      // pto: %12
      ;
      int64_t v68 = (int64_t) v66;
      // pto: %11, %13, %14
      ;
      if (v67 >= v23 & v68 >= v23) {
        // pto: %token_pos_inline5320__tile
        ;
        int64_t v69 = (v4)[v63];
        // pto: %17
        ;
        int64_t v70 = (int64_t) ((uint64_t) v68 * (uint64_t) v24);
        // pto: %18
        ;
        int64_t v71 = v69 % v25;
        // pto: %t__tile
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v72 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v21);
        // pto: %t__tile
        ;
        uint64_t v73 = (uint64_t) v16;
        TASSIGN(v72, v73);
        // pto: %20
        ;
        int64_t v74 = v63 < v23 ? v23 : v63;
        // pto: %cmp4_kv_proj_pad_inline5346__ssa_v0_pview
        ;
        __gm__ float* v75 = PTOAS__GLOBAL_TENSOR_DATA(v43);
        // pto: %cmp4_kv_proj_pad_inline5346__ssa_v0_pview
        ;
        const int64_t v76 = 0;
        // pto: %cmp4_kv_proj_pad_inline5346__ssa_v0_pview
        ;
        const int64_t v77 = 1024;
        // pto: %cmp4_kv_proj_pad_inline5346__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 1024> v78 = pto::Shape<1, 1, 1, 1, 1024>();
        // pto: %cmp4_kv_proj_pad_inline5346__ssa_v0_pview
        ;
        pto::Stride<1024, 1024, 1024, 1024, 1> v79 = pto::Stride<1024, 1024, 1024, 1024, 1>();
        // pto: %cmp4_kv_proj_pad_inline5346__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v80 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v75 + (v76 + v74 * v77), v78, v79);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
        TLOAD(v72, v80);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
        // pto: %21
        ;
        int64_t v81 = v67 < v23 ? v23 : v67;
        // pto: %22
        ;
        int64_t v82 = v70 < v23 ? v23 : v70;
        // pto: %compress_state__iter_v3_pview
        ;
        int64_t v83 = (int64_t) v11;
        // pto: %compress_state__iter_v3_pview
        ;
        const int64_t v84 = 0;
        // pto: %compress_state__iter_v3_pview
        ;
        __gm__ float* v85 = PTOAS__GLOBAL_TENSOR_DATA(v35);
        // pto: %compress_state__iter_v3_pview
        ;
        const int64_t v86 = 1;
        // pto: %compress_state__iter_v3_pview
        ;
        const int64_t v87 = 1;
        // pto: %compress_state__iter_v3_pview
        ;
        const int64_t v88 = 1;
        // pto: %compress_state__iter_v3_pview
        ;
        int64_t v89 = v18 * v83;
        // pto: %compress_state__iter_v3_pview
        ;
        int64_t v90 = v88 * v89;
        // pto: %compress_state__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 1, 1024> v91 = pto::Shape<1, 1, 1, 1, 1024>(v86, v87, v88, v18, v21);
        // pto: %compress_state__iter_v3_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v92 = pto::Stride<-1, -1, -1, -1, -1>(v87 * v90, v90, v89, v83, v18);
        // pto: %compress_state__iter_v3_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v93 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v85 + (v84 + v81 * v83 + v82 * v18), v91, v92);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
        TSTORE(v93, v72);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
        // pto: %0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v21);
        // pto: %0
        ;
        uint64_t v95 = (uint64_t) v16;
        TASSIGN(v94, v95);
        // pto: %cmp4_score_proj_pad_inline5339__ssa_v0_pview
        ;
        __gm__ float* v96 = PTOAS__GLOBAL_TENSOR_DATA(v51);
        // pto: %cmp4_score_proj_pad_inline5339__ssa_v0_pview
        ;
        const int64_t v97 = 0;
        // pto: %cmp4_score_proj_pad_inline5339__ssa_v0_pview
        ;
        const int64_t v98 = 1024;
        // pto: %cmp4_score_proj_pad_inline5339__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 1024> v99 = pto::Shape<1, 1, 1, 1, 1024>();
        // pto: %cmp4_score_proj_pad_inline5339__ssa_v0_pview
        ;
        pto::Stride<1024, 1024, 1024, 1024, 1> v100 = pto::Stride<1024, 1024, 1024, 1024, 1>();
        // pto: %cmp4_score_proj_pad_inline5339__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v101 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v96 + (v97 + v74 * v98), v99, v100);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
        TLOAD(v94, v101);
        // pto: %1
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v21);
        // pto: %1
        ;
        uint64_t v103 = (uint64_t) v17;
        TASSIGN(v102, v103);
        // pto: %24
        ;
        int64_t v104 = v71 < v23 ? v23 : v71;
        // pto: %cmp_ape__ssa_v0_pview
        ;
        __gm__ float* v105 = PTOAS__GLOBAL_TENSOR_DATA(v59);
        // pto: %cmp_ape__ssa_v0_pview
        ;
        const int64_t v106 = 0;
        // pto: %cmp_ape__ssa_v0_pview
        ;
        const int64_t v107 = 1024;
        // pto: %cmp_ape__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 1024> v108 = pto::Shape<1, 1, 1, 1, 1024>();
        // pto: %cmp_ape__ssa_v0_pview
        ;
        pto::Stride<1024, 1024, 1024, 1024, 1> v109 = pto::Stride<1024, 1024, 1024, 1024, 1>();
        // pto: %cmp_ape__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v110 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v105 + (v106 + v104 * v107), v108, v109);
        TLOAD(v102, v110);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %2
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v21);
        // pto: %2
        ;
        uint64_t v112 = (uint64_t) v16;
        TASSIGN(v111, v112);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        TADD(v111, v94, v102);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %27
        ;
        int64_t v113 = (int64_t) ((uint64_t) v70 + (uint64_t) v21);
        // pto: %28
        ;
        int64_t v114 = v113 < v23 ? v23 : v113;
        // pto: %compress_state__tile_pview
        ;
        int64_t v115 = (int64_t) v11;
        // pto: %compress_state__tile_pview
        ;
        const int64_t v116 = 0;
        // pto: %compress_state__tile_pview
        ;
        __gm__ float* v117 = PTOAS__GLOBAL_TENSOR_DATA(v35);
        // pto: %compress_state__tile_pview
        ;
        const int64_t v118 = 1;
        // pto: %compress_state__tile_pview
        ;
        const int64_t v119 = 1;
        // pto: %compress_state__tile_pview
        ;
        const int64_t v120 = 1;
        // pto: %compress_state__tile_pview
        ;
        int64_t v121 = v18 * v115;
        // pto: %compress_state__tile_pview
        ;
        int64_t v122 = v120 * v121;
        // pto: %compress_state__tile_pview
        ;
        pto::Shape<1, 1, 1, 1, 1024> v123 = pto::Shape<1, 1, 1, 1, 1024>(v118, v119, v120, v18, v21);
        // pto: %compress_state__tile_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v124 = pto::Stride<-1, -1, -1, -1, -1>(v119 * v122, v122, v121, v115, v18);
        // pto: %compress_state__tile_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v125 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v117 + (v116 + v81 * v115 + v114 * v18), v123, v124);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v125, v111);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      };
    };
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}