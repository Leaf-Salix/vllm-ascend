#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void hc_post(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, __gm__ float* v4, __gm__ float* v5, int64_t v6, int64_t v7, int64_t v8, int32_t v9, int32_t v10) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c16384_i64
  const int64_t v11 = 16384;
  // pto: %c32768_i64
  const int64_t v12 = 32768;
  // pto: %c49152_i64
  const int64_t v13 = 49152;
  // pto: %c65536_i64
  const int64_t v14 = 65536;
  // pto: %c81920_i64
  const int64_t v15 = 81920;
  // pto: %c0_i64
  const int64_t v16 = 0;
  // pto: %c98304_i64
  const int64_t v17 = 98304;
  // pto: %c114688_i64
  const int64_t v18 = 114688;
  // pto: %c122880_i64
  const int64_t v19 = 122880;
  // pto: %c16384_index
  const int64_t v20 = 16384;
  // pto: %c1_index
  const int64_t v21 = 1;
  // pto: %c4096_index
  const int64_t v22 = 4096;
  // pto: %c4_index
  const int64_t v23 = 4;
  // pto: %c16_index
  const int64_t v24 = 16;
  // pto: %c2_index
  const int64_t v25 = 2;
  // pto: %c0_index
  const int64_t v26 = 0;
  // pto: %c8_index
  const int64_t v27 = 8;
  // pto: %c12_index
  const int64_t v28 = 12;
  // pto: %c5_index
  const int64_t v29 = 5;
  // pto: %c9_index
  const int64_t v30 = 9;
  // pto: %c13_index
  const int64_t v31 = 13;
  // pto: %c6_index
  const int64_t v32 = 6;
  // pto: %c10_index
  const int64_t v33 = 10;
  // pto: %c14_index
  const int64_t v34 = 14;
  // pto: %c3_index
  const int64_t v35 = 3;
  // pto: %c7_index
  const int64_t v36 = 7;
  // pto: %c11_index
  const int64_t v37 = 11;
  // pto: %c15_index
  const int64_t v38 = 15;
  // pto: %c8192_index
  const int64_t v39 = 8192;
  // pto: %c12288_index
  const int64_t v40 = 12288;
  // pto: %cn1_index
  const int64_t v41 = -1;
  // pto: %y_flat_inline1546__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %y_flat_inline1546__ssa_v0_view
  const int64_t v43 = 1;
  // pto: %y_flat_inline1546__ssa_v0_view
  const int64_t v44 = 1;
  // pto: %y_flat_inline1546__ssa_v0_view
  int64_t v45 = (int64_t) v7;
  // pto: %y_flat_inline1546__ssa_v0_view
  int64_t v46 = v45 * v20;
  // pto: %y_flat_inline1546__ssa_v0_view
  int64_t v47 = v44 * v46;
  // pto: %y_flat_inline1546__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v48 = pto::Shape<1, 1, 1, -1, -1>(v42, v43, v44, v45, v20);
  // pto: %y_flat_inline1546__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v49 = pto::Stride<-1, -1, -1, -1, -1>(v43 * v47, v47, v46, v20, v21);
  // pto: %y_flat_inline1546__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v50 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v48, v49);
  // pto: %attention_out__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %attention_out__ssa_v0_view
  const int64_t v52 = 1;
  // pto: %attention_out__ssa_v0_view
  const int64_t v53 = 1;
  // pto: %attention_out__ssa_v0_view
  int64_t v54 = (int64_t) v8;
  // pto: %attention_out__ssa_v0_view
  int64_t v55 = v54 * v22;
  // pto: %attention_out__ssa_v0_view
  int64_t v56 = v53 * v55;
  // pto: %attention_out__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v57 = pto::Shape<1, 1, 1, -1, -1>(v51, v52, v53, v54, v22);
  // pto: %attention_out__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v58 = pto::Stride<-1, -1, -1, -1, -1>(v52 * v56, v56, v55, v22, v21);
  // pto: %attention_out__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v59 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v57, v58);
  // pto: %residual_flat_inline1549__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %residual_flat_inline1549__ssa_v0_view
  const int64_t v61 = 1;
  // pto: %residual_flat_inline1549__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %residual_flat_inline1549__ssa_v0_view
  int64_t v63 = (int64_t) v7;
  // pto: %residual_flat_inline1549__ssa_v0_view
  int64_t v64 = v63 * v20;
  // pto: %residual_flat_inline1549__ssa_v0_view
  int64_t v65 = v62 * v64;
  // pto: %residual_flat_inline1549__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v66 = pto::Shape<1, 1, 1, -1, -1>(v60, v61, v62, v63, v20);
  // pto: %residual_flat_inline1549__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v67 = pto::Stride<-1, -1, -1, -1, -1>(v61 * v65, v65, v64, v20, v21);
  // pto: %residual_flat_inline1549__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v68 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v66, v67);
  // pto: %token_block_inline1548__ssa_v0, %145
  int64_t v69 = (int64_t) ((uint64_t) ((int64_t) v9) * (uint64_t) v23);
  // pto: %146
  int64_t v70 = (int64_t) ((uint64_t) v69 + (uint64_t) v23);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t v71 = v69; v71 < v70; v71 += v25) {
    // pto: %147
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    if (v71 < v7) {
      // pto: %flat_offset_mul
      ;
      int64_t v72 = (int64_t) ((uint64_t) v71 * (uint64_t) v23);
      // pto: %post_scalar_inline5941__tile
      ;
      float v73 = (v4)[v72];
      // pto: %148
      ;
      int64_t v74 = (int64_t) ((uint64_t) v71 * (uint64_t) v24);
      // pto: %comb_scalar_0_inline5937__tile
      ;
      float v75 = (v5)[v74];
      // pto: %151, %comb_scalar_1_inline5939__tile
      ;
      float v76 = (v5)[(int64_t) ((uint64_t) v74 + (uint64_t) v23)];
      // pto: %153, %comb_scalar_2_inline5927__tile
      ;
      float v77 = (v5)[(int64_t) ((uint64_t) v74 + (uint64_t) v27)];
      // pto: %155, %comb_scalar_3_inline5926__tile
      ;
      float v78 = (v5)[(int64_t) ((uint64_t) v74 + (uint64_t) v28)];
      // pto: %158, %156
      ;
      float v79 = (v4)[(int64_t) ((uint64_t) v72 + (uint64_t) v21)];
      // pto: %161, %159
      ;
      float v80 = (v5)[(int64_t) ((uint64_t) v74 + (uint64_t) v21)];
      // pto: %164, %162
      ;
      float v81 = (v5)[(int64_t) ((uint64_t) v74 + (uint64_t) v29)];
      // pto: %167, %165
      ;
      float v82 = (v5)[(int64_t) ((uint64_t) v74 + (uint64_t) v30)];
      // pto: %170, %168
      ;
      float v83 = (v5)[(int64_t) ((uint64_t) v74 + (uint64_t) v31)];
      // pto: %173, %171
      ;
      float v84 = (v4)[(int64_t) ((uint64_t) v72 + (uint64_t) v25)];
      // pto: %176, %174
      ;
      float v85 = (v5)[(int64_t) ((uint64_t) v74 + (uint64_t) v25)];
      // pto: %179, %177
      ;
      float v86 = (v5)[(int64_t) ((uint64_t) v74 + (uint64_t) v32)];
      // pto: %182, %180
      ;
      float v87 = (v5)[(int64_t) ((uint64_t) v74 + (uint64_t) v33)];
      // pto: %185, %183
      ;
      float v88 = (v5)[(int64_t) ((uint64_t) v74 + (uint64_t) v34)];
      // pto: %188, %186
      ;
      float v89 = (v4)[(int64_t) ((uint64_t) v72 + (uint64_t) v35)];
      // pto: %191, %189
      ;
      float v90 = (v5)[(int64_t) ((uint64_t) v74 + (uint64_t) v35)];
      // pto: %194, %192
      ;
      float v91 = (v5)[(int64_t) ((uint64_t) v74 + (uint64_t) v36)];
      // pto: %197, %195
      ;
      float v92 = (v5)[(int64_t) ((uint64_t) v74 + (uint64_t) v37)];
      // pto: %200, %198
      ;
      float v93 = (v5)[(int64_t) ((uint64_t) v74 + (uint64_t) v38)];
      // pto: %x_block_inline1543__tile
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %x_block_inline1543__tile
      ;
      uint64_t v95 = (uint64_t) v11;
      TASSIGN(v94, v95);
      // pto: %201
      ;
      int64_t v96 = v71 < v26 ? v26 : v71;
      // pto: %attention_out__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v97 = PTOAS__GLOBAL_TENSOR_DATA(v59);
      // pto: %attention_out__ssa_v0_pview
      ;
      const int64_t v98 = 0;
      // pto: %attention_out__ssa_v0_pview
      ;
      const int64_t v99 = 4096;
      // pto: %attention_out__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 4096> v100 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %attention_out__ssa_v0_pview
      ;
      pto::Stride<4096, 4096, 4096, 4096, 1> v101 = pto::Stride<4096, 4096, 4096, 4096, 1>();
      // pto: %attention_out__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v102 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v97 + (v98 + v96 * v99), v100, v101);
      TLOAD(v94, v102);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %202
      ;
      int64_t v103 = (int64_t) ((uint64_t) v7 - (uint64_t) v71);
      // pto: %203
      ;
      int64_t v104 = v103 < v26 ? v26 : v103;
      // pto: %204
      ;
      int64_t v105 = v104 < v21 ? v104 : v21;
      // pto: %t__tile
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %t__tile
      ;
      uint64_t v107 = (uint64_t) v12;
      TASSIGN(v106, v107);
      // pto: %residual_flat_inline1549__ssa_v0_pview
      ;
      const int64_t v108 = 0;
      // pto: %residual_flat_inline1549__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v109 = PTOAS__GLOBAL_TENSOR_DATA(v68);
      // pto: %residual_flat_inline1549__ssa_v0_pview
      ;
      const int64_t v110 = 1;
      // pto: %residual_flat_inline1549__ssa_v0_pview
      ;
      const int64_t v111 = 1;
      // pto: %residual_flat_inline1549__ssa_v0_pview
      ;
      const int64_t v112 = 1;
      // pto: %residual_flat_inline1549__ssa_v0_pview
      ;
      int64_t v113 = v105 * v20;
      // pto: %residual_flat_inline1549__ssa_v0_pview
      ;
      int64_t v114 = v112 * v113;
      // pto: %residual_flat_inline1549__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 4096> v115 = pto::Shape<1, 1, 1, -1, 4096>(v110, v111, v112, v105, v22);
      // pto: %residual_flat_inline1549__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v116 = pto::Stride<-1, -1, -1, -1, -1>(v111 * v114, v114, v113, v20, v21);
      // pto: %residual_flat_inline1549__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v117 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v109 + (v108 + v96 * v20 + v26 * v21), v115, v116);
      TLOAD(v106, v117);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %0
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %0
      ;
      uint64_t v119 = (uint64_t) v13;
      TASSIGN(v118, v119);
      // pto: %216
      ;
      const int64_t v120 = 0;
      // pto: %216
      ;
      __gm__ bfloat16_t* v121 = PTOAS__GLOBAL_TENSOR_DATA(v68);
      // pto: %216
      ;
      const int64_t v122 = 1;
      // pto: %216
      ;
      const int64_t v123 = 1;
      // pto: %216
      ;
      const int64_t v124 = 1;
      // pto: %216
      ;
      int64_t v125 = v105 * v20;
      // pto: %216
      ;
      int64_t v126 = v124 * v125;
      // pto: %216
      ;
      pto::Shape<1, 1, 1, -1, 4096> v127 = pto::Shape<1, 1, 1, -1, 4096>(v122, v123, v124, v105, v22);
      // pto: %216
      ;
      pto::Stride<-1, -1, -1, -1, -1> v128 = pto::Stride<-1, -1, -1, -1, -1>(v123 * v126, v126, v125, v20, v21);
      // pto: %216
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v129 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v121 + (v120 + v96 * v20 + v22 * v21), v127, v128);
      TLOAD(v118, v129);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %1
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %1
      ;
      uint64_t v131 = (uint64_t) v14;
      TASSIGN(v130, v131);
      // pto: %224
      ;
      const int64_t v132 = 0;
      // pto: %224
      ;
      __gm__ bfloat16_t* v133 = PTOAS__GLOBAL_TENSOR_DATA(v68);
      // pto: %224
      ;
      const int64_t v134 = 1;
      // pto: %224
      ;
      const int64_t v135 = 1;
      // pto: %224
      ;
      const int64_t v136 = 1;
      // pto: %224
      ;
      int64_t v137 = v105 * v20;
      // pto: %224
      ;
      int64_t v138 = v136 * v137;
      // pto: %224
      ;
      pto::Shape<1, 1, 1, -1, 4096> v139 = pto::Shape<1, 1, 1, -1, 4096>(v134, v135, v136, v105, v22);
      // pto: %224
      ;
      pto::Stride<-1, -1, -1, -1, -1> v140 = pto::Stride<-1, -1, -1, -1, -1>(v135 * v138, v138, v137, v20, v21);
      // pto: %224
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v141 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v133 + (v132 + v96 * v20 + v39 * v21), v139, v140);
      TLOAD(v130, v141);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %2
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v142 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %2
      ;
      uint64_t v143 = (uint64_t) v15;
      TASSIGN(v142, v143);
      // pto: %232
      ;
      const int64_t v144 = 0;
      // pto: %232
      ;
      __gm__ bfloat16_t* v145 = PTOAS__GLOBAL_TENSOR_DATA(v68);
      // pto: %232
      ;
      const int64_t v146 = 1;
      // pto: %232
      ;
      const int64_t v147 = 1;
      // pto: %232
      ;
      const int64_t v148 = 1;
      // pto: %232
      ;
      int64_t v149 = v105 * v20;
      // pto: %232
      ;
      int64_t v150 = v148 * v149;
      // pto: %232
      ;
      pto::Shape<1, 1, 1, -1, 4096> v151 = pto::Shape<1, 1, 1, -1, 4096>(v146, v147, v148, v105, v22);
      // pto: %232
      ;
      pto::Stride<-1, -1, -1, -1, -1> v152 = pto::Stride<-1, -1, -1, -1, -1>(v147 * v150, v150, v149, v20, v21);
      // pto: %232
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v153 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v145 + (v144 + v96 * v20 + v40 * v21), v151, v152);
      TLOAD(v142, v153);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      // pto: %x_f32_inline5940__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v154 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %x_f32_inline5940__tile
      ;
      uint64_t v155 = (uint64_t) v16;
      TASSIGN(v154, v155);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      RoundMode v156 = RoundMode::CAST_ROUND;
      SaturationMode v157 = SaturationMode::ON;
      TCVT(v154, v94, v156, v157);
      // pto: %res_0_inline5933__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v158 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %res_0_inline5933__tile
      ;
      uint64_t v159 = (uint64_t) v11;
      TASSIGN(v158, v159);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      RoundMode v160 = RoundMode::CAST_ROUND;
      SaturationMode v161 = SaturationMode::ON;
      TCVT(v158, v106, v160, v161);
      // pto: %res_1_inline5931__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v162 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %res_1_inline5931__tile
      ;
      uint64_t v163 = (uint64_t) v12;
      TASSIGN(v162, v163);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      RoundMode v164 = RoundMode::CAST_ROUND;
      SaturationMode v165 = SaturationMode::ON;
      TCVT(v162, v118, v164, v165);
      // pto: %res_2_inline5934__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v166 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %res_2_inline5934__tile
      ;
      uint64_t v167 = (uint64_t) v13;
      TASSIGN(v166, v167);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      RoundMode v168 = RoundMode::CAST_ROUND;
      SaturationMode v169 = SaturationMode::ON;
      TCVT(v166, v130, v168, v169);
      // pto: %res_3_inline5936__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v170 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %res_3_inline5936__tile
      ;
      uint64_t v171 = (uint64_t) v14;
      TASSIGN(v170, v171);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      RoundMode v172 = RoundMode::CAST_ROUND;
      SaturationMode v173 = SaturationMode::ON;
      TCVT(v170, v142, v172, v173);
      // pto: %single_y_inline5942__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %single_y_inline5942__tile
      ;
      uint64_t v175 = (uint64_t) v15;
      TASSIGN(v174, v175);
      pipe_barrier(PIPE_V);
      TMULS(v174, v154, v73);
      // pto: %single_weighted_0_inline5943__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v176 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %single_weighted_0_inline5943__tile
      ;
      uint64_t v177 = (uint64_t) v17;
      TASSIGN(v176, v177);
      TMULS(v176, v158, v75);
      // pto: %single_y_v1_inline5944__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v178 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %single_y_v1_inline5944__tile
      ;
      uint64_t v179 = (uint64_t) v15;
      TASSIGN(v178, v179);
      pipe_barrier(PIPE_V);
      TADD(v178, v174, v176);
      // pto: %single_weighted_1_inline5930__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v180 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %single_weighted_1_inline5930__tile
      ;
      uint64_t v181 = (uint64_t) v17;
      TASSIGN(v180, v181);
      pipe_barrier(PIPE_V);
      TMULS(v180, v162, v76);
      // pto: %single_y_v2_inline5929__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v182 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %single_y_v2_inline5929__tile
      ;
      uint64_t v183 = (uint64_t) v15;
      TASSIGN(v182, v183);
      pipe_barrier(PIPE_V);
      TADD(v182, v178, v180);
      // pto: %single_weighted_2_inline5928__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %single_weighted_2_inline5928__tile
      ;
      uint64_t v185 = (uint64_t) v17;
      TASSIGN(v184, v185);
      pipe_barrier(PIPE_V);
      TMULS(v184, v166, v77);
      // pto: %single_y_v3_inline5935__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v186 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %single_y_v3_inline5935__tile
      ;
      uint64_t v187 = (uint64_t) v15;
      TASSIGN(v186, v187);
      pipe_barrier(PIPE_V);
      TADD(v186, v182, v184);
      // pto: %single_weighted_3_inline5925__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v188 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %single_weighted_3_inline5925__tile
      ;
      uint64_t v189 = (uint64_t) v17;
      TASSIGN(v188, v189);
      pipe_barrier(PIPE_V);
      TMULS(v188, v170, v78);
      // pto: %single_y_v4_inline5932__tile
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v190 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %single_y_v4_inline5932__tile
      ;
      uint64_t v191 = (uint64_t) v15;
      TASSIGN(v190, v191);
      pipe_barrier(PIPE_V);
      TADD(v190, v186, v188);
      // pto: %single_result_inline5924__tile
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %single_result_inline5924__tile
      ;
      uint64_t v193 = (uint64_t) v18;
      TASSIGN(v192, v193);
      pipe_barrier(PIPE_V);
      RoundMode v194 = RoundMode::CAST_RINT;
      SaturationMode v195 = SaturationMode::ON;
      TCVT(v192, v190, v194, v195);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      v192.SetValidShape(v21, v22);
      // pto: %4
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %4
      ;
      uint64_t v197 = (uint64_t) v15;
      TASSIGN(v196, v197);
      pipe_barrier(PIPE_V);
      TMULS(v196, v154, v79);
      // pto: %5
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v198 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %5
      ;
      uint64_t v199 = (uint64_t) v17;
      TASSIGN(v198, v199);
      TMULS(v198, v158, v80);
      // pto: %6
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v200 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %6
      ;
      uint64_t v201 = (uint64_t) v15;
      TASSIGN(v200, v201);
      pipe_barrier(PIPE_V);
      TADD(v200, v196, v198);
      // pto: %7
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v202 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %7
      ;
      uint64_t v203 = (uint64_t) v17;
      TASSIGN(v202, v203);
      pipe_barrier(PIPE_V);
      TMULS(v202, v162, v81);
      // pto: %8
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v204 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %8
      ;
      uint64_t v205 = (uint64_t) v15;
      TASSIGN(v204, v205);
      pipe_barrier(PIPE_V);
      TADD(v204, v200, v202);
      // pto: %9
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v206 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %9
      ;
      uint64_t v207 = (uint64_t) v17;
      TASSIGN(v206, v207);
      pipe_barrier(PIPE_V);
      TMULS(v206, v166, v82);
      // pto: %10
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v208 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %10
      ;
      uint64_t v209 = (uint64_t) v15;
      TASSIGN(v208, v209);
      pipe_barrier(PIPE_V);
      TADD(v208, v204, v206);
      // pto: %11
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %11
      ;
      uint64_t v211 = (uint64_t) v17;
      TASSIGN(v210, v211);
      pipe_barrier(PIPE_V);
      TMULS(v210, v170, v83);
      // pto: %12
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v212 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %12
      ;
      uint64_t v213 = (uint64_t) v15;
      TASSIGN(v212, v213);
      pipe_barrier(PIPE_V);
      TADD(v212, v208, v210);
      // pto: %13
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %13
      ;
      uint64_t v215 = (uint64_t) v19;
      TASSIGN(v214, v215);
      pipe_barrier(PIPE_V);
      RoundMode v216 = RoundMode::CAST_RINT;
      SaturationMode v217 = SaturationMode::ON;
      TCVT(v214, v212, v216, v217);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      v214.SetValidShape(v21, v22);
      // pto: %15
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %15
      ;
      uint64_t v219 = (uint64_t) v15;
      TASSIGN(v218, v219);
      pipe_barrier(PIPE_V);
      TMULS(v218, v154, v84);
      // pto: %16
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %16
      ;
      uint64_t v221 = (uint64_t) v17;
      TASSIGN(v220, v221);
      TMULS(v220, v158, v85);
      // pto: %17
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %17
      ;
      uint64_t v223 = (uint64_t) v15;
      TASSIGN(v222, v223);
      pipe_barrier(PIPE_V);
      TADD(v222, v218, v220);
      // pto: %18
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %18
      ;
      uint64_t v225 = (uint64_t) v17;
      TASSIGN(v224, v225);
      pipe_barrier(PIPE_V);
      TMULS(v224, v162, v86);
      // pto: %19
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v226 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %19
      ;
      uint64_t v227 = (uint64_t) v15;
      TASSIGN(v226, v227);
      pipe_barrier(PIPE_V);
      TADD(v226, v222, v224);
      // pto: %20
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v228 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %20
      ;
      uint64_t v229 = (uint64_t) v17;
      TASSIGN(v228, v229);
      pipe_barrier(PIPE_V);
      TMULS(v228, v166, v87);
      // pto: %21
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v230 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %21
      ;
      uint64_t v231 = (uint64_t) v15;
      TASSIGN(v230, v231);
      pipe_barrier(PIPE_V);
      TADD(v230, v226, v228);
      // pto: %22
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %22
      ;
      uint64_t v233 = (uint64_t) v17;
      TASSIGN(v232, v233);
      pipe_barrier(PIPE_V);
      TMULS(v232, v170, v88);
      // pto: %23
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %23
      ;
      uint64_t v235 = (uint64_t) v15;
      TASSIGN(v234, v235);
      pipe_barrier(PIPE_V);
      TADD(v234, v230, v232);
      // pto: %24
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %24
      ;
      uint64_t v237 = (uint64_t) v15;
      TASSIGN(v236, v237);
      pipe_barrier(PIPE_V);
      RoundMode v238 = RoundMode::CAST_RINT;
      SaturationMode v239 = SaturationMode::ON;
      TCVT(v236, v234, v238, v239);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      v236.SetValidShape(v21, v22);
      // pto: %26
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %26
      ;
      uint64_t v241 = (uint64_t) v16;
      TASSIGN(v240, v241);
      TMULS(v240, v154, v89);
      // pto: %27
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v242 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %27
      ;
      uint64_t v243 = (uint64_t) v11;
      TASSIGN(v242, v243);
      TMULS(v242, v158, v90);
      // pto: %28
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %28
      ;
      uint64_t v245 = (uint64_t) v16;
      TASSIGN(v244, v245);
      pipe_barrier(PIPE_V);
      TADD(v244, v240, v242);
      // pto: %29
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %29
      ;
      uint64_t v247 = (uint64_t) v11;
      TASSIGN(v246, v247);
      pipe_barrier(PIPE_V);
      TMULS(v246, v162, v91);
      // pto: %30
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v248 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %30
      ;
      uint64_t v249 = (uint64_t) v16;
      TASSIGN(v248, v249);
      pipe_barrier(PIPE_V);
      TADD(v248, v244, v246);
      // pto: %31
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v250 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %31
      ;
      uint64_t v251 = (uint64_t) v11;
      TASSIGN(v250, v251);
      pipe_barrier(PIPE_V);
      TMULS(v250, v166, v92);
      // pto: %32
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v252 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %32
      ;
      uint64_t v253 = (uint64_t) v16;
      TASSIGN(v252, v253);
      pipe_barrier(PIPE_V);
      TADD(v252, v248, v250);
      // pto: %33
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v254 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v105, v22);
      // pto: %33
      ;
      uint64_t v255 = (uint64_t) v11;
      TASSIGN(v254, v255);
      pipe_barrier(PIPE_V);
      TMULS(v254, v170, v93);
      // pto: %34
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v256 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %34
      ;
      uint64_t v257 = (uint64_t) v16;
      TASSIGN(v256, v257);
      pipe_barrier(PIPE_V);
      TADD(v256, v252, v254);
      // pto: %35
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v258 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %35
      ;
      uint64_t v259 = (uint64_t) v16;
      TASSIGN(v258, v259);
      pipe_barrier(PIPE_V);
      RoundMode v260 = RoundMode::CAST_RINT;
      SaturationMode v261 = SaturationMode::ON;
      TCVT(v258, v256, v260, v261);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      v258.SetValidShape(v21, v22);
      // pto: %y_flat_inline1546__iter_v1_pview
      ;
      __gm__ bfloat16_t* v262 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %y_flat_inline1546__iter_v1_pview
      ;
      const int64_t v263 = 0;
      // pto: %y_flat_inline1546__iter_v1_pview
      ;
      const int64_t v264 = 16384;
      // pto: %y_flat_inline1546__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, 1, 4096> v265 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %y_flat_inline1546__iter_v1_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v266 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %y_flat_inline1546__iter_v1_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v267 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v262 + (v263 + v96 * v264), v265, v266);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v267, v192);
      // pto: %y_flat_inline1546__tile_pview
      ;
      __gm__ bfloat16_t* v268 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %y_flat_inline1546__tile_pview
      ;
      const int64_t v269 = 4096;
      // pto: %y_flat_inline1546__tile_pview
      ;
      const int64_t v270 = 16384;
      // pto: %y_flat_inline1546__tile_pview
      ;
      pto::Shape<1, 1, 1, 1, 4096> v271 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %y_flat_inline1546__tile_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v272 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %y_flat_inline1546__tile_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v273 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v268 + (v269 + v96 * v270), v271, v272);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      TSTORE(v273, v214);
      // pto: %298
      ;
      __gm__ bfloat16_t* v274 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %298
      ;
      const int64_t v275 = 8192;
      // pto: %298
      ;
      const int64_t v276 = 16384;
      // pto: %298
      ;
      pto::Shape<1, 1, 1, 1, 4096> v277 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %298
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v278 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %298
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v279 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v274 + (v275 + v96 * v276), v277, v278);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      TSTORE(v279, v236);
      // pto: %301
      ;
      __gm__ bfloat16_t* v280 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %301
      ;
      const int64_t v281 = 12288;
      // pto: %301
      ;
      const int64_t v282 = 16384;
      // pto: %301
      ;
      pto::Shape<1, 1, 1, 1, 4096> v283 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %301
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v284 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %301
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v285 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v280 + (v281 + v96 * v282), v283, v284);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      TSTORE(v285, v258);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    // pto: %302
    ;
    int64_t v286 = (int64_t) ((uint64_t) v71 + (uint64_t) v21);
    // pto: %303
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    if (v286 < v7) {
      // pto: %306
      ;
      int64_t v287 = (int64_t) ((uint64_t) v286 * (uint64_t) v23);
      // pto: %304
      ;
      float v288 = (v4)[v287];
      // pto: %310
      ;
      int64_t v289 = (int64_t) ((uint64_t) v286 * (uint64_t) v24);
      // pto: %308
      ;
      float v290 = (v5)[v289];
      // pto: %315, %312
      ;
      float v291 = (v5)[(int64_t) ((uint64_t) v289 + (uint64_t) v23)];
      // pto: %319, %316
      ;
      float v292 = (v5)[(int64_t) ((uint64_t) v289 + (uint64_t) v27)];
      // pto: %323, %320
      ;
      float v293 = (v5)[(int64_t) ((uint64_t) v289 + (uint64_t) v28)];
      // pto: %327, %324
      ;
      float v294 = (v4)[(int64_t) ((uint64_t) v287 + (uint64_t) v21)];
      // pto: %331, %328
      ;
      float v295 = (v5)[(int64_t) ((uint64_t) v289 + (uint64_t) v21)];
      // pto: %335, %332
      ;
      float v296 = (v5)[(int64_t) ((uint64_t) v289 + (uint64_t) v29)];
      // pto: %339, %336
      ;
      float v297 = (v5)[(int64_t) ((uint64_t) v289 + (uint64_t) v30)];
      // pto: %343, %340
      ;
      float v298 = (v5)[(int64_t) ((uint64_t) v289 + (uint64_t) v31)];
      // pto: %347, %344
      ;
      float v299 = (v4)[(int64_t) ((uint64_t) v287 + (uint64_t) v25)];
      // pto: %351, %348
      ;
      float v300 = (v5)[(int64_t) ((uint64_t) v289 + (uint64_t) v25)];
      // pto: %355, %352
      ;
      float v301 = (v5)[(int64_t) ((uint64_t) v289 + (uint64_t) v32)];
      // pto: %359, %356
      ;
      float v302 = (v5)[(int64_t) ((uint64_t) v289 + (uint64_t) v33)];
      // pto: %363, %360
      ;
      float v303 = (v5)[(int64_t) ((uint64_t) v289 + (uint64_t) v34)];
      // pto: %367, %364
      ;
      float v304 = (v4)[(int64_t) ((uint64_t) v287 + (uint64_t) v35)];
      // pto: %371, %368
      ;
      float v305 = (v5)[(int64_t) ((uint64_t) v289 + (uint64_t) v35)];
      // pto: %375, %372
      ;
      float v306 = (v5)[(int64_t) ((uint64_t) v289 + (uint64_t) v36)];
      // pto: %379, %376
      ;
      float v307 = (v5)[(int64_t) ((uint64_t) v289 + (uint64_t) v37)];
      // pto: %383, %380
      ;
      float v308 = (v5)[(int64_t) ((uint64_t) v289 + (uint64_t) v38)];
      // pto: %37
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %37
      ;
      uint64_t v310 = (uint64_t) v11;
      TASSIGN(v309, v310);
      // pto: %385
      ;
      int64_t v311 = v286 < v26 ? v26 : v286;
      // pto: %386
      ;
      __gm__ bfloat16_t* v312 = PTOAS__GLOBAL_TENSOR_DATA(v59);
      // pto: %386
      ;
      const int64_t v313 = 0;
      // pto: %386
      ;
      const int64_t v314 = 4096;
      // pto: %386
      ;
      pto::Shape<1, 1, 1, 1, 4096> v315 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %386
      ;
      pto::Stride<4096, 4096, 4096, 4096, 1> v316 = pto::Stride<4096, 4096, 4096, 4096, 1>();
      // pto: %386
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v317 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v312 + (v313 + v311 * v314), v315, v316);
      TLOAD(v309, v317);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      // pto: %387, %388
      ;
      int64_t v318 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v7 - (uint64_t) v71) + (uint64_t) v41);
      // pto: %389
      ;
      int64_t v319 = v318 < v26 ? v26 : v318;
      // pto: %390
      ;
      int64_t v320 = v319 < v21 ? v319 : v21;
      // pto: %38
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %38
      ;
      uint64_t v322 = (uint64_t) v12;
      TASSIGN(v321, v322);
      // pto: %397
      ;
      const int64_t v323 = 0;
      // pto: %397
      ;
      __gm__ bfloat16_t* v324 = PTOAS__GLOBAL_TENSOR_DATA(v68);
      // pto: %397
      ;
      const int64_t v325 = 1;
      // pto: %397
      ;
      const int64_t v326 = 1;
      // pto: %397
      ;
      const int64_t v327 = 1;
      // pto: %397
      ;
      int64_t v328 = v320 * v20;
      // pto: %397
      ;
      int64_t v329 = v327 * v328;
      // pto: %397
      ;
      pto::Shape<1, 1, 1, -1, 4096> v330 = pto::Shape<1, 1, 1, -1, 4096>(v325, v326, v327, v320, v22);
      // pto: %397
      ;
      pto::Stride<-1, -1, -1, -1, -1> v331 = pto::Stride<-1, -1, -1, -1, -1>(v326 * v329, v329, v328, v20, v21);
      // pto: %397
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v332 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v324 + (v323 + v311 * v20 + v26 * v21), v330, v331);
      TLOAD(v321, v332);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      // pto: %39
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v333 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %39
      ;
      uint64_t v334 = (uint64_t) v13;
      TASSIGN(v333, v334);
      // pto: %408
      ;
      const int64_t v335 = 0;
      // pto: %408
      ;
      __gm__ bfloat16_t* v336 = PTOAS__GLOBAL_TENSOR_DATA(v68);
      // pto: %408
      ;
      const int64_t v337 = 1;
      // pto: %408
      ;
      const int64_t v338 = 1;
      // pto: %408
      ;
      const int64_t v339 = 1;
      // pto: %408
      ;
      int64_t v340 = v320 * v20;
      // pto: %408
      ;
      int64_t v341 = v339 * v340;
      // pto: %408
      ;
      pto::Shape<1, 1, 1, -1, 4096> v342 = pto::Shape<1, 1, 1, -1, 4096>(v337, v338, v339, v320, v22);
      // pto: %408
      ;
      pto::Stride<-1, -1, -1, -1, -1> v343 = pto::Stride<-1, -1, -1, -1, -1>(v338 * v341, v341, v340, v20, v21);
      // pto: %408
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v344 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v336 + (v335 + v311 * v20 + v22 * v21), v342, v343);
      TLOAD(v333, v344);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      // pto: %40
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v345 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %40
      ;
      uint64_t v346 = (uint64_t) v14;
      TASSIGN(v345, v346);
      // pto: %419
      ;
      const int64_t v347 = 0;
      // pto: %419
      ;
      __gm__ bfloat16_t* v348 = PTOAS__GLOBAL_TENSOR_DATA(v68);
      // pto: %419
      ;
      const int64_t v349 = 1;
      // pto: %419
      ;
      const int64_t v350 = 1;
      // pto: %419
      ;
      const int64_t v351 = 1;
      // pto: %419
      ;
      int64_t v352 = v320 * v20;
      // pto: %419
      ;
      int64_t v353 = v351 * v352;
      // pto: %419
      ;
      pto::Shape<1, 1, 1, -1, 4096> v354 = pto::Shape<1, 1, 1, -1, 4096>(v349, v350, v351, v320, v22);
      // pto: %419
      ;
      pto::Stride<-1, -1, -1, -1, -1> v355 = pto::Stride<-1, -1, -1, -1, -1>(v350 * v353, v353, v352, v20, v21);
      // pto: %419
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v356 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v348 + (v347 + v311 * v20 + v39 * v21), v354, v355);
      TLOAD(v345, v356);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %41
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v357 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %41
      ;
      uint64_t v358 = (uint64_t) v15;
      TASSIGN(v357, v358);
      // pto: %430
      ;
      const int64_t v359 = 0;
      // pto: %430
      ;
      __gm__ bfloat16_t* v360 = PTOAS__GLOBAL_TENSOR_DATA(v68);
      // pto: %430
      ;
      const int64_t v361 = 1;
      // pto: %430
      ;
      const int64_t v362 = 1;
      // pto: %430
      ;
      const int64_t v363 = 1;
      // pto: %430
      ;
      int64_t v364 = v320 * v20;
      // pto: %430
      ;
      int64_t v365 = v363 * v364;
      // pto: %430
      ;
      pto::Shape<1, 1, 1, -1, 4096> v366 = pto::Shape<1, 1, 1, -1, 4096>(v361, v362, v363, v320, v22);
      // pto: %430
      ;
      pto::Stride<-1, -1, -1, -1, -1> v367 = pto::Stride<-1, -1, -1, -1, -1>(v362 * v365, v365, v364, v20, v21);
      // pto: %430
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v368 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v360 + (v359 + v311 * v20 + v40 * v21), v366, v367);
      TLOAD(v357, v368);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %42
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v369 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %42
      ;
      uint64_t v370 = (uint64_t) v16;
      TASSIGN(v369, v370);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      RoundMode v371 = RoundMode::CAST_ROUND;
      SaturationMode v372 = SaturationMode::ON;
      TCVT(v369, v309, v371, v372);
      // pto: %43
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v373 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %43
      ;
      uint64_t v374 = (uint64_t) v11;
      TASSIGN(v373, v374);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      RoundMode v375 = RoundMode::CAST_ROUND;
      SaturationMode v376 = SaturationMode::ON;
      TCVT(v373, v321, v375, v376);
      // pto: %44
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v377 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %44
      ;
      uint64_t v378 = (uint64_t) v12;
      TASSIGN(v377, v378);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      RoundMode v379 = RoundMode::CAST_ROUND;
      SaturationMode v380 = SaturationMode::ON;
      TCVT(v377, v333, v379, v380);
      // pto: %45
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v381 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %45
      ;
      uint64_t v382 = (uint64_t) v13;
      TASSIGN(v381, v382);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      RoundMode v383 = RoundMode::CAST_ROUND;
      SaturationMode v384 = SaturationMode::ON;
      TCVT(v381, v345, v383, v384);
      // pto: %46
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v385 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %46
      ;
      uint64_t v386 = (uint64_t) v14;
      TASSIGN(v385, v386);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      RoundMode v387 = RoundMode::CAST_ROUND;
      SaturationMode v388 = SaturationMode::ON;
      TCVT(v385, v357, v387, v388);
      // pto: %47
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v389 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %47
      ;
      uint64_t v390 = (uint64_t) v15;
      TASSIGN(v389, v390);
      pipe_barrier(PIPE_V);
      TMULS(v389, v369, v288);
      // pto: %48
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v391 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %48
      ;
      uint64_t v392 = (uint64_t) v17;
      TASSIGN(v391, v392);
      TMULS(v391, v373, v290);
      // pto: %49
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v393 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %49
      ;
      uint64_t v394 = (uint64_t) v15;
      TASSIGN(v393, v394);
      pipe_barrier(PIPE_V);
      TADD(v393, v389, v391);
      // pto: %50
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v395 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %50
      ;
      uint64_t v396 = (uint64_t) v17;
      TASSIGN(v395, v396);
      pipe_barrier(PIPE_V);
      TMULS(v395, v377, v291);
      // pto: %51
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v397 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %51
      ;
      uint64_t v398 = (uint64_t) v15;
      TASSIGN(v397, v398);
      pipe_barrier(PIPE_V);
      TADD(v397, v393, v395);
      // pto: %52
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v399 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %52
      ;
      uint64_t v400 = (uint64_t) v17;
      TASSIGN(v399, v400);
      pipe_barrier(PIPE_V);
      TMULS(v399, v381, v292);
      // pto: %53
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v401 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %53
      ;
      uint64_t v402 = (uint64_t) v15;
      TASSIGN(v401, v402);
      pipe_barrier(PIPE_V);
      TADD(v401, v397, v399);
      // pto: %54
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v403 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %54
      ;
      uint64_t v404 = (uint64_t) v17;
      TASSIGN(v403, v404);
      pipe_barrier(PIPE_V);
      TMULS(v403, v385, v293);
      // pto: %55
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v405 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %55
      ;
      uint64_t v406 = (uint64_t) v15;
      TASSIGN(v405, v406);
      pipe_barrier(PIPE_V);
      TADD(v405, v401, v403);
      // pto: %56
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v407 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %56
      ;
      uint64_t v408 = (uint64_t) v18;
      TASSIGN(v407, v408);
      pipe_barrier(PIPE_V);
      RoundMode v409 = RoundMode::CAST_RINT;
      SaturationMode v410 = SaturationMode::ON;
      TCVT(v407, v405, v409, v410);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
      v407.SetValidShape(v21, v22);
      // pto: %58
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v411 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %58
      ;
      uint64_t v412 = (uint64_t) v15;
      TASSIGN(v411, v412);
      pipe_barrier(PIPE_V);
      TMULS(v411, v369, v294);
      // pto: %59
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v413 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %59
      ;
      uint64_t v414 = (uint64_t) v17;
      TASSIGN(v413, v414);
      TMULS(v413, v373, v295);
      // pto: %60
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v415 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %60
      ;
      uint64_t v416 = (uint64_t) v15;
      TASSIGN(v415, v416);
      pipe_barrier(PIPE_V);
      TADD(v415, v411, v413);
      // pto: %61
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v417 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %61
      ;
      uint64_t v418 = (uint64_t) v17;
      TASSIGN(v417, v418);
      pipe_barrier(PIPE_V);
      TMULS(v417, v377, v296);
      // pto: %62
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v419 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %62
      ;
      uint64_t v420 = (uint64_t) v15;
      TASSIGN(v419, v420);
      pipe_barrier(PIPE_V);
      TADD(v419, v415, v417);
      // pto: %63
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v421 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %63
      ;
      uint64_t v422 = (uint64_t) v17;
      TASSIGN(v421, v422);
      pipe_barrier(PIPE_V);
      TMULS(v421, v381, v297);
      // pto: %64
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v423 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %64
      ;
      uint64_t v424 = (uint64_t) v15;
      TASSIGN(v423, v424);
      pipe_barrier(PIPE_V);
      TADD(v423, v419, v421);
      // pto: %65
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v425 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %65
      ;
      uint64_t v426 = (uint64_t) v17;
      TASSIGN(v425, v426);
      pipe_barrier(PIPE_V);
      TMULS(v425, v385, v298);
      // pto: %66
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v427 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %66
      ;
      uint64_t v428 = (uint64_t) v15;
      TASSIGN(v427, v428);
      pipe_barrier(PIPE_V);
      TADD(v427, v423, v425);
      // pto: %67
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v429 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %67
      ;
      uint64_t v430 = (uint64_t) v19;
      TASSIGN(v429, v430);
      pipe_barrier(PIPE_V);
      RoundMode v431 = RoundMode::CAST_RINT;
      SaturationMode v432 = SaturationMode::ON;
      TCVT(v429, v427, v431, v432);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
      v429.SetValidShape(v21, v22);
      // pto: %69
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v433 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %69
      ;
      uint64_t v434 = (uint64_t) v15;
      TASSIGN(v433, v434);
      pipe_barrier(PIPE_V);
      TMULS(v433, v369, v299);
      // pto: %70
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v435 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %70
      ;
      uint64_t v436 = (uint64_t) v17;
      TASSIGN(v435, v436);
      TMULS(v435, v373, v300);
      // pto: %71
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v437 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %71
      ;
      uint64_t v438 = (uint64_t) v15;
      TASSIGN(v437, v438);
      pipe_barrier(PIPE_V);
      TADD(v437, v433, v435);
      // pto: %72
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v439 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %72
      ;
      uint64_t v440 = (uint64_t) v17;
      TASSIGN(v439, v440);
      pipe_barrier(PIPE_V);
      TMULS(v439, v377, v301);
      // pto: %73
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v441 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %73
      ;
      uint64_t v442 = (uint64_t) v15;
      TASSIGN(v441, v442);
      pipe_barrier(PIPE_V);
      TADD(v441, v437, v439);
      // pto: %74
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v443 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %74
      ;
      uint64_t v444 = (uint64_t) v17;
      TASSIGN(v443, v444);
      pipe_barrier(PIPE_V);
      TMULS(v443, v381, v302);
      // pto: %75
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v445 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %75
      ;
      uint64_t v446 = (uint64_t) v15;
      TASSIGN(v445, v446);
      pipe_barrier(PIPE_V);
      TADD(v445, v441, v443);
      // pto: %76
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v447 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %76
      ;
      uint64_t v448 = (uint64_t) v17;
      TASSIGN(v447, v448);
      pipe_barrier(PIPE_V);
      TMULS(v447, v385, v303);
      // pto: %77
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v449 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %77
      ;
      uint64_t v450 = (uint64_t) v15;
      TASSIGN(v449, v450);
      pipe_barrier(PIPE_V);
      TADD(v449, v445, v447);
      // pto: %78
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v451 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %78
      ;
      uint64_t v452 = (uint64_t) v15;
      TASSIGN(v451, v452);
      pipe_barrier(PIPE_V);
      RoundMode v453 = RoundMode::CAST_RINT;
      SaturationMode v454 = SaturationMode::ON;
      TCVT(v451, v449, v453, v454);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
      v451.SetValidShape(v21, v22);
      // pto: %80
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v455 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %80
      ;
      uint64_t v456 = (uint64_t) v16;
      TASSIGN(v455, v456);
      TMULS(v455, v369, v304);
      // pto: %81
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v457 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %81
      ;
      uint64_t v458 = (uint64_t) v11;
      TASSIGN(v457, v458);
      TMULS(v457, v373, v305);
      // pto: %82
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v459 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %82
      ;
      uint64_t v460 = (uint64_t) v16;
      TASSIGN(v459, v460);
      pipe_barrier(PIPE_V);
      TADD(v459, v455, v457);
      // pto: %83
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v461 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %83
      ;
      uint64_t v462 = (uint64_t) v11;
      TASSIGN(v461, v462);
      pipe_barrier(PIPE_V);
      TMULS(v461, v377, v306);
      // pto: %84
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v463 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %84
      ;
      uint64_t v464 = (uint64_t) v16;
      TASSIGN(v463, v464);
      pipe_barrier(PIPE_V);
      TADD(v463, v459, v461);
      // pto: %85
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v465 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %85
      ;
      uint64_t v466 = (uint64_t) v11;
      TASSIGN(v465, v466);
      pipe_barrier(PIPE_V);
      TMULS(v465, v381, v307);
      // pto: %86
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v467 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %86
      ;
      uint64_t v468 = (uint64_t) v16;
      TASSIGN(v467, v468);
      pipe_barrier(PIPE_V);
      TADD(v467, v463, v465);
      // pto: %87
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v469 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v320, v22);
      // pto: %87
      ;
      uint64_t v470 = (uint64_t) v11;
      TASSIGN(v469, v470);
      pipe_barrier(PIPE_V);
      TMULS(v469, v385, v308);
      // pto: %88
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v471 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %88
      ;
      uint64_t v472 = (uint64_t) v16;
      TASSIGN(v471, v472);
      pipe_barrier(PIPE_V);
      TADD(v471, v467, v469);
      // pto: %89
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v473 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %89
      ;
      uint64_t v474 = (uint64_t) v16;
      TASSIGN(v473, v474);
      pipe_barrier(PIPE_V);
      RoundMode v475 = RoundMode::CAST_RINT;
      SaturationMode v476 = SaturationMode::ON;
      TCVT(v473, v471, v475, v476);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
      v473.SetValidShape(v21, v22);
      // pto: %y_flat_inline1546__phi_v7_pview
      ;
      __gm__ bfloat16_t* v477 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %y_flat_inline1546__phi_v7_pview
      ;
      const int64_t v478 = 0;
      // pto: %y_flat_inline1546__phi_v7_pview
      ;
      const int64_t v479 = 16384;
      // pto: %y_flat_inline1546__phi_v7_pview
      ;
      pto::Shape<1, 1, 1, 1, 4096> v480 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %y_flat_inline1546__phi_v7_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v481 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %y_flat_inline1546__phi_v7_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v482 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v477 + (v478 + v311 * v479), v480, v481);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
      TSTORE(v482, v407);
      // pto: %517
      ;
      __gm__ bfloat16_t* v483 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %517
      ;
      const int64_t v484 = 4096;
      // pto: %517
      ;
      const int64_t v485 = 16384;
      // pto: %517
      ;
      pto::Shape<1, 1, 1, 1, 4096> v486 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %517
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v487 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %517
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v488 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v483 + (v484 + v311 * v485), v486, v487);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
      TSTORE(v488, v429);
      // pto: %521
      ;
      __gm__ bfloat16_t* v489 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %521
      ;
      const int64_t v490 = 8192;
      // pto: %521
      ;
      const int64_t v491 = 16384;
      // pto: %521
      ;
      pto::Shape<1, 1, 1, 1, 4096> v492 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %521
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v493 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %521
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v494 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v489 + (v490 + v311 * v491), v492, v493);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
      TSTORE(v494, v451);
      // pto: %525
      ;
      __gm__ bfloat16_t* v495 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %525
      ;
      const int64_t v496 = 12288;
      // pto: %525
      ;
      const int64_t v497 = 16384;
      // pto: %525
      ;
      pto::Shape<1, 1, 1, 1, 4096> v498 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %525
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v499 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %525
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v500 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v495 + (v496 + v311 * v497), v498, v499);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
      TSTORE(v500, v473);
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  // pto: %526, %527, %528
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  if ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v69 - (uint64_t) v70) + (uint64_t) v23) == v21) {
    // pto: %529
    ;
    if (v70 < v7) {
      // pto: %91
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v501 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %91
      ;
      uint64_t v502 = (uint64_t) v11;
      TASSIGN(v501, v502);
      // pto: %530
      ;
      int64_t v503 = v70 < v26 ? v26 : v70;
      // pto: %531
      ;
      __gm__ bfloat16_t* v504 = PTOAS__GLOBAL_TENSOR_DATA(v59);
      // pto: %531
      ;
      const int64_t v505 = 0;
      // pto: %531
      ;
      const int64_t v506 = 4096;
      // pto: %531
      ;
      pto::Shape<1, 1, 1, 1, 4096> v507 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %531
      ;
      pto::Stride<4096, 4096, 4096, 4096, 1> v508 = pto::Stride<4096, 4096, 4096, 4096, 1>();
      // pto: %531
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v509 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v504 + (v505 + v503 * v506), v507, v508);
      TLOAD(v501, v509);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %92
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v510 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %92
      ;
      uint64_t v511 = (uint64_t) v16;
      TASSIGN(v510, v511);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      RoundMode v512 = RoundMode::CAST_ROUND;
      SaturationMode v513 = SaturationMode::ON;
      TCVT(v510, v501, v512, v513);
      // pto: %532
      ;
      int64_t v514 = (int64_t) ((uint64_t) v7 - (uint64_t) v70);
      // pto: %533
      ;
      int64_t v515 = v514 < v26 ? v26 : v514;
      // pto: %534
      ;
      int64_t v516 = v515 < v21 ? v515 : v21;
      // pto: %93
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v517 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %93
      ;
      uint64_t v518 = (uint64_t) v12;
      TASSIGN(v517, v518);
      // pto: %539
      ;
      const int64_t v519 = 0;
      // pto: %539
      ;
      __gm__ bfloat16_t* v520 = PTOAS__GLOBAL_TENSOR_DATA(v68);
      // pto: %539
      ;
      const int64_t v521 = 1;
      // pto: %539
      ;
      const int64_t v522 = 1;
      // pto: %539
      ;
      const int64_t v523 = 1;
      // pto: %539
      ;
      int64_t v524 = v516 * v20;
      // pto: %539
      ;
      int64_t v525 = v523 * v524;
      // pto: %539
      ;
      pto::Shape<1, 1, 1, -1, 4096> v526 = pto::Shape<1, 1, 1, -1, 4096>(v521, v522, v523, v516, v22);
      // pto: %539
      ;
      pto::Stride<-1, -1, -1, -1, -1> v527 = pto::Stride<-1, -1, -1, -1, -1>(v522 * v525, v525, v524, v20, v21);
      // pto: %539
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v528 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v520 + (v519 + v503 * v20 + v26 * v21), v526, v527);
      TLOAD(v517, v528);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %94
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v529 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %94
      ;
      uint64_t v530 = (uint64_t) v11;
      TASSIGN(v529, v530);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      RoundMode v531 = RoundMode::CAST_ROUND;
      SaturationMode v532 = SaturationMode::ON;
      TCVT(v529, v517, v531, v532);
      // pto: %95
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v533 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %95
      ;
      uint64_t v534 = (uint64_t) v13;
      TASSIGN(v533, v534);
      // pto: %550
      ;
      const int64_t v535 = 0;
      // pto: %550
      ;
      __gm__ bfloat16_t* v536 = PTOAS__GLOBAL_TENSOR_DATA(v68);
      // pto: %550
      ;
      const int64_t v537 = 1;
      // pto: %550
      ;
      const int64_t v538 = 1;
      // pto: %550
      ;
      const int64_t v539 = 1;
      // pto: %550
      ;
      int64_t v540 = v516 * v20;
      // pto: %550
      ;
      int64_t v541 = v539 * v540;
      // pto: %550
      ;
      pto::Shape<1, 1, 1, -1, 4096> v542 = pto::Shape<1, 1, 1, -1, 4096>(v537, v538, v539, v516, v22);
      // pto: %550
      ;
      pto::Stride<-1, -1, -1, -1, -1> v543 = pto::Stride<-1, -1, -1, -1, -1>(v538 * v541, v541, v540, v20, v21);
      // pto: %550
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v544 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v536 + (v535 + v503 * v20 + v22 * v21), v542, v543);
      TLOAD(v533, v544);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %96
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v545 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %96
      ;
      uint64_t v546 = (uint64_t) v12;
      TASSIGN(v545, v546);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      RoundMode v547 = RoundMode::CAST_ROUND;
      SaturationMode v548 = SaturationMode::ON;
      TCVT(v545, v533, v547, v548);
      // pto: %97
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v549 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %97
      ;
      uint64_t v550 = (uint64_t) v14;
      TASSIGN(v549, v550);
      // pto: %561
      ;
      const int64_t v551 = 0;
      // pto: %561
      ;
      __gm__ bfloat16_t* v552 = PTOAS__GLOBAL_TENSOR_DATA(v68);
      // pto: %561
      ;
      const int64_t v553 = 1;
      // pto: %561
      ;
      const int64_t v554 = 1;
      // pto: %561
      ;
      const int64_t v555 = 1;
      // pto: %561
      ;
      int64_t v556 = v516 * v20;
      // pto: %561
      ;
      int64_t v557 = v555 * v556;
      // pto: %561
      ;
      pto::Shape<1, 1, 1, -1, 4096> v558 = pto::Shape<1, 1, 1, -1, 4096>(v553, v554, v555, v516, v22);
      // pto: %561
      ;
      pto::Stride<-1, -1, -1, -1, -1> v559 = pto::Stride<-1, -1, -1, -1, -1>(v554 * v557, v557, v556, v20, v21);
      // pto: %561
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v560 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v552 + (v551 + v503 * v20 + v39 * v21), v558, v559);
      TLOAD(v549, v560);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %98
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v561 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %98
      ;
      uint64_t v562 = (uint64_t) v13;
      TASSIGN(v561, v562);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      RoundMode v563 = RoundMode::CAST_ROUND;
      SaturationMode v564 = SaturationMode::ON;
      TCVT(v561, v549, v563, v564);
      // pto: %99
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v565 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %99
      ;
      uint64_t v566 = (uint64_t) v15;
      TASSIGN(v565, v566);
      // pto: %572
      ;
      const int64_t v567 = 0;
      // pto: %572
      ;
      __gm__ bfloat16_t* v568 = PTOAS__GLOBAL_TENSOR_DATA(v68);
      // pto: %572
      ;
      const int64_t v569 = 1;
      // pto: %572
      ;
      const int64_t v570 = 1;
      // pto: %572
      ;
      const int64_t v571 = 1;
      // pto: %572
      ;
      int64_t v572 = v516 * v20;
      // pto: %572
      ;
      int64_t v573 = v571 * v572;
      // pto: %572
      ;
      pto::Shape<1, 1, 1, -1, 4096> v574 = pto::Shape<1, 1, 1, -1, 4096>(v569, v570, v571, v516, v22);
      // pto: %572
      ;
      pto::Stride<-1, -1, -1, -1, -1> v575 = pto::Stride<-1, -1, -1, -1, -1>(v570 * v573, v573, v572, v20, v21);
      // pto: %572
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v576 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 4096>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v568 + (v567 + v503 * v20 + v40 * v21), v574, v575);
      TLOAD(v565, v576);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %100
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v577 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %100
      ;
      uint64_t v578 = (uint64_t) v14;
      TASSIGN(v577, v578);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      RoundMode v579 = RoundMode::CAST_ROUND;
      SaturationMode v580 = SaturationMode::ON;
      TCVT(v577, v565, v579, v580);
      // pto: %577
      ;
      int64_t v581 = (int64_t) ((uint64_t) v70 * (uint64_t) v23);
      // pto: %576
      ;
      float v582 = (v4)[v581];
      // pto: %101
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v583 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %101
      ;
      uint64_t v584 = (uint64_t) v15;
      TASSIGN(v583, v584);
      pipe_barrier(PIPE_V);
      TMULS(v583, v510, v582);
      // pto: %580
      ;
      int64_t v585 = (int64_t) ((uint64_t) v70 * (uint64_t) v24);
      // pto: %579
      ;
      float v586 = (v5)[v585];
      // pto: %102
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v587 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %102
      ;
      uint64_t v588 = (uint64_t) v17;
      TASSIGN(v587, v588);
      TMULS(v587, v529, v586);
      // pto: %103
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v589 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %103
      ;
      uint64_t v590 = (uint64_t) v15;
      TASSIGN(v589, v590);
      pipe_barrier(PIPE_V);
      TADD(v589, v583, v587);
      // pto: %587, %585
      ;
      float v591 = (v5)[(int64_t) ((uint64_t) v585 + (uint64_t) v23)];
      // pto: %104
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v592 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %104
      ;
      uint64_t v593 = (uint64_t) v17;
      TASSIGN(v592, v593);
      pipe_barrier(PIPE_V);
      TMULS(v592, v545, v591);
      // pto: %105
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v594 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %105
      ;
      uint64_t v595 = (uint64_t) v15;
      TASSIGN(v594, v595);
      pipe_barrier(PIPE_V);
      TADD(v594, v589, v592);
      // pto: %593, %591
      ;
      float v596 = (v5)[(int64_t) ((uint64_t) v585 + (uint64_t) v27)];
      // pto: %106
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v597 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %106
      ;
      uint64_t v598 = (uint64_t) v17;
      TASSIGN(v597, v598);
      pipe_barrier(PIPE_V);
      TMULS(v597, v561, v596);
      // pto: %107
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v599 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %107
      ;
      uint64_t v600 = (uint64_t) v15;
      TASSIGN(v599, v600);
      pipe_barrier(PIPE_V);
      TADD(v599, v594, v597);
      // pto: %599, %597
      ;
      float v601 = (v5)[(int64_t) ((uint64_t) v585 + (uint64_t) v28)];
      // pto: %108
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v602 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %108
      ;
      uint64_t v603 = (uint64_t) v17;
      TASSIGN(v602, v603);
      pipe_barrier(PIPE_V);
      TMULS(v602, v577, v601);
      // pto: %109
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v604 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %109
      ;
      uint64_t v605 = (uint64_t) v15;
      TASSIGN(v604, v605);
      pipe_barrier(PIPE_V);
      TADD(v604, v599, v602);
      // pto: %110
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v606 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %110
      ;
      uint64_t v607 = (uint64_t) v15;
      TASSIGN(v606, v607);
      pipe_barrier(PIPE_V);
      RoundMode v608 = RoundMode::CAST_RINT;
      SaturationMode v609 = SaturationMode::ON;
      TCVT(v606, v604, v608, v609);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      v606.SetValidShape(v21, v22);
      // pto: %y_flat_inline1546__rv_v2_main_pview
      ;
      __gm__ bfloat16_t* v610 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %y_flat_inline1546__rv_v2_main_pview
      ;
      const int64_t v611 = 0;
      // pto: %y_flat_inline1546__rv_v2_main_pview
      ;
      const int64_t v612 = 16384;
      // pto: %y_flat_inline1546__rv_v2_main_pview
      ;
      pto::Shape<1, 1, 1, 1, 4096> v613 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %y_flat_inline1546__rv_v2_main_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v614 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %y_flat_inline1546__rv_v2_main_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v615 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v610 + (v611 + v503 * v612), v613, v614);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v615, v606);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
      // pto: %607, %605
      ;
      float v616 = (v4)[(int64_t) ((uint64_t) v581 + (uint64_t) v21)];
      // pto: %112
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v617 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %112
      ;
      uint64_t v618 = (uint64_t) v15;
      TASSIGN(v617, v618);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
      TMULS(v617, v510, v616);
      // pto: %610, %608
      ;
      float v619 = (v5)[(int64_t) ((uint64_t) v585 + (uint64_t) v21)];
      // pto: %113
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v620 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %113
      ;
      uint64_t v621 = (uint64_t) v17;
      TASSIGN(v620, v621);
      TMULS(v620, v529, v619);
      // pto: %114
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v622 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %114
      ;
      uint64_t v623 = (uint64_t) v15;
      TASSIGN(v622, v623);
      pipe_barrier(PIPE_V);
      TADD(v622, v617, v620);
      // pto: %616, %614
      ;
      float v624 = (v5)[(int64_t) ((uint64_t) v585 + (uint64_t) v29)];
      // pto: %115
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v625 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %115
      ;
      uint64_t v626 = (uint64_t) v17;
      TASSIGN(v625, v626);
      pipe_barrier(PIPE_V);
      TMULS(v625, v545, v624);
      // pto: %116
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v627 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %116
      ;
      uint64_t v628 = (uint64_t) v15;
      TASSIGN(v627, v628);
      pipe_barrier(PIPE_V);
      TADD(v627, v622, v625);
      // pto: %622, %620
      ;
      float v629 = (v5)[(int64_t) ((uint64_t) v585 + (uint64_t) v30)];
      // pto: %117
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v630 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %117
      ;
      uint64_t v631 = (uint64_t) v17;
      TASSIGN(v630, v631);
      pipe_barrier(PIPE_V);
      TMULS(v630, v561, v629);
      // pto: %118
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v632 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %118
      ;
      uint64_t v633 = (uint64_t) v15;
      TASSIGN(v632, v633);
      pipe_barrier(PIPE_V);
      TADD(v632, v627, v630);
      // pto: %628, %626
      ;
      float v634 = (v5)[(int64_t) ((uint64_t) v585 + (uint64_t) v31)];
      // pto: %119
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v635 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %119
      ;
      uint64_t v636 = (uint64_t) v17;
      TASSIGN(v635, v636);
      pipe_barrier(PIPE_V);
      TMULS(v635, v577, v634);
      // pto: %120
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v637 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %120
      ;
      uint64_t v638 = (uint64_t) v15;
      TASSIGN(v637, v638);
      pipe_barrier(PIPE_V);
      TADD(v637, v632, v635);
      // pto: %121
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v639 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %121
      ;
      uint64_t v640 = (uint64_t) v15;
      TASSIGN(v639, v640);
      pipe_barrier(PIPE_V);
      RoundMode v641 = RoundMode::CAST_RINT;
      SaturationMode v642 = SaturationMode::ON;
      TCVT(v639, v637, v641, v642);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      v639.SetValidShape(v21, v22);
      // pto: %634
      ;
      __gm__ bfloat16_t* v643 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %634
      ;
      const int64_t v644 = 4096;
      // pto: %634
      ;
      const int64_t v645 = 16384;
      // pto: %634
      ;
      pto::Shape<1, 1, 1, 1, 4096> v646 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %634
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v647 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %634
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v648 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v643 + (v644 + v503 * v645), v646, v647);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v648, v639);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      // pto: %637, %635
      ;
      float v649 = (v4)[(int64_t) ((uint64_t) v581 + (uint64_t) v25)];
      // pto: %123
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v650 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %123
      ;
      uint64_t v651 = (uint64_t) v15;
      TASSIGN(v650, v651);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      TMULS(v650, v510, v649);
      // pto: %640, %638
      ;
      float v652 = (v5)[(int64_t) ((uint64_t) v585 + (uint64_t) v25)];
      // pto: %124
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v653 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %124
      ;
      uint64_t v654 = (uint64_t) v17;
      TASSIGN(v653, v654);
      TMULS(v653, v529, v652);
      // pto: %125
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v655 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %125
      ;
      uint64_t v656 = (uint64_t) v15;
      TASSIGN(v655, v656);
      pipe_barrier(PIPE_V);
      TADD(v655, v650, v653);
      // pto: %646, %644
      ;
      float v657 = (v5)[(int64_t) ((uint64_t) v585 + (uint64_t) v32)];
      // pto: %126
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v658 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %126
      ;
      uint64_t v659 = (uint64_t) v17;
      TASSIGN(v658, v659);
      pipe_barrier(PIPE_V);
      TMULS(v658, v545, v657);
      // pto: %127
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v660 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %127
      ;
      uint64_t v661 = (uint64_t) v15;
      TASSIGN(v660, v661);
      pipe_barrier(PIPE_V);
      TADD(v660, v655, v658);
      // pto: %652, %650
      ;
      float v662 = (v5)[(int64_t) ((uint64_t) v585 + (uint64_t) v33)];
      // pto: %128
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v663 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %128
      ;
      uint64_t v664 = (uint64_t) v17;
      TASSIGN(v663, v664);
      pipe_barrier(PIPE_V);
      TMULS(v663, v561, v662);
      // pto: %129
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v665 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %129
      ;
      uint64_t v666 = (uint64_t) v15;
      TASSIGN(v665, v666);
      pipe_barrier(PIPE_V);
      TADD(v665, v660, v663);
      // pto: %658, %656
      ;
      float v667 = (v5)[(int64_t) ((uint64_t) v585 + (uint64_t) v34)];
      // pto: %130
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v668 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %130
      ;
      uint64_t v669 = (uint64_t) v17;
      TASSIGN(v668, v669);
      pipe_barrier(PIPE_V);
      TMULS(v668, v577, v667);
      // pto: %131
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v670 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %131
      ;
      uint64_t v671 = (uint64_t) v15;
      TASSIGN(v670, v671);
      pipe_barrier(PIPE_V);
      TADD(v670, v665, v668);
      // pto: %132
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v672 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %132
      ;
      uint64_t v673 = (uint64_t) v15;
      TASSIGN(v672, v673);
      pipe_barrier(PIPE_V);
      RoundMode v674 = RoundMode::CAST_RINT;
      SaturationMode v675 = SaturationMode::ON;
      TCVT(v672, v670, v674, v675);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      v672.SetValidShape(v21, v22);
      // pto: %664
      ;
      __gm__ bfloat16_t* v676 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %664
      ;
      const int64_t v677 = 8192;
      // pto: %664
      ;
      const int64_t v678 = 16384;
      // pto: %664
      ;
      pto::Shape<1, 1, 1, 1, 4096> v679 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %664
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v680 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %664
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v681 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v676 + (v677 + v503 * v678), v679, v680);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v681, v672);
      // pto: %667, %665
      ;
      float v682 = (v4)[(int64_t) ((uint64_t) v581 + (uint64_t) v35)];
      // pto: %134
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v683 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %134
      ;
      uint64_t v684 = (uint64_t) v16;
      TASSIGN(v683, v684);
      TMULS(v683, v510, v682);
      // pto: %670, %668
      ;
      float v685 = (v5)[(int64_t) ((uint64_t) v585 + (uint64_t) v35)];
      // pto: %135
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v686 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %135
      ;
      uint64_t v687 = (uint64_t) v11;
      TASSIGN(v686, v687);
      TMULS(v686, v529, v685);
      // pto: %136
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v688 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %136
      ;
      uint64_t v689 = (uint64_t) v16;
      TASSIGN(v688, v689);
      pipe_barrier(PIPE_V);
      TADD(v688, v683, v686);
      // pto: %676, %674
      ;
      float v690 = (v5)[(int64_t) ((uint64_t) v585 + (uint64_t) v36)];
      // pto: %137
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v691 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %137
      ;
      uint64_t v692 = (uint64_t) v11;
      TASSIGN(v691, v692);
      pipe_barrier(PIPE_V);
      TMULS(v691, v545, v690);
      // pto: %138
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v693 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %138
      ;
      uint64_t v694 = (uint64_t) v16;
      TASSIGN(v693, v694);
      pipe_barrier(PIPE_V);
      TADD(v693, v688, v691);
      // pto: %682, %680
      ;
      float v695 = (v5)[(int64_t) ((uint64_t) v585 + (uint64_t) v37)];
      // pto: %139
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v696 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %139
      ;
      uint64_t v697 = (uint64_t) v11;
      TASSIGN(v696, v697);
      pipe_barrier(PIPE_V);
      TMULS(v696, v561, v695);
      // pto: %140
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v698 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %140
      ;
      uint64_t v699 = (uint64_t) v16;
      TASSIGN(v698, v699);
      pipe_barrier(PIPE_V);
      TADD(v698, v693, v696);
      // pto: %688, %686
      ;
      float v700 = (v5)[(int64_t) ((uint64_t) v585 + (uint64_t) v38)];
      // pto: %141
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v701 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v516, v22);
      // pto: %141
      ;
      uint64_t v702 = (uint64_t) v11;
      TASSIGN(v701, v702);
      pipe_barrier(PIPE_V);
      TMULS(v701, v577, v700);
      // pto: %142
      ;
      Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v703 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %142
      ;
      uint64_t v704 = (uint64_t) v16;
      TASSIGN(v703, v704);
      pipe_barrier(PIPE_V);
      TADD(v703, v698, v701);
      // pto: %143
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v705 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %143
      ;
      uint64_t v706 = (uint64_t) v16;
      TASSIGN(v705, v706);
      pipe_barrier(PIPE_V);
      RoundMode v707 = RoundMode::CAST_RINT;
      SaturationMode v708 = SaturationMode::ON;
      TCVT(v705, v703, v707, v708);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      v705.SetValidShape(v21, v22);
      // pto: %694
      ;
      __gm__ bfloat16_t* v709 = PTOAS__GLOBAL_TENSOR_DATA(v50);
      // pto: %694
      ;
      const int64_t v710 = 12288;
      // pto: %694
      ;
      const int64_t v711 = 16384;
      // pto: %694
      ;
      pto::Shape<1, 1, 1, 1, 4096> v712 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %694
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v713 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %694
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v714 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v709 + (v710 + v503 * v711), v712, v713);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v714, v705);
    };
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}