#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void hcpre_bf16_half_exact8(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ float* v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v8 = 0;
  // pto: %c4096_i64
  const int64_t v9 = 4096;
  // pto: %c32768_index
  const int64_t v10 = 32768;
  // pto: %c1_index
  const int64_t v11 = 1;
  // pto: %c32_index
  const int64_t v12 = 32;
  // pto: %c16_index
  const int64_t v13 = 16;
  // pto: %c16384_index
  const int64_t v14 = 16384;
  // pto: %c768_index
  const int64_t v15 = 768;
  // pto: %c64_index
  const int64_t v16 = 64;
  // pto: %c0_index
  const int64_t v17 = 0;
  // pto: %c1536_index
  const int64_t v18 = 1536;
  // pto: %c128_index
  const int64_t v19 = 128;
  // pto: %c22_index
  const int64_t v20 = 22;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  const int64_t v21 = 1;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  const int64_t v22 = 1;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  const int64_t v23 = 1;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  int64_t v24 = (int64_t) v5;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  int64_t v25 = v24 * v10;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  int64_t v26 = v23 * v25;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v27 = pto::Shape<1, 1, 1, -1, -1>(v21, v22, v23, v24, v10);
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v28 = pto::Stride<-1, -1, -1, -1, -1>(v22 * v26, v26, v25, v10, v11);
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v29 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v27, v28);
  // pto: %panel64_packed_weight_inline8309__ssa_v0_view
  const int64_t v30 = 1;
  // pto: %panel64_packed_weight_inline8309__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %panel64_packed_weight_inline8309__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %panel64_packed_weight_inline8309__ssa_v0_view
  int64_t v33 = v10 * v12;
  // pto: %panel64_packed_weight_inline8309__ssa_v0_view
  int64_t v34 = v32 * v33;
  // pto: %panel64_packed_weight_inline8309__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v35 = pto::Shape<1, 1, 1, -1, -1>(v30, v31, v32, v10, v12);
  // pto: %panel64_packed_weight_inline8309__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v36 = pto::Stride<-1, -1, -1, -1, -1>(v31 * v34, v34, v33, v12, v11);
  // pto: %panel64_packed_weight_inline8309__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v37 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v35, v36);
  // pto: %20
  int64_t v38 = (int64_t) ((uint64_t) v5 * (uint64_t) v20);
  // pto: %mixes_partials_inline8250__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %mixes_partials_inline8250__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %mixes_partials_inline8250__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %mixes_partials_inline8250__ssa_v0_view
  int64_t v42 = v38 * v12;
  // pto: %mixes_partials_inline8250__ssa_v0_view
  int64_t v43 = v41 * v42;
  // pto: %mixes_partials_inline8250__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v44 = pto::Shape<1, 1, 1, -1, -1>(v39, v40, v41, v38, v12);
  // pto: %mixes_partials_inline8250__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v45 = pto::Stride<-1, -1, -1, -1, -1>(v40 * v43, v43, v42, v12, v11);
  // pto: %mixes_partials_inline8250__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v46 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v44, v45);
  // pto: %panel64_unit_inline8183__ssa_v0
  int64_t v47 = (int64_t) v6;
  // pto: %1
  int64_t v48 = v5 / v13;
  // pto: %2
  int64_t v49 = v47 / v48;
  // pto: %4, %5
  int64_t v50 = (int64_t) ((uint64_t) (v47 % v48) * (uint64_t) v13);
  // pto: %7, %6
  int64_t v51 = (int64_t) ((uint64_t) v14 - (uint64_t) ((int64_t) (uint64_t) v49 * (uint64_t) v15));
  // pto: %8
  int64_t v52 = v51 < v15 ? v51 : v15;
  // pto: %9
  // pto: %panel64_accumulator_inline8240__tile
  Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v53 = Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v13, v12);
  // pto: %panel64_accumulator_inline8240__tile
  uint64_t v54 = (uint64_t) v8;
  TASSIGN(v53, v54);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t v55 = v17; v55 < (v52 / v16); v55 += v11) {
    // pto: %10, %12, %11
    ;
    int64_t v56 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v49 * (uint64_t) v18) + (uint64_t) ((int64_t) (uint64_t) v55 * (uint64_t) v19));
    // pto: %panel64_x16_inline8282__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v57 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v13, v19);
    // pto: %panel64_x16_inline8282__tile
    ;
    uint64_t v58 = (uint64_t) v8;
    TASSIGN(v57, v58);
    // pto: %13
    ;
    int64_t v59 = v50 < v17 ? v17 : v50;
    // pto: %14
    ;
    int64_t v60 = v56 < v17 ? v17 : v56;
    // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v61 = PTOAS__GLOBAL_TENSOR_DATA(v29);
    // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
    ;
    const int64_t v62 = 0;
    // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
    ;
    const int64_t v63 = 32768;
    // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 16, 128> v64 = pto::Shape<1, 1, 1, 16, 128>();
    // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
    ;
    pto::Stride<524288, 524288, 524288, 32768, 1> v65 = pto::Stride<524288, 524288, 524288, 32768, 1>();
    // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND> v66 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND>(v61 + (v62 + v59 * v63 + v60), v64, v65);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v57, v66);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %panel64_w16_inline8257__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v12);
    // pto: %panel64_w16_inline8257__tile
    ;
    uint64_t v68 = (uint64_t) v9;
    TASSIGN(v67, v68);
    // pto: %panel64_packed_weight_inline8309__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v69 = PTOAS__GLOBAL_TENSOR_DATA(v37);
    // pto: %panel64_packed_weight_inline8309__ssa_v0_pview
    ;
    const int64_t v70 = 0;
    // pto: %panel64_packed_weight_inline8309__ssa_v0_pview
    ;
    const int64_t v71 = 32;
    // pto: %panel64_packed_weight_inline8309__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 128, 32> v72 = pto::Shape<1, 1, 1, 128, 32>();
    // pto: %panel64_packed_weight_inline8309__ssa_v0_pview
    ;
    pto::Stride<4096, 4096, 4096, 32, 1> v73 = pto::Stride<4096, 4096, 4096, 32, 1>();
    // pto: %panel64_packed_weight_inline8309__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v74 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v69 + (v70 + v60 * v71), v72, v73);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v67, v74);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    // pto: %panel64_x16_inline8282__tile_Left
    ;
    Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v13, v19);
    // pto: %panel64_x16_inline8282__tile_Left
    ;
    uint64_t v76 = (uint64_t) v8;
    TASSIGN(v75, v76);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    TMOV(v75, v57);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    // pto: %panel64_w16_inline8257__tile_Right
    ;
    Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v77 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v12);
    // pto: %panel64_w16_inline8257__tile_Right
    ;
    uint64_t v78 = (uint64_t) v8;
    TASSIGN(v77, v78);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    TMOV(v77, v67);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    // pto: %16
    ;
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    if (v55 == v17) {
      TMATMUL(v53, v75, v77);
    } else {
      TMATMUL_ACC(v53, v53, v75, v77);
    };
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  }
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  // pto: %17, %18
  int64_t v79 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v49 * (uint64_t) v5) + (uint64_t) v50);
  // pto: %19
  int64_t v80 = v79 < v17 ? v17 : v79;
  // pto: %mixes_partials_inline8250__ssa_v0_pview
  __gm__ float* v81 = PTOAS__GLOBAL_TENSOR_DATA(v46);
  // pto: %mixes_partials_inline8250__ssa_v0_pview
  const int64_t v82 = 0;
  // pto: %mixes_partials_inline8250__ssa_v0_pview
  const int64_t v83 = 32;
  // pto: %mixes_partials_inline8250__ssa_v0_pview
  pto::Shape<1, 1, 1, 16, 32> v84 = pto::Shape<1, 1, 1, 16, 32>();
  // pto: %mixes_partials_inline8250__ssa_v0_pview
  pto::Stride<512, 512, 512, 32, 1> v85 = pto::Stride<512, 512, 512, 32, 1>();
  // pto: %mixes_partials_inline8250__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v86 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v81 + (v82 + v80 * v83), v84, v85);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE(v86, v53);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}