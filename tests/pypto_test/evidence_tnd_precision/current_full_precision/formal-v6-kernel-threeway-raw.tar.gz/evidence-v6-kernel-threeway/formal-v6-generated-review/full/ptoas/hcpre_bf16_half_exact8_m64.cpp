#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void hcpre_bf16_half_exact8_m64(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, __gm__ float* v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v8 = 0;
  // pto: %c16384_i64
  const int64_t v9 = 16384;
  // pto: %c32768_index
  const int64_t v10 = 32768;
  // pto: %c1_index
  const int64_t v11 = 1;
  // pto: %c32_index
  const int64_t v12 = 32;
  // pto: %c63_index
  const int64_t v13 = 63;
  // pto: %c64_index
  const int64_t v14 = 64;
  // pto: %c16384_index
  const int64_t v15 = 16384;
  // pto: %c768_index
  const int64_t v16 = 768;
  // pto: %c1536_index
  const int64_t v17 = 1536;
  // pto: %c128_index
  const int64_t v18 = 128;
  // pto: %c0_index
  const int64_t v19 = 0;
  // pto: %c22_index
  const int64_t v20 = 22;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  const int64_t v21 = 1;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  const int64_t v22 = 1;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  const int64_t v23 = 1;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  int64_t v24 = (int64_t) v5;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  int64_t v25 = v24 * v10;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  int64_t v26 = v23 * v25;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v27 = pto::Shape<1, 1, 1, -1, -1>(v21, v22, v23, v24, v10);
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v28 = pto::Stride<-1, -1, -1, -1, -1>(v22 * v26, v26, v25, v10, v11);
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v29 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v27, v28);
  // pto: %panel64_packed_weight_inline8309__ssa_v0_view
  const int64_t v30 = 1;
  // pto: %panel64_packed_weight_inline8309__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %panel64_packed_weight_inline8309__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %panel64_packed_weight_inline8309__ssa_v0_view
  int64_t v33 = v10 * v12;
  // pto: %panel64_packed_weight_inline8309__ssa_v0_view
  int64_t v34 = v32 * v33;
  // pto: %panel64_packed_weight_inline8309__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v35 = pto::Shape<1, 1, 1, -1, -1>(v30, v31, v32, v10, v12);
  // pto: %panel64_packed_weight_inline8309__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v36 = pto::Stride<-1, -1, -1, -1, -1>(v31 * v34, v34, v33, v12, v11);
  // pto: %panel64_packed_weight_inline8309__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v37 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v35, v36);
  // pto: %29
  int64_t v38 = (int64_t) ((uint64_t) v5 * (uint64_t) v20);
  // pto: %mixes_partials_inline8250__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %mixes_partials_inline8250__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %mixes_partials_inline8250__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %mixes_partials_inline8250__ssa_v0_view
  int64_t v42 = v38 * v12;
  // pto: %mixes_partials_inline8250__ssa_v0_view
  int64_t v43 = v41 * v42;
  // pto: %mixes_partials_inline8250__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v44 = pto::Shape<1, 1, 1, -1, -1>(v39, v40, v41, v38, v12);
  // pto: %mixes_partials_inline8250__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v45 = pto::Stride<-1, -1, -1, -1, -1>(v40 * v43, v43, v42, v12, v11);
  // pto: %mixes_partials_inline8250__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v46 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v44, v45);
  // pto: %panel64_wide_unit_inline8315__ssa_v0
  int64_t v47 = (int64_t) v6;
  // pto: %1, %2
  int64_t v48 = (int64_t) ((uint64_t) v5 + (uint64_t) v13) / v14;
  // pto: %3
  int64_t v49 = v47 / v48;
  // pto: %6, %7
  int64_t v50 = (int64_t) ((uint64_t) (v47 % v48) * (uint64_t) v14);
  // pto: %8
  int64_t v51 = (int64_t) ((uint64_t) v5 - (uint64_t) v50);
  // pto: %9
  int64_t v52 = v51 < v14 ? v51 : v14;
  // pto: %11, %10
  int64_t v53 = (int64_t) ((uint64_t) v15 - (uint64_t) ((int64_t) (uint64_t) v49 * (uint64_t) v16));
  // pto: %12
  int64_t v54 = v53 < v16 ? v53 : v16;
  // pto: %13
  // pto: %14
  int64_t v55 = (int64_t) ((uint64_t) v49 * (uint64_t) v17);
  // pto: %panel64_wide_first_x_inline8297__tile
  Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v52, v18);
  // pto: %panel64_wide_first_x_inline8297__tile
  uint64_t v57 = (uint64_t) v8;
  TASSIGN(v56, v57);
  // pto: %15
  int64_t v58 = v50 < v19 ? v19 : v50;
  // pto: %16
  int64_t v59 = v55 < v19 ? v19 : v55;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
  const int64_t v60 = 0;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
  __gm__ bfloat16_t* v61 = PTOAS__GLOBAL_TENSOR_DATA(v29);
  // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
  const int64_t v62 = 1;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
  const int64_t v63 = 1;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
  const int64_t v64 = 1;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
  int64_t v65 = v52 * v10;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
  int64_t v66 = v64 * v65;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 128> v67 = pto::Shape<1, 1, 1, -1, 128>(v62, v63, v64, v52, v18);
  // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v68 = pto::Stride<-1, -1, -1, -1, -1>(v63 * v66, v66, v65, v10, v11);
  // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v69 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v61 + (v60 + v58 * v10 + v59 * v11), v67, v68);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  TLOAD(v56, v69);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  // pto: %panel64_wide_first_w_inline8180__tile
  Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v70 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v12);
  // pto: %panel64_wide_first_w_inline8180__tile
  uint64_t v71 = (uint64_t) v9;
  TASSIGN(v70, v71);
  // pto: %panel64_packed_weight_inline8309__ssa_v0_pview
  __gm__ bfloat16_t* v72 = PTOAS__GLOBAL_TENSOR_DATA(v37);
  // pto: %panel64_packed_weight_inline8309__ssa_v0_pview
  const int64_t v73 = 0;
  // pto: %panel64_packed_weight_inline8309__ssa_v0_pview
  const int64_t v74 = 32;
  // pto: %panel64_packed_weight_inline8309__ssa_v0_pview
  pto::Shape<1, 1, 1, 128, 32> v75 = pto::Shape<1, 1, 1, 128, 32>();
  // pto: %panel64_packed_weight_inline8309__ssa_v0_pview
  pto::Stride<4096, 4096, 4096, 32, 1> v76 = pto::Stride<4096, 4096, 4096, 32, 1>();
  // pto: %panel64_packed_weight_inline8309__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v77 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v72 + (v73 + v59 * v74), v75, v76);
  TLOAD(v70, v77);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
  // pto: %panel64_wide_first_x_inline8297__tile_Left
  Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v52, v18);
  // pto: %panel64_wide_first_x_inline8297__tile_Left
  uint64_t v79 = (uint64_t) v8;
  TASSIGN(v78, v79);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  TMOV(v78, v56);
  // pto: %panel64_wide_first_w_inline8180__tile_Right
  Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v80 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v12);
  // pto: %panel64_wide_first_w_inline8180__tile_Right
  uint64_t v81 = (uint64_t) v8;
  TASSIGN(v80, v81);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
  TMOV(v80, v70);
  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  // pto: %panel64_wide_accumulator_inline8278__tile
  Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v82 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v52, v12);
  // pto: %panel64_wide_accumulator_inline8278__tile
  uint64_t v83 = (uint64_t) v8;
  TASSIGN(v82, v83);
  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
  TMATMUL(v82, v78, v80);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t v84 = v11; v84 < (v54 / v14); v84 += v11) {
    // pto: %20, %19
    ;
    int64_t v85 = (int64_t) ((uint64_t) v55 + (uint64_t) ((int64_t) (uint64_t) v84 * (uint64_t) v18));
    // pto: %panel64_wide_x_inline8241__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v86 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v52, v18);
    // pto: %panel64_wide_x_inline8241__tile
    ;
    uint64_t v87 = (uint64_t) v8;
    TASSIGN(v86, v87);
    // pto: %22
    ;
    int64_t v88 = v85 < v19 ? v19 : v85;
    // pto: %23
    ;
    const int64_t v89 = 0;
    // pto: %23
    ;
    __gm__ bfloat16_t* v90 = PTOAS__GLOBAL_TENSOR_DATA(v29);
    // pto: %23
    ;
    const int64_t v91 = 1;
    // pto: %23
    ;
    const int64_t v92 = 1;
    // pto: %23
    ;
    const int64_t v93 = 1;
    // pto: %23
    ;
    int64_t v94 = v52 * v10;
    // pto: %23
    ;
    int64_t v95 = v93 * v94;
    // pto: %23
    ;
    pto::Shape<1, 1, 1, -1, 128> v96 = pto::Shape<1, 1, 1, -1, 128>(v91, v92, v93, v52, v18);
    // pto: %23
    ;
    pto::Stride<-1, -1, -1, -1, -1> v97 = pto::Stride<-1, -1, -1, -1, -1>(v92 * v95, v95, v94, v10, v11);
    // pto: %23
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v98 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v90 + (v89 + v58 * v10 + v88 * v11), v96, v97);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v86, v98);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    // pto: %panel64_wide_w_inline8182__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v18, v12);
    // pto: %panel64_wide_w_inline8182__tile
    ;
    uint64_t v100 = (uint64_t) v9;
    TASSIGN(v99, v100);
    // pto: %25
    ;
    __gm__ bfloat16_t* v101 = PTOAS__GLOBAL_TENSOR_DATA(v37);
    // pto: %25
    ;
    const int64_t v102 = 0;
    // pto: %25
    ;
    const int64_t v103 = 32;
    // pto: %25
    ;
    pto::Shape<1, 1, 1, 128, 32> v104 = pto::Shape<1, 1, 1, 128, 32>();
    // pto: %25
    ;
    pto::Stride<4096, 4096, 4096, 32, 1> v105 = pto::Stride<4096, 4096, 4096, 32, 1>();
    // pto: %25
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v106 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v101 + (v102 + v88 * v103), v104, v105);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    TLOAD(v99, v106);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    // pto: %panel64_wide_x_inline8241__tile_Left
    ;
    Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v107 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v52, v18);
    // pto: %panel64_wide_x_inline8241__tile_Left
    ;
    uint64_t v108 = (uint64_t) v8;
    TASSIGN(v107, v108);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    TMOV(v107, v86);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    // pto: %panel64_wide_w_inline8182__tile_Right
    ;
    Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v12);
    // pto: %panel64_wide_w_inline8182__tile_Right
    ;
    uint64_t v110 = (uint64_t) v8;
    TASSIGN(v109, v110);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    TMOV(v109, v99);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
    TMATMUL_ACC(v82, v82, v107, v109);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  }
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  v82.SetValidShape(v52, v12);
  // pto: %26, %27
  int64_t v111 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v49 * (uint64_t) v5) + (uint64_t) v50);
  // pto: %28
  int64_t v112 = v111 < v19 ? v19 : v111;
  // pto: %mixes_partials_inline8250__ssa_v0_pview
  const int64_t v113 = 0;
  // pto: %mixes_partials_inline8250__ssa_v0_pview
  __gm__ float* v114 = PTOAS__GLOBAL_TENSOR_DATA(v46);
  // pto: %mixes_partials_inline8250__ssa_v0_pview
  const int64_t v115 = 1;
  // pto: %mixes_partials_inline8250__ssa_v0_pview
  const int64_t v116 = 1;
  // pto: %mixes_partials_inline8250__ssa_v0_pview
  const int64_t v117 = 1;
  // pto: %mixes_partials_inline8250__ssa_v0_pview
  int64_t v118 = v52 * v12;
  // pto: %mixes_partials_inline8250__ssa_v0_pview
  int64_t v119 = v117 * v118;
  // pto: %mixes_partials_inline8250__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 32> v120 = pto::Shape<1, 1, 1, -1, 32>(v115, v116, v117, v52, v12);
  // pto: %mixes_partials_inline8250__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v121 = pto::Stride<-1, -1, -1, -1, -1>(v116 * v119, v119, v118, v12, v11);
  // pto: %mixes_partials_inline8250__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v122 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v114 + (v113 + v112 * v12 + v19 * v11), v120, v121);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE(v122, v82);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}