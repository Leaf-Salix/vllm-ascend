#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_a(__gm__ float* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int64_t v9, int32_t v10, int32_t v11) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c131072_i64
  const int64_t v12 = 131072;
  // pto: %c196608_i64
  const int64_t v13 = 196608;
  // pto: %c0_i64
  const int64_t v14 = 0;
  // pto: %c32768_i64
  const int64_t v15 = 32768;
  // pto: %c65536_i64
  const int64_t v16 = 65536;
  // pto: %c8192_index
  const int64_t v17 = 8192;
  // pto: %c1_index
  const int64_t v18 = 1;
  // pto: %c16_index
  const int64_t v19 = 16;
  // pto: %c8_index
  const int64_t v20 = 8;
  // pto: %c32768_index
  const int64_t v21 = 32768;
  const int64_t v22 = 64;
  // pto: %c256_index
  const int64_t v23 = 256;
  // pto: %c4194304_index
  const int64_t v24 = 4194304;
  // pto: %c65536_index
  const int64_t v25 = 65536;
  const int64_t v26 = 128;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %c7_index
  const int64_t v28 = 7;
  // pto: %c2_index
  const int64_t v29 = 2;
  // pto: %c3_index
  const int64_t v30 = 3;
  // pto: %c4_index
  const int64_t v31 = 4;
  // pto: %c5_index
  const int64_t v32 = 5;
  // pto: %c6_index
  const int64_t v33 = 6;
  // pto: %c240_index
  const int64_t v34 = 240;
  // pto: %c4096_index
  const int64_t v35 = 4096;
  // pto: %c15_index
  const int64_t v36 = 15;
  // pto: %c1024_index
  const int64_t v37 = 1024;
  // pto: %c127_index
  const int64_t v38 = 127;
  // pto: %289
  int64_t v39 = (int64_t) ((uint64_t) v8 + (uint64_t) v38);
  // pto: %accum_inline1531__iter_v1_view
  const int64_t v40 = 1;
  // pto: %accum_inline1531__iter_v1_view
  const int64_t v41 = 1;
  // pto: %accum_inline1531__iter_v1_view
  const int64_t v42 = 1;
  // pto: %accum_inline1531__iter_v1_view
  int64_t v43 = v39 * v17;
  // pto: %accum_inline1531__iter_v1_view
  int64_t v44 = v42 * v43;
  // pto: %accum_inline1531__iter_v1_view
  pto::Shape<1, 1, 1, -1, -1> v45 = pto::Shape<1, 1, 1, -1, -1>(v40, v41, v42, v39, v17);
  // pto: %accum_inline1531__iter_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v41 * v44, v44, v43, v17, v18);
  // pto: %accum_inline1531__iter_v1_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v47 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v45, v46);
  // pto: %heads__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v51 = (int64_t) v9;
  // pto: %heads__ssa_v0_view
  int64_t v52 = v51 * v21;
  // pto: %heads__ssa_v0_view
  int64_t v53 = v50 * v52;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v54 = pto::Shape<1, 1, 1, -1, -1>(v48, v49, v50, v51, v21);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v55 = pto::Stride<-1, -1, -1, -1, -1>(v49 * v53, v53, v52, v21, v18);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v56 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v54, v55);
  // pto: %wo_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v57 = pto::Shape<-1, -1, -1, -1, -1>(v20, v22, v23, v19, v19);
  // pto: %wo_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v58 = pto::Stride<-1, -1, -1, -1, -1>(v24, v25, v23, v19, v18);
  // pto: %wo_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v59 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v4, v57, v58);
  // pto: %seed_fast_acc_inline1463__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v60 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
  // pto: %seed_fast_acc_inline1463__phi_v7
  uint64_t v61 = (uint64_t) v14;
  TASSIGN(v60, v61);
  // pto: %174
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v62 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
  // pto: %174
  uint64_t v63 = (uint64_t) v14;
  TASSIGN(v62, v63);
  // pto: %206
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v64 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
  // pto: %206
  uint64_t v65 = (uint64_t) v14;
  TASSIGN(v64, v65);
  // pto: %seed_narrow_acc_inline1471__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v66 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v19, v26);
  // pto: %seed_narrow_acc_inline1471__phi_v7
  uint64_t v67 = (uint64_t) v14;
  TASSIGN(v66, v67);
  // pto: %seed_block_inline1453__ssa_v0
  int64_t v68 = (int64_t) v10;
  // pto: %37
  int64_t v69 = (int64_t) ((uint64_t) v68 * (uint64_t) v26);
  // pto: %38, %39
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  for (int64_t v70 = v27; v70 < ((int64_t) ((uint64_t) v5 + (uint64_t) v28) / v20); v70 += v18) {
    // pto: %40
    ;
    int64_t v71 = (int64_t) ((uint64_t) v70 * (uint64_t) v20);
    // pto: %flat_offset, %41, %42, %t__tile
    ;
    int32_t v72 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v70 * (uint64_t) v22) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
    // pto: %43
    ;
    int64_t v73 = (int64_t) v72;
    // pto: %44
    ;
    int64_t v74 = v73 < v27 ? v27 : v73;
    // pto: %45
    ;
    int64_t v75 = (int64_t) ((uint64_t) v71 + (uint64_t) v18);
    // pto: %46
    ;
    // pto: %seed_same_start_inline1443__phi_v3
    ;
    int64_t v76;
    if (v75 < v5) {
      // pto: %49, %50, %51, %52, %47
      ;
      int32_t v77 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v75 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %53
      ;
      int64_t v78 = (int64_t) v77;
      // pto: %54
      ;
      int64_t v79 = v78 < v27 ? v27 : v78;
      // pto: %55, %seed_same_start_inline1443__phi_v2
      ;
      v76 = v79 != v74 ? v27 : v18;
    } else {
      v76 = v18;
    };
    // pto: %56
    ;
    int64_t v80 = (int64_t) ((uint64_t) v71 + (uint64_t) v29);
    // pto: %57
    ;
    // pto: %seed_same_start_inline1443__phi_v6
    ;
    int64_t v81;
    if (v80 < v5) {
      // pto: %60, %61, %62, %63, %58
      ;
      int32_t v82 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v80 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %64
      ;
      int64_t v83 = (int64_t) v82;
      // pto: %65
      ;
      int64_t v84 = v83 < v27 ? v27 : v83;
      // pto: %66, %seed_same_start_inline1443__phi_v5
      ;
      int64_t v85 = v84 != v74 ? v27 : v76;
      v81 = v85;
    } else {
      v81 = v76;
    };
    // pto: %67
    ;
    int64_t v86 = (int64_t) ((uint64_t) v71 + (uint64_t) v30);
    // pto: %68
    ;
    // pto: %seed_same_start_inline1443__phi_v9
    ;
    int64_t v87;
    if (v86 < v5) {
      // pto: %71, %72, %73, %74, %69
      ;
      int32_t v88 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v86 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %75
      ;
      int64_t v89 = (int64_t) v88;
      // pto: %76
      ;
      int64_t v90 = v89 < v27 ? v27 : v89;
      // pto: %77, %seed_same_start_inline1443__phi_v8
      ;
      int64_t v91 = v90 != v74 ? v27 : v81;
      v87 = v91;
    } else {
      v87 = v81;
    };
    // pto: %78
    ;
    int64_t v92 = (int64_t) ((uint64_t) v71 + (uint64_t) v31);
    // pto: %79
    ;
    // pto: %seed_same_start_inline1443__phi_v12
    ;
    int64_t v93;
    if (v92 < v5) {
      // pto: %82, %83, %84, %85, %80
      ;
      int32_t v94 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v92 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %86
      ;
      int64_t v95 = (int64_t) v94;
      // pto: %87
      ;
      int64_t v96 = v95 < v27 ? v27 : v95;
      // pto: %88, %seed_same_start_inline1443__phi_v11
      ;
      int64_t v97 = v96 != v74 ? v27 : v87;
      v93 = v97;
    } else {
      v93 = v87;
    };
    // pto: %89
    ;
    int64_t v98 = (int64_t) ((uint64_t) v71 + (uint64_t) v32);
    // pto: %90
    ;
    // pto: %seed_same_start_inline1443__phi_v15
    ;
    int64_t v99;
    if (v98 < v5) {
      // pto: %93, %94, %95, %96, %91
      ;
      int32_t v100 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v98 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %97
      ;
      int64_t v101 = (int64_t) v100;
      // pto: %98
      ;
      int64_t v102 = v101 < v27 ? v27 : v101;
      // pto: %99, %seed_same_start_inline1443__phi_v14
      ;
      int64_t v103 = v102 != v74 ? v27 : v93;
      v99 = v103;
    } else {
      v99 = v93;
    };
    // pto: %100
    ;
    int64_t v104 = (int64_t) ((uint64_t) v71 + (uint64_t) v33);
    // pto: %101
    ;
    // pto: %seed_same_start_inline1443__phi_v18
    ;
    int64_t v105;
    if (v104 < v5) {
      // pto: %104, %105, %106, %107, %102
      ;
      int32_t v106 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v104 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %108
      ;
      int64_t v107 = (int64_t) v106;
      // pto: %109
      ;
      int64_t v108 = v107 < v27 ? v27 : v107;
      // pto: %110, %seed_same_start_inline1443__phi_v17
      ;
      int64_t v109 = v108 != v74 ? v27 : v99;
      v105 = v109;
    } else {
      v105 = v99;
    };
    // pto: %111
    ;
    int64_t v110 = (int64_t) ((uint64_t) v71 + (uint64_t) v28);
    // pto: %112
    ;
    // pto: %seed_same_start_inline1443__phi_v21
    ;
    int64_t v111;
    if (v110 < v5) {
      // pto: %115, %116, %117, %118, %113
      ;
      int32_t v112 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v110 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %119
      ;
      int64_t v113 = (int64_t) v112;
      // pto: %120
      ;
      int64_t v114 = v113 < v27 ? v27 : v113;
      // pto: %121, %seed_same_start_inline1443__phi_v20
      ;
      int64_t v115 = v114 != v74 ? v27 : v105;
      v111 = v115;
    } else {
      v111 = v105;
    };
    // pto: %122, %seed_same_start_inline1443__phi_v25
    ;
    int64_t v116 = v74 > v34 ? v27 : v111;
    // pto: %123
    ;
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    if (v116 == v18) {
      int64_t v117 = (int64_t) ((uint64_t) v70 * (uint64_t) v26);
      // pto: %125
      ;
      int64_t v118 = (int64_t) ((uint64_t) v8 - (uint64_t) v117);
      // pto: %126
      ;
      int64_t v119 = v118 < v26 ? v118 : v26;
      // pto: %127
      ;
      int64_t v120 = (int64_t) ((uint64_t) v74 * (uint64_t) v19);
      // pto: %seed_fast_seed_x_inline1431__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v119, v23);
      // pto: %seed_fast_seed_x_inline1431__tile
      ;
      uint64_t v122 = (uint64_t) v12;
      TASSIGN(v121, v122);
      // pto: %128
      ;
      int64_t v123 = v117 < v27 ? v27 : v117;
      // pto: %129
      ;
      int64_t v124 = (int64_t) ((uint64_t) v6 * (uint64_t) v35);
      // pto: %130
      ;
      int64_t v125 = (int64_t) ((uint64_t) v124 + (uint64_t) v120);
      // pto: %131
      ;
      int64_t v126 = v125 < v27 ? v27 : v125;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v127 = 0;
      // pto: %heads__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v128 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v129 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v130 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v131 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      int64_t v132 = v119 * v21;
      // pto: %heads__ssa_v0_pview
      ;
      int64_t v133 = v131 * v132;
      // pto: %heads__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 256> v134 = pto::Shape<1, 1, 1, -1, 256>(v129, v130, v131, v119, v23);
      // pto: %heads__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v135 = pto::Stride<-1, -1, -1, -1, -1>(v130 * v133, v133, v132, v21, v18);
      // pto: %heads__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v136 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v128 + (v127 + v123 * v21 + v126 * v18), v134, v135);
      TLOAD(v121, v136);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %seed_fast_seed_w_inline1474__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
      // pto: %seed_fast_seed_w_inline1474__tile
      ;
      uint64_t v138 = (uint64_t) v13;
      TASSIGN(v137, v138);
      // pto: %132
      ;
      int64_t v139 = v6 < v27 ? v27 : v6;
      // pto: %133
      ;
      int64_t v140 = v69 / v19;
      // pto: %134
      ;
      int64_t v141 = v140 < v27 ? v27 : v140;
      // pto: %135
      ;
      int64_t v142 = v120 / v19;
      // pto: %136
      ;
      int64_t v143 = v142 < v27 ? v27 : v142;
      // pto: %wo_a__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v144 = PTOAS__GLOBAL_TENSOR_DATA(v59);
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v145 = 0;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v146 = 4194304;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v147 = 65536;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v148 = 256;
      // pto: %wo_a__ssa_v0_pview
      ;
      pto::Shape<1, 8, 16, 16, 16> v149 = pto::Shape<1, 8, 16, 16, 16>();
      // pto: %wo_a__ssa_v0_pview
      ;
      pto::Stride<4194304, 65536, 256, 16, 1> v150 = pto::Stride<4194304, 65536, 256, 16, 1>();
      // pto: %wo_a__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v151 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v144 + ((v145 + v139 * v146) + v141 * v147 + v143 * v148), v149, v150);
      TLOAD(v137, v151);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %seed_fast_acc_inline1463__tile_l0_init_storage
      ;
      Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v152 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
      // pto: %seed_fast_acc_inline1463__tile_l0_init_storage
      ;
      uint64_t v153 = (uint64_t) v14;
      TASSIGN(v152, v153);
      v152.SetValidShape(v119, v26);
      // pto: %seed_fast_acc_inline1463__tile_l0_a
      ;
      Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v154 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v26);
      // pto: %seed_fast_acc_inline1463__tile_l0_a
      ;
      uint64_t v155 = (uint64_t) v14;
      TASSIGN(v154, v155);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      uint16_t v156 = static_cast<uint16_t>(v27);
      uint16_t v157 = static_cast<uint16_t>(v27);
      TEXTRACT(v154, v121, v156, v157);
      // pto: %seed_fast_acc_inline1463__tile_l0_b
      ;
      Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v158 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
      // pto: %seed_fast_acc_inline1463__tile_l0_b
      ;
      uint64_t v159 = (uint64_t) v15;
      TASSIGN(v158, v159);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      uint16_t v160 = static_cast<uint16_t>(v27);
      uint16_t v161 = static_cast<uint16_t>(v27);
      TEXTRACT(v158, v137, v160, v161);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v162 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v26);
      // pto: %0
      ;
      uint64_t v163 = (uint64_t) v15;
      TASSIGN(v162, v163);
      uint16_t v164 = static_cast<uint16_t>(v27);
      uint16_t v165 = static_cast<uint16_t>(v26);
      TEXTRACT(v162, v121, v164, v165);
      // pto: %1
      ;
      Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v166 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
      // pto: %1
      ;
      uint64_t v167 = (uint64_t) v14;
      TASSIGN(v166, v167);
      uint16_t v168 = static_cast<uint16_t>(v26);
      uint16_t v169 = static_cast<uint16_t>(v27);
      TEXTRACT(v166, v137, v168, v169);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      TMATMUL(v152, v154, v158);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v152, v152, v162, v166);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      for (int64_t v170 = v18; v170 < v36; v170 += v29) {
        // pto: %137
        ;
        int64_t v171 = (int64_t) ((uint64_t) v170 * (uint64_t) v19);
        // pto: %138, %139
        ;
        int64_t v172 = (int64_t) ((uint64_t) v74 + (uint64_t) v171) % v23;
        // pto: %142, %141, %143
        ;
        int64_t v173 = (int64_t) ((uint64_t) v74 + (uint64_t) ((int64_t) (uint64_t) v171 + (uint64_t) v19)) % v23;
        // pto: %144
        ;
        // pto: %145
        ;
        int64_t v174 = v119 < v26 ? v119 : v26;
        v60.SetValidShape(v174, v26);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        if (v172 <= v34) {
          // pto: %146
          ;
          int64_t v175 = (int64_t) ((uint64_t) v172 * (uint64_t) v19);
          // pto: %seed_fast_packet_x_inline1482__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v176 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v119, v23);
          // pto: %seed_fast_packet_x_inline1482__tile
          ;
          uint64_t v177 = (uint64_t) v12;
          TASSIGN(v176, v177);
          // pto: %149
          ;
          int64_t v178 = (int64_t) ((uint64_t) v124 + (uint64_t) v175);
          // pto: %150
          ;
          int64_t v179 = v178 < v27 ? v27 : v178;
          // pto: %151
          ;
          const int64_t v180 = 0;
          // pto: %151
          ;
          __gm__ bfloat16_t* v181 = PTOAS__GLOBAL_TENSOR_DATA(v56);
          // pto: %151
          ;
          const int64_t v182 = 1;
          // pto: %151
          ;
          const int64_t v183 = 1;
          // pto: %151
          ;
          const int64_t v184 = 1;
          // pto: %151
          ;
          int64_t v185 = v119 * v21;
          // pto: %151
          ;
          int64_t v186 = v184 * v185;
          // pto: %151
          ;
          pto::Shape<1, 1, 1, -1, 256> v187 = pto::Shape<1, 1, 1, -1, 256>(v182, v183, v184, v119, v23);
          // pto: %151
          ;
          pto::Stride<-1, -1, -1, -1, -1> v188 = pto::Stride<-1, -1, -1, -1, -1>(v183 * v186, v186, v185, v21, v18);
          // pto: %151
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v189 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v181 + (v180 + v123 * v21 + v179 * v18), v187, v188);
          TLOAD(v176, v189);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          // pto: %seed_fast_packet_w_inline1456__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v190 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
          // pto: %seed_fast_packet_w_inline1456__tile
          ;
          uint64_t v191 = (uint64_t) v13;
          TASSIGN(v190, v191);
          // pto: %155
          ;
          int64_t v192 = v175 / v19;
          // pto: %156
          ;
          int64_t v193 = v192 < v27 ? v27 : v192;
          // pto: %157
          ;
          __gm__ bfloat16_t* v194 = PTOAS__GLOBAL_TENSOR_DATA(v59);
          // pto: %157
          ;
          const int64_t v195 = 0;
          // pto: %157
          ;
          const int64_t v196 = 4194304;
          // pto: %157
          ;
          const int64_t v197 = 65536;
          // pto: %157
          ;
          const int64_t v198 = 256;
          // pto: %157
          ;
          pto::Shape<1, 8, 16, 16, 16> v199 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %157
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v200 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %157
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v201 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v194 + ((v195 + v139 * v196) + v141 * v197 + v193 * v198), v199, v200);
          TLOAD(v190, v201);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
          // pto: %seed_fast_acc_inline1463__iter_v1_l0_a
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v202 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v26);
          // pto: %seed_fast_acc_inline1463__iter_v1_l0_a
          ;
          uint64_t v203 = (uint64_t) v14;
          TASSIGN(v202, v203);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          uint16_t v204 = static_cast<uint16_t>(v27);
          uint16_t v205 = static_cast<uint16_t>(v27);
          TEXTRACT(v202, v176, v204, v205);
          // pto: %seed_fast_acc_inline1463__iter_v1_l0_b
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v206 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %seed_fast_acc_inline1463__iter_v1_l0_b
          ;
          uint64_t v207 = (uint64_t) v15;
          TASSIGN(v206, v207);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
          uint16_t v208 = static_cast<uint16_t>(v27);
          uint16_t v209 = static_cast<uint16_t>(v27);
          TEXTRACT(v206, v190, v208, v209);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
          // pto: %3
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v210 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v26);
          // pto: %3
          ;
          uint64_t v211 = (uint64_t) v15;
          TASSIGN(v210, v211);
          uint16_t v212 = static_cast<uint16_t>(v27);
          uint16_t v213 = static_cast<uint16_t>(v26);
          TEXTRACT(v210, v176, v212, v213);
          // pto: %4
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %4
          ;
          uint64_t v215 = (uint64_t) v14;
          TASSIGN(v214, v215);
          uint16_t v216 = static_cast<uint16_t>(v26);
          uint16_t v217 = static_cast<uint16_t>(v27);
          TEXTRACT(v214, v190, v216, v217);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v152, v152, v202, v206);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
          TMATMUL_ACC(v152, v152, v210, v214);
        } else {
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
          for (int64_t v218 = v27; v218 < v19; v218 += v18) {
            // pto: %158, %159, %160
            ;
            int64_t v219 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v172 + (uint64_t) v218) % v23) * (uint64_t) v19);
            // pto: %seed_fast_wrap_x_inline1483__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v119, v19);
            // pto: %seed_fast_wrap_x_inline1483__tile
            ;
            uint64_t v221 = (uint64_t) v12;
            TASSIGN(v220, v221);
            // pto: %163
            ;
            int64_t v222 = (int64_t) ((uint64_t) v124 + (uint64_t) v219);
            // pto: %164
            ;
            int64_t v223 = v222 < v27 ? v27 : v222;
            // pto: %165
            ;
            const int64_t v224 = 0;
            // pto: %165
            ;
            __gm__ bfloat16_t* v225 = PTOAS__GLOBAL_TENSOR_DATA(v56);
            // pto: %165
            ;
            const int64_t v226 = 1;
            // pto: %165
            ;
            const int64_t v227 = 1;
            // pto: %165
            ;
            const int64_t v228 = 1;
            // pto: %165
            ;
            int64_t v229 = v119 * v21;
            // pto: %165
            ;
            int64_t v230 = v228 * v229;
            // pto: %165
            ;
            pto::Shape<1, 1, 1, -1, 16> v231 = pto::Shape<1, 1, 1, -1, 16>(v226, v227, v228, v119, v19);
            // pto: %165
            ;
            pto::Stride<-1, -1, -1, -1, -1> v232 = pto::Stride<-1, -1, -1, -1, -1>(v227 * v230, v230, v229, v21, v18);
            // pto: %165
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v233 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v225 + (v224 + v123 * v21 + v223 * v18), v231, v232);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            TLOAD(v220, v233);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
            // pto: %seed_fast_wrap_w_inline1484__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %seed_fast_wrap_w_inline1484__tile
            ;
            uint64_t v235 = (uint64_t) v13;
            TASSIGN(v234, v235);
            // pto: %169
            ;
            int64_t v236 = v219 / v19;
            // pto: %170
            ;
            int64_t v237 = v236 < v27 ? v27 : v236;
            // pto: %171
            ;
            __gm__ bfloat16_t* v238 = PTOAS__GLOBAL_TENSOR_DATA(v59);
            // pto: %171
            ;
            const int64_t v239 = 0;
            // pto: %171
            ;
            const int64_t v240 = 4194304;
            // pto: %171
            ;
            const int64_t v241 = 65536;
            // pto: %171
            ;
            const int64_t v242 = 256;
            // pto: %171
            ;
            pto::Shape<1, 8, 1, 16, 16> v243 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %171
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v244 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %171
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v245 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v238 + ((v239 + v139 * v240) + v141 * v241 + v237 * v242), v243, v244);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            TLOAD(v234, v245);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
            // pto: %lhs_slice_0_textract
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v246 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v19);
            // pto: %lhs_slice_0_textract
            ;
            uint64_t v247 = (uint64_t) v14;
            TASSIGN(v246, v247);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
            uint16_t v248 = static_cast<uint16_t>(v27);
            uint16_t v249 = static_cast<uint16_t>(v27);
            TEXTRACT(v246, v220, v248, v249);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            // pto: %rhs_slice_0_textract
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v250 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %rhs_slice_0_textract
            ;
            uint64_t v251 = (uint64_t) v15;
            TASSIGN(v250, v251);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
            uint16_t v252 = static_cast<uint16_t>(v27);
            uint16_t v253 = static_cast<uint16_t>(v27);
            TEXTRACT(v250, v234, v252, v253);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v152, v152, v246, v250);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        };
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        // pto: %172
        ;
        v62.SetValidShape(v174, v26);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        if (v173 <= v34) {
          // pto: %175
          ;
          int64_t v254 = (int64_t) ((uint64_t) v173 * (uint64_t) v19);
          // pto: %6
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v119, v23);
          // pto: %6
          ;
          uint64_t v256 = (uint64_t) v14;
          TASSIGN(v255, v256);
          // pto: %178
          ;
          int64_t v257 = (int64_t) ((uint64_t) v124 + (uint64_t) v254);
          // pto: %179
          ;
          int64_t v258 = v257 < v27 ? v27 : v257;
          // pto: %180
          ;
          const int64_t v259 = 0;
          // pto: %180
          ;
          __gm__ bfloat16_t* v260 = PTOAS__GLOBAL_TENSOR_DATA(v56);
          // pto: %180
          ;
          const int64_t v261 = 1;
          // pto: %180
          ;
          const int64_t v262 = 1;
          // pto: %180
          ;
          const int64_t v263 = 1;
          // pto: %180
          ;
          int64_t v264 = v119 * v21;
          // pto: %180
          ;
          int64_t v265 = v263 * v264;
          // pto: %180
          ;
          pto::Shape<1, 1, 1, -1, 256> v266 = pto::Shape<1, 1, 1, -1, 256>(v261, v262, v263, v119, v23);
          // pto: %180
          ;
          pto::Stride<-1, -1, -1, -1, -1> v267 = pto::Stride<-1, -1, -1, -1, -1>(v262 * v265, v265, v264, v21, v18);
          // pto: %180
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v268 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v260 + (v259 + v123 * v21 + v258 * v18), v266, v267);
          TLOAD(v255, v268);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
          // pto: %7
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
          // pto: %7
          ;
          uint64_t v270 = (uint64_t) v16;
          TASSIGN(v269, v270);
          // pto: %184
          ;
          int64_t v271 = v254 / v19;
          // pto: %185
          ;
          int64_t v272 = v271 < v27 ? v27 : v271;
          // pto: %186
          ;
          __gm__ bfloat16_t* v273 = PTOAS__GLOBAL_TENSOR_DATA(v59);
          // pto: %186
          ;
          const int64_t v274 = 0;
          // pto: %186
          ;
          const int64_t v275 = 4194304;
          // pto: %186
          ;
          const int64_t v276 = 65536;
          // pto: %186
          ;
          const int64_t v277 = 256;
          // pto: %186
          ;
          pto::Shape<1, 8, 16, 16, 16> v278 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %186
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v279 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %186
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v280 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v273 + ((v274 + v139 * v275) + v141 * v276 + v272 * v277), v278, v279);
          TLOAD(v269, v280);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
          // pto: %8
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v281 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v26);
          // pto: %8
          ;
          uint64_t v282 = (uint64_t) v14;
          TASSIGN(v281, v282);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
          uint16_t v283 = static_cast<uint16_t>(v27);
          uint16_t v284 = static_cast<uint16_t>(v27);
          TEXTRACT(v281, v255, v283, v284);
          // pto: %9
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %9
          ;
          uint64_t v286 = (uint64_t) v15;
          TASSIGN(v285, v286);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
          uint16_t v287 = static_cast<uint16_t>(v27);
          uint16_t v288 = static_cast<uint16_t>(v27);
          TEXTRACT(v285, v269, v287, v288);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          // pto: %10
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v289 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v26);
          // pto: %10
          ;
          uint64_t v290 = (uint64_t) v15;
          TASSIGN(v289, v290);
          uint16_t v291 = static_cast<uint16_t>(v27);
          uint16_t v292 = static_cast<uint16_t>(v26);
          TEXTRACT(v289, v255, v291, v292);
          // pto: %11
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %11
          ;
          uint64_t v294 = (uint64_t) v14;
          TASSIGN(v293, v294);
          uint16_t v295 = static_cast<uint16_t>(v26);
          uint16_t v296 = static_cast<uint16_t>(v27);
          TEXTRACT(v293, v269, v295, v296);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v60, v60, v281, v285);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
          TMATMUL_ACC(v60, v60, v289, v293);
        } else {
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
          for (int64_t v297 = v27; v297 < v19; v297 += v18) {
            // pto: %188, %189, %190
            ;
            int64_t v298 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v173 + (uint64_t) v297) % v23) * (uint64_t) v19);
            // pto: %14
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v119, v19);
            // pto: %14
            ;
            uint64_t v300 = (uint64_t) v14;
            TASSIGN(v299, v300);
            // pto: %193
            ;
            int64_t v301 = (int64_t) ((uint64_t) v124 + (uint64_t) v298);
            // pto: %194
            ;
            int64_t v302 = v301 < v27 ? v27 : v301;
            // pto: %195
            ;
            const int64_t v303 = 0;
            // pto: %195
            ;
            __gm__ bfloat16_t* v304 = PTOAS__GLOBAL_TENSOR_DATA(v56);
            // pto: %195
            ;
            const int64_t v305 = 1;
            // pto: %195
            ;
            const int64_t v306 = 1;
            // pto: %195
            ;
            const int64_t v307 = 1;
            // pto: %195
            ;
            int64_t v308 = v119 * v21;
            // pto: %195
            ;
            int64_t v309 = v307 * v308;
            // pto: %195
            ;
            pto::Shape<1, 1, 1, -1, 16> v310 = pto::Shape<1, 1, 1, -1, 16>(v305, v306, v307, v119, v19);
            // pto: %195
            ;
            pto::Stride<-1, -1, -1, -1, -1> v311 = pto::Stride<-1, -1, -1, -1, -1>(v306 * v309, v309, v308, v21, v18);
            // pto: %195
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v312 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v304 + (v303 + v123 * v21 + v302 * v18), v310, v311);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
            TLOAD(v299, v312);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %15
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %15
            ;
            uint64_t v314 = (uint64_t) v16;
            TASSIGN(v313, v314);
            // pto: %199
            ;
            int64_t v315 = v298 / v19;
            // pto: %200
            ;
            int64_t v316 = v315 < v27 ? v27 : v315;
            // pto: %201
            ;
            __gm__ bfloat16_t* v317 = PTOAS__GLOBAL_TENSOR_DATA(v59);
            // pto: %201
            ;
            const int64_t v318 = 0;
            // pto: %201
            ;
            const int64_t v319 = 4194304;
            // pto: %201
            ;
            const int64_t v320 = 65536;
            // pto: %201
            ;
            const int64_t v321 = 256;
            // pto: %201
            ;
            pto::Shape<1, 8, 1, 16, 16> v322 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %201
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v323 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %201
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v324 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v317 + ((v318 + v139 * v319) + v141 * v320 + v316 * v321), v322, v323);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
            TLOAD(v313, v324);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %16
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v325 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v19);
            // pto: %16
            ;
            uint64_t v326 = (uint64_t) v14;
            TASSIGN(v325, v326);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
            uint16_t v327 = static_cast<uint16_t>(v27);
            uint16_t v328 = static_cast<uint16_t>(v27);
            TEXTRACT(v325, v299, v327, v328);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
            // pto: %17
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v329 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %17
            ;
            uint64_t v330 = (uint64_t) v15;
            TASSIGN(v329, v330);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v331 = static_cast<uint16_t>(v27);
            uint16_t v332 = static_cast<uint16_t>(v27);
            TEXTRACT(v329, v313, v331, v332);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v60, v60, v325, v329);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        };
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      // pto: %202, %203
      ;
      int64_t v333 = (int64_t) ((uint64_t) v74 + (uint64_t) v34) % v23;
      // pto: %204
      ;
      // pto: %205
      ;
      int64_t v334 = v119 < v26 ? v119 : v26;
      v64.SetValidShape(v334, v26);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      if (v333 <= v34) {
        // pto: %207
        ;
        int64_t v335 = (int64_t) ((uint64_t) v333 * (uint64_t) v19);
        // pto: %19
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v336 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v119, v23);
        // pto: %19
        ;
        uint64_t v337 = (uint64_t) v12;
        TASSIGN(v336, v337);
        // pto: %210
        ;
        int64_t v338 = (int64_t) ((uint64_t) v124 + (uint64_t) v335);
        // pto: %211
        ;
        int64_t v339 = v338 < v27 ? v27 : v338;
        // pto: %212
        ;
        const int64_t v340 = 0;
        // pto: %212
        ;
        __gm__ bfloat16_t* v341 = PTOAS__GLOBAL_TENSOR_DATA(v56);
        // pto: %212
        ;
        const int64_t v342 = 1;
        // pto: %212
        ;
        const int64_t v343 = 1;
        // pto: %212
        ;
        const int64_t v344 = 1;
        // pto: %212
        ;
        int64_t v345 = v119 * v21;
        // pto: %212
        ;
        int64_t v346 = v344 * v345;
        // pto: %212
        ;
        pto::Shape<1, 1, 1, -1, 256> v347 = pto::Shape<1, 1, 1, -1, 256>(v342, v343, v344, v119, v23);
        // pto: %212
        ;
        pto::Stride<-1, -1, -1, -1, -1> v348 = pto::Stride<-1, -1, -1, -1, -1>(v343 * v346, v346, v345, v21, v18);
        // pto: %212
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v349 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v341 + (v340 + v123 * v21 + v339 * v18), v347, v348);
        TLOAD(v336, v349);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %20
        ;
        Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v350 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
        // pto: %20
        ;
        uint64_t v351 = (uint64_t) v13;
        TASSIGN(v350, v351);
        // pto: %216
        ;
        int64_t v352 = v335 / v19;
        // pto: %217
        ;
        int64_t v353 = v352 < v27 ? v27 : v352;
        // pto: %218
        ;
        __gm__ bfloat16_t* v354 = PTOAS__GLOBAL_TENSOR_DATA(v59);
        // pto: %218
        ;
        const int64_t v355 = 0;
        // pto: %218
        ;
        const int64_t v356 = 4194304;
        // pto: %218
        ;
        const int64_t v357 = 65536;
        // pto: %218
        ;
        const int64_t v358 = 256;
        // pto: %218
        ;
        pto::Shape<1, 8, 16, 16, 16> v359 = pto::Shape<1, 8, 16, 16, 16>();
        // pto: %218
        ;
        pto::Stride<4194304, 65536, 256, 16, 1> v360 = pto::Stride<4194304, 65536, 256, 16, 1>();
        // pto: %218
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v361 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v354 + ((v355 + v139 * v356) + v141 * v357 + v353 * v358), v359, v360);
        TLOAD(v350, v361);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %21
        ;
        Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v362 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v26);
        // pto: %21
        ;
        uint64_t v363 = (uint64_t) v14;
        TASSIGN(v362, v363);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        uint16_t v364 = static_cast<uint16_t>(v27);
        uint16_t v365 = static_cast<uint16_t>(v27);
        TEXTRACT(v362, v336, v364, v365);
        // pto: %22
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v366 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
        // pto: %22
        ;
        uint64_t v367 = (uint64_t) v15;
        TASSIGN(v366, v367);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v368 = static_cast<uint16_t>(v27);
        uint16_t v369 = static_cast<uint16_t>(v27);
        TEXTRACT(v366, v350, v368, v369);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %23
        ;
        Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v370 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v26);
        // pto: %23
        ;
        uint64_t v371 = (uint64_t) v15;
        TASSIGN(v370, v371);
        uint16_t v372 = static_cast<uint16_t>(v27);
        uint16_t v373 = static_cast<uint16_t>(v26);
        TEXTRACT(v370, v336, v372, v373);
        // pto: %24
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v374 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
        // pto: %24
        ;
        uint64_t v375 = (uint64_t) v14;
        TASSIGN(v374, v375);
        uint16_t v376 = static_cast<uint16_t>(v26);
        uint16_t v377 = static_cast<uint16_t>(v27);
        TEXTRACT(v374, v350, v376, v377);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v152, v152, v362, v366);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v152, v152, v370, v374);
      } else {
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        for (int64_t v378 = v27; v378 < v19; v378 += v18) {
          // pto: %220, %221, %222
          ;
          int64_t v379 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v333 + (uint64_t) v378) % v23) * (uint64_t) v19);
          // pto: %27
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v380 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v119, v19);
          // pto: %27
          ;
          uint64_t v381 = (uint64_t) v12;
          TASSIGN(v380, v381);
          // pto: %225
          ;
          int64_t v382 = (int64_t) ((uint64_t) v124 + (uint64_t) v379);
          // pto: %226
          ;
          int64_t v383 = v382 < v27 ? v27 : v382;
          // pto: %227
          ;
          const int64_t v384 = 0;
          // pto: %227
          ;
          __gm__ bfloat16_t* v385 = PTOAS__GLOBAL_TENSOR_DATA(v56);
          // pto: %227
          ;
          const int64_t v386 = 1;
          // pto: %227
          ;
          const int64_t v387 = 1;
          // pto: %227
          ;
          const int64_t v388 = 1;
          // pto: %227
          ;
          int64_t v389 = v119 * v21;
          // pto: %227
          ;
          int64_t v390 = v388 * v389;
          // pto: %227
          ;
          pto::Shape<1, 1, 1, -1, 16> v391 = pto::Shape<1, 1, 1, -1, 16>(v386, v387, v388, v119, v19);
          // pto: %227
          ;
          pto::Stride<-1, -1, -1, -1, -1> v392 = pto::Stride<-1, -1, -1, -1, -1>(v387 * v390, v390, v389, v21, v18);
          // pto: %227
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v393 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v385 + (v384 + v123 * v21 + v383 * v18), v391, v392);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          TLOAD(v380, v393);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %28
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v394 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
          // pto: %28
          ;
          uint64_t v395 = (uint64_t) v13;
          TASSIGN(v394, v395);
          // pto: %231
          ;
          int64_t v396 = v379 / v19;
          // pto: %232
          ;
          int64_t v397 = v396 < v27 ? v27 : v396;
          // pto: %233
          ;
          __gm__ bfloat16_t* v398 = PTOAS__GLOBAL_TENSOR_DATA(v59);
          // pto: %233
          ;
          const int64_t v399 = 0;
          // pto: %233
          ;
          const int64_t v400 = 4194304;
          // pto: %233
          ;
          const int64_t v401 = 65536;
          // pto: %233
          ;
          const int64_t v402 = 256;
          // pto: %233
          ;
          pto::Shape<1, 8, 1, 16, 16> v403 = pto::Shape<1, 8, 1, 16, 16>();
          // pto: %233
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v404 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %233
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v405 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v398 + ((v399 + v139 * v400) + v141 * v401 + v397 * v402), v403, v404);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          TLOAD(v394, v405);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %29
          ;
          Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v406 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v119, v19);
          // pto: %29
          ;
          uint64_t v407 = (uint64_t) v14;
          TASSIGN(v406, v407);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          uint16_t v408 = static_cast<uint16_t>(v27);
          uint16_t v409 = static_cast<uint16_t>(v27);
          TEXTRACT(v406, v380, v408, v409);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %30
          ;
          Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v410 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
          // pto: %30
          ;
          uint64_t v411 = (uint64_t) v15;
          TASSIGN(v410, v411);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v412 = static_cast<uint16_t>(v27);
          uint16_t v413 = static_cast<uint16_t>(v27);
          TEXTRACT(v410, v394, v412, v413);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v152, v152, v406, v410);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        };
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      };
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      // pto: %seed_fast_acc_inline1463__rv_v2
      ;
      Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v414 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v119, v26);
      // pto: %seed_fast_acc_inline1463__rv_v2
      ;
      uint64_t v415 = (uint64_t) v14;
      TASSIGN(v414, v415);
      // pto: %235, %236
      ;
      int64_t v416 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v37) + (uint64_t) v69);
      // pto: %237
      ;
      int64_t v417 = v416 < v27 ? v27 : v416;
      // pto: %accum_inline1531__iter_v3_pview
      ;
      const int64_t v418 = 0;
      // pto: %accum_inline1531__iter_v3_pview
      ;
      __gm__ float* v419 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %accum_inline1531__iter_v3_pview
      ;
      const int64_t v420 = 1;
      // pto: %accum_inline1531__iter_v3_pview
      ;
      const int64_t v421 = 1;
      // pto: %accum_inline1531__iter_v3_pview
      ;
      const int64_t v422 = 1;
      // pto: %accum_inline1531__iter_v3_pview
      ;
      int64_t v423 = v119 * v17;
      // pto: %accum_inline1531__iter_v3_pview
      ;
      int64_t v424 = v422 * v423;
      // pto: %accum_inline1531__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, -1, 128> v425 = pto::Shape<1, 1, 1, -1, 128>(v420, v421, v422, v119, v26);
      // pto: %accum_inline1531__iter_v3_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v426 = pto::Stride<-1, -1, -1, -1, -1>(v421 * v424, v424, v423, v17, v18);
      // pto: %accum_inline1531__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v427 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v419 + (v418 + v123 * v17 + v417 * v18), v425, v426);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      TSTORE(v427, v414);
    } else {
      for (int64_t v428 = v27; v428 < v20; v428 += v18) {
        // pto: %238
        ;
        int64_t v429 = (int64_t) ((uint64_t) v71 + (uint64_t) v428);
        // pto: %239
        ;
        if (v429 < v5) {
          // pto: %240
          ;
          int64_t v430 = (int64_t) ((uint64_t) v429 * (uint64_t) v19);
          // pto: %241
          ;
          int64_t v431 = (int64_t) ((uint64_t) v8 - (uint64_t) v430);
          // pto: %242
          ;
          int64_t v432 = v431 < v19 ? v431 : v19;
          // pto: %244, %245, %246, %247, %243
          ;
          int32_t v433 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v429 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
          // pto: %248
          ;
          int64_t v434 = (int64_t) v433;
          // pto: %249
          ;
          int64_t v435 = v434 < v27 ? v27 : v434;
          // pto: %seed_narrow_acc_inline1471__tile
          ;
          Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v436 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v19, v26);
          // pto: %seed_narrow_acc_inline1471__tile
          ;
          uint64_t v437 = (uint64_t) v14;
          TASSIGN(v436, v437);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          for (int64_t v438 = v27; v438 < v19; v438 += v18) {
            // pto: %250
            ;
            int64_t v439 = (int64_t) ((uint64_t) v438 * (uint64_t) v19);
            // pto: %251, %252
            ;
            int64_t v440 = (int64_t) ((uint64_t) v435 + (uint64_t) v439) % v23;
            // pto: %253
            ;
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            if (v440 <= v34) {
              // pto: %254
              ;
              int64_t v441 = (int64_t) ((uint64_t) v440 * (uint64_t) v19);
              // pto: %seed_narrow_packet_x_inline1437__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v442 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v432, v23);
              // pto: %seed_narrow_packet_x_inline1437__tile
              ;
              uint64_t v443 = (uint64_t) v13;
              TASSIGN(v442, v443);
              // pto: %255
              ;
              int64_t v444 = v430 < v27 ? v27 : v430;
              // pto: %256, %257
              ;
              int64_t v445 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v35) + (uint64_t) v441);
              // pto: %258
              ;
              int64_t v446 = v445 < v27 ? v27 : v445;
              // pto: %259
              ;
              const int64_t v447 = 0;
              // pto: %259
              ;
              __gm__ bfloat16_t* v448 = PTOAS__GLOBAL_TENSOR_DATA(v56);
              // pto: %259
              ;
              const int64_t v449 = 1;
              // pto: %259
              ;
              const int64_t v450 = 1;
              // pto: %259
              ;
              const int64_t v451 = 1;
              // pto: %259
              ;
              int64_t v452 = v432 * v21;
              // pto: %259
              ;
              int64_t v453 = v451 * v452;
              // pto: %259
              ;
              pto::Shape<1, 1, 1, -1, 256> v454 = pto::Shape<1, 1, 1, -1, 256>(v449, v450, v451, v432, v23);
              // pto: %259
              ;
              pto::Stride<-1, -1, -1, -1, -1> v455 = pto::Stride<-1, -1, -1, -1, -1>(v450 * v453, v453, v452, v21, v18);
              // pto: %259
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v456 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v448 + (v447 + v444 * v21 + v446 * v18), v454, v455);
              TLOAD(v442, v456);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %seed_narrow_packet_w_inline1434__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v457 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
              // pto: %seed_narrow_packet_w_inline1434__tile
              ;
              uint64_t v458 = (uint64_t) v12;
              TASSIGN(v457, v458);
              // pto: %260
              ;
              int64_t v459 = v6 < v27 ? v27 : v6;
              // pto: %261
              ;
              int64_t v460 = v69 / v19;
              // pto: %262
              ;
              int64_t v461 = v460 < v27 ? v27 : v460;
              // pto: %263
              ;
              int64_t v462 = v441 / v19;
              // pto: %264
              ;
              int64_t v463 = v462 < v27 ? v27 : v462;
              // pto: %265
              ;
              __gm__ bfloat16_t* v464 = PTOAS__GLOBAL_TENSOR_DATA(v59);
              // pto: %265
              ;
              const int64_t v465 = 0;
              // pto: %265
              ;
              const int64_t v466 = 4194304;
              // pto: %265
              ;
              const int64_t v467 = 65536;
              // pto: %265
              ;
              const int64_t v468 = 256;
              // pto: %265
              ;
              pto::Shape<1, 8, 16, 16, 16> v469 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %265
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v470 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %265
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v471 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v464 + ((v465 + v459 * v466) + v461 * v467 + v463 * v468), v469, v470);
              TLOAD(v457, v471);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %seed_narrow_acc_inline1471__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v472 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v432, v26);
              // pto: %seed_narrow_acc_inline1471__iter_v1_l0_a
              ;
              uint64_t v473 = (uint64_t) v14;
              TASSIGN(v472, v473);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              uint16_t v474 = static_cast<uint16_t>(v27);
              uint16_t v475 = static_cast<uint16_t>(v27);
              TEXTRACT(v472, v442, v474, v475);
              // pto: %seed_narrow_acc_inline1471__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v476 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
              // pto: %seed_narrow_acc_inline1471__iter_v1_l0_b
              ;
              uint64_t v477 = (uint64_t) v15;
              TASSIGN(v476, v477);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v478 = static_cast<uint16_t>(v27);
              uint16_t v479 = static_cast<uint16_t>(v27);
              TEXTRACT(v476, v457, v478, v479);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              // pto: %32
              ;
              Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v480 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v432, v26);
              // pto: %32
              ;
              uint64_t v481 = (uint64_t) v15;
              TASSIGN(v480, v481);
              uint16_t v482 = static_cast<uint16_t>(v27);
              uint16_t v483 = static_cast<uint16_t>(v26);
              TEXTRACT(v480, v442, v482, v483);
              // pto: %33
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v484 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
              // pto: %33
              ;
              uint64_t v485 = (uint64_t) v14;
              TASSIGN(v484, v485);
              uint16_t v486 = static_cast<uint16_t>(v26);
              uint16_t v487 = static_cast<uint16_t>(v27);
              TEXTRACT(v484, v457, v486, v487);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              // pto: %266
              ;
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              if (v438 == v27) {
                pipe_barrier(PIPE_M);
                TMATMUL(v436, v472, v476);
              } else {
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v436, v436, v472, v476);
              };
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              TMATMUL_ACC(v436, v436, v480, v484);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              for (int64_t v488 = v27; v488 < v19; v488 += v18) {
                // pto: %267, %268, %269
                ;
                int64_t v489 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v440 + (uint64_t) v488) % v23) * (uint64_t) v19);
                // pto: %seed_narrow_wrap_x_inline1429__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v490 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v432, v19);
                // pto: %seed_narrow_wrap_x_inline1429__tile
                ;
                uint64_t v491 = (uint64_t) v13;
                TASSIGN(v490, v491);
                // pto: %270
                ;
                int64_t v492 = v430 < v27 ? v27 : v430;
                // pto: %271, %272
                ;
                int64_t v493 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v35) + (uint64_t) v489);
                // pto: %273
                ;
                int64_t v494 = v493 < v27 ? v27 : v493;
                // pto: %274
                ;
                const int64_t v495 = 0;
                // pto: %274
                ;
                __gm__ bfloat16_t* v496 = PTOAS__GLOBAL_TENSOR_DATA(v56);
                // pto: %274
                ;
                const int64_t v497 = 1;
                // pto: %274
                ;
                const int64_t v498 = 1;
                // pto: %274
                ;
                const int64_t v499 = 1;
                // pto: %274
                ;
                int64_t v500 = v432 * v21;
                // pto: %274
                ;
                int64_t v501 = v499 * v500;
                // pto: %274
                ;
                pto::Shape<1, 1, 1, -1, 16> v502 = pto::Shape<1, 1, 1, -1, 16>(v497, v498, v499, v432, v19);
                // pto: %274
                ;
                pto::Stride<-1, -1, -1, -1, -1> v503 = pto::Stride<-1, -1, -1, -1, -1>(v498 * v501, v501, v500, v21, v18);
                // pto: %274
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v504 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v496 + (v495 + v492 * v21 + v494 * v18), v502, v503);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                TLOAD(v490, v504);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %seed_narrow_wrap_w_inline1466__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v505 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
                // pto: %seed_narrow_wrap_w_inline1466__tile
                ;
                uint64_t v506 = (uint64_t) v12;
                TASSIGN(v505, v506);
                // pto: %275
                ;
                int64_t v507 = v6 < v27 ? v27 : v6;
                // pto: %276
                ;
                int64_t v508 = v69 / v19;
                // pto: %277
                ;
                int64_t v509 = v508 < v27 ? v27 : v508;
                // pto: %278
                ;
                int64_t v510 = v489 / v19;
                // pto: %279
                ;
                int64_t v511 = v510 < v27 ? v27 : v510;
                // pto: %280
                ;
                __gm__ bfloat16_t* v512 = PTOAS__GLOBAL_TENSOR_DATA(v59);
                // pto: %280
                ;
                const int64_t v513 = 0;
                // pto: %280
                ;
                const int64_t v514 = 4194304;
                // pto: %280
                ;
                const int64_t v515 = 65536;
                // pto: %280
                ;
                const int64_t v516 = 256;
                // pto: %280
                ;
                pto::Shape<1, 8, 1, 16, 16> v517 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %280
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v518 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %280
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v519 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v512 + ((v513 + v507 * v514) + v509 * v515 + v511 * v516), v517, v518);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v505, v519);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %35
                ;
                Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v520 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v432, v19);
                // pto: %35
                ;
                uint64_t v521 = (uint64_t) v14;
                TASSIGN(v520, v521);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                uint16_t v522 = static_cast<uint16_t>(v27);
                uint16_t v523 = static_cast<uint16_t>(v27);
                TEXTRACT(v520, v490, v522, v523);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                // pto: %36
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v524 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
                // pto: %36
                ;
                uint64_t v525 = (uint64_t) v15;
                TASSIGN(v524, v525);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v526 = static_cast<uint16_t>(v27);
                uint16_t v527 = static_cast<uint16_t>(v27);
                TEXTRACT(v524, v505, v526, v527);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                // pto: %282, %283
                ;
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                if ((int64_t) ((uint64_t) v439 + (uint64_t) v488) == v27) {
                  pipe_barrier(PIPE_M);
                  TMATMUL(v436, v520, v524);
                } else {
                  pipe_barrier(PIPE_M);
                  TMATMUL_ACC(v436, v436, v520, v524);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          // pto: %285
          ;
          int64_t v528 = v430 < v27 ? v27 : v430;
          // pto: %286, %287
          ;
          int64_t v529 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v37) + (uint64_t) v69);
          // pto: %288
          ;
          int64_t v530 = v529 < v27 ? v27 : v529;
          // pto: %accum_inline1531__iter_v6_pview
          ;
          __gm__ float* v531 = PTOAS__GLOBAL_TENSOR_DATA(v47);
          // pto: %accum_inline1531__iter_v6_pview
          ;
          const int64_t v532 = 0;
          // pto: %accum_inline1531__iter_v6_pview
          ;
          const int64_t v533 = 8192;
          // pto: %accum_inline1531__iter_v6_pview
          ;
          pto::Shape<1, 1, 1, 16, 128> v534 = pto::Shape<1, 1, 1, 16, 128>();
          // pto: %accum_inline1531__iter_v6_pview
          ;
          pto::Stride<131072, 131072, 131072, 8192, 1> v535 = pto::Stride<131072, 131072, 131072, 8192, 1>();
          // pto: %accum_inline1531__iter_v6_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v536 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v531 + (v532 + v528 * v533 + v530), v534, v535);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          pipe_barrier(PIPE_FIX);
          TSTORE(v536, v436);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        };
      };
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}