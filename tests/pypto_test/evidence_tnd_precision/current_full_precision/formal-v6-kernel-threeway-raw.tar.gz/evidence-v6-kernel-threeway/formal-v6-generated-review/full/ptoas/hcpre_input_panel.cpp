#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void hcpre_input_panel(__gm__ float* v1, __gm__ bfloat16_t* v2, int64_t v3, int64_t v4, int64_t v5, int64_t v6, int32_t v7, int32_t v8) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v9 = 64;
  // pto: %c0_i64
  const int64_t v10 = 0;
  // pto: %c32768_i64
  const int64_t v11 = 32768;
  // pto: %c65536_i64
  const int64_t v12 = 65536;
  // pto: %c16384_index
  const int64_t v13 = 16384;
  // pto: %c1_index
  const int64_t v14 = 1;
  // pto: %c32768_index
  const int64_t v15 = 32768;
  // pto: %c0_index
  const int64_t v16 = 0;
  // pto: %c64_index
  const int64_t v17 = 64;
  // pto: %c16_index
  const int64_t v18 = 16;
  // pto: %c256_index
  const int64_t v19 = 256;
  // pto: %cst_10
  const float v20 = 0.0f;
  const int64_t v21 = 512;
  // pto: %c32_index
  const int64_t v22 = 32;
  // pto: %c8_index
  const int64_t v23 = 8;
  // pto: %x_flat_inline8233__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %x_flat_inline8233__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %x_flat_inline8233__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %x_flat_inline8233__ssa_v0_view
  int64_t v27 = (int64_t) v5;
  // pto: %x_flat_inline8233__ssa_v0_view
  int64_t v28 = v27 * v13;
  // pto: %x_flat_inline8233__ssa_v0_view
  int64_t v29 = v26 * v28;
  // pto: %x_flat_inline8233__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v30 = pto::Shape<1, 1, 1, -1, -1>(v24, v25, v26, v27, v13);
  // pto: %x_flat_inline8233__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v31 = pto::Stride<-1, -1, -1, -1, -1>(v25 * v29, v29, v28, v13, v14);
  // pto: %x_flat_inline8233__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v32 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v30, v31);
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  int64_t v36 = (int64_t) v6;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  int64_t v37 = v36 * v15;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  int64_t v38 = v35 * v37;
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v39 = pto::Shape<1, 1, 1, -1, -1>(v33, v34, v35, v36, v15);
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v40 = pto::Stride<-1, -1, -1, -1, -1>(v34 * v38, v38, v37, v15, v14);
  // pto: %panel64_packed_flat_inline8179__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v41 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v39, v40);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v42 = v16; v42 < v3; v42 += v14) {
    // pto: %panel64_input_group_inline8248__ssa_v0, %1, %2
    ;
    int64_t v43 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v7) * (uint64_t) v3) + (uint64_t) v42);
    // pto: %3, %4
    ;
    int64_t v44 = (int64_t) ((uint64_t) (v43 / v17) * (uint64_t) v18);
    // pto: %5
    ;
    int64_t v45 = v43 % v17;
    // pto: %6
    ;
    int64_t v46 = (int64_t) ((uint64_t) v45 * (uint64_t) v19);
    // pto: %7
    ;
    int64_t v47 = (int64_t) ((uint64_t) v5 - (uint64_t) v44);
    // pto: %8
    ;
    int64_t v48 = v47 < v18 ? v47 : v18;
    // pto: %panel64_values_inline8193__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v49 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v19);
    // pto: %panel64_values_inline8193__ssa_v0
    ;
    uint64_t v50 = (uint64_t) v10;
    TASSIGN(v49, v50);
    // pto: %9
    ;
    int64_t v51 = v44 < v16 ? v16 : v44;
    // pto: %10
    ;
    int64_t v52 = v46 < v16 ? v16 : v46;
    // pto: %x_flat_inline8233__ssa_v0_pview
    ;
    const int64_t v53 = 0;
    // pto: %x_flat_inline8233__ssa_v0_pview
    ;
    __gm__ float* v54 = PTOAS__GLOBAL_TENSOR_DATA(v32);
    // pto: %x_flat_inline8233__ssa_v0_pview
    ;
    const int64_t v55 = 1;
    // pto: %x_flat_inline8233__ssa_v0_pview
    ;
    const int64_t v56 = 1;
    // pto: %x_flat_inline8233__ssa_v0_pview
    ;
    const int64_t v57 = 1;
    // pto: %x_flat_inline8233__ssa_v0_pview
    ;
    int64_t v58 = v48 * v13;
    // pto: %x_flat_inline8233__ssa_v0_pview
    ;
    int64_t v59 = v57 * v58;
    // pto: %x_flat_inline8233__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 256> v60 = pto::Shape<1, 1, 1, -1, 256>(v55, v56, v57, v48, v19);
    // pto: %x_flat_inline8233__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v61 = pto::Stride<-1, -1, -1, -1, -1>(v56 * v59, v59, v58, v13, v14);
    // pto: %x_flat_inline8233__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v62 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v54 + (v53 + v51 * v13 + v52 * v14), v60, v61);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v49, v62);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    set_flag(PIPE_MTE2, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE2, PIPE_S, EVENT_ID0);
    for (int64_t v63 = v48; v63 < v18; v63 += v14) {
      for (int64_t v64 = v16; v64 < v19; v64 += v14) {
        // pto: %flat_offset_mul, %flat_offset
        ;
        int64_t v65 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v63 * (uint64_t) v19) + (uint64_t) v64);
        v49.SetValue(v65, v20);
      };
    };
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    v49.SetValidShape(v18, v19);
    // pto: %transpose_tmp
    ;
    Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v66 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v19);
    // pto: %transpose_tmp
    ;
    uint64_t v67 = (uint64_t) v11;
    TASSIGN(v66, v67);
    // pto: %panel64_transposed_values_inline8201__ssa_v0
    ;
    Tile<TileType::Vec, float, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v68 = Tile<TileType::Vec, float, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v18);
    // pto: %panel64_transposed_values_inline8201__ssa_v0
    ;
    uint64_t v69 = (uint64_t) v12;
    TASSIGN(v68, v69);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TTRANS(v68, v49, v66);
    // pto: %panel64_packed_transposed_inline8207__ssa_v0
    ;
    Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v70 = Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v18);
    // pto: %panel64_packed_transposed_inline8207__ssa_v0
    ;
    uint64_t v71 = (uint64_t) v10;
    TASSIGN(v70, v71);
    pipe_barrier(PIPE_V);
    TEXPANDS(v70, v20);
    for (int64_t v72 = v16; v72 < v22; v72 += v14) {
      // pto: %panel64_input8_inline8185__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v73 = Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v18);
      // pto: %panel64_input8_inline8185__ssa_v0
      ;
      uint64_t v74 = (uint64_t) v12;
      TASSIGN(v73, v74);
      // pto: %slice_view
      ;
      Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v75;
      // pto: %15, %slice_view
      ;
      uint64_t v76 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v72 * (uint64_t) v23) * (uint64_t) v9) + (uint64_t) v12);
      TASSIGN(v75, v76);
      // pto: %16
      ;
      int64_t v77 = (int64_t) ((uint64_t) v72 * (uint64_t) v18);
      // pto: %assemble_view
      ;
      Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v78;
      // pto: %assemble_view
      ;
      uint64_t v79 = (uint64_t) ((int64_t) (uint64_t) v77 * (uint64_t) v9);
      TASSIGN(v78, v79);
      pipe_barrier(PIPE_V);
      TMOV(v78, v75);
      // pto: %19
      ;
      Tile<TileType::Vec, float, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v80;
      // pto: %18, %19
      ;
      uint64_t v81 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v77 + (uint64_t) v23) * (uint64_t) v9);
      TASSIGN(v80, v81);
      pipe_barrier(PIPE_V);
      TMOV(v80, v75);
    };
    // pto: %0
    ;
    Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v82 = Tile<TileType::Vec, float, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v18);
    // pto: %0
    ;
    uint64_t v83 = (uint64_t) v11;
    TASSIGN(v82, v83);
    // pto: %panel64_packed_values_inline8200__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v84 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v21);
    // pto: %panel64_packed_values_inline8200__ssa_v0
    ;
    uint64_t v85 = (uint64_t) v12;
    TASSIGN(v84, v85);
    pipe_barrier(PIPE_V);
    TTRANS(v84, v70, v82);
    // pto: %t__tmp_v10
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v86 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v21);
    // pto: %t__tmp_v10
    ;
    uint64_t v87 = (uint64_t) v10;
    TASSIGN(v86, v87);
    pipe_barrier(PIPE_V);
    RoundMode v88 = RoundMode::CAST_ROUND;
    SaturationMode v89 = SaturationMode::ON;
    TCVT(v86, v84, v88, v89);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    int64_t v90 = (int64_t) ((uint64_t) v45 * (uint64_t) v21);
    // pto: %22
    ;
    int64_t v91 = v90 < v16 ? v16 : v90;
    // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v92 = PTOAS__GLOBAL_TENSOR_DATA(v41);
    // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
    ;
    const int64_t v93 = 0;
    // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
    ;
    const int64_t v94 = 32768;
    // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 16, 512> v95 = pto::Shape<1, 1, 1, 16, 512>();
    // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
    ;
    pto::Stride<524288, 524288, 524288, 32768, 1> v96 = pto::Stride<524288, 524288, 524288, 32768, 1>();
    // pto: %panel64_packed_flat_inline8179__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND> v97 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND>(v92 + (v93 + v51 * v94 + v91), v95, v96);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v97, v86);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}