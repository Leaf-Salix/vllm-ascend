#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_a_bf16(__gm__ float* v1, __gm__ bfloat16_t* v2, int64_t v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v8 = 0;
  // pto: %c8192_index
  const int64_t v9 = 8192;
  // pto: %c1_index
  const int64_t v10 = 1;
  // pto: %c8_index
  const int64_t v11 = 8;
  // pto: %c16_index
  const int64_t v12 = 16;
  // pto: %c1024_index
  const int64_t v13 = 1024;
  // pto: %c0_index
  const int64_t v14 = 0;
  // pto: %c127_index
  const int64_t v15 = 127;
  // pto: %10
  int64_t v16 = (int64_t) ((uint64_t) v4 + (uint64_t) v15);
  // pto: %accum_inline1531__phi_v21_view
  const int64_t v17 = 1;
  // pto: %accum_inline1531__phi_v21_view
  const int64_t v18 = 1;
  // pto: %accum_inline1531__phi_v21_view
  const int64_t v19 = 1;
  // pto: %accum_inline1531__phi_v21_view
  int64_t v20 = v16 * v9;
  // pto: %accum_inline1531__phi_v21_view
  int64_t v21 = v19 * v20;
  // pto: %accum_inline1531__phi_v21_view
  pto::Shape<1, 1, 1, -1, -1> v22 = pto::Shape<1, 1, 1, -1, -1>(v17, v18, v19, v16, v9);
  // pto: %accum_inline1531__phi_v21_view
  pto::Stride<-1, -1, -1, -1, -1> v23 = pto::Stride<-1, -1, -1, -1, -1>(v18 * v21, v21, v20, v9, v10);
  // pto: %accum_inline1531__phi_v21_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v24 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v22, v23);
  // pto: %projected_o__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %projected_o__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %projected_o__ssa_v0_view
  const int64_t v27 = 1;
  // pto: %projected_o__ssa_v0_view
  int64_t v28 = (int64_t) v5;
  // pto: %projected_o__ssa_v0_view
  int64_t v29 = v28 * v9;
  // pto: %projected_o__ssa_v0_view
  int64_t v30 = v27 * v29;
  // pto: %projected_o__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v31 = pto::Shape<1, 1, 1, -1, -1>(v25, v26, v27, v28, v9);
  // pto: %projected_o__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v32 = pto::Stride<-1, -1, -1, -1, -1>(v26 * v30, v30, v29, v9, v10);
  // pto: %projected_o__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v33 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v31, v32);
  // pto: %block_inline1499__ssa_v0
  int64_t v34 = (int64_t) v6;
  // pto: %0, %1
  int64_t v35 = (int64_t) ((uint64_t) (v34 / v11) * (uint64_t) v12);
  // pto: %2, %3
  int64_t v36 = (int64_t) ((uint64_t) (v34 % v11) * (uint64_t) v13);
  // pto: %4
  int64_t v37 = (int64_t) ((uint64_t) v4 - (uint64_t) v35);
  // pto: %5
  int64_t v38 = v37 < v12 ? v37 : v12;
  // pto: %oa_value_inline1503__ssa_v0
  Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v39 = Tile<TileType::Vec, float, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v13);
  // pto: %oa_value_inline1503__ssa_v0
  uint64_t v40 = (uint64_t) v8;
  TASSIGN(v39, v40);
  // pto: %6
  int64_t v41 = v35 < v14 ? v14 : v35;
  // pto: %7
  int64_t v42 = v36 < v14 ? v14 : v36;
  // pto: %accum_inline1531__phi_v21_pview
  const int64_t v43 = 0;
  // pto: %accum_inline1531__phi_v21_pview
  __gm__ float* v44 = PTOAS__GLOBAL_TENSOR_DATA(v24);
  // pto: %accum_inline1531__phi_v21_pview
  const int64_t v45 = 1;
  // pto: %accum_inline1531__phi_v21_pview
  const int64_t v46 = 1;
  // pto: %accum_inline1531__phi_v21_pview
  const int64_t v47 = 1;
  // pto: %accum_inline1531__phi_v21_pview
  int64_t v48 = v38 * v9;
  // pto: %accum_inline1531__phi_v21_pview
  int64_t v49 = v47 * v48;
  // pto: %accum_inline1531__phi_v21_pview
  pto::Shape<1, 1, 1, -1, 1024> v50 = pto::Shape<1, 1, 1, -1, 1024>(v45, v46, v47, v38, v13);
  // pto: %accum_inline1531__phi_v21_pview
  pto::Stride<-1, -1, -1, -1, -1> v51 = pto::Stride<-1, -1, -1, -1, -1>(v46 * v49, v49, v48, v9, v10);
  // pto: %accum_inline1531__phi_v21_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v52 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v44 + (v43 + v41 * v9 + v42 * v10), v50, v51);
  TLOAD(v39, v52);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %t__tmp_v1061
  Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v53 = Tile<TileType::Vec, bfloat16_t, 16, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v13);
  // pto: %t__tmp_v1061
  uint64_t v54 = (uint64_t) v8;
  TASSIGN(v53, v54);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  RoundMode v55 = RoundMode::CAST_RINT;
  SaturationMode v56 = SaturationMode::ON;
  TCVT(v53, v39, v55, v56);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %projected_o__ssa_v0_pview
  const int64_t v57 = 0;
  // pto: %projected_o__ssa_v0_pview
  __gm__ bfloat16_t* v58 = PTOAS__GLOBAL_TENSOR_DATA(v33);
  // pto: %projected_o__ssa_v0_pview
  const int64_t v59 = 1;
  // pto: %projected_o__ssa_v0_pview
  const int64_t v60 = 1;
  // pto: %projected_o__ssa_v0_pview
  const int64_t v61 = 1;
  // pto: %projected_o__ssa_v0_pview
  int64_t v62 = v38 * v9;
  // pto: %projected_o__ssa_v0_pview
  int64_t v63 = v61 * v62;
  // pto: %projected_o__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 1024> v64 = pto::Shape<1, 1, 1, -1, 1024>(v59, v60, v61, v38, v13);
  // pto: %projected_o__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v65 = pto::Stride<-1, -1, -1, -1, -1>(v60 * v63, v63, v62, v9, v10);
  // pto: %projected_o__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v66 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v58 + (v57 + v41 * v9 + v42 * v10), v64, v65);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v66, v53);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}