#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_score_topk_leaf_aic(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ float* v3, __gm__ int32_t* v4, __gm__ int8_t* v5, __gm__ float* v6, __gm__ float* v7, __gm__ int32_t* v8, __gm__ int8_t* v9, __gm__ int8_t* v10, __gm__ int8_t* v11, __gm__ float* v12, __gm__ float* v13, int64_t v14, int64_t v15, int64_t v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int32_t v22, int32_t v23) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v24 = 32;
  const int32_t v25 = 0;
  // pto: %c0_i64
  const int64_t v26 = 0;
  // pto: %c8192_i64
  const int64_t v27 = 8192;
  // pto: %c4096_i64
  const int64_t v28 = 4096;
  // pto: %c24576_i64
  const int64_t v29 = 24576;
  // pto: %c57344_i64
  const int64_t v30 = 57344;
  // pto: %c12288_i64
  const int64_t v31 = 12288;
  // pto: %c1_index
  const int64_t v32 = 1;
  // pto: %c8192_index
  const int64_t v33 = 8192;
  // pto: %c27648_index
  const int64_t v34 = 27648;
  // pto: %c128_index
  const int64_t v35 = 128;
  // pto: %c64_index
  const int64_t v36 = 64;
  // pto: %c0_index
  const int64_t v37 = 0;
  // pto: %c4_index
  const int64_t v38 = 4;
  // pto: %c262144_index
  const int64_t v39 = 262144;
  // pto: %c8191_index
  const int64_t v40 = 8191;
  // pto: %c24_index
  const int64_t v41 = 24;
  // pto: %c1_i64
  const int64_t v42 = 1;
  // pto: %c4_i64
  const int64_t v43 = 4;
  // pto: %c383_index
  const int64_t v44 = 383;
  // pto: %c384_index
  const int64_t v45 = 384;
  // pto: %c192_index
  const int64_t v46 = 192;
  // pto: %c4096_index
  const int64_t v47 = 4096;
  // pto: %c191_index
  const int64_t v48 = 191;
  // pto: %c6_index
  const int64_t v49 = 6;
  // pto: %c32_index
  const int64_t v50 = 32;
  // pto: %c2_index
  const int64_t v51 = 2;
  // pto: %qr_hadamard_i8_inline1363__rv_v2_view
  const int64_t v52 = 1;
  // pto: %qr_hadamard_i8_inline1363__rv_v2_view
  const int64_t v53 = 1;
  // pto: %qr_hadamard_i8_inline1363__rv_v2_view
  const int64_t v54 = 1;
  // pto: %qr_hadamard_i8_inline1363__rv_v2_view
  int64_t v55 = v34 * v35;
  // pto: %qr_hadamard_i8_inline1363__rv_v2_view
  int64_t v56 = v54 * v55;
  // pto: %qr_hadamard_i8_inline1363__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v57 = pto::Shape<1, 1, 1, -1, -1>(v52, v53, v54, v34, v35);
  // pto: %qr_hadamard_i8_inline1363__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v58 = pto::Stride<-1, -1, -1, -1, -1>(v53 * v56, v56, v55, v35, v32);
  // pto: %qr_hadamard_i8_inline1363__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v59 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v57, v58);
  // pto: %idx_kv_cache_inline2971_inline5670__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %idx_kv_cache_inline2971_inline5670__ssa_v0_view
  const int64_t v61 = 1;
  // pto: %idx_kv_cache_inline2971_inline5670__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %idx_kv_cache_inline2971_inline5670__ssa_v0_view
  int64_t v63 = (int64_t) v18;
  // pto: %idx_kv_cache_inline2971_inline5670__ssa_v0_view
  int64_t v64 = v63 * v35;
  // pto: %idx_kv_cache_inline2971_inline5670__ssa_v0_view
  int64_t v65 = v62 * v64;
  // pto: %idx_kv_cache_inline2971_inline5670__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v66 = pto::Shape<1, 1, 1, -1, -1>(v60, v61, v62, v63, v35);
  // pto: %idx_kv_cache_inline2971_inline5670__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v67 = pto::Stride<-1, -1, -1, -1, -1>(v61 * v65, v65, v64, v35, v32);
  // pto: %idx_kv_cache_inline2971_inline5670__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v68 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v66, v67);
  // pto: %idx_kv_cache_shift64_inline2986_inline5679__ssa_v0_view
  const int64_t v69 = 1;
  // pto: %idx_kv_cache_shift64_inline2986_inline5679__ssa_v0_view
  const int64_t v70 = 1;
  // pto: %idx_kv_cache_shift64_inline2986_inline5679__ssa_v0_view
  const int64_t v71 = 1;
  // pto: %idx_kv_cache_shift64_inline2986_inline5679__ssa_v0_view
  int64_t v72 = (int64_t) v19;
  // pto: %idx_kv_cache_shift64_inline2986_inline5679__ssa_v0_view
  int64_t v73 = v72 * v35;
  // pto: %idx_kv_cache_shift64_inline2986_inline5679__ssa_v0_view
  int64_t v74 = v71 * v73;
  // pto: %idx_kv_cache_shift64_inline2986_inline5679__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v75 = pto::Shape<1, 1, 1, -1, -1>(v69, v70, v71, v72, v35);
  // pto: %idx_kv_cache_shift64_inline2986_inline5679__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v76 = pto::Stride<-1, -1, -1, -1, -1>(v70 * v74, v74, v73, v35, v32);
  // pto: %idx_kv_cache_shift64_inline2986_inline5679__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v77 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v75, v76);
  // pto: %kv_i8_inline2998_inline5666__phi_v5
  Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
  // pto: %kv_i8_inline2998_inline5666__phi_v5
  uint64_t v79 = (uint64_t) v27;
  TASSIGN(v78, v79);
  // pto: %kv_i8_inline2998_inline5666__phi_v10
  Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v80 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
  // pto: %kv_i8_inline2998_inline5666__phi_v10
  uint64_t v81 = (uint64_t) v27;
  TASSIGN(v80, v81);
  // pto: %147
  Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v82 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
  // pto: %147
  uint64_t v83 = (uint64_t) v30;
  TASSIGN(v82, v83);
  // pto: %176
  Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v84 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
  // pto: %176
  uint64_t v85 = (uint64_t) v30;
  TASSIGN(v84, v85);
  // pto: %215
  Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v86 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
  // pto: %215
  uint64_t v87 = (uint64_t) v27;
  TASSIGN(v86, v87);
  // pto: %244
  Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
  // pto: %244
  uint64_t v89 = (uint64_t) v27;
  TASSIGN(v88, v89);
  const int32_t v90 = 0;
  auto v91 = TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>(v13, v25, v90);
  // pto: %worker_inline2982_inline5712__ssa_v0
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  // pto: %max_cache_len_inline2958_inline5690__rv_v2
  int64_t v92;
  v92 = v37;
  for (int64_t v93 = v37; v93 < v16; v93 += v32) {
    // pto: %t__tile
    ;
    int32_t v94 = (v2)[v93];
    // pto: %33, %34
    ;
    int64_t v95 = (int64_t) v94 / v38;
    // pto: %35
    ;
    bool v96 = v92 < v95;
    // pto: %35
    ;
    int64_t v97 = v96 ? v95 : v92;
    v92 = v97;
  }
  // pto: %36
  bool v98 = v92 < v39;
  // pto: %36
  int64_t v99 = v98 ? v92 : v39;
  // pto: %37, %38
  int64_t v100 = (int64_t) ((uint64_t) v99 + (uint64_t) v40) / v33;
  // pto: %39
  int64_t v101 = v100 < v32 ? v32 : v100;
  // pto: %40, %41
  int64_t v102 = (int64_t) (v101 == v32);
  // pto: %42
  for (int64_t v103 = (int64_t) v22; v103 < ((int64_t) ((uint64_t) v15 * (uint64_t) v101)); v103 += v41) {
    // pto: %43
    ;
    int64_t v104 = v103 / v101;
    // pto: %45
    ;
    int32_t v105 = (v4)[v104];
    // pto: %46
    ;
    int64_t v106 = (int64_t) v105;
    // pto: %position_inline3003_inline5711__tile
    ;
    int64_t v107 = (v1)[v104];
    // pto: %48
    ;
    int64_t v108 = v106 < v37 ? v37 : v106;
    // pto: %47
    ;
    int32_t v109 = (v2)[v108];
    // pto: %51, %49, %50, %cache_len_inline2956_inline5684__phi_v2
    ;
    int64_t v110 = v106 < v37 ? v37 : (int64_t) v109 / v38;
    // pto: %52, %53
    ;
    int64_t v111 = (int64_t) ((uint64_t) v107 + (uint64_t) v42) / v43;
    // pto: %55
    ;
    int64_t v112 = v110 < v111 ? v110 : v111;
    // pto: %56
    ;
    int64_t v113 = v112 < v39 ? v112 : v39;
    // pto: %57
    ;
    int64_t v114 = v113 < v37 ? v37 : v113;
    // pto: %44, %58
    ;
    int64_t v115 = (int64_t) ((uint64_t) (v103 % v101) * (uint64_t) v33);
    // pto: %59
    ;
    if (v115 < v114) {
      // pto: %60
      ;
      int64_t v116 = (int64_t) ((uint64_t) v114 - (uint64_t) v115);
      // pto: %61
      ;
      int64_t v117 = v116 < v33 ? v116 : v33;
      // pto: %62, %63, %64
      ;
      int64_t v118 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v117 + (uint64_t) v44) / v45) * (uint64_t) v46);
      // pto: %65
      ;
      int64_t v119 = v118 < v47 ? v118 : v47;
      // pto: %66, %69, %67, %68
      ;
      int64_t v120 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v102 * (uint64_t) v46) + (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v32 - (uint64_t) v102) * (uint64_t) v119));
      // pto: %70
      ;
      int64_t v121 = (int64_t) ((uint64_t) v104 * (uint64_t) v36);
      // pto: %query_vector_inline3012_inline5726__tile
      ;
      Tile<TileType::Mat, int8_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Mat, int8_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v35);
      // pto: %query_vector_inline3012_inline5726__tile
      ;
      uint64_t v123 = (uint64_t) v26;
      TASSIGN(v122, v123);
      // pto: %71
      ;
      int64_t v124 = v121 < v37 ? v37 : v121;
      // pto: %qr_hadamard_i8_inline1363__rv_v2_pview
      ;
      __gm__ int8_t* v125 = PTOAS__GLOBAL_TENSOR_DATA(v59);
      // pto: %qr_hadamard_i8_inline1363__rv_v2_pview
      ;
      const int64_t v126 = 0;
      // pto: %qr_hadamard_i8_inline1363__rv_v2_pview
      ;
      const int64_t v127 = 128;
      // pto: %qr_hadamard_i8_inline1363__rv_v2_pview
      ;
      pto::Shape<1, 1, 1, 64, 128> v128 = pto::Shape<1, 1, 1, 64, 128>();
      // pto: %qr_hadamard_i8_inline1363__rv_v2_pview
      ;
      pto::Stride<8192, 8192, 8192, 128, 1> v129 = pto::Stride<8192, 8192, 8192, 128, 1>();
      // pto: %qr_hadamard_i8_inline1363__rv_v2_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND> v130 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND>(v125 + (v126 + v124 * v127), v128, v129);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v122, v130);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %72
      ;
      int64_t v131 = (int64_t) ((uint64_t) v119 + (uint64_t) v48);
      // pto: %73
      ;
      int64_t v132 = v131 / v45;
      // pto: %74
      ;
      int64_t v133 = (int64_t) ((uint64_t) v132 * (uint64_t) v45);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
      for (int64_t v134 = v37; v134 < v133; v134 += v45) {
        // pto: %75
        ;
        int64_t v135 = (int64_t) ((uint64_t) v102 + (uint64_t) v32);
        // pto: %76
        ;
        int64_t v136 = (int64_t) ((uint64_t) v134 * (uint64_t) v135);
        // pto: %77, %79
        ;
        int64_t v137 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v134 + (uint64_t) v46) * (uint64_t) v135);
        // pto: %kv_i8_inline2998_inline5666__tile
        ;
        Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
        // pto: %kv_i8_inline2998_inline5666__tile
        ;
        uint64_t v139 = (uint64_t) v27;
        TASSIGN(v138, v139);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        for (int64_t v140 = v37; v140 < v49; v140 += v32) {
          // pto: %81
          ;
          int64_t v141 = (int64_t) ((uint64_t) v140 * (uint64_t) v50);
          // pto: %80, %82, %83
          ;
          int64_t v142 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v115 + (uint64_t) v136) + (uint64_t) v141) / v50;
          // pto: %84, %85
          ;
          int64_t v143 = (int64_t) ((uint64_t) v110 - (uint64_t) v32) / v50;
          // pto: %86
          ;
          int64_t v144 = v143 < v37 ? v37 : v143;
          // pto: %87
          ;
          int64_t v145 = v142 < v144 ? v142 : v144;
          // pto: %flat_offset_mul, %flat_offset, %88
          ;
          int32_t v146 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v17) + (uint64_t) v145)];
          // pto: %89
          ;
          int64_t v147 = (int64_t) v146;
          // pto: %90
          ;
          int64_t v148 = v147 < v37 ? v37 : v147;
          // pto: %91
          ;
          int64_t v149 = (int64_t) ((uint64_t) v148 * (uint64_t) v14);
          // pto: %92, %93
          ;
          if (v149 % v35 == v37) {
            // pto: %gather_row_view
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v150;
            // pto: %gather_row_view
            ;
            uint64_t v151 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v141 * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v150, v151);
            // pto: %95
            ;
            int64_t v152 = v149 / v35;
            // pto: %96
            ;
            int64_t v153 = v152 < v37 ? v37 : v152;
            // pto: %idx_kv_cache_inline2971_inline5670__ssa_v0_pview
            ;
            __gm__ int8_t* v154 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %idx_kv_cache_inline2971_inline5670__ssa_v0_pview
            ;
            const int64_t v155 = 0;
            // pto: %idx_kv_cache_inline2971_inline5670__ssa_v0_pview
            ;
            const int64_t v156 = 128;
            // pto: %idx_kv_cache_inline2971_inline5670__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 32, 128> v157 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %idx_kv_cache_inline2971_inline5670__ssa_v0_pview
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v158 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %idx_kv_cache_inline2971_inline5670__ssa_v0_pview
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v159 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v154 + (v155 + v153 * v156), v157, v158);
            TLOAD(v150, v159);
          } else {
            // pto: %98
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v160;
            // pto: %98
            ;
            uint64_t v161 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v141 * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v160, v161);
            // pto: %99
            ;
            int64_t v162 = v149 / v35;
            // pto: %100
            ;
            int64_t v163 = v162 < v37 ? v37 : v162;
            // pto: %idx_kv_cache_shift64_inline2986_inline5679__ssa_v0_pview
            ;
            __gm__ int8_t* v164 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %idx_kv_cache_shift64_inline2986_inline5679__ssa_v0_pview
            ;
            const int64_t v165 = 0;
            // pto: %idx_kv_cache_shift64_inline2986_inline5679__ssa_v0_pview
            ;
            const int64_t v166 = 128;
            // pto: %idx_kv_cache_shift64_inline2986_inline5679__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 32, 128> v167 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %idx_kv_cache_shift64_inline2986_inline5679__ssa_v0_pview
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v168 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %idx_kv_cache_shift64_inline2986_inline5679__ssa_v0_pview
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v169 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v164 + (v165 + v163 * v166), v167, v168);
            TLOAD(v160, v169);
          };
        };
        for (int64_t v170 = v37; v170 < v49; v170 += v32) {
          // pto: %103
          ;
          int64_t v171 = (int64_t) ((uint64_t) v170 * (uint64_t) v50);
          // pto: %101, %102, %104, %105
          ;
          int64_t v172 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v115 + (uint64_t) v136) + (uint64_t) v120) + (uint64_t) v171) / v50;
          // pto: %106, %107
          ;
          int64_t v173 = (int64_t) ((uint64_t) v110 - (uint64_t) v32) / v50;
          // pto: %108
          ;
          int64_t v174 = v173 < v37 ? v37 : v173;
          // pto: %109
          ;
          int64_t v175 = v172 < v174 ? v172 : v174;
          // pto: %111, %112, %110
          ;
          int32_t v176 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v17) + (uint64_t) v175)];
          // pto: %113
          ;
          int64_t v177 = (int64_t) v176;
          // pto: %114
          ;
          int64_t v178 = v177 < v37 ? v37 : v177;
          // pto: %115
          ;
          int64_t v179 = (int64_t) ((uint64_t) v178 * (uint64_t) v14);
          // pto: %116, %117
          ;
          if (v179 % v35 == v37) {
            // pto: %120
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v180;
            // pto: %119, %120
            ;
            uint64_t v181 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v171 + (uint64_t) v46) * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v180, v181);
            // pto: %121
            ;
            int64_t v182 = v179 / v35;
            // pto: %122
            ;
            int64_t v183 = v182 < v37 ? v37 : v182;
            // pto: %123
            ;
            __gm__ int8_t* v184 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %123
            ;
            const int64_t v185 = 0;
            // pto: %123
            ;
            const int64_t v186 = 128;
            // pto: %123
            ;
            pto::Shape<1, 1, 1, 32, 128> v187 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %123
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v188 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %123
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v189 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v184 + (v185 + v183 * v186), v187, v188);
            TLOAD(v180, v189);
          } else {
            // pto: %126
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v190;
            // pto: %125, %126
            ;
            uint64_t v191 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v171 + (uint64_t) v46) * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v190, v191);
            // pto: %127
            ;
            int64_t v192 = v179 / v35;
            // pto: %128
            ;
            int64_t v193 = v192 < v37 ? v37 : v192;
            // pto: %129
            ;
            __gm__ int8_t* v194 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %129
            ;
            const int64_t v195 = 0;
            // pto: %129
            ;
            const int64_t v196 = 128;
            // pto: %129
            ;
            pto::Shape<1, 1, 1, 32, 128> v197 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %129
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v198 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %129
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v199 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v194 + (v195 + v193 * v196), v197, v198);
            TLOAD(v190, v199);
          };
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %kv_i8_inline2998_inline5666__rv_v7_t
        ;
        Tile<TileType::Mat, int8_t, 128, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v200 = Tile<TileType::Mat, int8_t, 128, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v35, v45);
        // pto: %kv_i8_inline2998_inline5666__rv_v7_t
        ;
        uint64_t v201 = (uint64_t) v27;
        TASSIGN(v200, v201);
        // pto: %score_i32_inline2984_inline5659__tile_l0_init
        ;
        Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v202 = Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %score_i32_inline2984_inline5659__tile_l0_init
        ;
        uint64_t v203 = (uint64_t) v26;
        TASSIGN(v202, v203);
        // pto: %score_i32_inline2984_inline5659__tile_l0_a
        ;
        Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v204 = Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %score_i32_inline2984_inline5659__tile_l0_a
        ;
        uint64_t v205 = (uint64_t) v26;
        TASSIGN(v204, v205);
        uint16_t v206 = static_cast<uint16_t>(v37);
        uint16_t v207 = static_cast<uint16_t>(v37);
        TEXTRACT(v204, v122, v206, v207);
        // pto: %score_i32_inline2984_inline5659__tile_l0_b
        ;
        Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v208 = Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %score_i32_inline2984_inline5659__tile_l0_b
        ;
        uint64_t v209 = (uint64_t) v26;
        TASSIGN(v208, v209);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v210 = static_cast<uint16_t>(v37);
        uint16_t v211 = static_cast<uint16_t>(v37);
        TEXTRACT(v208, v200, v210, v211);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %4
        ;
        Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v212 = Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %4
        ;
        uint64_t v213 = (uint64_t) v28;
        TASSIGN(v212, v213);
        uint16_t v214 = static_cast<uint16_t>(v37);
        uint16_t v215 = static_cast<uint16_t>(v36);
        TEXTRACT(v212, v122, v214, v215);
        // pto: %5
        ;
        Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %5
        ;
        uint64_t v217 = (uint64_t) v29;
        TASSIGN(v216, v217);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v218 = static_cast<uint16_t>(v36);
        uint16_t v219 = static_cast<uint16_t>(v37);
        TEXTRACT(v216, v200, v218, v219);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v202, v204, v208);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v202, v202, v212, v216);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        TPUSH<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_LEFT_RIGHT>(v91, v202);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %7
        ;
        Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
        // pto: %7
        ;
        uint64_t v221 = (uint64_t) v30;
        TASSIGN(v220, v221);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        for (int64_t v222 = v37; v222 < v49; v222 += v32) {
          // pto: %132
          ;
          int64_t v223 = (int64_t) ((uint64_t) v222 * (uint64_t) v50);
          // pto: %131, %133, %134
          ;
          int64_t v224 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v115 + (uint64_t) v137) + (uint64_t) v223) / v50;
          // pto: %135, %136
          ;
          int64_t v225 = (int64_t) ((uint64_t) v110 - (uint64_t) v32) / v50;
          // pto: %137
          ;
          int64_t v226 = v225 < v37 ? v37 : v225;
          // pto: %138
          ;
          int64_t v227 = v224 < v226 ? v224 : v226;
          // pto: %140, %141, %139
          ;
          int32_t v228 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v17) + (uint64_t) v227)];
          // pto: %142
          ;
          int64_t v229 = (int64_t) v228;
          // pto: %143
          ;
          int64_t v230 = v229 < v37 ? v37 : v229;
          // pto: %144
          ;
          int64_t v231 = (int64_t) ((uint64_t) v230 * (uint64_t) v14);
          // pto: %145, %146
          ;
          if (v231 % v35 == v37) {
            // pto: %149
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v232;
            // pto: %149
            ;
            uint64_t v233 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v223 * (uint64_t) v24) + (uint64_t) v30);
            TASSIGN(v232, v233);
            // pto: %150
            ;
            int64_t v234 = v231 / v35;
            // pto: %151
            ;
            int64_t v235 = v234 < v37 ? v37 : v234;
            // pto: %152
            ;
            __gm__ int8_t* v236 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %152
            ;
            const int64_t v237 = 0;
            // pto: %152
            ;
            const int64_t v238 = 128;
            // pto: %152
            ;
            pto::Shape<1, 1, 1, 32, 128> v239 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %152
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v240 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %152
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v241 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v236 + (v237 + v235 * v238), v239, v240);
            TLOAD(v232, v241);
          } else {
            // pto: %154
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v242;
            // pto: %154
            ;
            uint64_t v243 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v223 * (uint64_t) v24) + (uint64_t) v30);
            TASSIGN(v242, v243);
            // pto: %155
            ;
            int64_t v244 = v231 / v35;
            // pto: %156
            ;
            int64_t v245 = v244 < v37 ? v37 : v244;
            // pto: %157
            ;
            __gm__ int8_t* v246 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %157
            ;
            const int64_t v247 = 0;
            // pto: %157
            ;
            const int64_t v248 = 128;
            // pto: %157
            ;
            pto::Shape<1, 1, 1, 32, 128> v249 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %157
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v250 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %157
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v251 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v246 + (v247 + v245 * v248), v249, v250);
            TLOAD(v242, v251);
          };
        };
        for (int64_t v252 = v37; v252 < v49; v252 += v32) {
          // pto: %161
          ;
          int64_t v253 = (int64_t) ((uint64_t) v252 * (uint64_t) v50);
          // pto: %159, %160, %162, %163
          ;
          int64_t v254 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v115 + (uint64_t) v137) + (uint64_t) v120) + (uint64_t) v253) / v50;
          // pto: %164, %165
          ;
          int64_t v255 = (int64_t) ((uint64_t) v110 - (uint64_t) v32) / v50;
          // pto: %166
          ;
          int64_t v256 = v255 < v37 ? v37 : v255;
          // pto: %167
          ;
          int64_t v257 = v254 < v256 ? v254 : v256;
          // pto: %169, %170, %168
          ;
          int32_t v258 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v17) + (uint64_t) v257)];
          // pto: %171
          ;
          int64_t v259 = (int64_t) v258;
          // pto: %172
          ;
          int64_t v260 = v259 < v37 ? v37 : v259;
          // pto: %173
          ;
          int64_t v261 = (int64_t) ((uint64_t) v260 * (uint64_t) v14);
          // pto: %174, %175
          ;
          if (v261 % v35 == v37) {
            // pto: %179
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v262;
            // pto: %178, %179
            ;
            uint64_t v263 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v253 + (uint64_t) v46) * (uint64_t) v24) + (uint64_t) v30);
            TASSIGN(v262, v263);
            // pto: %180
            ;
            int64_t v264 = v261 / v35;
            // pto: %181
            ;
            int64_t v265 = v264 < v37 ? v37 : v264;
            // pto: %182
            ;
            __gm__ int8_t* v266 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %182
            ;
            const int64_t v267 = 0;
            // pto: %182
            ;
            const int64_t v268 = 128;
            // pto: %182
            ;
            pto::Shape<1, 1, 1, 32, 128> v269 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %182
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v270 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %182
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v271 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v266 + (v267 + v265 * v268), v269, v270);
            TLOAD(v262, v271);
          } else {
            // pto: %185
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v272;
            // pto: %184, %185
            ;
            uint64_t v273 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v253 + (uint64_t) v46) * (uint64_t) v24) + (uint64_t) v30);
            TASSIGN(v272, v273);
            // pto: %186
            ;
            int64_t v274 = v261 / v35;
            // pto: %187
            ;
            int64_t v275 = v274 < v37 ? v37 : v274;
            // pto: %188
            ;
            __gm__ int8_t* v276 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %188
            ;
            const int64_t v277 = 0;
            // pto: %188
            ;
            const int64_t v278 = 128;
            // pto: %188
            ;
            pto::Shape<1, 1, 1, 32, 128> v279 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %188
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v280 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %188
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v281 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v276 + (v277 + v275 * v278), v279, v280);
            TLOAD(v272, v281);
          };
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        // pto: %12
        ;
        Tile<TileType::Mat, int8_t, 128, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v282 = Tile<TileType::Mat, int8_t, 128, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v35, v45);
        // pto: %12
        ;
        uint64_t v283 = (uint64_t) v30;
        TASSIGN(v282, v283);
        // pto: %13
        ;
        Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v284 = Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %13
        ;
        uint64_t v285 = (uint64_t) v26;
        TASSIGN(v284, v285);
        // pto: %14
        ;
        Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %14
        ;
        uint64_t v287 = (uint64_t) v27;
        TASSIGN(v286, v287);
        uint16_t v288 = static_cast<uint16_t>(v37);
        uint16_t v289 = static_cast<uint16_t>(v37);
        TEXTRACT(v286, v122, v288, v289);
        // pto: %15
        ;
        Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %15
        ;
        uint64_t v291 = (uint64_t) v26;
        TASSIGN(v290, v291);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v292 = static_cast<uint16_t>(v37);
        uint16_t v293 = static_cast<uint16_t>(v37);
        TEXTRACT(v290, v282, v292, v293);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %16
        ;
        Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v294 = Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %16
        ;
        uint64_t v295 = (uint64_t) v31;
        TASSIGN(v294, v295);
        uint16_t v296 = static_cast<uint16_t>(v37);
        uint16_t v297 = static_cast<uint16_t>(v36);
        TEXTRACT(v294, v122, v296, v297);
        // pto: %17
        ;
        Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %17
        ;
        uint64_t v299 = (uint64_t) v29;
        TASSIGN(v298, v299);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        uint16_t v300 = static_cast<uint16_t>(v36);
        uint16_t v301 = static_cast<uint16_t>(v37);
        TEXTRACT(v298, v282, v300, v301);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v284, v286, v290);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        TMATMUL_ACC(v284, v284, v294, v298);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TPUSH<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_LEFT_RIGHT>(v91, v284);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
      // pto: %190, %194, %193, %195
      ;
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
      if ((int64_t) ((uint64_t) (v131 / v46) - (uint64_t) ((int64_t) (uint64_t) v132 * (uint64_t) v51)) == v32) {
        // pto: %197, %196
        ;
        int64_t v302 = (int64_t) ((uint64_t) v133 * (uint64_t) ((int64_t) (uint64_t) v102 + (uint64_t) v32));
        // pto: %20
        ;
        Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v35);
        // pto: %20
        ;
        uint64_t v304 = (uint64_t) v27;
        TASSIGN(v303, v304);
        for (int64_t v305 = v37; v305 < v49; v305 += v32) {
          // pto: %200
          ;
          int64_t v306 = (int64_t) ((uint64_t) v305 * (uint64_t) v50);
          // pto: %199, %201, %202
          ;
          int64_t v307 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v115 + (uint64_t) v302) + (uint64_t) v306) / v50;
          // pto: %203, %204
          ;
          int64_t v308 = (int64_t) ((uint64_t) v110 - (uint64_t) v32) / v50;
          // pto: %205
          ;
          int64_t v309 = v308 < v37 ? v37 : v308;
          // pto: %206
          ;
          int64_t v310 = v307 < v309 ? v307 : v309;
          // pto: %208, %209, %207
          ;
          int32_t v311 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v17) + (uint64_t) v310)];
          // pto: %210
          ;
          int64_t v312 = (int64_t) v311;
          // pto: %211
          ;
          int64_t v313 = v312 < v37 ? v37 : v312;
          // pto: %212
          ;
          int64_t v314 = (int64_t) ((uint64_t) v313 * (uint64_t) v14);
          // pto: %213, %214
          ;
          if (v314 % v35 == v37) {
            // pto: %217
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v315;
            // pto: %217
            ;
            uint64_t v316 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v306 * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v315, v316);
            // pto: %218
            ;
            int64_t v317 = v314 / v35;
            // pto: %219
            ;
            int64_t v318 = v317 < v37 ? v37 : v317;
            // pto: %220
            ;
            __gm__ int8_t* v319 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %220
            ;
            const int64_t v320 = 0;
            // pto: %220
            ;
            const int64_t v321 = 128;
            // pto: %220
            ;
            pto::Shape<1, 1, 1, 32, 128> v322 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %220
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v323 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %220
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v324 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v319 + (v320 + v318 * v321), v322, v323);
            TLOAD(v315, v324);
          } else {
            // pto: %222
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v325;
            // pto: %222
            ;
            uint64_t v326 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v306 * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v325, v326);
            // pto: %223
            ;
            int64_t v327 = v314 / v35;
            // pto: %224
            ;
            int64_t v328 = v327 < v37 ? v37 : v327;
            // pto: %225
            ;
            __gm__ int8_t* v329 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %225
            ;
            const int64_t v330 = 0;
            // pto: %225
            ;
            const int64_t v331 = 128;
            // pto: %225
            ;
            pto::Shape<1, 1, 1, 32, 128> v332 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %225
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v333 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %225
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v334 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v329 + (v330 + v328 * v331), v332, v333);
            TLOAD(v325, v334);
          };
        };
        for (int64_t v335 = v37; v335 < v49; v335 += v32) {
          // pto: %229
          ;
          int64_t v336 = (int64_t) ((uint64_t) v335 * (uint64_t) v50);
          // pto: %227, %228, %230, %231
          ;
          int64_t v337 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v115 + (uint64_t) v302) + (uint64_t) v120) + (uint64_t) v336) / v50;
          // pto: %232, %233
          ;
          int64_t v338 = (int64_t) ((uint64_t) v110 - (uint64_t) v32) / v50;
          // pto: %234
          ;
          int64_t v339 = v338 < v37 ? v37 : v338;
          // pto: %235
          ;
          int64_t v340 = v337 < v339 ? v337 : v339;
          // pto: %237, %238, %236
          ;
          int32_t v341 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v17) + (uint64_t) v340)];
          // pto: %239
          ;
          int64_t v342 = (int64_t) v341;
          // pto: %240
          ;
          int64_t v343 = v342 < v37 ? v37 : v342;
          // pto: %241
          ;
          int64_t v344 = (int64_t) ((uint64_t) v343 * (uint64_t) v14);
          // pto: %242, %243
          ;
          if (v344 % v35 == v37) {
            // pto: %247
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v345;
            // pto: %246, %247
            ;
            uint64_t v346 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v336 + (uint64_t) v46) * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v345, v346);
            // pto: %248
            ;
            int64_t v347 = v344 / v35;
            // pto: %249
            ;
            int64_t v348 = v347 < v37 ? v37 : v347;
            // pto: %250
            ;
            __gm__ int8_t* v349 = PTOAS__GLOBAL_TENSOR_DATA(v68);
            // pto: %250
            ;
            const int64_t v350 = 0;
            // pto: %250
            ;
            const int64_t v351 = 128;
            // pto: %250
            ;
            pto::Shape<1, 1, 1, 32, 128> v352 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %250
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v353 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %250
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v354 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v349 + (v350 + v348 * v351), v352, v353);
            TLOAD(v345, v354);
          } else {
            // pto: %253
            ;
            Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v355;
            // pto: %252, %253
            ;
            uint64_t v356 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v336 + (uint64_t) v46) * (uint64_t) v24) + (uint64_t) v27);
            TASSIGN(v355, v356);
            // pto: %254
            ;
            int64_t v357 = v344 / v35;
            // pto: %255
            ;
            int64_t v358 = v357 < v37 ? v37 : v357;
            // pto: %256
            ;
            __gm__ int8_t* v359 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %256
            ;
            const int64_t v360 = 0;
            // pto: %256
            ;
            const int64_t v361 = 128;
            // pto: %256
            ;
            pto::Shape<1, 1, 1, 32, 128> v362 = pto::Shape<1, 1, 1, 32, 128>();
            // pto: %256
            ;
            pto::Stride<4096, 4096, 4096, 128, 1> v363 = pto::Stride<4096, 4096, 4096, 128, 1>();
            // pto: %256
            ;
            GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v364 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v359 + (v360 + v358 * v361), v362, v363);
            TLOAD(v355, v364);
          };
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
        // pto: %25
        ;
        Tile<TileType::Mat, int8_t, 128, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v365 = Tile<TileType::Mat, int8_t, 128, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v35, v45);
        // pto: %25
        ;
        uint64_t v366 = (uint64_t) v27;
        TASSIGN(v365, v366);
        // pto: %26
        ;
        Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v367 = Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %26
        ;
        uint64_t v368 = (uint64_t) v26;
        TASSIGN(v367, v368);
        // pto: %27
        ;
        Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v369 = Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %27
        ;
        uint64_t v370 = (uint64_t) v26;
        TASSIGN(v369, v370);
        uint16_t v371 = static_cast<uint16_t>(v37);
        uint16_t v372 = static_cast<uint16_t>(v37);
        TEXTRACT(v369, v122, v371, v372);
        // pto: %28
        ;
        Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v373 = Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %28
        ;
        uint64_t v374 = (uint64_t) v26;
        TASSIGN(v373, v374);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
        uint16_t v375 = static_cast<uint16_t>(v37);
        uint16_t v376 = static_cast<uint16_t>(v37);
        TEXTRACT(v373, v365, v375, v376);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        // pto: %29
        ;
        Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v377 = Tile<TileType::Left, int8_t, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v36, v36);
        // pto: %29
        ;
        uint64_t v378 = (uint64_t) v28;
        TASSIGN(v377, v378);
        uint16_t v379 = static_cast<uint16_t>(v37);
        uint16_t v380 = static_cast<uint16_t>(v36);
        TEXTRACT(v377, v122, v379, v380);
        // pto: %30
        ;
        Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v381 = Tile<TileType::Right, int8_t, 64, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v36, v45);
        // pto: %30
        ;
        uint64_t v382 = (uint64_t) v29;
        TASSIGN(v381, v382);
        uint16_t v383 = static_cast<uint16_t>(v36);
        uint16_t v384 = static_cast<uint16_t>(v37);
        TEXTRACT(v381, v365, v383, v384);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        TMATMUL(v367, v369, v373);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        TMATMUL_ACC(v367, v367, v377, v381);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        TPUSH<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, Tile<TileType::Acc, int32_t, 64, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_LEFT_RIGHT>(v91, v367);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void indexer_score_topk_leaf_aiv(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ float* v3, __gm__ int32_t* v4, __gm__ int8_t* v5, __gm__ float* v6, __gm__ float* v7, __gm__ int32_t* v8, __gm__ int8_t* v9, __gm__ int8_t* v10, __gm__ int8_t* v11, __gm__ float* v12, __gm__ float* v13, int64_t v14, int64_t v15, int64_t v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int32_t v22, int32_t v23, int32_t v24) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  pto::MrgSortExecutedNumList v25 = pto::MrgSortExecutedNumList{0, 0, 0, 0};
  // pto: %c131072_i64
  const int64_t v26 = 131072;
  // pto: %c131328_i64
  const int64_t v27 = 131328;
  // pto: %c98688_i64
  const int64_t v28 = 98688;
  // pto: %c98304_i64
  const int64_t v29 = 98304;
  // pto: %c131840_i64
  const int64_t v30 = 131840;
  // pto: %c133120_i64
  const int64_t v31 = 133120;
  const int64_t v32 = 135168;
  // pto: %c137216_i64
  const int64_t v33 = 137216;
  // pto: %c139264_i64
  const int64_t v34 = 139264;
  // pto: %c143360_i64
  const int64_t v35 = 143360;
  const int64_t v36 = 147456;
  // pto: %c155648_i64
  const int64_t v37 = 155648;
  // pto: %c141312_i64
  const int64_t v38 = 141312;
  const int64_t v39 = 151552;
  // pto: %c161792_i64
  const int64_t v40 = 161792;
  // pto: %c172032_i64
  const int64_t v41 = 172032;
  // pto: %c167936_i64
  const int64_t v42 = 167936;
  // pto: %c110592_i64
  const int64_t v43 = 110592;
  // pto: %c163840_i64
  const int64_t v44 = 163840;
  const int64_t v45 = 114688;
  // pto: %c1_index
  const int64_t v46 = 1;
  // pto: %c432_index
  const int64_t v47 = 432;
  // pto: %c8192_index
  const int64_t v48 = 8192;
  // pto: %c27648_index
  const int64_t v49 = 27648;
  // pto: %c64_index
  const int64_t v50 = 64;
  // pto: %c1024_index
  const int64_t v51 = 1024;
  // pto: %c0_i32
  const int32_t v52 = 0;
  // pto: %c0_index
  const int64_t v53 = 0;
  // pto: %c4_index
  const int64_t v54 = 4;
  // pto: %c262144_index
  const int64_t v55 = 262144;
  // pto: %c8191_index
  const int64_t v56 = 8191;
  // pto: %c24_index
  const int64_t v57 = 24;
  // pto: %c1_i64
  const int64_t v58 = 1;
  // pto: %c4_i64
  const int64_t v59 = 4;
  // pto: %c383_index
  const int64_t v60 = 383;
  // pto: %c384_index
  const int64_t v61 = 384;
  // pto: %c192_index
  const int64_t v62 = 192;
  // pto: %c4096_index
  const int64_t v63 = 4096;
  // pto: %c191_index
  const int64_t v64 = 191;
  // pto: %c2_index
  const int64_t v65 = 2;
  // pto: %c6_index
  const int64_t v66 = 6;
  // pto: %c32_index
  const int64_t v67 = 32;
  // pto: %cst_43
  const float v68 = 0.0f;
  // pto: %c512_index
  const int64_t v69 = 512;
  // pto: %cst_45
  const float v70 = -3.40282347E+38f;
  // pto: %c64_i32
  const int32_t v71 = 64;
  // pto: %c256_i32
  const int32_t v72 = 256;
  // pto: %c2048_index
  const int64_t v73 = 2048;
  // pto: %c1024_i32
  const int32_t v74 = 1024;
  // pto: %c2560_index
  const int64_t v75 = 2560;
  // pto: %c5120_index
  const int64_t v76 = 5120;
  // pto: %c3072_index
  const int64_t v77 = 3072;
  // pto: %c6144_index
  const int64_t v78 = 6144;
  // pto: %score_arena_inline2961_inline5669__ssa_v0_view
  const int64_t v79 = 1;
  // pto: %score_arena_inline2961_inline5669__ssa_v0_view
  const int64_t v80 = 1;
  // pto: %score_arena_inline2961_inline5669__ssa_v0_view
  const int64_t v81 = 1;
  // pto: %score_arena_inline2961_inline5669__ssa_v0_view
  int64_t v82 = v47 * v48;
  // pto: %score_arena_inline2961_inline5669__ssa_v0_view
  int64_t v83 = v81 * v82;
  // pto: %score_arena_inline2961_inline5669__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v84 = pto::Shape<1, 1, 1, -1, -1>(v79, v80, v81, v47, v48);
  // pto: %score_arena_inline2961_inline5669__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v85 = pto::Stride<-1, -1, -1, -1, -1>(v80 * v83, v83, v82, v48, v46);
  // pto: %score_arena_inline2961_inline5669__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v86 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v84, v85);
  // pto: %qr_hadamard_scale_dq_inline1362__rv_v2_view
  const int64_t v87 = 1;
  // pto: %qr_hadamard_scale_dq_inline1362__rv_v2_view
  const int64_t v88 = 1;
  // pto: %qr_hadamard_scale_dq_inline1362__rv_v2_view
  const int64_t v89 = 1;
  // pto: %qr_hadamard_scale_dq_inline1362__rv_v2_view
  int64_t v90 = v49 * v46;
  // pto: %qr_hadamard_scale_dq_inline1362__rv_v2_view
  int64_t v91 = v89 * v90;
  // pto: %qr_hadamard_scale_dq_inline1362__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v92 = pto::Shape<1, 1, 1, -1, -1>(v87, v88, v89, v49, v46);
  // pto: %qr_hadamard_scale_dq_inline1362__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v93 = pto::Stride<-1, -1, -1, -1, -1>(v88 * v91, v91, v90, v46, v49);
  // pto: %qr_hadamard_scale_dq_inline1362__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v94 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v6, v92, v93);
  // pto: %weights_inline5692__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %weights_inline5692__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %weights_inline5692__ssa_v0_view
  const int64_t v97 = 1;
  // pto: %weights_inline5692__ssa_v0_view
  int64_t v98 = v47 * v50;
  // pto: %weights_inline5692__ssa_v0_view
  int64_t v99 = v97 * v98;
  // pto: %weights_inline5692__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v100 = pto::Shape<1, 1, 1, -1, -1>(v95, v96, v97, v47, v50);
  // pto: %weights_inline5692__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v101 = pto::Stride<-1, -1, -1, -1, -1>(v96 * v99, v99, v98, v50, v46);
  // pto: %weights_inline5692__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v102 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v100, v101);
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v103 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v104 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v105 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v106 = (int64_t) v20;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v107 = (int64_t) v21;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v108 = v106 * v107;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v109 = v105 * v108;
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v110 = pto::Shape<1, 1, 1, -1, -1>(v103, v104, v105, v106, (int64_t) v21);
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v111 = pto::Stride<-1, -1, -1, -1, -1>(v104 * v109, v109, v108, v107, v46);
  // pto: %idx_native_kv_cache__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v112 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v11, v110, v111);
  // pto: %pair_arena_inline2969_inline5683__ssa_v0_view
  const int64_t v113 = 1;
  // pto: %pair_arena_inline2969_inline5683__ssa_v0_view
  const int64_t v114 = 1;
  // pto: %pair_arena_inline2969_inline5683__ssa_v0_view
  const int64_t v115 = 1;
  // pto: %pair_arena_inline2969_inline5683__ssa_v0_view
  int64_t v116 = v49 * v51;
  // pto: %pair_arena_inline2969_inline5683__ssa_v0_view
  int64_t v117 = v115 * v116;
  // pto: %pair_arena_inline2969_inline5683__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v118 = pto::Shape<1, 1, 1, -1, -1>(v113, v114, v115, v49, v51);
  // pto: %pair_arena_inline2969_inline5683__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v119 = pto::Stride<-1, -1, -1, -1, -1>(v114 * v117, v117, v116, v51, v46);
  // pto: %pair_arena_inline2969_inline5683__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v120 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v12, v118, v119);
  const int32_t v121 = 0;
  auto v122 = TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>(v13, v52, v121);
  // pto: %worker_inline2982_inline5712__ssa_v0
  int64_t v123 = (int64_t) v22;
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  // pto: %max_cache_len_inline2958_inline5690__rv_v2
  int64_t v124;
  v124 = v53;
  for (int64_t v125 = v53; v125 < v16; v125 += v46) {
    // pto: %26
    ;
    int32_t v126 = (v2)[v125];
    // pto: %27, %28
    ;
    int64_t v127 = (int64_t) v126 / v54;
    // pto: %29
    ;
    bool v128 = v124 < v127;
    // pto: %29
    ;
    int64_t v129 = v128 ? v127 : v124;
    v124 = v129;
  }
  // pto: %30
  bool v130 = v124 < v55;
  // pto: %30
  int64_t v131 = v130 ? v124 : v55;
  // pto: %31, %32
  int64_t v132 = (int64_t) ((uint64_t) v131 + (uint64_t) v56) / v48;
  // pto: %33
  int64_t v133 = v132 < v46 ? v46 : v132;
  // pto: %34, %35
  int64_t v134 = (int64_t) (v133 == v46);
  // pto: %36
  for (int64_t v135 = v123; v135 < ((int64_t) ((uint64_t) v15 * (uint64_t) v133)); v135 += v57) {
    // pto: %37
    ;
    int64_t v136 = v135 / v133;
    // pto: %38
    ;
    int64_t v137 = v135 % v133;
    // pto: %39
    ;
    int32_t v138 = (v4)[v136];
    // pto: %40
    ;
    int64_t v139 = (int64_t) v138;
    // pto: %position_inline3003_inline5711__tile
    ;
    int64_t v140 = (v1)[v136];
    // pto: %42
    ;
    int64_t v141 = v139 < v53 ? v53 : v139;
    // pto: %41
    ;
    int32_t v142 = (v2)[v141];
    // pto: %45, %43, %44, %cache_len_inline2956_inline5684__phi_v2
    ;
    int64_t v143 = v139 < v53 ? v53 : (int64_t) v142 / v54;
    // pto: %46, %47
    ;
    int64_t v144 = (int64_t) ((uint64_t) v140 + (uint64_t) v58) / v59;
    // pto: %49
    ;
    int64_t v145 = v143 < v144 ? v143 : v144;
    // pto: %50
    ;
    int64_t v146 = v145 < v55 ? v145 : v55;
    // pto: %51
    ;
    int64_t v147 = v146 < v53 ? v53 : v146;
    // pto: %52
    ;
    int64_t v148 = (int64_t) ((uint64_t) v137 * (uint64_t) v48);
    // pto: %53
    ;
    if (v148 < v147) {
      // pto: %54
      ;
      int64_t v149 = (int64_t) ((uint64_t) v147 - (uint64_t) v148);
      // pto: %55
      ;
      int64_t v150 = v149 < v48 ? v149 : v48;
      // pto: %56, %57, %58
      ;
      int64_t v151 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v150 + (uint64_t) v60) / v61) * (uint64_t) v62);
      // pto: %59
      ;
      int64_t v152 = v151 < v63 ? v151 : v63;
      // pto: %61
      ;
      int64_t v153 = (int64_t) ((uint64_t) v46 - (uint64_t) v134);
      // pto: %60, %63, %62
      ;
      int64_t v154 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v134 * (uint64_t) v62) + (uint64_t) ((int64_t) (uint64_t) v153 * (uint64_t) v152));
      // pto: %64
      ;
      int64_t v155 = (int64_t) ((uint64_t) v136 * (uint64_t) v50);
      // pto: %t__tile
      ;
      Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v156 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v46);
      // pto: %t__tile
      ;
      uint64_t v157 = (uint64_t) v26;
      TASSIGN(v156, v157);
      // pto: %65
      ;
      int64_t v158 = v155 < v53 ? v53 : v155;
      // pto: %qr_hadamard_scale_dq_inline1362__rv_v2_pview
      ;
      __gm__ float* v159 = PTOAS__GLOBAL_TENSOR_DATA(v94);
      // pto: %qr_hadamard_scale_dq_inline1362__rv_v2_pview
      ;
      const int64_t v160 = 0;
      // pto: %qr_hadamard_scale_dq_inline1362__rv_v2_pview
      ;
      pto::Shape<1, 1, 1, 64, 1> v161 = pto::Shape<1, 1, 1, 64, 1>();
      // pto: %qr_hadamard_scale_dq_inline1362__rv_v2_pview
      ;
      pto::Stride<64, 64, 64, 1, 27648> v162 = pto::Stride<64, 64, 64, 1, 27648>();
      // pto: %qr_hadamard_scale_dq_inline1362__rv_v2_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 64, 1>, pto::Stride<64, 64, 64, 1, 27648>, pto::Layout::DN> v163 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 1>, pto::Stride<64, 64, 64, 1, 27648>, pto::Layout::DN>(v159 + (v160 + v158), v161, v162);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      TLOAD(v156, v163);
      // pto: %query_scale_inline3004_inline5716__tile
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v164 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v50);
      // pto: %query_scale_inline3004_inline5716__tile
      ;
      uint64_t v165 = (uint64_t) v26;
      TASSIGN(v164, v165);
      // pto: %query_weight_inline3009_inline5729__tile
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v166 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v50);
      // pto: %query_weight_inline3009_inline5729__tile
      ;
      uint64_t v167 = (uint64_t) v27;
      TASSIGN(v166, v167);
      // pto: %66
      ;
      int64_t v168 = v136 < v53 ? v53 : v136;
      // pto: %weights_inline5692__ssa_v0_pview
      ;
      __gm__ float* v169 = PTOAS__GLOBAL_TENSOR_DATA(v102);
      // pto: %weights_inline5692__ssa_v0_pview
      ;
      const int64_t v170 = 0;
      // pto: %weights_inline5692__ssa_v0_pview
      ;
      const int64_t v171 = 64;
      // pto: %weights_inline5692__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 64> v172 = pto::Shape<1, 1, 1, 1, 64>();
      // pto: %weights_inline5692__ssa_v0_pview
      ;
      pto::Stride<64, 64, 64, 64, 1> v173 = pto::Stride<64, 64, 64, 64, 1>();
      // pto: %weights_inline5692__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v174 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v169 + (v170 + v168 * v171), v172, v173);
      TLOAD(v166, v174);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v50);
      // pto: %0
      ;
      uint64_t v176 = (uint64_t) v28;
      TASSIGN(v175, v176);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      TMUL(v175, v164, v166);
      // pto: %head_coefficient_inline3010_inline5699__tile
      ;
      Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v46);
      // pto: %head_coefficient_inline3010_inline5699__tile
      ;
      uint64_t v178 = (uint64_t) v28;
      TASSIGN(v177, v178);
      // pto: %67
      ;
      int64_t v179 = (int64_t) ((uint64_t) v152 + (uint64_t) v64);
      // pto: %68
      ;
      int64_t v180 = v179 / v61;
      // pto: %69
      ;
      int64_t v181 = (int64_t) ((uint64_t) v180 * (uint64_t) v61);
      for (int64_t v182 = v53; v182 < v181; v182 += v61) {
        // pto: %70
        ;
        int64_t v183 = (int64_t) ((uint64_t) v134 + (uint64_t) v46);
        // pto: %71
        ;
        int64_t v184 = (int64_t) ((uint64_t) v182 * (uint64_t) v183);
        // pto: %aiv_id_inline2952_inline5698__ssa_v0
        ;
        int64_t v185 = (int64_t) v24;
        // pto: %72
        ;
        int64_t v186 = (int64_t) ((uint64_t) v185 * (uint64_t) v154);
        // pto: %73, %74
        ;
        int64_t v187 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v150 - (uint64_t) v184) - (uint64_t) v186);
        // pto: %75
        ;
        int64_t v188 = v187 < v62 ? v187 : v62;
        // pto: %76
        ;
        int64_t v189 = v188 < v53 ? v53 : v188;
        // pto: %79, %84, %83, %81, %82
        ;
        int64_t v190 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v134 * (uint64_t) v136) + (uint64_t) ((int64_t) (uint64_t) v153 * (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v185)));
        // pto: %86, %85, %89, %88
        ;
        int64_t v191 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v134 * (uint64_t) ((int64_t) (uint64_t) v184 + (uint64_t) v186)) + (uint64_t) ((int64_t) (uint64_t) v153 * (uint64_t) v182));
        // pto: %90
        ;
        int64_t v192 = (int64_t) ((uint64_t) v182 + (uint64_t) v62);
        // pto: %92
        ;
        int64_t v193 = (int64_t) ((uint64_t) v192 * (uint64_t) v183);
        // pto: %95, %96
        ;
        int64_t v194 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v150 - (uint64_t) v193) - (uint64_t) v186);
        // pto: %97
        ;
        int64_t v195 = v194 < v62 ? v194 : v62;
        // pto: %98
        ;
        int64_t v196 = v195 < v53 ? v53 : v195;
        // pto: %108, %107, %112, %111
        ;
        int64_t v197 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v134 * (uint64_t) ((int64_t) (uint64_t) v193 + (uint64_t) v186)) + (uint64_t) ((int64_t) (uint64_t) v153 * (uint64_t) v192));
        // pto: %scale_bytes_inline2949_inline5657__tile
        ;
        Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v198 = Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v61);
        // pto: %scale_bytes_inline2949_inline5657__tile
        ;
        uint64_t v199 = (uint64_t) v29;
        TASSIGN(v198, v199);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        for (int64_t v200 = v53; v200 < v66; v200 += v46) {
          // pto: %77, %78, %113, %114
          ;
          int64_t v201 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v148 + (uint64_t) v184) + (uint64_t) v186) / v67) + (uint64_t) v200);
          // pto: %115, %116
          ;
          int64_t v202 = (int64_t) ((uint64_t) v143 - (uint64_t) v46) / v67;
          // pto: %117
          ;
          int64_t v203 = v202 < v53 ? v53 : v202;
          // pto: %118
          ;
          int64_t v204 = v201 < v203 ? v201 : v203;
          // pto: %flat_offset_mul, %flat_offset, %119
          ;
          int32_t v205 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v139 * (uint64_t) v17) + (uint64_t) v204)];
          // pto: %120
          ;
          int64_t v206 = (int64_t) v205;
          // pto: %121
          ;
          int64_t v207 = v206 < v53 ? v53 : v206;
          // pto: %gather_row_view
          ;
          Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v208;
          // pto: %122, %gather_row_view
          ;
          uint64_t v209 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v200 * (uint64_t) v50) + (uint64_t) v29);
          TASSIGN(v208, v209);
          // pto: %123
          ;
          int64_t v210 = v207 < v53 ? v53 : v207;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v211 = (int64_t) v21;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v212 = 0;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          __gm__ int8_t* v213 = PTOAS__GLOBAL_TENSOR_DATA(v112);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v214 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v215 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v216 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v217 = v46 * v211;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v218 = v216 * v217;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          pto::Shape<1, 1, 1, 1, 64> v219 = pto::Shape<1, 1, 1, 1, 64>(v214, v215, v216, v46, v50);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v220 = pto::Stride<-1, -1, -1, -1, -1>(v215 * v218, v218, v217, v211, v46);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v221 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v213 + (v212 + v210 * v211 + v63 * v46), v219, v220);
          TLOAD(v208, v221);
        };
        // pto: %kv_scale_inline2947_inline5654__tile
        ;
        Tile<TileType::Vec, half, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Vec, half, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %kv_scale_inline2947_inline5654__tile
        ;
        uint64_t v223 = (uint64_t) v29;
        TASSIGN(v222, v223);
        // pto: %score_shard_inline2946_inline5653__tile
        ;
        const int32_t v224 = 64;
        // pto: %score_shard_inline2946_inline5653__tile
        ;
        const int32_t v225 = 192;
        // pto: %score_shard_inline2946_inline5653__tile
        ;
        Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v226 = Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v224, v225);
        TPOP<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_LEFT_RIGHT>(v122, v226);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %score_fp32_inline2945_inline5652__tile
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %score_fp32_inline2945_inline5652__tile
        ;
        uint64_t v228 = (uint64_t) v26;
        TASSIGN(v227, v228);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        RoundMode v229 = RoundMode::CAST_NONE;
        SaturationMode v230 = SaturationMode::ON;
        TCVT(v227, v226, v229, v230);
        TFREE<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, TileSplitAxis::TILE_LEFT_RIGHT>(v122);
        // pto: %score_fp32_v1_inline2943_inline5665__tile
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v231 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %score_fp32_v1_inline2943_inline5665__tile
        ;
        uint64_t v232 = (uint64_t) v26;
        TASSIGN(v231, v232);
        pipe_barrier(PIPE_V);
        TMAXS(v231, v227, v68);
        // pto: %score_fp32_v2_inline2942_inline5674__tile
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %score_fp32_v2_inline2942_inline5674__tile
        ;
        uint64_t v234 = (uint64_t) v26;
        TASSIGN(v233, v234);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v233, v231, v177);
        // pto: %2
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %2
        ;
        uint64_t v236 = (uint64_t) v26;
        TASSIGN(v235, v236);
        pipe_barrier(PIPE_V);
        TCOLSUM(v235, v233);
        // pto: %score_row_inline2950_inline5651__tile
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v237 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %score_row_inline2950_inline5651__tile
        ;
        uint64_t v238 = (uint64_t) v26;
        TASSIGN(v237, v238);
        // pto: %3
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v239 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %3
        ;
        uint64_t v240 = (uint64_t) v30;
        TASSIGN(v239, v240);
        pipe_barrier(PIPE_V);
        RoundMode v241 = RoundMode::CAST_ROUND;
        SaturationMode v242 = SaturationMode::ON;
        TCVT(v239, v222, v241, v242);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        // pto: %score_row_v1_inline2941_inline5667__tile
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %score_row_v1_inline2941_inline5667__tile
        ;
        uint64_t v244 = (uint64_t) v26;
        TASSIGN(v243, v244);
        pipe_barrier(PIPE_V);
        TMUL(v243, v237, v239);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %124
        ;
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        if (v189 > v53) {
          v243.SetValidShape(v46, v189);
          // pto: %125
          ;
          int64_t v245 = v190 < v53 ? v53 : v190;
          // pto: %126
          ;
          int64_t v246 = v191 < v53 ? v53 : v191;
          // pto: %score_arena_inline2961_inline5669__iter_v3_pview
          ;
          const int64_t v247 = 0;
          // pto: %score_arena_inline2961_inline5669__iter_v3_pview
          ;
          __gm__ float* v248 = PTOAS__GLOBAL_TENSOR_DATA(v86);
          // pto: %score_arena_inline2961_inline5669__iter_v3_pview
          ;
          const int64_t v249 = 1;
          // pto: %score_arena_inline2961_inline5669__iter_v3_pview
          ;
          const int64_t v250 = 1;
          // pto: %score_arena_inline2961_inline5669__iter_v3_pview
          ;
          const int64_t v251 = 1;
          // pto: %score_arena_inline2961_inline5669__iter_v3_pview
          ;
          int64_t v252 = v46 * v48;
          // pto: %score_arena_inline2961_inline5669__iter_v3_pview
          ;
          int64_t v253 = v251 * v252;
          // pto: %score_arena_inline2961_inline5669__iter_v3_pview
          ;
          pto::Shape<1, 1, 1, 1, -1> v254 = pto::Shape<1, 1, 1, 1, -1>(v249, v250, v251, v46, v189);
          // pto: %score_arena_inline2961_inline5669__iter_v3_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v255 = pto::Stride<-1, -1, -1, -1, -1>(v250 * v253, v253, v252, v48, v46);
          // pto: %score_arena_inline2961_inline5669__iter_v3_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v256 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v248 + (v247 + v245 * v48 + v246 * v46), v254, v255);
          TSTORE(v256, v243);
        };
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        // pto: %4
        ;
        Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v257 = Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v61);
        // pto: %4
        ;
        uint64_t v258 = (uint64_t) v29;
        TASSIGN(v257, v258);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        for (int64_t v259 = v53; v259 < v66; v259 += v46) {
          // pto: %99, %100, %128, %129
          ;
          int64_t v260 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v148 + (uint64_t) v193) + (uint64_t) v186) / v67) + (uint64_t) v259);
          // pto: %130, %131
          ;
          int64_t v261 = (int64_t) ((uint64_t) v143 - (uint64_t) v46) / v67;
          // pto: %132
          ;
          int64_t v262 = v261 < v53 ? v53 : v261;
          // pto: %133
          ;
          int64_t v263 = v260 < v262 ? v260 : v262;
          // pto: %135, %136, %134
          ;
          int32_t v264 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v139 * (uint64_t) v17) + (uint64_t) v263)];
          // pto: %137
          ;
          int64_t v265 = (int64_t) v264;
          // pto: %138
          ;
          int64_t v266 = v265 < v53 ? v53 : v265;
          // pto: %140
          ;
          Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v267;
          // pto: %139, %140
          ;
          uint64_t v268 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v259 * (uint64_t) v50) + (uint64_t) v29);
          TASSIGN(v267, v268);
          // pto: %141
          ;
          int64_t v269 = v266 < v53 ? v53 : v266;
          // pto: %142
          ;
          int64_t v270 = (int64_t) v21;
          // pto: %142
          ;
          const int64_t v271 = 0;
          // pto: %142
          ;
          __gm__ int8_t* v272 = PTOAS__GLOBAL_TENSOR_DATA(v112);
          // pto: %142
          ;
          const int64_t v273 = 1;
          // pto: %142
          ;
          const int64_t v274 = 1;
          // pto: %142
          ;
          const int64_t v275 = 1;
          // pto: %142
          ;
          int64_t v276 = v46 * v270;
          // pto: %142
          ;
          int64_t v277 = v275 * v276;
          // pto: %142
          ;
          pto::Shape<1, 1, 1, 1, 64> v278 = pto::Shape<1, 1, 1, 1, 64>(v273, v274, v275, v46, v50);
          // pto: %142
          ;
          pto::Stride<-1, -1, -1, -1, -1> v279 = pto::Stride<-1, -1, -1, -1, -1>(v274 * v277, v277, v276, v270, v46);
          // pto: %142
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v280 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v272 + (v271 + v269 * v270 + v63 * v46), v278, v279);
          TLOAD(v267, v280);
        };
        // pto: %6
        ;
        Tile<TileType::Vec, half, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Vec, half, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %6
        ;
        uint64_t v282 = (uint64_t) v29;
        TASSIGN(v281, v282);
        // pto: %143
        ;
        const int32_t v283 = 64;
        // pto: %143
        ;
        const int32_t v284 = 192;
        // pto: %143
        ;
        Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v283, v284);
        TPOP<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_LEFT_RIGHT>(v122, v285);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %7
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %7
        ;
        uint64_t v287 = (uint64_t) v26;
        TASSIGN(v286, v287);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        pipe_barrier(PIPE_V);
        RoundMode v288 = RoundMode::CAST_NONE;
        SaturationMode v289 = SaturationMode::ON;
        TCVT(v286, v285, v288, v289);
        TFREE<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, TileSplitAxis::TILE_LEFT_RIGHT>(v122);
        // pto: %8
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %8
        ;
        uint64_t v291 = (uint64_t) v26;
        TASSIGN(v290, v291);
        pipe_barrier(PIPE_V);
        TMAXS(v290, v286, v68);
        // pto: %9
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v292 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %9
        ;
        uint64_t v293 = (uint64_t) v26;
        TASSIGN(v292, v293);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v292, v290, v177);
        // pto: %10
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v294 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %10
        ;
        uint64_t v295 = (uint64_t) v26;
        TASSIGN(v294, v295);
        pipe_barrier(PIPE_V);
        TCOLSUM(v294, v292);
        // pto: %11
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %11
        ;
        uint64_t v297 = (uint64_t) v26;
        TASSIGN(v296, v297);
        // pto: %12
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %12
        ;
        uint64_t v299 = (uint64_t) v30;
        TASSIGN(v298, v299);
        pipe_barrier(PIPE_V);
        RoundMode v300 = RoundMode::CAST_ROUND;
        SaturationMode v301 = SaturationMode::ON;
        TCVT(v298, v281, v300, v301);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        // pto: %13
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v302 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %13
        ;
        uint64_t v303 = (uint64_t) v26;
        TASSIGN(v302, v303);
        pipe_barrier(PIPE_V);
        TMUL(v302, v296, v298);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        // pto: %144
        ;
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        if (v196 > v53) {
          v302.SetValidShape(v46, v196);
          // pto: %146
          ;
          int64_t v304 = v190 < v53 ? v53 : v190;
          // pto: %147
          ;
          int64_t v305 = v197 < v53 ? v53 : v197;
          // pto: %score_arena_inline2961_inline5669__phi_v6_pview
          ;
          const int64_t v306 = 0;
          // pto: %score_arena_inline2961_inline5669__phi_v6_pview
          ;
          __gm__ float* v307 = PTOAS__GLOBAL_TENSOR_DATA(v86);
          // pto: %score_arena_inline2961_inline5669__phi_v6_pview
          ;
          const int64_t v308 = 1;
          // pto: %score_arena_inline2961_inline5669__phi_v6_pview
          ;
          const int64_t v309 = 1;
          // pto: %score_arena_inline2961_inline5669__phi_v6_pview
          ;
          const int64_t v310 = 1;
          // pto: %score_arena_inline2961_inline5669__phi_v6_pview
          ;
          int64_t v311 = v46 * v48;
          // pto: %score_arena_inline2961_inline5669__phi_v6_pview
          ;
          int64_t v312 = v310 * v311;
          // pto: %score_arena_inline2961_inline5669__phi_v6_pview
          ;
          pto::Shape<1, 1, 1, 1, -1> v313 = pto::Shape<1, 1, 1, 1, -1>(v308, v309, v310, v46, v196);
          // pto: %score_arena_inline2961_inline5669__phi_v6_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v314 = pto::Stride<-1, -1, -1, -1, -1>(v309 * v312, v312, v311, v48, v46);
          // pto: %score_arena_inline2961_inline5669__phi_v6_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v315 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v307 + (v306 + v304 * v48 + v305 * v46), v313, v314);
          TSTORE(v315, v302);
        };
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      };
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
      // pto: %149, %153, %152, %154
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
      if ((int64_t) ((uint64_t) (v179 / v62) - (uint64_t) ((int64_t) (uint64_t) v180 * (uint64_t) v65)) == v46) {
        // pto: %156, %155
        ;
        int64_t v316 = (int64_t) ((uint64_t) v181 * (uint64_t) ((int64_t) (uint64_t) v134 + (uint64_t) v46));
        // pto: %157
        ;
        int64_t v317 = (int64_t) v24;
        // pto: %158
        ;
        int64_t v318 = (int64_t) ((uint64_t) v317 * (uint64_t) v154);
        // pto: %159, %160
        ;
        int64_t v319 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v150 - (uint64_t) v316) - (uint64_t) v318);
        // pto: %161
        ;
        int64_t v320 = v319 < v62 ? v319 : v62;
        // pto: %162
        ;
        int64_t v321 = v320 < v53 ? v53 : v320;
        // pto: %15
        ;
        Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v322 = Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v61);
        // pto: %15
        ;
        uint64_t v323 = (uint64_t) v29;
        TASSIGN(v322, v323);
        for (int64_t v324 = v53; v324 < v66; v324 += v46) {
          // pto: %163, %164, %166, %167
          ;
          int64_t v325 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v148 + (uint64_t) v316) + (uint64_t) v318) / v67) + (uint64_t) v324);
          // pto: %168, %169
          ;
          int64_t v326 = (int64_t) ((uint64_t) v143 - (uint64_t) v46) / v67;
          // pto: %170
          ;
          int64_t v327 = v326 < v53 ? v53 : v326;
          // pto: %171
          ;
          int64_t v328 = v325 < v327 ? v325 : v327;
          // pto: %173, %174, %172
          ;
          int32_t v329 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v139 * (uint64_t) v17) + (uint64_t) v328)];
          // pto: %175
          ;
          int64_t v330 = (int64_t) v329;
          // pto: %176
          ;
          int64_t v331 = v330 < v53 ? v53 : v330;
          // pto: %178
          ;
          Tile<TileType::Vec, int8_t, 1, 384, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v332;
          // pto: %177, %178
          ;
          uint64_t v333 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v324 * (uint64_t) v50) + (uint64_t) v29);
          TASSIGN(v332, v333);
          // pto: %179
          ;
          int64_t v334 = v331 < v53 ? v53 : v331;
          // pto: %180
          ;
          int64_t v335 = (int64_t) v21;
          // pto: %180
          ;
          const int64_t v336 = 0;
          // pto: %180
          ;
          __gm__ int8_t* v337 = PTOAS__GLOBAL_TENSOR_DATA(v112);
          // pto: %180
          ;
          const int64_t v338 = 1;
          // pto: %180
          ;
          const int64_t v339 = 1;
          // pto: %180
          ;
          const int64_t v340 = 1;
          // pto: %180
          ;
          int64_t v341 = v46 * v335;
          // pto: %180
          ;
          int64_t v342 = v340 * v341;
          // pto: %180
          ;
          pto::Shape<1, 1, 1, 1, 64> v343 = pto::Shape<1, 1, 1, 1, 64>(v338, v339, v340, v46, v50);
          // pto: %180
          ;
          pto::Stride<-1, -1, -1, -1, -1> v344 = pto::Stride<-1, -1, -1, -1, -1>(v339 * v342, v342, v341, v335, v46);
          // pto: %180
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v345 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v337 + (v336 + v334 * v335 + v63 * v46), v343, v344);
          TLOAD(v332, v345);
        };
        // pto: %17
        ;
        Tile<TileType::Vec, half, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v346 = Tile<TileType::Vec, half, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %17
        ;
        uint64_t v347 = (uint64_t) v29;
        TASSIGN(v346, v347);
        // pto: %181
        ;
        const int32_t v348 = 64;
        // pto: %181
        ;
        const int32_t v349 = 192;
        // pto: %181
        ;
        Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v350 = Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v348, v349);
        TPOP<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, Tile<TileType::Vec, int32_t, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, TileSplitAxis::TILE_LEFT_RIGHT>(v122, v350);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %18
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v351 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %18
        ;
        uint64_t v352 = (uint64_t) v26;
        TASSIGN(v351, v352);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        pipe_barrier(PIPE_V);
        RoundMode v353 = RoundMode::CAST_NONE;
        SaturationMode v354 = SaturationMode::ON;
        TCVT(v351, v350, v353, v354);
        TFREE<TPipe<0, Direction::DIR_C2V, 98304, 1, 1, false>, TileSplitAxis::TILE_LEFT_RIGHT>(v122);
        // pto: %19
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v355 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %19
        ;
        uint64_t v356 = (uint64_t) v26;
        TASSIGN(v355, v356);
        pipe_barrier(PIPE_V);
        TMAXS(v355, v351, v68);
        // pto: %20
        ;
        Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v357 = Tile<TileType::Vec, float, 64, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v50, v62);
        // pto: %20
        ;
        uint64_t v358 = (uint64_t) v26;
        TASSIGN(v357, v358);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v357, v355, v177);
        // pto: %21
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v359 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %21
        ;
        uint64_t v360 = (uint64_t) v26;
        TASSIGN(v359, v360);
        pipe_barrier(PIPE_V);
        TCOLSUM(v359, v357);
        // pto: %22
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v361 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %22
        ;
        uint64_t v362 = (uint64_t) v26;
        TASSIGN(v361, v362);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v363 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %23
        ;
        uint64_t v364 = (uint64_t) v30;
        TASSIGN(v363, v364);
        pipe_barrier(PIPE_V);
        RoundMode v365 = RoundMode::CAST_ROUND;
        SaturationMode v366 = SaturationMode::ON;
        TCVT(v363, v346, v365, v366);
        // pto: %24
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v367 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %24
        ;
        uint64_t v368 = (uint64_t) v26;
        TASSIGN(v367, v368);
        pipe_barrier(PIPE_V);
        TMUL(v367, v361, v363);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        // pto: %182, %187, %186, %184, %185
        ;
        int64_t v369 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v134 * (uint64_t) v136) + (uint64_t) ((int64_t) (uint64_t) v153 * (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v317)));
        // pto: %189, %188, %192, %191
        ;
        int64_t v370 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v134 * (uint64_t) ((int64_t) (uint64_t) v316 + (uint64_t) v318)) + (uint64_t) ((int64_t) (uint64_t) v153 * (uint64_t) v181));
        // pto: %193
        ;
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        if (v321 > v53) {
          v367.SetValidShape(v46, v321);
          // pto: %195
          ;
          int64_t v371 = v369 < v53 ? v53 : v369;
          // pto: %196
          ;
          int64_t v372 = v370 < v53 ? v53 : v370;
          // pto: %score_arena_inline2961_inline5669__rv_v4_main_pview
          ;
          const int64_t v373 = 0;
          // pto: %score_arena_inline2961_inline5669__rv_v4_main_pview
          ;
          __gm__ float* v374 = PTOAS__GLOBAL_TENSOR_DATA(v86);
          // pto: %score_arena_inline2961_inline5669__rv_v4_main_pview
          ;
          const int64_t v375 = 1;
          // pto: %score_arena_inline2961_inline5669__rv_v4_main_pview
          ;
          const int64_t v376 = 1;
          // pto: %score_arena_inline2961_inline5669__rv_v4_main_pview
          ;
          const int64_t v377 = 1;
          // pto: %score_arena_inline2961_inline5669__rv_v4_main_pview
          ;
          int64_t v378 = v46 * v48;
          // pto: %score_arena_inline2961_inline5669__rv_v4_main_pview
          ;
          int64_t v379 = v377 * v378;
          // pto: %score_arena_inline2961_inline5669__rv_v4_main_pview
          ;
          pto::Shape<1, 1, 1, 1, -1> v380 = pto::Shape<1, 1, 1, 1, -1>(v375, v376, v377, v46, v321);
          // pto: %score_arena_inline2961_inline5669__rv_v4_main_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v381 = pto::Stride<-1, -1, -1, -1, -1>(v376 * v379, v379, v378, v48, v46);
          // pto: %score_arena_inline2961_inline5669__rv_v4_main_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v382 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v374 + (v373 + v371 * v48 + v372 * v46), v380, v381);
          TSTORE(v382, v367);
        };
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      // pto: %197
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      if (v134 == v53) {
        // pto: %sort_lane_inline2938_inline5648__ssa_v0
        ;
        int64_t v383 = (int64_t) v24;
        // pto: %198
        ;
        int64_t v384 = (int64_t) ((uint64_t) v383 * (uint64_t) v152);
        // pto: %201
        ;
        int64_t v385 = (int64_t) ((uint64_t) v150 - (uint64_t) v384);
        // pto: %202
        ;
        int64_t v386 = v385 < v152 ? v385 : v152;
        // pto: %203
        ;
        int64_t v387 = v386 < v53 ? v53 : v386;
        // pto: %206, %205, %207
        ;
        int64_t v388 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v155 + (uint64_t) ((int64_t) (uint64_t) v137 * (uint64_t) v65)) + (uint64_t) v383);
        // pto: %208
        ;
        if (v387 > v53) {
          // pto: %199, %209
          ;
          int32_t v389 = (int32_t) ((int64_t) (uint64_t) v148 + (uint64_t) v384);
          // pto: %210
          ;
          if (v387 <= v69) {
            // pto: %t__ci_tmp_v0
            ;
            Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v390 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
            // pto: %t__ci_tmp_v0
            ;
            uint64_t v391 = (uint64_t) v31;
            TASSIGN(v390, v391);
            // pto: %t__tmp_v934
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v392 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v69);
            // pto: %t__tmp_v934
            ;
            uint64_t v393 = (uint64_t) v26;
            TASSIGN(v392, v393);
            // pto: %ci_tmp_view
            ;
            Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v394;
            TRESHAPE(v394, v390);
            // pto: %ci_dst_view
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v395;
            TRESHAPE(v395, v392);
            pipe_barrier(PIPE_V);
            TCI<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v395, v52, v394);
            // pto: %short_indices_inline9796__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v396 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v69);
            // pto: %short_indices_inline9796__ssa_v0
            ;
            uint64_t v397 = (uint64_t) v32;
            TASSIGN(v396, v397);
            pipe_barrier(PIPE_V);
            TADDS(v396, v392, v389);
            set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
            // pto: %short_raw_inline9759__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v398 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v387);
            // pto: %short_raw_inline9759__ssa_v0
            ;
            uint64_t v399 = (uint64_t) v26;
            TASSIGN(v398, v399);
            // pto: %211, %212
            ;
            int64_t v400 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v383);
            // pto: %213
            ;
            int64_t v401 = v400 < v53 ? v53 : v400;
            // pto: %score_arena_inline2961_inline5669__rv_v4_pview
            ;
            const int64_t v402 = 0;
            // pto: %score_arena_inline2961_inline5669__rv_v4_pview
            ;
            __gm__ float* v403 = PTOAS__GLOBAL_TENSOR_DATA(v86);
            // pto: %score_arena_inline2961_inline5669__rv_v4_pview
            ;
            const int64_t v404 = 1;
            // pto: %score_arena_inline2961_inline5669__rv_v4_pview
            ;
            const int64_t v405 = 1;
            // pto: %score_arena_inline2961_inline5669__rv_v4_pview
            ;
            const int64_t v406 = 1;
            // pto: %score_arena_inline2961_inline5669__rv_v4_pview
            ;
            int64_t v407 = v46 * v48;
            // pto: %score_arena_inline2961_inline5669__rv_v4_pview
            ;
            int64_t v408 = v406 * v407;
            // pto: %score_arena_inline2961_inline5669__rv_v4_pview
            ;
            pto::Shape<1, 1, 1, 1, -1> v409 = pto::Shape<1, 1, 1, 1, -1>(v404, v405, v406, v46, v387);
            // pto: %score_arena_inline2961_inline5669__rv_v4_pview
            ;
            pto::Stride<-1, -1, -1, -1, -1> v410 = pto::Stride<-1, -1, -1, -1, -1>(v405 * v408, v408, v407, v48, v46);
            // pto: %score_arena_inline2961_inline5669__rv_v4_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v411 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v403 + (v402 + v401 * v48 + v53 * v46), v409, v410);
            wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
            TLOAD(v398, v411);
            set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
            // pto: %short_scores_inline9760__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v412 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v69);
            // pto: %short_scores_inline9760__ssa_v0
            ;
            uint64_t v413 = (uint64_t) v26;
            TASSIGN(v412, v413);
            wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
            TFILLPAD<pto::TFillPadMode::InPlace>(v412, v398);
            // pto: %short_scores_v1_inline9762__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v414 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v69);
            // pto: %short_scores_v1_inline9762__ssa_v0
            ;
            uint64_t v415 = (uint64_t) v33;
            TASSIGN(v414, v415);
            pipe_barrier(PIPE_V);
            TMAXS(v414, v412, v70);
            // pto: %t__tmp_v935
            ;
            Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v416 = Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v69);
            // pto: %t__tmp_v935
            ;
            uint64_t v417 = (uint64_t) v32;
            TASSIGN(v416, v417);
            // pto: %short_pairs_inline9794__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v418 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
            // pto: %short_pairs_inline9794__ssa_v0
            ;
            uint64_t v419 = (uint64_t) v26;
            TASSIGN(v418, v419);
            // pto: %sort32_src_view
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v420;
            TRESHAPE(v420, v414);
            // pto: %sort32_idx_view
            ;
            Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v421;
            TRESHAPE(v421, v416);
            // pto: %sort32_dst_view
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v422;
            TRESHAPE(v422, v418);
            pipe_barrier(PIPE_V);
            TSORT32(v422, v420, v421);
            // pto: %short_pairs_v1_inline9754__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v423 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
            // pto: %short_pairs_v1_inline9754__ssa_v0
            ;
            uint64_t v424 = (uint64_t) v32;
            TASSIGN(v423, v424);
            pipe_barrier(PIPE_V);
            TMRGSORT(v423, v418, v71);
            // pto: %short_pairs_v2_inline9747__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v425 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
            // pto: %short_pairs_v2_inline9747__ssa_v0
            ;
            uint64_t v426 = (uint64_t) v26;
            TASSIGN(v425, v426);
            pipe_barrier(PIPE_V);
            TMRGSORT(v425, v423, v72);
            set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
            // pto: %214
            ;
            int64_t v427 = v388 < v53 ? v53 : v388;
            // pto: %pair_arena_inline2969_inline5683__ssa_v0_pview
            ;
            __gm__ float* v428 = PTOAS__GLOBAL_TENSOR_DATA(v120);
            // pto: %pair_arena_inline2969_inline5683__ssa_v0_pview
            ;
            const int64_t v429 = 0;
            // pto: %pair_arena_inline2969_inline5683__ssa_v0_pview
            ;
            const int64_t v430 = 1024;
            // pto: %pair_arena_inline2969_inline5683__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 1, 1024> v431 = pto::Shape<1, 1, 1, 1, 1024>();
            // pto: %pair_arena_inline2969_inline5683__ssa_v0_pview
            ;
            pto::Stride<1024, 1024, 1024, 1024, 1> v432 = pto::Stride<1024, 1024, 1024, 1024, 1>();
            // pto: %pair_arena_inline2969_inline5683__ssa_v0_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v433 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v428 + (v429 + v427 * v430), v431, v432);
            wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
            pipe_barrier(PIPE_MTE3);
            TSTORE(v433, v425);
          } else {
            // pto: %215
            ;
            if (v387 <= v51) {
              // pto: %t__ci_tmp_v1
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v434 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
              // pto: %t__ci_tmp_v1
              ;
              uint64_t v435 = (uint64_t) v32;
              TASSIGN(v434, v435);
              // pto: %t__tmp_v936
              ;
              Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v436 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v51);
              // pto: %t__tmp_v936
              ;
              uint64_t v437 = (uint64_t) v26;
              TASSIGN(v436, v437);
              // pto: %216
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v438;
              TRESHAPE(v438, v434);
              // pto: %217
              ;
              Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v439;
              TRESHAPE(v439, v436);
              pipe_barrier(PIPE_V);
              TCI<Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v439, v52, v438);
              // pto: %small_indices_inline9753__ssa_v0
              ;
              Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v440 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v51);
              // pto: %small_indices_inline9753__ssa_v0
              ;
              uint64_t v441 = (uint64_t) v34;
              TASSIGN(v440, v441);
              pipe_barrier(PIPE_V);
              TADDS(v440, v436, v389);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
              // pto: %small_raw_inline9779__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v442 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v387);
              // pto: %small_raw_inline9779__ssa_v0
              ;
              uint64_t v443 = (uint64_t) v26;
              TASSIGN(v442, v443);
              // pto: %218, %219
              ;
              int64_t v444 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v383);
              // pto: %220
              ;
              int64_t v445 = v444 < v53 ? v53 : v444;
              // pto: %221
              ;
              const int64_t v446 = 0;
              // pto: %221
              ;
              __gm__ float* v447 = PTOAS__GLOBAL_TENSOR_DATA(v86);
              // pto: %221
              ;
              const int64_t v448 = 1;
              // pto: %221
              ;
              const int64_t v449 = 1;
              // pto: %221
              ;
              const int64_t v450 = 1;
              // pto: %221
              ;
              int64_t v451 = v46 * v48;
              // pto: %221
              ;
              int64_t v452 = v450 * v451;
              // pto: %221
              ;
              pto::Shape<1, 1, 1, 1, -1> v453 = pto::Shape<1, 1, 1, 1, -1>(v448, v449, v450, v46, v387);
              // pto: %221
              ;
              pto::Stride<-1, -1, -1, -1, -1> v454 = pto::Stride<-1, -1, -1, -1, -1>(v449 * v452, v452, v451, v48, v46);
              // pto: %221
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v455 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v447 + (v446 + v445 * v48 + v53 * v46), v453, v454);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
              TLOAD(v442, v455);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
              // pto: %small_scores_inline9772__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v456 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
              // pto: %small_scores_inline9772__ssa_v0
              ;
              uint64_t v457 = (uint64_t) v26;
              TASSIGN(v456, v457);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
              TFILLPAD<pto::TFillPadMode::InPlace>(v456, v442);
              // pto: %small_scores_v1_inline9755__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v458 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
              // pto: %small_scores_v1_inline9755__ssa_v0
              ;
              uint64_t v459 = (uint64_t) v35;
              TASSIGN(v458, v459);
              pipe_barrier(PIPE_V);
              TMAXS(v458, v456, v70);
              // pto: %t__tmp_v937
              ;
              Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v460 = Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v51);
              // pto: %t__tmp_v937
              ;
              uint64_t v461 = (uint64_t) v34;
              TASSIGN(v460, v461);
              // pto: %small_pairs_inline9784__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v462 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
              // pto: %small_pairs_inline9784__ssa_v0
              ;
              uint64_t v463 = (uint64_t) v26;
              TASSIGN(v462, v463);
              // pto: %222
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v464;
              TRESHAPE(v464, v458);
              // pto: %223
              ;
              Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v465;
              TRESHAPE(v465, v460);
              // pto: %224
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v466;
              TRESHAPE(v466, v462);
              pipe_barrier(PIPE_V);
              TSORT32(v466, v464, v465);
              // pto: %small_pairs_v1_inline9791__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v467 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
              // pto: %small_pairs_v1_inline9791__ssa_v0
              ;
              uint64_t v468 = (uint64_t) v34;
              TASSIGN(v467, v468);
              pipe_barrier(PIPE_V);
              TMRGSORT(v467, v462, v71);
              // pto: %small_pairs_v2_inline9749__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v469 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
              // pto: %small_pairs_v2_inline9749__ssa_v0
              ;
              uint64_t v470 = (uint64_t) v26;
              TASSIGN(v469, v470);
              pipe_barrier(PIPE_V);
              TMRGSORT(v469, v467, v72);
              // pto: %small_left_inline9770__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v471 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
              // pto: %small_left_inline9770__ssa_v0
              ;
              uint64_t v472 = (uint64_t) v26;
              TASSIGN(v471, v472);
              // pto: %slice_view
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v473;
              // pto: %slice_view
              ;
              uint64_t v474 = (uint64_t) v26;
              TASSIGN(v473, v474);
              // pto: %small_right_inline9752__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v475 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
              // pto: %small_right_inline9752__ssa_v0
              ;
              uint64_t v476 = (uint64_t) v32;
              TASSIGN(v475, v476);
              // pto: %225
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v477;
              // pto: %225
              ;
              uint64_t v478 = (uint64_t) v32;
              TASSIGN(v477, v478);
              // pto: %small_tmp_inline9748__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v479 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v73);
              // pto: %small_tmp_inline9748__ssa_v0
              ;
              uint64_t v480 = (uint64_t) v34;
              TASSIGN(v479, v480);
              // pto: %small_merged_inline9782__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v481 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
              // pto: %small_merged_inline9782__ssa_v0
              ;
              uint64_t v482 = (uint64_t) v36;
              TASSIGN(v481, v482);
              pipe_barrier(PIPE_V);
              TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v481, v25, v479, v473, v477);
              set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
              // pto: %small_top_inline9745__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v483 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
              // pto: %small_top_inline9745__ssa_v0
              ;
              uint64_t v484 = (uint64_t) v36;
              TASSIGN(v483, v484);
              // pto: %226
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v485;
              // pto: %226
              ;
              uint64_t v486 = (uint64_t) v36;
              TASSIGN(v485, v486);
              // pto: %227
              ;
              int64_t v487 = v388 < v53 ? v53 : v388;
              // pto: %228
              ;
              __gm__ float* v488 = PTOAS__GLOBAL_TENSOR_DATA(v120);
              // pto: %228
              ;
              const int64_t v489 = 0;
              // pto: %228
              ;
              const int64_t v490 = 1024;
              // pto: %228
              ;
              pto::Shape<1, 1, 1, 1, 1024> v491 = pto::Shape<1, 1, 1, 1, 1024>();
              // pto: %228
              ;
              pto::Stride<1024, 1024, 1024, 1024, 1> v492 = pto::Stride<1024, 1024, 1024, 1024, 1>();
              // pto: %228
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v493 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v488 + (v489 + v487 * v490), v491, v492);
              wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
              pipe_barrier(PIPE_MTE3);
              TSTORE(v493, v485);
            } else {
              // pto: %229
              ;
              if (v387 <= v73) {
                // pto: %t__ci_tmp_v2
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v494 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
                // pto: %t__ci_tmp_v2
                ;
                uint64_t v495 = (uint64_t) v34;
                TASSIGN(v494, v495);
                // pto: %t__tmp_v938
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v496 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v73);
                // pto: %t__tmp_v938
                ;
                uint64_t v497 = (uint64_t) v26;
                TASSIGN(v496, v497);
                // pto: %230
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v498;
                TRESHAPE(v498, v494);
                // pto: %231
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v499;
                TRESHAPE(v499, v496);
                pipe_barrier(PIPE_V);
                TCI<Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v499, v52, v498);
                // pto: %leaf_indices_inline9744__ssa_v0
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v500 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v73);
                // pto: %leaf_indices_inline9744__ssa_v0
                ;
                uint64_t v501 = (uint64_t) v36;
                TASSIGN(v500, v501);
                pipe_barrier(PIPE_V);
                TADDS(v500, v496, v389);
                set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
                // pto: %leaf_scores_raw_inline9769__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v502 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v387);
                // pto: %leaf_scores_raw_inline9769__ssa_v0
                ;
                uint64_t v503 = (uint64_t) v26;
                TASSIGN(v502, v503);
                // pto: %232, %233
                ;
                int64_t v504 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v383);
                // pto: %234
                ;
                int64_t v505 = v504 < v53 ? v53 : v504;
                // pto: %235
                ;
                const int64_t v506 = 0;
                // pto: %235
                ;
                __gm__ float* v507 = PTOAS__GLOBAL_TENSOR_DATA(v86);
                // pto: %235
                ;
                const int64_t v508 = 1;
                // pto: %235
                ;
                const int64_t v509 = 1;
                // pto: %235
                ;
                const int64_t v510 = 1;
                // pto: %235
                ;
                int64_t v511 = v46 * v48;
                // pto: %235
                ;
                int64_t v512 = v510 * v511;
                // pto: %235
                ;
                pto::Shape<1, 1, 1, 1, -1> v513 = pto::Shape<1, 1, 1, 1, -1>(v508, v509, v510, v46, v387);
                // pto: %235
                ;
                pto::Stride<-1, -1, -1, -1, -1> v514 = pto::Stride<-1, -1, -1, -1, -1>(v509 * v512, v512, v511, v48, v46);
                // pto: %235
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v515 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v507 + (v506 + v505 * v48 + v53 * v46), v513, v514);
                wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
                TLOAD(v502, v515);
                set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
                // pto: %leaf_scores_inline9776__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v516 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
                // pto: %leaf_scores_inline9776__ssa_v0
                ;
                uint64_t v517 = (uint64_t) v26;
                TASSIGN(v516, v517);
                wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
                TFILLPAD<pto::TFillPadMode::InPlace>(v516, v502);
                // pto: %leaf_scores_v1_inline9743__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v518 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
                // pto: %leaf_scores_v1_inline9743__ssa_v0
                ;
                uint64_t v519 = (uint64_t) v37;
                TASSIGN(v518, v519);
                pipe_barrier(PIPE_V);
                TMAXS(v518, v516, v70);
                // pto: %t__tmp_v939
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v520 = Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v73);
                // pto: %t__tmp_v939
                ;
                uint64_t v521 = (uint64_t) v36;
                TASSIGN(v520, v521);
                // pto: %pairs_inline9751__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v522 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v63);
                // pto: %pairs_inline9751__ssa_v0
                ;
                uint64_t v523 = (uint64_t) v26;
                TASSIGN(v522, v523);
                // pto: %236
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v524;
                TRESHAPE(v524, v518);
                // pto: %237
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v525;
                TRESHAPE(v525, v520);
                // pto: %238
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v526;
                TRESHAPE(v526, v522);
                pipe_barrier(PIPE_V);
                TSORT32(v526, v524, v525);
                // pto: %pairs_v1_inline9775__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v527 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v63);
                // pto: %pairs_v1_inline9775__ssa_v0
                ;
                uint64_t v528 = (uint64_t) v36;
                TASSIGN(v527, v528);
                pipe_barrier(PIPE_V);
                TMRGSORT(v527, v522, v71);
                // pto: %pairs_v2_inline9773__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v529 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v63);
                // pto: %pairs_v2_inline9773__ssa_v0
                ;
                uint64_t v530 = (uint64_t) v26;
                TASSIGN(v529, v530);
                pipe_barrier(PIPE_V);
                TMRGSORT(v529, v527, v72);
                // pto: %pairs_v3_inline9765__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v531 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v63);
                // pto: %pairs_v3_inline9765__ssa_v0
                ;
                uint64_t v532 = (uint64_t) v36;
                TASSIGN(v531, v532);
                pipe_barrier(PIPE_V);
                TMRGSORT(v531, v529, v74);
                set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
                // pto: %t__tmp_v940
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v533 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                // pto: %t__tmp_v940
                ;
                uint64_t v534 = (uint64_t) v36;
                TASSIGN(v533, v534);
                // pto: %239
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v535;
                // pto: %239
                ;
                uint64_t v536 = (uint64_t) v36;
                TASSIGN(v535, v536);
                // pto: %240
                ;
                int64_t v537 = v388 < v53 ? v53 : v388;
                // pto: %241
                ;
                __gm__ float* v538 = PTOAS__GLOBAL_TENSOR_DATA(v120);
                // pto: %241
                ;
                const int64_t v539 = 0;
                // pto: %241
                ;
                const int64_t v540 = 1024;
                // pto: %241
                ;
                pto::Shape<1, 1, 1, 1, 1024> v541 = pto::Shape<1, 1, 1, 1, 1024>();
                // pto: %241
                ;
                pto::Stride<1024, 1024, 1024, 1024, 1> v542 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                // pto: %241
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v543 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v538 + (v539 + v537 * v540), v541, v542);
                wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
                pipe_barrier(PIPE_MTE3);
                TSTORE(v543, v535);
              } else {
                // pto: %242
                ;
                if (v387 <= v75) {
                  // pto: %t__ci_tmp_v3
                  ;
                  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v544 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
                  // pto: %t__ci_tmp_v3
                  ;
                  uint64_t v545 = (uint64_t) v38;
                  TASSIGN(v544, v545);
                  // pto: %t__tmp_v941
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v546 = Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v75);
                  // pto: %t__tmp_v941
                  ;
                  uint64_t v547 = (uint64_t) v26;
                  TASSIGN(v546, v547);
                  // pto: %243
                  ;
                  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v548;
                  TRESHAPE(v548, v544);
                  // pto: %244
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v549;
                  TRESHAPE(v549, v546);
                  pipe_barrier(PIPE_V);
                  TCI<Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v549, v52, v548);
                  // pto: %partial_indices_inline9781__ssa_v0
                  ;
                  Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v550 = Tile<TileType::Vec, int32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v75);
                  // pto: %partial_indices_inline9781__ssa_v0
                  ;
                  uint64_t v551 = (uint64_t) v39;
                  TASSIGN(v550, v551);
                  pipe_barrier(PIPE_V);
                  TADDS(v550, v546, v389);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
                  // pto: %partial_raw_inline9786__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v552 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v387);
                  // pto: %partial_raw_inline9786__ssa_v0
                  ;
                  uint64_t v553 = (uint64_t) v26;
                  TASSIGN(v552, v553);
                  // pto: %245, %246
                  ;
                  int64_t v554 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v383);
                  // pto: %247
                  ;
                  int64_t v555 = v554 < v53 ? v53 : v554;
                  // pto: %248
                  ;
                  const int64_t v556 = 0;
                  // pto: %248
                  ;
                  __gm__ float* v557 = PTOAS__GLOBAL_TENSOR_DATA(v86);
                  // pto: %248
                  ;
                  const int64_t v558 = 1;
                  // pto: %248
                  ;
                  const int64_t v559 = 1;
                  // pto: %248
                  ;
                  const int64_t v560 = 1;
                  // pto: %248
                  ;
                  int64_t v561 = v46 * v48;
                  // pto: %248
                  ;
                  int64_t v562 = v560 * v561;
                  // pto: %248
                  ;
                  pto::Shape<1, 1, 1, 1, -1> v563 = pto::Shape<1, 1, 1, 1, -1>(v558, v559, v560, v46, v387);
                  // pto: %248
                  ;
                  pto::Stride<-1, -1, -1, -1, -1> v564 = pto::Stride<-1, -1, -1, -1, -1>(v559 * v562, v562, v561, v48, v46);
                  // pto: %248
                  ;
                  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v565 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v557 + (v556 + v555 * v48 + v53 * v46), v563, v564);
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
                  TLOAD(v552, v565);
                  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
                  // pto: %partial_scores_inline9768__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v566 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v75);
                  // pto: %partial_scores_inline9768__ssa_v0
                  ;
                  uint64_t v567 = (uint64_t) v26;
                  TASSIGN(v566, v567);
                  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
                  TFILLPAD<pto::TFillPadMode::InPlace>(v566, v552);
                  // pto: %partial_scores_v1_inline9788__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v568 = Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v75);
                  // pto: %partial_scores_v1_inline9788__ssa_v0
                  ;
                  uint64_t v569 = (uint64_t) v40;
                  TASSIGN(v568, v569);
                  pipe_barrier(PIPE_V);
                  TMAXS(v568, v566, v70);
                  // pto: %t__tmp_v942
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v570 = Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v75);
                  // pto: %t__tmp_v942
                  ;
                  uint64_t v571 = (uint64_t) v39;
                  TASSIGN(v570, v571);
                  // pto: %partial_pairs_inline9777__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v572 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v76);
                  // pto: %partial_pairs_inline9777__ssa_v0
                  ;
                  uint64_t v573 = (uint64_t) v26;
                  TASSIGN(v572, v573);
                  // pto: %249
                  ;
                  Tile<TileType::Vec, float, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v574;
                  TRESHAPE(v574, v568);
                  // pto: %250
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 2560, BLayout::RowMajor, 1, 2560, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v575;
                  TRESHAPE(v575, v570);
                  // pto: %251
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 5120, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v576;
                  TRESHAPE(v576, v572);
                  pipe_barrier(PIPE_V);
                  TSORT32(v576, v574, v575);
                  // pto: %partial_pairs_v1_inline9790__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v577 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v76);
                  // pto: %partial_pairs_v1_inline9790__ssa_v0
                  ;
                  uint64_t v578 = (uint64_t) v39;
                  TASSIGN(v577, v578);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v577, v572, v71);
                  // pto: %partial_pairs_v2_inline9793__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v579 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v76);
                  // pto: %partial_pairs_v2_inline9793__ssa_v0
                  ;
                  uint64_t v580 = (uint64_t) v26;
                  TASSIGN(v579, v580);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v579, v577, v72);
                  v579.SetValidShape(v46, v63);
                  // pto: %partial_prefix_v1_inline9795__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v581 = Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v76);
                  // pto: %partial_prefix_v1_inline9795__ssa_v0
                  ;
                  uint64_t v582 = (uint64_t) v39;
                  TASSIGN(v581, v582);
                  pipe_barrier(PIPE_V);
                  TMRGSORT(v581, v579, v74);
                  // pto: %partial_left_inline9797__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v583 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                  // pto: %partial_left_inline9797__ssa_v0
                  ;
                  uint64_t v584 = (uint64_t) v39;
                  TASSIGN(v583, v584);
                  // pto: %252
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v585;
                  // pto: %252
                  ;
                  uint64_t v586 = (uint64_t) v39;
                  TASSIGN(v585, v586);
                  // pto: %partial_right_inline9787__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v587 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                  // pto: %partial_right_inline9787__ssa_v0
                  ;
                  uint64_t v588 = (uint64_t) v36;
                  TASSIGN(v587, v588);
                  // pto: %253
                  ;
                  Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v589;
                  // pto: %253
                  ;
                  uint64_t v590 = (uint64_t) v36;
                  TASSIGN(v589, v590);
                  // pto: %partial_tmp_inline9766__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v591 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v73);
                  // pto: %partial_tmp_inline9766__ssa_v0
                  ;
                  uint64_t v592 = (uint64_t) v41;
                  TASSIGN(v591, v592);
                  // pto: %partial_merged_inline9774__ssa_v0
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v593 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
                  // pto: %partial_merged_inline9774__ssa_v0
                  ;
                  uint64_t v594 = (uint64_t) v29;
                  TASSIGN(v593, v594);
                  pipe_barrier(PIPE_V);
                  TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 5120, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v593, v25, v591, v589, v585);
                  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
                  // pto: %t__tmp_v943
                  ;
                  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v595 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                  // pto: %t__tmp_v943
                  ;
                  uint64_t v596 = (uint64_t) v29;
                  TASSIGN(v595, v596);
                  // pto: %255
                  ;
                  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v597;
                  // pto: %255
                  ;
                  uint64_t v598 = (uint64_t) v29;
                  TASSIGN(v597, v598);
                  // pto: %256
                  ;
                  int64_t v599 = v388 < v53 ? v53 : v388;
                  // pto: %257
                  ;
                  __gm__ float* v600 = PTOAS__GLOBAL_TENSOR_DATA(v120);
                  // pto: %257
                  ;
                  const int64_t v601 = 0;
                  // pto: %257
                  ;
                  const int64_t v602 = 1024;
                  // pto: %257
                  ;
                  pto::Shape<1, 1, 1, 1, 1024> v603 = pto::Shape<1, 1, 1, 1, 1024>();
                  // pto: %257
                  ;
                  pto::Stride<1024, 1024, 1024, 1024, 1> v604 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                  // pto: %257
                  ;
                  GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v605 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v600 + (v601 + v599 * v602), v603, v604);
                  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
                  pipe_barrier(PIPE_MTE3);
                  TSTORE(v605, v597);
                } else {
                  // pto: %258
                  ;
                  if (v387 <= v77) {
                    // pto: %t__ci_tmp_v4
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v606 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
                    // pto: %t__ci_tmp_v4
                    ;
                    uint64_t v607 = (uint64_t) v35;
                    TASSIGN(v606, v607);
                    // pto: %t__tmp_v944
                    ;
                    Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v608 = Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v77);
                    // pto: %t__tmp_v944
                    ;
                    uint64_t v609 = (uint64_t) v26;
                    TASSIGN(v608, v609);
                    // pto: %259
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v610;
                    TRESHAPE(v610, v606);
                    // pto: %260
                    ;
                    Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v611;
                    TRESHAPE(v611, v608);
                    pipe_barrier(PIPE_V);
                    TCI<Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v611, v52, v610);
                    // pto: %triple_indices_inline9798__ssa_v0
                    ;
                    Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v612 = Tile<TileType::Vec, int32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v77);
                    // pto: %triple_indices_inline9798__ssa_v0
                    ;
                    uint64_t v613 = (uint64_t) v37;
                    TASSIGN(v612, v613);
                    pipe_barrier(PIPE_V);
                    TADDS(v612, v608, v389);
                    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                    // pto: %triple_raw_inline9758__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v614 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v387);
                    // pto: %triple_raw_inline9758__ssa_v0
                    ;
                    uint64_t v615 = (uint64_t) v26;
                    TASSIGN(v614, v615);
                    // pto: %261, %262
                    ;
                    int64_t v616 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v383);
                    // pto: %263
                    ;
                    int64_t v617 = v616 < v53 ? v53 : v616;
                    // pto: %264
                    ;
                    const int64_t v618 = 0;
                    // pto: %264
                    ;
                    __gm__ float* v619 = PTOAS__GLOBAL_TENSOR_DATA(v86);
                    // pto: %264
                    ;
                    const int64_t v620 = 1;
                    // pto: %264
                    ;
                    const int64_t v621 = 1;
                    // pto: %264
                    ;
                    const int64_t v622 = 1;
                    // pto: %264
                    ;
                    int64_t v623 = v46 * v48;
                    // pto: %264
                    ;
                    int64_t v624 = v622 * v623;
                    // pto: %264
                    ;
                    pto::Shape<1, 1, 1, 1, -1> v625 = pto::Shape<1, 1, 1, 1, -1>(v620, v621, v622, v46, v387);
                    // pto: %264
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v626 = pto::Stride<-1, -1, -1, -1, -1>(v621 * v624, v624, v623, v48, v46);
                    // pto: %264
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v627 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v619 + (v618 + v617 * v48 + v53 * v46), v625, v626);
                    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v614, v627);
                    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                    // pto: %triple_scores_inline9801__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v628 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v77);
                    // pto: %triple_scores_inline9801__ssa_v0
                    ;
                    uint64_t v629 = (uint64_t) v26;
                    TASSIGN(v628, v629);
                    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                    TFILLPAD<pto::TFillPadMode::InPlace>(v628, v614);
                    // pto: %triple_scores_v1_inline9757__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v630 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v77);
                    // pto: %triple_scores_v1_inline9757__ssa_v0
                    ;
                    uint64_t v631 = (uint64_t) v42;
                    TASSIGN(v630, v631);
                    pipe_barrier(PIPE_V);
                    TMAXS(v630, v628, v70);
                    // pto: %t__tmp_v945
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v632 = Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v77);
                    // pto: %t__tmp_v945
                    ;
                    uint64_t v633 = (uint64_t) v37;
                    TASSIGN(v632, v633);
                    // pto: %triple_pairs_inline9785__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v634 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v78);
                    // pto: %triple_pairs_inline9785__ssa_v0
                    ;
                    uint64_t v635 = (uint64_t) v26;
                    TASSIGN(v634, v635);
                    // pto: %265
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v636;
                    TRESHAPE(v636, v630);
                    // pto: %266
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 3072, BLayout::RowMajor, 1, 3072, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v637;
                    TRESHAPE(v637, v632);
                    // pto: %267
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 6144, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v638;
                    TRESHAPE(v638, v634);
                    pipe_barrier(PIPE_V);
                    TSORT32(v638, v636, v637);
                    // pto: %triple_pairs_v1_inline9750__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v639 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v78);
                    // pto: %triple_pairs_v1_inline9750__ssa_v0
                    ;
                    uint64_t v640 = (uint64_t) v37;
                    TASSIGN(v639, v640);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v639, v634, v71);
                    // pto: %triple_pairs_v2_inline9800__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v641 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v78);
                    // pto: %triple_pairs_v2_inline9800__ssa_v0
                    ;
                    uint64_t v642 = (uint64_t) v26;
                    TASSIGN(v641, v642);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v641, v639, v72);
                    v641.SetValidShape(v46, v63);
                    // pto: %triple_prefix_v1_inline9756__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v643 = Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v78);
                    // pto: %triple_prefix_v1_inline9756__ssa_v0
                    ;
                    uint64_t v644 = (uint64_t) v37;
                    TASSIGN(v643, v644);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v643, v641, v74);
                    // pto: %triple_left_inline9799__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v645 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %triple_left_inline9799__ssa_v0
                    ;
                    uint64_t v646 = (uint64_t) v37;
                    TASSIGN(v645, v646);
                    // pto: %268
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v647;
                    // pto: %268
                    ;
                    uint64_t v648 = (uint64_t) v37;
                    TASSIGN(v647, v648);
                    // pto: %triple_right0_inline9767__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v649 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %triple_right0_inline9767__ssa_v0
                    ;
                    uint64_t v650 = (uint64_t) v36;
                    TASSIGN(v649, v650);
                    // pto: %269
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v651;
                    // pto: %269
                    ;
                    uint64_t v652 = (uint64_t) v36;
                    TASSIGN(v651, v652);
                    // pto: %triple_right1_inline9761__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v653 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %triple_right1_inline9761__ssa_v0
                    ;
                    uint64_t v654 = (uint64_t) v39;
                    TASSIGN(v653, v654);
                    // pto: %270
                    ;
                    Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v655;
                    // pto: %270
                    ;
                    uint64_t v656 = (uint64_t) v39;
                    TASSIGN(v655, v656);
                    // pto: %triple_tmp_inline9764__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v657 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v77);
                    // pto: %triple_tmp_inline9764__ssa_v0
                    ;
                    uint64_t v658 = (uint64_t) v29;
                    TASSIGN(v657, v658);
                    // pto: %triple_merged_inline9803__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v659 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v77);
                    // pto: %triple_merged_inline9803__ssa_v0
                    ;
                    uint64_t v660 = (uint64_t) v43;
                    TASSIGN(v659, v660);
                    pipe_barrier(PIPE_V);
                    TMRGSORT<Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 6144, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v659, v25, v657, v651, v655, v647);
                    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
                    // pto: %t__tmp_v946
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v661 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %t__tmp_v946
                    ;
                    uint64_t v662 = (uint64_t) v43;
                    TASSIGN(v661, v662);
                    // pto: %272
                    ;
                    Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v663;
                    // pto: %272
                    ;
                    uint64_t v664 = (uint64_t) v43;
                    TASSIGN(v663, v664);
                    // pto: %273
                    ;
                    int64_t v665 = v388 < v53 ? v53 : v388;
                    // pto: %274
                    ;
                    __gm__ float* v666 = PTOAS__GLOBAL_TENSOR_DATA(v120);
                    // pto: %274
                    ;
                    const int64_t v667 = 0;
                    // pto: %274
                    ;
                    const int64_t v668 = 1024;
                    // pto: %274
                    ;
                    pto::Shape<1, 1, 1, 1, 1024> v669 = pto::Shape<1, 1, 1, 1, 1024>();
                    // pto: %274
                    ;
                    pto::Stride<1024, 1024, 1024, 1024, 1> v670 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                    // pto: %274
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v671 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v666 + (v667 + v665 * v668), v669, v670);
                    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
                    TSTORE(v671, v663);
                  } else {
                    // pto: %t__ci_tmp_v5
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v672 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v62);
                    // pto: %t__ci_tmp_v5
                    ;
                    uint64_t v673 = (uint64_t) v36;
                    TASSIGN(v672, v673);
                    // pto: %t__tmp_v947
                    ;
                    Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v674 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v63);
                    // pto: %t__tmp_v947
                    ;
                    uint64_t v675 = (uint64_t) v26;
                    TASSIGN(v674, v675);
                    // pto: %275
                    ;
                    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v676;
                    TRESHAPE(v676, v672);
                    // pto: %276
                    ;
                    Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v677;
                    TRESHAPE(v677, v674);
                    pipe_barrier(PIPE_V);
                    TCI<Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v677, v52, v676);
                    // pto: %medium_indices_inline9804__ssa_v0
                    ;
                    Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v678 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v63);
                    // pto: %medium_indices_inline9804__ssa_v0
                    ;
                    uint64_t v679 = (uint64_t) v44;
                    TASSIGN(v678, v679);
                    pipe_barrier(PIPE_V);
                    TADDS(v678, v674, v389);
                    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                    // pto: %medium_scores_raw_inline9771__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v680 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v387);
                    // pto: %medium_scores_raw_inline9771__ssa_v0
                    ;
                    uint64_t v681 = (uint64_t) v26;
                    TASSIGN(v680, v681);
                    // pto: %277, %278
                    ;
                    int64_t v682 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v65) + (uint64_t) v383);
                    // pto: %279
                    ;
                    int64_t v683 = v682 < v53 ? v53 : v682;
                    // pto: %280
                    ;
                    const int64_t v684 = 0;
                    // pto: %280
                    ;
                    __gm__ float* v685 = PTOAS__GLOBAL_TENSOR_DATA(v86);
                    // pto: %280
                    ;
                    const int64_t v686 = 1;
                    // pto: %280
                    ;
                    const int64_t v687 = 1;
                    // pto: %280
                    ;
                    const int64_t v688 = 1;
                    // pto: %280
                    ;
                    int64_t v689 = v46 * v48;
                    // pto: %280
                    ;
                    int64_t v690 = v688 * v689;
                    // pto: %280
                    ;
                    pto::Shape<1, 1, 1, 1, -1> v691 = pto::Shape<1, 1, 1, 1, -1>(v686, v687, v688, v46, v387);
                    // pto: %280
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v692 = pto::Stride<-1, -1, -1, -1, -1>(v687 * v690, v690, v689, v48, v46);
                    // pto: %280
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v693 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v685 + (v684 + v683 * v48 + v53 * v46), v691, v692);
                    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                    TLOAD(v680, v693);
                    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                    // pto: %medium_scores_inline9802__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v694 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v63);
                    // pto: %medium_scores_inline9802__ssa_v0
                    ;
                    uint64_t v695 = (uint64_t) v26;
                    TASSIGN(v694, v695);
                    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
                    TFILLPAD<pto::TFillPadMode::InPlace>(v694, v680);
                    // pto: %medium_scores_v1_inline9789__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v696 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v63);
                    // pto: %medium_scores_v1_inline9789__ssa_v0
                    ;
                    uint64_t v697 = (uint64_t) v29;
                    TASSIGN(v696, v697);
                    pipe_barrier(PIPE_V);
                    TMAXS(v696, v694, v70);
                    // pto: %t__tmp_v948
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v698 = Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v63);
                    // pto: %t__tmp_v948
                    ;
                    uint64_t v699 = (uint64_t) v44;
                    TASSIGN(v698, v699);
                    // pto: %medium_pairs_inline9746__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v700 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v48);
                    // pto: %medium_pairs_inline9746__ssa_v0
                    ;
                    uint64_t v701 = (uint64_t) v26;
                    TASSIGN(v700, v701);
                    // pto: %281
                    ;
                    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v702;
                    TRESHAPE(v702, v696);
                    // pto: %282
                    ;
                    Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v703;
                    TRESHAPE(v703, v698);
                    // pto: %283
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 8192, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v704;
                    TRESHAPE(v704, v700);
                    pipe_barrier(PIPE_V);
                    TSORT32(v704, v702, v703);
                    // pto: %medium_pairs_v1_inline9742__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v705 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v48);
                    // pto: %medium_pairs_v1_inline9742__ssa_v0
                    ;
                    uint64_t v706 = (uint64_t) v29;
                    TASSIGN(v705, v706);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v705, v700, v71);
                    // pto: %medium_pairs_v2_inline9741__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v707 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v48);
                    // pto: %medium_pairs_v2_inline9741__ssa_v0
                    ;
                    uint64_t v708 = (uint64_t) v26;
                    TASSIGN(v707, v708);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v707, v705, v72);
                    // pto: %medium_pairs_v3_inline9739__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v709 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v48);
                    // pto: %medium_pairs_v3_inline9739__ssa_v0
                    ;
                    uint64_t v710 = (uint64_t) v29;
                    TASSIGN(v709, v710);
                    pipe_barrier(PIPE_V);
                    TMRGSORT(v709, v707, v74);
                    // pto: %medium_left_inline9780__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v711 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %medium_left_inline9780__ssa_v0
                    ;
                    uint64_t v712 = (uint64_t) v29;
                    TASSIGN(v711, v712);
                    // pto: %284
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v713;
                    // pto: %284
                    ;
                    uint64_t v714 = (uint64_t) v29;
                    TASSIGN(v713, v714);
                    // pto: %medium_right_inline9740__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v715 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %medium_right_inline9740__ssa_v0
                    ;
                    uint64_t v716 = (uint64_t) v45;
                    TASSIGN(v715, v716);
                    // pto: %285
                    ;
                    Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v717;
                    // pto: %285
                    ;
                    uint64_t v718 = (uint64_t) v45;
                    TASSIGN(v717, v718);
                    // pto: %medium_tmp_inline9763__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v719 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v73);
                    // pto: %medium_tmp_inline9763__ssa_v0
                    ;
                    uint64_t v720 = (uint64_t) v26;
                    TASSIGN(v719, v720);
                    // pto: %medium_merged_inline9738__ssa_v0
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v721 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v73);
                    // pto: %medium_merged_inline9738__ssa_v0
                    ;
                    uint64_t v722 = (uint64_t) v34;
                    TASSIGN(v721, v722);
                    pipe_barrier(PIPE_V);
                    TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v721, v25, v719, v717, v713);
                    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                    // pto: %t__tmp_v949
                    ;
                    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v723 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v46, v51);
                    // pto: %t__tmp_v949
                    ;
                    uint64_t v724 = (uint64_t) v34;
                    TASSIGN(v723, v724);
                    // pto: %287
                    ;
                    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v725;
                    // pto: %287
                    ;
                    uint64_t v726 = (uint64_t) v34;
                    TASSIGN(v725, v726);
                    // pto: %288
                    ;
                    int64_t v727 = v388 < v53 ? v53 : v388;
                    // pto: %289
                    ;
                    __gm__ float* v728 = PTOAS__GLOBAL_TENSOR_DATA(v120);
                    // pto: %289
                    ;
                    const int64_t v729 = 0;
                    // pto: %289
                    ;
                    const int64_t v730 = 1024;
                    // pto: %289
                    ;
                    pto::Shape<1, 1, 1, 1, 1024> v731 = pto::Shape<1, 1, 1, 1, 1024>();
                    // pto: %289
                    ;
                    pto::Stride<1024, 1024, 1024, 1024, 1> v732 = pto::Stride<1024, 1024, 1024, 1024, 1>();
                    // pto: %289
                    ;
                    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v733 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v728 + (v729 + v727 * v730), v731, v732);
                    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
                    TSTORE(v733, v725);
                  };
                };
              };
            };
          };
        } else {
          // pto: %empty_pairs_inline2934_inline5644__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v734 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v46, v51);
          // pto: %empty_pairs_inline2934_inline5644__ssa_v0
          ;
          uint64_t v735 = (uint64_t) v26;
          TASSIGN(v734, v735);
          pipe_barrier(PIPE_V);
          TEXPANDS(v734, v70);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
          // pto: %290
          ;
          int64_t v736 = v388 < v53 ? v53 : v388;
          // pto: %291
          ;
          __gm__ float* v737 = PTOAS__GLOBAL_TENSOR_DATA(v120);
          // pto: %291
          ;
          const int64_t v738 = 0;
          // pto: %291
          ;
          const int64_t v739 = 1024;
          // pto: %291
          ;
          pto::Shape<1, 1, 1, 1, 1024> v740 = pto::Shape<1, 1, 1, 1, 1024>();
          // pto: %291
          ;
          pto::Stride<1024, 1024, 1024, 1024, 1> v741 = pto::Stride<1024, 1024, 1024, 1024, 1>();
          // pto: %291
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v742 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v737 + (v738 + v736 * v739), v740, v741);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
          pipe_barrier(PIPE_MTE3);
          TSTORE(v742, v734);
        };
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}