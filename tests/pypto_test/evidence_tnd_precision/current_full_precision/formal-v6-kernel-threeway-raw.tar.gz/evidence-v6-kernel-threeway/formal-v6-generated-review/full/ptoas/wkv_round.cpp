#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void wkv_round(__gm__ float* v1, __gm__ bfloat16_t* v2, int64_t v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v8 = 0;
  // pto: %c512_index
  const int64_t v9 = 512;
  // pto: %c1_index
  const int64_t v10 = 1;
  // pto: %c16_index
  const int64_t v11 = 16;
  // pto: %c0_index
  const int64_t v12 = 0;
  // pto: %c63_index
  const int64_t v13 = 63;
  // pto: %5
  int64_t v14 = (int64_t) ((uint64_t) v4 + (uint64_t) v13);
  // pto: %accum_inline1275__phi_v7_view
  const int64_t v15 = 1;
  // pto: %accum_inline1275__phi_v7_view
  const int64_t v16 = 1;
  // pto: %accum_inline1275__phi_v7_view
  const int64_t v17 = 1;
  // pto: %accum_inline1275__phi_v7_view
  int64_t v18 = v14 * v9;
  // pto: %accum_inline1275__phi_v7_view
  int64_t v19 = v17 * v18;
  // pto: %accum_inline1275__phi_v7_view
  pto::Shape<1, 1, 1, -1, -1> v20 = pto::Shape<1, 1, 1, -1, -1>(v15, v16, v17, v14, v9);
  // pto: %accum_inline1275__phi_v7_view
  pto::Stride<-1, -1, -1, -1, -1> v21 = pto::Stride<-1, -1, -1, -1, -1>(v16 * v19, v19, v18, v9, v10);
  // pto: %accum_inline1275__phi_v7_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v22 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v20, v21);
  // pto: %projected_kv__ssa_v0_view
  const int64_t v23 = 1;
  // pto: %projected_kv__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %projected_kv__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %projected_kv__ssa_v0_view
  int64_t v26 = (int64_t) v5;
  // pto: %projected_kv__ssa_v0_view
  int64_t v27 = v26 * v9;
  // pto: %projected_kv__ssa_v0_view
  int64_t v28 = v25 * v27;
  // pto: %projected_kv__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v29 = pto::Shape<1, 1, 1, -1, -1>(v23, v24, v25, v26, v9);
  // pto: %projected_kv__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v30 = pto::Stride<-1, -1, -1, -1, -1>(v24 * v28, v28, v27, v9, v10);
  // pto: %projected_kv__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v31 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v29, v30);
  // pto: %block_inline1247__ssa_v0, %0
  int64_t v32 = (int64_t) ((uint64_t) ((int64_t) v6) * (uint64_t) v11);
  // pto: %1
  int64_t v33 = (int64_t) ((uint64_t) v4 - (uint64_t) v32);
  // pto: %2
  int64_t v34 = v33 < v11 ? v33 : v11;
  // pto: %projected_inline1254__ssa_v0
  Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v35 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v9);
  // pto: %projected_inline1254__ssa_v0
  uint64_t v36 = (uint64_t) v8;
  TASSIGN(v35, v36);
  // pto: %3
  int64_t v37 = v32 < v12 ? v12 : v32;
  // pto: %accum_inline1275__phi_v7_pview
  const int64_t v38 = 0;
  // pto: %accum_inline1275__phi_v7_pview
  __gm__ float* v39 = PTOAS__GLOBAL_TENSOR_DATA(v22);
  // pto: %accum_inline1275__phi_v7_pview
  const int64_t v40 = 1;
  // pto: %accum_inline1275__phi_v7_pview
  const int64_t v41 = 1;
  // pto: %accum_inline1275__phi_v7_pview
  const int64_t v42 = 1;
  // pto: %accum_inline1275__phi_v7_pview
  int64_t v43 = v34 * v9;
  // pto: %accum_inline1275__phi_v7_pview
  int64_t v44 = v42 * v43;
  // pto: %accum_inline1275__phi_v7_pview
  pto::Shape<1, 1, 1, -1, 512> v45 = pto::Shape<1, 1, 1, -1, 512>(v40, v41, v42, v34, v9);
  // pto: %accum_inline1275__phi_v7_pview
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v41 * v44, v44, v43, v9, v10);
  // pto: %accum_inline1275__phi_v7_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v47 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v39 + (v38 + v37 * v9 + v12 * v10), v45, v46);
  TLOAD(v35, v47);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %rounded_inline1286__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v48 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v9);
  // pto: %rounded_inline1286__ssa_v0
  uint64_t v49 = (uint64_t) v8;
  TASSIGN(v48, v49);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  RoundMode v50 = RoundMode::CAST_RINT;
  SaturationMode v51 = SaturationMode::ON;
  TCVT(v48, v35, v50, v51);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %projected_kv__ssa_v0_pview
  const int64_t v52 = 0;
  // pto: %projected_kv__ssa_v0_pview
  __gm__ bfloat16_t* v53 = PTOAS__GLOBAL_TENSOR_DATA(v31);
  // pto: %projected_kv__ssa_v0_pview
  const int64_t v54 = 1;
  // pto: %projected_kv__ssa_v0_pview
  const int64_t v55 = 1;
  // pto: %projected_kv__ssa_v0_pview
  const int64_t v56 = 1;
  // pto: %projected_kv__ssa_v0_pview
  int64_t v57 = v34 * v9;
  // pto: %projected_kv__ssa_v0_pview
  int64_t v58 = v56 * v57;
  // pto: %projected_kv__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 512> v59 = pto::Shape<1, 1, 1, -1, 512>(v54, v55, v56, v34, v9);
  // pto: %projected_kv__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v60 = pto::Stride<-1, -1, -1, -1, -1>(v55 * v58, v58, v57, v9, v10);
  // pto: %projected_kv__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v61 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v53 + (v52 + v37 * v9 + v12 * v10), v59, v60);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v61, v48);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}