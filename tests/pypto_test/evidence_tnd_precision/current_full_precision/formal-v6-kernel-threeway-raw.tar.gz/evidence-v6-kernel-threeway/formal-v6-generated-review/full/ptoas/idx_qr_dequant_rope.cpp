#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void idx_qr_dequant_rope(__gm__ bfloat16_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ float* v4, __gm__ float* v5, __gm__ int32_t* v6, int64_t v7, int64_t v8, int64_t v9, int64_t v10, int32_t v11, int32_t v12) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v13 = 256;
  const int64_t v14 = 512;
  // pto: %c6176_i64
  const int64_t v15 = 6176;
  // pto: %c10272_i64
  const int64_t v16 = 10272;
  // pto: %c14368_i64
  const int64_t v17 = 14368;
  // pto: %c0_i64
  const int64_t v18 = 0;
  // pto: %c2048_i64
  const int64_t v19 = 2048;
  // pto: %c2080_i64
  const int64_t v20 = 2080;
  // pto: %c4128_i64
  const int64_t v21 = 4128;
  // pto: %c18464_i64
  const int64_t v22 = 18464;
  // pto: %c24096_i64
  const int64_t v23 = 24096;
  const int64_t v24 = 6432;
  // pto: %c19488_i64
  const int64_t v25 = 19488;
  // pto: %c19744_i64
  const int64_t v26 = 19744;
  // pto: %c20000_i64
  const int64_t v27 = 20000;
  const int64_t v28 = 10528;
  // pto: %c25120_i64
  const int64_t v29 = 25120;
  // pto: %c25376_i64
  const int64_t v30 = 25376;
  const int64_t v31 = 14624;
  // pto: %c432_index
  const int64_t v32 = 432;
  // pto: %c8192_index
  const int64_t v33 = 8192;
  // pto: %c1_index
  const int64_t v34 = 1;
  // pto: %c64_index
  const int64_t v35 = 64;
  // pto: %c448_index
  const int64_t v36 = 448;
  // pto: %c8_index
  const int64_t v37 = 8;
  // pto: %cst_23
  const float v38 = 1.0f;
  // pto: %c192_index
  const int64_t v39 = 192;
  // pto: %c0_i32
  const int32_t v40 = 0;
  // pto: %cst_26
  const float v41 = 0.5f;
  // pto: %cst_27
  const float v42 = 2.0f;
  // pto: %c16_index
  const int64_t v43 = 16;
  // pto: %c4_index
  const int64_t v44 = 4;
  // pto: %c0_index
  const int64_t v45 = 0;
  // pto: %c2_index
  const int64_t v46 = 2;
  // pto: %c128_index
  const int64_t v47 = 128;
  // pto: %qr_bf16_2d_inline1123_inline5580__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %qr_bf16_2d_inline1123_inline5580__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %qr_bf16_2d_inline1123_inline5580__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %qr_bf16_2d_inline1123_inline5580__ssa_v0_view
  int64_t v51 = v32 * v33;
  // pto: %qr_bf16_2d_inline1123_inline5580__ssa_v0_view
  int64_t v52 = v50 * v51;
  // pto: %qr_bf16_2d_inline1123_inline5580__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v48, v49, v50, v32, v33);
  // pto: %qr_bf16_2d_inline1123_inline5580__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v49 * v52, v52, v51, v33, v34);
  // pto: %qr_bf16_2d_inline1123_inline5580__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v53, v54);
  // pto: %qr_scale__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %qr_scale__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %qr_scale__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %qr_scale__ssa_v0_view
  int64_t v59 = (int64_t) v10;
  // pto: %qr_scale__ssa_v0_view
  int64_t v60 = v59 * v34;
  // pto: %qr_scale__ssa_v0_view
  int64_t v61 = v58 * v60;
  // pto: %qr_scale__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v62 = pto::Shape<1, 1, 1, -1, -1>(v56, v57, v58, v59, v34);
  // pto: %qr_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v63 = pto::Stride<-1, -1, -1, -1, -1>(v57 * v61, v61, v60, v34, (int64_t) v10);
  // pto: %qr_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v64 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v2, v62, v63);
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v68 = (int64_t) v10;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v69 = v68 * v35;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v70 = v67 * v69;
  // pto: %freqs_cos__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v71 = pto::Shape<1, 1, 1, -1, -1>(v65, v66, v67, v68, v35);
  // pto: %freqs_cos__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v66 * v70, v70, v69, v35, v34);
  // pto: %freqs_cos__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v71, v72);
  // pto: %idx_sin_signed__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %idx_sin_signed__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %idx_sin_signed__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %idx_sin_signed__ssa_v0_view
  int64_t v77 = (int64_t) v10;
  // pto: %idx_sin_signed__ssa_v0_view
  int64_t v78 = v77 * v35;
  // pto: %idx_sin_signed__ssa_v0_view
  int64_t v79 = v76 * v78;
  // pto: %idx_sin_signed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v80 = pto::Shape<1, 1, 1, -1, -1>(v74, v75, v76, v77, v35);
  // pto: %idx_sin_signed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v81 = pto::Stride<-1, -1, -1, -1, -1>(v75 * v79, v79, v78, v35, v34);
  // pto: %idx_sin_signed__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v82 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v80, v81);
  // pto: %idx_wq_b_scale__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %idx_wq_b_scale__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %idx_wq_b_scale__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %idx_wq_b_scale__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %idx_wq_b_scale__ssa_v0_view
  int64_t v87 = v33 * v34;
  // pto: %idx_wq_b_scale__ssa_v0_view
  int64_t v88 = v86 * v87;
  // pto: %idx_wq_b_scale__ssa_v0_view
  int64_t v89 = v85 * v88;
  // pto: %idx_wq_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v90 = pto::Shape<1, 1, 1, 1, -1>(v83, v84, v85, v86, v33);
  // pto: %idx_wq_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v91 = pto::Stride<-1, -1, -1, -1, -1>(v84 * v89, v89, v88, v87, v34);
  // pto: %idx_wq_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v92 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v90, v91);
  // pto: %qr_acc_pad_inline1119_inline5602__rv_v2_view
  const int64_t v93 = 1;
  // pto: %qr_acc_pad_inline1119_inline5602__rv_v2_view
  const int64_t v94 = 1;
  // pto: %qr_acc_pad_inline1119_inline5602__rv_v2_view
  const int64_t v95 = 1;
  // pto: %qr_acc_pad_inline1119_inline5602__rv_v2_view
  int64_t v96 = v36 * v33;
  // pto: %qr_acc_pad_inline1119_inline5602__rv_v2_view
  int64_t v97 = v95 * v96;
  // pto: %qr_acc_pad_inline1119_inline5602__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v98 = pto::Shape<1, 1, 1, -1, -1>(v93, v94, v95, v36, v33);
  // pto: %qr_acc_pad_inline1119_inline5602__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v99 = pto::Stride<-1, -1, -1, -1, -1>(v94 * v97, v97, v96, v33, v34);
  // pto: %qr_acc_pad_inline1119_inline5602__rv_v2_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v100 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v98, v99);
  // pto: %dq_rope_worker_inline1125_inline5637__ssa_v0
  // pto: %sw_ones_inline1129_inline5597__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %sw_ones_inline1129_inline5597__tile
  uint64_t v102 = (uint64_t) v15;
  TASSIGN(v101, v102);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  TEXPANDS(v101, v38);
  // pto: %t__ci_tmp_v0
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v39);
  // pto: %t__ci_tmp_v0
  uint64_t v104 = (uint64_t) v16;
  TASSIGN(v103, v104);
  // pto: %t__tile
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v105 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
  // pto: %t__tile
  uint64_t v106 = (uint64_t) v17;
  TASSIGN(v105, v106);
  // pto: %ci_tmp_view
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v107;
  TRESHAPE(v107, v103);
  // pto: %ci_dst_view
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108;
  TRESHAPE(v108, v105);
  TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v108, v40, v107);
  // pto: %sw_index_inline1142_inline5610__tile
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v109 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
  // pto: %sw_index_inline1142_inline5610__tile
  uint64_t v110 = (uint64_t) v16;
  TASSIGN(v109, v110);
  pipe_barrier(PIPE_V);
  RoundMode v111 = RoundMode::CAST_ROUND;
  SaturationMode v112 = SaturationMode::ON;
  TCVT(v109, v105, v111, v112);
  // pto: %sw_col_inline1131_inline5586__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %sw_col_inline1131_inline5586__tile
  uint64_t v114 = (uint64_t) v15;
  TASSIGN(v113, v114);
  pipe_barrier(PIPE_V);
  TCOLEXPANDMUL(v113, v101, v109);
  // pto: %0
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %0
  uint64_t v116 = (uint64_t) v16;
  TASSIGN(v115, v116);
  pipe_barrier(PIPE_V);
  TMULS(v115, v113, v41);
  // pto: %1
  Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %1
  uint64_t v118 = (uint64_t) v16;
  TASSIGN(v117, v118);
  pipe_barrier(PIPE_V);
  RoundMode v119 = RoundMode::CAST_TRUNC;
  SaturationMode v120 = SaturationMode::ON;
  TCVT(v117, v115, v119, v120);
  // pto: %sw_dup_f_inline1135_inline5601__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %sw_dup_f_inline1135_inline5601__tile
  uint64_t v122 = (uint64_t) v16;
  TASSIGN(v121, v122);
  pipe_barrier(PIPE_V);
  RoundMode v123 = RoundMode::CAST_ROUND;
  SaturationMode v124 = SaturationMode::ON;
  TCVT(v121, v117, v123, v124);
  // pto: %2
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %2
  uint64_t v126 = (uint64_t) v16;
  TASSIGN(v125, v126);
  pipe_barrier(PIPE_V);
  TMULS(v125, v121, v42);
  // pto: %sw_lane_inline1143_inline5584__tile
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %sw_lane_inline1143_inline5584__tile
  uint64_t v128 = (uint64_t) v16;
  TASSIGN(v127, v128);
  pipe_barrier(PIPE_V);
  TSUB(v127, v113, v125);
  // pto: %3
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %3
  uint64_t v130 = (uint64_t) v15;
  TASSIGN(v129, v130);
  pipe_barrier(PIPE_V);
  TADDS(v129, v113, v38);
  // pto: %4
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %4
  uint64_t v132 = (uint64_t) v16;
  TASSIGN(v131, v132);
  TMULS(v131, v127, v42);
  // pto: %5
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %5
  uint64_t v134 = (uint64_t) v15;
  TASSIGN(v133, v134);
  pipe_barrier(PIPE_V);
  TSUB(v133, v129, v131);
  // pto: %rope_swap_idx_inline1108_inline5613__tile
  Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
  // pto: %rope_swap_idx_inline1108_inline5613__tile
  uint64_t v136 = (uint64_t) v18;
  TASSIGN(v135, v136);
  pipe_barrier(PIPE_V);
  RoundMode v137 = RoundMode::CAST_ROUND;
  SaturationMode v138 = SaturationMode::ON;
  TCVT(v135, v133, v137, v138);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  for (int64_t v139 = (int64_t) v11; v139 < v7; v139 += v8) {
    // pto: %72, %73
    ;
    int64_t v140 = (int64_t) ((uint64_t) (v139 % v43) * (uint64_t) v44);
    // pto: %74, %75
    ;
    int64_t v141 = (int64_t) ((uint64_t) (v139 / v43) * (uint64_t) v37);
    // pto: %76, %77
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    if ((int64_t) ((uint64_t) v141 + (uint64_t) v37) <= v9) {
      // pto: %qr_scale_tile_inline1145_inline5579__tile
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v142 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v34);
      // pto: %qr_scale_tile_inline1145_inline5579__tile
      ;
      uint64_t v143 = (uint64_t) v19;
      TASSIGN(v142, v143);
      // pto: %78
      ;
      int64_t v144 = v141 < v45 ? v45 : v141;
      // pto: %qr_scale__ssa_v0_pview
      ;
      int64_t v145 = (int64_t) v10;
      // pto: %qr_scale__ssa_v0_pview
      ;
      const int64_t v146 = 0;
      // pto: %qr_scale__ssa_v0_pview
      ;
      __gm__ float* v147 = PTOAS__GLOBAL_TENSOR_DATA(v64);
      // pto: %qr_scale__ssa_v0_pview
      ;
      const int64_t v148 = 1;
      // pto: %qr_scale__ssa_v0_pview
      ;
      const int64_t v149 = 1;
      // pto: %qr_scale__ssa_v0_pview
      ;
      const int64_t v150 = 1;
      // pto: %qr_scale__ssa_v0_pview
      ;
      int64_t v151 = v37 * v34;
      // pto: %qr_scale__ssa_v0_pview
      ;
      int64_t v152 = v150 * v151;
      // pto: %qr_scale__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 1> v153 = pto::Shape<1, 1, 1, 8, 1>(v148, v149, v150, v37, v34);
      // pto: %qr_scale__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v154 = pto::Stride<-1, -1, -1, -1, -1>(v149 * v152, v152, v151, v34, v145);
      // pto: %qr_scale__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v155 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v147 + (v146 + v144 * v34 + v45 * v145), v153, v154);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
      TLOAD(v142, v155);
      // pto: %cos_tile_inline1139_inline5609__tile
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v156 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
      // pto: %cos_tile_inline1139_inline5609__tile
      ;
      uint64_t v157 = (uint64_t) v20;
      TASSIGN(v156, v157);
      // pto: %freqs_cos__ssa_v0_pview
      ;
      __gm__ float* v158 = PTOAS__GLOBAL_TENSOR_DATA(v73);
      // pto: %freqs_cos__ssa_v0_pview
      ;
      const int64_t v159 = 0;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      const int64_t v160 = 64;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v161 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %freqs_cos__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v162 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %freqs_cos__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v163 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v158 + (v159 + v144 * v160), v161, v162);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      TLOAD(v156, v163);
      // pto: %sin_tile_inline1127_inline5617__tile
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v164 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
      // pto: %sin_tile_inline1127_inline5617__tile
      ;
      uint64_t v165 = (uint64_t) v21;
      TASSIGN(v164, v165);
      // pto: %idx_sin_signed__ssa_v0_pview
      ;
      __gm__ float* v166 = PTOAS__GLOBAL_TENSOR_DATA(v82);
      // pto: %idx_sin_signed__ssa_v0_pview
      ;
      const int64_t v167 = 0;
      // pto: %idx_sin_signed__ssa_v0_pview
      ;
      const int64_t v168 = 64;
      // pto: %idx_sin_signed__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v169 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %idx_sin_signed__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v170 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %idx_sin_signed__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v171 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v166 + (v167 + v144 * v168), v169, v170);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      TLOAD(v164, v171);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      for (int64_t v172 = v45; v172 < v44; v172 += v46) {
        // pto: %81, %82
        ;
        int64_t v173 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 + (uint64_t) v172) * (uint64_t) v47);
        // pto: %84, %83, %85
        ;
        int64_t v174 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 + (uint64_t) ((int64_t) (uint64_t) v172 + (uint64_t) v34)) * (uint64_t) v47);
        // pto: %6
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
        // pto: %6
        ;
        uint64_t v176 = (uint64_t) v22;
        TASSIGN(v175, v176);
        // pto: %86
        ;
        int64_t v177 = v173 < v45 ? v45 : v173;
        // pto: %idx_wq_b_scale__ssa_v0_pview
        ;
        __gm__ float* v178 = PTOAS__GLOBAL_TENSOR_DATA(v92);
        // pto: %idx_wq_b_scale__ssa_v0_pview
        ;
        const int64_t v179 = 0;
        // pto: %idx_wq_b_scale__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 128> v180 = pto::Shape<1, 1, 1, 1, 128>();
        // pto: %idx_wq_b_scale__ssa_v0_pview
        ;
        pto::Stride<128, 128, 128, 128, 1> v181 = pto::Stride<128, 128, 128, 128, 1>();
        // pto: %idx_wq_b_scale__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v182 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v178 + (v179 + v177), v180, v181);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        TLOAD(v175, v182);
        // pto: %7
        ;
        Tile<TileType::Vec, int32_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Vec, int32_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %7
        ;
        uint64_t v184 = (uint64_t) v15;
        TASSIGN(v183, v184);
        // pto: %qr_acc_pad_inline1119_inline5602__rv_v2_pview
        ;
        __gm__ int32_t* v185 = PTOAS__GLOBAL_TENSOR_DATA(v100);
        // pto: %qr_acc_pad_inline1119_inline5602__rv_v2_pview
        ;
        const int64_t v186 = 0;
        // pto: %qr_acc_pad_inline1119_inline5602__rv_v2_pview
        ;
        const int64_t v187 = 8192;
        // pto: %qr_acc_pad_inline1119_inline5602__rv_v2_pview
        ;
        pto::Shape<1, 1, 1, 8, 128> v188 = pto::Shape<1, 1, 1, 8, 128>();
        // pto: %qr_acc_pad_inline1119_inline5602__rv_v2_pview
        ;
        pto::Stride<65536, 65536, 65536, 8192, 1> v189 = pto::Stride<65536, 65536, 65536, 8192, 1>();
        // pto: %qr_acc_pad_inline1119_inline5602__rv_v2_pview
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v190 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v185 + (v186 + v144 * v187 + v177), v188, v189);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        TLOAD(v183, v190);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %8
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v191 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
        // pto: %8
        ;
        uint64_t v192 = (uint64_t) v23;
        TASSIGN(v191, v192);
        // pto: %89
        ;
        int64_t v193 = v174 < v45 ? v45 : v174;
        // pto: %90
        ;
        __gm__ float* v194 = PTOAS__GLOBAL_TENSOR_DATA(v92);
        // pto: %90
        ;
        const int64_t v195 = 0;
        // pto: %90
        ;
        pto::Shape<1, 1, 1, 1, 128> v196 = pto::Shape<1, 1, 1, 1, 128>();
        // pto: %90
        ;
        pto::Stride<128, 128, 128, 128, 1> v197 = pto::Stride<128, 128, 128, 128, 1>();
        // pto: %90
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v198 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v194 + (v195 + v193), v196, v197);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
        TLOAD(v191, v198);
        // pto: %9
        ;
        Tile<TileType::Vec, int32_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Vec, int32_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %9
        ;
        uint64_t v200 = (uint64_t) v16;
        TASSIGN(v199, v200);
        // pto: %93
        ;
        __gm__ int32_t* v201 = PTOAS__GLOBAL_TENSOR_DATA(v100);
        // pto: %93
        ;
        const int64_t v202 = 0;
        // pto: %93
        ;
        const int64_t v203 = 8192;
        // pto: %93
        ;
        pto::Shape<1, 1, 1, 8, 128> v204 = pto::Shape<1, 1, 1, 8, 128>();
        // pto: %93
        ;
        pto::Stride<65536, 65536, 65536, 8192, 1> v205 = pto::Stride<65536, 65536, 65536, 8192, 1>();
        // pto: %93
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v206 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v201 + (v202 + v144 * v203 + v193), v204, v205);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        TLOAD(v199, v206);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %wq_scale_inline1144_inline5642__tile
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
        // pto: %wq_scale_inline1144_inline5642__tile
        ;
        uint64_t v208 = (uint64_t) v22;
        TASSIGN(v207, v208);
        // pto: %acc_fp32_inline1100_inline5622__tile
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %acc_fp32_inline1100_inline5622__tile
        ;
        uint64_t v210 = (uint64_t) v15;
        TASSIGN(v209, v210);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v211 = RoundMode::CAST_NONE;
        SaturationMode v212 = SaturationMode::ON;
        TCVT(v209, v183, v211, v212);
        // pto: %10
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %10
        ;
        uint64_t v214 = (uint64_t) v17;
        TASSIGN(v213, v214);
        TEXPANDS(v213, v38);
        // pto: %11
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %11
        ;
        uint64_t v216 = (uint64_t) v17;
        TASSIGN(v215, v216);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v215, v213, v142);
        // pto: %qr_dequant_scale_inline1128_inline5624__tile
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %qr_dequant_scale_inline1128_inline5624__tile
        ;
        uint64_t v218 = (uint64_t) v17;
        TASSIGN(v217, v218);
        pipe_barrier(PIPE_V);
        TCOLEXPANDMUL(v217, v215, v207);
        // pto: %qr_dequant_inline1105_inline5625__tile
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v219 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %qr_dequant_inline1105_inline5625__tile
        ;
        uint64_t v220 = (uint64_t) v15;
        TASSIGN(v219, v220);
        pipe_barrier(PIPE_V);
        TMUL(v219, v209, v217);
        // pto: %12
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v221 = Tile<TileType::Vec, bfloat16_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %12
        ;
        uint64_t v222 = (uint64_t) v17;
        TASSIGN(v221, v222);
        pipe_barrier(PIPE_V);
        RoundMode v223 = RoundMode::CAST_RINT;
        SaturationMode v224 = SaturationMode::ON;
        TCVT(v221, v219, v223, v224);
        // pto: %qr_dequant_v1_inline1098_inline5626__tile
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v225 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %qr_dequant_v1_inline1098_inline5626__tile
        ;
        uint64_t v226 = (uint64_t) v15;
        TASSIGN(v225, v226);
        pipe_barrier(PIPE_V);
        RoundMode v227 = RoundMode::CAST_ROUND;
        SaturationMode v228 = SaturationMode::ON;
        TCVT(v225, v221, v227, v228);
        // pto: %13
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v229 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %13
        ;
        uint64_t v230 = (uint64_t) v15;
        TASSIGN(v229, v230);
        // pto: %slice_view
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v231;
        // pto: %slice_view
        ;
        uint64_t v232 = (uint64_t) v15;
        TASSIGN(v231, v232);
        // pto: %qr_nope_bf16_inline1141_inline5587__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %qr_nope_bf16_inline1141_inline5587__tile
        ;
        uint64_t v234 = (uint64_t) v22;
        TASSIGN(v233, v234);
        pipe_barrier(PIPE_V);
        RoundMode v235 = RoundMode::CAST_RINT;
        SaturationMode v236 = SaturationMode::ON;
        TCVT(v233, v231, v235, v236);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %qr_rope_slice_inline1097_inline5627__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v237 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %qr_rope_slice_inline1097_inline5627__tile
        ;
        uint64_t v238 = (uint64_t) v24;
        TASSIGN(v237, v238);
        // pto: %94
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v239;
        // pto: %94
        ;
        uint64_t v240 = (uint64_t) v24;
        TASSIGN(v239, v240);
        // pto: %gather_acc_init
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v241 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %gather_acc_init
        ;
        uint64_t v242 = (uint64_t) v17;
        TASSIGN(v241, v242);
        for (int64_t v243 = v45; v243 < v37; v243 += v34) {
          // pto: %gather_inp_row
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %gather_inp_row
          ;
          uint64_t v245 = (uint64_t) v15;
          TASSIGN(v244, v245);
          // pto: %95
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246;
          // pto: %95
          ;
          uint64_t v247 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v243 * (uint64_t) v14) + (uint64_t) v24);
          TASSIGN(v246, v247);
          // pto: %gather_idx_row
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v248 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %gather_idx_row
          ;
          uint64_t v249 = (uint64_t) v18;
          TASSIGN(v248, v249);
          // pto: %96
          ;
          int64_t v250 = (int64_t) ((uint64_t) v243 * (uint64_t) v13);
          // pto: %96
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v251;
          // pto: %96
          ;
          uint64_t v252 = (uint64_t) v250;
          TASSIGN(v251, v252);
          // pto: %gather_row_tmp
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v253 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %gather_row_tmp
          ;
          uint64_t v254 = (uint64_t) v25;
          TASSIGN(v253, v254);
          // pto: %gather_row
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %gather_row
          ;
          uint64_t v256 = (uint64_t) v26;
          TASSIGN(v255, v256);
          pipe_barrier(PIPE_V);
          TGATHER(v255, v246, v251, v253);
          // pto: %assemble_view
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v257;
          // pto: %assemble_view
          ;
          uint64_t v258 = (uint64_t) ((int64_t) (uint64_t) v250 + (uint64_t) v17);
          TASSIGN(v257, v258);
          pipe_barrier(PIPE_V);
          TMOV(v257, v255);
        };
        // pto: %qr_swapped_inline1107_inline5606__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v259 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %qr_swapped_inline1107_inline5606__tile
        ;
        uint64_t v260 = (uint64_t) v17;
        TASSIGN(v259, v260);
        // pto: %14
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v261 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %14
        ;
        uint64_t v262 = (uint64_t) v15;
        TASSIGN(v261, v262);
        pipe_barrier(PIPE_V);
        TMUL(v261, v239, v156);
        // pto: %15
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v263 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %15
        ;
        uint64_t v264 = (uint64_t) v17;
        TASSIGN(v263, v264);
        TMUL(v263, v259, v164);
        // pto: %rope_rot_inline1124_inline5629__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v265 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %rope_rot_inline1124_inline5629__tile
        ;
        uint64_t v266 = (uint64_t) v15;
        TASSIGN(v265, v266);
        pipe_barrier(PIPE_V);
        TADD(v265, v261, v263);
        // pto: %rope_bf16_inline1116_inline5631__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v267 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %rope_bf16_inline1116_inline5631__tile
        ;
        uint64_t v268 = (uint64_t) v15;
        TASSIGN(v267, v268);
        pipe_barrier(PIPE_V);
        RoundMode v269 = RoundMode::CAST_RINT;
        SaturationMode v270 = SaturationMode::ON;
        TCVT(v267, v265, v269, v270);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        // pto: %qr_bf16_2d_inline1123_inline5580__iter_v3_pview
        ;
        __gm__ bfloat16_t* v271 = PTOAS__GLOBAL_TENSOR_DATA(v55);
        // pto: %qr_bf16_2d_inline1123_inline5580__iter_v3_pview
        ;
        const int64_t v272 = 0;
        // pto: %qr_bf16_2d_inline1123_inline5580__iter_v3_pview
        ;
        const int64_t v273 = 8192;
        // pto: %qr_bf16_2d_inline1123_inline5580__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 8, 64> v274 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %qr_bf16_2d_inline1123_inline5580__iter_v3_pview
        ;
        pto::Stride<65536, 65536, 65536, 8192, 1> v275 = pto::Stride<65536, 65536, 65536, 8192, 1>();
        // pto: %qr_bf16_2d_inline1123_inline5580__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v276 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v271 + (v272 + v144 * v273 + v177), v274, v275);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v276, v233);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        // pto: %101
        ;
        int64_t v277 = (int64_t) ((uint64_t) v173 + (uint64_t) v35);
        // pto: %102
        ;
        int64_t v278 = v277 < v45 ? v45 : v277;
        // pto: %qr_bf16_2d_inline1123_inline5580__tile_pview
        ;
        __gm__ bfloat16_t* v279 = PTOAS__GLOBAL_TENSOR_DATA(v55);
        // pto: %qr_bf16_2d_inline1123_inline5580__tile_pview
        ;
        const int64_t v280 = 0;
        // pto: %qr_bf16_2d_inline1123_inline5580__tile_pview
        ;
        const int64_t v281 = 8192;
        // pto: %qr_bf16_2d_inline1123_inline5580__tile_pview
        ;
        pto::Shape<1, 1, 1, 8, 64> v282 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %qr_bf16_2d_inline1123_inline5580__tile_pview
        ;
        pto::Stride<65536, 65536, 65536, 8192, 1> v283 = pto::Stride<65536, 65536, 65536, 8192, 1>();
        // pto: %qr_bf16_2d_inline1123_inline5580__tile_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v284 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v279 + (v280 + v144 * v281 + v278), v282, v283);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v284, v267);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        // pto: %16
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
        // pto: %16
        ;
        uint64_t v286 = (uint64_t) v23;
        TASSIGN(v285, v286);
        // pto: %17
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %17
        ;
        uint64_t v288 = (uint64_t) v16;
        TASSIGN(v287, v288);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v289 = RoundMode::CAST_NONE;
        SaturationMode v290 = SaturationMode::ON;
        TCVT(v287, v199, v289, v290);
        // pto: %18
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %18
        ;
        uint64_t v292 = (uint64_t) v27;
        TASSIGN(v291, v292);
        TEXPANDS(v291, v38);
        // pto: %19
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %19
        ;
        uint64_t v294 = (uint64_t) v27;
        TASSIGN(v293, v294);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v293, v291, v142);
        // pto: %20
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %20
        ;
        uint64_t v296 = (uint64_t) v27;
        TASSIGN(v295, v296);
        pipe_barrier(PIPE_V);
        TCOLEXPANDMUL(v295, v293, v285);
        // pto: %21
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %21
        ;
        uint64_t v298 = (uint64_t) v16;
        TASSIGN(v297, v298);
        pipe_barrier(PIPE_V);
        TMUL(v297, v287, v295);
        // pto: %22
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, bfloat16_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %22
        ;
        uint64_t v300 = (uint64_t) v27;
        TASSIGN(v299, v300);
        pipe_barrier(PIPE_V);
        RoundMode v301 = RoundMode::CAST_RINT;
        SaturationMode v302 = SaturationMode::ON;
        TCVT(v299, v297, v301, v302);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v47);
        // pto: %23
        ;
        uint64_t v304 = (uint64_t) v16;
        TASSIGN(v303, v304);
        pipe_barrier(PIPE_V);
        RoundMode v305 = RoundMode::CAST_ROUND;
        SaturationMode v306 = SaturationMode::ON;
        TCVT(v303, v299, v305, v306);
        // pto: %24
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %24
        ;
        uint64_t v308 = (uint64_t) v16;
        TASSIGN(v307, v308);
        // pto: %103
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309;
        // pto: %103
        ;
        uint64_t v310 = (uint64_t) v16;
        TASSIGN(v309, v310);
        // pto: %25
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %25
        ;
        uint64_t v312 = (uint64_t) v23;
        TASSIGN(v311, v312);
        pipe_barrier(PIPE_V);
        RoundMode v313 = RoundMode::CAST_RINT;
        SaturationMode v314 = SaturationMode::ON;
        TCVT(v311, v309, v313, v314);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        // pto: %26
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %26
        ;
        uint64_t v316 = (uint64_t) v28;
        TASSIGN(v315, v316);
        // pto: %104
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317;
        // pto: %104
        ;
        uint64_t v318 = (uint64_t) v28;
        TASSIGN(v317, v318);
        // pto: %27
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v319 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %27
        ;
        uint64_t v320 = (uint64_t) v27;
        TASSIGN(v319, v320);
        for (int64_t v321 = v45; v321 < v37; v321 += v34) {
          // pto: %28
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v322 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %28
          ;
          uint64_t v323 = (uint64_t) v16;
          TASSIGN(v322, v323);
          // pto: %106
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v324;
          // pto: %106
          ;
          uint64_t v325 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v321 * (uint64_t) v14) + (uint64_t) v28);
          TASSIGN(v324, v325);
          // pto: %29
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v326 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %29
          ;
          uint64_t v327 = (uint64_t) v18;
          TASSIGN(v326, v327);
          // pto: %107
          ;
          int64_t v328 = (int64_t) ((uint64_t) v321 * (uint64_t) v13);
          // pto: %107
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v329;
          // pto: %107
          ;
          uint64_t v330 = (uint64_t) v328;
          TASSIGN(v329, v330);
          // pto: %30
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v331 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %30
          ;
          uint64_t v332 = (uint64_t) v29;
          TASSIGN(v331, v332);
          // pto: %31
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v333 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %31
          ;
          uint64_t v334 = (uint64_t) v30;
          TASSIGN(v333, v334);
          pipe_barrier(PIPE_V);
          TGATHER(v333, v324, v329, v331);
          // pto: %108
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v335;
          // pto: %108
          ;
          uint64_t v336 = (uint64_t) ((int64_t) (uint64_t) v328 + (uint64_t) v27);
          TASSIGN(v335, v336);
          pipe_barrier(PIPE_V);
          TMOV(v335, v333);
        };
        // pto: %33
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v337 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %33
        ;
        uint64_t v338 = (uint64_t) v27;
        TASSIGN(v337, v338);
        // pto: %34
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v339 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %34
        ;
        uint64_t v340 = (uint64_t) v16;
        TASSIGN(v339, v340);
        pipe_barrier(PIPE_V);
        TMUL(v339, v317, v156);
        // pto: %35
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v341 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %35
        ;
        uint64_t v342 = (uint64_t) v27;
        TASSIGN(v341, v342);
        TMUL(v341, v337, v164);
        // pto: %36
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %36
        ;
        uint64_t v344 = (uint64_t) v16;
        TASSIGN(v343, v344);
        pipe_barrier(PIPE_V);
        TADD(v343, v339, v341);
        // pto: %37
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v345 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v35);
        // pto: %37
        ;
        uint64_t v346 = (uint64_t) v16;
        TASSIGN(v345, v346);
        pipe_barrier(PIPE_V);
        RoundMode v347 = RoundMode::CAST_RINT;
        SaturationMode v348 = SaturationMode::ON;
        TCVT(v345, v343, v347, v348);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        // pto: %112
        ;
        __gm__ bfloat16_t* v349 = PTOAS__GLOBAL_TENSOR_DATA(v55);
        // pto: %112
        ;
        const int64_t v350 = 0;
        // pto: %112
        ;
        const int64_t v351 = 8192;
        // pto: %112
        ;
        pto::Shape<1, 1, 1, 8, 64> v352 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %112
        ;
        pto::Stride<65536, 65536, 65536, 8192, 1> v353 = pto::Stride<65536, 65536, 65536, 8192, 1>();
        // pto: %112
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v354 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v349 + (v350 + v144 * v351 + v193), v352, v353);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v354, v311);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
        // pto: %115
        ;
        int64_t v355 = (int64_t) ((uint64_t) v174 + (uint64_t) v35);
        // pto: %116
        ;
        int64_t v356 = v355 < v45 ? v45 : v355;
        // pto: %117
        ;
        __gm__ bfloat16_t* v357 = PTOAS__GLOBAL_TENSOR_DATA(v55);
        // pto: %117
        ;
        const int64_t v358 = 0;
        // pto: %117
        ;
        const int64_t v359 = 8192;
        // pto: %117
        ;
        pto::Shape<1, 1, 1, 8, 64> v360 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %117
        ;
        pto::Stride<65536, 65536, 65536, 8192, 1> v361 = pto::Stride<65536, 65536, 65536, 8192, 1>();
        // pto: %117
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v362 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v357 + (v358 + v144 * v359 + v356), v360, v361);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        TSTORE(v362, v345);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      };
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    } else {
      // pto: %tail_swap_idx_inline1096_inline5589__tile
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v363 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
      // pto: %tail_swap_idx_inline1096_inline5589__tile
      ;
      uint64_t v364 = (uint64_t) v18;
      TASSIGN(v363, v364);
      // pto: %118
      ;
      uint64_t v365 = (uint64_t) v18;
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      for (int64_t v366 = v141; v366 < v9; v366 += v34) {
        // pto: %tail_qr_scale_value_inline1092_inline5598__tile
        ;
        float v367 = (v2)[v366];
        // pto: %tail_cos_tile_inline1104_inline5633__tile
        ;
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v368 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
        // pto: %tail_cos_tile_inline1104_inline5633__tile
        ;
        uint64_t v369 = (uint64_t) v20;
        TASSIGN(v368, v369);
        // pto: %119
        ;
        int64_t v370 = v366 < v45 ? v45 : v366;
        // pto: %120
        ;
        __gm__ float* v371 = PTOAS__GLOBAL_TENSOR_DATA(v73);
        // pto: %120
        ;
        const int64_t v372 = 0;
        // pto: %120
        ;
        const int64_t v373 = 64;
        // pto: %120
        ;
        pto::Shape<1, 1, 1, 1, 64> v374 = pto::Shape<1, 1, 1, 1, 64>();
        // pto: %120
        ;
        pto::Stride<64, 64, 64, 64, 1> v375 = pto::Stride<64, 64, 64, 64, 1>();
        // pto: %120
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v376 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v371 + (v372 + v370 * v373), v374, v375);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        TLOAD(v368, v376);
        // pto: %tail_sin_tile_inline1099_inline5634__tile
        ;
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v377 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
        // pto: %tail_sin_tile_inline1099_inline5634__tile
        ;
        uint64_t v378 = (uint64_t) v21;
        TASSIGN(v377, v378);
        // pto: %122
        ;
        __gm__ float* v379 = PTOAS__GLOBAL_TENSOR_DATA(v82);
        // pto: %122
        ;
        const int64_t v380 = 0;
        // pto: %122
        ;
        const int64_t v381 = 64;
        // pto: %122
        ;
        pto::Shape<1, 1, 1, 1, 64> v382 = pto::Shape<1, 1, 1, 1, 64>();
        // pto: %122
        ;
        pto::Stride<64, 64, 64, 64, 1> v383 = pto::Stride<64, 64, 64, 64, 1>();
        // pto: %122
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v384 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v379 + (v380 + v370 * v381), v382, v383);
        pipe_barrier(PIPE_ALL);
        TLOAD(v377, v384);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
        for (int64_t v385 = v45; v385 < v44; v385 += v46) {
          // pto: %123, %124
          ;
          int64_t v386 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 + (uint64_t) v385) * (uint64_t) v47);
          // pto: %126, %125, %127
          ;
          int64_t v387 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v140 + (uint64_t) ((int64_t) (uint64_t) v385 + (uint64_t) v34)) * (uint64_t) v47);
          // pto: %38
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v388 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %38
          ;
          uint64_t v389 = (uint64_t) v15;
          TASSIGN(v388, v389);
          // pto: %128
          ;
          int64_t v390 = v386 < v45 ? v45 : v386;
          // pto: %129
          ;
          __gm__ float* v391 = PTOAS__GLOBAL_TENSOR_DATA(v92);
          // pto: %129
          ;
          const int64_t v392 = 0;
          // pto: %129
          ;
          pto::Shape<1, 1, 1, 1, 128> v393 = pto::Shape<1, 1, 1, 1, 128>();
          // pto: %129
          ;
          pto::Stride<128, 128, 128, 128, 1> v394 = pto::Stride<128, 128, 128, 128, 1>();
          // pto: %129
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v395 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v391 + (v392 + v390), v393, v394);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
          TLOAD(v388, v395);
          // pto: %39
          ;
          Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v396 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %39
          ;
          uint64_t v397 = (uint64_t) v16;
          TASSIGN(v396, v397);
          // pto: %132
          ;
          __gm__ int32_t* v398 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %132
          ;
          const int64_t v399 = 0;
          // pto: %132
          ;
          const int64_t v400 = 8192;
          // pto: %132
          ;
          pto::Shape<1, 1, 1, 1, 128> v401 = pto::Shape<1, 1, 1, 1, 128>();
          // pto: %132
          ;
          pto::Stride<8192, 8192, 8192, 8192, 1> v402 = pto::Stride<8192, 8192, 8192, 8192, 1>();
          // pto: %132
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v403 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v398 + (v399 + v370 * v400 + v390), v401, v402);
          TLOAD(v396, v403);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          // pto: %40
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v404 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %40
          ;
          uint64_t v405 = (uint64_t) v17;
          TASSIGN(v404, v405);
          // pto: %133
          ;
          int64_t v406 = v387 < v45 ? v45 : v387;
          // pto: %134
          ;
          __gm__ float* v407 = PTOAS__GLOBAL_TENSOR_DATA(v92);
          // pto: %134
          ;
          const int64_t v408 = 0;
          // pto: %134
          ;
          pto::Shape<1, 1, 1, 1, 128> v409 = pto::Shape<1, 1, 1, 1, 128>();
          // pto: %134
          ;
          pto::Stride<128, 128, 128, 128, 1> v410 = pto::Stride<128, 128, 128, 128, 1>();
          // pto: %134
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v411 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v407 + (v408 + v406), v409, v410);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          TLOAD(v404, v411);
          // pto: %41
          ;
          Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v412 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %41
          ;
          uint64_t v413 = (uint64_t) v27;
          TASSIGN(v412, v413);
          // pto: %137
          ;
          __gm__ int32_t* v414 = PTOAS__GLOBAL_TENSOR_DATA(v100);
          // pto: %137
          ;
          const int64_t v415 = 0;
          // pto: %137
          ;
          const int64_t v416 = 8192;
          // pto: %137
          ;
          pto::Shape<1, 1, 1, 1, 128> v417 = pto::Shape<1, 1, 1, 1, 128>();
          // pto: %137
          ;
          pto::Stride<8192, 8192, 8192, 8192, 1> v418 = pto::Stride<8192, 8192, 8192, 8192, 1>();
          // pto: %137
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v419 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v414 + (v415 + v370 * v416 + v406), v417, v418);
          TLOAD(v412, v419);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          // pto: %tail_wq_scale_inline1090_inline5638__tile
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v420 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %tail_wq_scale_inline1090_inline5638__tile
          ;
          uint64_t v421 = (uint64_t) v15;
          TASSIGN(v420, v421);
          // pto: %tail_acc_fp32_inline1133_inline5596__tile
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v422 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %tail_acc_fp32_inline1133_inline5596__tile
          ;
          uint64_t v423 = (uint64_t) v16;
          TASSIGN(v422, v423);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          RoundMode v424 = RoundMode::CAST_NONE;
          SaturationMode v425 = SaturationMode::ON;
          TCVT(v422, v396, v424, v425);
          // pto: %tail_qr_dequant_scale_inline1094_inline5639__tile
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v426 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %tail_qr_dequant_scale_inline1094_inline5639__tile
          ;
          uint64_t v427 = (uint64_t) v15;
          TASSIGN(v426, v427);
          TMULS(v426, v420, v367);
          // pto: %tail_qr_dequant_inline1089_inline5628__tile
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v428 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %tail_qr_dequant_inline1089_inline5628__tile
          ;
          uint64_t v429 = (uint64_t) v15;
          TASSIGN(v428, v429);
          pipe_barrier(PIPE_V);
          TMUL(v428, v422, v426);
          // pto: %42
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v430 = Tile<TileType::Vec, bfloat16_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %42
          ;
          uint64_t v431 = (uint64_t) v16;
          TASSIGN(v430, v431);
          pipe_barrier(PIPE_V);
          RoundMode v432 = RoundMode::CAST_RINT;
          SaturationMode v433 = SaturationMode::ON;
          TCVT(v430, v428, v432, v433);
          // pto: %tail_qr_dequant_v1_inline1109_inline5590__tile
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v434 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %tail_qr_dequant_v1_inline1109_inline5590__tile
          ;
          uint64_t v435 = (uint64_t) v15;
          TASSIGN(v434, v435);
          pipe_barrier(PIPE_V);
          RoundMode v436 = RoundMode::CAST_ROUND;
          SaturationMode v437 = SaturationMode::ON;
          TCVT(v434, v430, v436, v437);
          // pto: %43
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v438 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %43
          ;
          uint64_t v439 = (uint64_t) v15;
          TASSIGN(v438, v439);
          // pto: %138
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v440;
          // pto: %138
          ;
          uint64_t v441 = (uint64_t) v15;
          TASSIGN(v440, v441);
          // pto: %tail_qr_nope_bf16_inline1140_inline5594__tile
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v442 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %tail_qr_nope_bf16_inline1140_inline5594__tile
          ;
          uint64_t v443 = (uint64_t) v29;
          TASSIGN(v442, v443);
          pipe_barrier(PIPE_V);
          RoundMode v444 = RoundMode::CAST_RINT;
          SaturationMode v445 = SaturationMode::ON;
          TCVT(v442, v440, v444, v445);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
          // pto: %tail_qr_rope_slice_inline1093_inline5640__tile
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v446 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %tail_qr_rope_slice_inline1093_inline5640__tile
          ;
          uint64_t v447 = (uint64_t) v24;
          TASSIGN(v446, v447);
          // pto: %139
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v448;
          // pto: %139
          ;
          uint64_t v449 = (uint64_t) v24;
          TASSIGN(v448, v449);
          // pto: %44
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v450 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %44
          ;
          uint64_t v451 = (uint64_t) v16;
          TASSIGN(v450, v451);
          // pto: %45
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v452 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %45
          ;
          uint64_t v453 = (uint64_t) v15;
          TASSIGN(v452, v453);
          // pto: %140
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v454;
          // pto: %140
          ;
          uint64_t v455 = (uint64_t) v24;
          TASSIGN(v454, v455);
          // pto: %46
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v456 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %46
          ;
          uint64_t v457 = (uint64_t) v18;
          TASSIGN(v456, v457);
          // pto: %141
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v458;
          // pto: %141
          ;
          uint64_t v459 = (uint64_t) v18;
          TASSIGN(v458, v459);
          // pto: %47
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v460 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %47
          ;
          uint64_t v461 = (uint64_t) v22;
          TASSIGN(v460, v461);
          // pto: %48
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v462 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %48
          ;
          uint64_t v463 = (uint64_t) v23;
          TASSIGN(v462, v463);
          TGATHER(v462, v454, v458, v460);
          // pto: %142
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v464;
          // pto: %142
          ;
          uint64_t v465 = (uint64_t) v16;
          TASSIGN(v464, v465);
          pipe_barrier(PIPE_V);
          TMOV(v464, v462);
          // pto: %tail_qr_swapped_inline1115_inline5643__tile
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %tail_qr_swapped_inline1115_inline5643__tile
          ;
          uint64_t v467 = (uint64_t) v16;
          TASSIGN(v466, v467);
          // pto: %50
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v468 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %50
          ;
          uint64_t v469 = (uint64_t) v15;
          TASSIGN(v468, v469);
          TMUL(v468, v448, v368);
          // pto: %51
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v470 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %51
          ;
          uint64_t v471 = (uint64_t) v16;
          TASSIGN(v470, v471);
          pipe_barrier(PIPE_V);
          TMUL(v470, v466, v377);
          // pto: %tail_rope_rot_inline1132_inline5582__tile
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %tail_rope_rot_inline1132_inline5582__tile
          ;
          uint64_t v473 = (uint64_t) v15;
          TASSIGN(v472, v473);
          pipe_barrier(PIPE_V);
          TADD(v472, v468, v470);
          // pto: %tail_rope_bf16_inline1088_inline5604__tile
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v474 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %tail_rope_bf16_inline1088_inline5604__tile
          ;
          uint64_t v475 = (uint64_t) v15;
          TASSIGN(v474, v475);
          pipe_barrier(PIPE_V);
          RoundMode v476 = RoundMode::CAST_RINT;
          SaturationMode v477 = SaturationMode::ON;
          TCVT(v474, v472, v476, v477);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
          // pto: %qr_bf16_2d_inline1123_inline5580__iter_v9_pview
          ;
          __gm__ bfloat16_t* v478 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %qr_bf16_2d_inline1123_inline5580__iter_v9_pview
          ;
          const int64_t v479 = 0;
          // pto: %qr_bf16_2d_inline1123_inline5580__iter_v9_pview
          ;
          const int64_t v480 = 8192;
          // pto: %qr_bf16_2d_inline1123_inline5580__iter_v9_pview
          ;
          pto::Shape<1, 1, 1, 1, 64> v481 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %qr_bf16_2d_inline1123_inline5580__iter_v9_pview
          ;
          pto::Stride<8192, 8192, 8192, 8192, 1> v482 = pto::Stride<8192, 8192, 8192, 8192, 1>();
          // pto: %qr_bf16_2d_inline1123_inline5580__iter_v9_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v483 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v478 + (v479 + v370 * v480 + v390), v481, v482);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
          pipe_barrier(PIPE_MTE3);
          TSTORE(v483, v442);
          // pto: %148
          ;
          int64_t v484 = (int64_t) ((uint64_t) v386 + (uint64_t) v35);
          // pto: %149
          ;
          int64_t v485 = v484 < v45 ? v45 : v484;
          // pto: %150
          ;
          __gm__ bfloat16_t* v486 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %150
          ;
          const int64_t v487 = 0;
          // pto: %150
          ;
          const int64_t v488 = 8192;
          // pto: %150
          ;
          pto::Shape<1, 1, 1, 1, 64> v489 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %150
          ;
          pto::Stride<8192, 8192, 8192, 8192, 1> v490 = pto::Stride<8192, 8192, 8192, 8192, 1>();
          // pto: %150
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v491 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v486 + (v487 + v370 * v488 + v485), v489, v490);
          pipe_barrier(PIPE_MTE3);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
          TSTORE(v491, v474);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
          // pto: %52
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v492 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %52
          ;
          uint64_t v493 = (uint64_t) v17;
          TASSIGN(v492, v493);
          // pto: %53
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v494 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %53
          ;
          uint64_t v495 = (uint64_t) v27;
          TASSIGN(v494, v495);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          RoundMode v496 = RoundMode::CAST_NONE;
          SaturationMode v497 = SaturationMode::ON;
          TCVT(v494, v412, v496, v497);
          // pto: %54
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v498 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %54
          ;
          uint64_t v499 = (uint64_t) v17;
          TASSIGN(v498, v499);
          TMULS(v498, v492, v367);
          // pto: %55
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v500 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %55
          ;
          uint64_t v501 = (uint64_t) v17;
          TASSIGN(v500, v501);
          pipe_barrier(PIPE_V);
          TMUL(v500, v494, v498);
          // pto: %56
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v502 = Tile<TileType::Vec, bfloat16_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %56
          ;
          uint64_t v503 = (uint64_t) v27;
          TASSIGN(v502, v503);
          pipe_barrier(PIPE_V);
          RoundMode v504 = RoundMode::CAST_RINT;
          SaturationMode v505 = SaturationMode::ON;
          TCVT(v502, v500, v504, v505);
          // pto: %57
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v506 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v47);
          // pto: %57
          ;
          uint64_t v507 = (uint64_t) v17;
          TASSIGN(v506, v507);
          pipe_barrier(PIPE_V);
          RoundMode v508 = RoundMode::CAST_ROUND;
          SaturationMode v509 = SaturationMode::ON;
          TCVT(v506, v502, v508, v509);
          // pto: %58
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v510 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %58
          ;
          uint64_t v511 = (uint64_t) v17;
          TASSIGN(v510, v511);
          // pto: %151
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v512;
          // pto: %151
          ;
          uint64_t v513 = (uint64_t) v17;
          TASSIGN(v512, v513);
          // pto: %59
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v514 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %59
          ;
          uint64_t v515 = (uint64_t) v30;
          TASSIGN(v514, v515);
          pipe_barrier(PIPE_V);
          RoundMode v516 = RoundMode::CAST_RINT;
          SaturationMode v517 = SaturationMode::ON;
          TCVT(v514, v512, v516, v517);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
          // pto: %60
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v518 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %60
          ;
          uint64_t v519 = (uint64_t) v31;
          TASSIGN(v518, v519);
          // pto: %152
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v520;
          // pto: %152
          ;
          uint64_t v521 = (uint64_t) v31;
          TASSIGN(v520, v521);
          // pto: %61
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v522 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %61
          ;
          uint64_t v523 = (uint64_t) v27;
          TASSIGN(v522, v523);
          // pto: %62
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v524 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %62
          ;
          uint64_t v525 = (uint64_t) v17;
          TASSIGN(v524, v525);
          // pto: %153
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v526;
          // pto: %153
          ;
          uint64_t v527 = (uint64_t) v31;
          TASSIGN(v526, v527);
          // pto: %63
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v528 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %63
          ;
          uint64_t v529 = (uint64_t) v18;
          TASSIGN(v528, v529);
          // pto: %154
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v530;
          // pto: %154
          ;
          uint64_t v531 = (uint64_t) v18;
          TASSIGN(v530, v531);
          // pto: %64
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v532 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %64
          ;
          uint64_t v533 = (uint64_t) v25;
          TASSIGN(v532, v533);
          // pto: %65
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v534 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %65
          ;
          uint64_t v535 = (uint64_t) v26;
          TASSIGN(v534, v535);
          TGATHER(v534, v526, v530, v532);
          // pto: %155
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v536;
          // pto: %155
          ;
          uint64_t v537 = (uint64_t) v27;
          TASSIGN(v536, v537);
          pipe_barrier(PIPE_V);
          TMOV(v536, v534);
          // pto: %67
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v538 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %67
          ;
          uint64_t v539 = (uint64_t) v27;
          TASSIGN(v538, v539);
          // pto: %68
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v540 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %68
          ;
          uint64_t v541 = (uint64_t) v17;
          TASSIGN(v540, v541);
          TMUL(v540, v520, v368);
          // pto: %69
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v542 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %69
          ;
          uint64_t v543 = (uint64_t) v27;
          TASSIGN(v542, v543);
          pipe_barrier(PIPE_V);
          TMUL(v542, v538, v377);
          // pto: %70
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v544 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %70
          ;
          uint64_t v545 = (uint64_t) v17;
          TASSIGN(v544, v545);
          pipe_barrier(PIPE_V);
          TADD(v544, v540, v542);
          // pto: %71
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v546 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v34, v35);
          // pto: %71
          ;
          uint64_t v547 = (uint64_t) v17;
          TASSIGN(v546, v547);
          pipe_barrier(PIPE_V);
          RoundMode v548 = RoundMode::CAST_RINT;
          SaturationMode v549 = SaturationMode::ON;
          TCVT(v546, v544, v548, v549);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
          // pto: %159
          ;
          __gm__ bfloat16_t* v550 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %159
          ;
          const int64_t v551 = 0;
          // pto: %159
          ;
          const int64_t v552 = 8192;
          // pto: %159
          ;
          pto::Shape<1, 1, 1, 1, 64> v553 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %159
          ;
          pto::Stride<8192, 8192, 8192, 8192, 1> v554 = pto::Stride<8192, 8192, 8192, 8192, 1>();
          // pto: %159
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v555 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v550 + (v551 + v370 * v552 + v406), v553, v554);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
          pipe_barrier(PIPE_MTE3);
          TSTORE(v555, v514);
          // pto: %162
          ;
          int64_t v556 = (int64_t) ((uint64_t) v387 + (uint64_t) v35);
          // pto: %163
          ;
          int64_t v557 = v556 < v45 ? v45 : v556;
          // pto: %164
          ;
          __gm__ bfloat16_t* v558 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %164
          ;
          const int64_t v559 = 0;
          // pto: %164
          ;
          const int64_t v560 = 8192;
          // pto: %164
          ;
          pto::Shape<1, 1, 1, 1, 64> v561 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %164
          ;
          pto::Stride<8192, 8192, 8192, 8192, 1> v562 = pto::Stride<8192, 8192, 8192, 8192, 1>();
          // pto: %164
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v563 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v558 + (v559 + v370 * v560 + v557), v561, v562);
          pipe_barrier(PIPE_MTE3);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
          TSTORE(v563, v546);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        };
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      };
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}