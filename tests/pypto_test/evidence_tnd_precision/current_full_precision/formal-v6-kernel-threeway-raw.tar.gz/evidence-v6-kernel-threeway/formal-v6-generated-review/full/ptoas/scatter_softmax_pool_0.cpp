#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void scatter_softmax_pool_0(__gm__ float* v1, __gm__ float* v2, __gm__ float* v3, __gm__ int32_t* v4, __gm__ int64_t* v5, __gm__ int32_t* v6, __gm__ int32_t* v7, __gm__ float* v8, __gm__ float* v9, __gm__ float* v10, __gm__ float* v11, int64_t v12, int64_t v13, int64_t v14, int64_t v15, int64_t v16, int64_t v17, int64_t v18, int64_t v19, int32_t v20, int32_t v21) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v22 = -7;
  // pto: %c768_i64
  const int64_t v23 = 768;
  // pto: %c2816_i64
  const int64_t v24 = 2816;
  // pto: %c0_i64
  const int64_t v25 = 0;
  // pto: %c256_i64
  const int64_t v26 = 256;
  // pto: %c512_i64
  const int64_t v27 = 512;
  const int64_t v28 = 1792;
  const int64_t v29 = 3328;
  const int64_t v30 = 3072;
  const int64_t v31 = 1280;
  const int64_t v32 = 1024;
  // pto: %c384_index
  const int64_t v33 = 384;
  // pto: %c128_index
  const int64_t v34 = 128;
  // pto: %c1_index
  const int64_t v35 = 1;
  // pto: %c256_index
  const int64_t v36 = 256;
  // pto: %c4_index
  const int64_t v37 = 4;
  // pto: %c0_index
  const int64_t v38 = 0;
  // pto: %cst_16
  const float v39 = 0.0f;
  // pto: %c1_i64
  const int64_t v40 = 1;
  // pto: %c4_i64
  const int64_t v41 = 4;
  // pto: %c64_index
  const int64_t v42 = 64;
  // pto: %c8_index
  const int64_t v43 = 8;
  // pto: %cst_22
  const float v44 = -3.40282347E+38f;
  // pto: %c2_i64
  const int64_t v45 = 2;
  // pto: %c512_index
  const int64_t v46 = 512;
  // pto: %c2_index
  const int64_t v47 = 2;
  // pto: %pooled_kv_inline5489__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %pooled_kv_inline5489__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %pooled_kv_inline5489__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %pooled_kv_inline5489__ssa_v0_view
  int64_t v51 = v33 * v34;
  // pto: %pooled_kv_inline5489__ssa_v0_view
  int64_t v52 = v50 * v51;
  // pto: %pooled_kv_inline5489__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v48, v49, v50, v33, v34);
  // pto: %pooled_kv_inline5489__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v49 * v52, v52, v51, v34, v35);
  // pto: %pooled_kv_inline5489__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v53, v54);
  // pto: %window_scores_inline525_inline5440__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %window_scores_inline525_inline5440__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %window_scores_inline525_inline5440__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %window_scores_inline525_inline5440__ssa_v0_view
  int64_t v59 = v33 * v34;
  // pto: %window_scores_inline525_inline5440__ssa_v0_view
  int64_t v60 = v58 * v59;
  // pto: %window_scores_inline525_inline5440__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v61 = pto::Shape<1, 1, 1, -1, -1>(v56, v57, v58, v33, v34);
  // pto: %window_scores_inline525_inline5440__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v62 = pto::Stride<-1, -1, -1, -1, -1>(v57 * v60, v60, v59, v34, v35);
  // pto: %window_scores_inline525_inline5440__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v63 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v61, v62);
  // pto: %window_values_inline513_inline5422__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %window_values_inline513_inline5422__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %window_values_inline513_inline5422__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %window_values_inline513_inline5422__ssa_v0_view
  int64_t v67 = v33 * v34;
  // pto: %window_values_inline513_inline5422__ssa_v0_view
  int64_t v68 = v66 * v67;
  // pto: %window_values_inline513_inline5422__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v69 = pto::Shape<1, 1, 1, -1, -1>(v64, v65, v66, v33, v34);
  // pto: %window_values_inline513_inline5422__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v70 = pto::Stride<-1, -1, -1, -1, -1>(v65 * v68, v68, v67, v34, v35);
  // pto: %window_values_inline513_inline5422__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v71 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v69, v70);
  // pto: %inner_compress_state__ssa_v0_view
  const int64_t v72 = 1;
  // pto: %inner_compress_state__ssa_v0_view
  const int64_t v73 = 1;
  // pto: %inner_compress_state__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %inner_compress_state__ssa_v0_view
  int64_t v75 = (int64_t) v18;
  // pto: %inner_compress_state__ssa_v0_view
  int64_t v76 = (int64_t) v19;
  // pto: %inner_compress_state__ssa_v0_view
  int64_t v77 = v75 * v76;
  // pto: %inner_compress_state__ssa_v0_view
  int64_t v78 = v74 * v77;
  // pto: %inner_compress_state__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v79 = pto::Shape<1, 1, 1, -1, -1>(v72, v73, v74, v75, (int64_t) v19);
  // pto: %inner_compress_state__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v80 = pto::Stride<-1, -1, -1, -1, -1>(v73 * v78, v78, v77, v76, v35);
  // pto: %inner_compress_state__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v81 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v79, v80);
  // pto: %kv_proj_pad_inline5433__rv_v2_view
  const int64_t v82 = 1;
  // pto: %kv_proj_pad_inline5433__rv_v2_view
  const int64_t v83 = 1;
  // pto: %kv_proj_pad_inline5433__rv_v2_view
  const int64_t v84 = 1;
  // pto: %kv_proj_pad_inline5433__rv_v2_view
  int64_t v85 = v33 * v36;
  // pto: %kv_proj_pad_inline5433__rv_v2_view
  int64_t v86 = v84 * v85;
  // pto: %kv_proj_pad_inline5433__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v87 = pto::Shape<1, 1, 1, -1, -1>(v82, v83, v84, v33, v36);
  // pto: %kv_proj_pad_inline5433__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v88 = pto::Stride<-1, -1, -1, -1, -1>(v83 * v86, v86, v85, v36, v35);
  // pto: %kv_proj_pad_inline5433__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v89 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v87, v88);
  // pto: %score_proj_pad_inline5458__rv_v2_view
  const int64_t v90 = 1;
  // pto: %score_proj_pad_inline5458__rv_v2_view
  const int64_t v91 = 1;
  // pto: %score_proj_pad_inline5458__rv_v2_view
  const int64_t v92 = 1;
  // pto: %score_proj_pad_inline5458__rv_v2_view
  int64_t v93 = v33 * v36;
  // pto: %score_proj_pad_inline5458__rv_v2_view
  int64_t v94 = v92 * v93;
  // pto: %score_proj_pad_inline5458__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v95 = pto::Shape<1, 1, 1, -1, -1>(v90, v91, v92, v33, v36);
  // pto: %score_proj_pad_inline5458__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v96 = pto::Stride<-1, -1, -1, -1, -1>(v91 * v94, v94, v93, v36, v35);
  // pto: %score_proj_pad_inline5458__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v97 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v95, v96);
  // pto: %inner_ape__ssa_v0_view
  const int64_t v98 = 1;
  // pto: %inner_ape__ssa_v0_view
  const int64_t v99 = 1;
  // pto: %inner_ape__ssa_v0_view
  const int64_t v100 = 1;
  // pto: %inner_ape__ssa_v0_view
  int64_t v101 = v37 * v36;
  // pto: %inner_ape__ssa_v0_view
  int64_t v102 = v100 * v101;
  // pto: %inner_ape__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v103 = pto::Shape<1, 1, 1, -1, -1>(v98, v99, v100, v37, v36);
  // pto: %inner_ape__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v104 = pto::Stride<-1, -1, -1, -1, -1>(v99 * v102, v102, v101, v36, v35);
  // pto: %inner_ape__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v105 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v11, v103, v104);
  // pto: %score_inline530_inline5439__phi_v4
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %score_inline530_inline5439__phi_v4
  uint64_t v107 = (uint64_t) v27;
  TASSIGN(v106, v107);
  // pto: %value_inline511_inline5464__phi_v3
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %value_inline511_inline5464__phi_v3
  uint64_t v109 = (uint64_t) v26;
  TASSIGN(v108, v109);
  // pto: %score_inline530_inline5439__phi_v3
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %score_inline530_inline5439__phi_v3
  uint64_t v111 = (uint64_t) v27;
  TASSIGN(v110, v111);
  // pto: %value_inline511_inline5464__phi_v2
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %value_inline511_inline5464__phi_v2
  uint64_t v113 = (uint64_t) v26;
  TASSIGN(v112, v113);
  // pto: %score_inline530_inline5439__phi_v7
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %score_inline530_inline5439__phi_v7
  uint64_t v115 = (uint64_t) v24;
  TASSIGN(v114, v115);
  // pto: %value_inline511_inline5464__phi_v6
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %value_inline511_inline5464__phi_v6
  uint64_t v117 = (uint64_t) v23;
  TASSIGN(v116, v117);
  // pto: %score_inline530_inline5439__phi_v6
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %score_inline530_inline5439__phi_v6
  uint64_t v119 = (uint64_t) v24;
  TASSIGN(v118, v119);
  // pto: %value_inline511_inline5464__phi_v5
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %value_inline511_inline5464__phi_v5
  uint64_t v121 = (uint64_t) v23;
  TASSIGN(v120, v121);
  // pto: %pool_worker_inline541_inline5461__ssa_v0
  int64_t v122 = (int64_t) v20;
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v123 = v122; v123 < v12; v123 += v13) {
    // pto: %31
    ;
    int32_t v124 = (v4)[v123];
    // pto: %32
    ;
    int64_t v125 = (int64_t) v124;
    // pto: %34, %33
    ;
    int32_t v126 = (v4)[(int64_t) ((uint64_t) v123 + (uint64_t) v35)];
    // pto: %35
    ;
    int64_t v127 = (int64_t) v126;
    // pto: %37
    ;
    // pto: %first_pos_b_inline542_inline5476__phi_v2
    ;
    int64_t v128;
    if (v125 < v127) {
      // pto: %38
      ;
      int64_t v129 = (v5)[v125];
      v128 = v129;
    } else {
      v128 = v38;
    };
    for (int64_t v130 = v125; v130 < v127; v130 += v35) {
      // pto: %token_pos_inline507_inline5474__tile
      ;
      int64_t v131 = (v5)[v130];
      // pto: %t__tile
      ;
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v34);
      // pto: %t__tile
      ;
      uint64_t v133 = (uint64_t) v23;
      TASSIGN(v132, v133);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      TEXPANDS(v132, v39);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %45
      ;
      int64_t v134 = v130 < v38 ? v38 : v130;
      // pto: %pooled_kv_inline5489__iter_v3_pview
      ;
      __gm__ float* v135 = PTOAS__GLOBAL_TENSOR_DATA(v55);
      // pto: %pooled_kv_inline5489__iter_v3_pview
      ;
      const int64_t v136 = 0;
      // pto: %pooled_kv_inline5489__iter_v3_pview
      ;
      const int64_t v137 = 128;
      // pto: %pooled_kv_inline5489__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 1, 128> v138 = pto::Shape<1, 1, 1, 1, 128>();
      // pto: %pooled_kv_inline5489__iter_v3_pview
      ;
      pto::Stride<128, 128, 128, 128, 1> v139 = pto::Stride<128, 128, 128, 128, 1>();
      // pto: %pooled_kv_inline5489__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v140 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v135 + (v136 + v134 * v137), v138, v139);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v140, v132);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      // pto: %46
      ;
      int32_t v141 = (v6)[v130];
      // pto: %47, %48, %49, %50, %51, %52
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      if ((int64_t) v141 >= v38 & (int64_t) ((uint64_t) v131 + (uint64_t) v40) % v41 == v25) {
        for (int64_t v142 = v38; v142 < v34; v142 += v42) {
          // pto: %55
          ;
          int64_t v143 = (int64_t) ((uint64_t) v122 * (uint64_t) v43);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
          for (int64_t v144 = v38; v144 < v43; v144 += v35) {
            // pto: %57
            ;
            int64_t v145 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v131 + (uint64_t) v22) + (uint64_t) v144);
            // pto: %value_inline511_inline5464__tile
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v146 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
            // pto: %value_inline511_inline5464__tile
            ;
            uint64_t v147 = (uint64_t) v23;
            TASSIGN(v146, v147);
            wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
            pipe_barrier(PIPE_V);
            TEXPANDS(v146, v39);
            // pto: %score_inline530_inline5439__tile
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v148 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
            // pto: %score_inline530_inline5439__tile
            ;
            uint64_t v149 = (uint64_t) v24;
            TASSIGN(v148, v149);
            wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
            TEXPANDS(v148, v44);
            // pto: %58, %state_half_inline523_inline5425__phi_v2
            ;
            int64_t v150 = v144 >= v37 ? v34 : v38;
            // pto: %62
            ;
            bool v151 = v145 < v128;
            // pto: %60, %63
            ;
            wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
            if (v145 >= v38 & v151) {
              // pto: %0
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v152 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
              // pto: %0
              ;
              uint64_t v153 = (uint64_t) v25;
              TASSIGN(v152, v153);
              TEXPANDS(v152, v39);
              // pto: %flat_offset_mul, %flat_offset, %65, %64
              ;
              int32_t v154 = (v7)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v123 * (uint64_t) v17) + (uint64_t) (v145 / v45))];
              // pto: %67
              ;
              int64_t v155 = (int64_t) v154;
              // pto: %68
              ;
              if (v155 >= v38) {
                // pto: %69, %71, %72, %73
                ;
                int64_t v156 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) (v145 % v45) * (uint64_t) v46) + (uint64_t) v150) + (uint64_t) v142);
                // pto: %1
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %1
                ;
                uint64_t v158 = (uint64_t) v26;
                TASSIGN(v157, v158);
                // pto: %74
                ;
                int64_t v159 = v155 < v38 ? v38 : v155;
                // pto: %75
                ;
                int64_t v160 = v156 < v38 ? v38 : v156;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                int64_t v161 = (int64_t) v19;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                const int64_t v162 = 0;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                __gm__ float* v163 = PTOAS__GLOBAL_TENSOR_DATA(v81);
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                const int64_t v164 = 1;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                const int64_t v165 = 1;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                const int64_t v166 = 1;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                int64_t v167 = v35 * v161;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                int64_t v168 = v166 * v167;
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                pto::Shape<1, 1, 1, 1, 64> v169 = pto::Shape<1, 1, 1, 1, 64>(v164, v165, v166, v35, v42);
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                pto::Stride<-1, -1, -1, -1, -1> v170 = pto::Stride<-1, -1, -1, -1, -1>(v165 * v168, v168, v167, v161, v35);
                // pto: %inner_compress_state__ssa_v0_pview
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v171 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v163 + (v162 + v159 * v161 + v160 * v35), v169, v170);
                TLOAD(v157, v171);
                // pto: %2
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v172 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %2
                ;
                uint64_t v173 = (uint64_t) v27;
                TASSIGN(v172, v173);
                // pto: %77
                ;
                int64_t v174 = (int64_t) ((uint64_t) v156 + (uint64_t) v36);
                // pto: %78
                ;
                int64_t v175 = v174 < v38 ? v38 : v174;
                // pto: %79
                ;
                int64_t v176 = (int64_t) v19;
                // pto: %79
                ;
                const int64_t v177 = 0;
                // pto: %79
                ;
                __gm__ float* v178 = PTOAS__GLOBAL_TENSOR_DATA(v81);
                // pto: %79
                ;
                const int64_t v179 = 1;
                // pto: %79
                ;
                const int64_t v180 = 1;
                // pto: %79
                ;
                const int64_t v181 = 1;
                // pto: %79
                ;
                int64_t v182 = v35 * v176;
                // pto: %79
                ;
                int64_t v183 = v181 * v182;
                // pto: %79
                ;
                pto::Shape<1, 1, 1, 1, 64> v184 = pto::Shape<1, 1, 1, 1, 64>(v179, v180, v181, v35, v42);
                // pto: %79
                ;
                pto::Stride<-1, -1, -1, -1, -1> v185 = pto::Stride<-1, -1, -1, -1, -1>(v180 * v183, v183, v182, v176, v35);
                // pto: %79
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v186 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v178 + (v177 + v159 * v176 + v175 * v35), v184, v185);
                TLOAD(v172, v186);
              } else {
                // pto: %score_inline530_inline5439__tile_mv
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v187 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %score_inline530_inline5439__tile_mv
                ;
                uint64_t v188 = (uint64_t) v27;
                TASSIGN(v187, v188);
                pipe_barrier(PIPE_V);
                TMOV(v187, v152);
                // pto: %value_inline511_inline5464__tile_mv
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v189 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %value_inline511_inline5464__tile_mv
                ;
                uint64_t v190 = (uint64_t) v26;
                TASSIGN(v189, v190);
                TMOV(v189, v146);
              };
            } else {
              // pto: %3
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v191 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
              // pto: %3
              ;
              uint64_t v192 = (uint64_t) v27;
              TASSIGN(v191, v192);
              pipe_barrier(PIPE_V);
              TMOV(v191, v148);
              // pto: %4
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v193 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
              // pto: %4
              ;
              uint64_t v194 = (uint64_t) v26;
              TASSIGN(v193, v194);
              TMOV(v193, v146);
            };
            set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
            // pto: %81
            ;
            bool v195 = v128 <= v145;
            wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
            wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
            if (v195) {
              // pto: %82
              ;
              if (v145 <= v131) {
                // pto: %85
                ;
                uint64_t v196 = (uint64_t) v128;
                // pto: %84, %85
                ;
                int64_t v197 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v125 + (uint64_t) v145) - v196);
                // pto: %86
                ;
                int64_t v198 = v145 % v41;
                // pto: %5
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %5
                ;
                uint64_t v200 = (uint64_t) v23;
                TASSIGN(v199, v200);
                // pto: %88
                ;
                int64_t v201 = v197 < v38 ? v38 : v197;
                // pto: %89
                ;
                int64_t v202 = (int64_t) ((uint64_t) v150 + (uint64_t) v142);
                // pto: %90
                ;
                int64_t v203 = v202 < v38 ? v38 : v202;
                // pto: %kv_proj_pad_inline5433__rv_v2_pview
                ;
                __gm__ float* v204 = PTOAS__GLOBAL_TENSOR_DATA(v89);
                // pto: %kv_proj_pad_inline5433__rv_v2_pview
                ;
                const int64_t v205 = 0;
                // pto: %kv_proj_pad_inline5433__rv_v2_pview
                ;
                const int64_t v206 = 256;
                // pto: %kv_proj_pad_inline5433__rv_v2_pview
                ;
                pto::Shape<1, 1, 1, 1, 64> v207 = pto::Shape<1, 1, 1, 1, 64>();
                // pto: %kv_proj_pad_inline5433__rv_v2_pview
                ;
                pto::Stride<256, 256, 256, 256, 1> v208 = pto::Stride<256, 256, 256, 256, 1>();
                // pto: %kv_proj_pad_inline5433__rv_v2_pview
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v209 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v204 + (v205 + v201 * v206 + v203), v207, v208);
                TLOAD(v199, v209);
                // pto: %6
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %6
                ;
                uint64_t v211 = (uint64_t) v24;
                TASSIGN(v210, v211);
                // pto: %score_proj_pad_inline5458__rv_v2_pview
                ;
                __gm__ float* v212 = PTOAS__GLOBAL_TENSOR_DATA(v97);
                // pto: %score_proj_pad_inline5458__rv_v2_pview
                ;
                const int64_t v213 = 0;
                // pto: %score_proj_pad_inline5458__rv_v2_pview
                ;
                const int64_t v214 = 256;
                // pto: %score_proj_pad_inline5458__rv_v2_pview
                ;
                pto::Shape<1, 1, 1, 1, 64> v215 = pto::Shape<1, 1, 1, 1, 64>();
                // pto: %score_proj_pad_inline5458__rv_v2_pview
                ;
                pto::Stride<256, 256, 256, 256, 1> v216 = pto::Stride<256, 256, 256, 256, 1>();
                // pto: %score_proj_pad_inline5458__rv_v2_pview
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v217 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v212 + (v213 + v201 * v214 + v203), v215, v216);
                TLOAD(v210, v217);
                // pto: %7
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %7
                ;
                uint64_t v219 = (uint64_t) v25;
                TASSIGN(v218, v219);
                // pto: %94
                ;
                int64_t v220 = v198 < v38 ? v38 : v198;
                // pto: %inner_ape__ssa_v0_pview
                ;
                __gm__ float* v221 = PTOAS__GLOBAL_TENSOR_DATA(v105);
                // pto: %inner_ape__ssa_v0_pview
                ;
                const int64_t v222 = 0;
                // pto: %inner_ape__ssa_v0_pview
                ;
                const int64_t v223 = 256;
                // pto: %inner_ape__ssa_v0_pview
                ;
                pto::Shape<1, 1, 1, 1, 64> v224 = pto::Shape<1, 1, 1, 1, 64>();
                // pto: %inner_ape__ssa_v0_pview
                ;
                pto::Stride<256, 256, 256, 256, 1> v225 = pto::Stride<256, 256, 256, 256, 1>();
                // pto: %inner_ape__ssa_v0_pview
                ;
                GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v226 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v221 + (v222 + v220 * v223 + v203), v224, v225);
                TLOAD(v218, v226);
                set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
                // pto: %8
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %8
                ;
                uint64_t v228 = (uint64_t) v24;
                TASSIGN(v227, v228);
                wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
                TADD(v227, v210, v218);
              } else {
                // pto: %score_inline530_inline5439__phi_v4_mv
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v229 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %score_inline530_inline5439__phi_v4_mv
                ;
                uint64_t v230 = (uint64_t) v24;
                TASSIGN(v229, v230);
                pipe_barrier(PIPE_V);
                TMOV(v229, v106);
                // pto: %value_inline511_inline5464__phi_v3_mv
                ;
                Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v231 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
                // pto: %value_inline511_inline5464__phi_v3_mv
                ;
                uint64_t v232 = (uint64_t) v23;
                TASSIGN(v231, v232);
                TMOV(v231, v108);
              };
            } else {
              // pto: %9
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
              // pto: %9
              ;
              uint64_t v234 = (uint64_t) v24;
              TASSIGN(v233, v234);
              pipe_barrier(PIPE_V);
              TMOV(v233, v106);
              // pto: %10
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
              // pto: %10
              ;
              uint64_t v236 = (uint64_t) v23;
              TASSIGN(v235, v236);
              TMOV(v235, v108);
            };
            set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
            set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
            set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
            // pto: %101, %97, %98, %100, %99
            ;
            int64_t v237 = (int64_t) ((uint64_t) v143 + (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) (v144 % v37) * (uint64_t) v47) + (uint64_t) (v144 / v37)));
            // pto: %102
            ;
            int64_t v238 = v237 < v38 ? v38 : v237;
            // pto: %103
            ;
            int64_t v239 = v142 < v38 ? v38 : v142;
            // pto: %window_values_inline513_inline5422__iter_v7_pview
            ;
            __gm__ float* v240 = PTOAS__GLOBAL_TENSOR_DATA(v71);
            // pto: %window_values_inline513_inline5422__iter_v7_pview
            ;
            const int64_t v241 = 0;
            // pto: %window_values_inline513_inline5422__iter_v7_pview
            ;
            const int64_t v242 = 128;
            // pto: %window_values_inline513_inline5422__iter_v7_pview
            ;
            pto::Shape<1, 1, 1, 1, 64> v243 = pto::Shape<1, 1, 1, 1, 64>();
            // pto: %window_values_inline513_inline5422__iter_v7_pview
            ;
            pto::Stride<128, 128, 128, 128, 1> v244 = pto::Stride<128, 128, 128, 128, 1>();
            // pto: %window_values_inline513_inline5422__iter_v7_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v245 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v240 + (v241 + v238 * v242 + v239), v243, v244);
            wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
            wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
            TSTORE(v245, v116);
            set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
            // pto: %window_scores_inline525_inline5440__iter_v7_pview
            ;
            __gm__ float* v246 = PTOAS__GLOBAL_TENSOR_DATA(v63);
            // pto: %window_scores_inline525_inline5440__iter_v7_pview
            ;
            const int64_t v247 = 0;
            // pto: %window_scores_inline525_inline5440__iter_v7_pview
            ;
            const int64_t v248 = 128;
            // pto: %window_scores_inline525_inline5440__iter_v7_pview
            ;
            pto::Shape<1, 1, 1, 1, 64> v249 = pto::Shape<1, 1, 1, 1, 64>();
            // pto: %window_scores_inline525_inline5440__iter_v7_pview
            ;
            pto::Stride<128, 128, 128, 128, 1> v250 = pto::Stride<128, 128, 128, 128, 1>();
            // pto: %window_scores_inline525_inline5440__iter_v7_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v251 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v246 + (v247 + v238 * v248 + v239), v249, v250);
            TSTORE(v251, v114);
            set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
          };
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
          // pto: %score_rows_inline548_inline5468__tile
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v252 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v42);
          // pto: %score_rows_inline548_inline5468__tile
          ;
          uint64_t v253 = (uint64_t) v23;
          TASSIGN(v252, v253);
          // pto: %106
          ;
          int64_t v254 = v143 < v38 ? v38 : v143;
          // pto: %107
          ;
          int64_t v255 = v142 < v38 ? v38 : v142;
          // pto: %window_scores_inline525_inline5440__rv_v8_pview
          ;
          __gm__ float* v256 = PTOAS__GLOBAL_TENSOR_DATA(v63);
          // pto: %window_scores_inline525_inline5440__rv_v8_pview
          ;
          const int64_t v257 = 0;
          // pto: %window_scores_inline525_inline5440__rv_v8_pview
          ;
          const int64_t v258 = 128;
          // pto: %window_scores_inline525_inline5440__rv_v8_pview
          ;
          pto::Shape<1, 1, 1, 8, 64> v259 = pto::Shape<1, 1, 1, 8, 64>();
          // pto: %window_scores_inline525_inline5440__rv_v8_pview
          ;
          pto::Stride<1024, 1024, 1024, 128, 1> v260 = pto::Stride<1024, 1024, 1024, 128, 1>();
          // pto: %window_scores_inline525_inline5440__rv_v8_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<1024, 1024, 1024, 128, 1>, pto::Layout::ND> v261 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<1024, 1024, 1024, 128, 1>, pto::Layout::ND>(v256 + (v257 + v254 * v258 + v255), v259, v260);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
          TLOAD(v252, v261);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          // pto: %11
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v262 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %11
          ;
          uint64_t v263 = (uint64_t) v23;
          TASSIGN(v262, v263);
          // pto: %slice_view
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, 4, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v264;
          // pto: %slice_view
          ;
          uint64_t v265 = (uint64_t) v23;
          TASSIGN(v264, v265);
          // pto: %12
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %12
          ;
          uint64_t v267 = (uint64_t) v28;
          TASSIGN(v266, v267);
          // pto: %108
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, 4, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v268;
          // pto: %108
          ;
          uint64_t v269 = (uint64_t) v28;
          TASSIGN(v268, v269);
          // pto: %max4_inline558_inline5429__tile
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %max4_inline558_inline5429__tile
          ;
          uint64_t v271 = (uint64_t) v24;
          TASSIGN(v270, v271);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          TMAX(v270, v264, v268);
          // pto: %13
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v272 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %13
          ;
          uint64_t v273 = (uint64_t) v24;
          TASSIGN(v272, v273);
          // pto: %109
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, 2, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v274;
          // pto: %109
          ;
          uint64_t v275 = (uint64_t) v24;
          TASSIGN(v274, v275);
          // pto: %14
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v276 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %14
          ;
          uint64_t v277 = (uint64_t) v29;
          TASSIGN(v276, v277);
          // pto: %110
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, 2, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v278;
          // pto: %110
          ;
          uint64_t v279 = (uint64_t) v29;
          TASSIGN(v278, v279);
          // pto: %max2_inline519_inline5453__tile
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v280 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %max2_inline519_inline5453__tile
          ;
          uint64_t v281 = (uint64_t) v24;
          TASSIGN(v280, v281);
          pipe_barrier(PIPE_V);
          TMAX(v280, v274, v278);
          // pto: %15
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v282 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %15
          ;
          uint64_t v283 = (uint64_t) v24;
          TASSIGN(v282, v283);
          // pto: %111
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v284;
          // pto: %111
          ;
          uint64_t v285 = (uint64_t) v24;
          TASSIGN(v284, v285);
          // pto: %16
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %16
          ;
          uint64_t v287 = (uint64_t) v30;
          TASSIGN(v286, v287);
          // pto: %112
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v288;
          // pto: %112
          ;
          uint64_t v289 = (uint64_t) v30;
          TASSIGN(v288, v289);
          // pto: %maximum_inline545_inline5488__tile
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %maximum_inline545_inline5488__tile
          ;
          uint64_t v291 = (uint64_t) v24;
          TASSIGN(v290, v291);
          pipe_barrier(PIPE_V);
          TMAX(v290, v284, v288);
          // pto: %17
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v292 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v42);
          // pto: %17
          ;
          uint64_t v293 = (uint64_t) v23;
          TASSIGN(v292, v293);
          pipe_barrier(PIPE_V);
          TCOLEXPANDSUB(v292, v252, v290);
          // pto: %probability_inline547_inline5490__tile
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v294 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v42);
          // pto: %probability_inline547_inline5490__tile
          ;
          uint64_t v295 = (uint64_t) v23;
          TASSIGN(v294, v295);
          pipe_barrier(PIPE_V);
          TEXP(v294, v292);
          // pto: %18
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %18
          ;
          uint64_t v297 = (uint64_t) v23;
          TASSIGN(v296, v297);
          // pto: %113
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, 4, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v298;
          // pto: %113
          ;
          uint64_t v299 = (uint64_t) v23;
          TASSIGN(v298, v299);
          // pto: %19
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v300 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %19
          ;
          uint64_t v301 = (uint64_t) v28;
          TASSIGN(v300, v301);
          // pto: %114
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, 4, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v302;
          // pto: %114
          ;
          uint64_t v303 = (uint64_t) v28;
          TASSIGN(v302, v303);
          // pto: %sum4_inline506_inline5492__tile
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v304 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %sum4_inline506_inline5492__tile
          ;
          uint64_t v305 = (uint64_t) v24;
          TASSIGN(v304, v305);
          pipe_barrier(PIPE_V);
          TADD(v304, v298, v302);
          // pto: %20
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %20
          ;
          uint64_t v307 = (uint64_t) v24;
          TASSIGN(v306, v307);
          // pto: %115
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, 2, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v308;
          // pto: %115
          ;
          uint64_t v309 = (uint64_t) v24;
          TASSIGN(v308, v309);
          // pto: %21
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v310 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %21
          ;
          uint64_t v311 = (uint64_t) v29;
          TASSIGN(v310, v311);
          // pto: %116
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, 2, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v312;
          // pto: %116
          ;
          uint64_t v313 = (uint64_t) v29;
          TASSIGN(v312, v313);
          // pto: %sum2_inline508_inline5459__tile
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v314 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %sum2_inline508_inline5459__tile
          ;
          uint64_t v315 = (uint64_t) v24;
          TASSIGN(v314, v315);
          pipe_barrier(PIPE_V);
          TADD(v314, v308, v312);
          // pto: %22
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v316 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %22
          ;
          uint64_t v317 = (uint64_t) v24;
          TASSIGN(v316, v317);
          // pto: %117
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v318;
          // pto: %117
          ;
          uint64_t v319 = (uint64_t) v24;
          TASSIGN(v318, v319);
          // pto: %23
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v320 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %23
          ;
          uint64_t v321 = (uint64_t) v30;
          TASSIGN(v320, v321);
          // pto: %118
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v322;
          // pto: %118
          ;
          uint64_t v323 = (uint64_t) v30;
          TASSIGN(v322, v323);
          // pto: %total_inline516_inline5438__tile
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v324 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %total_inline516_inline5438__tile
          ;
          uint64_t v325 = (uint64_t) v24;
          TASSIGN(v324, v325);
          pipe_barrier(PIPE_V);
          TADD(v324, v318, v322);
          // pto: %probability_v1_inline553_inline5417__tile
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v326 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v42);
          // pto: %probability_v1_inline553_inline5417__tile
          ;
          uint64_t v327 = (uint64_t) v23;
          TASSIGN(v326, v327);
          pipe_barrier(PIPE_V);
          TCOLEXPANDDIV(v326, v294, v324);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
          // pto: %value_rows_inline554_inline5416__tile
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v42);
          // pto: %value_rows_inline554_inline5416__tile
          ;
          uint64_t v329 = (uint64_t) v24;
          TASSIGN(v328, v329);
          // pto: %window_values_inline513_inline5422__rv_v8_pview
          ;
          __gm__ float* v330 = PTOAS__GLOBAL_TENSOR_DATA(v71);
          // pto: %window_values_inline513_inline5422__rv_v8_pview
          ;
          const int64_t v331 = 0;
          // pto: %window_values_inline513_inline5422__rv_v8_pview
          ;
          const int64_t v332 = 128;
          // pto: %window_values_inline513_inline5422__rv_v8_pview
          ;
          pto::Shape<1, 1, 1, 8, 64> v333 = pto::Shape<1, 1, 1, 8, 64>();
          // pto: %window_values_inline513_inline5422__rv_v8_pview
          ;
          pto::Stride<1024, 1024, 1024, 128, 1> v334 = pto::Stride<1024, 1024, 1024, 128, 1>();
          // pto: %window_values_inline513_inline5422__rv_v8_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<1024, 1024, 1024, 128, 1>, pto::Layout::ND> v335 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<1024, 1024, 1024, 128, 1>, pto::Layout::ND>(v330 + (v331 + v254 * v332 + v255), v333, v334);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
          TLOAD(v328, v335);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          // pto: %weighted_inline528_inline5415__tile
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v336 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v42);
          // pto: %weighted_inline528_inline5415__tile
          ;
          uint64_t v337 = (uint64_t) v23;
          TASSIGN(v336, v337);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          TMUL(v336, v328, v326);
          // pto: %24
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v338 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %24
          ;
          uint64_t v339 = (uint64_t) v23;
          TASSIGN(v338, v339);
          // pto: %121
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, 4, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v340;
          // pto: %121
          ;
          uint64_t v341 = (uint64_t) v23;
          TASSIGN(v340, v341);
          // pto: %25
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v342 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %25
          ;
          uint64_t v343 = (uint64_t) v28;
          TASSIGN(v342, v343);
          // pto: %122
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, 4, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v344;
          // pto: %122
          ;
          uint64_t v345 = (uint64_t) v28;
          TASSIGN(v344, v345);
          // pto: %weighted4_inline559_inline5412__tile
          ;
          Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v346 = Tile<TileType::Vec, float, 4, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v37, v42);
          // pto: %weighted4_inline559_inline5412__tile
          ;
          uint64_t v347 = (uint64_t) v23;
          TASSIGN(v346, v347);
          pipe_barrier(PIPE_V);
          TADD(v346, v340, v344);
          // pto: %26
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v348 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %26
          ;
          uint64_t v349 = (uint64_t) v23;
          TASSIGN(v348, v349);
          // pto: %123
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, 2, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v350;
          // pto: %123
          ;
          uint64_t v351 = (uint64_t) v23;
          TASSIGN(v350, v351);
          // pto: %27
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v352 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %27
          ;
          uint64_t v353 = (uint64_t) v31;
          TASSIGN(v352, v353);
          // pto: %124
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, 2, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v354;
          // pto: %124
          ;
          uint64_t v355 = (uint64_t) v31;
          TASSIGN(v354, v355);
          // pto: %weighted2_inline549_inline5411__tile
          ;
          Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v356 = Tile<TileType::Vec, float, 2, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %weighted2_inline549_inline5411__tile
          ;
          uint64_t v357 = (uint64_t) v23;
          TASSIGN(v356, v357);
          pipe_barrier(PIPE_V);
          TADD(v356, v350, v354);
          // pto: %28
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v358 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %28
          ;
          uint64_t v359 = (uint64_t) v23;
          TASSIGN(v358, v359);
          // pto: %125
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v360;
          // pto: %125
          ;
          uint64_t v361 = (uint64_t) v23;
          TASSIGN(v360, v361);
          // pto: %29
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v362 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %29
          ;
          uint64_t v363 = (uint64_t) v32;
          TASSIGN(v362, v363);
          // pto: %126
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v364;
          // pto: %126
          ;
          uint64_t v365 = (uint64_t) v32;
          TASSIGN(v364, v365);
          // pto: %30
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v366 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
          // pto: %30
          ;
          uint64_t v367 = (uint64_t) v23;
          TASSIGN(v366, v367);
          pipe_barrier(PIPE_V);
          TADD(v366, v360, v364);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          // pto: %pooled_kv_inline5489__iter_v6_pview
          ;
          __gm__ float* v368 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %pooled_kv_inline5489__iter_v6_pview
          ;
          const int64_t v369 = 0;
          // pto: %pooled_kv_inline5489__iter_v6_pview
          ;
          const int64_t v370 = 128;
          // pto: %pooled_kv_inline5489__iter_v6_pview
          ;
          pto::Shape<1, 1, 1, 1, 64> v371 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %pooled_kv_inline5489__iter_v6_pview
          ;
          pto::Stride<128, 128, 128, 128, 1> v372 = pto::Stride<128, 128, 128, 128, 1>();
          // pto: %pooled_kv_inline5489__iter_v6_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v373 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v368 + (v369 + v134 * v370 + v255), v371, v372);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          TSTORE(v373, v366);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        };
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}