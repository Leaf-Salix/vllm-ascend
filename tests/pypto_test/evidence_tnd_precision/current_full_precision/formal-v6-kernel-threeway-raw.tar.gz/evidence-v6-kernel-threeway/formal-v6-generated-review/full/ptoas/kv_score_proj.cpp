#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void kv_score_proj(__gm__ int32_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ bfloat16_t* v4, __gm__ bfloat16_t* v5, __gm__ bfloat16_t* v6, int64_t v7, int64_t v8, int64_t v9, int64_t v10, int32_t v11, int32_t v12) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int32_t v13 = 0;
  // pto: %c0_i64
  const int64_t v14 = 0;
  // pto: %c8192_i64
  const int64_t v15 = 8192;
  // pto: %c16384_i64
  const int64_t v16 = 16384;
  // pto: %c24576_i64
  const int64_t v17 = 24576;
  // pto: %c32768_i64
  const int64_t v18 = 32768;
  // pto: %c49152_i64
  const int64_t v19 = 49152;
  // pto: %c57344_i64
  const int64_t v20 = 57344;
  // pto: %c1_index
  const int64_t v21 = 1;
  // pto: %c384_index
  const int64_t v22 = 384;
  // pto: %c1024_index
  const int64_t v23 = 1024;
  // pto: %c4096_index
  const int64_t v24 = 4096;
  // pto: %c0_index
  const int64_t v25 = 0;
  // pto: %c64_index
  const int64_t v26 = 64;
  // pto: %c32_index
  const int64_t v27 = 32;
  // pto: %c2_index
  const int64_t v28 = 2;
  // pto: %c24_index
  const int64_t v29 = 24;
  // pto: %c128_index
  const int64_t v30 = 128;
  // pto: %c512_index
  const int64_t v31 = 512;
  // pto: %c256_index
  const int64_t v32 = 256;
  // pto: %cmp4_kv_proj_pad_inline598_inline5267__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %cmp4_kv_proj_pad_inline598_inline5267__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %cmp4_kv_proj_pad_inline598_inline5267__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %cmp4_kv_proj_pad_inline598_inline5267__ssa_v0_view
  int64_t v36 = v22 * v23;
  // pto: %cmp4_kv_proj_pad_inline598_inline5267__ssa_v0_view
  int64_t v37 = v35 * v36;
  // pto: %cmp4_kv_proj_pad_inline598_inline5267__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v38 = pto::Shape<1, 1, 1, -1, -1>(v33, v34, v35, v22, v23);
  // pto: %cmp4_kv_proj_pad_inline598_inline5267__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v39 = pto::Stride<-1, -1, -1, -1, -1>(v34 * v37, v37, v36, v23, v21);
  // pto: %cmp4_kv_proj_pad_inline598_inline5267__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v40 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v38, v39);
  // pto: %cmp4_score_proj_pad_inline599_inline5272__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %cmp4_score_proj_pad_inline599_inline5272__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %cmp4_score_proj_pad_inline599_inline5272__ssa_v0_view
  const int64_t v43 = 1;
  // pto: %cmp4_score_proj_pad_inline599_inline5272__ssa_v0_view
  int64_t v44 = v22 * v23;
  // pto: %cmp4_score_proj_pad_inline599_inline5272__ssa_v0_view
  int64_t v45 = v43 * v44;
  // pto: %cmp4_score_proj_pad_inline599_inline5272__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v46 = pto::Shape<1, 1, 1, -1, -1>(v41, v42, v43, v22, v23);
  // pto: %cmp4_score_proj_pad_inline599_inline5272__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v47 = pto::Stride<-1, -1, -1, -1, -1>(v42 * v45, v45, v44, v23, v21);
  // pto: %cmp4_score_proj_pad_inline599_inline5272__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v48 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v46, v47);
  // pto: %x_flat_inline596_inline5265__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %x_flat_inline596_inline5265__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %x_flat_inline596_inline5265__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %x_flat_inline596_inline5265__ssa_v0_view
  int64_t v52 = (int64_t) v10;
  // pto: %x_flat_inline596_inline5265__ssa_v0_view
  int64_t v53 = v52 * v24;
  // pto: %x_flat_inline596_inline5265__ssa_v0_view
  int64_t v54 = v51 * v53;
  // pto: %x_flat_inline596_inline5265__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v55 = pto::Shape<1, 1, 1, -1, -1>(v49, v50, v51, v52, v24);
  // pto: %x_flat_inline596_inline5265__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v56 = pto::Stride<-1, -1, -1, -1, -1>(v50 * v54, v54, v53, v24, v21);
  // pto: %x_flat_inline596_inline5265__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v57 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v55, v56);
  // pto: %cmp_wkv__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %cmp_wkv__ssa_v0_view
  const int64_t v59 = 1;
  // pto: %cmp_wkv__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %cmp_wkv__ssa_v0_view
  int64_t v61 = v23 * v24;
  // pto: %cmp_wkv__ssa_v0_view
  int64_t v62 = v60 * v61;
  // pto: %cmp_wkv__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v63 = pto::Shape<1, 1, 1, -1, -1>(v58, v59, v60, v23, v24);
  // pto: %cmp_wkv__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v59 * v62, v62, v61, v24, v21);
  // pto: %cmp_wkv__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v65 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v63, v64);
  // pto: %cmp_wgate__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %cmp_wgate__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %cmp_wgate__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %cmp_wgate__ssa_v0_view
  int64_t v69 = v23 * v24;
  // pto: %cmp_wgate__ssa_v0_view
  int64_t v70 = v68 * v69;
  // pto: %cmp_wgate__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v71 = pto::Shape<1, 1, 1, -1, -1>(v66, v67, v68, v23, v24);
  // pto: %cmp_wgate__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v70, v70, v69, v24, v21);
  // pto: %cmp_wgate__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v71, v72);
  // pto: %kv_acc_inline601_inline5270__phi_v5
  Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v74 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v27);
  // pto: %kv_acc_inline601_inline5270__phi_v5
  uint64_t v75 = (uint64_t) v14;
  TASSIGN(v74, v75);
  // pto: %score_acc_inline593_inline5261__phi_v5
  Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v76 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v27);
  // pto: %score_acc_inline593_inline5261__phi_v5
  uint64_t v77 = (uint64_t) v15;
  TASSIGN(v76, v77);
  // pto: %kv_worker_inline595_inline5274__ssa_v0
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  // pto: %t__tile
  int32_t v78 = (v1)[v21];
  // pto: %19
  int32_t v79 = (v1)[v25];
  // pto: %22
  // pto: %deviation_inline8536__rv_v2
  int32_t v80;
  v80 = v13;
  for (int64_t v81 = v21; v81 < ((int64_t) ((uint64_t) v9 - (uint64_t) v21)); v81 += v21) {
    // pto: %24, %23
    ;
    int32_t v82 = (v1)[(int64_t) ((uint64_t) v81 + (uint64_t) v21)];
    // pto: %25
    ;
    int32_t v83 = (v1)[v81];
    // pto: %26, %27, %20
    ;
    int32_t v84 = (int32_t) ((uint32_t) ((int32_t) (uint32_t) v82 - (uint32_t) v83) - (uint32_t) ((int32_t) (uint32_t) v78 - (uint32_t) v79));
    // pto: %29
    ;
    uint32_t v85 = (uint32_t) v80;
    // pto: %28, %29
    ;
    v80 = (int32_t) (v85 + (uint32_t) ((int32_t) (uint32_t) v84 * (uint32_t) v84));
  }
  // pto: %31
  int64_t v86 = (int64_t) v80;
  // pto: %32, %33, %34, %group_inline8534__phi_v4
  int64_t v87 = v86 == v25 & v7 <= v22 ? v27 : v26;
  // pto: %36
  for (int64_t v88 = (int64_t) v11; v88 < (v8 / v28); v88 += v29) {
    // pto: %37, %38
    ;
    int64_t v89 = (int64_t) ((uint64_t) (v88 / v27) * (uint64_t) v26);
    // pto: %39, %40
    ;
    int64_t v90 = (int64_t) ((uint64_t) (v88 % v27) * (uint64_t) v27);
    // pto: %41
    ;
    int64_t v91 = (int64_t) ((uint64_t) v7 - (uint64_t) v89);
    // pto: %42
    ;
    int64_t v92 = v91 < v26 ? v91 : v26;
    // pto: %kv_acc_inline601_inline5270__tile
    ;
    Tile<TileType::Vec, float, 64, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Vec, float, 64, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v27);
    // pto: %kv_acc_inline601_inline5270__tile
    ;
    uint64_t v94 = (uint64_t) v14;
    TASSIGN(v93, v94);
    // pto: %score_acc_inline593_inline5261__tile
    ;
    Tile<TileType::Vec, float, 64, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Vec, float, 64, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v26, v27);
    // pto: %score_acc_inline593_inline5261__tile
    ;
    uint64_t v96 = (uint64_t) v14;
    TASSIGN(v95, v96);
    // pto: %kv_acc_inline601_inline5270__tile_narrowed_storage
    ;
    Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v97 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v27);
    // pto: %kv_acc_inline601_inline5270__tile_narrowed_storage
    ;
    uint64_t v98 = (uint64_t) v14;
    TASSIGN(v97, v98);
    v97.SetValidShape(v92, v27);
    // pto: %score_acc_inline593_inline5261__tile_narrowed_storage
    ;
    Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v99 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v27);
    // pto: %score_acc_inline593_inline5261__tile_narrowed_storage
    ;
    uint64_t v100 = (uint64_t) v15;
    TASSIGN(v99, v100);
    v99.SetValidShape(v92, v27);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    for (int64_t v101 = v25; v101 < v27; v101 += v28) {
      // pto: %43, %47, %44, %45, %46
      ;
      int64_t v102 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v101 * (uint64_t) v30) + (uint64_t) ((int64_t) (uint64_t) (v90 % v31 / v87) * (uint64_t) v32));
      // pto: %48
      ;
      int64_t v103 = v102 % v24;
      // pto: %54, %55
      ;
      int64_t v104 = (int64_t) ((uint64_t) v102 + (uint64_t) v30) % v24;
      // pto: %x_tile_inline589_inline5264__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v105 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v92, v30);
      // pto: %x_tile_inline589_inline5264__tile
      ;
      uint64_t v106 = (uint64_t) v14;
      TASSIGN(v105, v106);
      // pto: %56
      ;
      int64_t v107 = v89 < v25 ? v25 : v89;
      // pto: %57
      ;
      int64_t v108 = v103 < v25 ? v25 : v103;
      // pto: %x_flat_inline596_inline5265__ssa_v0_pview
      ;
      const int64_t v109 = 0;
      // pto: %x_flat_inline596_inline5265__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v110 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %x_flat_inline596_inline5265__ssa_v0_pview
      ;
      const int64_t v111 = 1;
      // pto: %x_flat_inline596_inline5265__ssa_v0_pview
      ;
      const int64_t v112 = 1;
      // pto: %x_flat_inline596_inline5265__ssa_v0_pview
      ;
      const int64_t v113 = 1;
      // pto: %x_flat_inline596_inline5265__ssa_v0_pview
      ;
      int64_t v114 = v92 * v24;
      // pto: %x_flat_inline596_inline5265__ssa_v0_pview
      ;
      int64_t v115 = v113 * v114;
      // pto: %x_flat_inline596_inline5265__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 128> v116 = pto::Shape<1, 1, 1, -1, 128>(v111, v112, v113, v92, v30);
      // pto: %x_flat_inline596_inline5265__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v117 = pto::Stride<-1, -1, -1, -1, -1>(v112 * v115, v115, v114, v24, v21);
      // pto: %x_flat_inline596_inline5265__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v118 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v110 + (v109 + v107 * v24 + v108 * v21), v116, v117);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v105, v118);
      // pto: %wkv_tile_inline588_inline5280__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v119 = Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v27, v30);
      // pto: %wkv_tile_inline588_inline5280__tile
      ;
      uint64_t v120 = (uint64_t) v16;
      TASSIGN(v119, v120);
      // pto: %58
      ;
      int64_t v121 = v90 < v25 ? v25 : v90;
      // pto: %cmp_wkv__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v122 = PTOAS__GLOBAL_TENSOR_DATA(v65);
      // pto: %cmp_wkv__ssa_v0_pview
      ;
      const int64_t v123 = 0;
      // pto: %cmp_wkv__ssa_v0_pview
      ;
      const int64_t v124 = 4096;
      // pto: %cmp_wkv__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 32, 128> v125 = pto::Shape<1, 1, 1, 32, 128>();
      // pto: %cmp_wkv__ssa_v0_pview
      ;
      pto::Stride<131072, 131072, 131072, 4096, 1> v126 = pto::Stride<131072, 131072, 131072, 4096, 1>();
      // pto: %cmp_wkv__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v127 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v122 + (v123 + v121 * v124 + v108), v125, v126);
      TLOAD(v119, v127);
      // pto: %wgate_tile_inline590_inline5277__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v128 = Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v27, v30);
      // pto: %wgate_tile_inline590_inline5277__tile
      ;
      uint64_t v129 = (uint64_t) v17;
      TASSIGN(v128, v129);
      // pto: %cmp_wgate__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v130 = PTOAS__GLOBAL_TENSOR_DATA(v73);
      // pto: %cmp_wgate__ssa_v0_pview
      ;
      const int64_t v131 = 0;
      // pto: %cmp_wgate__ssa_v0_pview
      ;
      const int64_t v132 = 4096;
      // pto: %cmp_wgate__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 32, 128> v133 = pto::Shape<1, 1, 1, 32, 128>();
      // pto: %cmp_wgate__ssa_v0_pview
      ;
      pto::Stride<131072, 131072, 131072, 4096, 1> v134 = pto::Stride<131072, 131072, 131072, 4096, 1>();
      // pto: %cmp_wgate__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v135 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v130 + (v131 + v121 * v132 + v108), v133, v134);
      TLOAD(v128, v135);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v92, v30);
      // pto: %0
      ;
      uint64_t v137 = (uint64_t) v18;
      TASSIGN(v136, v137);
      // pto: %63
      ;
      int64_t v138 = v104 < v25 ? v25 : v104;
      // pto: %64
      ;
      const int64_t v139 = 0;
      // pto: %64
      ;
      __gm__ bfloat16_t* v140 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %64
      ;
      const int64_t v141 = 1;
      // pto: %64
      ;
      const int64_t v142 = 1;
      // pto: %64
      ;
      const int64_t v143 = 1;
      // pto: %64
      ;
      int64_t v144 = v92 * v24;
      // pto: %64
      ;
      int64_t v145 = v143 * v144;
      // pto: %64
      ;
      pto::Shape<1, 1, 1, -1, 128> v146 = pto::Shape<1, 1, 1, -1, 128>(v141, v142, v143, v92, v30);
      // pto: %64
      ;
      pto::Stride<-1, -1, -1, -1, -1> v147 = pto::Stride<-1, -1, -1, -1, -1>(v142 * v145, v145, v144, v24, v21);
      // pto: %64
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v148 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v140 + (v139 + v107 * v24 + v138 * v21), v146, v147);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v136, v148);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %1
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v149 = Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v27, v30);
      // pto: %1
      ;
      uint64_t v150 = (uint64_t) v19;
      TASSIGN(v149, v150);
      // pto: %67
      ;
      __gm__ bfloat16_t* v151 = PTOAS__GLOBAL_TENSOR_DATA(v65);
      // pto: %67
      ;
      const int64_t v152 = 0;
      // pto: %67
      ;
      const int64_t v153 = 4096;
      // pto: %67
      ;
      pto::Shape<1, 1, 1, 32, 128> v154 = pto::Shape<1, 1, 1, 32, 128>();
      // pto: %67
      ;
      pto::Stride<131072, 131072, 131072, 4096, 1> v155 = pto::Stride<131072, 131072, 131072, 4096, 1>();
      // pto: %67
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v156 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v151 + (v152 + v121 * v153 + v138), v154, v155);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v149, v156);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %2
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Mat, bfloat16_t, 32, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v27, v30);
      // pto: %2
      ;
      uint64_t v158 = (uint64_t) v20;
      TASSIGN(v157, v158);
      // pto: %70
      ;
      __gm__ bfloat16_t* v159 = PTOAS__GLOBAL_TENSOR_DATA(v73);
      // pto: %70
      ;
      const int64_t v160 = 0;
      // pto: %70
      ;
      const int64_t v161 = 4096;
      // pto: %70
      ;
      pto::Shape<1, 1, 1, 32, 128> v162 = pto::Shape<1, 1, 1, 32, 128>();
      // pto: %70
      ;
      pto::Stride<131072, 131072, 131072, 4096, 1> v163 = pto::Stride<131072, 131072, 131072, 4096, 1>();
      // pto: %70
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v164 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v159 + (v160 + v121 * v161 + v138), v162, v163);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v157, v164);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %71
      ;
      v74.SetValidShape(v92, v27);
      v76.SetValidShape(v92, v27);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      if (v101 == v25) {
        // pto: %wkv_tile_inline588_inline5280__tile_t
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
        // pto: %wkv_tile_inline588_inline5280__tile_t
        ;
        uint64_t v166 = (uint64_t) v16;
        TASSIGN(v165, v166);
        // pto: %x_tile_inline589_inline5264__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v92, v30);
        // pto: %x_tile_inline589_inline5264__tile_Left
        ;
        uint64_t v168 = (uint64_t) v14;
        TASSIGN(v167, v168);
        TMOV(v167, v105);
        // pto: %wkv_tile_inline588_inline5280__tile_t_Right
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
        // pto: %wkv_tile_inline588_inline5280__tile_t_Right
        ;
        uint64_t v170 = (uint64_t) v14;
        TASSIGN(v169, v170);
        TMOV(v169, v165);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %3
        ;
        Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v171 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v92, v27);
        // pto: %3
        ;
        uint64_t v172 = (uint64_t) v14;
        TASSIGN(v171, v172);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        TMATMUL(v171, v167, v169);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        // pto: %wgate_tile_inline590_inline5277__tile_t
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v173 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
        // pto: %wgate_tile_inline590_inline5277__tile_t
        ;
        uint64_t v174 = (uint64_t) v17;
        TASSIGN(v173, v174);
        // pto: %wgate_tile_inline590_inline5277__tile_t_Right
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
        // pto: %wgate_tile_inline590_inline5277__tile_t_Right
        ;
        uint64_t v176 = (uint64_t) v14;
        TASSIGN(v175, v176);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        TMOV(v175, v173);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %4
        ;
        Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v177 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v92, v27);
        // pto: %4
        ;
        uint64_t v178 = (uint64_t) v15;
        TASSIGN(v177, v178);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL(v177, v167, v175);
      } else {
        // pto: %5
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
        // pto: %5
        ;
        uint64_t v180 = (uint64_t) v16;
        TASSIGN(v179, v180);
        // pto: %6
        ;
        Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v92, v30);
        // pto: %6
        ;
        uint64_t v182 = (uint64_t) v14;
        TASSIGN(v181, v182);
        TMOV(v181, v105);
        // pto: %7
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
        // pto: %7
        ;
        uint64_t v184 = (uint64_t) v14;
        TASSIGN(v183, v184);
        TMOV(v183, v179);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        TMATMUL_ACC(v97, v97, v181, v183);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %9
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v185 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
        // pto: %9
        ;
        uint64_t v186 = (uint64_t) v17;
        TASSIGN(v185, v186);
        // pto: %10
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v187 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
        // pto: %10
        ;
        uint64_t v188 = (uint64_t) v14;
        TASSIGN(v187, v188);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        TMOV(v187, v185);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        TMATMUL_ACC(v99, v99, v181, v187);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %12
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v189 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
      // pto: %12
      ;
      uint64_t v190 = (uint64_t) v19;
      TASSIGN(v189, v190);
      // pto: %13
      ;
      Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v191 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v92, v30);
      // pto: %13
      ;
      uint64_t v192 = (uint64_t) v16;
      TASSIGN(v191, v192);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      TMOV(v191, v136);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %14
      ;
      Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v193 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
      // pto: %14
      ;
      uint64_t v194 = (uint64_t) v15;
      TASSIGN(v193, v194);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      TMOV(v193, v189);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
      TMATMUL_ACC(v74, v74, v191, v193);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      // pto: %16
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v195 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
      // pto: %16
      ;
      uint64_t v196 = (uint64_t) v20;
      TASSIGN(v195, v196);
      // pto: %17
      ;
      Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v197 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v30, v27);
      // pto: %17
      ;
      uint64_t v198 = (uint64_t) v15;
      TASSIGN(v197, v198);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      TMOV(v197, v195);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
      TMATMUL_ACC(v76, v76, v191, v197);
    };
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %72
    ;
    int64_t v199 = v89 < v25 ? v25 : v89;
    // pto: %73
    ;
    int64_t v200 = v90 < v25 ? v25 : v90;
    // pto: %cmp4_kv_proj_pad_inline598_inline5267__iter_v1_pview
    ;
    const int64_t v201 = 0;
    // pto: %cmp4_kv_proj_pad_inline598_inline5267__iter_v1_pview
    ;
    __gm__ float* v202 = PTOAS__GLOBAL_TENSOR_DATA(v40);
    // pto: %cmp4_kv_proj_pad_inline598_inline5267__iter_v1_pview
    ;
    const int64_t v203 = 1;
    // pto: %cmp4_kv_proj_pad_inline598_inline5267__iter_v1_pview
    ;
    const int64_t v204 = 1;
    // pto: %cmp4_kv_proj_pad_inline598_inline5267__iter_v1_pview
    ;
    const int64_t v205 = 1;
    // pto: %cmp4_kv_proj_pad_inline598_inline5267__iter_v1_pview
    ;
    int64_t v206 = v92 * v23;
    // pto: %cmp4_kv_proj_pad_inline598_inline5267__iter_v1_pview
    ;
    int64_t v207 = v205 * v206;
    // pto: %cmp4_kv_proj_pad_inline598_inline5267__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, -1, 32> v208 = pto::Shape<1, 1, 1, -1, 32>(v203, v204, v205, v92, v27);
    // pto: %cmp4_kv_proj_pad_inline598_inline5267__iter_v1_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v209 = pto::Stride<-1, -1, -1, -1, -1>(v204 * v207, v207, v206, v23, v21);
    // pto: %cmp4_kv_proj_pad_inline598_inline5267__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v210 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v202 + (v201 + v199 * v23 + v200 * v21), v208, v209);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v210, v97);
    // pto: %cmp4_score_proj_pad_inline599_inline5272__iter_v1_pview
    ;
    const int64_t v211 = 0;
    // pto: %cmp4_score_proj_pad_inline599_inline5272__iter_v1_pview
    ;
    __gm__ float* v212 = PTOAS__GLOBAL_TENSOR_DATA(v48);
    // pto: %cmp4_score_proj_pad_inline599_inline5272__iter_v1_pview
    ;
    const int64_t v213 = 1;
    // pto: %cmp4_score_proj_pad_inline599_inline5272__iter_v1_pview
    ;
    const int64_t v214 = 1;
    // pto: %cmp4_score_proj_pad_inline599_inline5272__iter_v1_pview
    ;
    const int64_t v215 = 1;
    // pto: %cmp4_score_proj_pad_inline599_inline5272__iter_v1_pview
    ;
    int64_t v216 = v92 * v23;
    // pto: %cmp4_score_proj_pad_inline599_inline5272__iter_v1_pview
    ;
    int64_t v217 = v215 * v216;
    // pto: %cmp4_score_proj_pad_inline599_inline5272__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, -1, 32> v218 = pto::Shape<1, 1, 1, -1, 32>(v213, v214, v215, v92, v27);
    // pto: %cmp4_score_proj_pad_inline599_inline5272__iter_v1_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v219 = pto::Stride<-1, -1, -1, -1, -1>(v214 * v217, v217, v216, v23, v21);
    // pto: %cmp4_score_proj_pad_inline599_inline5272__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v220 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v212 + (v211 + v199 * v23 + v200 * v21), v218, v219);
    TSTORE(v220, v99);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}