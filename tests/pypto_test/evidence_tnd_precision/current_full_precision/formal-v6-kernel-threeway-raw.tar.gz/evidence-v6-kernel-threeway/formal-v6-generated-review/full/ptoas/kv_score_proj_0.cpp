#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void kv_score_proj_0(__gm__ int32_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ bfloat16_t* v4, __gm__ bfloat16_t* v5, __gm__ bfloat16_t* v6, int64_t v7, int64_t v8, int64_t v9, int64_t v10, int32_t v11, int32_t v12) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int32_t v13 = 0;
  // pto: %c0_i64
  const int64_t v14 = 0;
  // pto: %c1024_i64
  const int64_t v15 = 1024;
  // pto: %c32768_i64
  const int64_t v16 = 32768;
  // pto: %c40960_i64
  const int64_t v17 = 40960;
  // pto: %c8192_i64
  const int64_t v18 = 8192;
  // pto: %c16384_i64
  const int64_t v19 = 16384;
  // pto: %c24576_i64
  const int64_t v20 = 24576;
  // pto: %c1_index
  const int64_t v21 = 1;
  // pto: %c384_index
  const int64_t v22 = 384;
  // pto: %c256_index
  const int64_t v23 = 256;
  // pto: %c4096_index
  const int64_t v24 = 4096;
  // pto: %c0_index
  const int64_t v25 = 0;
  // pto: %c64_index
  const int64_t v26 = 64;
  // pto: %c1536_index
  const int64_t v27 = 1536;
  // pto: %c16_index
  const int64_t v28 = 16;
  // pto: %c24_index
  const int64_t v29 = 24;
  // pto: %c2_index
  const int64_t v30 = 2;
  // pto: %c128_index
  const int64_t v31 = 128;
  // pto: %cn1_index
  const int64_t v32 = -1;
  // pto: %kv_proj_pad_inline5433__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %kv_proj_pad_inline5433__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %kv_proj_pad_inline5433__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %kv_proj_pad_inline5433__ssa_v0_view
  int64_t v36 = v22 * v23;
  // pto: %kv_proj_pad_inline5433__ssa_v0_view
  int64_t v37 = v35 * v36;
  // pto: %kv_proj_pad_inline5433__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v38 = pto::Shape<1, 1, 1, -1, -1>(v33, v34, v35, v22, v23);
  // pto: %kv_proj_pad_inline5433__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v39 = pto::Stride<-1, -1, -1, -1, -1>(v34 * v37, v37, v36, v23, v21);
  // pto: %kv_proj_pad_inline5433__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v40 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v38, v39);
  // pto: %score_proj_pad_inline5458__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %score_proj_pad_inline5458__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %score_proj_pad_inline5458__ssa_v0_view
  const int64_t v43 = 1;
  // pto: %score_proj_pad_inline5458__ssa_v0_view
  int64_t v44 = v22 * v23;
  // pto: %score_proj_pad_inline5458__ssa_v0_view
  int64_t v45 = v43 * v44;
  // pto: %score_proj_pad_inline5458__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v46 = pto::Shape<1, 1, 1, -1, -1>(v41, v42, v43, v22, v23);
  // pto: %score_proj_pad_inline5458__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v47 = pto::Stride<-1, -1, -1, -1, -1>(v42 * v45, v45, v44, v23, v21);
  // pto: %score_proj_pad_inline5458__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v48 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v46, v47);
  // pto: %x_flat_inline466_inline5472__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %x_flat_inline466_inline5472__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %x_flat_inline466_inline5472__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %x_flat_inline466_inline5472__ssa_v0_view
  int64_t v52 = (int64_t) v10;
  // pto: %x_flat_inline466_inline5472__ssa_v0_view
  int64_t v53 = v52 * v24;
  // pto: %x_flat_inline466_inline5472__ssa_v0_view
  int64_t v54 = v51 * v53;
  // pto: %x_flat_inline466_inline5472__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v55 = pto::Shape<1, 1, 1, -1, -1>(v49, v50, v51, v52, v24);
  // pto: %x_flat_inline466_inline5472__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v56 = pto::Stride<-1, -1, -1, -1, -1>(v50 * v54, v54, v53, v24, v21);
  // pto: %x_flat_inline466_inline5472__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v57 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v55, v56);
  // pto: %inner_wkv__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %inner_wkv__ssa_v0_view
  const int64_t v59 = 1;
  // pto: %inner_wkv__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %inner_wkv__ssa_v0_view
  int64_t v61 = v23 * v24;
  // pto: %inner_wkv__ssa_v0_view
  int64_t v62 = v60 * v61;
  // pto: %inner_wkv__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v63 = pto::Shape<1, 1, 1, -1, -1>(v58, v59, v60, v23, v24);
  // pto: %inner_wkv__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v59 * v62, v62, v61, v24, v21);
  // pto: %inner_wkv__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v65 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v63, v64);
  // pto: %inner_wgate__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %inner_wgate__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %inner_wgate__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %inner_wgate__ssa_v0_view
  int64_t v69 = v23 * v24;
  // pto: %inner_wgate__ssa_v0_view
  int64_t v70 = v68 * v69;
  // pto: %inner_wgate__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v71 = pto::Shape<1, 1, 1, -1, -1>(v66, v67, v68, v23, v24);
  // pto: %inner_wgate__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v70, v70, v69, v24, v21);
  // pto: %inner_wgate__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v71, v72);
  // pto: %kv_worker_inline467_inline5457__ssa_v0
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
  // pto: %t__tile
  int32_t v74 = (v1)[v21];
  // pto: %12
  int32_t v75 = (v1)[v25];
  // pto: %15
  // pto: %deviation_inline8543__rv_v2
  int32_t v76;
  v76 = v13;
  for (int64_t v77 = v21; v77 < ((int64_t) ((uint64_t) v9 - (uint64_t) v21)); v77 += v21) {
    // pto: %17, %16
    ;
    int32_t v78 = (v1)[(int64_t) ((uint64_t) v77 + (uint64_t) v21)];
    // pto: %18
    ;
    int32_t v79 = (v1)[v77];
    // pto: %19, %20, %13
    ;
    int32_t v80 = (int32_t) ((uint32_t) ((int32_t) (uint32_t) v78 - (uint32_t) v79) - (uint32_t) ((int32_t) (uint32_t) v74 - (uint32_t) v75));
    // pto: %22
    ;
    uint32_t v81 = (uint32_t) v76;
    // pto: %21, %22
    ;
    v76 = (int32_t) (v81 + (uint32_t) ((int32_t) (uint32_t) v80 * (uint32_t) v80));
  }
  // pto: %24
  int64_t v82 = (int64_t) v76;
  // pto: %25, %26, %27, %group_inline8541__phi_v4
  int64_t v83 = v82 == v25 & v7 <= v27 ? v28 : v26;
  for (int64_t v84 = (int64_t) v11; v84 < v8; v84 += v29) {
    // pto: %29, %30
    ;
    int64_t v85 = (int64_t) ((uint64_t) (v84 / v28) * (uint64_t) v28);
    // pto: %31, %32
    ;
    int64_t v86 = (int64_t) ((uint64_t) (v84 % v28) * (uint64_t) v28);
    // pto: %kv_acc_inline462_inline5470__tile
    ;
    Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v28, v28);
    // pto: %kv_acc_inline462_inline5470__tile
    ;
    uint64_t v88 = (uint64_t) v14;
    TASSIGN(v87, v88);
    // pto: %score_acc_inline472_inline5450__tile
    ;
    Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v89 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v28, v28);
    // pto: %score_acc_inline472_inline5450__tile
    ;
    uint64_t v90 = (uint64_t) v15;
    TASSIGN(v89, v90);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    for (int64_t v91 = v25; v91 < v28; v91 += v30) {
      // pto: %35, %33, %34, %36
      ;
      int64_t v92 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v91 + (uint64_t) (v86 % v31 / v83)) * (uint64_t) v23);
      // pto: %37
      ;
      int64_t v93 = v92 % v24;
      // pto: %38
      ;
      int64_t v94 = (int64_t) ((uint64_t) v7 - (uint64_t) v85);
      // pto: %39
      ;
      int64_t v95 = v94 < v28 ? v94 : v28;
      // pto: %44, %45
      ;
      int64_t v96 = (int64_t) ((uint64_t) v92 + (uint64_t) v23) % v24;
      // pto: %x_tile_inline464_inline5428__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v95, v23);
      // pto: %x_tile_inline464_inline5428__tile
      ;
      uint64_t v98 = (uint64_t) v16;
      TASSIGN(v97, v98);
      // pto: %48
      ;
      int64_t v99 = v85 < v25 ? v25 : v85;
      // pto: %49
      ;
      int64_t v100 = v93 < v25 ? v25 : v93;
      // pto: %x_flat_inline466_inline5472__ssa_v0_pview
      ;
      const int64_t v101 = 0;
      // pto: %x_flat_inline466_inline5472__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v102 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %x_flat_inline466_inline5472__ssa_v0_pview
      ;
      const int64_t v103 = 1;
      // pto: %x_flat_inline466_inline5472__ssa_v0_pview
      ;
      const int64_t v104 = 1;
      // pto: %x_flat_inline466_inline5472__ssa_v0_pview
      ;
      const int64_t v105 = 1;
      // pto: %x_flat_inline466_inline5472__ssa_v0_pview
      ;
      int64_t v106 = v95 * v24;
      // pto: %x_flat_inline466_inline5472__ssa_v0_pview
      ;
      int64_t v107 = v105 * v106;
      // pto: %x_flat_inline466_inline5472__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 256> v108 = pto::Shape<1, 1, 1, -1, 256>(v103, v104, v105, v95, v23);
      // pto: %x_flat_inline466_inline5472__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v109 = pto::Stride<-1, -1, -1, -1, -1>(v104 * v107, v107, v106, v24, v21);
      // pto: %x_flat_inline466_inline5472__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v110 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v102 + (v101 + v99 * v24 + v100 * v21), v108, v109);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v97, v110);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %wkv_tile_inline460_inline5446__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v28, v23);
      // pto: %wkv_tile_inline460_inline5446__tile
      ;
      uint64_t v112 = (uint64_t) v17;
      TASSIGN(v111, v112);
      // pto: %50
      ;
      int64_t v113 = v86 < v25 ? v25 : v86;
      // pto: %inner_wkv__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v114 = PTOAS__GLOBAL_TENSOR_DATA(v65);
      // pto: %inner_wkv__ssa_v0_pview
      ;
      const int64_t v115 = 0;
      // pto: %inner_wkv__ssa_v0_pview
      ;
      const int64_t v116 = 4096;
      // pto: %inner_wkv__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 256> v117 = pto::Shape<1, 1, 1, 16, 256>();
      // pto: %inner_wkv__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v118 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %inner_wkv__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v119 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v114 + (v115 + v113 * v116 + v100), v117, v118);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v111, v119);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %wgate_tile_inline474_inline5484__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v28, v23);
      // pto: %wgate_tile_inline474_inline5484__tile
      ;
      uint64_t v121 = (uint64_t) v14;
      TASSIGN(v120, v121);
      // pto: %inner_wgate__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v122 = PTOAS__GLOBAL_TENSOR_DATA(v73);
      // pto: %inner_wgate__ssa_v0_pview
      ;
      const int64_t v123 = 0;
      // pto: %inner_wgate__ssa_v0_pview
      ;
      const int64_t v124 = 4096;
      // pto: %inner_wgate__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 256> v125 = pto::Shape<1, 1, 1, 16, 256>();
      // pto: %inner_wgate__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v126 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %inner_wgate__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v127 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v122 + (v123 + v113 * v124 + v100), v125, v126);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v120, v127);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %0
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v128 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v95, v23);
      // pto: %0
      ;
      uint64_t v129 = (uint64_t) v18;
      TASSIGN(v128, v129);
      // pto: %55
      ;
      int64_t v130 = v96 < v25 ? v25 : v96;
      // pto: %56
      ;
      const int64_t v131 = 0;
      // pto: %56
      ;
      __gm__ bfloat16_t* v132 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %56
      ;
      const int64_t v133 = 1;
      // pto: %56
      ;
      const int64_t v134 = 1;
      // pto: %56
      ;
      const int64_t v135 = 1;
      // pto: %56
      ;
      int64_t v136 = v95 * v24;
      // pto: %56
      ;
      int64_t v137 = v135 * v136;
      // pto: %56
      ;
      pto::Shape<1, 1, 1, -1, 256> v138 = pto::Shape<1, 1, 1, -1, 256>(v133, v134, v135, v95, v23);
      // pto: %56
      ;
      pto::Stride<-1, -1, -1, -1, -1> v139 = pto::Stride<-1, -1, -1, -1, -1>(v134 * v137, v137, v136, v24, v21);
      // pto: %56
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v140 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v132 + (v131 + v99 * v24 + v130 * v21), v138, v139);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v128, v140);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %1
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v28, v23);
      // pto: %1
      ;
      uint64_t v142 = (uint64_t) v19;
      TASSIGN(v141, v142);
      // pto: %59
      ;
      __gm__ bfloat16_t* v143 = PTOAS__GLOBAL_TENSOR_DATA(v65);
      // pto: %59
      ;
      const int64_t v144 = 0;
      // pto: %59
      ;
      const int64_t v145 = 4096;
      // pto: %59
      ;
      pto::Shape<1, 1, 1, 16, 256> v146 = pto::Shape<1, 1, 1, 16, 256>();
      // pto: %59
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v147 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %59
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v148 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v143 + (v144 + v113 * v145 + v130), v146, v147);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
      TLOAD(v141, v148);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      // pto: %2
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v149 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v28, v23);
      // pto: %2
      ;
      uint64_t v150 = (uint64_t) v20;
      TASSIGN(v149, v150);
      // pto: %62
      ;
      __gm__ bfloat16_t* v151 = PTOAS__GLOBAL_TENSOR_DATA(v73);
      // pto: %62
      ;
      const int64_t v152 = 0;
      // pto: %62
      ;
      const int64_t v153 = 4096;
      // pto: %62
      ;
      pto::Shape<1, 1, 1, 16, 256> v154 = pto::Shape<1, 1, 1, 16, 256>();
      // pto: %62
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v155 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %62
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v156 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v151 + (v152 + v113 * v153 + v130), v154, v155);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      TLOAD(v149, v156);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      // pto: %wkv_tile_inline460_inline5446__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v28);
      // pto: %wkv_tile_inline460_inline5446__tile_t
      ;
      uint64_t v158 = (uint64_t) v17;
      TASSIGN(v157, v158);
      // pto: %x_tile_inline464_inline5428__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v159 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v95, v23);
      // pto: %x_tile_inline464_inline5428__tile_Left
      ;
      uint64_t v160 = (uint64_t) v14;
      TASSIGN(v159, v160);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      TMOV(v159, v97);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %wkv_tile_inline460_inline5446__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v28);
      // pto: %wkv_tile_inline460_inline5446__tile_t_Right
      ;
      uint64_t v162 = (uint64_t) v14;
      TASSIGN(v161, v162);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      TMOV(v161, v157);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %63
      ;
      bool v163 = v91 == v25;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (v163) {
        TMATMUL(v87, v159, v161);
      } else {
        TMATMUL_ACC(v87, v87, v159, v161);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      // pto: %wgate_tile_inline474_inline5484__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v164 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v28);
      // pto: %wgate_tile_inline474_inline5484__tile_t
      ;
      uint64_t v165 = (uint64_t) v14;
      TASSIGN(v164, v165);
      // pto: %wgate_tile_inline474_inline5484__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v166 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v28);
      // pto: %wgate_tile_inline474_inline5484__tile_t_Right
      ;
      uint64_t v167 = (uint64_t) v14;
      TASSIGN(v166, v167);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      pipe_barrier(PIPE_MTE1);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      TMOV(v166, v164);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      if (v163) {
        TMATMUL(v89, v159, v166);
      } else {
        TMATMUL_ACC(v89, v89, v159, v166);
      };
      // pto: %5
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v168 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v28);
      // pto: %5
      ;
      uint64_t v169 = (uint64_t) v19;
      TASSIGN(v168, v169);
      // pto: %6
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v170 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v95, v23);
      // pto: %6
      ;
      uint64_t v171 = (uint64_t) v18;
      TASSIGN(v170, v171);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      TMOV(v170, v128);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      // pto: %7
      ;
      Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v172 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v28);
      // pto: %7
      ;
      uint64_t v173 = (uint64_t) v18;
      TASSIGN(v172, v173);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      TMOV(v172, v168);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
      // pto: %65
      ;
      bool v174 = v91 == v32;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      if (v174) {
        TMATMUL(v87, v170, v172);
      } else {
        TMATMUL_ACC(v87, v87, v170, v172);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %9
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v28);
      // pto: %9
      ;
      uint64_t v176 = (uint64_t) v20;
      TASSIGN(v175, v176);
      // pto: %10
      ;
      Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v28);
      // pto: %10
      ;
      uint64_t v178 = (uint64_t) v18;
      TASSIGN(v177, v178);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      pipe_barrier(PIPE_MTE1);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      TMOV(v177, v175);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      if (v174) {
        TMATMUL(v89, v170, v177);
      } else {
        TMATMUL_ACC(v89, v89, v170, v177);
      };
    };
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %67
    ;
    int64_t v179 = v85 < v25 ? v25 : v85;
    // pto: %68
    ;
    int64_t v180 = v86 < v25 ? v25 : v86;
    // pto: %kv_proj_pad_inline5433__iter_v1_pview
    ;
    __gm__ float* v181 = PTOAS__GLOBAL_TENSOR_DATA(v40);
    // pto: %kv_proj_pad_inline5433__iter_v1_pview
    ;
    const int64_t v182 = 0;
    // pto: %kv_proj_pad_inline5433__iter_v1_pview
    ;
    const int64_t v183 = 256;
    // pto: %kv_proj_pad_inline5433__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 16> v184 = pto::Shape<1, 1, 1, 16, 16>();
    // pto: %kv_proj_pad_inline5433__iter_v1_pview
    ;
    pto::Stride<4096, 4096, 4096, 256, 1> v185 = pto::Stride<4096, 4096, 4096, 256, 1>();
    // pto: %kv_proj_pad_inline5433__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<4096, 4096, 4096, 256, 1>, pto::Layout::ND> v186 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<4096, 4096, 4096, 256, 1>, pto::Layout::ND>(v181 + (v182 + v179 * v183 + v180), v184, v185);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v186, v87);
    // pto: %score_proj_pad_inline5458__iter_v1_pview
    ;
    __gm__ float* v187 = PTOAS__GLOBAL_TENSOR_DATA(v48);
    // pto: %score_proj_pad_inline5458__iter_v1_pview
    ;
    const int64_t v188 = 0;
    // pto: %score_proj_pad_inline5458__iter_v1_pview
    ;
    const int64_t v189 = 256;
    // pto: %score_proj_pad_inline5458__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 16> v190 = pto::Shape<1, 1, 1, 16, 16>();
    // pto: %score_proj_pad_inline5458__iter_v1_pview
    ;
    pto::Stride<4096, 4096, 4096, 256, 1> v191 = pto::Stride<4096, 4096, 4096, 256, 1>();
    // pto: %score_proj_pad_inline5458__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<4096, 4096, 4096, 256, 1>, pto::Layout::ND> v192 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<4096, 4096, 4096, 256, 1>, pto::Layout::ND>(v187 + (v188 + v179 * v189 + v180), v190, v191);
    TSTORE(v192, v89);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}