#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_b_dequant(__gm__ int32_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ bfloat16_t* v4, int64_t v5, int64_t v6, int64_t v7, int32_t v8, int32_t v9) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v10 = 0;
  // pto: %c32768_i64
  const int64_t v11 = 32768;
  // pto: %c34816_i64
  const int64_t v12 = 34816;
  // pto: %c34880_i64
  const int64_t v13 = 34880;
  // pto: %c4096_index
  const int64_t v14 = 4096;
  // pto: %c1_index
  const int64_t v15 = 1;
  // pto: %c8_index
  const int64_t v16 = 8;
  // pto: %c16_index
  const int64_t v17 = 16;
  // pto: %c512_index
  const int64_t v18 = 512;
  // pto: %c0_index
  const int64_t v19 = 0;
  // pto: %cst_10
  const float v20 = 1.0f;
  // pto: %c63_index
  const int64_t v21 = 63;
  // pto: %12
  int64_t v22 = (int64_t) ((uint64_t) v6 + (uint64_t) v21);
  // pto: %integer_accum_inline1506__phi_v3_view
  const int64_t v23 = 1;
  // pto: %integer_accum_inline1506__phi_v3_view
  const int64_t v24 = 1;
  // pto: %integer_accum_inline1506__phi_v3_view
  const int64_t v25 = 1;
  // pto: %integer_accum_inline1506__phi_v3_view
  int64_t v26 = v22 * v14;
  // pto: %integer_accum_inline1506__phi_v3_view
  int64_t v27 = v25 * v26;
  // pto: %integer_accum_inline1506__phi_v3_view
  pto::Shape<1, 1, 1, -1, -1> v28 = pto::Shape<1, 1, 1, -1, -1>(v23, v24, v25, v22, v14);
  // pto: %integer_accum_inline1506__phi_v3_view
  pto::Stride<-1, -1, -1, -1, -1> v29 = pto::Stride<-1, -1, -1, -1, -1>(v24 * v27, v27, v26, v14, v15);
  // pto: %integer_accum_inline1506__phi_v3_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v30 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v28, v29);
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v35 = v14 * v15;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v36 = v34 * v35;
  // pto: %wo_b_scale__ssa_v0_view
  int64_t v37 = v33 * v36;
  // pto: %wo_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v38 = pto::Shape<1, 1, 1, 1, -1>(v31, v32, v33, v34, v14);
  // pto: %wo_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v39 = pto::Stride<-1, -1, -1, -1, -1>(v32 * v37, v37, v36, v35, v15);
  // pto: %wo_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v40 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v38, v39);
  // pto: %scale_o__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %scale_o__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %scale_o__ssa_v0_view
  const int64_t v43 = 1;
  // pto: %scale_o__ssa_v0_view
  int64_t v44 = (int64_t) v7;
  // pto: %scale_o__ssa_v0_view
  int64_t v45 = v44 * v15;
  // pto: %scale_o__ssa_v0_view
  int64_t v46 = v43 * v45;
  // pto: %scale_o__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v47 = pto::Shape<1, 1, 1, -1, -1>(v41, v42, v43, v44, v15);
  // pto: %scale_o__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v48 = pto::Stride<-1, -1, -1, -1, -1>(v42 * v46, v46, v45, v15, (int64_t) v7);
  // pto: %scale_o__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v49 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v3, v47, v48);
  // pto: %attention_out__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %attention_out__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %attention_out__ssa_v0_view
  const int64_t v52 = 1;
  // pto: %attention_out__ssa_v0_view
  int64_t v53 = (int64_t) v7;
  // pto: %attention_out__ssa_v0_view
  int64_t v54 = v53 * v14;
  // pto: %attention_out__ssa_v0_view
  int64_t v55 = v52 * v54;
  // pto: %attention_out__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v56 = pto::Shape<1, 1, 1, -1, -1>(v50, v51, v52, v53, v14);
  // pto: %attention_out__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v57 = pto::Stride<-1, -1, -1, -1, -1>(v51 * v55, v55, v54, v14, v15);
  // pto: %attention_out__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v58 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v56, v57);
  // pto: %block_inline1523__ssa_v0
  int64_t v59 = (int64_t) v8;
  // pto: %0, %1
  int64_t v60 = (int64_t) ((uint64_t) (v59 / v16) * (uint64_t) v17);
  // pto: %2, %3
  int64_t v61 = (int64_t) ((uint64_t) (v59 % v16) * (uint64_t) v18);
  // pto: %4
  int64_t v62 = (int64_t) ((uint64_t) v6 - (uint64_t) v60);
  // pto: %5
  int64_t v63 = v62 < v17 ? v62 : v17;
  // pto: %ob_integer_inline1469__ssa_v0
  Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v64 = Tile<TileType::Vec, int32_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v18);
  // pto: %ob_integer_inline1469__ssa_v0
  uint64_t v65 = (uint64_t) v10;
  TASSIGN(v64, v65);
  // pto: %6
  int64_t v66 = v60 < v19 ? v19 : v60;
  // pto: %7
  int64_t v67 = v61 < v19 ? v19 : v61;
  // pto: %integer_accum_inline1506__phi_v3_pview
  const int64_t v68 = 0;
  // pto: %integer_accum_inline1506__phi_v3_pview
  __gm__ int32_t* v69 = PTOAS__GLOBAL_TENSOR_DATA(v30);
  // pto: %integer_accum_inline1506__phi_v3_pview
  const int64_t v70 = 1;
  // pto: %integer_accum_inline1506__phi_v3_pview
  const int64_t v71 = 1;
  // pto: %integer_accum_inline1506__phi_v3_pview
  const int64_t v72 = 1;
  // pto: %integer_accum_inline1506__phi_v3_pview
  int64_t v73 = v63 * v14;
  // pto: %integer_accum_inline1506__phi_v3_pview
  int64_t v74 = v72 * v73;
  // pto: %integer_accum_inline1506__phi_v3_pview
  pto::Shape<1, 1, 1, -1, 512> v75 = pto::Shape<1, 1, 1, -1, 512>(v70, v71, v72, v63, v18);
  // pto: %integer_accum_inline1506__phi_v3_pview
  pto::Stride<-1, -1, -1, -1, -1> v76 = pto::Stride<-1, -1, -1, -1, -1>(v71 * v74, v74, v73, v14, v15);
  // pto: %integer_accum_inline1506__phi_v3_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v77 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v69 + (v68 + v66 * v14 + v67 * v15), v75, v76);
  TLOAD(v64, v77);
  // pto: %t__tmp_v1072
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v18);
  // pto: %t__tmp_v1072
  uint64_t v79 = (uint64_t) v11;
  TASSIGN(v78, v79);
  // pto: %wo_b_scale__ssa_v0_pview
  __gm__ float* v80 = PTOAS__GLOBAL_TENSOR_DATA(v40);
  // pto: %wo_b_scale__ssa_v0_pview
  const int64_t v81 = 0;
  // pto: %wo_b_scale__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 512> v82 = pto::Shape<1, 1, 1, 1, 512>();
  // pto: %wo_b_scale__ssa_v0_pview
  pto::Stride<512, 512, 512, 512, 1> v83 = pto::Stride<512, 512, 512, 512, 1>();
  // pto: %wo_b_scale__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v84 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v80 + (v81 + v67), v82, v83);
  TLOAD(v78, v84);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %channel_inline1537__ssa_v0
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v85 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v18);
  // pto: %channel_inline1537__ssa_v0
  uint64_t v86 = (uint64_t) v11;
  TASSIGN(v85, v86);
  // pto: %scale_inline1414__ssa_v0
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v15);
  // pto: %scale_inline1414__ssa_v0
  uint64_t v88 = (uint64_t) v12;
  TASSIGN(v87, v88);
  // pto: %scale_o__ssa_v0_pview
  int64_t v89 = (int64_t) v7;
  // pto: %scale_o__ssa_v0_pview
  const int64_t v90 = 0;
  // pto: %scale_o__ssa_v0_pview
  __gm__ float* v91 = PTOAS__GLOBAL_TENSOR_DATA(v49);
  // pto: %scale_o__ssa_v0_pview
  const int64_t v92 = 1;
  // pto: %scale_o__ssa_v0_pview
  const int64_t v93 = 1;
  // pto: %scale_o__ssa_v0_pview
  const int64_t v94 = 1;
  // pto: %scale_o__ssa_v0_pview
  int64_t v95 = v63 * v15;
  // pto: %scale_o__ssa_v0_pview
  int64_t v96 = v94 * v95;
  // pto: %scale_o__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 1> v97 = pto::Shape<1, 1, 1, -1, 1>(v92, v93, v94, v63, v15);
  // pto: %scale_o__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v98 = pto::Stride<-1, -1, -1, -1, -1>(v93 * v96, v96, v95, v15, v89);
  // pto: %scale_o__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v99 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v91 + (v90 + v66 * v15 + v19 * v89), v97, v98);
  TLOAD(v87, v99);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  // pto: %coefficient_one_inline1530__ssa_v0
  Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
  // pto: %coefficient_one_inline1530__ssa_v0
  uint64_t v101 = (uint64_t) v13;
  TASSIGN(v100, v101);
  TEXPANDS(v100, v20);
  // pto: %coefficient_channel_inline1413__ssa_v0
  Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
  // pto: %coefficient_channel_inline1413__ssa_v0
  uint64_t v103 = (uint64_t) v13;
  TASSIGN(v102, v103);
  pipe_barrier(PIPE_V);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  TCOLEXPANDMUL(v102, v100, v85);
  // pto: %coefficient_inline1412__ssa_v0
  Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
  // pto: %coefficient_inline1412__ssa_v0
  uint64_t v105 = (uint64_t) v13;
  TASSIGN(v104, v105);
  pipe_barrier(PIPE_V);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  TROWEXPANDMUL(v104, v102, v87);
  // pto: %t__tmp_v1073
  Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v18);
  // pto: %t__tmp_v1073
  uint64_t v107 = (uint64_t) v10;
  TASSIGN(v106, v107);
  RoundMode v108 = RoundMode::CAST_ROUND;
  SaturationMode v109 = SaturationMode::ON;
  TCVT(v106, v64, v108, v109);
  // pto: %ob_scaled_inline1411__ssa_v0
  Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v18);
  // pto: %ob_scaled_inline1411__ssa_v0
  uint64_t v111 = (uint64_t) v10;
  TASSIGN(v110, v111);
  pipe_barrier(PIPE_V);
  TMUL(v110, v106, v104);
  // pto: %t__tmp_v1074
  Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v18);
  // pto: %t__tmp_v1074
  uint64_t v113 = (uint64_t) v10;
  TASSIGN(v112, v113);
  pipe_barrier(PIPE_V);
  RoundMode v114 = RoundMode::CAST_RINT;
  SaturationMode v115 = SaturationMode::ON;
  TCVT(v112, v110, v114, v115);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %attention_out__ssa_v0_pview
  const int64_t v116 = 0;
  // pto: %attention_out__ssa_v0_pview
  __gm__ bfloat16_t* v117 = PTOAS__GLOBAL_TENSOR_DATA(v58);
  // pto: %attention_out__ssa_v0_pview
  const int64_t v118 = 1;
  // pto: %attention_out__ssa_v0_pview
  const int64_t v119 = 1;
  // pto: %attention_out__ssa_v0_pview
  const int64_t v120 = 1;
  // pto: %attention_out__ssa_v0_pview
  int64_t v121 = v63 * v14;
  // pto: %attention_out__ssa_v0_pview
  int64_t v122 = v120 * v121;
  // pto: %attention_out__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 512> v123 = pto::Shape<1, 1, 1, -1, 512>(v118, v119, v120, v63, v18);
  // pto: %attention_out__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v124 = pto::Stride<-1, -1, -1, -1, -1>(v119 * v122, v122, v121, v14, v15);
  // pto: %attention_out__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v125 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v117 + (v116 + v66 * v14 + v67 * v15), v123, v124);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v125, v112);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}