#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void split_pre_post(__gm__ float* v1, __gm__ float* v2, __gm__ float* v3, __gm__ float* v4, __gm__ float* v5, __gm__ float* v6, __gm__ float* v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int64_t v12, int64_t v13, int32_t v14, int32_t v15) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c256_i64
  const int64_t v16 = 256;
  // pto: %c288_i64
  const int64_t v17 = 288;
  // pto: %c320_i64
  const int64_t v18 = 320;
  // pto: %c0_i64
  const int64_t v19 = 0;
  // pto: %c1_index
  const int64_t v20 = 1;
  // pto: %c4_index
  const int64_t v21 = 4;
  // pto: %c8_index
  const int64_t v22 = 8;
  // pto: %c24_index
  const int64_t v23 = 24;
  // pto: %c32_index
  const int64_t v24 = 32;
  // pto: %c0_index
  const int64_t v25 = 0;
  // pto: %c16_index
  const int64_t v26 = 16;
  // pto: %cst_12
  const float v27 = 1.0f;
  // pto: %cst_13
  const float v28 = 9.99999997E-7f;
  // pto: %cst_14
  const float v29 = 2.0f;
  // pto: %post__ssa_v0_view
  const int64_t v30 = 1;
  // pto: %post__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %post__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %post__ssa_v0_view
  int64_t v33 = (int64_t) v10;
  // pto: %post__ssa_v0_view
  int64_t v34 = v33 * v21;
  // pto: %post__ssa_v0_view
  int64_t v35 = v32 * v34;
  // pto: %post__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v36 = pto::Shape<1, 1, 1, -1, -1>(v30, v31, v32, v33, v21);
  // pto: %post__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v37 = pto::Stride<-1, -1, -1, -1, -1>(v31 * v35, v35, v34, v21, v20);
  // pto: %post__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v38 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v36, v37);
  // pto: %post_tail_store_inline8225__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %post_tail_store_inline8225__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %post_tail_store_inline8225__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %post_tail_store_inline8225__ssa_v0_view
  int64_t v42 = v22 * v22;
  // pto: %post_tail_store_inline8225__ssa_v0_view
  int64_t v43 = v41 * v42;
  // pto: %post_tail_store_inline8225__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v44 = pto::Shape<1, 1, 1, -1, -1>(v39, v40, v41, v22, v22);
  // pto: %post_tail_store_inline8225__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v45 = pto::Stride<-1, -1, -1, -1, -1>(v40 * v43, v43, v42, v22, v20);
  // pto: %post_tail_store_inline8225__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v46 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v44, v45);
  // pto: %pre_val_store_inline5101__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %pre_val_store_inline5101__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %pre_val_store_inline5101__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %pre_val_store_inline5101__ssa_v0_view
  int64_t v50 = (int64_t) v11;
  // pto: %pre_val_store_inline5101__ssa_v0_view
  int64_t v51 = v50 * v22;
  // pto: %pre_val_store_inline5101__ssa_v0_view
  int64_t v52 = v49 * v51;
  // pto: %pre_val_store_inline5101__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v47, v48, v49, v50, v22);
  // pto: %pre_val_store_inline5101__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v48 * v52, v52, v51, v22, v20);
  // pto: %pre_val_store_inline5101__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v53, v54);
  // pto: %inv_rms_inline912_inline5083__ssa_v1_view
  const int64_t v56 = 1;
  // pto: %inv_rms_inline912_inline5083__ssa_v1_view
  const int64_t v57 = 1;
  // pto: %inv_rms_inline912_inline5083__ssa_v1_view
  const int64_t v58 = 1;
  // pto: %inv_rms_inline912_inline5083__ssa_v1_view
  int64_t v59 = (int64_t) v12;
  // pto: %inv_rms_inline912_inline5083__ssa_v1_view
  int64_t v60 = v59 * v20;
  // pto: %inv_rms_inline912_inline5083__ssa_v1_view
  int64_t v61 = v58 * v60;
  // pto: %inv_rms_inline912_inline5083__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v62 = pto::Shape<1, 1, 1, -1, -1>(v56, v57, v58, v59, v20);
  // pto: %inv_rms_inline912_inline5083__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v63 = pto::Stride<-1, -1, -1, -1, -1>(v57 * v61, v61, v60, v20, (int64_t) v12);
  // pto: %inv_rms_inline912_inline5083__ssa_v1_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v64 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v5, v62, v63);
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %hc_attn_base__ssa_v0_view
  int64_t v69 = v23 * v20;
  // pto: %hc_attn_base__ssa_v0_view
  int64_t v70 = v68 * v69;
  // pto: %hc_attn_base__ssa_v0_view
  int64_t v71 = v67 * v70;
  // pto: %hc_attn_base__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v72 = pto::Shape<1, 1, 1, 1, -1>(v65, v66, v67, v68, v23);
  // pto: %hc_attn_base__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v73 = pto::Stride<-1, -1, -1, -1, -1>(v66 * v71, v71, v70, v69, v20);
  // pto: %hc_attn_base__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v74 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v72, v73);
  // pto: %mixes_raw_inline8258__ssa_v1_view
  const int64_t v75 = 1;
  // pto: %mixes_raw_inline8258__ssa_v1_view
  const int64_t v76 = 1;
  // pto: %mixes_raw_inline8258__ssa_v1_view
  const int64_t v77 = 1;
  // pto: %mixes_raw_inline8258__ssa_v1_view
  int64_t v78 = (int64_t) v13;
  // pto: %mixes_raw_inline8258__ssa_v1_view
  int64_t v79 = v78 * v24;
  // pto: %mixes_raw_inline8258__ssa_v1_view
  int64_t v80 = v77 * v79;
  // pto: %mixes_raw_inline8258__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v81 = pto::Shape<1, 1, 1, -1, -1>(v75, v76, v77, v78, v24);
  // pto: %mixes_raw_inline8258__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v82 = pto::Stride<-1, -1, -1, -1, -1>(v76 * v80, v80, v79, v24, v20);
  // pto: %mixes_raw_inline8258__ssa_v1_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v83 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v81, v82);
  // pto: %ob_worker_inline8227__ssa_v0
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  // pto: %scale0_inline8270__tile
  float v84 = (v1)[v25];
  // pto: %scale1_inline8252__tile
  float v85 = (v1)[v20];
  // pto: %16
  for (int64_t v86 = (int64_t) v14; v86 < v8; v86 += v8 < v26 ? v8 : v26) {
    // pto: %17
    ;
    int64_t v87 = (int64_t) ((uint64_t) v86 * (uint64_t) v22);
    // pto: %18
    ;
    int64_t v88 = (int64_t) ((uint64_t) v9 - (uint64_t) v87);
    // pto: %19
    ;
    int64_t v89 = v88 < v22 ? v88 : v22;
    // pto: %inv_col_inline8308__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v20);
    // pto: %inv_col_inline8308__tile
    ;
    uint64_t v91 = (uint64_t) v16;
    TASSIGN(v90, v91);
    // pto: %20
    ;
    int64_t v92 = v87 < v25 ? v25 : v87;
    // pto: %inv_rms_inline912_inline5083__ssa_v1_pview
    ;
    int64_t v93 = (int64_t) v12;
    // pto: %inv_rms_inline912_inline5083__ssa_v1_pview
    ;
    const int64_t v94 = 0;
    // pto: %inv_rms_inline912_inline5083__ssa_v1_pview
    ;
    __gm__ float* v95 = PTOAS__GLOBAL_TENSOR_DATA(v64);
    // pto: %inv_rms_inline912_inline5083__ssa_v1_pview
    ;
    const int64_t v96 = 1;
    // pto: %inv_rms_inline912_inline5083__ssa_v1_pview
    ;
    const int64_t v97 = 1;
    // pto: %inv_rms_inline912_inline5083__ssa_v1_pview
    ;
    const int64_t v98 = 1;
    // pto: %inv_rms_inline912_inline5083__ssa_v1_pview
    ;
    int64_t v99 = v22 * v20;
    // pto: %inv_rms_inline912_inline5083__ssa_v1_pview
    ;
    int64_t v100 = v98 * v99;
    // pto: %inv_rms_inline912_inline5083__ssa_v1_pview
    ;
    pto::Shape<1, 1, 1, 8, 1> v101 = pto::Shape<1, 1, 1, 8, 1>(v96, v97, v98, v22, v20);
    // pto: %inv_rms_inline912_inline5083__ssa_v1_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v102 = pto::Stride<-1, -1, -1, -1, -1>(v97 * v100, v100, v99, v20, v93);
    // pto: %inv_rms_inline912_inline5083__ssa_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v103 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v95 + (v94 + v92 * v20 + v25 * v93), v101, v102);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v90, v103);
    // pto: %t__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
    // pto: %t__tile
    ;
    uint64_t v105 = (uint64_t) v17;
    TASSIGN(v104, v105);
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    __gm__ float* v106 = PTOAS__GLOBAL_TENSOR_DATA(v74);
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v107 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    pto::Stride<8, 8, 8, 8, 1> v108 = pto::Stride<8, 8, 8, 8, 1>();
    // pto: %hc_attn_base__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v109 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v106, v107, v108);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    TLOAD(v104, v109);
    // pto: %pre_base_inline8277__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
    // pto: %pre_base_inline8277__tile
    ;
    uint64_t v111 = (uint64_t) v17;
    TASSIGN(v110, v111);
    // pto: %0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %0
    ;
    uint64_t v113 = (uint64_t) v18;
    TASSIGN(v112, v113);
    // pto: %mixes_raw_inline8258__ssa_v1_pview
    ;
    __gm__ float* v114 = PTOAS__GLOBAL_TENSOR_DATA(v83);
    // pto: %mixes_raw_inline8258__ssa_v1_pview
    ;
    const int64_t v115 = 0;
    // pto: %mixes_raw_inline8258__ssa_v1_pview
    ;
    const int64_t v116 = 32;
    // pto: %mixes_raw_inline8258__ssa_v1_pview
    ;
    pto::Shape<1, 1, 1, 8, 8> v117 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %mixes_raw_inline8258__ssa_v1_pview
    ;
    pto::Stride<256, 256, 256, 32, 1> v118 = pto::Stride<256, 256, 256, 32, 1>();
    // pto: %mixes_raw_inline8258__ssa_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<256, 256, 256, 32, 1>, pto::Layout::ND> v119 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<256, 256, 256, 32, 1>, pto::Layout::ND>(v114 + (v115 + v92 * v116), v117, v118);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    TLOAD(v112, v119);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %1
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %1
    ;
    uint64_t v121 = (uint64_t) v18;
    TASSIGN(v120, v121);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TROWEXPANDMUL(v120, v112, v90);
    // pto: %pre_scaled_inline8254__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %pre_scaled_inline8254__tile
    ;
    uint64_t v123 = (uint64_t) v18;
    TASSIGN(v122, v123);
    pipe_barrier(PIPE_V);
    TMULS(v122, v120, v84);
    // pto: %2
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %2
    ;
    uint64_t v125 = (uint64_t) v19;
    TASSIGN(v124, v125);
    TCOLEXPAND(v124, v110);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    // pto: %pre_logits_inline8245__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v126 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %pre_logits_inline8245__tile
    ;
    uint64_t v127 = (uint64_t) v18;
    TASSIGN(v126, v127);
    pipe_barrier(PIPE_V);
    TADD(v126, v122, v124);
    // pto: %3
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v128 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %3
    ;
    uint64_t v129 = (uint64_t) v19;
    TASSIGN(v128, v129);
    pipe_barrier(PIPE_V);
    TEXPANDS(v128, v27);
    // pto: %4
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %4
    ;
    uint64_t v131 = (uint64_t) v18;
    TASSIGN(v130, v131);
    TNEG(v130, v126);
    // pto: %5
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %5
    ;
    uint64_t v133 = (uint64_t) v18;
    TASSIGN(v132, v133);
    pipe_barrier(PIPE_V);
    TEXP(v132, v130);
    // pto: %6
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %6
    ;
    uint64_t v135 = (uint64_t) v18;
    TASSIGN(v134, v135);
    pipe_barrier(PIPE_V);
    TADDS(v134, v132, v27);
    // pto: %pre_sig_inline8264__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %pre_sig_inline8264__tile
    ;
    uint64_t v137 = (uint64_t) v18;
    TASSIGN(v136, v137);
    pipe_barrier(PIPE_V);
    TDIV(v136, v128, v134);
    // pto: %pre_val_inline8283__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %pre_val_inline8283__tile
    ;
    uint64_t v139 = (uint64_t) v18;
    TASSIGN(v138, v139);
    pipe_barrier(PIPE_V);
    TADDS(v138, v136, v28);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %pre_val_store_inline5101__iter_v1_pview
    ;
    __gm__ float* v140 = PTOAS__GLOBAL_TENSOR_DATA(v55);
    // pto: %pre_val_store_inline5101__iter_v1_pview
    ;
    const int64_t v141 = 0;
    // pto: %pre_val_store_inline5101__iter_v1_pview
    ;
    const int64_t v142 = 8;
    // pto: %pre_val_store_inline5101__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 8, 8> v143 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %pre_val_store_inline5101__iter_v1_pview
    ;
    pto::Stride<64, 64, 64, 8, 1> v144 = pto::Stride<64, 64, 64, 8, 1>();
    // pto: %pre_val_store_inline5101__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<64, 64, 64, 8, 1>, pto::Layout::ND> v145 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<64, 64, 64, 8, 1>, pto::Layout::ND>(v140 + (v141 + v92 * v142), v143, v144);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v145, v138);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    // pto: %7
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v146 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
    // pto: %7
    ;
    uint64_t v147 = (uint64_t) v17;
    TASSIGN(v146, v147);
    // pto: %23
    ;
    __gm__ float* v148 = PTOAS__GLOBAL_TENSOR_DATA(v74);
    // pto: %23
    ;
    unsigned v149 = 4;
    // pto: %23
    ;
    pto::Shape<1, 1, 1, 1, 8> v150 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %23
    ;
    pto::Stride<8, 8, 8, 8, 1> v151 = pto::Stride<8, 8, 8, 8, 1>();
    // pto: %23
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v152 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v148 + v149, v150, v151);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    TLOAD(v146, v152);
    // pto: %post_base_inline8220__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
    // pto: %post_base_inline8220__tile
    ;
    uint64_t v154 = (uint64_t) v17;
    TASSIGN(v153, v154);
    // pto: %8
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %8
    ;
    uint64_t v156 = (uint64_t) v18;
    TASSIGN(v155, v156);
    // pto: %25
    ;
    __gm__ float* v157 = PTOAS__GLOBAL_TENSOR_DATA(v83);
    // pto: %25
    ;
    const int64_t v158 = 4;
    // pto: %25
    ;
    const int64_t v159 = 32;
    // pto: %25
    ;
    pto::Shape<1, 1, 1, 8, 8> v160 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %25
    ;
    pto::Stride<256, 256, 256, 32, 1> v161 = pto::Stride<256, 256, 256, 32, 1>();
    // pto: %25
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<256, 256, 256, 32, 1>, pto::Layout::ND> v162 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<256, 256, 256, 32, 1>, pto::Layout::ND>(v157 + (v158 + v92 * v159), v160, v161);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    TLOAD(v155, v162);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %9
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v163 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %9
    ;
    uint64_t v164 = (uint64_t) v18;
    TASSIGN(v163, v164);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TROWEXPANDMUL(v163, v155, v90);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %post_scaled_inline8279__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %post_scaled_inline8279__tile
    ;
    uint64_t v166 = (uint64_t) v18;
    TASSIGN(v165, v166);
    pipe_barrier(PIPE_V);
    TMULS(v165, v163, v85);
    // pto: %10
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %10
    ;
    uint64_t v168 = (uint64_t) v19;
    TASSIGN(v167, v168);
    TCOLEXPAND(v167, v153);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    // pto: %post_logits_inline8218__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %post_logits_inline8218__tile
    ;
    uint64_t v170 = (uint64_t) v18;
    TASSIGN(v169, v170);
    pipe_barrier(PIPE_V);
    TADD(v169, v165, v167);
    // pto: %11
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v171 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %11
    ;
    uint64_t v172 = (uint64_t) v19;
    TASSIGN(v171, v172);
    pipe_barrier(PIPE_V);
    TEXPANDS(v171, v27);
    // pto: %12
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v173 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %12
    ;
    uint64_t v174 = (uint64_t) v18;
    TASSIGN(v173, v174);
    TNEG(v173, v169);
    // pto: %13
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %13
    ;
    uint64_t v176 = (uint64_t) v18;
    TASSIGN(v175, v176);
    pipe_barrier(PIPE_V);
    TEXP(v175, v173);
    // pto: %14
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %14
    ;
    uint64_t v178 = (uint64_t) v18;
    TASSIGN(v177, v178);
    pipe_barrier(PIPE_V);
    TADDS(v177, v175, v27);
    // pto: %post_sig_inline8271__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %post_sig_inline8271__tile
    ;
    uint64_t v180 = (uint64_t) v18;
    TASSIGN(v179, v180);
    pipe_barrier(PIPE_V);
    TDIV(v179, v171, v177);
    // pto: %post_pad_inline8285__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v22);
    // pto: %post_pad_inline8285__tile
    ;
    uint64_t v182 = (uint64_t) v18;
    TASSIGN(v181, v182);
    pipe_barrier(PIPE_V);
    TMULS(v181, v179, v29);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %26
    ;
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    if (v89 == v22) {
      // pto: %15
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v21);
      // pto: %15
      ;
      uint64_t v184 = (uint64_t) v18;
      TASSIGN(v183, v184);
      // pto: %slice_view
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, 8, 4, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v185;
      // pto: %slice_view
      ;
      uint64_t v186 = (uint64_t) v18;
      TASSIGN(v185, v186);
      // pto: %post__iter_v1_pview
      ;
      __gm__ float* v187 = PTOAS__GLOBAL_TENSOR_DATA(v38);
      // pto: %post__iter_v1_pview
      ;
      const int64_t v188 = 0;
      // pto: %post__iter_v1_pview
      ;
      const int64_t v189 = 4;
      // pto: %post__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, 8, 4> v190 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %post__iter_v1_pview
      ;
      pto::Stride<32, 32, 32, 4, 1> v191 = pto::Stride<32, 32, 32, 4, 1>();
      // pto: %post__iter_v1_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<32, 32, 32, 4, 1>, pto::Layout::ND> v192 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<32, 32, 32, 4, 1>, pto::Layout::ND>(v187 + (v188 + v92 * v189), v190, v191);
      TSTORE(v192, v185);
    } else {
      // pto: %post_tail_store_inline8225__iter_v1_pview
      ;
      __gm__ float* v193 = PTOAS__GLOBAL_TENSOR_DATA(v46);
      // pto: %post_tail_store_inline8225__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, 8, 8> v194 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %post_tail_store_inline8225__iter_v1_pview
      ;
      pto::Stride<64, 64, 64, 8, 1> v195 = pto::Stride<64, 64, 64, 8, 1>();
      // pto: %post_tail_store_inline8225__iter_v1_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<64, 64, 64, 8, 1>, pto::Layout::ND> v196 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<64, 64, 64, 8, 1>, pto::Layout::ND>(v193, v194, v195);
      TSTORE(v196, v181);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      // pto: %post_tile_inline8272__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v197 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v89, v21);
      // pto: %post_tile_inline8272__ssa_v0
      ;
      uint64_t v198 = (uint64_t) v18;
      TASSIGN(v197, v198);
      // pto: %post_tail_store_inline8225__tile_pview
      ;
      const int64_t v199 = 0;
      // pto: %post_tail_store_inline8225__tile_pview
      ;
      __gm__ float* v200 = PTOAS__GLOBAL_TENSOR_DATA(v46);
      // pto: %post_tail_store_inline8225__tile_pview
      ;
      const int64_t v201 = 1;
      // pto: %post_tail_store_inline8225__tile_pview
      ;
      const int64_t v202 = 1;
      // pto: %post_tail_store_inline8225__tile_pview
      ;
      const int64_t v203 = 1;
      // pto: %post_tail_store_inline8225__tile_pview
      ;
      int64_t v204 = v89 * v22;
      // pto: %post_tail_store_inline8225__tile_pview
      ;
      int64_t v205 = v203 * v204;
      // pto: %post_tail_store_inline8225__tile_pview
      ;
      pto::Shape<1, 1, 1, -1, 4> v206 = pto::Shape<1, 1, 1, -1, 4>(v201, v202, v203, v89, v21);
      // pto: %post_tail_store_inline8225__tile_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v207 = pto::Stride<-1, -1, -1, -1, -1>(v202 * v205, v205, v204, v22, v20);
      // pto: %post_tail_store_inline8225__tile_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v208 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v200 + (v199 + v25 * v22 + v25 * v20), v206, v207);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      TLOAD(v197, v208);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
      // pto: %29
      ;
      const int64_t v209 = 0;
      // pto: %29
      ;
      __gm__ float* v210 = PTOAS__GLOBAL_TENSOR_DATA(v38);
      // pto: %29
      ;
      const int64_t v211 = 1;
      // pto: %29
      ;
      const int64_t v212 = 1;
      // pto: %29
      ;
      const int64_t v213 = 1;
      // pto: %29
      ;
      int64_t v214 = v89 * v21;
      // pto: %29
      ;
      int64_t v215 = v213 * v214;
      // pto: %29
      ;
      pto::Shape<1, 1, 1, -1, 4> v216 = pto::Shape<1, 1, 1, -1, 4>(v211, v212, v213, v89, v21);
      // pto: %29
      ;
      pto::Stride<-1, -1, -1, -1, -1> v217 = pto::Stride<-1, -1, -1, -1, -1>(v212 * v215, v215, v214, v21, v20);
      // pto: %29
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v218 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v210 + (v209 + v92 * v21 + v25 * v20), v216, v217);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
      TSTORE(v218, v197);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}