#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_b64(__gm__ int8_t* v1, __gm__ int8_t* v2, __gm__ int32_t* v3, int64_t v4, int64_t v5, int64_t v6, int32_t v7, int32_t v8) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v9 = 0;
  // pto: %c32768_i64
  const int64_t v10 = 32768;
  // pto: %c16384_i64
  const int64_t v11 = 16384;
  // pto: %c8192_index
  const int64_t v12 = 8192;
  // pto: %c1_index
  const int64_t v13 = 1;
  // pto: %c128_index
  const int64_t v14 = 128;
  // pto: %c512_index
  const int64_t v15 = 512;
  // pto: %c16_index
  const int64_t v16 = 16;
  // pto: %c32_index
  const int64_t v17 = 32;
  // pto: %c33554432_index
  const int64_t v18 = 33554432;
  // pto: %c262144_index
  const int64_t v19 = 262144;
  // pto: %c4096_index
  const int64_t v20 = 4096;
  // pto: %c64_index
  const int64_t v21 = 64;
  // pto: %c0_index
  const int64_t v22 = 0;
  // pto: %c256_index
  const int64_t v23 = 256;
  // pto: %c63_index
  const int64_t v24 = 63;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %quantized_o__ssa_v0_view
  const int64_t v27 = 1;
  // pto: %quantized_o__ssa_v0_view
  int64_t v28 = (int64_t) v5;
  // pto: %quantized_o__ssa_v0_view
  int64_t v29 = v28 * v12;
  // pto: %quantized_o__ssa_v0_view
  int64_t v30 = v27 * v29;
  // pto: %quantized_o__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v31 = pto::Shape<1, 1, 1, -1, -1>(v25, v26, v27, v28, v12);
  // pto: %quantized_o__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v32 = pto::Stride<-1, -1, -1, -1, -1>(v26 * v30, v30, v29, v12, v13);
  // pto: %quantized_o__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v33 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v31, v32);
  // pto: %wo_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v34 = pto::Shape<-1, -1, -1, -1, -1>(v13, v14, v15, v16, v17);
  // pto: %wo_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v35 = pto::Stride<-1, -1, -1, -1, -1>(v18, v19, v15, v17, v13);
  // pto: %wo_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v36 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v2, v34, v35);
  // pto: %29
  int64_t v37 = (int64_t) ((uint64_t) v6 + (uint64_t) v24);
  // pto: %integer_accum_inline1506__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %integer_accum_inline1506__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %integer_accum_inline1506__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %integer_accum_inline1506__ssa_v0_view
  int64_t v41 = v37 * v20;
  // pto: %integer_accum_inline1506__ssa_v0_view
  int64_t v42 = v40 * v41;
  // pto: %integer_accum_inline1506__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v43 = pto::Shape<1, 1, 1, -1, -1>(v38, v39, v40, v37, v20);
  // pto: %integer_accum_inline1506__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v44 = pto::Stride<-1, -1, -1, -1, -1>(v39 * v42, v42, v41, v20, v13);
  // pto: %integer_accum_inline1506__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v45 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v43, v44);
  // pto: %wide_block_inline1461__ssa_v0
  int64_t v46 = (int64_t) v7;
  // pto: %9, %10
  int64_t v47 = (int64_t) ((uint64_t) (v46 / v17) * (uint64_t) v21);
  // pto: %11, %12
  int64_t v48 = (int64_t) ((uint64_t) (v46 % v17) * (uint64_t) v14);
  // pto: %13
  int64_t v49 = (int64_t) ((uint64_t) v6 - (uint64_t) v47);
  // pto: %14
  int64_t v50 = v49 < v21 ? v49 : v21;
  // pto: %wide_first_input_inline1442__tile
  Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v51 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v50, v15);
  // pto: %wide_first_input_inline1442__tile
  uint64_t v52 = (uint64_t) v9;
  TASSIGN(v51, v52);
  // pto: %15
  int64_t v53 = v47 < v22 ? v22 : v47;
  // pto: %quantized_o__ssa_v0_pview
  const int64_t v54 = 0;
  // pto: %quantized_o__ssa_v0_pview
  __gm__ int8_t* v55 = PTOAS__GLOBAL_TENSOR_DATA(v33);
  // pto: %quantized_o__ssa_v0_pview
  const int64_t v56 = 1;
  // pto: %quantized_o__ssa_v0_pview
  const int64_t v57 = 1;
  // pto: %quantized_o__ssa_v0_pview
  const int64_t v58 = 1;
  // pto: %quantized_o__ssa_v0_pview
  int64_t v59 = v50 * v12;
  // pto: %quantized_o__ssa_v0_pview
  int64_t v60 = v58 * v59;
  // pto: %quantized_o__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 512> v61 = pto::Shape<1, 1, 1, -1, 512>(v56, v57, v58, v50, v15);
  // pto: %quantized_o__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v62 = pto::Stride<-1, -1, -1, -1, -1>(v57 * v60, v60, v59, v12, v13);
  // pto: %quantized_o__ssa_v0_pview
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v63 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v55 + (v54 + v53 * v12 + v22 * v13), v61, v62);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  TLOAD(v51, v63);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  // pto: %wide_first_weight_inline1538__tile
  Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v64 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v14);
  // pto: %wide_first_weight_inline1538__tile
  uint64_t v65 = (uint64_t) v10;
  TASSIGN(v64, v65);
  // pto: %16
  int64_t v66 = v48 / v17;
  // pto: %17
  int64_t v67 = v66 < v22 ? v22 : v66;
  // pto: %wo_b__ssa_v0_pview
  __gm__ int8_t* v68 = PTOAS__GLOBAL_TENSOR_DATA(v36);
  // pto: %wo_b__ssa_v0_pview
  const int64_t v69 = 0;
  // pto: %wo_b__ssa_v0_pview
  const int64_t v70 = 262144;
  // pto: %wo_b__ssa_v0_pview
  pto::Shape<1, 4, 32, 16, 32> v71 = pto::Shape<1, 4, 32, 16, 32>();
  // pto: %wo_b__ssa_v0_pview
  pto::Stride<33554432, 262144, 512, 32, 1> v72 = pto::Stride<33554432, 262144, 512, 32, 1>();
  // pto: %wo_b__ssa_v0_pview
  GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v73 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v68 + (v69 + v67 * v70), v71, v72);
  TLOAD(v64, v73);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
  // pto: %wide_b_acc_inline1540__tile_l0_init_storage
  Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v74 = Tile<TileType::Acc, int32_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v21, v14);
  // pto: %wide_b_acc_inline1540__tile_l0_init_storage
  uint64_t v75 = (uint64_t) v9;
  TASSIGN(v74, v75);
  v74.SetValidShape(v50, v14);
  // pto: %wide_b_acc_inline1540__tile_l0_a
  Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v76 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v50, v23);
  // pto: %wide_b_acc_inline1540__tile_l0_a
  uint64_t v77 = (uint64_t) v9;
  TASSIGN(v76, v77);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  uint16_t v78 = static_cast<uint16_t>(v22);
  uint16_t v79 = static_cast<uint16_t>(v22);
  TEXTRACT(v76, v51, v78, v79);
  // pto: %wide_b_acc_inline1540__tile_l0_b
  Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v80 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v14);
  // pto: %wide_b_acc_inline1540__tile_l0_b
  uint64_t v81 = (uint64_t) v9;
  TASSIGN(v80, v81);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
  uint16_t v82 = static_cast<uint16_t>(v22);
  uint16_t v83 = static_cast<uint16_t>(v22);
  TEXTRACT(v80, v64, v82, v83);
  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
  // pto: %0
  Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v84 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v50, v23);
  // pto: %0
  uint64_t v85 = (uint64_t) v11;
  TASSIGN(v84, v85);
  uint16_t v86 = static_cast<uint16_t>(v22);
  uint16_t v87 = static_cast<uint16_t>(v23);
  TEXTRACT(v84, v51, v86, v87);
  // pto: %1
  Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v14);
  // pto: %1
  uint64_t v89 = (uint64_t) v10;
  TASSIGN(v88, v89);
  uint16_t v90 = static_cast<uint16_t>(v23);
  uint16_t v91 = static_cast<uint16_t>(v22);
  TEXTRACT(v88, v64, v90, v91);
  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
  TMATMUL(v74, v76, v80);
  pipe_barrier(PIPE_M);
  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
  TMATMUL_ACC(v74, v74, v84, v88);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t v92 = v13; v92 < v16; v92 += v13) {
    // pto: %18
    ;
    int64_t v93 = (int64_t) ((uint64_t) v92 * (uint64_t) v15);
    // pto: %wide_b_input_inline1542__tile
    ;
    Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Mat, int8_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v50, v15);
    // pto: %wide_b_input_inline1542__tile
    ;
    uint64_t v95 = (uint64_t) v9;
    TASSIGN(v94, v95);
    // pto: %20
    ;
    int64_t v96 = v93 < v22 ? v22 : v93;
    // pto: %21
    ;
    const int64_t v97 = 0;
    // pto: %21
    ;
    __gm__ int8_t* v98 = PTOAS__GLOBAL_TENSOR_DATA(v33);
    // pto: %21
    ;
    const int64_t v99 = 1;
    // pto: %21
    ;
    const int64_t v100 = 1;
    // pto: %21
    ;
    const int64_t v101 = 1;
    // pto: %21
    ;
    int64_t v102 = v50 * v12;
    // pto: %21
    ;
    int64_t v103 = v101 * v102;
    // pto: %21
    ;
    pto::Shape<1, 1, 1, -1, 512> v104 = pto::Shape<1, 1, 1, -1, 512>(v99, v100, v101, v50, v15);
    // pto: %21
    ;
    pto::Stride<-1, -1, -1, -1, -1> v105 = pto::Stride<-1, -1, -1, -1, -1>(v100 * v103, v103, v102, v12, v13);
    // pto: %21
    ;
    GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v106 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v98 + (v97 + v53 * v12 + v96 * v13), v104, v105);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v94, v106);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    // pto: %wide_b_weight_inline1510__tile
    ;
    Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v107 = Tile<TileType::Mat, int8_t, 512, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v15, v14);
    // pto: %wide_b_weight_inline1510__tile
    ;
    uint64_t v108 = (uint64_t) v10;
    TASSIGN(v107, v108);
    // pto: %24
    ;
    int64_t v109 = v93 / v16;
    // pto: %25
    ;
    int64_t v110 = v109 < v22 ? v22 : v109;
    // pto: %26
    ;
    __gm__ int8_t* v111 = PTOAS__GLOBAL_TENSOR_DATA(v36);
    // pto: %26
    ;
    const int64_t v112 = 0;
    // pto: %26
    ;
    const int64_t v113 = 262144;
    // pto: %26
    ;
    const int64_t v114 = 512;
    // pto: %26
    ;
    pto::Shape<1, 4, 32, 16, 32> v115 = pto::Shape<1, 4, 32, 16, 32>();
    // pto: %26
    ;
    pto::Stride<33554432, 262144, 512, 32, 1> v116 = pto::Stride<33554432, 262144, 512, 32, 1>();
    // pto: %26
    ;
    GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ> v117 = GlobalTensor<int8_t, pto::Shape<1, 4, 32, 16, 32>, pto::Stride<33554432, 262144, 512, 32, 1>, pto::Layout::NZ>(v111 + (v112 + v67 * v113 + v110 * v114), v115, v116);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    TLOAD(v107, v117);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    // pto: %3
    ;
    Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v118 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v50, v23);
    // pto: %3
    ;
    uint64_t v119 = (uint64_t) v9;
    TASSIGN(v118, v119);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    uint16_t v120 = static_cast<uint16_t>(v22);
    uint16_t v121 = static_cast<uint16_t>(v22);
    TEXTRACT(v118, v94, v120, v121);
    // pto: %4
    ;
    Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v14);
    // pto: %4
    ;
    uint64_t v123 = (uint64_t) v9;
    TASSIGN(v122, v123);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
    uint16_t v124 = static_cast<uint16_t>(v22);
    uint16_t v125 = static_cast<uint16_t>(v22);
    TEXTRACT(v122, v107, v124, v125);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
    // pto: %5
    ;
    Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v126 = Tile<TileType::Left, int8_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v50, v23);
    // pto: %5
    ;
    uint64_t v127 = (uint64_t) v11;
    TASSIGN(v126, v127);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
    uint16_t v128 = static_cast<uint16_t>(v22);
    uint16_t v129 = static_cast<uint16_t>(v23);
    TEXTRACT(v126, v94, v128, v129);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    // pto: %6
    ;
    Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Right, int8_t, 256, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v23, v14);
    // pto: %6
    ;
    uint64_t v131 = (uint64_t) v10;
    TASSIGN(v130, v131);
    uint16_t v132 = static_cast<uint16_t>(v23);
    uint16_t v133 = static_cast<uint16_t>(v22);
    TEXTRACT(v130, v107, v132, v133);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
    pipe_barrier(PIPE_M);
    TMATMUL_ACC(v74, v74, v118, v122);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    pipe_barrier(PIPE_M);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
    TMATMUL_ACC(v74, v74, v126, v130);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  }
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  // pto: %28
  int64_t v134 = v48 < v22 ? v22 : v48;
  // pto: %integer_accum_inline1506__ssa_v0_pview
  const int64_t v135 = 0;
  // pto: %integer_accum_inline1506__ssa_v0_pview
  __gm__ int32_t* v136 = PTOAS__GLOBAL_TENSOR_DATA(v45);
  // pto: %integer_accum_inline1506__ssa_v0_pview
  const int64_t v137 = 1;
  // pto: %integer_accum_inline1506__ssa_v0_pview
  const int64_t v138 = 1;
  // pto: %integer_accum_inline1506__ssa_v0_pview
  const int64_t v139 = 1;
  // pto: %integer_accum_inline1506__ssa_v0_pview
  int64_t v140 = v50 * v20;
  // pto: %integer_accum_inline1506__ssa_v0_pview
  int64_t v141 = v139 * v140;
  // pto: %integer_accum_inline1506__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 128> v142 = pto::Shape<1, 1, 1, -1, 128>(v137, v138, v139, v50, v14);
  // pto: %integer_accum_inline1506__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v143 = pto::Stride<-1, -1, -1, -1, -1>(v138 * v141, v141, v140, v20, v13);
  // pto: %integer_accum_inline1506__ssa_v0_pview
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v144 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v136 + (v135 + v53 * v20 + v134 * v13), v142, v143);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE(v144, v74);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}