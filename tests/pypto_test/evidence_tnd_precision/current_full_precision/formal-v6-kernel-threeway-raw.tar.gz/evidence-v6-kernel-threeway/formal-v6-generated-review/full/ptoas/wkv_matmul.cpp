#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void wkv_matmul(__gm__ int32_t* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, __gm__ float* v4, int64_t v5, int64_t v6, int64_t v7, int32_t v8, int32_t v9) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v10 = 0;
  // pto: %c8192_i64
  const int64_t v11 = 8192;
  // pto: %c32_index
  const int64_t v12 = 32;
  // pto: %c16_index
  const int64_t v13 = 16;
  // pto: %c1_index
  const int64_t v14 = 1;
  // pto: %c4096_index
  const int64_t v15 = 4096;
  // pto: %c512_index
  const int64_t v16 = 512;
  // pto: %c0_index
  const int64_t v17 = 0;
  // pto: %c256_index
  const int64_t v18 = 256;
  // pto: %c63_index
  const int64_t v19 = 63;
  // pto: %normed__ssa_v0_view
  const int64_t v20 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v21 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v22 = 1;
  // pto: %normed__ssa_v0_view
  int64_t v23 = (int64_t) v6;
  // pto: %normed__ssa_v0_view
  int64_t v24 = v23 * v15;
  // pto: %normed__ssa_v0_view
  int64_t v25 = v22 * v24;
  // pto: %normed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v26 = pto::Shape<1, 1, 1, -1, -1>(v20, v21, v22, v23, v15);
  // pto: %normed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v27 = pto::Stride<-1, -1, -1, -1, -1>(v21 * v25, v25, v24, v15, v14);
  // pto: %normed__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v28 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v26, v27);
  // pto: %wkv__ssa_v0_view
  const int64_t v29 = 1;
  // pto: %wkv__ssa_v0_view
  const int64_t v30 = 1;
  // pto: %wkv__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %wkv__ssa_v0_view
  int64_t v32 = v16 * v15;
  // pto: %wkv__ssa_v0_view
  int64_t v33 = v31 * v32;
  // pto: %wkv__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v34 = pto::Shape<1, 1, 1, -1, -1>(v29, v30, v31, v16, v15);
  // pto: %wkv__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v35 = pto::Stride<-1, -1, -1, -1, -1>(v30 * v33, v33, v32, v15, v14);
  // pto: %wkv__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v36 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v34, v35);
  // pto: %16
  int64_t v37 = (int64_t) ((uint64_t) v7 + (uint64_t) v19);
  // pto: %accum_inline1275__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %accum_inline1275__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %accum_inline1275__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %accum_inline1275__ssa_v0_view
  int64_t v41 = v37 * v16;
  // pto: %accum_inline1275__ssa_v0_view
  int64_t v42 = v40 * v41;
  // pto: %accum_inline1275__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v43 = pto::Shape<1, 1, 1, -1, -1>(v38, v39, v40, v37, v16);
  // pto: %accum_inline1275__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v44 = pto::Stride<-1, -1, -1, -1, -1>(v39 * v42, v42, v41, v16, v14);
  // pto: %accum_inline1275__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v45 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v43, v44);
  // pto: %m16_worker_inline1266__ssa_v0
  int64_t v46 = (int64_t) v8;
  // pto: %1, %2
  int64_t v47 = (int64_t) ((uint64_t) (v46 / v12) * (uint64_t) v13);
  // pto: %3, %4
  int64_t v48 = (int64_t) ((uint64_t) (v46 % v12) * (uint64_t) v13);
  // pto: %5
  int64_t v49 = (int64_t) ((uint64_t) v7 - (uint64_t) v47);
  // pto: %m16_tile_inline1270__tile
  Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v50 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v13, v13);
  // pto: %m16_tile_inline1270__tile
  uint64_t v51 = (uint64_t) v10;
  TASSIGN(v50, v51);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  for (int64_t v52 = v17; v52 < v13; v52 += v14) {
    // pto: %flat_offset, %m16_k_block_inline1269__tile
    ;
    int32_t v53 = (v1)[(int64_t) ((uint64_t) v48 + (uint64_t) v52)];
    // pto: %6
    ;
    int64_t v54 = (int64_t) v53;
    // pto: %7
    ;
    int64_t v55 = v54 < v17 ? v17 : v54;
    // pto: %8
    ;
    int64_t v56 = (int64_t) ((uint64_t) v55 * (uint64_t) v18);
    // pto: %m16_a_inline1278__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v57 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v49, v18);
    // pto: %m16_a_inline1278__tile
    ;
    uint64_t v58 = (uint64_t) v10;
    TASSIGN(v57, v58);
    // pto: %9
    ;
    int64_t v59 = v47 < v17 ? v17 : v47;
    // pto: %10
    ;
    int64_t v60 = v56 < v17 ? v17 : v56;
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v61 = 0;
    // pto: %normed__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v62 = PTOAS__GLOBAL_TENSOR_DATA(v28);
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v63 = 1;
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v64 = 1;
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v65 = 1;
    // pto: %normed__ssa_v0_pview
    ;
    int64_t v66 = v49 * v15;
    // pto: %normed__ssa_v0_pview
    ;
    int64_t v67 = v65 * v66;
    // pto: %normed__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 256> v68 = pto::Shape<1, 1, 1, -1, 256>(v63, v64, v65, v49, v18);
    // pto: %normed__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v69 = pto::Stride<-1, -1, -1, -1, -1>(v64 * v67, v67, v66, v15, v14);
    // pto: %normed__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v70 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v62 + (v61 + v59 * v15 + v60 * v14), v68, v69);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v57, v70);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %m16_b_inline1279__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v71 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v13, v18);
    // pto: %m16_b_inline1279__tile
    ;
    uint64_t v72 = (uint64_t) v11;
    TASSIGN(v71, v72);
    // pto: %11
    ;
    int64_t v73 = v48 < v17 ? v17 : v48;
    // pto: %wkv__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v74 = PTOAS__GLOBAL_TENSOR_DATA(v36);
    // pto: %wkv__ssa_v0_pview
    ;
    const int64_t v75 = 0;
    // pto: %wkv__ssa_v0_pview
    ;
    const int64_t v76 = 4096;
    // pto: %wkv__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 16, 256> v77 = pto::Shape<1, 1, 1, 16, 256>();
    // pto: %wkv__ssa_v0_pview
    ;
    pto::Stride<65536, 65536, 65536, 4096, 1> v78 = pto::Stride<65536, 65536, 65536, 4096, 1>();
    // pto: %wkv__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v79 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v74 + (v75 + v73 * v76 + v60), v77, v78);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    TLOAD(v71, v79);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    // pto: %m16_b_inline1279__tile_t
    ;
    Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v80 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v13);
    // pto: %m16_b_inline1279__tile_t
    ;
    uint64_t v81 = (uint64_t) v11;
    TASSIGN(v80, v81);
    // pto: %m16_a_inline1278__tile_Left
    ;
    Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v82 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v49, v18);
    // pto: %m16_a_inline1278__tile_Left
    ;
    uint64_t v83 = (uint64_t) v10;
    TASSIGN(v82, v83);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    TMOV(v82, v57);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    // pto: %m16_b_inline1279__tile_t_Right
    ;
    Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v84 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v18, v13);
    // pto: %m16_b_inline1279__tile_t_Right
    ;
    uint64_t v85 = (uint64_t) v10;
    TASSIGN(v84, v85);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    TMOV(v84, v80);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    // pto: %13
    ;
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    if (v52 == v17) {
      TMATMUL(v50, v82, v84);
    } else {
      TMATMUL_ACC(v50, v50, v82, v84);
    };
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  }
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  // pto: %14
  int64_t v86 = v47 < v17 ? v17 : v47;
  // pto: %15
  int64_t v87 = v48 < v17 ? v17 : v48;
  // pto: %accum_inline1275__ssa_v0_pview
  __gm__ float* v88 = PTOAS__GLOBAL_TENSOR_DATA(v45);
  // pto: %accum_inline1275__ssa_v0_pview
  const int64_t v89 = 0;
  // pto: %accum_inline1275__ssa_v0_pview
  const int64_t v90 = 512;
  // pto: %accum_inline1275__ssa_v0_pview
  pto::Shape<1, 1, 1, 16, 16> v91 = pto::Shape<1, 1, 1, 16, 16>();
  // pto: %accum_inline1275__ssa_v0_pview
  pto::Stride<8192, 8192, 8192, 512, 1> v92 = pto::Stride<8192, 8192, 8192, 512, 1>();
  // pto: %accum_inline1275__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v93 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v88 + (v89 + v86 * v90 + v87), v91, v92);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE(v93, v50);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}