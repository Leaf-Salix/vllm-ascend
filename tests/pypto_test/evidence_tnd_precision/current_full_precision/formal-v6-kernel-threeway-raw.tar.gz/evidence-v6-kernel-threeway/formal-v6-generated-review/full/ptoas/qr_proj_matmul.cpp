#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qr_proj_matmul(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, int64_t v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int64_t v9, int32_t v10, int32_t v11) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v12 = 0;
  // pto: %c32768_i64
  const int64_t v13 = 32768;
  // pto: %c49152_i64
  const int64_t v14 = 49152;
  // pto: %c81920_i64
  const int64_t v15 = 81920;
  // pto: %c16384_i64
  const int64_t v16 = 16384;
  // pto: %c1024_index
  const int64_t v17 = 1024;
  // pto: %c1_index
  const int64_t v18 = 1;
  // pto: %c4096_index
  const int64_t v19 = 4096;
  // pto: %c256_index
  const int64_t v20 = 256;
  // pto: %c64_index
  const int64_t v21 = 64;
  // pto: %c16_index
  const int64_t v22 = 16;
  // pto: %c4194304_index
  const int64_t v23 = 4194304;
  // pto: %c16384_index
  const int64_t v24 = 16384;
  // pto: %c32_index
  const int64_t v25 = 32;
  // pto: %c96_index
  const int64_t v26 = 96;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %c2_index
  const int64_t v28 = 2;
  // pto: %c240_index
  const int64_t v29 = 240;
  // pto: %c48_index
  const int64_t v30 = 48;
  // pto: %c9_index
  const int64_t v31 = 9;
  // pto: %c15_index
  const int64_t v32 = 15;
  // pto: %c3_index
  const int64_t v33 = 3;
  // pto: %c14_index
  const int64_t v34 = 14;
  // pto: %cn1_index
  const int64_t v35 = -1;
  // pto: %qr_fp32_inline174_inline5151__rv_v2_view
  const int64_t v36 = 1;
  // pto: %qr_fp32_inline174_inline5151__rv_v2_view
  const int64_t v37 = 1;
  // pto: %qr_fp32_inline174_inline5151__rv_v2_view
  const int64_t v38 = 1;
  // pto: %qr_fp32_inline174_inline5151__rv_v2_view
  int64_t v39 = (int64_t) v8;
  // pto: %qr_fp32_inline174_inline5151__rv_v2_view
  int64_t v40 = v39 * v17;
  // pto: %qr_fp32_inline174_inline5151__rv_v2_view
  int64_t v41 = v38 * v40;
  // pto: %qr_fp32_inline174_inline5151__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v42 = pto::Shape<1, 1, 1, -1, -1>(v36, v37, v38, v39, v17);
  // pto: %qr_fp32_inline174_inline5151__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v43 = pto::Stride<-1, -1, -1, -1, -1>(v37 * v41, v41, v40, v17, v18);
  // pto: %qr_fp32_inline174_inline5151__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v44 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v42, v43);
  // pto: %x_view_inline8333__ssa_v0_view
  const int64_t v45 = 1;
  // pto: %x_view_inline8333__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %x_view_inline8333__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %x_view_inline8333__ssa_v0_view
  int64_t v48 = (int64_t) v9;
  // pto: %x_view_inline8333__ssa_v0_view
  int64_t v49 = v48 * v19;
  // pto: %x_view_inline8333__ssa_v0_view
  int64_t v50 = v47 * v49;
  // pto: %x_view_inline8333__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v51 = pto::Shape<1, 1, 1, -1, -1>(v45, v46, v47, v48, v19);
  // pto: %x_view_inline8333__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v52 = pto::Stride<-1, -1, -1, -1, -1>(v46 * v50, v50, v49, v19, v18);
  // pto: %x_view_inline8333__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v53 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v51, v52);
  // pto: %wq_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v54 = pto::Shape<-1, -1, -1, -1, -1>(v18, v20, v21, v22, v22);
  // pto: %wq_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v55 = pto::Stride<-1, -1, -1, -1, -1>(v23, v24, v20, v22, v18);
  // pto: %wq_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v56 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v3, v54, v55);
  // pto: %qbg_idx_inline8323__ssa_v0, %14
  int64_t v57 = (int64_t) ((uint64_t) ((int64_t) v10) * (uint64_t) v25);
  // pto: %15
  int64_t v58 = v57 / v26;
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  for (int64_t v59 = v27; v59 < v4; v59 += v21) {
    // pto: %16
    ;
    int64_t v60 = (int64_t) ((uint64_t) v5 + (uint64_t) v59);
    // pto: %dense_acc_inline8338__tile
    ;
    Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v61 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v21, v25);
    // pto: %dense_acc_inline8338__tile
    ;
    uint64_t v62 = (uint64_t) v12;
    TASSIGN(v61, v62);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    for (int64_t v63 = v27; v63 < v22; v63 += v28) {
      // pto: %17
      ;
      int64_t v64 = (int64_t) ((uint64_t) v63 + (uint64_t) v18);
      // pto: %18, %19, %20, %21, %22, %23, %24, %25
      ;
      bool v65 = (v6 >= v26 & v6 <= v29 & v6 % v30 == v27) & v58 < v31;
      // pto: %dense_k_order_inline8337__phi_v2
      ;
      int64_t v66;
      if (v65) {
        // pto: %26, %27
        ;
        // pto: %dense_k_direction_inline8341__phi_v2
        ;
        int64_t v67;
        if (v58 % v28 == v18) {
          // pto: %28
          ;
          v67 = (int64_t) ((uint64_t) v32 - (uint64_t) v63);
        } else {
          v67 = v63;
        };
        // pto: %31
        ;
        uint64_t v68 = (uint64_t) v67;
        // pto: %29, %30, %31, %32
        ;
        v66 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v58 / v28) * (uint64_t) v33) + v68) % v22;
      } else {
        v66 = v63;
      };
      // pto: %33
      ;
      bool v69 = v66 < v27;
      // pto: %33
      ;
      int64_t v70 = v69 ? v27 : v66;
      // pto: %34
      ;
      int64_t v71 = (int64_t) ((uint64_t) v70 * (uint64_t) v20);
      // pto: %dense_x_inline8342__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v72 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %dense_x_inline8342__tile
      ;
      uint64_t v73 = (uint64_t) v12;
      TASSIGN(v72, v73);
      // pto: %35
      ;
      int64_t v74 = v60 < v27 ? v27 : v60;
      // pto: %36
      ;
      int64_t v75 = v71 < v27 ? v27 : v71;
      // pto: %x_view_inline8333__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v76 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %x_view_inline8333__ssa_v0_pview
      ;
      const int64_t v77 = 0;
      // pto: %x_view_inline8333__ssa_v0_pview
      ;
      const int64_t v78 = 4096;
      // pto: %x_view_inline8333__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 64, 256> v79 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %x_view_inline8333__ssa_v0_pview
      ;
      pto::Stride<262144, 262144, 262144, 4096, 1> v80 = pto::Stride<262144, 262144, 262144, 4096, 1>();
      // pto: %x_view_inline8333__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND> v81 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND>(v76 + (v77 + v74 * v78 + v75), v79, v80);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v72, v81);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %dense_w_inline8332__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v82 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %dense_w_inline8332__tile
      ;
      uint64_t v83 = (uint64_t) v13;
      TASSIGN(v82, v83);
      // pto: %37
      ;
      int64_t v84 = v71 / v22;
      // pto: %38
      ;
      int64_t v85 = v84 < v27 ? v27 : v84;
      // pto: %39
      ;
      int64_t v86 = v57 / v22;
      // pto: %40
      ;
      int64_t v87 = v86 < v27 ? v27 : v86;
      // pto: %wq_a__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v88 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %wq_a__ssa_v0_pview
      ;
      const int64_t v89 = 0;
      // pto: %wq_a__ssa_v0_pview
      ;
      const int64_t v90 = 16384;
      // pto: %wq_a__ssa_v0_pview
      ;
      const int64_t v91 = 256;
      // pto: %wq_a__ssa_v0_pview
      ;
      pto::Shape<1, 16, 2, 16, 16> v92 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %wq_a__ssa_v0_pview
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v93 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %wq_a__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v94 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v88 + (v89 + v85 * v90 + v87 * v91), v92, v93);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v82, v94);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %49
      ;
      int64_t v95;
      if (v65) {
        // pto: %51, %52
        ;
        // pto: %53
        ;
        int64_t v96;
        if (v58 % v28 == v18) {
          // pto: %54
          ;
          v96 = (int64_t) ((uint64_t) v34 - (uint64_t) v63);
        } else {
          v96 = v64;
        };
        // pto: %57
        ;
        uint64_t v97 = (uint64_t) v96;
        // pto: %55, %56, %57, %58
        ;
        v95 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v58 / v28) * (uint64_t) v33) + v97) % v22;
      } else {
        v95 = v64;
      };
      // pto: %59
      ;
      bool v98 = v95 < v27;
      // pto: %59
      ;
      int64_t v99 = v98 ? v27 : v95;
      // pto: %60
      ;
      int64_t v100 = (int64_t) ((uint64_t) v99 * (uint64_t) v20);
      // pto: %0
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %0
      ;
      uint64_t v102 = (uint64_t) v14;
      TASSIGN(v101, v102);
      // pto: %62
      ;
      int64_t v103 = v100 < v27 ? v27 : v100;
      // pto: %63
      ;
      __gm__ bfloat16_t* v104 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %63
      ;
      const int64_t v105 = 0;
      // pto: %63
      ;
      const int64_t v106 = 4096;
      // pto: %63
      ;
      pto::Shape<1, 1, 1, 64, 256> v107 = pto::Shape<1, 1, 1, 64, 256>();
      // pto: %63
      ;
      pto::Stride<262144, 262144, 262144, 4096, 1> v108 = pto::Stride<262144, 262144, 262144, 4096, 1>();
      // pto: %63
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND> v109 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<262144, 262144, 262144, 4096, 1>, pto::Layout::ND>(v104 + (v105 + v74 * v106 + v103), v107, v108);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v101, v109);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %1
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %1
      ;
      uint64_t v111 = (uint64_t) v15;
      TASSIGN(v110, v111);
      // pto: %64
      ;
      int64_t v112 = v100 / v22;
      // pto: %65
      ;
      int64_t v113 = v112 < v27 ? v27 : v112;
      // pto: %68
      ;
      __gm__ bfloat16_t* v114 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %68
      ;
      const int64_t v115 = 0;
      // pto: %68
      ;
      const int64_t v116 = 16384;
      // pto: %68
      ;
      const int64_t v117 = 256;
      // pto: %68
      ;
      pto::Shape<1, 16, 2, 16, 16> v118 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %68
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v119 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %68
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v120 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v114 + (v115 + v113 * v116 + v87 * v117), v118, v119);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v110, v120);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %dense_w_inline8332__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %dense_w_inline8332__tile_t
      ;
      uint64_t v122 = (uint64_t) v13;
      TASSIGN(v121, v122);
      // pto: %dense_x_inline8342__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v123 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %dense_x_inline8342__tile_Left
      ;
      uint64_t v124 = (uint64_t) v13;
      TASSIGN(v123, v124);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v123, v72);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %dense_w_inline8332__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %dense_w_inline8332__tile_t_Right
      ;
      uint64_t v126 = (uint64_t) v16;
      TASSIGN(v125, v126);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      TMOV(v125, v121);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %69
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (v63 == v27) {
        pipe_barrier(PIPE_M);
        TMATMUL(v61, v123, v125);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v61, v61, v123, v125);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      // pto: %3
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %3
      ;
      uint64_t v128 = (uint64_t) v15;
      TASSIGN(v127, v128);
      // pto: %4
      ;
      Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v21, v20);
      // pto: %4
      ;
      uint64_t v130 = (uint64_t) v12;
      TASSIGN(v129, v130);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TMOV(v129, v101);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      // pto: %5
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %5
      ;
      uint64_t v132 = (uint64_t) v12;
      TASSIGN(v131, v132);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      TMOV(v131, v127);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      // pto: %70
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      if (v63 == v35) {
        pipe_barrier(PIPE_M);
        TMATMUL(v61, v129, v131);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v61, v61, v129, v131);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %71
    ;
    int64_t v133 = v59 < v27 ? v27 : v59;
    // pto: %72
    ;
    int64_t v134 = v57 < v27 ? v27 : v57;
    // pto: %qr_fp32_inline174_inline5151__iter_v6_pview
    ;
    __gm__ float* v135 = PTOAS__GLOBAL_TENSOR_DATA(v44);
    // pto: %qr_fp32_inline174_inline5151__iter_v6_pview
    ;
    const int64_t v136 = 0;
    // pto: %qr_fp32_inline174_inline5151__iter_v6_pview
    ;
    const int64_t v137 = 1024;
    // pto: %qr_fp32_inline174_inline5151__iter_v6_pview
    ;
    pto::Shape<1, 1, 1, 64, 32> v138 = pto::Shape<1, 1, 1, 64, 32>();
    // pto: %qr_fp32_inline174_inline5151__iter_v6_pview
    ;
    pto::Stride<65536, 65536, 65536, 1024, 1> v139 = pto::Stride<65536, 65536, 65536, 1024, 1>();
    // pto: %qr_fp32_inline174_inline5151__iter_v6_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 32>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND> v140 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 32>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND>(v135 + (v136 + v133 * v137 + v134), v138, v139);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    pipe_barrier(PIPE_FIX);
    TSTORE(v140, v61);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  for (int64_t v141 = v4; v141 < v7; v141 += v22) {
    // pto: %q_acc_inline8328__tile
    ;
    Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v142 = Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v22, v25);
    // pto: %q_acc_inline8328__tile
    ;
    uint64_t v143 = (uint64_t) v12;
    TASSIGN(v142, v143);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    for (int64_t v144 = v27; v144 < v22; v144 += v28) {
      // pto: %73
      ;
      int64_t v145 = (int64_t) ((uint64_t) v6 - (uint64_t) v141);
      // pto: %74
      ;
      int64_t v146 = v145 < v22 ? v145 : v22;
      // pto: %75
      ;
      int64_t v147 = (int64_t) ((uint64_t) v5 + (uint64_t) v141);
      // pto: %76
      ;
      int64_t v148 = (int64_t) ((uint64_t) v144 + (uint64_t) v18);
      // pto: %80, %81, %82, %83, %84, %85, %86, %87
      ;
      bool v149 = (v6 >= v26 & v6 <= v29 & v6 % v30 == v27) & v58 < v31;
      // pto: %qr_k_order_inline8344__phi_v2
      ;
      int64_t v150;
      if (v149) {
        // pto: %88, %89
        ;
        // pto: %qr_k_direction_inline8335__phi_v2
        ;
        int64_t v151;
        if (v58 % v28 == v18) {
          // pto: %90
          ;
          v151 = (int64_t) ((uint64_t) v32 - (uint64_t) v144);
        } else {
          v151 = v144;
        };
        // pto: %93
        ;
        uint64_t v152 = (uint64_t) v151;
        // pto: %91, %92, %93, %94
        ;
        v150 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v58 / v28) * (uint64_t) v33) + v152) % v22;
      } else {
        v150 = v144;
      };
      // pto: %95
      ;
      bool v153 = v150 < v27;
      // pto: %95
      ;
      int64_t v154 = v153 ? v27 : v150;
      // pto: %96
      ;
      int64_t v155 = (int64_t) ((uint64_t) v154 * (uint64_t) v20);
      // pto: %q_x_chunk_bf16_inline8320__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v156 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v146, v20);
      // pto: %q_x_chunk_bf16_inline8320__tile
      ;
      uint64_t v157 = (uint64_t) v13;
      TASSIGN(v156, v157);
      // pto: %97
      ;
      int64_t v158 = v147 < v27 ? v27 : v147;
      // pto: %98
      ;
      int64_t v159 = v155 < v27 ? v27 : v155;
      // pto: %99
      ;
      const int64_t v160 = 0;
      // pto: %99
      ;
      __gm__ bfloat16_t* v161 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %99
      ;
      const int64_t v162 = 1;
      // pto: %99
      ;
      const int64_t v163 = 1;
      // pto: %99
      ;
      const int64_t v164 = 1;
      // pto: %99
      ;
      int64_t v165 = v146 * v19;
      // pto: %99
      ;
      int64_t v166 = v164 * v165;
      // pto: %99
      ;
      pto::Shape<1, 1, 1, -1, 256> v167 = pto::Shape<1, 1, 1, -1, 256>(v162, v163, v164, v146, v20);
      // pto: %99
      ;
      pto::Stride<-1, -1, -1, -1, -1> v168 = pto::Stride<-1, -1, -1, -1, -1>(v163 * v166, v166, v165, v19, v18);
      // pto: %99
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v169 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v161 + (v160 + v158 * v19 + v159 * v18), v167, v168);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      TLOAD(v156, v169);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      // pto: %w_chunk_inline8319__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v170 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %w_chunk_inline8319__tile
      ;
      uint64_t v171 = (uint64_t) v12;
      TASSIGN(v170, v171);
      // pto: %100
      ;
      int64_t v172 = v155 / v22;
      // pto: %101
      ;
      int64_t v173 = v172 < v27 ? v27 : v172;
      // pto: %102
      ;
      int64_t v174 = v57 / v22;
      // pto: %103
      ;
      int64_t v175 = v174 < v27 ? v27 : v174;
      // pto: %104
      ;
      __gm__ bfloat16_t* v176 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %104
      ;
      const int64_t v177 = 0;
      // pto: %104
      ;
      const int64_t v178 = 16384;
      // pto: %104
      ;
      const int64_t v179 = 256;
      // pto: %104
      ;
      pto::Shape<1, 16, 2, 16, 16> v180 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %104
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v181 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %104
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v182 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v176 + (v177 + v173 * v178 + v175 * v179), v180, v181);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      TLOAD(v170, v182);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      // pto: %113
      ;
      int64_t v183;
      if (v149) {
        // pto: %115, %116
        ;
        // pto: %117
        ;
        int64_t v184;
        if (v58 % v28 == v18) {
          // pto: %118
          ;
          v184 = (int64_t) ((uint64_t) v34 - (uint64_t) v144);
        } else {
          v184 = v148;
        };
        // pto: %121
        ;
        uint64_t v185 = (uint64_t) v184;
        // pto: %119, %120, %121, %122
        ;
        v183 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v58 / v28) * (uint64_t) v33) + v185) % v22;
      } else {
        v183 = v148;
      };
      // pto: %123
      ;
      bool v186 = v183 < v27;
      // pto: %123
      ;
      int64_t v187 = v186 ? v27 : v183;
      // pto: %124
      ;
      int64_t v188 = (int64_t) ((uint64_t) v187 * (uint64_t) v20);
      // pto: %7
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v189 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v146, v20);
      // pto: %7
      ;
      uint64_t v190 = (uint64_t) v15;
      TASSIGN(v189, v190);
      // pto: %126
      ;
      int64_t v191 = v188 < v27 ? v27 : v188;
      // pto: %127
      ;
      const int64_t v192 = 0;
      // pto: %127
      ;
      __gm__ bfloat16_t* v193 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %127
      ;
      const int64_t v194 = 1;
      // pto: %127
      ;
      const int64_t v195 = 1;
      // pto: %127
      ;
      const int64_t v196 = 1;
      // pto: %127
      ;
      int64_t v197 = v146 * v19;
      // pto: %127
      ;
      int64_t v198 = v196 * v197;
      // pto: %127
      ;
      pto::Shape<1, 1, 1, -1, 256> v199 = pto::Shape<1, 1, 1, -1, 256>(v194, v195, v196, v146, v20);
      // pto: %127
      ;
      pto::Stride<-1, -1, -1, -1, -1> v200 = pto::Stride<-1, -1, -1, -1, -1>(v195 * v198, v198, v197, v19, v18);
      // pto: %127
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v201 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v193 + (v192 + v158 * v19 + v191 * v18), v199, v200);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      TLOAD(v189, v201);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      // pto: %8
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v202 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v25, v20);
      // pto: %8
      ;
      uint64_t v203 = (uint64_t) v14;
      TASSIGN(v202, v203);
      // pto: %128
      ;
      int64_t v204 = v188 / v22;
      // pto: %129
      ;
      int64_t v205 = v204 < v27 ? v27 : v204;
      // pto: %132
      ;
      __gm__ bfloat16_t* v206 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %132
      ;
      const int64_t v207 = 0;
      // pto: %132
      ;
      const int64_t v208 = 16384;
      // pto: %132
      ;
      const int64_t v209 = 256;
      // pto: %132
      ;
      pto::Shape<1, 16, 2, 16, 16> v210 = pto::Shape<1, 16, 2, 16, 16>();
      // pto: %132
      ;
      pto::Stride<4194304, 16384, 256, 16, 1> v211 = pto::Stride<4194304, 16384, 256, 16, 1>();
      // pto: %132
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ> v212 = GlobalTensor<bfloat16_t, pto::Shape<1, 16, 2, 16, 16>, pto::Stride<4194304, 16384, 256, 16, 1>, pto::Layout::NZ>(v206 + (v207 + v205 * v208 + v175 * v209), v210, v211);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v202, v212);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
      // pto: %w_chunk_inline8319__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %w_chunk_inline8319__tile_t
      ;
      uint64_t v214 = (uint64_t) v12;
      TASSIGN(v213, v214);
      // pto: %q_x_chunk_bf16_inline8320__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v146, v20);
      // pto: %q_x_chunk_bf16_inline8320__tile_Left
      ;
      uint64_t v216 = (uint64_t) v13;
      TASSIGN(v215, v216);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      TMOV(v215, v156);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      // pto: %w_chunk_inline8319__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %w_chunk_inline8319__tile_t_Right
      ;
      uint64_t v218 = (uint64_t) v16;
      TASSIGN(v217, v218);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      TMOV(v217, v213);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      // pto: %133
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      if (v144 == v27) {
        pipe_barrier(PIPE_M);
        TMATMUL(v142, v215, v217);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v142, v142, v215, v217);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      // pto: %10
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v219 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %10
      ;
      uint64_t v220 = (uint64_t) v14;
      TASSIGN(v219, v220);
      // pto: %11
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v221 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v146, v20);
      // pto: %11
      ;
      uint64_t v222 = (uint64_t) v12;
      TASSIGN(v221, v222);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      TMOV(v221, v189);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      // pto: %12
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v223 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v25);
      // pto: %12
      ;
      uint64_t v224 = (uint64_t) v12;
      TASSIGN(v223, v224);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
      TMOV(v223, v219);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %134
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      if (v144 == v35) {
        pipe_barrier(PIPE_M);
        TMATMUL(v142, v221, v223);
      } else {
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v142, v142, v221, v223);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    // pto: %136
    ;
    int64_t v225 = v141 < v27 ? v27 : v141;
    // pto: %137
    ;
    int64_t v226 = v57 < v27 ? v27 : v57;
    // pto: %qr_fp32_inline174_inline5151__iter_v9_pview
    ;
    __gm__ float* v227 = PTOAS__GLOBAL_TENSOR_DATA(v44);
    // pto: %qr_fp32_inline174_inline5151__iter_v9_pview
    ;
    const int64_t v228 = 0;
    // pto: %qr_fp32_inline174_inline5151__iter_v9_pview
    ;
    const int64_t v229 = 1024;
    // pto: %qr_fp32_inline174_inline5151__iter_v9_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v230 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %qr_fp32_inline174_inline5151__iter_v9_pview
    ;
    pto::Stride<16384, 16384, 16384, 1024, 1> v231 = pto::Stride<16384, 16384, 16384, 1024, 1>();
    // pto: %qr_fp32_inline174_inline5151__iter_v9_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND> v232 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<16384, 16384, 16384, 1024, 1>, pto::Layout::ND>(v227 + (v228 + v225 * v229 + v226), v230, v231);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
    pipe_barrier(PIPE_FIX);
    TSTORE(v232, v142);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}