#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qproj_dequant_rms_nope_rope(__gm__ bfloat16_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ float* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ float* v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int64_t v12, int64_t v13, int32_t v14, int32_t v15) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v16 = 256;
  // pto: %c79872_i64
  const int64_t v17 = 79872;
  // pto: %c79904_i64
  const int64_t v18 = 79904;
  // pto: %c81952_i64
  const int64_t v19 = 81952;
  // pto: %c0_i64
  const int64_t v20 = 0;
  // pto: %c2048_i64
  const int64_t v21 = 2048;
  // pto: %c18432_i64
  const int64_t v22 = 18432;
  // pto: %c20480_i64
  const int64_t v23 = 20480;
  // pto: %c36864_i64
  const int64_t v24 = 36864;
  // pto: %c38912_i64
  const int64_t v25 = 38912;
  const int64_t v26 = 39936;
  const int64_t v27 = 39168;
  const int64_t v28 = 40192;
  // pto: %c55296_i64
  const int64_t v29 = 55296;
  const int64_t v30 = 39424;
  const int64_t v31 = 40448;
  // pto: %c57344_i64
  const int64_t v32 = 57344;
  const int64_t v33 = 39680;
  const int64_t v34 = 40704;
  const int64_t v35 = 3840;
  // pto: %c59392_i64
  const int64_t v36 = 59392;
  const int64_t v37 = 60416;
  const int64_t v38 = 59648;
  const int64_t v39 = 60672;
  // pto: %c75776_i64
  const int64_t v40 = 75776;
  const int64_t v41 = 59904;
  const int64_t v42 = 60928;
  // pto: %c77824_i64
  const int64_t v43 = 77824;
  const int64_t v44 = 60160;
  const int64_t v45 = 61184;
  const int64_t v46 = 22272;
  const int64_t v47 = 21504;
  const int64_t v48 = 20736;
  const int64_t v49 = 21760;
  const int64_t v50 = 20992;
  const int64_t v51 = 22016;
  const int64_t v52 = 21248;
  // pto: %c32768_index
  const int64_t v53 = 32768;
  // pto: %c1_index
  const int64_t v54 = 1;
  // pto: %c512_index
  const int64_t v55 = 512;
  // pto: %c64_index
  const int64_t v56 = 64;
  // pto: %c384_index
  const int64_t v57 = 384;
  // pto: %c0_index
  const int64_t v58 = 0;
  // pto: %c96_index
  const int64_t v59 = 96;
  // pto: %c16_index
  const int64_t v60 = 16;
  // pto: %c4_index
  const int64_t v61 = 4;
  // pto: %c7_index
  const int64_t v62 = 7;
  // pto: %c8_index
  const int64_t v63 = 8;
  // pto: %c48_index
  const int64_t v64 = 48;
  // pto: %c2_index
  const int64_t v65 = 2;
  // pto: %cst_49
  const float v66 = 1.0f;
  // pto: %c128_index
  const int64_t v67 = 128;
  // pto: %c192_index
  const int64_t v68 = 192;
  // pto: %c448_index
  const int64_t v69 = 448;
  // pto: %cst_55
  const float v70 = 0.001953125f;
  // pto: %cst_56
  const float v71 = 9.99999997E-7f;
  // pto: %c0_i32
  const int32_t v72 = 0;
  // pto: %cst_58
  const float v73 = 0.5f;
  // pto: %cst_59
  const float v74 = 2.0f;
  // pto: %cst_60
  const float v75 = 64.0f;
  // pto: %q_flat_inline8482__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %q_flat_inline8482__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %q_flat_inline8482__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %q_flat_inline8482__ssa_v0_view
  int64_t v79 = (int64_t) v10;
  // pto: %q_flat_inline8482__ssa_v0_view
  int64_t v80 = v79 * v53;
  // pto: %q_flat_inline8482__ssa_v0_view
  int64_t v81 = v78 * v80;
  // pto: %q_flat_inline8482__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v82 = pto::Shape<1, 1, 1, -1, -1>(v76, v77, v78, v79, v53);
  // pto: %q_flat_inline8482__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v83 = pto::Stride<-1, -1, -1, -1, -1>(v77 * v81, v81, v80, v53, v54);
  // pto: %q_flat_inline8482__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v84 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v82, v83);
  // pto: %qr_scale_pad_store_inline5159__rv_v2_view
  const int64_t v85 = 1;
  // pto: %qr_scale_pad_store_inline5159__rv_v2_view
  const int64_t v86 = 1;
  // pto: %qr_scale_pad_store_inline5159__rv_v2_view
  const int64_t v87 = 1;
  // pto: %qr_scale_pad_store_inline5159__rv_v2_view
  int64_t v88 = v55 * v54;
  // pto: %qr_scale_pad_store_inline5159__rv_v2_view
  int64_t v89 = v87 * v88;
  // pto: %qr_scale_pad_store_inline5159__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v90 = pto::Shape<1, 1, 1, -1, -1>(v85, v86, v87, v55, v54);
  // pto: %qr_scale_pad_store_inline5159__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v91 = pto::Stride<-1, -1, -1, -1, -1>(v86 * v89, v89, v88, v54, v55);
  // pto: %qr_scale_pad_store_inline5159__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v92 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v2, v90, v91);
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v93 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v96 = (int64_t) v11;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v97 = v96 * v56;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v98 = v95 * v97;
  // pto: %freqs_cos__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v99 = pto::Shape<1, 1, 1, -1, -1>(v93, v94, v95, v96, v56);
  // pto: %freqs_cos__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v100 = pto::Stride<-1, -1, -1, -1, -1>(v94 * v98, v98, v97, v56, v54);
  // pto: %freqs_cos__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v101 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v99, v100);
  // pto: %q_rope_sin_signed_inline1339__ssa_v0_view
  const int64_t v102 = 1;
  // pto: %q_rope_sin_signed_inline1339__ssa_v0_view
  const int64_t v103 = 1;
  // pto: %q_rope_sin_signed_inline1339__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %q_rope_sin_signed_inline1339__ssa_v0_view
  int64_t v105 = (int64_t) v12;
  // pto: %q_rope_sin_signed_inline1339__ssa_v0_view
  int64_t v106 = v105 * v56;
  // pto: %q_rope_sin_signed_inline1339__ssa_v0_view
  int64_t v107 = v104 * v106;
  // pto: %q_rope_sin_signed_inline1339__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v108 = pto::Shape<1, 1, 1, -1, -1>(v102, v103, v104, v105, v56);
  // pto: %q_rope_sin_signed_inline1339__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v109 = pto::Stride<-1, -1, -1, -1, -1>(v103 * v107, v107, v106, v56, v54);
  // pto: %q_rope_sin_signed_inline1339__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v110 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v108, v109);
  // pto: %q_rope_swap_idx_inline1338__ssa_v0_view
  const int64_t v111 = 1;
  // pto: %q_rope_swap_idx_inline1338__ssa_v0_view
  const int64_t v112 = 1;
  // pto: %q_rope_swap_idx_inline1338__ssa_v0_view
  const int64_t v113 = 1;
  // pto: %q_rope_swap_idx_inline1338__ssa_v0_view
  int64_t v114 = (int64_t) v12;
  // pto: %q_rope_swap_idx_inline1338__ssa_v0_view
  int64_t v115 = v114 * v56;
  // pto: %q_rope_swap_idx_inline1338__ssa_v0_view
  int64_t v116 = v113 * v115;
  // pto: %q_rope_swap_idx_inline1338__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v117 = pto::Shape<1, 1, 1, -1, -1>(v111, v112, v113, v114, v56);
  // pto: %q_rope_swap_idx_inline1338__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v118 = pto::Stride<-1, -1, -1, -1, -1>(v112 * v116, v116, v115, v56, v54);
  // pto: %q_rope_swap_idx_inline1338__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v119 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v117, v118);
  // pto: %q_proj_i32_inline180_inline5157__ssa_v9_view
  const int64_t v120 = 1;
  // pto: %q_proj_i32_inline180_inline5157__ssa_v9_view
  const int64_t v121 = 1;
  // pto: %q_proj_i32_inline180_inline5157__ssa_v9_view
  const int64_t v122 = 1;
  // pto: %q_proj_i32_inline180_inline5157__ssa_v9_view
  int64_t v123 = (int64_t) v13;
  // pto: %q_proj_i32_inline180_inline5157__ssa_v9_view
  int64_t v124 = v123 * v53;
  // pto: %q_proj_i32_inline180_inline5157__ssa_v9_view
  int64_t v125 = v122 * v124;
  // pto: %q_proj_i32_inline180_inline5157__ssa_v9_view
  pto::Shape<1, 1, 1, -1, -1> v126 = pto::Shape<1, 1, 1, -1, -1>(v120, v121, v122, v123, v53);
  // pto: %q_proj_i32_inline180_inline5157__ssa_v9_view
  pto::Stride<-1, -1, -1, -1, -1> v127 = pto::Stride<-1, -1, -1, -1, -1>(v121 * v125, v125, v124, v53, v54);
  // pto: %q_proj_i32_inline180_inline5157__ssa_v9_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v128 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v126, v127);
  // pto: %wq_b_scale__ssa_v0_view
  const int64_t v129 = 1;
  // pto: %wq_b_scale__ssa_v0_view
  const int64_t v130 = 1;
  // pto: %wq_b_scale__ssa_v0_view
  const int64_t v131 = 1;
  // pto: %wq_b_scale__ssa_v0_view
  const int64_t v132 = 1;
  // pto: %wq_b_scale__ssa_v0_view
  int64_t v133 = v53 * v54;
  // pto: %wq_b_scale__ssa_v0_view
  int64_t v134 = v132 * v133;
  // pto: %wq_b_scale__ssa_v0_view
  int64_t v135 = v131 * v134;
  // pto: %wq_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v136 = pto::Shape<1, 1, 1, 1, -1>(v129, v130, v131, v132, v53);
  // pto: %wq_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v137 = pto::Stride<-1, -1, -1, -1, -1>(v130 * v135, v135, v134, v133, v54);
  // pto: %wq_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v138 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v136, v137);
  // pto: %dq_worker_inline8518__ssa_v0
  // pto: %117, %118, %119, %120
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  // pto: %dq_head_tile_inline8470__phi_v4
  int64_t v139;
  if (v8 >= v57 & v8 % v57 == v58) {
    v139 = v56;
  } else {
    // pto: %121, %122, %123, %124, %dq_head_tile_inline8470__phi_v3
    ;
    v139 = v8 >= v59 & v8 % v59 == v58 ? v60 : v61;
  }
  // pto: %127
  int64_t v140 = v56 / v139;
  // pto: %125, %126, %128
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v141 = (int64_t) v14; v141 < ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v8 + (uint64_t) v62) / v63) * (uint64_t) v140)); v141 += v64) {
    // pto: %131
    ;
    uint64_t v142 = (uint64_t) v139;
    // pto: %130, %131
    ;
    int64_t v143 = (int64_t) ((uint64_t) (v141 % v140) * v142);
    // pto: %133, %134
    ;
    int64_t v144 = (int64_t) ((uint64_t) (v141 / v140) * (uint64_t) v63);
    // pto: %135
    ;
    int64_t v145 = (int64_t) ((uint64_t) v9 + (uint64_t) v144);
    // pto: %136, %137
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    if ((int64_t) ((uint64_t) v144 + (uint64_t) v63) <= v8) {
      // pto: %qr_scale_dq_t_inline8472__tile
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v146 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
      // pto: %qr_scale_dq_t_inline8472__tile
      ;
      uint64_t v147 = (uint64_t) v17;
      TASSIGN(v146, v147);
      // pto: %138
      ;
      int64_t v148 = v144 < v58 ? v58 : v144;
      // pto: %qr_scale_pad_store_inline5159__rv_v2_pview
      ;
      __gm__ float* v149 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %qr_scale_pad_store_inline5159__rv_v2_pview
      ;
      const int64_t v150 = 0;
      // pto: %qr_scale_pad_store_inline5159__rv_v2_pview
      ;
      pto::Shape<1, 1, 1, 8, 1> v151 = pto::Shape<1, 1, 1, 8, 1>();
      // pto: %qr_scale_pad_store_inline5159__rv_v2_pview
      ;
      pto::Stride<8, 8, 8, 1, 512> v152 = pto::Stride<8, 8, 8, 1, 512>();
      // pto: %qr_scale_pad_store_inline5159__rv_v2_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN> v153 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN>(v149 + (v150 + v148), v151, v152);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      pipe_barrier(PIPE_ALL);
      TLOAD(v146, v153);
      // pto: %q_cos_il_inline8506__tile
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v154 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_cos_il_inline8506__tile
      ;
      uint64_t v155 = (uint64_t) v18;
      TASSIGN(v154, v155);
      // pto: %139
      ;
      int64_t v156 = v145 < v58 ? v58 : v145;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      __gm__ float* v157 = PTOAS__GLOBAL_TENSOR_DATA(v101);
      // pto: %freqs_cos__ssa_v0_pview
      ;
      const int64_t v158 = 0;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      const int64_t v159 = 64;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v160 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %freqs_cos__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v161 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %freqs_cos__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v162 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v157 + (v158 + v156 * v159), v160, v161);
      pipe_barrier(PIPE_ALL);
      TLOAD(v154, v162);
      // pto: %q_sin_signed_inline8484__tile
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v163 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_sin_signed_inline8484__tile
      ;
      uint64_t v164 = (uint64_t) v19;
      TASSIGN(v163, v164);
      // pto: %q_rope_sin_signed_inline1339__ssa_v0_pview
      ;
      __gm__ float* v165 = PTOAS__GLOBAL_TENSOR_DATA(v110);
      // pto: %q_rope_sin_signed_inline1339__ssa_v0_pview
      ;
      const int64_t v166 = 0;
      // pto: %q_rope_sin_signed_inline1339__ssa_v0_pview
      ;
      const int64_t v167 = 64;
      // pto: %q_rope_sin_signed_inline1339__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v168 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %q_rope_sin_signed_inline1339__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v169 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %q_rope_sin_signed_inline1339__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v170 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v165 + (v166 + v156 * v167), v168, v169);
      pipe_barrier(PIPE_ALL);
      TLOAD(v163, v170);
      // pto: %q_swap_idx_inline8499__tile
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v171 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_swap_idx_inline8499__tile
      ;
      uint64_t v172 = (uint64_t) v20;
      TASSIGN(v171, v172);
      // pto: %q_rope_swap_idx_inline1338__ssa_v0_pview
      ;
      __gm__ int32_t* v173 = PTOAS__GLOBAL_TENSOR_DATA(v119);
      // pto: %q_rope_swap_idx_inline1338__ssa_v0_pview
      ;
      const int64_t v174 = 0;
      // pto: %q_rope_swap_idx_inline1338__ssa_v0_pview
      ;
      const int64_t v175 = 64;
      // pto: %q_rope_swap_idx_inline1338__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v176 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %q_rope_swap_idx_inline1338__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v177 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %q_rope_swap_idx_inline1338__ssa_v0_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v178 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v173 + (v174 + v156 * v175), v176, v177);
      TLOAD(v171, v178);
      // pto: %142
      ;
      int64_t v179 = v139 / v65;
      // pto: %143
      ;
      int64_t v180 = (int64_t) ((uint64_t) v179 * (uint64_t) v65);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      for (int64_t v181 = v58; v181 < v180; v181 += v65) {
        // pto: %144, %145
        ;
        int64_t v182 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v143 + (uint64_t) v181) * (uint64_t) v55);
        // pto: %147, %146, %148
        ;
        int64_t v183 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v143 + (uint64_t) ((int64_t) (uint64_t) v181 + (uint64_t) v54)) * (uint64_t) v55);
        // pto: %q_head_acc_inline8495__tile
        ;
        Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_acc_inline8495__tile
        ;
        uint64_t v185 = (uint64_t) v21;
        TASSIGN(v184, v185);
        // pto: %150
        ;
        int64_t v186 = v182 < v58 ? v58 : v182;
        // pto: %q_proj_i32_inline180_inline5157__ssa_v9_pview
        ;
        __gm__ int32_t* v187 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %q_proj_i32_inline180_inline5157__ssa_v9_pview
        ;
        const int64_t v188 = 0;
        // pto: %q_proj_i32_inline180_inline5157__ssa_v9_pview
        ;
        const int64_t v189 = 32768;
        // pto: %q_proj_i32_inline180_inline5157__ssa_v9_pview
        ;
        pto::Shape<1, 1, 1, 8, 512> v190 = pto::Shape<1, 1, 1, 8, 512>();
        // pto: %q_proj_i32_inline180_inline5157__ssa_v9_pview
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v191 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %q_proj_i32_inline180_inline5157__ssa_v9_pview
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v192 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v187 + (v188 + v148 * v189 + v186), v190, v191);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        TLOAD(v184, v192);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %t__tile
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v193 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %t__tile
        ;
        uint64_t v194 = (uint64_t) v22;
        TASSIGN(v193, v194);
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        __gm__ float* v195 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        const int64_t v196 = 0;
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 512> v197 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        pto::Stride<512, 512, 512, 512, 1> v198 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v199 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v195 + (v196 + v186), v197, v198);
        TLOAD(v193, v199);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %0
        ;
        Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v200 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %0
        ;
        uint64_t v201 = (uint64_t) v23;
        TASSIGN(v200, v201);
        // pto: %153
        ;
        int64_t v202 = v183 < v58 ? v58 : v183;
        // pto: %154
        ;
        __gm__ int32_t* v203 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %154
        ;
        const int64_t v204 = 0;
        // pto: %154
        ;
        const int64_t v205 = 32768;
        // pto: %154
        ;
        pto::Shape<1, 1, 1, 8, 512> v206 = pto::Shape<1, 1, 1, 8, 512>();
        // pto: %154
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v207 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %154
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v208 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v203 + (v204 + v148 * v205 + v202), v206, v207);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
        TLOAD(v200, v208);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        // pto: %1
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %1
        ;
        uint64_t v210 = (uint64_t) v24;
        TASSIGN(v209, v210);
        // pto: %156
        ;
        __gm__ float* v211 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %156
        ;
        const int64_t v212 = 0;
        // pto: %156
        ;
        pto::Shape<1, 1, 1, 1, 512> v213 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %156
        ;
        pto::Stride<512, 512, 512, 512, 1> v214 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %156
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v215 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v211 + (v212 + v202), v213, v214);
        TLOAD(v209, v215);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
        // pto: %q_head_scale_inline8465__tile
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %q_head_scale_inline8465__tile
        ;
        uint64_t v217 = (uint64_t) v22;
        TASSIGN(v216, v217);
        // pto: %q_head_acc_fp32_inline8476__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_acc_fp32_inline8476__tile
        ;
        uint64_t v219 = (uint64_t) v21;
        TASSIGN(v218, v219);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v220 = RoundMode::CAST_NONE;
        SaturationMode v221 = SaturationMode::ON;
        TCVT(v218, v184, v220, v221);
        // pto: %2
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %2
        ;
        uint64_t v223 = (uint64_t) v25;
        TASSIGN(v222, v223);
        TEXPANDS(v222, v66);
        // pto: %3
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %3
        ;
        uint64_t v225 = (uint64_t) v25;
        TASSIGN(v224, v225);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v224, v222, v146);
        // pto: %q_head_scale_combined_inline8522__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v226 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_scale_combined_inline8522__tile
        ;
        uint64_t v227 = (uint64_t) v25;
        TASSIGN(v226, v227);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        TCOLEXPANDMUL(v226, v224, v216);
        // pto: %q_head_dq_inline8462__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v228 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_dq_inline8462__tile
        ;
        uint64_t v229 = (uint64_t) v21;
        TASSIGN(v228, v229);
        pipe_barrier(PIPE_V);
        TMUL(v228, v218, v226);
        // pto: %4
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v230 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %4
        ;
        uint64_t v231 = (uint64_t) v25;
        TASSIGN(v230, v231);
        pipe_barrier(PIPE_V);
        RoundMode v232 = RoundMode::CAST_RINT;
        SaturationMode v233 = SaturationMode::ON;
        TCVT(v230, v228, v232, v233);
        // pto: %q_head_dq_v1_inline8493__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_dq_v1_inline8493__tile
        ;
        uint64_t v235 = (uint64_t) v21;
        TASSIGN(v234, v235);
        pipe_barrier(PIPE_V);
        RoundMode v236 = RoundMode::CAST_ROUND;
        SaturationMode v237 = SaturationMode::ON;
        TCVT(v234, v230, v236, v237);
        // pto: %q_head_sq_inline8461__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_sq_inline8461__tile
        ;
        uint64_t v239 = (uint64_t) v25;
        TASSIGN(v238, v239);
        pipe_barrier(PIPE_V);
        TMUL(v238, v234, v234);
        // pto: %5
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %5
        ;
        uint64_t v241 = (uint64_t) v25;
        TASSIGN(v240, v241);
        // pto: %slice_view
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v242;
        // pto: %slice_view
        ;
        uint64_t v243 = (uint64_t) v25;
        TASSIGN(v242, v243);
        // pto: %6
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %6
        ;
        uint64_t v245 = (uint64_t) v26;
        TASSIGN(v244, v245);
        // pto: %157
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246;
        // pto: %157
        ;
        uint64_t v247 = (uint64_t) v26;
        TASSIGN(v246, v247);
        // pto: %q_sq_04_inline8480__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v248 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_04_inline8480__tile
        ;
        uint64_t v249 = (uint64_t) v22;
        TASSIGN(v248, v249);
        pipe_barrier(PIPE_V);
        TADD(v248, v242, v246);
        // pto: %7
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v250 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %7
        ;
        uint64_t v251 = (uint64_t) v27;
        TASSIGN(v250, v251);
        // pto: %158
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v252;
        // pto: %158
        ;
        uint64_t v253 = (uint64_t) v27;
        TASSIGN(v252, v253);
        // pto: %8
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v254 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %8
        ;
        uint64_t v255 = (uint64_t) v28;
        TASSIGN(v254, v255);
        // pto: %159
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v256;
        // pto: %159
        ;
        uint64_t v257 = (uint64_t) v28;
        TASSIGN(v256, v257);
        // pto: %q_sq_15_inline8500__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v258 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_15_inline8500__tile
        ;
        uint64_t v259 = (uint64_t) v29;
        TASSIGN(v258, v259);
        TADD(v258, v252, v256);
        // pto: %9
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v260 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %9
        ;
        uint64_t v261 = (uint64_t) v30;
        TASSIGN(v260, v261);
        // pto: %160
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v262;
        // pto: %160
        ;
        uint64_t v263 = (uint64_t) v30;
        TASSIGN(v262, v263);
        // pto: %10
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v264 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %10
        ;
        uint64_t v265 = (uint64_t) v31;
        TASSIGN(v264, v265);
        // pto: %161
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v266;
        // pto: %161
        ;
        uint64_t v267 = (uint64_t) v31;
        TASSIGN(v266, v267);
        // pto: %q_sq_26_inline8516__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v268 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_26_inline8516__tile
        ;
        uint64_t v269 = (uint64_t) v32;
        TASSIGN(v268, v269);
        TADD(v268, v262, v266);
        // pto: %11
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %11
        ;
        uint64_t v271 = (uint64_t) v33;
        TASSIGN(v270, v271);
        // pto: %162
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v272;
        // pto: %162
        ;
        uint64_t v273 = (uint64_t) v33;
        TASSIGN(v272, v273);
        // pto: %12
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v274 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %12
        ;
        uint64_t v275 = (uint64_t) v34;
        TASSIGN(v274, v275);
        // pto: %163
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v276;
        // pto: %163
        ;
        uint64_t v277 = (uint64_t) v34;
        TASSIGN(v276, v277);
        // pto: %q_sq_37_inline8469__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v278 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_37_inline8469__tile
        ;
        uint64_t v279 = (uint64_t) v25;
        TASSIGN(v278, v279);
        pipe_barrier(PIPE_V);
        TADD(v278, v272, v276);
        // pto: %q_sq_0246_inline8460__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v280 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_0246_inline8460__tile
        ;
        uint64_t v281 = (uint64_t) v22;
        TASSIGN(v280, v281);
        TADD(v280, v248, v268);
        // pto: %q_sq_1357_inline8459__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v282 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_1357_inline8459__tile
        ;
        uint64_t v283 = (uint64_t) v25;
        TASSIGN(v282, v283);
        pipe_barrier(PIPE_V);
        TADD(v282, v258, v278);
        // pto: %q_sq_64_inline8458__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v284 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_64_inline8458__tile
        ;
        uint64_t v285 = (uint64_t) v22;
        TASSIGN(v284, v285);
        pipe_barrier(PIPE_V);
        TADD(v284, v280, v282);
        // pto: %tmp_tile
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v67);
        // pto: %tmp_tile
        ;
        uint64_t v287 = (uint64_t) v25;
        TASSIGN(v286, v287);
        // pto: %q_head_sq_row_inline8492__tile
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v288 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %q_head_sq_row_inline8492__tile
        ;
        uint64_t v289 = (uint64_t) v29;
        TASSIGN(v288, v289);
        pipe_barrier(PIPE_V);
        TROWSUM(v288, v284, v286);
        // pto: %q_head_sq_sum_inline8503__tile
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_sq_sum_inline8503__tile
        ;
        uint64_t v291 = (uint64_t) v29;
        TASSIGN(v290, v291);
        // pto: %q_head_sq_mean_inline8497__tile
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v292 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_sq_mean_inline8497__tile
        ;
        uint64_t v293 = (uint64_t) v25;
        TASSIGN(v292, v293);
        pipe_barrier(PIPE_V);
        TMULS(v292, v290, v70);
        // pto: %q_head_var_inline8529__tile
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v294 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_var_inline8529__tile
        ;
        uint64_t v295 = (uint64_t) v25;
        TASSIGN(v294, v295);
        pipe_barrier(PIPE_V);
        TADDS(v294, v292, v71);
        // pto: %rsqrt_tmp
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %rsqrt_tmp
        ;
        uint64_t v297 = (uint64_t) v22;
        TASSIGN(v296, v297);
        // pto: %q_head_inv_rms_inline8498__tile
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_inv_rms_inline8498__tile
        ;
        uint64_t v299 = (uint64_t) v29;
        TASSIGN(v298, v299);
        pipe_barrier(PIPE_V);
        TRSQRT(v298, v294, v296);
        // pto: %q_head_inv_rms_t_inline8464__tile
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v300 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %q_head_inv_rms_t_inline8464__tile
        ;
        uint64_t v301 = (uint64_t) v29;
        TASSIGN(v300, v301);
        // pto: %13
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v302 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %13
        ;
        uint64_t v303 = (uint64_t) v21;
        TASSIGN(v302, v303);
        // pto: %164
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v304;
        // pto: %164
        ;
        uint64_t v305 = (uint64_t) v21;
        TASSIGN(v304, v305);
        // pto: %q_nope_normed_inline8507__tile
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %q_nope_normed_inline8507__tile
        ;
        uint64_t v307 = (uint64_t) v25;
        TASSIGN(v306, v307);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v306, v304, v300);
        // pto: %q_nope_bf16_inline8510__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v308 = Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %q_nope_bf16_inline8510__tile
        ;
        uint64_t v309 = (uint64_t) v25;
        TASSIGN(v308, v309);
        pipe_barrier(PIPE_V);
        RoundMode v310 = RoundMode::CAST_RINT;
        SaturationMode v311 = SaturationMode::ON;
        TCVT(v308, v306, v310, v311);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %q_rope_chunk_raw_inline8513__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_chunk_raw_inline8513__tile
        ;
        uint64_t v313 = (uint64_t) v35;
        TASSIGN(v312, v313);
        // pto: %165
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v314;
        // pto: %165
        ;
        uint64_t v315 = (uint64_t) v35;
        TASSIGN(v314, v315);
        // pto: %q_rope_chunk_inline8515__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v316 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_chunk_inline8515__tile
        ;
        uint64_t v317 = (uint64_t) v21;
        TASSIGN(v316, v317);
        TROWEXPANDMUL(v316, v314, v300);
        // pto: %14
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v318 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %14
        ;
        uint64_t v319 = (uint64_t) v22;
        TASSIGN(v318, v319);
        pipe_barrier(PIPE_V);
        RoundMode v320 = RoundMode::CAST_RINT;
        SaturationMode v321 = SaturationMode::ON;
        TCVT(v318, v316, v320, v321);
        // pto: %q_rope_chunk_v1_inline8505__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v322 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_chunk_v1_inline8505__tile
        ;
        uint64_t v323 = (uint64_t) v21;
        TASSIGN(v322, v323);
        pipe_barrier(PIPE_V);
        RoundMode v324 = RoundMode::CAST_ROUND;
        SaturationMode v325 = SaturationMode::ON;
        TCVT(v322, v318, v324, v325);
        // pto: %gather_acc_init
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v326 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %gather_acc_init
        ;
        uint64_t v327 = (uint64_t) v22;
        TASSIGN(v326, v327);
        for (int64_t v328 = v58; v328 < v63; v328 += v54) {
          // pto: %gather_inp_row
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v329 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %gather_inp_row
          ;
          uint64_t v330 = (uint64_t) v21;
          TASSIGN(v329, v330);
          // pto: %166
          ;
          int64_t v331 = (int64_t) ((uint64_t) v328 * (uint64_t) v16);
          // pto: %166
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v332;
          // pto: %166
          ;
          uint64_t v333 = (uint64_t) ((int64_t) (uint64_t) v331 + (uint64_t) v21);
          TASSIGN(v332, v333);
          // pto: %gather_idx_row
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v334 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %gather_idx_row
          ;
          uint64_t v335 = (uint64_t) v20;
          TASSIGN(v334, v335);
          // pto: %167
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v336;
          // pto: %167
          ;
          uint64_t v337 = (uint64_t) v331;
          TASSIGN(v336, v337);
          // pto: %gather_row_tmp
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v338 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %gather_row_tmp
          ;
          uint64_t v339 = (uint64_t) v29;
          TASSIGN(v338, v339);
          // pto: %gather_row
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v340 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %gather_row
          ;
          uint64_t v341 = (uint64_t) v32;
          TASSIGN(v340, v341);
          pipe_barrier(PIPE_V);
          TGATHER(v340, v332, v336, v338);
          // pto: %assemble_view
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v342;
          // pto: %assemble_view
          ;
          uint64_t v343 = (uint64_t) ((int64_t) (uint64_t) v331 + (uint64_t) v22);
          TASSIGN(v342, v343);
          pipe_barrier(PIPE_V);
          TMOV(v342, v340);
        };
        // pto: %q_rope_swapped_inline8511__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v344 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_swapped_inline8511__tile
        ;
        uint64_t v345 = (uint64_t) v22;
        TASSIGN(v344, v345);
        // pto: %q_rope_base_inline8473__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v346 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_base_inline8473__tile
        ;
        uint64_t v347 = (uint64_t) v21;
        TASSIGN(v346, v347);
        pipe_barrier(PIPE_V);
        TMUL(v346, v322, v154);
        // pto: %q_rope_delta_inline8517__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v348 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_delta_inline8517__tile
        ;
        uint64_t v349 = (uint64_t) v22;
        TASSIGN(v348, v349);
        TMUL(v348, v344, v163);
        // pto: %q_rope_rot_inline8519__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v350 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_rot_inline8519__tile
        ;
        uint64_t v351 = (uint64_t) v21;
        TASSIGN(v350, v351);
        pipe_barrier(PIPE_V);
        TADD(v350, v346, v348);
        // pto: %q_rope_bf16_inline8512__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v352 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_bf16_inline8512__tile
        ;
        uint64_t v353 = (uint64_t) v21;
        TASSIGN(v352, v353);
        pipe_barrier(PIPE_V);
        RoundMode v354 = RoundMode::CAST_RINT;
        SaturationMode v355 = SaturationMode::ON;
        TCVT(v352, v350, v354, v355);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        // pto: %q_flat_inline8482__iter_v3_pview
        ;
        __gm__ bfloat16_t* v356 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %q_flat_inline8482__iter_v3_pview
        ;
        const int64_t v357 = 0;
        // pto: %q_flat_inline8482__iter_v3_pview
        ;
        const int64_t v358 = 32768;
        // pto: %q_flat_inline8482__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 8, 448> v359 = pto::Shape<1, 1, 1, 8, 448>();
        // pto: %q_flat_inline8482__iter_v3_pview
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v360 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %q_flat_inline8482__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v361 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v356 + (v357 + v156 * v358 + v186), v359, v360);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v361, v308);
        // pto: %172
        ;
        int64_t v362 = (int64_t) ((uint64_t) v182 + (uint64_t) v69);
        // pto: %173
        ;
        int64_t v363 = v362 < v58 ? v58 : v362;
        // pto: %q_flat_inline8482__tile_pview
        ;
        __gm__ bfloat16_t* v364 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %q_flat_inline8482__tile_pview
        ;
        const int64_t v365 = 0;
        // pto: %q_flat_inline8482__tile_pview
        ;
        const int64_t v366 = 32768;
        // pto: %q_flat_inline8482__tile_pview
        ;
        pto::Shape<1, 1, 1, 8, 64> v367 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %q_flat_inline8482__tile_pview
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v368 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %q_flat_inline8482__tile_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v369 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v364 + (v365 + v156 * v366 + v363), v367, v368);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v369, v352);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        // pto: %15
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v370 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %15
        ;
        uint64_t v371 = (uint64_t) v24;
        TASSIGN(v370, v371);
        // pto: %16
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v372 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %16
        ;
        uint64_t v373 = (uint64_t) v23;
        TASSIGN(v372, v373);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        RoundMode v374 = RoundMode::CAST_NONE;
        SaturationMode v375 = SaturationMode::ON;
        TCVT(v372, v200, v374, v375);
        // pto: %17
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v376 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %17
        ;
        uint64_t v377 = (uint64_t) v36;
        TASSIGN(v376, v377);
        TEXPANDS(v376, v66);
        // pto: %18
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v378 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %18
        ;
        uint64_t v379 = (uint64_t) v36;
        TASSIGN(v378, v379);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v378, v376, v146);
        // pto: %19
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v380 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %19
        ;
        uint64_t v381 = (uint64_t) v36;
        TASSIGN(v380, v381);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
        TCOLEXPANDMUL(v380, v378, v370);
        // pto: %20
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v382 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %20
        ;
        uint64_t v383 = (uint64_t) v23;
        TASSIGN(v382, v383);
        pipe_barrier(PIPE_V);
        TMUL(v382, v372, v380);
        // pto: %21
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v384 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %21
        ;
        uint64_t v385 = (uint64_t) v36;
        TASSIGN(v384, v385);
        pipe_barrier(PIPE_V);
        RoundMode v386 = RoundMode::CAST_RINT;
        SaturationMode v387 = SaturationMode::ON;
        TCVT(v384, v382, v386, v387);
        // pto: %22
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v388 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %22
        ;
        uint64_t v389 = (uint64_t) v23;
        TASSIGN(v388, v389);
        pipe_barrier(PIPE_V);
        RoundMode v390 = RoundMode::CAST_ROUND;
        SaturationMode v391 = SaturationMode::ON;
        TCVT(v388, v384, v390, v391);
        // pto: %23
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v392 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %23
        ;
        uint64_t v393 = (uint64_t) v36;
        TASSIGN(v392, v393);
        pipe_barrier(PIPE_V);
        TMUL(v392, v388, v388);
        // pto: %24
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v394 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %24
        ;
        uint64_t v395 = (uint64_t) v36;
        TASSIGN(v394, v395);
        // pto: %174
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v396;
        // pto: %174
        ;
        uint64_t v397 = (uint64_t) v36;
        TASSIGN(v396, v397);
        // pto: %25
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v398 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %25
        ;
        uint64_t v399 = (uint64_t) v37;
        TASSIGN(v398, v399);
        // pto: %175
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v400;
        // pto: %175
        ;
        uint64_t v401 = (uint64_t) v37;
        TASSIGN(v400, v401);
        // pto: %26
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v402 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %26
        ;
        uint64_t v403 = (uint64_t) v24;
        TASSIGN(v402, v403);
        pipe_barrier(PIPE_V);
        TADD(v402, v396, v400);
        // pto: %27
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v404 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %27
        ;
        uint64_t v405 = (uint64_t) v38;
        TASSIGN(v404, v405);
        // pto: %176
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v406;
        // pto: %176
        ;
        uint64_t v407 = (uint64_t) v38;
        TASSIGN(v406, v407);
        // pto: %28
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v408 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %28
        ;
        uint64_t v409 = (uint64_t) v39;
        TASSIGN(v408, v409);
        // pto: %177
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v410;
        // pto: %177
        ;
        uint64_t v411 = (uint64_t) v39;
        TASSIGN(v410, v411);
        // pto: %29
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v412 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %29
        ;
        uint64_t v413 = (uint64_t) v40;
        TASSIGN(v412, v413);
        TADD(v412, v406, v410);
        // pto: %30
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v414 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %30
        ;
        uint64_t v415 = (uint64_t) v41;
        TASSIGN(v414, v415);
        // pto: %178
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v416;
        // pto: %178
        ;
        uint64_t v417 = (uint64_t) v41;
        TASSIGN(v416, v417);
        // pto: %31
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v418 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %31
        ;
        uint64_t v419 = (uint64_t) v42;
        TASSIGN(v418, v419);
        // pto: %179
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v420;
        // pto: %179
        ;
        uint64_t v421 = (uint64_t) v42;
        TASSIGN(v420, v421);
        // pto: %32
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v422 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %32
        ;
        uint64_t v423 = (uint64_t) v43;
        TASSIGN(v422, v423);
        TADD(v422, v416, v420);
        // pto: %33
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v424 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %33
        ;
        uint64_t v425 = (uint64_t) v44;
        TASSIGN(v424, v425);
        // pto: %180
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v426;
        // pto: %180
        ;
        uint64_t v427 = (uint64_t) v44;
        TASSIGN(v426, v427);
        // pto: %34
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v428 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %34
        ;
        uint64_t v429 = (uint64_t) v45;
        TASSIGN(v428, v429);
        // pto: %181
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v430;
        // pto: %181
        ;
        uint64_t v431 = (uint64_t) v45;
        TASSIGN(v430, v431);
        // pto: %35
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v432 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %35
        ;
        uint64_t v433 = (uint64_t) v36;
        TASSIGN(v432, v433);
        pipe_barrier(PIPE_V);
        TADD(v432, v426, v430);
        // pto: %36
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v434 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %36
        ;
        uint64_t v435 = (uint64_t) v24;
        TASSIGN(v434, v435);
        TADD(v434, v402, v422);
        // pto: %37
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v436 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %37
        ;
        uint64_t v437 = (uint64_t) v36;
        TASSIGN(v436, v437);
        pipe_barrier(PIPE_V);
        TADD(v436, v412, v432);
        // pto: %38
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v438 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %38
        ;
        uint64_t v439 = (uint64_t) v24;
        TASSIGN(v438, v439);
        pipe_barrier(PIPE_V);
        TADD(v438, v434, v436);
        // pto: %39
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v440 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v67);
        // pto: %39
        ;
        uint64_t v441 = (uint64_t) v36;
        TASSIGN(v440, v441);
        // pto: %40
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v442 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %40
        ;
        uint64_t v443 = (uint64_t) v40;
        TASSIGN(v442, v443);
        pipe_barrier(PIPE_V);
        TROWSUM(v442, v438, v440);
        // pto: %41
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v444 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %41
        ;
        uint64_t v445 = (uint64_t) v40;
        TASSIGN(v444, v445);
        // pto: %42
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v446 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %42
        ;
        uint64_t v447 = (uint64_t) v36;
        TASSIGN(v446, v447);
        pipe_barrier(PIPE_V);
        TMULS(v446, v444, v70);
        // pto: %43
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v448 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %43
        ;
        uint64_t v449 = (uint64_t) v36;
        TASSIGN(v448, v449);
        pipe_barrier(PIPE_V);
        TADDS(v448, v446, v71);
        // pto: %44
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v450 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %44
        ;
        uint64_t v451 = (uint64_t) v24;
        TASSIGN(v450, v451);
        // pto: %45
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v452 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %45
        ;
        uint64_t v453 = (uint64_t) v40;
        TASSIGN(v452, v453);
        pipe_barrier(PIPE_V);
        TRSQRT(v452, v448, v450);
        // pto: %46
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v454 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %46
        ;
        uint64_t v455 = (uint64_t) v40;
        TASSIGN(v454, v455);
        // pto: %47
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v456 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %47
        ;
        uint64_t v457 = (uint64_t) v23;
        TASSIGN(v456, v457);
        // pto: %182
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v458;
        // pto: %182
        ;
        uint64_t v459 = (uint64_t) v23;
        TASSIGN(v458, v459);
        // pto: %48
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v460 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %48
        ;
        uint64_t v461 = (uint64_t) v36;
        TASSIGN(v460, v461);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v460, v458, v454);
        // pto: %49
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v462 = Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %49
        ;
        uint64_t v463 = (uint64_t) v36;
        TASSIGN(v462, v463);
        pipe_barrier(PIPE_V);
        RoundMode v464 = RoundMode::CAST_RINT;
        SaturationMode v465 = SaturationMode::ON;
        TCVT(v462, v460, v464, v465);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        // pto: %50
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %50
        ;
        uint64_t v467 = (uint64_t) v46;
        TASSIGN(v466, v467);
        // pto: %183
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v468;
        // pto: %183
        ;
        uint64_t v469 = (uint64_t) v46;
        TASSIGN(v468, v469);
        // pto: %51
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v470 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %51
        ;
        uint64_t v471 = (uint64_t) v23;
        TASSIGN(v470, v471);
        TROWEXPANDMUL(v470, v468, v454);
        // pto: %52
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %52
        ;
        uint64_t v473 = (uint64_t) v24;
        TASSIGN(v472, v473);
        pipe_barrier(PIPE_V);
        RoundMode v474 = RoundMode::CAST_RINT;
        SaturationMode v475 = SaturationMode::ON;
        TCVT(v472, v470, v474, v475);
        // pto: %53
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v476 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %53
        ;
        uint64_t v477 = (uint64_t) v23;
        TASSIGN(v476, v477);
        pipe_barrier(PIPE_V);
        RoundMode v478 = RoundMode::CAST_ROUND;
        SaturationMode v479 = SaturationMode::ON;
        TCVT(v476, v472, v478, v479);
        // pto: %54
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v480 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %54
        ;
        uint64_t v481 = (uint64_t) v24;
        TASSIGN(v480, v481);
        for (int64_t v482 = v58; v482 < v63; v482 += v54) {
          // pto: %55
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v483 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %55
          ;
          uint64_t v484 = (uint64_t) v23;
          TASSIGN(v483, v484);
          // pto: %185
          ;
          int64_t v485 = (int64_t) ((uint64_t) v482 * (uint64_t) v16);
          // pto: %185
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v486;
          // pto: %185
          ;
          uint64_t v487 = (uint64_t) ((int64_t) (uint64_t) v485 + (uint64_t) v23);
          TASSIGN(v486, v487);
          // pto: %56
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v488 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %56
          ;
          uint64_t v489 = (uint64_t) v20;
          TASSIGN(v488, v489);
          // pto: %186
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v490;
          // pto: %186
          ;
          uint64_t v491 = (uint64_t) v485;
          TASSIGN(v490, v491);
          // pto: %57
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v492 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %57
          ;
          uint64_t v493 = (uint64_t) v40;
          TASSIGN(v492, v493);
          // pto: %58
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v494 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %58
          ;
          uint64_t v495 = (uint64_t) v43;
          TASSIGN(v494, v495);
          pipe_barrier(PIPE_V);
          TGATHER(v494, v486, v490, v492);
          // pto: %187
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v496;
          // pto: %187
          ;
          uint64_t v497 = (uint64_t) ((int64_t) (uint64_t) v485 + (uint64_t) v24);
          TASSIGN(v496, v497);
          pipe_barrier(PIPE_V);
          TMOV(v496, v494);
        };
        // pto: %60
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v498 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %60
        ;
        uint64_t v499 = (uint64_t) v24;
        TASSIGN(v498, v499);
        // pto: %61
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v500 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %61
        ;
        uint64_t v501 = (uint64_t) v23;
        TASSIGN(v500, v501);
        pipe_barrier(PIPE_V);
        TMUL(v500, v476, v154);
        // pto: %62
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v502 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %62
        ;
        uint64_t v503 = (uint64_t) v24;
        TASSIGN(v502, v503);
        TMUL(v502, v498, v163);
        // pto: %63
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v504 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %63
        ;
        uint64_t v505 = (uint64_t) v23;
        TASSIGN(v504, v505);
        pipe_barrier(PIPE_V);
        TADD(v504, v500, v502);
        // pto: %64
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v506 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %64
        ;
        uint64_t v507 = (uint64_t) v23;
        TASSIGN(v506, v507);
        pipe_barrier(PIPE_V);
        RoundMode v508 = RoundMode::CAST_RINT;
        SaturationMode v509 = SaturationMode::ON;
        TCVT(v506, v504, v508, v509);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        // pto: %191
        ;
        __gm__ bfloat16_t* v510 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %191
        ;
        const int64_t v511 = 0;
        // pto: %191
        ;
        const int64_t v512 = 32768;
        // pto: %191
        ;
        pto::Shape<1, 1, 1, 8, 448> v513 = pto::Shape<1, 1, 1, 8, 448>();
        // pto: %191
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v514 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %191
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v515 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v510 + (v511 + v156 * v512 + v202), v513, v514);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v515, v462);
        // pto: %194
        ;
        int64_t v516 = (int64_t) ((uint64_t) v183 + (uint64_t) v69);
        // pto: %195
        ;
        int64_t v517 = v516 < v58 ? v58 : v516;
        // pto: %196
        ;
        __gm__ bfloat16_t* v518 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %196
        ;
        const int64_t v519 = 0;
        // pto: %196
        ;
        const int64_t v520 = 32768;
        // pto: %196
        ;
        pto::Shape<1, 1, 1, 8, 64> v521 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %196
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v522 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %196
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v523 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v518 + (v519 + v156 * v520 + v517), v521, v522);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        TSTORE(v523, v506);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
      // pto: %197
      ;
      uint64_t v524 = (uint64_t) v139;
      // pto: %197, %198
      ;
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
      if ((int64_t) (v524 - (uint64_t) v180) == v54) {
        // pto: %199, %200
        ;
        int64_t v525 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v143 + (uint64_t) v180) * (uint64_t) v55);
        // pto: %65
        ;
        Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v526 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %65
        ;
        uint64_t v527 = (uint64_t) v21;
        TASSIGN(v526, v527);
        // pto: %202
        ;
        int64_t v528 = v525 < v58 ? v58 : v525;
        // pto: %203
        ;
        __gm__ int32_t* v529 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %203
        ;
        const int64_t v530 = 0;
        // pto: %203
        ;
        const int64_t v531 = 32768;
        // pto: %203
        ;
        pto::Shape<1, 1, 1, 8, 512> v532 = pto::Shape<1, 1, 1, 8, 512>();
        // pto: %203
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v533 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %203
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v534 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v529 + (v530 + v148 * v531 + v528), v532, v533);
        TLOAD(v526, v534);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        // pto: %66
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v535 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %66
        ;
        uint64_t v536 = (uint64_t) v25;
        TASSIGN(v535, v536);
        // pto: %205
        ;
        __gm__ float* v537 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %205
        ;
        const int64_t v538 = 0;
        // pto: %205
        ;
        pto::Shape<1, 1, 1, 1, 512> v539 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %205
        ;
        pto::Stride<512, 512, 512, 512, 1> v540 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %205
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v541 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v537 + (v538 + v528), v539, v540);
        TLOAD(v535, v541);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        // pto: %67
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v542 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %67
        ;
        uint64_t v543 = (uint64_t) v25;
        TASSIGN(v542, v543);
        // pto: %68
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v544 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %68
        ;
        uint64_t v545 = (uint64_t) v21;
        TASSIGN(v544, v545);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        RoundMode v546 = RoundMode::CAST_NONE;
        SaturationMode v547 = SaturationMode::ON;
        TCVT(v544, v526, v546, v547);
        // pto: %69
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v548 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %69
        ;
        uint64_t v549 = (uint64_t) v23;
        TASSIGN(v548, v549);
        TEXPANDS(v548, v66);
        // pto: %70
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v550 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %70
        ;
        uint64_t v551 = (uint64_t) v23;
        TASSIGN(v550, v551);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v550, v548, v146);
        // pto: %71
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v552 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %71
        ;
        uint64_t v553 = (uint64_t) v23;
        TASSIGN(v552, v553);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        TCOLEXPANDMUL(v552, v550, v542);
        // pto: %72
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v554 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %72
        ;
        uint64_t v555 = (uint64_t) v21;
        TASSIGN(v554, v555);
        pipe_barrier(PIPE_V);
        TMUL(v554, v544, v552);
        // pto: %73
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v556 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %73
        ;
        uint64_t v557 = (uint64_t) v23;
        TASSIGN(v556, v557);
        pipe_barrier(PIPE_V);
        RoundMode v558 = RoundMode::CAST_RINT;
        SaturationMode v559 = SaturationMode::ON;
        TCVT(v556, v554, v558, v559);
        // pto: %74
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v560 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %74
        ;
        uint64_t v561 = (uint64_t) v21;
        TASSIGN(v560, v561);
        pipe_barrier(PIPE_V);
        RoundMode v562 = RoundMode::CAST_ROUND;
        SaturationMode v563 = SaturationMode::ON;
        TCVT(v560, v556, v562, v563);
        // pto: %75
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v564 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %75
        ;
        uint64_t v565 = (uint64_t) v23;
        TASSIGN(v564, v565);
        pipe_barrier(PIPE_V);
        TMUL(v564, v560, v560);
        // pto: %76
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v566 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %76
        ;
        uint64_t v567 = (uint64_t) v23;
        TASSIGN(v566, v567);
        // pto: %206
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v568;
        // pto: %206
        ;
        uint64_t v569 = (uint64_t) v23;
        TASSIGN(v568, v569);
        // pto: %77
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v570 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %77
        ;
        uint64_t v571 = (uint64_t) v47;
        TASSIGN(v570, v571);
        // pto: %207
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v572;
        // pto: %207
        ;
        uint64_t v573 = (uint64_t) v47;
        TASSIGN(v572, v573);
        // pto: %78
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v574 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %78
        ;
        uint64_t v575 = (uint64_t) v25;
        TASSIGN(v574, v575);
        pipe_barrier(PIPE_V);
        TADD(v574, v568, v572);
        // pto: %79
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v576 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %79
        ;
        uint64_t v577 = (uint64_t) v48;
        TASSIGN(v576, v577);
        // pto: %208
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v578;
        // pto: %208
        ;
        uint64_t v579 = (uint64_t) v48;
        TASSIGN(v578, v579);
        // pto: %80
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v580 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %80
        ;
        uint64_t v581 = (uint64_t) v49;
        TASSIGN(v580, v581);
        // pto: %209
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v582;
        // pto: %209
        ;
        uint64_t v583 = (uint64_t) v49;
        TASSIGN(v582, v583);
        // pto: %81
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v584 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %81
        ;
        uint64_t v585 = (uint64_t) v36;
        TASSIGN(v584, v585);
        TADD(v584, v578, v582);
        // pto: %82
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v586 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %82
        ;
        uint64_t v587 = (uint64_t) v50;
        TASSIGN(v586, v587);
        // pto: %210
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v588;
        // pto: %210
        ;
        uint64_t v589 = (uint64_t) v50;
        TASSIGN(v588, v589);
        // pto: %83
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v590 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %83
        ;
        uint64_t v591 = (uint64_t) v51;
        TASSIGN(v590, v591);
        // pto: %211
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v592;
        // pto: %211
        ;
        uint64_t v593 = (uint64_t) v51;
        TASSIGN(v592, v593);
        // pto: %84
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v594 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %84
        ;
        uint64_t v595 = (uint64_t) v22;
        TASSIGN(v594, v595);
        TADD(v594, v588, v592);
        // pto: %85
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v596 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %85
        ;
        uint64_t v597 = (uint64_t) v52;
        TASSIGN(v596, v597);
        // pto: %212
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v598;
        // pto: %212
        ;
        uint64_t v599 = (uint64_t) v52;
        TASSIGN(v598, v599);
        // pto: %86
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v600 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %86
        ;
        uint64_t v601 = (uint64_t) v46;
        TASSIGN(v600, v601);
        // pto: %213
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v602;
        // pto: %213
        ;
        uint64_t v603 = (uint64_t) v46;
        TASSIGN(v602, v603);
        // pto: %87
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v604 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %87
        ;
        uint64_t v605 = (uint64_t) v23;
        TASSIGN(v604, v605);
        pipe_barrier(PIPE_V);
        TADD(v604, v598, v602);
        // pto: %88
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v606 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %88
        ;
        uint64_t v607 = (uint64_t) v25;
        TASSIGN(v606, v607);
        TADD(v606, v574, v594);
        // pto: %89
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v608 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %89
        ;
        uint64_t v609 = (uint64_t) v23;
        TASSIGN(v608, v609);
        pipe_barrier(PIPE_V);
        TADD(v608, v584, v604);
        // pto: %90
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v610 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %90
        ;
        uint64_t v611 = (uint64_t) v25;
        TASSIGN(v610, v611);
        pipe_barrier(PIPE_V);
        TADD(v610, v606, v608);
        // pto: %91
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v612 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v67);
        // pto: %91
        ;
        uint64_t v613 = (uint64_t) v23;
        TASSIGN(v612, v613);
        // pto: %92
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v614 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %92
        ;
        uint64_t v615 = (uint64_t) v36;
        TASSIGN(v614, v615);
        pipe_barrier(PIPE_V);
        TROWSUM(v614, v610, v612);
        // pto: %93
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v616 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %93
        ;
        uint64_t v617 = (uint64_t) v36;
        TASSIGN(v616, v617);
        // pto: %94
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v618 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %94
        ;
        uint64_t v619 = (uint64_t) v23;
        TASSIGN(v618, v619);
        pipe_barrier(PIPE_V);
        TMULS(v618, v616, v70);
        // pto: %95
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v620 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %95
        ;
        uint64_t v621 = (uint64_t) v23;
        TASSIGN(v620, v621);
        pipe_barrier(PIPE_V);
        TADDS(v620, v618, v71);
        // pto: %96
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v622 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %96
        ;
        uint64_t v623 = (uint64_t) v25;
        TASSIGN(v622, v623);
        // pto: %97
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v624 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %97
        ;
        uint64_t v625 = (uint64_t) v36;
        TASSIGN(v624, v625);
        pipe_barrier(PIPE_V);
        TRSQRT(v624, v620, v622);
        // pto: %98
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v626 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %98
        ;
        uint64_t v627 = (uint64_t) v36;
        TASSIGN(v626, v627);
        // pto: %99
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v628 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %99
        ;
        uint64_t v629 = (uint64_t) v21;
        TASSIGN(v628, v629);
        // pto: %214
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v630;
        // pto: %214
        ;
        uint64_t v631 = (uint64_t) v21;
        TASSIGN(v630, v631);
        // pto: %100
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v632 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %100
        ;
        uint64_t v633 = (uint64_t) v23;
        TASSIGN(v632, v633);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v632, v630, v626);
        // pto: %101
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v634 = Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %101
        ;
        uint64_t v635 = (uint64_t) v23;
        TASSIGN(v634, v635);
        pipe_barrier(PIPE_V);
        RoundMode v636 = RoundMode::CAST_RINT;
        SaturationMode v637 = SaturationMode::ON;
        TCVT(v634, v632, v636, v637);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        // pto: %q_flat_inline8482__rv_v4_main_pview
        ;
        __gm__ bfloat16_t* v638 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %q_flat_inline8482__rv_v4_main_pview
        ;
        const int64_t v639 = 0;
        // pto: %q_flat_inline8482__rv_v4_main_pview
        ;
        const int64_t v640 = 32768;
        // pto: %q_flat_inline8482__rv_v4_main_pview
        ;
        pto::Shape<1, 1, 1, 8, 448> v641 = pto::Shape<1, 1, 1, 8, 448>();
        // pto: %q_flat_inline8482__rv_v4_main_pview
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v642 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %q_flat_inline8482__rv_v4_main_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v643 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v638 + (v639 + v156 * v640 + v528), v641, v642);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        TSTORE(v643, v634);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
        // pto: %102
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v644 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %102
        ;
        uint64_t v645 = (uint64_t) v35;
        TASSIGN(v644, v645);
        // pto: %218
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v646;
        // pto: %218
        ;
        uint64_t v647 = (uint64_t) v35;
        TASSIGN(v646, v647);
        // pto: %103
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v648 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %103
        ;
        uint64_t v649 = (uint64_t) v21;
        TASSIGN(v648, v649);
        TROWEXPANDMUL(v648, v646, v626);
        // pto: %104
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v650 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %104
        ;
        uint64_t v651 = (uint64_t) v23;
        TASSIGN(v650, v651);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
        RoundMode v652 = RoundMode::CAST_RINT;
        SaturationMode v653 = SaturationMode::ON;
        TCVT(v650, v648, v652, v653);
        // pto: %105
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v654 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %105
        ;
        uint64_t v655 = (uint64_t) v21;
        TASSIGN(v654, v655);
        pipe_barrier(PIPE_V);
        RoundMode v656 = RoundMode::CAST_ROUND;
        SaturationMode v657 = SaturationMode::ON;
        TCVT(v654, v650, v656, v657);
        // pto: %106
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v658 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %106
        ;
        uint64_t v659 = (uint64_t) v23;
        TASSIGN(v658, v659);
        for (int64_t v660 = v58; v660 < v63; v660 += v54) {
          // pto: %107
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v661 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %107
          ;
          uint64_t v662 = (uint64_t) v21;
          TASSIGN(v661, v662);
          // pto: %220
          ;
          int64_t v663 = (int64_t) ((uint64_t) v660 * (uint64_t) v16);
          // pto: %220
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v664;
          // pto: %220
          ;
          uint64_t v665 = (uint64_t) ((int64_t) (uint64_t) v663 + (uint64_t) v21);
          TASSIGN(v664, v665);
          // pto: %108
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v666 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %108
          ;
          uint64_t v667 = (uint64_t) v20;
          TASSIGN(v666, v667);
          // pto: %221
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v668;
          // pto: %221
          ;
          uint64_t v669 = (uint64_t) v663;
          TASSIGN(v668, v669);
          // pto: %109
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v670 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %109
          ;
          uint64_t v671 = (uint64_t) v25;
          TASSIGN(v670, v671);
          // pto: %110
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v672 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
          // pto: %110
          ;
          uint64_t v673 = (uint64_t) v36;
          TASSIGN(v672, v673);
          pipe_barrier(PIPE_V);
          TGATHER(v672, v664, v668, v670);
          // pto: %222
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v674;
          // pto: %222
          ;
          uint64_t v675 = (uint64_t) ((int64_t) (uint64_t) v663 + (uint64_t) v23);
          TASSIGN(v674, v675);
          pipe_barrier(PIPE_V);
          TMOV(v674, v672);
        };
        // pto: %112
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v676 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %112
        ;
        uint64_t v677 = (uint64_t) v23;
        TASSIGN(v676, v677);
        // pto: %113
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v678 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %113
        ;
        uint64_t v679 = (uint64_t) v21;
        TASSIGN(v678, v679);
        pipe_barrier(PIPE_V);
        TMUL(v678, v654, v154);
        // pto: %114
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v680 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %114
        ;
        uint64_t v681 = (uint64_t) v23;
        TASSIGN(v680, v681);
        TMUL(v680, v676, v163);
        // pto: %115
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v682 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %115
        ;
        uint64_t v683 = (uint64_t) v21;
        TASSIGN(v682, v683);
        pipe_barrier(PIPE_V);
        TADD(v682, v678, v680);
        // pto: %116
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v684 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %116
        ;
        uint64_t v685 = (uint64_t) v21;
        TASSIGN(v684, v685);
        pipe_barrier(PIPE_V);
        RoundMode v686 = RoundMode::CAST_RINT;
        SaturationMode v687 = SaturationMode::ON;
        TCVT(v684, v682, v686, v687);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        // pto: %225
        ;
        int64_t v688 = (int64_t) ((uint64_t) v525 + (uint64_t) v69);
        // pto: %226
        ;
        int64_t v689 = v688 < v58 ? v58 : v688;
        // pto: %227
        ;
        __gm__ bfloat16_t* v690 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %227
        ;
        const int64_t v691 = 0;
        // pto: %227
        ;
        const int64_t v692 = 32768;
        // pto: %227
        ;
        pto::Shape<1, 1, 1, 8, 64> v693 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %227
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v694 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %227
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v695 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v690 + (v691 + v156 * v692 + v689), v693, v694);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
        TSTORE(v695, v684);
      };
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    } else {
      // pto: %228
      ;
      int64_t v696 = (int64_t) ((uint64_t) v8 - (uint64_t) v144);
      // pto: %qr_scale_dq_tail_inline8520__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v697 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
      // pto: %qr_scale_dq_tail_inline8520__ssa_v0
      ;
      uint64_t v698 = (uint64_t) v32;
      TASSIGN(v697, v698);
      // pto: %229
      ;
      int64_t v699 = v144 < v58 ? v58 : v144;
      // pto: %230
      ;
      __gm__ float* v700 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %230
      ;
      const int64_t v701 = 0;
      // pto: %230
      ;
      pto::Shape<1, 1, 1, 8, 1> v702 = pto::Shape<1, 1, 1, 8, 1>();
      // pto: %230
      ;
      pto::Stride<8, 8, 8, 1, 512> v703 = pto::Stride<8, 8, 8, 1, 512>();
      // pto: %230
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN> v704 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN>(v700 + (v701 + v699), v702, v703);
      pipe_barrier(PIPE_ALL);
      TLOAD(v697, v704);
      // pto: %q_cos_il_tail_inline8501__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v705 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v696, v56);
      // pto: %q_cos_il_tail_inline8501__ssa_v0
      ;
      uint64_t v706 = (uint64_t) v25;
      TASSIGN(v705, v706);
      // pto: %231
      ;
      int64_t v707 = v145 < v58 ? v58 : v145;
      // pto: %232
      ;
      const int64_t v708 = 0;
      // pto: %232
      ;
      __gm__ float* v709 = PTOAS__GLOBAL_TENSOR_DATA(v101);
      // pto: %232
      ;
      const int64_t v710 = 1;
      // pto: %232
      ;
      const int64_t v711 = 1;
      // pto: %232
      ;
      const int64_t v712 = 1;
      // pto: %232
      ;
      int64_t v713 = v696 * v56;
      // pto: %232
      ;
      int64_t v714 = v712 * v713;
      // pto: %232
      ;
      pto::Shape<1, 1, 1, -1, 64> v715 = pto::Shape<1, 1, 1, -1, 64>(v710, v711, v712, v696, v56);
      // pto: %232
      ;
      pto::Stride<-1, -1, -1, -1, -1> v716 = pto::Stride<-1, -1, -1, -1, -1>(v711 * v714, v714, v713, v56, v54);
      // pto: %232
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v717 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v709 + (v708 + v707 * v56 + v58 * v54), v715, v716);
      pipe_barrier(PIPE_ALL);
      TLOAD(v705, v717);
      // pto: %q_sin_signed_tail_inline8483__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v718 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v696, v56);
      // pto: %q_sin_signed_tail_inline8483__ssa_v0
      ;
      uint64_t v719 = (uint64_t) v36;
      TASSIGN(v718, v719);
      // pto: %234
      ;
      const int64_t v720 = 0;
      // pto: %234
      ;
      __gm__ float* v721 = PTOAS__GLOBAL_TENSOR_DATA(v110);
      // pto: %234
      ;
      const int64_t v722 = 1;
      // pto: %234
      ;
      const int64_t v723 = 1;
      // pto: %234
      ;
      const int64_t v724 = 1;
      // pto: %234
      ;
      int64_t v725 = v696 * v56;
      // pto: %234
      ;
      int64_t v726 = v724 * v725;
      // pto: %234
      ;
      pto::Shape<1, 1, 1, -1, 64> v727 = pto::Shape<1, 1, 1, -1, 64>(v722, v723, v724, v696, v56);
      // pto: %234
      ;
      pto::Stride<-1, -1, -1, -1, -1> v728 = pto::Stride<-1, -1, -1, -1, -1>(v723 * v726, v726, v725, v56, v54);
      // pto: %234
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v729 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v721 + (v720 + v707 * v56 + v58 * v54), v727, v728);
      pipe_barrier(PIPE_ALL);
      TLOAD(v718, v729);
      // pto: %t__tmp_v153
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v730 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v153
      ;
      uint64_t v731 = (uint64_t) v21;
      TASSIGN(v730, v731);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      pipe_barrier(PIPE_V);
      TEXPANDS(v730, v66);
      // pto: %t__ci_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v732 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v68);
      // pto: %t__ci_tmp_v0
      ;
      uint64_t v733 = (uint64_t) v23;
      TASSIGN(v732, v733);
      // pto: %t__tmp_v154
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v734 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
      // pto: %t__tmp_v154
      ;
      uint64_t v735 = (uint64_t) v18;
      TASSIGN(v734, v735);
      // pto: %ci_tmp_view
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v736;
      TRESHAPE(v736, v732);
      // pto: %ci_dst_view
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v737;
      TRESHAPE(v737, v734);
      TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v737, v72, v736);
      // pto: %t__tmp_v155
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v738 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v56);
      // pto: %t__tmp_v155
      ;
      uint64_t v739 = (uint64_t) v23;
      TASSIGN(v738, v739);
      pipe_barrier(PIPE_V);
      RoundMode v740 = RoundMode::CAST_ROUND;
      SaturationMode v741 = SaturationMode::ON;
      TCVT(v738, v734, v740, v741);
      // pto: %q_col_inline8525__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v742 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_col_inline8525__ssa_v0
      ;
      uint64_t v743 = (uint64_t) v21;
      TASSIGN(v742, v743);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v742, v730, v738);
      // pto: %t__tmp_v156
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v744 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v156
      ;
      uint64_t v745 = (uint64_t) v23;
      TASSIGN(v744, v745);
      pipe_barrier(PIPE_V);
      TMULS(v744, v742, v73);
      // pto: %t__tmp_v157
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v746 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v157
      ;
      uint64_t v747 = (uint64_t) v23;
      TASSIGN(v746, v747);
      pipe_barrier(PIPE_V);
      RoundMode v748 = RoundMode::CAST_TRUNC;
      SaturationMode v749 = SaturationMode::ON;
      TCVT(v746, v744, v748, v749);
      // pto: %q_dup_f_inline8521__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v750 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_dup_f_inline8521__ssa_v0
      ;
      uint64_t v751 = (uint64_t) v23;
      TASSIGN(v750, v751);
      pipe_barrier(PIPE_V);
      RoundMode v752 = RoundMode::CAST_ROUND;
      SaturationMode v753 = SaturationMode::ON;
      TCVT(v750, v746, v752, v753);
      // pto: %t__tmp_v158
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v754 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v158
      ;
      uint64_t v755 = (uint64_t) v23;
      TASSIGN(v754, v755);
      pipe_barrier(PIPE_V);
      TMULS(v754, v750, v74);
      // pto: %q_lane_inline8527__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v756 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_lane_inline8527__ssa_v0
      ;
      uint64_t v757 = (uint64_t) v23;
      TASSIGN(v756, v757);
      pipe_barrier(PIPE_V);
      TSUB(v756, v742, v754);
      // pto: %t__tmp_v159
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v758 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v159
      ;
      uint64_t v759 = (uint64_t) v21;
      TASSIGN(v758, v759);
      pipe_barrier(PIPE_V);
      TADDS(v758, v742, v66);
      // pto: %t__tmp_v160
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v760 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v160
      ;
      uint64_t v761 = (uint64_t) v23;
      TASSIGN(v760, v761);
      TMULS(v760, v756, v74);
      // pto: %q_swap_f_inline8528__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v762 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_swap_f_inline8528__ssa_v0
      ;
      uint64_t v763 = (uint64_t) v21;
      TASSIGN(v762, v763);
      pipe_barrier(PIPE_V);
      TSUB(v762, v758, v760);
      // pto: %t__ci_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v764 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v68);
      // pto: %t__ci_tmp_v1
      ;
      uint64_t v765 = (uint64_t) v23;
      TASSIGN(v764, v765);
      // pto: %t__tmp_v161
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v766 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
      // pto: %t__tmp_v161
      ;
      uint64_t v767 = (uint64_t) v18;
      TASSIGN(v766, v767);
      // pto: %235
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v768;
      TRESHAPE(v768, v764);
      // pto: %236
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v769;
      TRESHAPE(v769, v766);
      pipe_barrier(PIPE_V);
      TCI<Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v769, v72, v768);
      // pto: %t__tmp_v162
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v770 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
      // pto: %t__tmp_v162
      ;
      uint64_t v771 = (uint64_t) v23;
      TASSIGN(v770, v771);
      pipe_barrier(PIPE_V);
      RoundMode v772 = RoundMode::CAST_ROUND;
      SaturationMode v773 = SaturationMode::ON;
      TCVT(v770, v766, v772, v773);
      // pto: %q_row_seed_inline8523__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v774 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
      // pto: %q_row_seed_inline8523__ssa_v0
      ;
      uint64_t v775 = (uint64_t) v18;
      TASSIGN(v774, v775);
      pipe_barrier(PIPE_V);
      TMULS(v774, v770, v75);
      // pto: %t__tmp_v163
      ;
      Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v776 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v56, v63);
      // pto: %t__tmp_v163
      ;
      uint64_t v777 = (uint64_t) v23;
      TASSIGN(v776, v777);
      pipe_barrier(PIPE_V);
      TEXPANDS(v776, v66);
      // pto: %q_row_grid_inline8514__ssa_v0
      ;
      Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v778 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v56, v63);
      // pto: %q_row_grid_inline8514__ssa_v0
      ;
      uint64_t v779 = (uint64_t) v23;
      TASSIGN(v778, v779);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v778, v776, v774);
      // pto: %transpose_tmp
      ;
      Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v780 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v56, v63);
      // pto: %transpose_tmp
      ;
      uint64_t v781 = (uint64_t) v18;
      TASSIGN(v780, v781);
      // pto: %q_row_offset_inline8530__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v782 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_row_offset_inline8530__ssa_v0
      ;
      uint64_t v783 = (uint64_t) v19;
      TASSIGN(v782, v783);
      pipe_barrier(PIPE_V);
      TTRANS(v782, v778, v780);
      // pto: %t__tmp_v164
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v784 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %t__tmp_v164
      ;
      uint64_t v785 = (uint64_t) v21;
      TASSIGN(v784, v785);
      pipe_barrier(PIPE_V);
      TADD(v784, v762, v782);
      // pto: %q_swap_idx_tail_inline8485__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v786 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_swap_idx_tail_inline8485__ssa_v0
      ;
      uint64_t v787 = (uint64_t) v18;
      TASSIGN(v786, v787);
      pipe_barrier(PIPE_V);
      RoundMode v788 = RoundMode::CAST_ROUND;
      SaturationMode v789 = SaturationMode::ON;
      TCVT(v786, v784, v788, v789);
      // pto: %q_head_reduce_tmp_inline8526__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v790 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_head_reduce_tmp_inline8526__ssa_v0
      ;
      uint64_t v791 = (uint64_t) v19;
      TASSIGN(v790, v791);
      // pto: %q_rsqrt_tmp_inline8488__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v792 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
      // pto: %q_rsqrt_tmp_inline8488__ssa_v0
      ;
      uint64_t v793 = (uint64_t) v40;
      TASSIGN(v792, v793);
      // pto: %q_gather_tmp_inline8463__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v794 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
      // pto: %q_gather_tmp_inline8463__ssa_v0
      ;
      uint64_t v795 = (uint64_t) v20;
      TASSIGN(v794, v795);
      pipe_barrier(PIPE_ALL);
      for (int64_t v796 = v58; v796 < v139; v796 += v54) {
        // pto: %237, %238
        ;
        int64_t v797 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v143 + (uint64_t) v796) * (uint64_t) v55);
        // pto: %q_head_acc_tail_inline8455__ssa_v0
        ;
        Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v798 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_acc_tail_inline8455__ssa_v0
        ;
        uint64_t v799 = (uint64_t) v21;
        TASSIGN(v798, v799);
        // pto: %240
        ;
        int64_t v800 = v797 < v58 ? v58 : v797;
        // pto: %241
        ;
        __gm__ int32_t* v801 = PTOAS__GLOBAL_TENSOR_DATA(v128);
        // pto: %241
        ;
        const int64_t v802 = 0;
        // pto: %241
        ;
        const int64_t v803 = 32768;
        // pto: %241
        ;
        pto::Shape<1, 1, 1, 8, 512> v804 = pto::Shape<1, 1, 1, 8, 512>();
        // pto: %241
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v805 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %241
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v806 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v801 + (v802 + v699 * v803 + v800), v804, v805);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
        TLOAD(v798, v806);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %q_head_scale_input_tail_inline8454__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v807 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %q_head_scale_input_tail_inline8454__ssa_v0
        ;
        uint64_t v808 = (uint64_t) v22;
        TASSIGN(v807, v808);
        // pto: %243
        ;
        __gm__ float* v809 = PTOAS__GLOBAL_TENSOR_DATA(v138);
        // pto: %243
        ;
        const int64_t v810 = 0;
        // pto: %243
        ;
        pto::Shape<1, 1, 1, 1, 512> v811 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %243
        ;
        pto::Stride<512, 512, 512, 512, 1> v812 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %243
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v813 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v809 + (v810 + v800), v811, v812);
        TLOAD(v807, v813);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %q_head_scale_tail_inline8453__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v814 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v55);
        // pto: %q_head_scale_tail_inline8453__ssa_v0
        ;
        uint64_t v815 = (uint64_t) v22;
        TASSIGN(v814, v815);
        // pto: %q_head_acc_fp32_tail_inline8487__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v816 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_acc_fp32_tail_inline8487__ssa_v0
        ;
        uint64_t v817 = (uint64_t) v21;
        TASSIGN(v816, v817);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        RoundMode v818 = RoundMode::CAST_NONE;
        SaturationMode v819 = SaturationMode::ON;
        TCVT(v816, v798, v818, v819);
        // pto: %t__tmp_v165
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v820 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %t__tmp_v165
        ;
        uint64_t v821 = (uint64_t) v23;
        TASSIGN(v820, v821);
        TEXPANDS(v820, v66);
        // pto: %t__tmp_v166
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v822 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %t__tmp_v166
        ;
        uint64_t v823 = (uint64_t) v23;
        TASSIGN(v822, v823);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v822, v820, v697);
        // pto: %q_head_scale_combined_tail_inline8452__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v824 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_scale_combined_tail_inline8452__ssa_v0
        ;
        uint64_t v825 = (uint64_t) v23;
        TASSIGN(v824, v825);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        TCOLEXPANDMUL(v824, v822, v814);
        // pto: %q_head_dq_tail_inline8468__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v826 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_dq_tail_inline8468__ssa_v0
        ;
        uint64_t v827 = (uint64_t) v21;
        TASSIGN(v826, v827);
        pipe_barrier(PIPE_V);
        TMUL(v826, v816, v824);
        // pto: %t__tmp_v167
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v828 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %t__tmp_v167
        ;
        uint64_t v829 = (uint64_t) v23;
        TASSIGN(v828, v829);
        pipe_barrier(PIPE_V);
        RoundMode v830 = RoundMode::CAST_RINT;
        SaturationMode v831 = SaturationMode::ON;
        TCVT(v828, v826, v830, v831);
        // pto: %q_head_dq_tail_v1_inline8450__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v832 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_dq_tail_v1_inline8450__ssa_v0
        ;
        uint64_t v833 = (uint64_t) v21;
        TASSIGN(v832, v833);
        pipe_barrier(PIPE_V);
        RoundMode v834 = RoundMode::CAST_ROUND;
        SaturationMode v835 = SaturationMode::ON;
        TCVT(v832, v828, v834, v835);
        // pto: %q_head_sq_tail_inline8524__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v836 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v55);
        // pto: %q_head_sq_tail_inline8524__ssa_v0
        ;
        uint64_t v837 = (uint64_t) v23;
        TASSIGN(v836, v837);
        pipe_barrier(PIPE_V);
        TMUL(v836, v832, v832);
        // pto: %t__tmp_v168
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v838 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v168
        ;
        uint64_t v839 = (uint64_t) v23;
        TASSIGN(v838, v839);
        // pto: %244
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v840;
        // pto: %244
        ;
        uint64_t v841 = (uint64_t) v23;
        TASSIGN(v840, v841);
        // pto: %t__tmp_v169
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v842 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v169
        ;
        uint64_t v843 = (uint64_t) v47;
        TASSIGN(v842, v843);
        // pto: %245
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v844;
        // pto: %245
        ;
        uint64_t v845 = (uint64_t) v47;
        TASSIGN(v844, v845);
        // pto: %q_sq_04_tail_inline8451__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v846 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_04_tail_inline8451__ssa_v0
        ;
        uint64_t v847 = (uint64_t) v22;
        TASSIGN(v846, v847);
        pipe_barrier(PIPE_V);
        TADD(v846, v840, v844);
        // pto: %t__tmp_v170
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v848 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v170
        ;
        uint64_t v849 = (uint64_t) v48;
        TASSIGN(v848, v849);
        // pto: %246
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v850;
        // pto: %246
        ;
        uint64_t v851 = (uint64_t) v48;
        TASSIGN(v850, v851);
        // pto: %t__tmp_v171
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v852 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v171
        ;
        uint64_t v853 = (uint64_t) v49;
        TASSIGN(v852, v853);
        // pto: %247
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v854;
        // pto: %247
        ;
        uint64_t v855 = (uint64_t) v49;
        TASSIGN(v854, v855);
        // pto: %q_sq_15_tail_inline8448__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v856 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_15_tail_inline8448__ssa_v0
        ;
        uint64_t v857 = (uint64_t) v24;
        TASSIGN(v856, v857);
        TADD(v856, v850, v854);
        // pto: %t__tmp_v172
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v858 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v172
        ;
        uint64_t v859 = (uint64_t) v50;
        TASSIGN(v858, v859);
        // pto: %248
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v860;
        // pto: %248
        ;
        uint64_t v861 = (uint64_t) v50;
        TASSIGN(v860, v861);
        // pto: %t__tmp_v173
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v862 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v173
        ;
        uint64_t v863 = (uint64_t) v51;
        TASSIGN(v862, v863);
        // pto: %249
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v864;
        // pto: %249
        ;
        uint64_t v865 = (uint64_t) v51;
        TASSIGN(v864, v865);
        // pto: %q_sq_26_tail_inline8471__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v866 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_26_tail_inline8471__ssa_v0
        ;
        uint64_t v867 = (uint64_t) v29;
        TASSIGN(v866, v867);
        TADD(v866, v860, v864);
        // pto: %t__tmp_v174
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v868 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v174
        ;
        uint64_t v869 = (uint64_t) v52;
        TASSIGN(v868, v869);
        // pto: %250
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v870;
        // pto: %250
        ;
        uint64_t v871 = (uint64_t) v52;
        TASSIGN(v870, v871);
        // pto: %t__tmp_v175
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v872 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v175
        ;
        uint64_t v873 = (uint64_t) v46;
        TASSIGN(v872, v873);
        // pto: %251
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v874;
        // pto: %251
        ;
        uint64_t v875 = (uint64_t) v46;
        TASSIGN(v874, v875);
        // pto: %q_sq_37_tail_inline8466__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v876 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_37_tail_inline8466__ssa_v0
        ;
        uint64_t v877 = (uint64_t) v23;
        TASSIGN(v876, v877);
        pipe_barrier(PIPE_V);
        TADD(v876, v870, v874);
        // pto: %q_sq_0246_tail_inline8447__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v878 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_0246_tail_inline8447__ssa_v0
        ;
        uint64_t v879 = (uint64_t) v22;
        TASSIGN(v878, v879);
        TADD(v878, v846, v866);
        // pto: %q_sq_1357_tail_inline8496__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v880 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_1357_tail_inline8496__ssa_v0
        ;
        uint64_t v881 = (uint64_t) v23;
        TASSIGN(v880, v881);
        pipe_barrier(PIPE_V);
        TADD(v880, v856, v876);
        // pto: %q_sq_64_tail_inline8446__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v882 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_sq_64_tail_inline8446__ssa_v0
        ;
        uint64_t v883 = (uint64_t) v23;
        TASSIGN(v882, v883);
        pipe_barrier(PIPE_V);
        TADD(v882, v878, v880);
        // pto: %q_head_sq_sum_tail_inline8490__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v884 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %q_head_sq_sum_tail_inline8490__ssa_v0
        ;
        uint64_t v885 = (uint64_t) v22;
        TASSIGN(v884, v885);
        pipe_barrier(PIPE_V);
        TROWSUM(v884, v882, v790);
        // pto: %t__rm_a0_tmp_v0
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v886 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %t__rm_a0_tmp_v0
        ;
        uint64_t v887 = (uint64_t) v22;
        TASSIGN(v886, v887);
        // pto: %t__row_major_tmp_v1
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v888 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %t__row_major_tmp_v1
        ;
        uint64_t v889 = (uint64_t) v23;
        TASSIGN(v888, v889);
        pipe_barrier(PIPE_V);
        TMULS(v888, v886, v70);
        // pto: %t__tmp_v176
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v890 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %t__tmp_v176
        ;
        uint64_t v891 = (uint64_t) v23;
        TASSIGN(v890, v891);
        // pto: %q_head_var_tail_inline8445__rm_a0_tmp_v2
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v892 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_var_tail_inline8445__rm_a0_tmp_v2
        ;
        uint64_t v893 = (uint64_t) v23;
        TASSIGN(v892, v893);
        // pto: %q_head_var_tail_inline8445__row_major_tmp_v3
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v894 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_var_tail_inline8445__row_major_tmp_v3
        ;
        uint64_t v895 = (uint64_t) v23;
        TASSIGN(v894, v895);
        pipe_barrier(PIPE_V);
        TADDS(v894, v892, v71);
        // pto: %q_head_var_tail_inline8445__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v896 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %q_head_var_tail_inline8445__ssa_v0
        ;
        uint64_t v897 = (uint64_t) v23;
        TASSIGN(v896, v897);
        // pto: %q_head_inv_rms_tail_inline8444__rm_a0_tmp_v4
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v898 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_inv_rms_tail_inline8444__rm_a0_tmp_v4
        ;
        uint64_t v899 = (uint64_t) v23;
        TASSIGN(v898, v899);
        // pto: %q_head_inv_rms_tail_inline8444__rm_a1_tmp_v5
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v900 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_inv_rms_tail_inline8444__rm_a1_tmp_v5
        ;
        uint64_t v901 = (uint64_t) v40;
        TASSIGN(v900, v901);
        // pto: %q_head_inv_rms_tail_inline8444__row_major_tmp_v6
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v902 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v54, v63);
        // pto: %q_head_inv_rms_tail_inline8444__row_major_tmp_v6
        ;
        uint64_t v903 = (uint64_t) v22;
        TASSIGN(v902, v903);
        pipe_barrier(PIPE_V);
        TRSQRT(v902, v898, v900);
        // pto: %q_head_inv_rms_tail_inline8444__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v904 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v54);
        // pto: %q_head_inv_rms_tail_inline8444__ssa_v0
        ;
        uint64_t v905 = (uint64_t) v22;
        TASSIGN(v904, v905);
        // pto: %t__tmp_v177
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v906 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %t__tmp_v177
        ;
        uint64_t v907 = (uint64_t) v21;
        TASSIGN(v906, v907);
        // pto: %252
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v908;
        // pto: %252
        ;
        uint64_t v909 = (uint64_t) v21;
        TASSIGN(v908, v909);
        // pto: %q_nope_normed_tail_inline8478__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v910 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %q_nope_normed_tail_inline8478__ssa_v0
        ;
        uint64_t v911 = (uint64_t) v23;
        TASSIGN(v910, v911);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v910, v908, v904);
        // pto: %q_nope_bf16_tail_inline8443__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v912 = Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v69);
        // pto: %q_nope_bf16_tail_inline8443__ssa_v0
        ;
        uint64_t v913 = (uint64_t) v23;
        TASSIGN(v912, v913);
        pipe_barrier(PIPE_V);
        RoundMode v914 = RoundMode::CAST_RINT;
        SaturationMode v915 = SaturationMode::ON;
        TCVT(v912, v910, v914, v915);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        v912.SetValidShape(v696, v69);
        // pto: %q_flat_inline8482__iter_v1_pview
        ;
        const int64_t v916 = 0;
        // pto: %q_flat_inline8482__iter_v1_pview
        ;
        __gm__ bfloat16_t* v917 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %q_flat_inline8482__iter_v1_pview
        ;
        const int64_t v918 = 1;
        // pto: %q_flat_inline8482__iter_v1_pview
        ;
        const int64_t v919 = 1;
        // pto: %q_flat_inline8482__iter_v1_pview
        ;
        const int64_t v920 = 1;
        // pto: %q_flat_inline8482__iter_v1_pview
        ;
        int64_t v921 = v696 * v53;
        // pto: %q_flat_inline8482__iter_v1_pview
        ;
        int64_t v922 = v920 * v921;
        // pto: %q_flat_inline8482__iter_v1_pview
        ;
        pto::Shape<1, 1, 1, -1, 448> v923 = pto::Shape<1, 1, 1, -1, 448>(v918, v919, v920, v696, v69);
        // pto: %q_flat_inline8482__iter_v1_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v924 = pto::Stride<-1, -1, -1, -1, -1>(v919 * v922, v922, v921, v53, v54);
        // pto: %q_flat_inline8482__iter_v1_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 448>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v925 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 448>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v917 + (v916 + v707 * v53 + v800 * v54), v923, v924);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
        TSTORE(v925, v912);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
        // pto: %q_rope_chunk_raw_tail_inline8442__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v926 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_chunk_raw_tail_inline8442__ssa_v0
        ;
        uint64_t v927 = (uint64_t) v35;
        TASSIGN(v926, v927);
        // pto: %255
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v928;
        // pto: %255
        ;
        uint64_t v929 = (uint64_t) v35;
        TASSIGN(v928, v929);
        // pto: %q_rope_chunk_tail_inline8441__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v930 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_chunk_tail_inline8441__ssa_v0
        ;
        uint64_t v931 = (uint64_t) v21;
        TASSIGN(v930, v931);
        TROWEXPANDMUL(v930, v928, v904);
        // pto: %t__tmp_v178
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v932 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %t__tmp_v178
        ;
        uint64_t v933 = (uint64_t) v23;
        TASSIGN(v932, v933);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
        RoundMode v934 = RoundMode::CAST_RINT;
        SaturationMode v935 = SaturationMode::ON;
        TCVT(v932, v930, v934, v935);
        // pto: %q_rope_chunk_tail_v1_inline8509__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v936 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_chunk_tail_v1_inline8509__ssa_v0
        ;
        uint64_t v937 = (uint64_t) v21;
        TASSIGN(v936, v937);
        pipe_barrier(PIPE_V);
        RoundMode v938 = RoundMode::CAST_ROUND;
        SaturationMode v939 = SaturationMode::ON;
        TCVT(v936, v932, v938, v939);
        // pto: %q_rope_swapped_tail_inline8508__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v940 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v63, v56);
        // pto: %q_rope_swapped_tail_inline8508__ssa_v0
        ;
        uint64_t v941 = (uint64_t) v23;
        TASSIGN(v940, v941);
        pipe_barrier(PIPE_V);
        TGATHER(v940, v936, v786, v794);
        v936.SetValidShape(v696, v56);
        v940.SetValidShape(v696, v56);
        // pto: %q_rope_base_tail_inline8439__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v942 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v696, v56);
        // pto: %q_rope_base_tail_inline8439__ssa_v0
        ;
        uint64_t v943 = (uint64_t) v21;
        TASSIGN(v942, v943);
        pipe_barrier(PIPE_V);
        TMUL(v942, v936, v705);
        // pto: %q_rope_delta_tail_inline8438__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v944 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v696, v56);
        // pto: %q_rope_delta_tail_inline8438__ssa_v0
        ;
        uint64_t v945 = (uint64_t) v23;
        TASSIGN(v944, v945);
        TMUL(v944, v940, v718);
        // pto: %q_rope_rot_tail_inline8477__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v946 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v696, v56);
        // pto: %q_rope_rot_tail_inline8477__ssa_v0
        ;
        uint64_t v947 = (uint64_t) v21;
        TASSIGN(v946, v947);
        pipe_barrier(PIPE_V);
        TADD(v946, v942, v944);
        // pto: %q_rope_bf16_tail_inline8437__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v948 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v696, v56);
        // pto: %q_rope_bf16_tail_inline8437__ssa_v0
        ;
        uint64_t v949 = (uint64_t) v21;
        TASSIGN(v948, v949);
        pipe_barrier(PIPE_V);
        RoundMode v950 = RoundMode::CAST_RINT;
        SaturationMode v951 = SaturationMode::ON;
        TCVT(v948, v946, v950, v951);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        v948.SetValidShape(v696, v56);
        // pto: %257
        ;
        int64_t v952 = (int64_t) ((uint64_t) v797 + (uint64_t) v69);
        // pto: %258
        ;
        int64_t v953 = v952 < v58 ? v58 : v952;
        // pto: %259
        ;
        const int64_t v954 = 0;
        // pto: %259
        ;
        __gm__ bfloat16_t* v955 = PTOAS__GLOBAL_TENSOR_DATA(v84);
        // pto: %259
        ;
        const int64_t v956 = 1;
        // pto: %259
        ;
        const int64_t v957 = 1;
        // pto: %259
        ;
        const int64_t v958 = 1;
        // pto: %259
        ;
        int64_t v959 = v696 * v53;
        // pto: %259
        ;
        int64_t v960 = v958 * v959;
        // pto: %259
        ;
        pto::Shape<1, 1, 1, -1, 64> v961 = pto::Shape<1, 1, 1, -1, 64>(v956, v957, v958, v696, v56);
        // pto: %259
        ;
        pto::Stride<-1, -1, -1, -1, -1> v962 = pto::Stride<-1, -1, -1, -1, -1>(v957 * v960, v960, v959, v53, v54);
        // pto: %259
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v963 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v955 + (v954 + v707 * v53 + v953 * v54), v961, v962);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        TSTORE(v963, v948);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
    };
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}