#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void rope_cs(__gm__ float* v1, __gm__ float* v2, int64_t v3, int64_t v4, int64_t v5, int32_t v6, int32_t v7) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v8 = 0;
  // pto: %c1792_i64
  const int64_t v9 = 1792;
  // pto: %c1536_i64
  const int64_t v10 = 1536;
  // pto: %c64_index
  const int64_t v11 = 64;
  // pto: %c1_index
  const int64_t v12 = 1;
  // pto: %c384_index
  const int64_t v13 = 384;
  // pto: %c16_index
  const int64_t v14 = 16;
  // pto: %c6_index
  const int64_t v15 = 6;
  // pto: %cst_8
  const float v16 = 1.0f;
  // pto: %c192_index
  const int64_t v17 = 192;
  // pto: %c0_i32
  const int32_t v18 = 0;
  // pto: %cst_11
  const float v19 = 0.5f;
  // pto: %cst_12
  const float v20 = 2.0f;
  // pto: %c0_index
  const int64_t v21 = 0;
  // pto: %freqs_sin__ssa_v0_view
  const int64_t v22 = 1;
  // pto: %freqs_sin__ssa_v0_view
  const int64_t v23 = 1;
  // pto: %freqs_sin__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %freqs_sin__ssa_v0_view
  int64_t v25 = (int64_t) v5;
  // pto: %freqs_sin__ssa_v0_view
  int64_t v26 = v25 * v11;
  // pto: %freqs_sin__ssa_v0_view
  int64_t v27 = v24 * v26;
  // pto: %freqs_sin__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v28 = pto::Shape<1, 1, 1, -1, -1>(v22, v23, v24, v25, v11);
  // pto: %freqs_sin__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v29 = pto::Stride<-1, -1, -1, -1, -1>(v23 * v27, v27, v26, v11, v12);
  // pto: %freqs_sin__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v30 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v28, v29);
  // pto: %rope_sin_signed_inline5877__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %rope_sin_signed_inline5877__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %rope_sin_signed_inline5877__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %rope_sin_signed_inline5877__ssa_v0_view
  int64_t v34 = v13 * v11;
  // pto: %rope_sin_signed_inline5877__ssa_v0_view
  int64_t v35 = v33 * v34;
  // pto: %rope_sin_signed_inline5877__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v36 = pto::Shape<1, 1, 1, -1, -1>(v31, v32, v33, v13, v11);
  // pto: %rope_sin_signed_inline5877__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v37 = pto::Stride<-1, -1, -1, -1, -1>(v32 * v35, v35, v34, v11, v12);
  // pto: %rope_sin_signed_inline5877__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v38 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v36, v37);
  // pto: %t__tmp_v1028
  // pto: %0
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t v39 = (int64_t) v6; v39 < v3; v39 += v3 < v14 ? v3 : v14) {
    // pto: %1
    ;
    int64_t v40 = (int64_t) ((uint64_t) v39 * (uint64_t) v15);
    // pto: %2
    ;
    int64_t v41 = (int64_t) ((uint64_t) v4 - (uint64_t) v40);
    // pto: %3
    ;
    int64_t v42 = v41 < v15 ? v41 : v15;
    // pto: %cs_ones_inline5748__ssa_v0
    ;
    Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v43 = Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %cs_ones_inline5748__ssa_v0
    ;
    uint64_t v44 = (uint64_t) v8;
    TASSIGN(v43, v44);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    TEXPANDS(v43, v16);
    // pto: %t__ci_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v45 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v17);
    // pto: %t__ci_tmp_v0
    ;
    uint64_t v46 = (uint64_t) v9;
    TASSIGN(v45, v46);
    // pto: %t__tmp_v1029
    ;
    Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v47 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v11);
    // pto: %t__tmp_v1029
    ;
    uint64_t v48 = (uint64_t) v10;
    TASSIGN(v47, v48);
    // pto: %ci_tmp_view
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v49;
    TRESHAPE(v49, v45);
    // pto: %ci_dst_view
    ;
    Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v50;
    TRESHAPE(v50, v47);
    TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v50, v18, v49);
    // pto: %cs_idx_f_inline5821__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v51 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v12, v11);
    // pto: %cs_idx_f_inline5821__ssa_v0
    ;
    uint64_t v52 = (uint64_t) v9;
    TASSIGN(v51, v52);
    pipe_barrier(PIPE_V);
    RoundMode v53 = RoundMode::CAST_ROUND;
    SaturationMode v54 = SaturationMode::ON;
    TCVT(v51, v47, v53, v54);
    // pto: %cs_col_inline5866__ssa_v0
    ;
    Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v55 = Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %cs_col_inline5866__ssa_v0
    ;
    uint64_t v56 = (uint64_t) v8;
    TASSIGN(v55, v56);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v55, v43, v51);
    // pto: %t__tmp_v1030
    ;
    Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v57 = Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %t__tmp_v1030
    ;
    uint64_t v58 = (uint64_t) v9;
    TASSIGN(v57, v58);
    pipe_barrier(PIPE_V);
    TMULS(v57, v55, v19);
    // pto: %cs_dup_i32_inline5859__ssa_v0
    ;
    Tile<TileType::Vec, int32_t, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v59 = Tile<TileType::Vec, int32_t, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %cs_dup_i32_inline5859__ssa_v0
    ;
    uint64_t v60 = (uint64_t) v9;
    TASSIGN(v59, v60);
    pipe_barrier(PIPE_V);
    RoundMode v61 = RoundMode::CAST_TRUNC;
    SaturationMode v62 = SaturationMode::ON;
    TCVT(v59, v57, v61, v62);
    // pto: %cs_dup_f_inline5848__ssa_v0
    ;
    Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v63 = Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %cs_dup_f_inline5848__ssa_v0
    ;
    uint64_t v64 = (uint64_t) v9;
    TASSIGN(v63, v64);
    pipe_barrier(PIPE_V);
    RoundMode v65 = RoundMode::CAST_ROUND;
    SaturationMode v66 = SaturationMode::ON;
    TCVT(v63, v59, v65, v66);
    // pto: %t__tmp_v1031
    ;
    Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v67 = Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %t__tmp_v1031
    ;
    uint64_t v68 = (uint64_t) v9;
    TASSIGN(v67, v68);
    pipe_barrier(PIPE_V);
    TMULS(v67, v63, v20);
    // pto: %cs_lane_inline5826__ssa_v0
    ;
    Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v69 = Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %cs_lane_inline5826__ssa_v0
    ;
    uint64_t v70 = (uint64_t) v8;
    TASSIGN(v69, v70);
    pipe_barrier(PIPE_V);
    TSUB(v69, v55, v67);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %t__tmp_v1032
    ;
    Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v71 = Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %t__tmp_v1032
    ;
    uint64_t v72 = (uint64_t) v8;
    TASSIGN(v71, v72);
    pipe_barrier(PIPE_V);
    TMULS(v71, v69, v20);
    // pto: %t__tmp_v1033
    ;
    Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v73 = Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %t__tmp_v1033
    ;
    uint64_t v74 = (uint64_t) v8;
    TASSIGN(v73, v74);
    pipe_barrier(PIPE_V);
    TSUBS(v73, v71, v16);
    // pto: %cs_sign_inline5812__ssa_v0
    ;
    Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v15, v11);
    // pto: %cs_sign_inline5812__ssa_v0
    ;
    uint64_t v76 = (uint64_t) v8;
    TASSIGN(v75, v76);
    pipe_barrier(PIPE_V);
    TNEG(v75, v73);
    // pto: %cs_sin_inline5906__ssa_v0
    ;
    Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v77 = Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v42, v11);
    // pto: %cs_sin_inline5906__ssa_v0
    ;
    uint64_t v78 = (uint64_t) v9;
    TASSIGN(v77, v78);
    // pto: %4
    ;
    int64_t v79 = v40 < v21 ? v21 : v40;
    // pto: %freqs_sin__ssa_v0_pview
    ;
    const int64_t v80 = 0;
    // pto: %freqs_sin__ssa_v0_pview
    ;
    __gm__ float* v81 = PTOAS__GLOBAL_TENSOR_DATA(v30);
    // pto: %freqs_sin__ssa_v0_pview
    ;
    const int64_t v82 = 1;
    // pto: %freqs_sin__ssa_v0_pview
    ;
    const int64_t v83 = 1;
    // pto: %freqs_sin__ssa_v0_pview
    ;
    const int64_t v84 = 1;
    // pto: %freqs_sin__ssa_v0_pview
    ;
    int64_t v85 = v42 * v11;
    // pto: %freqs_sin__ssa_v0_pview
    ;
    int64_t v86 = v84 * v85;
    // pto: %freqs_sin__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v87 = pto::Shape<1, 1, 1, -1, 64>(v82, v83, v84, v42, v11);
    // pto: %freqs_sin__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v88 = pto::Stride<-1, -1, -1, -1, -1>(v83 * v86, v86, v85, v11, v12);
    // pto: %freqs_sin__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v89 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v81 + (v80 + v79 * v11 + v21 * v12), v87, v88);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v77, v89);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    v75.SetValidShape(v42, v11);
    // pto: %t__tmp_v1034
    ;
    Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Vec, float, 6, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v42, v11);
    // pto: %t__tmp_v1034
    ;
    uint64_t v91 = (uint64_t) v8;
    TASSIGN(v90, v91);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    TMUL(v90, v77, v75);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %rope_sin_signed_inline5877__ssa_v0_pview
    ;
    const int64_t v92 = 0;
    // pto: %rope_sin_signed_inline5877__ssa_v0_pview
    ;
    __gm__ float* v93 = PTOAS__GLOBAL_TENSOR_DATA(v38);
    // pto: %rope_sin_signed_inline5877__ssa_v0_pview
    ;
    const int64_t v94 = 1;
    // pto: %rope_sin_signed_inline5877__ssa_v0_pview
    ;
    const int64_t v95 = 1;
    // pto: %rope_sin_signed_inline5877__ssa_v0_pview
    ;
    const int64_t v96 = 1;
    // pto: %rope_sin_signed_inline5877__ssa_v0_pview
    ;
    int64_t v97 = v42 * v11;
    // pto: %rope_sin_signed_inline5877__ssa_v0_pview
    ;
    int64_t v98 = v96 * v97;
    // pto: %rope_sin_signed_inline5877__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v99 = pto::Shape<1, 1, 1, -1, 64>(v94, v95, v96, v42, v11);
    // pto: %rope_sin_signed_inline5877__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v100 = pto::Stride<-1, -1, -1, -1, -1>(v95 * v98, v98, v97, v11, v12);
    // pto: %rope_sin_signed_inline5877__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v101 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v93 + (v92 + v79 * v11 + v21 * v12), v99, v100);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v101, v90);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}