#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void native_heads(__gm__ bfloat16_t* v1, __gm__ bfloat16_t* v2, int64_t v3, int64_t v4, int32_t v5, int32_t v6) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v7 = 0;
  // pto: %c3072_index
  const int64_t v8 = 3072;
  // pto: %c4096_index
  const int64_t v9 = 4096;
  // pto: %c1_index
  const int64_t v10 = 1;
  // pto: %c32768_index
  const int64_t v11 = 32768;
  // pto: %c48_index
  const int64_t v12 = 48;
  // pto: %c0_index
  const int64_t v13 = 0;
  // pto: %c8_index
  const int64_t v14 = 8;
  // pto: %c384_index
  const int64_t v15 = 384;
  // pto: %o_packed_heads__ssa_v1_view
  const int64_t v16 = 1;
  // pto: %o_packed_heads__ssa_v1_view
  const int64_t v17 = 1;
  // pto: %o_packed_heads__ssa_v1_view
  const int64_t v18 = 1;
  // pto: %o_packed_heads__ssa_v1_view
  int64_t v19 = v8 * v9;
  // pto: %o_packed_heads__ssa_v1_view
  int64_t v20 = v18 * v19;
  // pto: %o_packed_heads__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v21 = pto::Shape<1, 1, 1, -1, -1>(v16, v17, v18, v8, v9);
  // pto: %o_packed_heads__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v22 = pto::Stride<-1, -1, -1, -1, -1>(v17 * v20, v20, v19, v9, v10);
  // pto: %o_packed_heads__ssa_v1_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v23 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v21, v22);
  // pto: %heads__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v27 = (int64_t) v4;
  // pto: %heads__ssa_v0_view
  int64_t v28 = v27 * v11;
  // pto: %heads__ssa_v0_view
  int64_t v29 = v26 * v28;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v30 = pto::Shape<1, 1, 1, -1, -1>(v24, v25, v26, v27, v11);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v31 = pto::Stride<-1, -1, -1, -1, -1>(v25 * v29, v29, v28, v11, v10);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v32 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v30, v31);
  // pto: %worker_inline1409__ssa_v0
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v33 = (int64_t) v5; v33 < v4; v33 += v12) {
    for (int64_t v34 = v13; v34 < v14; v34 += v10) {
      // pto: %value_inline1408__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v35 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v10, v9);
      // pto: %value_inline1408__ssa_v0
      ;
      uint64_t v36 = (uint64_t) v7;
      TASSIGN(v35, v36);
      // pto: %0, %1
      ;
      int64_t v37 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v34 * (uint64_t) v15) + (uint64_t) v33);
      // pto: %2
      ;
      int64_t v38 = v37 < v13 ? v13 : v37;
      // pto: %o_packed_heads__ssa_v1_pview
      ;
      __gm__ bfloat16_t* v39 = PTOAS__GLOBAL_TENSOR_DATA(v23);
      // pto: %o_packed_heads__ssa_v1_pview
      ;
      const int64_t v40 = 0;
      // pto: %o_packed_heads__ssa_v1_pview
      ;
      const int64_t v41 = 4096;
      // pto: %o_packed_heads__ssa_v1_pview
      ;
      pto::Shape<1, 1, 1, 1, 4096> v42 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %o_packed_heads__ssa_v1_pview
      ;
      pto::Stride<4096, 4096, 4096, 4096, 1> v43 = pto::Stride<4096, 4096, 4096, 4096, 1>();
      // pto: %o_packed_heads__ssa_v1_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v44 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v39 + (v40 + v38 * v41), v42, v43);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      TLOAD(v35, v44);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
      // pto: %3
      ;
      int64_t v45 = v33 < v13 ? v13 : v33;
      // pto: %4
      ;
      int64_t v46 = (int64_t) ((uint64_t) v34 * (uint64_t) v9);
      // pto: %5
      ;
      int64_t v47 = v46 < v13 ? v13 : v46;
      // pto: %heads__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v48 = PTOAS__GLOBAL_TENSOR_DATA(v32);
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v49 = 0;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v50 = 32768;
      // pto: %heads__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 4096> v51 = pto::Shape<1, 1, 1, 1, 4096>();
      // pto: %heads__ssa_v0_pview
      ;
      pto::Stride<32768, 32768, 32768, 32768, 1> v52 = pto::Stride<32768, 32768, 32768, 32768, 1>();
      // pto: %heads__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<32768, 32768, 32768, 32768, 1>, pto::Layout::ND> v53 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<32768, 32768, 32768, 32768, 1>, pto::Layout::ND>(v48 + (v49 + v45 * v50 + v47), v51, v52);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
      TSTORE(v53, v35);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}