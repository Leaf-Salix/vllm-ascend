#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_a_0(__gm__ float* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int64_t v9, int32_t v10, int32_t v11) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c196608_i64
  const int64_t v12 = 196608;
  // pto: %c0_i64
  const int64_t v13 = 0;
  // pto: %c32768_i64
  const int64_t v14 = 32768;
  // pto: %c65536_i64
  const int64_t v15 = 65536;
  // pto: %c131072_i64
  const int64_t v16 = 131072;
  // pto: %c8192_index
  const int64_t v17 = 8192;
  // pto: %c1_index
  const int64_t v18 = 1;
  // pto: %c16_index
  const int64_t v19 = 16;
  // pto: %c8_index
  const int64_t v20 = 8;
  // pto: %c32768_index
  const int64_t v21 = 32768;
  const int64_t v22 = 64;
  // pto: %c256_index
  const int64_t v23 = 256;
  // pto: %c4194304_index
  const int64_t v24 = 4194304;
  // pto: %c65536_index
  const int64_t v25 = 65536;
  const int64_t v26 = 128;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %c7_index
  const int64_t v28 = 7;
  // pto: %c2_index
  const int64_t v29 = 2;
  // pto: %c3_index
  const int64_t v30 = 3;
  // pto: %c4_index
  const int64_t v31 = 4;
  // pto: %c5_index
  const int64_t v32 = 5;
  // pto: %c6_index
  const int64_t v33 = 6;
  // pto: %c4096_index
  const int64_t v34 = 4096;
  // pto: %c14_index
  const int64_t v35 = 14;
  // pto: %c240_index
  const int64_t v36 = 240;
  // pto: %c225_index
  const int64_t v37 = 225;
  // pto: %c241_index
  const int64_t v38 = 241;
  // pto: %c1024_index
  const int64_t v39 = 1024;
  // pto: %c127_index
  const int64_t v40 = 127;
  // pto: %307
  int64_t v41 = (int64_t) ((uint64_t) v8 + (uint64_t) v40);
  // pto: %accum_inline1531__iter_v11_view
  const int64_t v42 = 1;
  // pto: %accum_inline1531__iter_v11_view
  const int64_t v43 = 1;
  // pto: %accum_inline1531__iter_v11_view
  const int64_t v44 = 1;
  // pto: %accum_inline1531__iter_v11_view
  int64_t v45 = v41 * v17;
  // pto: %accum_inline1531__iter_v11_view
  int64_t v46 = v44 * v45;
  // pto: %accum_inline1531__iter_v11_view
  pto::Shape<1, 1, 1, -1, -1> v47 = pto::Shape<1, 1, 1, -1, -1>(v42, v43, v44, v41, v17);
  // pto: %accum_inline1531__iter_v11_view
  pto::Stride<-1, -1, -1, -1, -1> v48 = pto::Stride<-1, -1, -1, -1, -1>(v43 * v46, v46, v45, v17, v18);
  // pto: %accum_inline1531__iter_v11_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v49 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v47, v48);
  // pto: %heads__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v52 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v53 = (int64_t) v9;
  // pto: %heads__ssa_v0_view
  int64_t v54 = v53 * v21;
  // pto: %heads__ssa_v0_view
  int64_t v55 = v52 * v54;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v56 = pto::Shape<1, 1, 1, -1, -1>(v50, v51, v52, v53, v21);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v57 = pto::Stride<-1, -1, -1, -1, -1>(v51 * v55, v55, v54, v21, v18);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v58 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v56, v57);
  // pto: %wo_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v59 = pto::Shape<-1, -1, -1, -1, -1>(v20, v22, v23, v19, v19);
  // pto: %wo_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v60 = pto::Stride<-1, -1, -1, -1, -1>(v24, v25, v23, v19, v18);
  // pto: %wo_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v61 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v4, v59, v60);
  // pto: %v4_wide_acc_inline1421__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v62 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
  // pto: %v4_wide_acc_inline1421__phi_v7
  uint64_t v63 = (uint64_t) v13;
  TASSIGN(v62, v63);
  // pto: %178
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v64 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
  // pto: %178
  uint64_t v65 = (uint64_t) v13;
  TASSIGN(v64, v65);
  // pto: %210
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v66 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
  // pto: %210
  uint64_t v67 = (uint64_t) v13;
  TASSIGN(v66, v67);
  // pto: %v4_narrow_acc_inline1491__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v68 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v19, v26);
  // pto: %v4_narrow_acc_inline1491__phi_v7
  uint64_t v69 = (uint64_t) v13;
  TASSIGN(v68, v69);
  // pto: %v4_block_inline1465__ssa_v0
  int64_t v70 = (int64_t) v10;
  // pto: %38
  int64_t v71 = (int64_t) ((uint64_t) v70 * (uint64_t) v26);
  // pto: %39, %40
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  for (int64_t v72 = v27; v72 < ((int64_t) ((uint64_t) v5 + (uint64_t) v28) / v20); v72 += v18) {
    // pto: %41
    ;
    int64_t v73 = (int64_t) ((uint64_t) v72 * (uint64_t) v20);
    // pto: %flat_offset, %42, %43, %t__tile
    ;
    int32_t v74 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v72 * (uint64_t) v22) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
    // pto: %44
    ;
    int64_t v75 = (int64_t) v74;
    // pto: %45
    ;
    int64_t v76 = v75 < v27 ? v27 : v75;
    // pto: %46
    ;
    int64_t v77 = (int64_t) ((uint64_t) v73 + (uint64_t) v18);
    // pto: %47
    ;
    // pto: %v4_same_start_inline1426__phi_v3
    ;
    int64_t v78;
    if (v77 < v5) {
      // pto: %50, %51, %52, %53, %48
      ;
      int32_t v79 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v77 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %54
      ;
      int64_t v80 = (int64_t) v79;
      // pto: %55
      ;
      int64_t v81 = v80 < v27 ? v27 : v80;
      // pto: %56, %v4_same_start_inline1426__phi_v2
      ;
      v78 = v81 != v76 ? v27 : v18;
    } else {
      v78 = v18;
    };
    // pto: %57
    ;
    int64_t v82 = (int64_t) ((uint64_t) v73 + (uint64_t) v29);
    // pto: %58
    ;
    // pto: %v4_same_start_inline1426__phi_v6
    ;
    int64_t v83;
    if (v82 < v5) {
      // pto: %61, %62, %63, %64, %59
      ;
      int32_t v84 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v82 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %65
      ;
      int64_t v85 = (int64_t) v84;
      // pto: %66
      ;
      int64_t v86 = v85 < v27 ? v27 : v85;
      // pto: %67, %v4_same_start_inline1426__phi_v5
      ;
      int64_t v87 = v86 != v76 ? v27 : v78;
      v83 = v87;
    } else {
      v83 = v78;
    };
    // pto: %68
    ;
    int64_t v88 = (int64_t) ((uint64_t) v73 + (uint64_t) v30);
    // pto: %69
    ;
    // pto: %v4_same_start_inline1426__phi_v9
    ;
    int64_t v89;
    if (v88 < v5) {
      // pto: %72, %73, %74, %75, %70
      ;
      int32_t v90 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v88 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %76
      ;
      int64_t v91 = (int64_t) v90;
      // pto: %77
      ;
      int64_t v92 = v91 < v27 ? v27 : v91;
      // pto: %78, %v4_same_start_inline1426__phi_v8
      ;
      int64_t v93 = v92 != v76 ? v27 : v83;
      v89 = v93;
    } else {
      v89 = v83;
    };
    // pto: %79
    ;
    int64_t v94 = (int64_t) ((uint64_t) v73 + (uint64_t) v31);
    // pto: %80
    ;
    // pto: %v4_same_start_inline1426__phi_v12
    ;
    int64_t v95;
    if (v94 < v5) {
      // pto: %83, %84, %85, %86, %81
      ;
      int32_t v96 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v94 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %87
      ;
      int64_t v97 = (int64_t) v96;
      // pto: %88
      ;
      int64_t v98 = v97 < v27 ? v27 : v97;
      // pto: %89, %v4_same_start_inline1426__phi_v11
      ;
      int64_t v99 = v98 != v76 ? v27 : v89;
      v95 = v99;
    } else {
      v95 = v89;
    };
    // pto: %90
    ;
    int64_t v100 = (int64_t) ((uint64_t) v73 + (uint64_t) v32);
    // pto: %91
    ;
    // pto: %v4_same_start_inline1426__phi_v15
    ;
    int64_t v101;
    if (v100 < v5) {
      // pto: %94, %95, %96, %97, %92
      ;
      int32_t v102 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v100 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %98
      ;
      int64_t v103 = (int64_t) v102;
      // pto: %99
      ;
      int64_t v104 = v103 < v27 ? v27 : v103;
      // pto: %100, %v4_same_start_inline1426__phi_v14
      ;
      int64_t v105 = v104 != v76 ? v27 : v95;
      v101 = v105;
    } else {
      v101 = v95;
    };
    // pto: %101
    ;
    int64_t v106 = (int64_t) ((uint64_t) v73 + (uint64_t) v33);
    // pto: %102
    ;
    // pto: %v4_same_start_inline1426__phi_v18
    ;
    int64_t v107;
    if (v106 < v5) {
      // pto: %105, %106, %107, %108, %103
      ;
      int32_t v108 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %109
      ;
      int64_t v109 = (int64_t) v108;
      // pto: %110
      ;
      int64_t v110 = v109 < v27 ? v27 : v109;
      // pto: %111, %v4_same_start_inline1426__phi_v17
      ;
      int64_t v111 = v110 != v76 ? v27 : v101;
      v107 = v111;
    } else {
      v107 = v101;
    };
    // pto: %112
    ;
    int64_t v112 = (int64_t) ((uint64_t) v73 + (uint64_t) v28);
    // pto: %113
    ;
    // pto: %v4_same_start_inline1426__phi_v21
    ;
    int64_t v113;
    if (v112 < v5) {
      // pto: %116, %117, %118, %119, %114
      ;
      int32_t v114 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v112 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
      // pto: %120
      ;
      int64_t v115 = (int64_t) v114;
      // pto: %121
      ;
      int64_t v116 = v115 < v27 ? v27 : v115;
      // pto: %122, %v4_same_start_inline1426__phi_v20
      ;
      int64_t v117 = v116 != v76 ? v27 : v107;
      v113 = v117;
    } else {
      v113 = v107;
    };
    // pto: %123, %v4_same_start_inline1426__phi_v23
    ;
    int64_t v118 = v8 <= v19 ? v27 : v113;
    // pto: %124
    ;
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    if (v118 == v18) {
      int64_t v119 = (int64_t) ((uint64_t) v72 * (uint64_t) v26);
      // pto: %126
      ;
      int64_t v120 = (int64_t) ((uint64_t) v8 - (uint64_t) v119);
      // pto: %127
      ;
      int64_t v121 = v120 < v26 ? v120 : v26;
      // pto: %128, %129
      ;
      int64_t v122 = (int64_t) ((uint64_t) (v76 % v23) * (uint64_t) v19);
      // pto: %v4_wide_seed_x_inline1422__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v123 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v121, v19);
      // pto: %v4_wide_seed_x_inline1422__tile
      ;
      uint64_t v124 = (uint64_t) v12;
      TASSIGN(v123, v124);
      // pto: %130
      ;
      int64_t v125 = v119 < v27 ? v27 : v119;
      // pto: %131
      ;
      int64_t v126 = (int64_t) ((uint64_t) v6 * (uint64_t) v34);
      // pto: %132
      ;
      int64_t v127 = (int64_t) ((uint64_t) v126 + (uint64_t) v122);
      // pto: %133
      ;
      int64_t v128 = v127 < v27 ? v27 : v127;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v129 = 0;
      // pto: %heads__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v130 = PTOAS__GLOBAL_TENSOR_DATA(v58);
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v131 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v132 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v133 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      int64_t v134 = v121 * v21;
      // pto: %heads__ssa_v0_pview
      ;
      int64_t v135 = v133 * v134;
      // pto: %heads__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 16> v136 = pto::Shape<1, 1, 1, -1, 16>(v131, v132, v133, v121, v19);
      // pto: %heads__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v137 = pto::Stride<-1, -1, -1, -1, -1>(v132 * v135, v135, v134, v21, v18);
      // pto: %heads__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v138 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v130 + (v129 + v125 * v21 + v128 * v18), v136, v137);
      TLOAD(v123, v138);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %v4_wide_seed_w_inline1457__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v139 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
      // pto: %v4_wide_seed_w_inline1457__tile
      ;
      uint64_t v140 = (uint64_t) v13;
      TASSIGN(v139, v140);
      // pto: %134
      ;
      int64_t v141 = v6 < v27 ? v27 : v6;
      // pto: %135
      ;
      int64_t v142 = v71 / v19;
      // pto: %136
      ;
      int64_t v143 = v142 < v27 ? v27 : v142;
      // pto: %137
      ;
      int64_t v144 = v122 / v19;
      // pto: %138
      ;
      int64_t v145 = v144 < v27 ? v27 : v144;
      // pto: %wo_a__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v146 = PTOAS__GLOBAL_TENSOR_DATA(v61);
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v147 = 0;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v148 = 4194304;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v149 = 65536;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v150 = 256;
      // pto: %wo_a__ssa_v0_pview
      ;
      pto::Shape<1, 8, 1, 16, 16> v151 = pto::Shape<1, 8, 1, 16, 16>();
      // pto: %wo_a__ssa_v0_pview
      ;
      pto::Stride<4194304, 65536, 256, 16, 1> v152 = pto::Stride<4194304, 65536, 256, 16, 1>();
      // pto: %wo_a__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v153 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v146 + ((v147 + v141 * v148) + v143 * v149 + v145 * v150), v151, v152);
      TLOAD(v139, v153);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %lhs_slice_0_textract
      ;
      Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v154 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v19);
      // pto: %lhs_slice_0_textract
      ;
      uint64_t v155 = (uint64_t) v13;
      TASSIGN(v154, v155);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      uint16_t v156 = static_cast<uint16_t>(v27);
      uint16_t v157 = static_cast<uint16_t>(v27);
      TEXTRACT(v154, v123, v156, v157);
      // pto: %rhs_slice_0_textract
      ;
      Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v158 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
      // pto: %rhs_slice_0_textract
      ;
      uint64_t v159 = (uint64_t) v13;
      TASSIGN(v158, v159);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      uint16_t v160 = static_cast<uint16_t>(v27);
      uint16_t v161 = static_cast<uint16_t>(v27);
      TEXTRACT(v158, v139, v160, v161);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %v4_wide_acc_inline1421__tile
      ;
      Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v162 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v121, v26);
      // pto: %v4_wide_acc_inline1421__tile
      ;
      uint64_t v163 = (uint64_t) v13;
      TASSIGN(v162, v163);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      TMATMUL(v162, v154, v158);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      for (int64_t v164 = v27; v164 < v35; v164 += v29) {
        // pto: %139
        ;
        int64_t v165 = (int64_t) ((uint64_t) v164 * (uint64_t) v19);
        // pto: %140, %141, %142
        ;
        int64_t v166 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v76 + (uint64_t) v165) + (uint64_t) v18) % v23;
        // pto: %145, %144, %146, %147
        ;
        int64_t v167 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v76 + (uint64_t) ((int64_t) (uint64_t) v165 + (uint64_t) v19)) + (uint64_t) v18) % v23;
        // pto: %148
        ;
        // pto: %149
        ;
        int64_t v168 = v121 < v26 ? v121 : v26;
        v62.SetValidShape(v168, v26);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        if (v166 <= v36) {
          // pto: %150
          ;
          int64_t v169 = (int64_t) ((uint64_t) v166 * (uint64_t) v19);
          // pto: %v4_wide_packet_x_inline1418__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v170 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v121, v23);
          // pto: %v4_wide_packet_x_inline1418__tile
          ;
          uint64_t v171 = (uint64_t) v12;
          TASSIGN(v170, v171);
          // pto: %153
          ;
          int64_t v172 = (int64_t) ((uint64_t) v126 + (uint64_t) v169);
          // pto: %154
          ;
          int64_t v173 = v172 < v27 ? v27 : v172;
          // pto: %155
          ;
          const int64_t v174 = 0;
          // pto: %155
          ;
          __gm__ bfloat16_t* v175 = PTOAS__GLOBAL_TENSOR_DATA(v58);
          // pto: %155
          ;
          const int64_t v176 = 1;
          // pto: %155
          ;
          const int64_t v177 = 1;
          // pto: %155
          ;
          const int64_t v178 = 1;
          // pto: %155
          ;
          int64_t v179 = v121 * v21;
          // pto: %155
          ;
          int64_t v180 = v178 * v179;
          // pto: %155
          ;
          pto::Shape<1, 1, 1, -1, 256> v181 = pto::Shape<1, 1, 1, -1, 256>(v176, v177, v178, v121, v23);
          // pto: %155
          ;
          pto::Stride<-1, -1, -1, -1, -1> v182 = pto::Stride<-1, -1, -1, -1, -1>(v177 * v180, v180, v179, v21, v18);
          // pto: %155
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v183 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v175 + (v174 + v125 * v21 + v173 * v18), v181, v182);
          TLOAD(v170, v183);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          // pto: %v4_wide_packet_w_inline1415__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
          // pto: %v4_wide_packet_w_inline1415__tile
          ;
          uint64_t v185 = (uint64_t) v13;
          TASSIGN(v184, v185);
          // pto: %159
          ;
          int64_t v186 = v169 / v19;
          // pto: %160
          ;
          int64_t v187 = v186 < v27 ? v27 : v186;
          // pto: %161
          ;
          __gm__ bfloat16_t* v188 = PTOAS__GLOBAL_TENSOR_DATA(v61);
          // pto: %161
          ;
          const int64_t v189 = 0;
          // pto: %161
          ;
          const int64_t v190 = 4194304;
          // pto: %161
          ;
          const int64_t v191 = 65536;
          // pto: %161
          ;
          const int64_t v192 = 256;
          // pto: %161
          ;
          pto::Shape<1, 8, 16, 16, 16> v193 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %161
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v194 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %161
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v195 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v188 + ((v189 + v141 * v190) + v143 * v191 + v187 * v192), v193, v194);
          TLOAD(v184, v195);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
          // pto: %v4_wide_acc_inline1421__iter_v1_l0_a
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v196 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v26);
          // pto: %v4_wide_acc_inline1421__iter_v1_l0_a
          ;
          uint64_t v197 = (uint64_t) v13;
          TASSIGN(v196, v197);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          uint16_t v198 = static_cast<uint16_t>(v27);
          uint16_t v199 = static_cast<uint16_t>(v27);
          TEXTRACT(v196, v170, v198, v199);
          // pto: %v4_wide_acc_inline1421__iter_v1_l0_b
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v200 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %v4_wide_acc_inline1421__iter_v1_l0_b
          ;
          uint64_t v201 = (uint64_t) v13;
          TASSIGN(v200, v201);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
          uint16_t v202 = static_cast<uint16_t>(v27);
          uint16_t v203 = static_cast<uint16_t>(v27);
          TEXTRACT(v200, v184, v202, v203);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          // pto: %0
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v204 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v26);
          // pto: %0
          ;
          uint64_t v205 = (uint64_t) v14;
          TASSIGN(v204, v205);
          uint16_t v206 = static_cast<uint16_t>(v27);
          uint16_t v207 = static_cast<uint16_t>(v26);
          TEXTRACT(v204, v170, v206, v207);
          // pto: %1
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v208 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %1
          ;
          uint64_t v209 = (uint64_t) v14;
          TASSIGN(v208, v209);
          uint16_t v210 = static_cast<uint16_t>(v26);
          uint16_t v211 = static_cast<uint16_t>(v27);
          TEXTRACT(v208, v184, v210, v211);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v162, v162, v196, v200);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
          TMATMUL_ACC(v162, v162, v204, v208);
        } else {
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
          for (int64_t v212 = v27; v212 < v19; v212 += v18) {
            // pto: %162, %163, %164
            ;
            int64_t v213 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v166 + (uint64_t) v212) % v23) * (uint64_t) v19);
            // pto: %v4_wide_wrap_x_inline1487__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v121, v19);
            // pto: %v4_wide_wrap_x_inline1487__tile
            ;
            uint64_t v215 = (uint64_t) v12;
            TASSIGN(v214, v215);
            // pto: %167
            ;
            int64_t v216 = (int64_t) ((uint64_t) v126 + (uint64_t) v213);
            // pto: %168
            ;
            int64_t v217 = v216 < v27 ? v27 : v216;
            // pto: %169
            ;
            const int64_t v218 = 0;
            // pto: %169
            ;
            __gm__ bfloat16_t* v219 = PTOAS__GLOBAL_TENSOR_DATA(v58);
            // pto: %169
            ;
            const int64_t v220 = 1;
            // pto: %169
            ;
            const int64_t v221 = 1;
            // pto: %169
            ;
            const int64_t v222 = 1;
            // pto: %169
            ;
            int64_t v223 = v121 * v21;
            // pto: %169
            ;
            int64_t v224 = v222 * v223;
            // pto: %169
            ;
            pto::Shape<1, 1, 1, -1, 16> v225 = pto::Shape<1, 1, 1, -1, 16>(v220, v221, v222, v121, v19);
            // pto: %169
            ;
            pto::Stride<-1, -1, -1, -1, -1> v226 = pto::Stride<-1, -1, -1, -1, -1>(v221 * v224, v224, v223, v21, v18);
            // pto: %169
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v227 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v219 + (v218 + v125 * v21 + v217 * v18), v225, v226);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            TLOAD(v214, v227);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
            // pto: %v4_wide_wrap_w_inline1446__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v228 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %v4_wide_wrap_w_inline1446__tile
            ;
            uint64_t v229 = (uint64_t) v13;
            TASSIGN(v228, v229);
            // pto: %173
            ;
            int64_t v230 = v213 / v19;
            // pto: %174
            ;
            int64_t v231 = v230 < v27 ? v27 : v230;
            // pto: %175
            ;
            __gm__ bfloat16_t* v232 = PTOAS__GLOBAL_TENSOR_DATA(v61);
            // pto: %175
            ;
            const int64_t v233 = 0;
            // pto: %175
            ;
            const int64_t v234 = 4194304;
            // pto: %175
            ;
            const int64_t v235 = 65536;
            // pto: %175
            ;
            const int64_t v236 = 256;
            // pto: %175
            ;
            pto::Shape<1, 8, 1, 16, 16> v237 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %175
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v238 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %175
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v239 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v232 + ((v233 + v141 * v234) + v143 * v235 + v231 * v236), v237, v238);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            TLOAD(v228, v239);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
            // pto: %3
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v240 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v19);
            // pto: %3
            ;
            uint64_t v241 = (uint64_t) v13;
            TASSIGN(v240, v241);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
            uint16_t v242 = static_cast<uint16_t>(v27);
            uint16_t v243 = static_cast<uint16_t>(v27);
            TEXTRACT(v240, v214, v242, v243);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            // pto: %4
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %4
            ;
            uint64_t v245 = (uint64_t) v13;
            TASSIGN(v244, v245);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
            uint16_t v246 = static_cast<uint16_t>(v27);
            uint16_t v247 = static_cast<uint16_t>(v27);
            TEXTRACT(v244, v228, v246, v247);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v162, v162, v240, v244);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        };
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        // pto: %176
        ;
        v64.SetValidShape(v168, v26);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        if (v167 <= v36) {
          // pto: %179
          ;
          int64_t v248 = (int64_t) ((uint64_t) v167 * (uint64_t) v19);
          // pto: %5
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v249 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v121, v23);
          // pto: %5
          ;
          uint64_t v250 = (uint64_t) v15;
          TASSIGN(v249, v250);
          // pto: %182
          ;
          int64_t v251 = (int64_t) ((uint64_t) v126 + (uint64_t) v248);
          // pto: %183
          ;
          int64_t v252 = v251 < v27 ? v27 : v251;
          // pto: %184
          ;
          const int64_t v253 = 0;
          // pto: %184
          ;
          __gm__ bfloat16_t* v254 = PTOAS__GLOBAL_TENSOR_DATA(v58);
          // pto: %184
          ;
          const int64_t v255 = 1;
          // pto: %184
          ;
          const int64_t v256 = 1;
          // pto: %184
          ;
          const int64_t v257 = 1;
          // pto: %184
          ;
          int64_t v258 = v121 * v21;
          // pto: %184
          ;
          int64_t v259 = v257 * v258;
          // pto: %184
          ;
          pto::Shape<1, 1, 1, -1, 256> v260 = pto::Shape<1, 1, 1, -1, 256>(v255, v256, v257, v121, v23);
          // pto: %184
          ;
          pto::Stride<-1, -1, -1, -1, -1> v261 = pto::Stride<-1, -1, -1, -1, -1>(v256 * v259, v259, v258, v21, v18);
          // pto: %184
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v262 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v254 + (v253 + v125 * v21 + v252 * v18), v260, v261);
          TLOAD(v249, v262);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
          // pto: %6
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v263 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
          // pto: %6
          ;
          uint64_t v264 = (uint64_t) v16;
          TASSIGN(v263, v264);
          // pto: %188
          ;
          int64_t v265 = v248 / v19;
          // pto: %189
          ;
          int64_t v266 = v265 < v27 ? v27 : v265;
          // pto: %190
          ;
          __gm__ bfloat16_t* v267 = PTOAS__GLOBAL_TENSOR_DATA(v61);
          // pto: %190
          ;
          const int64_t v268 = 0;
          // pto: %190
          ;
          const int64_t v269 = 4194304;
          // pto: %190
          ;
          const int64_t v270 = 65536;
          // pto: %190
          ;
          const int64_t v271 = 256;
          // pto: %190
          ;
          pto::Shape<1, 8, 16, 16, 16> v272 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %190
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v273 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %190
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v274 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v267 + ((v268 + v141 * v269) + v143 * v270 + v266 * v271), v272, v273);
          TLOAD(v263, v274);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
          // pto: %7
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v275 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v26);
          // pto: %7
          ;
          uint64_t v276 = (uint64_t) v13;
          TASSIGN(v275, v276);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
          uint16_t v277 = static_cast<uint16_t>(v27);
          uint16_t v278 = static_cast<uint16_t>(v27);
          TEXTRACT(v275, v249, v277, v278);
          // pto: %8
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %8
          ;
          uint64_t v280 = (uint64_t) v13;
          TASSIGN(v279, v280);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
          uint16_t v281 = static_cast<uint16_t>(v27);
          uint16_t v282 = static_cast<uint16_t>(v27);
          TEXTRACT(v279, v263, v281, v282);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
          // pto: %9
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v283 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v26);
          // pto: %9
          ;
          uint64_t v284 = (uint64_t) v14;
          TASSIGN(v283, v284);
          uint16_t v285 = static_cast<uint16_t>(v27);
          uint16_t v286 = static_cast<uint16_t>(v26);
          TEXTRACT(v283, v249, v285, v286);
          // pto: %10
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %10
          ;
          uint64_t v288 = (uint64_t) v14;
          TASSIGN(v287, v288);
          uint16_t v289 = static_cast<uint16_t>(v26);
          uint16_t v290 = static_cast<uint16_t>(v27);
          TEXTRACT(v287, v263, v289, v290);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v62, v62, v275, v279);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          TMATMUL_ACC(v62, v62, v283, v287);
        } else {
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
          for (int64_t v291 = v27; v291 < v19; v291 += v18) {
            // pto: %192, %193, %194
            ;
            int64_t v292 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v167 + (uint64_t) v291) % v23) * (uint64_t) v19);
            // pto: %13
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v121, v19);
            // pto: %13
            ;
            uint64_t v294 = (uint64_t) v15;
            TASSIGN(v293, v294);
            // pto: %197
            ;
            int64_t v295 = (int64_t) ((uint64_t) v126 + (uint64_t) v292);
            // pto: %198
            ;
            int64_t v296 = v295 < v27 ? v27 : v295;
            // pto: %199
            ;
            const int64_t v297 = 0;
            // pto: %199
            ;
            __gm__ bfloat16_t* v298 = PTOAS__GLOBAL_TENSOR_DATA(v58);
            // pto: %199
            ;
            const int64_t v299 = 1;
            // pto: %199
            ;
            const int64_t v300 = 1;
            // pto: %199
            ;
            const int64_t v301 = 1;
            // pto: %199
            ;
            int64_t v302 = v121 * v21;
            // pto: %199
            ;
            int64_t v303 = v301 * v302;
            // pto: %199
            ;
            pto::Shape<1, 1, 1, -1, 16> v304 = pto::Shape<1, 1, 1, -1, 16>(v299, v300, v301, v121, v19);
            // pto: %199
            ;
            pto::Stride<-1, -1, -1, -1, -1> v305 = pto::Stride<-1, -1, -1, -1, -1>(v300 * v303, v303, v302, v21, v18);
            // pto: %199
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v306 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v298 + (v297 + v125 * v21 + v296 * v18), v304, v305);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
            TLOAD(v293, v306);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %14
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %14
            ;
            uint64_t v308 = (uint64_t) v16;
            TASSIGN(v307, v308);
            // pto: %203
            ;
            int64_t v309 = v292 / v19;
            // pto: %204
            ;
            int64_t v310 = v309 < v27 ? v27 : v309;
            // pto: %205
            ;
            __gm__ bfloat16_t* v311 = PTOAS__GLOBAL_TENSOR_DATA(v61);
            // pto: %205
            ;
            const int64_t v312 = 0;
            // pto: %205
            ;
            const int64_t v313 = 4194304;
            // pto: %205
            ;
            const int64_t v314 = 65536;
            // pto: %205
            ;
            const int64_t v315 = 256;
            // pto: %205
            ;
            pto::Shape<1, 8, 1, 16, 16> v316 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %205
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v317 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %205
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v318 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v311 + ((v312 + v141 * v313) + v143 * v314 + v310 * v315), v316, v317);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
            TLOAD(v307, v318);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %15
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v319 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v19);
            // pto: %15
            ;
            uint64_t v320 = (uint64_t) v13;
            TASSIGN(v319, v320);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
            uint16_t v321 = static_cast<uint16_t>(v27);
            uint16_t v322 = static_cast<uint16_t>(v27);
            TEXTRACT(v319, v293, v321, v322);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
            // pto: %16
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v323 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %16
            ;
            uint64_t v324 = (uint64_t) v13;
            TASSIGN(v323, v324);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v325 = static_cast<uint16_t>(v27);
            uint16_t v326 = static_cast<uint16_t>(v27);
            TEXTRACT(v323, v307, v325, v326);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v62, v62, v319, v323);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        };
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      // pto: %206, %207
      ;
      int64_t v327 = (int64_t) ((uint64_t) v76 + (uint64_t) v37) % v23;
      // pto: %208
      ;
      // pto: %209
      ;
      int64_t v328 = v121 < v26 ? v121 : v26;
      v66.SetValidShape(v328, v26);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      if (v327 <= v36) {
        // pto: %211
        ;
        int64_t v329 = (int64_t) ((uint64_t) v327 * (uint64_t) v19);
        // pto: %18
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v330 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v121, v23);
        // pto: %18
        ;
        uint64_t v331 = (uint64_t) v12;
        TASSIGN(v330, v331);
        // pto: %214
        ;
        int64_t v332 = (int64_t) ((uint64_t) v126 + (uint64_t) v329);
        // pto: %215
        ;
        int64_t v333 = v332 < v27 ? v27 : v332;
        // pto: %216
        ;
        const int64_t v334 = 0;
        // pto: %216
        ;
        __gm__ bfloat16_t* v335 = PTOAS__GLOBAL_TENSOR_DATA(v58);
        // pto: %216
        ;
        const int64_t v336 = 1;
        // pto: %216
        ;
        const int64_t v337 = 1;
        // pto: %216
        ;
        const int64_t v338 = 1;
        // pto: %216
        ;
        int64_t v339 = v121 * v21;
        // pto: %216
        ;
        int64_t v340 = v338 * v339;
        // pto: %216
        ;
        pto::Shape<1, 1, 1, -1, 256> v341 = pto::Shape<1, 1, 1, -1, 256>(v336, v337, v338, v121, v23);
        // pto: %216
        ;
        pto::Stride<-1, -1, -1, -1, -1> v342 = pto::Stride<-1, -1, -1, -1, -1>(v337 * v340, v340, v339, v21, v18);
        // pto: %216
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v343 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v335 + (v334 + v125 * v21 + v333 * v18), v341, v342);
        TLOAD(v330, v343);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %19
        ;
        Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v344 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
        // pto: %19
        ;
        uint64_t v345 = (uint64_t) v13;
        TASSIGN(v344, v345);
        // pto: %220
        ;
        int64_t v346 = v329 / v19;
        // pto: %221
        ;
        int64_t v347 = v346 < v27 ? v27 : v346;
        // pto: %222
        ;
        __gm__ bfloat16_t* v348 = PTOAS__GLOBAL_TENSOR_DATA(v61);
        // pto: %222
        ;
        const int64_t v349 = 0;
        // pto: %222
        ;
        const int64_t v350 = 4194304;
        // pto: %222
        ;
        const int64_t v351 = 65536;
        // pto: %222
        ;
        const int64_t v352 = 256;
        // pto: %222
        ;
        pto::Shape<1, 8, 16, 16, 16> v353 = pto::Shape<1, 8, 16, 16, 16>();
        // pto: %222
        ;
        pto::Stride<4194304, 65536, 256, 16, 1> v354 = pto::Stride<4194304, 65536, 256, 16, 1>();
        // pto: %222
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v355 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v348 + ((v349 + v141 * v350) + v143 * v351 + v347 * v352), v353, v354);
        TLOAD(v344, v355);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %20
        ;
        Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v356 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v26);
        // pto: %20
        ;
        uint64_t v357 = (uint64_t) v13;
        TASSIGN(v356, v357);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        uint16_t v358 = static_cast<uint16_t>(v27);
        uint16_t v359 = static_cast<uint16_t>(v27);
        TEXTRACT(v356, v330, v358, v359);
        // pto: %21
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v360 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
        // pto: %21
        ;
        uint64_t v361 = (uint64_t) v13;
        TASSIGN(v360, v361);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v362 = static_cast<uint16_t>(v27);
        uint16_t v363 = static_cast<uint16_t>(v27);
        TEXTRACT(v360, v344, v362, v363);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        // pto: %22
        ;
        Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v364 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v26);
        // pto: %22
        ;
        uint64_t v365 = (uint64_t) v14;
        TASSIGN(v364, v365);
        uint16_t v366 = static_cast<uint16_t>(v27);
        uint16_t v367 = static_cast<uint16_t>(v26);
        TEXTRACT(v364, v330, v366, v367);
        // pto: %23
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v368 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
        // pto: %23
        ;
        uint64_t v369 = (uint64_t) v14;
        TASSIGN(v368, v369);
        uint16_t v370 = static_cast<uint16_t>(v26);
        uint16_t v371 = static_cast<uint16_t>(v27);
        TEXTRACT(v368, v344, v370, v371);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v162, v162, v356, v360);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        TMATMUL_ACC(v162, v162, v364, v368);
      } else {
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        for (int64_t v372 = v27; v372 < v19; v372 += v18) {
          // pto: %224, %225, %226
          ;
          int64_t v373 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v327 + (uint64_t) v372) % v23) * (uint64_t) v19);
          // pto: %26
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v374 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v121, v19);
          // pto: %26
          ;
          uint64_t v375 = (uint64_t) v12;
          TASSIGN(v374, v375);
          // pto: %229
          ;
          int64_t v376 = (int64_t) ((uint64_t) v126 + (uint64_t) v373);
          // pto: %230
          ;
          int64_t v377 = v376 < v27 ? v27 : v376;
          // pto: %231
          ;
          const int64_t v378 = 0;
          // pto: %231
          ;
          __gm__ bfloat16_t* v379 = PTOAS__GLOBAL_TENSOR_DATA(v58);
          // pto: %231
          ;
          const int64_t v380 = 1;
          // pto: %231
          ;
          const int64_t v381 = 1;
          // pto: %231
          ;
          const int64_t v382 = 1;
          // pto: %231
          ;
          int64_t v383 = v121 * v21;
          // pto: %231
          ;
          int64_t v384 = v382 * v383;
          // pto: %231
          ;
          pto::Shape<1, 1, 1, -1, 16> v385 = pto::Shape<1, 1, 1, -1, 16>(v380, v381, v382, v121, v19);
          // pto: %231
          ;
          pto::Stride<-1, -1, -1, -1, -1> v386 = pto::Stride<-1, -1, -1, -1, -1>(v381 * v384, v384, v383, v21, v18);
          // pto: %231
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v387 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v379 + (v378 + v125 * v21 + v377 * v18), v385, v386);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          TLOAD(v374, v387);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %27
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v388 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
          // pto: %27
          ;
          uint64_t v389 = (uint64_t) v13;
          TASSIGN(v388, v389);
          // pto: %235
          ;
          int64_t v390 = v373 / v19;
          // pto: %236
          ;
          int64_t v391 = v390 < v27 ? v27 : v390;
          // pto: %237
          ;
          __gm__ bfloat16_t* v392 = PTOAS__GLOBAL_TENSOR_DATA(v61);
          // pto: %237
          ;
          const int64_t v393 = 0;
          // pto: %237
          ;
          const int64_t v394 = 4194304;
          // pto: %237
          ;
          const int64_t v395 = 65536;
          // pto: %237
          ;
          const int64_t v396 = 256;
          // pto: %237
          ;
          pto::Shape<1, 8, 1, 16, 16> v397 = pto::Shape<1, 8, 1, 16, 16>();
          // pto: %237
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v398 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %237
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v399 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v392 + ((v393 + v141 * v394) + v143 * v395 + v391 * v396), v397, v398);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          TLOAD(v388, v399);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %28
          ;
          Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v400 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v19);
          // pto: %28
          ;
          uint64_t v401 = (uint64_t) v13;
          TASSIGN(v400, v401);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          uint16_t v402 = static_cast<uint16_t>(v27);
          uint16_t v403 = static_cast<uint16_t>(v27);
          TEXTRACT(v400, v374, v402, v403);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %29
          ;
          Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v404 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
          // pto: %29
          ;
          uint64_t v405 = (uint64_t) v13;
          TASSIGN(v404, v405);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v406 = static_cast<uint16_t>(v27);
          uint16_t v407 = static_cast<uint16_t>(v27);
          TEXTRACT(v404, v388, v406, v407);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v162, v162, v400, v404);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        };
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      // pto: %v4_wide_acc_inline1421__rv_v2
      ;
      Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v408 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v121, v26);
      // pto: %v4_wide_acc_inline1421__rv_v2
      ;
      uint64_t v409 = (uint64_t) v13;
      TASSIGN(v408, v409);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      for (int64_t v410 = v38; v410 < v23; v410 += v18) {
        // pto: %238, %239, %240
        ;
        int64_t v411 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v76 + (uint64_t) v410) % v23) * (uint64_t) v19);
        // pto: %v4_wide_tail_x_inline1417__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v412 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v121, v19);
        // pto: %v4_wide_tail_x_inline1417__tile
        ;
        uint64_t v413 = (uint64_t) v12;
        TASSIGN(v412, v413);
        // pto: %243
        ;
        int64_t v414 = (int64_t) ((uint64_t) v126 + (uint64_t) v411);
        // pto: %244
        ;
        int64_t v415 = v414 < v27 ? v27 : v414;
        // pto: %245
        ;
        const int64_t v416 = 0;
        // pto: %245
        ;
        __gm__ bfloat16_t* v417 = PTOAS__GLOBAL_TENSOR_DATA(v58);
        // pto: %245
        ;
        const int64_t v418 = 1;
        // pto: %245
        ;
        const int64_t v419 = 1;
        // pto: %245
        ;
        const int64_t v420 = 1;
        // pto: %245
        ;
        int64_t v421 = v121 * v21;
        // pto: %245
        ;
        int64_t v422 = v420 * v421;
        // pto: %245
        ;
        pto::Shape<1, 1, 1, -1, 16> v423 = pto::Shape<1, 1, 1, -1, 16>(v418, v419, v420, v121, v19);
        // pto: %245
        ;
        pto::Stride<-1, -1, -1, -1, -1> v424 = pto::Stride<-1, -1, -1, -1, -1>(v419 * v422, v422, v421, v21, v18);
        // pto: %245
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v425 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v417 + (v416 + v125 * v21 + v415 * v18), v423, v424);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v412, v425);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %v4_wide_tail_w_inline1488__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v426 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
        // pto: %v4_wide_tail_w_inline1488__tile
        ;
        uint64_t v427 = (uint64_t) v13;
        TASSIGN(v426, v427);
        // pto: %249
        ;
        int64_t v428 = v411 / v19;
        // pto: %250
        ;
        int64_t v429 = v428 < v27 ? v27 : v428;
        // pto: %251
        ;
        __gm__ bfloat16_t* v430 = PTOAS__GLOBAL_TENSOR_DATA(v61);
        // pto: %251
        ;
        const int64_t v431 = 0;
        // pto: %251
        ;
        const int64_t v432 = 4194304;
        // pto: %251
        ;
        const int64_t v433 = 65536;
        // pto: %251
        ;
        const int64_t v434 = 256;
        // pto: %251
        ;
        pto::Shape<1, 8, 1, 16, 16> v435 = pto::Shape<1, 8, 1, 16, 16>();
        // pto: %251
        ;
        pto::Stride<4194304, 65536, 256, 16, 1> v436 = pto::Stride<4194304, 65536, 256, 16, 1>();
        // pto: %251
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v437 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v430 + ((v431 + v141 * v432) + v143 * v433 + v429 * v434), v435, v436);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        TLOAD(v426, v437);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %31
        ;
        Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v438 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v121, v19);
        // pto: %31
        ;
        uint64_t v439 = (uint64_t) v13;
        TASSIGN(v438, v439);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v440 = static_cast<uint16_t>(v27);
        uint16_t v441 = static_cast<uint16_t>(v27);
        TEXTRACT(v438, v412, v440, v441);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        // pto: %32
        ;
        Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v442 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
        // pto: %32
        ;
        uint64_t v443 = (uint64_t) v13;
        TASSIGN(v442, v443);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v444 = static_cast<uint16_t>(v27);
        uint16_t v445 = static_cast<uint16_t>(v27);
        TEXTRACT(v442, v426, v444, v445);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v408, v408, v438, v442);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      // pto: %253, %254
      ;
      int64_t v446 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v39) + (uint64_t) v71);
      // pto: %255
      ;
      int64_t v447 = v446 < v27 ? v27 : v446;
      // pto: %accum_inline1531__iter_v13_pview
      ;
      const int64_t v448 = 0;
      // pto: %accum_inline1531__iter_v13_pview
      ;
      __gm__ float* v449 = PTOAS__GLOBAL_TENSOR_DATA(v49);
      // pto: %accum_inline1531__iter_v13_pview
      ;
      const int64_t v450 = 1;
      // pto: %accum_inline1531__iter_v13_pview
      ;
      const int64_t v451 = 1;
      // pto: %accum_inline1531__iter_v13_pview
      ;
      const int64_t v452 = 1;
      // pto: %accum_inline1531__iter_v13_pview
      ;
      int64_t v453 = v121 * v17;
      // pto: %accum_inline1531__iter_v13_pview
      ;
      int64_t v454 = v452 * v453;
      // pto: %accum_inline1531__iter_v13_pview
      ;
      pto::Shape<1, 1, 1, -1, 128> v455 = pto::Shape<1, 1, 1, -1, 128>(v450, v451, v452, v121, v26);
      // pto: %accum_inline1531__iter_v13_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v456 = pto::Stride<-1, -1, -1, -1, -1>(v451 * v454, v454, v453, v17, v18);
      // pto: %accum_inline1531__iter_v13_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v457 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v449 + (v448 + v125 * v17 + v447 * v18), v455, v456);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      TSTORE(v457, v408);
    } else {
      for (int64_t v458 = v27; v458 < v20; v458 += v18) {
        // pto: %256
        ;
        int64_t v459 = (int64_t) ((uint64_t) v73 + (uint64_t) v458);
        // pto: %257
        ;
        if (v459 < v5) {
          // pto: %258
          ;
          int64_t v460 = (int64_t) ((uint64_t) v459 * (uint64_t) v19);
          // pto: %259
          ;
          int64_t v461 = (int64_t) ((uint64_t) v8 - (uint64_t) v460);
          // pto: %260
          ;
          int64_t v462 = v461 < v19 ? v461 : v19;
          // pto: %262, %263, %264, %265, %261
          ;
          int32_t v463 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v459 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v70)];
          // pto: %266
          ;
          int64_t v464 = (int64_t) v463;
          // pto: %267
          ;
          int64_t v465 = v464 < v27 ? v27 : v464;
          // pto: %v4_narrow_acc_inline1491__tile
          ;
          Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v466 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v19, v26);
          // pto: %v4_narrow_acc_inline1491__tile
          ;
          uint64_t v467 = (uint64_t) v13;
          TASSIGN(v466, v467);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          for (int64_t v468 = v27; v468 < v19; v468 += v18) {
            // pto: %268
            ;
            int64_t v469 = (int64_t) ((uint64_t) v468 * (uint64_t) v19);
            // pto: %269, %270
            ;
            int64_t v470 = (int64_t) ((uint64_t) v465 + (uint64_t) v469) % v23;
            // pto: %271
            ;
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            if (v470 <= v36) {
              // pto: %272
              ;
              int64_t v471 = (int64_t) ((uint64_t) v470 * (uint64_t) v19);
              // pto: %v4_narrow_packet_x_inline1497__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v462, v23);
              // pto: %v4_narrow_packet_x_inline1497__tile
              ;
              uint64_t v473 = (uint64_t) v13;
              TASSIGN(v472, v473);
              // pto: %273
              ;
              int64_t v474 = v460 < v27 ? v27 : v460;
              // pto: %274, %275
              ;
              int64_t v475 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v34) + (uint64_t) v471);
              // pto: %276
              ;
              int64_t v476 = v475 < v27 ? v27 : v475;
              // pto: %277
              ;
              const int64_t v477 = 0;
              // pto: %277
              ;
              __gm__ bfloat16_t* v478 = PTOAS__GLOBAL_TENSOR_DATA(v58);
              // pto: %277
              ;
              const int64_t v479 = 1;
              // pto: %277
              ;
              const int64_t v480 = 1;
              // pto: %277
              ;
              const int64_t v481 = 1;
              // pto: %277
              ;
              int64_t v482 = v462 * v21;
              // pto: %277
              ;
              int64_t v483 = v481 * v482;
              // pto: %277
              ;
              pto::Shape<1, 1, 1, -1, 256> v484 = pto::Shape<1, 1, 1, -1, 256>(v479, v480, v481, v462, v23);
              // pto: %277
              ;
              pto::Stride<-1, -1, -1, -1, -1> v485 = pto::Stride<-1, -1, -1, -1, -1>(v480 * v483, v483, v482, v21, v18);
              // pto: %277
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v486 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v478 + (v477 + v474 * v21 + v476 * v18), v484, v485);
              TLOAD(v472, v486);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %v4_narrow_packet_w_inline1447__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v487 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
              // pto: %v4_narrow_packet_w_inline1447__tile
              ;
              uint64_t v488 = (uint64_t) v12;
              TASSIGN(v487, v488);
              // pto: %278
              ;
              int64_t v489 = v6 < v27 ? v27 : v6;
              // pto: %279
              ;
              int64_t v490 = v71 / v19;
              // pto: %280
              ;
              int64_t v491 = v490 < v27 ? v27 : v490;
              // pto: %281
              ;
              int64_t v492 = v471 / v19;
              // pto: %282
              ;
              int64_t v493 = v492 < v27 ? v27 : v492;
              // pto: %283
              ;
              __gm__ bfloat16_t* v494 = PTOAS__GLOBAL_TENSOR_DATA(v61);
              // pto: %283
              ;
              const int64_t v495 = 0;
              // pto: %283
              ;
              const int64_t v496 = 4194304;
              // pto: %283
              ;
              const int64_t v497 = 65536;
              // pto: %283
              ;
              const int64_t v498 = 256;
              // pto: %283
              ;
              pto::Shape<1, 8, 16, 16, 16> v499 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %283
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v500 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %283
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v501 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v494 + ((v495 + v489 * v496) + v491 * v497 + v493 * v498), v499, v500);
              TLOAD(v487, v501);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %v4_narrow_acc_inline1491__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v502 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v462, v26);
              // pto: %v4_narrow_acc_inline1491__iter_v1_l0_a
              ;
              uint64_t v503 = (uint64_t) v13;
              TASSIGN(v502, v503);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              uint16_t v504 = static_cast<uint16_t>(v27);
              uint16_t v505 = static_cast<uint16_t>(v27);
              TEXTRACT(v502, v472, v504, v505);
              // pto: %v4_narrow_acc_inline1491__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v506 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
              // pto: %v4_narrow_acc_inline1491__iter_v1_l0_b
              ;
              uint64_t v507 = (uint64_t) v13;
              TASSIGN(v506, v507);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v508 = static_cast<uint16_t>(v27);
              uint16_t v509 = static_cast<uint16_t>(v27);
              TEXTRACT(v506, v487, v508, v509);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              // pto: %33
              ;
              Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v510 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v462, v26);
              // pto: %33
              ;
              uint64_t v511 = (uint64_t) v14;
              TASSIGN(v510, v511);
              uint16_t v512 = static_cast<uint16_t>(v27);
              uint16_t v513 = static_cast<uint16_t>(v26);
              TEXTRACT(v510, v472, v512, v513);
              // pto: %34
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v514 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
              // pto: %34
              ;
              uint64_t v515 = (uint64_t) v14;
              TASSIGN(v514, v515);
              uint16_t v516 = static_cast<uint16_t>(v26);
              uint16_t v517 = static_cast<uint16_t>(v27);
              TEXTRACT(v514, v487, v516, v517);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              // pto: %284
              ;
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              if (v468 == v27) {
                pipe_barrier(PIPE_M);
                TMATMUL(v466, v502, v506);
              } else {
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v466, v466, v502, v506);
              };
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              TMATMUL_ACC(v466, v466, v510, v514);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              for (int64_t v518 = v27; v518 < v19; v518 += v18) {
                // pto: %285, %286, %287
                ;
                int64_t v519 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v470 + (uint64_t) v518) % v23) * (uint64_t) v19);
                // pto: %v4_narrow_wrap_x_inline1498__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v520 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v462, v19);
                // pto: %v4_narrow_wrap_x_inline1498__tile
                ;
                uint64_t v521 = (uint64_t) v13;
                TASSIGN(v520, v521);
                // pto: %288
                ;
                int64_t v522 = v460 < v27 ? v27 : v460;
                // pto: %289, %290
                ;
                int64_t v523 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v34) + (uint64_t) v519);
                // pto: %291
                ;
                int64_t v524 = v523 < v27 ? v27 : v523;
                // pto: %292
                ;
                const int64_t v525 = 0;
                // pto: %292
                ;
                __gm__ bfloat16_t* v526 = PTOAS__GLOBAL_TENSOR_DATA(v58);
                // pto: %292
                ;
                const int64_t v527 = 1;
                // pto: %292
                ;
                const int64_t v528 = 1;
                // pto: %292
                ;
                const int64_t v529 = 1;
                // pto: %292
                ;
                int64_t v530 = v462 * v21;
                // pto: %292
                ;
                int64_t v531 = v529 * v530;
                // pto: %292
                ;
                pto::Shape<1, 1, 1, -1, 16> v532 = pto::Shape<1, 1, 1, -1, 16>(v527, v528, v529, v462, v19);
                // pto: %292
                ;
                pto::Stride<-1, -1, -1, -1, -1> v533 = pto::Stride<-1, -1, -1, -1, -1>(v528 * v531, v531, v530, v21, v18);
                // pto: %292
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v534 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v526 + (v525 + v522 * v21 + v524 * v18), v532, v533);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                TLOAD(v520, v534);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %v4_narrow_wrap_w_inline1490__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v535 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
                // pto: %v4_narrow_wrap_w_inline1490__tile
                ;
                uint64_t v536 = (uint64_t) v12;
                TASSIGN(v535, v536);
                // pto: %293
                ;
                int64_t v537 = v6 < v27 ? v27 : v6;
                // pto: %294
                ;
                int64_t v538 = v71 / v19;
                // pto: %295
                ;
                int64_t v539 = v538 < v27 ? v27 : v538;
                // pto: %296
                ;
                int64_t v540 = v519 / v19;
                // pto: %297
                ;
                int64_t v541 = v540 < v27 ? v27 : v540;
                // pto: %298
                ;
                __gm__ bfloat16_t* v542 = PTOAS__GLOBAL_TENSOR_DATA(v61);
                // pto: %298
                ;
                const int64_t v543 = 0;
                // pto: %298
                ;
                const int64_t v544 = 4194304;
                // pto: %298
                ;
                const int64_t v545 = 65536;
                // pto: %298
                ;
                const int64_t v546 = 256;
                // pto: %298
                ;
                pto::Shape<1, 8, 1, 16, 16> v547 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %298
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v548 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %298
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v549 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v542 + ((v543 + v537 * v544) + v539 * v545 + v541 * v546), v547, v548);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v535, v549);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %36
                ;
                Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v550 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v462, v19);
                // pto: %36
                ;
                uint64_t v551 = (uint64_t) v13;
                TASSIGN(v550, v551);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                uint16_t v552 = static_cast<uint16_t>(v27);
                uint16_t v553 = static_cast<uint16_t>(v27);
                TEXTRACT(v550, v520, v552, v553);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                // pto: %37
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v554 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
                // pto: %37
                ;
                uint64_t v555 = (uint64_t) v13;
                TASSIGN(v554, v555);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v556 = static_cast<uint16_t>(v27);
                uint16_t v557 = static_cast<uint16_t>(v27);
                TEXTRACT(v554, v535, v556, v557);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                // pto: %300, %301
                ;
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                if ((int64_t) ((uint64_t) v469 + (uint64_t) v518) == v27) {
                  pipe_barrier(PIPE_M);
                  TMATMUL(v466, v550, v554);
                } else {
                  pipe_barrier(PIPE_M);
                  TMATMUL_ACC(v466, v466, v550, v554);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          // pto: %303
          ;
          int64_t v558 = v460 < v27 ? v27 : v460;
          // pto: %304, %305
          ;
          int64_t v559 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v39) + (uint64_t) v71);
          // pto: %306
          ;
          int64_t v560 = v559 < v27 ? v27 : v559;
          // pto: %accum_inline1531__iter_v16_pview
          ;
          __gm__ float* v561 = PTOAS__GLOBAL_TENSOR_DATA(v49);
          // pto: %accum_inline1531__iter_v16_pview
          ;
          const int64_t v562 = 0;
          // pto: %accum_inline1531__iter_v16_pview
          ;
          const int64_t v563 = 8192;
          // pto: %accum_inline1531__iter_v16_pview
          ;
          pto::Shape<1, 1, 1, 16, 128> v564 = pto::Shape<1, 1, 1, 16, 128>();
          // pto: %accum_inline1531__iter_v16_pview
          ;
          pto::Stride<131072, 131072, 131072, 8192, 1> v565 = pto::Stride<131072, 131072, 131072, 8192, 1>();
          // pto: %accum_inline1531__iter_v16_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v566 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v561 + (v562 + v558 * v563 + v560), v564, v565);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          pipe_barrier(PIPE_FIX);
          TSTORE(v566, v466);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        };
      };
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}