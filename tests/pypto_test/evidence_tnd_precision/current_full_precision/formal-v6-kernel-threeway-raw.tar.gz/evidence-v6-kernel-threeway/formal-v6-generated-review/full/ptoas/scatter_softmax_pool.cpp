#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void scatter_softmax_pool(__gm__ float* v1, __gm__ int32_t* v2, __gm__ int64_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ float* v6, __gm__ float* v7, __gm__ float* v8, __gm__ float* v9, int64_t v10, int64_t v11, int64_t v12, int64_t v13, int64_t v14, int64_t v15, int64_t v16, int64_t v17, int32_t v18, int32_t v19) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v20 = -7;
  // pto: %c0_i64
  const int64_t v21 = 0;
  // pto: %c16384_i64
  const int64_t v22 = 16384;
  // pto: %c40960_i64
  const int64_t v23 = 40960;
  // pto: %c32768_i64
  const int64_t v24 = 32768;
  // pto: %c34816_i64
  const int64_t v25 = 34816;
  // pto: %c36864_i64
  const int64_t v26 = 36864;
  // pto: %c38912_i64
  const int64_t v27 = 38912;
  const int64_t v28 = 24576;
  const int64_t v29 = 45056;
  const int64_t v30 = 43008;
  const int64_t v31 = 8192;
  const int64_t v32 = 4096;
  const int64_t v33 = 2048;
  // pto: %c384_index
  const int64_t v34 = 384;
  // pto: %c512_index
  const int64_t v35 = 512;
  // pto: %c1_index
  const int64_t v36 = 1;
  // pto: %c1024_index
  const int64_t v37 = 1024;
  // pto: %c4_index
  const int64_t v38 = 4;
  // pto: %c0_index
  const int64_t v39 = 0;
  // pto: %cst_19
  const float v40 = 0.0f;
  // pto: %c1_i64
  const int64_t v41 = 1;
  // pto: %c4_i64
  const int64_t v42 = 4;
  // pto: %c8_index
  const int64_t v43 = 8;
  // pto: %cst_24
  const float v44 = -3.40282347E+38f;
  // pto: %c2_i64
  const int64_t v45 = 2;
  // pto: %c2048_index
  const int64_t v46 = 2048;
  // pto: %c2_index
  const int64_t v47 = 2;
  // pto: %pooled_kv_inline1347__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %pooled_kv_inline1347__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %pooled_kv_inline1347__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %pooled_kv_inline1347__ssa_v0_view
  int64_t v51 = v34 * v35;
  // pto: %pooled_kv_inline1347__ssa_v0_view
  int64_t v52 = v50 * v51;
  // pto: %pooled_kv_inline1347__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v48, v49, v50, v34, v35);
  // pto: %pooled_kv_inline1347__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v49 * v52, v52, v51, v35, v36);
  // pto: %pooled_kv_inline1347__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v53, v54);
  // pto: %compress_state__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %compress_state__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %compress_state__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %compress_state__ssa_v0_view
  int64_t v59 = (int64_t) v16;
  // pto: %compress_state__ssa_v0_view
  int64_t v60 = (int64_t) v17;
  // pto: %compress_state__ssa_v0_view
  int64_t v61 = v59 * v60;
  // pto: %compress_state__ssa_v0_view
  int64_t v62 = v58 * v61;
  // pto: %compress_state__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v63 = pto::Shape<1, 1, 1, -1, -1>(v56, v57, v58, v59, (int64_t) v17);
  // pto: %compress_state__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v57 * v62, v62, v61, v60, v36);
  // pto: %compress_state__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v65 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v63, v64);
  // pto: %cmp4_kv_proj_pad_inline624_inline5253__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %cmp4_kv_proj_pad_inline624_inline5253__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %cmp4_kv_proj_pad_inline624_inline5253__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %cmp4_kv_proj_pad_inline624_inline5253__ssa_v0_view
  int64_t v69 = v34 * v37;
  // pto: %cmp4_kv_proj_pad_inline624_inline5253__ssa_v0_view
  int64_t v70 = v68 * v69;
  // pto: %cmp4_kv_proj_pad_inline624_inline5253__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v71 = pto::Shape<1, 1, 1, -1, -1>(v66, v67, v68, v34, v37);
  // pto: %cmp4_kv_proj_pad_inline624_inline5253__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v70, v70, v69, v37, v36);
  // pto: %cmp4_kv_proj_pad_inline624_inline5253__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v71, v72);
  // pto: %cmp4_score_proj_pad_inline628_inline5252__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %cmp4_score_proj_pad_inline628_inline5252__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %cmp4_score_proj_pad_inline628_inline5252__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %cmp4_score_proj_pad_inline628_inline5252__ssa_v0_view
  int64_t v77 = v34 * v37;
  // pto: %cmp4_score_proj_pad_inline628_inline5252__ssa_v0_view
  int64_t v78 = v76 * v77;
  // pto: %cmp4_score_proj_pad_inline628_inline5252__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v79 = pto::Shape<1, 1, 1, -1, -1>(v74, v75, v76, v34, v37);
  // pto: %cmp4_score_proj_pad_inline628_inline5252__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v80 = pto::Stride<-1, -1, -1, -1, -1>(v75 * v78, v78, v77, v37, v36);
  // pto: %cmp4_score_proj_pad_inline628_inline5252__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v81 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v79, v80);
  // pto: %cmp_ape__ssa_v0_view
  const int64_t v82 = 1;
  // pto: %cmp_ape__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %cmp_ape__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %cmp_ape__ssa_v0_view
  int64_t v85 = v38 * v37;
  // pto: %cmp_ape__ssa_v0_view
  int64_t v86 = v84 * v85;
  // pto: %cmp_ape__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v87 = pto::Shape<1, 1, 1, -1, -1>(v82, v83, v84, v38, v37);
  // pto: %cmp_ape__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v88 = pto::Stride<-1, -1, -1, -1, -1>(v83 * v86, v86, v85, v37, v36);
  // pto: %cmp_ape__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v89 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v87, v88);
  // pto: %score_inline645_inline5292__phi_v4
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %score_inline645_inline5292__phi_v4
  uint64_t v91 = (uint64_t) v27;
  TASSIGN(v90, v91);
  // pto: %value_inline642_inline5258__phi_v3
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %value_inline642_inline5258__phi_v3
  uint64_t v93 = (uint64_t) v26;
  TASSIGN(v92, v93);
  // pto: %score_inline645_inline5292__phi_v3
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %score_inline645_inline5292__phi_v3
  uint64_t v95 = (uint64_t) v27;
  TASSIGN(v94, v95);
  // pto: %value_inline642_inline5258__phi_v2
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %value_inline642_inline5258__phi_v2
  uint64_t v97 = (uint64_t) v26;
  TASSIGN(v96, v97);
  // pto: %score_inline645_inline5292__phi_v7
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %score_inline645_inline5292__phi_v7
  uint64_t v99 = (uint64_t) v24;
  TASSIGN(v98, v99);
  // pto: %value_inline642_inline5258__phi_v6
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %value_inline642_inline5258__phi_v6
  uint64_t v101 = (uint64_t) v23;
  TASSIGN(v100, v101);
  // pto: %score_inline645_inline5292__phi_v6
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %score_inline645_inline5292__phi_v6
  uint64_t v103 = (uint64_t) v24;
  TASSIGN(v102, v103);
  // pto: %value_inline642_inline5258__phi_v5
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
  // pto: %value_inline642_inline5258__phi_v5
  uint64_t v105 = (uint64_t) v23;
  TASSIGN(v104, v105);
  // pto: %pool_worker_inline625_inline5249__ssa_v0
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v106 = (int64_t) v18; v106 < v10; v106 += v11) {
    // pto: %3
    ;
    int32_t v107 = (v2)[v106];
    // pto: %4
    ;
    int64_t v108 = (int64_t) v107;
    // pto: %6, %5
    ;
    int32_t v109 = (v2)[(int64_t) ((uint64_t) v106 + (uint64_t) v36)];
    // pto: %7
    ;
    int64_t v110 = (int64_t) v109;
    // pto: %9
    ;
    // pto: %first_pos_b_inline635_inline5278__phi_v2
    ;
    int64_t v111;
    if (v108 < v110) {
      // pto: %10
      ;
      int64_t v112 = (v3)[v108];
      v111 = v112;
    } else {
      v111 = v39;
    };
    // pto: %c_len_inline618_inline5279__tile
    ;
    int32_t v113 = (v4)[v106];
    for (int64_t v114 = v108; v114 < v110; v114 += v36) {
      // pto: %token_pos_inline633_inline5284__tile
      ;
      int64_t v115 = (v3)[v114];
      // pto: %t__tile
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
      // pto: %t__tile
      ;
      uint64_t v117 = (uint64_t) v21;
      TASSIGN(v116, v117);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      TEXPANDS(v116, v40);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %17
      ;
      int64_t v118 = v114 < v39 ? v39 : v114;
      // pto: %pooled_kv_inline1347__iter_v3_pview
      ;
      __gm__ float* v119 = PTOAS__GLOBAL_TENSOR_DATA(v55);
      // pto: %pooled_kv_inline1347__iter_v3_pview
      ;
      const int64_t v120 = 0;
      // pto: %pooled_kv_inline1347__iter_v3_pview
      ;
      const int64_t v121 = 512;
      // pto: %pooled_kv_inline1347__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v122 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %pooled_kv_inline1347__iter_v3_pview
      ;
      pto::Stride<512, 512, 512, 512, 1> v123 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %pooled_kv_inline1347__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v124 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v119 + (v120 + v118 * v121), v122, v123);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v124, v116);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      // pto: %18, %19, %20, %21, %22, %23
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      if ((int64_t) v113 > v39 & (int64_t) ((uint64_t) v115 + (uint64_t) v41) % v42 == v21) {
        // pto: %window_values_inline617_inline5288__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v35);
        // pto: %window_values_inline617_inline5288__ssa_v0
        ;
        uint64_t v126 = (uint64_t) v21;
        TASSIGN(v125, v126);
        TEXPANDS(v125, v40);
        // pto: %window_scores_inline638_inline5289__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v35);
        // pto: %window_scores_inline638_inline5289__ssa_v0
        ;
        uint64_t v128 = (uint64_t) v22;
        TASSIGN(v127, v128);
        TEXPANDS(v127, v44);
        for (int64_t v129 = v39; v129 < v43; v129 += v36) {
          // pto: %27
          ;
          int64_t v130 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v115 + (uint64_t) v20) + (uint64_t) v129);
          // pto: %value_inline642_inline5258__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
          // pto: %value_inline642_inline5258__ssa_v0
          ;
          uint64_t v132 = (uint64_t) v23;
          TASSIGN(v131, v132);
          pipe_barrier(PIPE_V);
          TEXPANDS(v131, v40);
          // pto: %score_inline645_inline5292__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
          // pto: %score_inline645_inline5292__ssa_v0
          ;
          uint64_t v134 = (uint64_t) v24;
          TASSIGN(v133, v134);
          TEXPANDS(v133, v44);
          // pto: %28, %state_half_inline644_inline5304__phi_v2
          ;
          int64_t v135 = v129 >= v38 ? v35 : v39;
          // pto: %32
          ;
          bool v136 = v130 < v111;
          // pto: %30, %33
          ;
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
          if (v130 >= v39 & v136) {
            // pto: %score_inline645_inline5292__ssa_v1
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
            // pto: %score_inline645_inline5292__ssa_v1
            ;
            uint64_t v138 = (uint64_t) v25;
            TASSIGN(v137, v138);
            TEXPANDS(v137, v40);
            // pto: %flat_offset_mul, %flat_offset, %35, %34
            ;
            int32_t v139 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v15) + (uint64_t) (v130 / v45))];
            // pto: %37
            ;
            int64_t v140 = (int64_t) v139;
            // pto: %38
            ;
            if (v140 >= v39) {
              // pto: %39, %41, %42
              ;
              int64_t v141 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v130 % v45) * (uint64_t) v46) + (uint64_t) v135);
              // pto: %value_inline642_inline5258__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v142 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %value_inline642_inline5258__ssa_v1
              ;
              uint64_t v143 = (uint64_t) v26;
              TASSIGN(v142, v143);
              // pto: %43
              ;
              int64_t v144 = v140 < v39 ? v39 : v140;
              // pto: %44
              ;
              int64_t v145 = v141 < v39 ? v39 : v141;
              // pto: %compress_state__ssa_v0_pview
              ;
              int64_t v146 = (int64_t) v17;
              // pto: %compress_state__ssa_v0_pview
              ;
              const int64_t v147 = 0;
              // pto: %compress_state__ssa_v0_pview
              ;
              __gm__ float* v148 = PTOAS__GLOBAL_TENSOR_DATA(v65);
              // pto: %compress_state__ssa_v0_pview
              ;
              const int64_t v149 = 1;
              // pto: %compress_state__ssa_v0_pview
              ;
              const int64_t v150 = 1;
              // pto: %compress_state__ssa_v0_pview
              ;
              const int64_t v151 = 1;
              // pto: %compress_state__ssa_v0_pview
              ;
              int64_t v152 = v36 * v146;
              // pto: %compress_state__ssa_v0_pview
              ;
              int64_t v153 = v151 * v152;
              // pto: %compress_state__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 1, 512> v154 = pto::Shape<1, 1, 1, 1, 512>(v149, v150, v151, v36, v35);
              // pto: %compress_state__ssa_v0_pview
              ;
              pto::Stride<-1, -1, -1, -1, -1> v155 = pto::Stride<-1, -1, -1, -1, -1>(v150 * v153, v153, v152, v146, v36);
              // pto: %compress_state__ssa_v0_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v156 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v148 + (v147 + v144 * v146 + v145 * v36), v154, v155);
              TLOAD(v142, v156);
              // pto: %score_inline645_inline5292__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %score_inline645_inline5292__ssa_v2
              ;
              uint64_t v158 = (uint64_t) v27;
              TASSIGN(v157, v158);
              // pto: %46
              ;
              int64_t v159 = (int64_t) ((uint64_t) v141 + (uint64_t) v37);
              // pto: %47
              ;
              int64_t v160 = v159 < v39 ? v39 : v159;
              // pto: %48
              ;
              int64_t v161 = (int64_t) v17;
              // pto: %48
              ;
              const int64_t v162 = 0;
              // pto: %48
              ;
              __gm__ float* v163 = PTOAS__GLOBAL_TENSOR_DATA(v65);
              // pto: %48
              ;
              const int64_t v164 = 1;
              // pto: %48
              ;
              const int64_t v165 = 1;
              // pto: %48
              ;
              const int64_t v166 = 1;
              // pto: %48
              ;
              int64_t v167 = v36 * v161;
              // pto: %48
              ;
              int64_t v168 = v166 * v167;
              // pto: %48
              ;
              pto::Shape<1, 1, 1, 1, 512> v169 = pto::Shape<1, 1, 1, 1, 512>(v164, v165, v166, v36, v35);
              // pto: %48
              ;
              pto::Stride<-1, -1, -1, -1, -1> v170 = pto::Stride<-1, -1, -1, -1, -1>(v165 * v168, v168, v167, v161, v36);
              // pto: %48
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v171 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v163 + (v162 + v144 * v161 + v160 * v36), v169, v170);
              TLOAD(v157, v171);
            } else {
              // pto: %score_inline645_inline5292__ssa_v1_mv
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v172 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %score_inline645_inline5292__ssa_v1_mv
              ;
              uint64_t v173 = (uint64_t) v27;
              TASSIGN(v172, v173);
              pipe_barrier(PIPE_V);
              TMOV(v172, v137);
              // pto: %value_inline642_inline5258__ssa_v0_mv
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %value_inline642_inline5258__ssa_v0_mv
              ;
              uint64_t v175 = (uint64_t) v26;
              TASSIGN(v174, v175);
              TMOV(v174, v131);
            };
          } else {
            // pto: %score_inline645_inline5292__ssa_v0_mv
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v176 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
            // pto: %score_inline645_inline5292__ssa_v0_mv
            ;
            uint64_t v177 = (uint64_t) v27;
            TASSIGN(v176, v177);
            pipe_barrier(PIPE_V);
            TMOV(v176, v133);
            // pto: %0
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v178 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
            // pto: %0
            ;
            uint64_t v179 = (uint64_t) v26;
            TASSIGN(v178, v179);
            TMOV(v178, v131);
          };
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          // pto: %50
          ;
          bool v180 = v111 <= v130;
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
          if (v180) {
            // pto: %51
            ;
            if (v130 <= v115) {
              // pto: %54
              ;
              uint64_t v181 = (uint64_t) v111;
              // pto: %53, %54
              ;
              int64_t v182 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v108 + (uint64_t) v130) - v181);
              // pto: %55
              ;
              int64_t v183 = v130 % v42;
              // pto: %value_inline642_inline5258__ssa_v4
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %value_inline642_inline5258__ssa_v4
              ;
              uint64_t v185 = (uint64_t) v23;
              TASSIGN(v184, v185);
              // pto: %57
              ;
              int64_t v186 = v182 < v39 ? v39 : v182;
              // pto: %58
              ;
              int64_t v187 = v135 < v39 ? v39 : v135;
              // pto: %cmp4_kv_proj_pad_inline624_inline5253__ssa_v0_pview
              ;
              __gm__ float* v188 = PTOAS__GLOBAL_TENSOR_DATA(v73);
              // pto: %cmp4_kv_proj_pad_inline624_inline5253__ssa_v0_pview
              ;
              const int64_t v189 = 0;
              // pto: %cmp4_kv_proj_pad_inline624_inline5253__ssa_v0_pview
              ;
              const int64_t v190 = 1024;
              // pto: %cmp4_kv_proj_pad_inline624_inline5253__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 1, 512> v191 = pto::Shape<1, 1, 1, 1, 512>();
              // pto: %cmp4_kv_proj_pad_inline624_inline5253__ssa_v0_pview
              ;
              pto::Stride<1024, 1024, 1024, 1024, 1> v192 = pto::Stride<1024, 1024, 1024, 1024, 1>();
              // pto: %cmp4_kv_proj_pad_inline624_inline5253__ssa_v0_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v193 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v188 + (v189 + v186 * v190 + v187), v191, v192);
              TLOAD(v184, v193);
              // pto: %t__tmp_v232
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v194 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %t__tmp_v232
              ;
              uint64_t v195 = (uint64_t) v24;
              TASSIGN(v194, v195);
              // pto: %cmp4_score_proj_pad_inline628_inline5252__ssa_v0_pview
              ;
              __gm__ float* v196 = PTOAS__GLOBAL_TENSOR_DATA(v81);
              // pto: %cmp4_score_proj_pad_inline628_inline5252__ssa_v0_pview
              ;
              const int64_t v197 = 0;
              // pto: %cmp4_score_proj_pad_inline628_inline5252__ssa_v0_pview
              ;
              const int64_t v198 = 1024;
              // pto: %cmp4_score_proj_pad_inline628_inline5252__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 1, 512> v199 = pto::Shape<1, 1, 1, 1, 512>();
              // pto: %cmp4_score_proj_pad_inline628_inline5252__ssa_v0_pview
              ;
              pto::Stride<1024, 1024, 1024, 1024, 1> v200 = pto::Stride<1024, 1024, 1024, 1024, 1>();
              // pto: %cmp4_score_proj_pad_inline628_inline5252__ssa_v0_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v201 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v196 + (v197 + v186 * v198 + v187), v199, v200);
              TLOAD(v194, v201);
              // pto: %t__tmp_v233
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v202 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %t__tmp_v233
              ;
              uint64_t v203 = (uint64_t) v25;
              TASSIGN(v202, v203);
              // pto: %61
              ;
              int64_t v204 = v183 < v39 ? v39 : v183;
              // pto: %cmp_ape__ssa_v0_pview
              ;
              __gm__ float* v205 = PTOAS__GLOBAL_TENSOR_DATA(v89);
              // pto: %cmp_ape__ssa_v0_pview
              ;
              const int64_t v206 = 0;
              // pto: %cmp_ape__ssa_v0_pview
              ;
              const int64_t v207 = 1024;
              // pto: %cmp_ape__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 1, 512> v208 = pto::Shape<1, 1, 1, 1, 512>();
              // pto: %cmp_ape__ssa_v0_pview
              ;
              pto::Stride<1024, 1024, 1024, 1024, 1> v209 = pto::Stride<1024, 1024, 1024, 1024, 1>();
              // pto: %cmp_ape__ssa_v0_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v210 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v205 + (v206 + v204 * v207 + v187), v208, v209);
              TLOAD(v202, v210);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
              // pto: %score_inline645_inline5292__ssa_v5
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %score_inline645_inline5292__ssa_v5
              ;
              uint64_t v212 = (uint64_t) v24;
              TASSIGN(v211, v212);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
              TADD(v211, v194, v202);
            } else {
              // pto: %score_inline645_inline5292__phi_v4_mv
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %score_inline645_inline5292__phi_v4_mv
              ;
              uint64_t v214 = (uint64_t) v24;
              TASSIGN(v213, v214);
              pipe_barrier(PIPE_V);
              TMOV(v213, v90);
              // pto: %value_inline642_inline5258__phi_v3_mv
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
              // pto: %value_inline642_inline5258__phi_v3_mv
              ;
              uint64_t v216 = (uint64_t) v23;
              TASSIGN(v215, v216);
              TMOV(v215, v92);
            };
          } else {
            // pto: %1
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
            // pto: %1
            ;
            uint64_t v218 = (uint64_t) v24;
            TASSIGN(v217, v218);
            pipe_barrier(PIPE_V);
            TMOV(v217, v90);
            // pto: %2
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v219 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
            // pto: %2
            ;
            uint64_t v220 = (uint64_t) v23;
            TASSIGN(v219, v220);
            TMOV(v219, v92);
          };
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
          // pto: %63, %64, %66, %65, %assemble_view
          ;
          int64_t v221 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) (v129 % v38) * (uint64_t) v47) + (uint64_t) (v129 / v38)) * (uint64_t) v33);
          // pto: %assemble_view
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v222;
          // pto: %assemble_view
          ;
          uint64_t v223 = (uint64_t) v221;
          TASSIGN(v222, v223);
          pipe_barrier(PIPE_V);
          TMOV(v222, v100);
          // pto: %67
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v224;
          // pto: %67
          ;
          uint64_t v225 = (uint64_t) ((int64_t) (uint64_t) v221 + (uint64_t) v22);
          TASSIGN(v224, v225);
          TMOV(v224, v98);
        };
        // pto: %t__tmp_v234
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v226 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %t__tmp_v234
        ;
        uint64_t v227 = (uint64_t) v22;
        TASSIGN(v226, v227);
        // pto: %slice_view
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, 4, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v228;
        // pto: %slice_view
        ;
        uint64_t v229 = (uint64_t) v22;
        TASSIGN(v228, v229);
        // pto: %t__tmp_v235
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v230 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %t__tmp_v235
        ;
        uint64_t v231 = (uint64_t) v28;
        TASSIGN(v230, v231);
        // pto: %68
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, 4, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v232;
        // pto: %68
        ;
        uint64_t v233 = (uint64_t) v28;
        TASSIGN(v232, v233);
        // pto: %max4_inline615_inline5298__ssa_v0
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %max4_inline615_inline5298__ssa_v0
        ;
        uint64_t v235 = (uint64_t) v23;
        TASSIGN(v234, v235);
        pipe_barrier(PIPE_V);
        TMAX(v234, v228, v232);
        // pto: %t__tmp_v236
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %t__tmp_v236
        ;
        uint64_t v237 = (uint64_t) v23;
        TASSIGN(v236, v237);
        // pto: %69
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, 2, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v238;
        // pto: %69
        ;
        uint64_t v239 = (uint64_t) v23;
        TASSIGN(v238, v239);
        // pto: %t__tmp_v237
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %t__tmp_v237
        ;
        uint64_t v241 = (uint64_t) v29;
        TASSIGN(v240, v241);
        // pto: %70
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, 2, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v242;
        // pto: %70
        ;
        uint64_t v243 = (uint64_t) v29;
        TASSIGN(v242, v243);
        // pto: %max2_inline614_inline5302__ssa_v0
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %max2_inline614_inline5302__ssa_v0
        ;
        uint64_t v245 = (uint64_t) v23;
        TASSIGN(v244, v245);
        pipe_barrier(PIPE_V);
        TMAX(v244, v238, v242);
        // pto: %t__tmp_v238
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %t__tmp_v238
        ;
        uint64_t v247 = (uint64_t) v23;
        TASSIGN(v246, v247);
        // pto: %71
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v248;
        // pto: %71
        ;
        uint64_t v249 = (uint64_t) v23;
        TASSIGN(v248, v249);
        // pto: %t__tmp_v239
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v250 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %t__tmp_v239
        ;
        uint64_t v251 = (uint64_t) v30;
        TASSIGN(v250, v251);
        // pto: %72
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v252;
        // pto: %72
        ;
        uint64_t v253 = (uint64_t) v30;
        TASSIGN(v252, v253);
        // pto: %maximum_inline620_inline5303__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v254 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %maximum_inline620_inline5303__ssa_v0
        ;
        uint64_t v255 = (uint64_t) v23;
        TASSIGN(v254, v255);
        pipe_barrier(PIPE_V);
        TMAX(v254, v248, v252);
        // pto: %t__tmp_v240
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v256 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v35);
        // pto: %t__tmp_v240
        ;
        uint64_t v257 = (uint64_t) v22;
        TASSIGN(v256, v257);
        pipe_barrier(PIPE_V);
        TCOLEXPANDSUB(v256, v127, v254);
        // pto: %probability_inline613_inline5286__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v258 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v35);
        // pto: %probability_inline613_inline5286__ssa_v0
        ;
        uint64_t v259 = (uint64_t) v22;
        TASSIGN(v258, v259);
        pipe_barrier(PIPE_V);
        TEXP(v258, v256);
        // pto: %t__tmp_v241
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v260 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %t__tmp_v241
        ;
        uint64_t v261 = (uint64_t) v22;
        TASSIGN(v260, v261);
        // pto: %73
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, 4, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v262;
        // pto: %73
        ;
        uint64_t v263 = (uint64_t) v22;
        TASSIGN(v262, v263);
        // pto: %t__tmp_v242
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v264 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %t__tmp_v242
        ;
        uint64_t v265 = (uint64_t) v28;
        TASSIGN(v264, v265);
        // pto: %74
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, 4, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v266;
        // pto: %74
        ;
        uint64_t v267 = (uint64_t) v28;
        TASSIGN(v266, v267);
        // pto: %sum4_inline612_inline5293__ssa_v0
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v268 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %sum4_inline612_inline5293__ssa_v0
        ;
        uint64_t v269 = (uint64_t) v23;
        TASSIGN(v268, v269);
        pipe_barrier(PIPE_V);
        TADD(v268, v262, v266);
        // pto: %t__tmp_v243
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %t__tmp_v243
        ;
        uint64_t v271 = (uint64_t) v23;
        TASSIGN(v270, v271);
        // pto: %75
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, 2, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v272;
        // pto: %75
        ;
        uint64_t v273 = (uint64_t) v23;
        TASSIGN(v272, v273);
        // pto: %t__tmp_v244
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v274 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %t__tmp_v244
        ;
        uint64_t v275 = (uint64_t) v29;
        TASSIGN(v274, v275);
        // pto: %76
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, 2, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v276;
        // pto: %76
        ;
        uint64_t v277 = (uint64_t) v29;
        TASSIGN(v276, v277);
        // pto: %sum2_inline611_inline5291__ssa_v0
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v278 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %sum2_inline611_inline5291__ssa_v0
        ;
        uint64_t v279 = (uint64_t) v23;
        TASSIGN(v278, v279);
        pipe_barrier(PIPE_V);
        TADD(v278, v272, v276);
        // pto: %t__tmp_v245
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v280 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %t__tmp_v245
        ;
        uint64_t v281 = (uint64_t) v23;
        TASSIGN(v280, v281);
        // pto: %77
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v282;
        // pto: %77
        ;
        uint64_t v283 = (uint64_t) v23;
        TASSIGN(v282, v283);
        // pto: %t__tmp_v246
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v284 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %t__tmp_v246
        ;
        uint64_t v285 = (uint64_t) v30;
        TASSIGN(v284, v285);
        // pto: %78
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v286;
        // pto: %78
        ;
        uint64_t v287 = (uint64_t) v30;
        TASSIGN(v286, v287);
        // pto: %total_inline610_inline5305__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v288 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %total_inline610_inline5305__ssa_v0
        ;
        uint64_t v289 = (uint64_t) v23;
        TASSIGN(v288, v289);
        pipe_barrier(PIPE_V);
        TADD(v288, v282, v286);
        // pto: %probability_v1_inline609_inline5307__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v35);
        // pto: %probability_v1_inline609_inline5307__ssa_v0
        ;
        uint64_t v291 = (uint64_t) v22;
        TASSIGN(v290, v291);
        pipe_barrier(PIPE_V);
        TCOLEXPANDDIV(v290, v258, v288);
        // pto: %weighted_inline608_inline5246__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v292 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v43, v35);
        // pto: %weighted_inline608_inline5246__ssa_v0
        ;
        uint64_t v293 = (uint64_t) v21;
        TASSIGN(v292, v293);
        pipe_barrier(PIPE_V);
        TMUL(v292, v125, v290);
        // pto: %t__tmp_v247
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v294 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %t__tmp_v247
        ;
        uint64_t v295 = (uint64_t) v21;
        TASSIGN(v294, v295);
        // pto: %79
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, 4, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v296;
        // pto: %79
        ;
        uint64_t v297 = (uint64_t) v21;
        TASSIGN(v296, v297);
        // pto: %t__tmp_v248
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %t__tmp_v248
        ;
        uint64_t v299 = (uint64_t) v31;
        TASSIGN(v298, v299);
        // pto: %80
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, 4, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v300;
        // pto: %80
        ;
        uint64_t v301 = (uint64_t) v31;
        TASSIGN(v300, v301);
        // pto: %weighted4_inline643_inline5306__ssa_v0
        ;
        Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v302 = Tile<TileType::Vec, float, 4, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v35);
        // pto: %weighted4_inline643_inline5306__ssa_v0
        ;
        uint64_t v303 = (uint64_t) v21;
        TASSIGN(v302, v303);
        pipe_barrier(PIPE_V);
        TADD(v302, v296, v300);
        // pto: %t__tmp_v249
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v304 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %t__tmp_v249
        ;
        uint64_t v305 = (uint64_t) v21;
        TASSIGN(v304, v305);
        // pto: %81
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, 2, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306;
        // pto: %81
        ;
        uint64_t v307 = (uint64_t) v21;
        TASSIGN(v306, v307);
        // pto: %t__tmp_v250
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v308 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %t__tmp_v250
        ;
        uint64_t v309 = (uint64_t) v32;
        TASSIGN(v308, v309);
        // pto: %82
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, 2, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v310;
        // pto: %82
        ;
        uint64_t v311 = (uint64_t) v32;
        TASSIGN(v310, v311);
        // pto: %weighted2_inline632_inline5299__ssa_v0
        ;
        Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Vec, float, 2, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v47, v35);
        // pto: %weighted2_inline632_inline5299__ssa_v0
        ;
        uint64_t v313 = (uint64_t) v21;
        TASSIGN(v312, v313);
        pipe_barrier(PIPE_V);
        TADD(v312, v306, v310);
        // pto: %t__tmp_v251
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v314 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %t__tmp_v251
        ;
        uint64_t v315 = (uint64_t) v21;
        TASSIGN(v314, v315);
        // pto: %83
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v316;
        // pto: %83
        ;
        uint64_t v317 = (uint64_t) v21;
        TASSIGN(v316, v317);
        // pto: %t__tmp_v252
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v318 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %t__tmp_v252
        ;
        uint64_t v319 = (uint64_t) v33;
        TASSIGN(v318, v319);
        // pto: %84
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v320;
        // pto: %84
        ;
        uint64_t v321 = (uint64_t) v33;
        TASSIGN(v320, v321);
        // pto: %pooled_row_inline607_inline5247__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v322 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v36, v35);
        // pto: %pooled_row_inline607_inline5247__ssa_v0
        ;
        uint64_t v323 = (uint64_t) v21;
        TASSIGN(v322, v323);
        pipe_barrier(PIPE_V);
        TADD(v322, v316, v320);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v124, v322);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}