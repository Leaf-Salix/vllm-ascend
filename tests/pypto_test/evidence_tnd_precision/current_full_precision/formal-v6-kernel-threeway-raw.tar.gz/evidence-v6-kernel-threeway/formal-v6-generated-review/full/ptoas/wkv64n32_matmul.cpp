#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void wkv64n32_matmul(__gm__ int32_t* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, __gm__ float* v4, int64_t v5, int64_t v6, int64_t v7, int32_t v8, int32_t v9) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v10 = 0;
  // pto: %c32768_i64
  const int64_t v11 = 32768;
  const int64_t v12 = 32;
  // pto: %c16_index
  const int64_t v13 = 16;
  // pto: %c1_index
  const int64_t v14 = 1;
  // pto: %c4096_index
  const int64_t v15 = 4096;
  // pto: %c512_index
  const int64_t v16 = 512;
  // pto: %c64_index
  const int64_t v17 = 64;
  // pto: %c2_index
  const int64_t v18 = 2;
  // pto: %c0_index
  const int64_t v19 = 0;
  // pto: %c256_index
  const int64_t v20 = 256;
  // pto: %c63_index
  const int64_t v21 = 63;
  // pto: %normed__ssa_v0_view
  const int64_t v22 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v23 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %normed__ssa_v0_view
  int64_t v25 = (int64_t) v6;
  // pto: %normed__ssa_v0_view
  int64_t v26 = v25 * v15;
  // pto: %normed__ssa_v0_view
  int64_t v27 = v24 * v26;
  // pto: %normed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v28 = pto::Shape<1, 1, 1, -1, -1>(v22, v23, v24, v25, v15);
  // pto: %normed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v29 = pto::Stride<-1, -1, -1, -1, -1>(v23 * v27, v27, v26, v15, v14);
  // pto: %normed__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v30 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v28, v29);
  // pto: %wkv__ssa_v0_view
  const int64_t v31 = 1;
  // pto: %wkv__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %wkv__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %wkv__ssa_v0_view
  int64_t v34 = v16 * v15;
  // pto: %wkv__ssa_v0_view
  int64_t v35 = v33 * v34;
  // pto: %wkv__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v36 = pto::Shape<1, 1, 1, -1, -1>(v31, v32, v33, v16, v15);
  // pto: %wkv__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v37 = pto::Stride<-1, -1, -1, -1, -1>(v32 * v35, v35, v34, v15, v14);
  // pto: %wkv__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v38 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v36, v37);
  // pto: %64
  int64_t v39 = (int64_t) ((uint64_t) v7 + (uint64_t) v21);
  // pto: %accum_inline1275__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %accum_inline1275__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %accum_inline1275__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %accum_inline1275__ssa_v0_view
  int64_t v43 = v39 * v16;
  // pto: %accum_inline1275__ssa_v0_view
  int64_t v44 = v42 * v43;
  // pto: %accum_inline1275__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v45 = pto::Shape<1, 1, 1, -1, -1>(v40, v41, v42, v39, v16);
  // pto: %accum_inline1275__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v41 * v44, v44, v43, v16, v14);
  // pto: %accum_inline1275__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v47 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v45, v46);
  // pto: %worker_inline1284__ssa_v0
  int64_t v48 = (int64_t) v8;
  // pto: %2, %3
  int64_t v49 = (int64_t) ((uint64_t) (v48 / v13) * (uint64_t) v17);
  // pto: %4
  int64_t v50 = v48 % v13;
  // pto: %5
  int64_t v51 = (int64_t) ((uint64_t) v50 * (uint64_t) v18);
  int64_t v52 = (int64_t) ((uint64_t) v50 * (uint64_t) v12);
  // pto: %7
  int64_t v53 = (int64_t) ((uint64_t) v7 - (uint64_t) v49);
  // pto: %8
  int64_t v54 = v53 < v17 ? v53 : v17;
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  // pto: %same_order_inline1285__rv_v2
  int64_t v55;
  v55 = v14;
  for (int64_t v56 = v19; v56 < v13; v56 += v14) {
    // pto: %flat_offset, %t__tile
    ;
    int32_t v57 = (v1)[(int64_t) ((uint64_t) v52 + (uint64_t) v56)];
    // pto: %10, %11, %12, %9
    ;
    int32_t v58 = (v1)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v51 + (uint64_t) v14) * (uint64_t) v13) + (uint64_t) v56)];
    // pto: %13, %same_order_inline1285__phi_v4
    ;
    int64_t v59 = v57 != v58 ? v19 : v55;
    v55 = v59;
  }
  // pto: %14
  bool v60 = v55 == v14;
  if (v60) {
    // pto: %first_block_inline1291__tile
    ;
    int32_t v61 = (v1)[v52];
    // pto: %17
    ;
    int64_t v62 = (int64_t) v61;
    // pto: %18
    ;
    int64_t v63 = v62 < v19 ? v19 : v62;
    // pto: %19
    ;
    int64_t v64 = (int64_t) ((uint64_t) v63 * (uint64_t) v20);
    // pto: %first_a_inline1287__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v65 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v54, v20);
    // pto: %first_a_inline1287__tile
    ;
    uint64_t v66 = (uint64_t) v10;
    TASSIGN(v65, v66);
    // pto: %20
    ;
    int64_t v67 = v49 < v19 ? v19 : v49;
    // pto: %21
    ;
    int64_t v68 = v64 < v19 ? v19 : v64;
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v69 = 0;
    // pto: %normed__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v70 = PTOAS__GLOBAL_TENSOR_DATA(v30);
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v71 = 1;
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v72 = 1;
    // pto: %normed__ssa_v0_pview
    ;
    const int64_t v73 = 1;
    // pto: %normed__ssa_v0_pview
    ;
    int64_t v74 = v54 * v15;
    // pto: %normed__ssa_v0_pview
    ;
    int64_t v75 = v73 * v74;
    // pto: %normed__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 256> v76 = pto::Shape<1, 1, 1, -1, 256>(v71, v72, v73, v54, v20);
    // pto: %normed__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v77 = pto::Stride<-1, -1, -1, -1, -1>(v72 * v75, v75, v74, v15, v14);
    // pto: %normed__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v78 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v70 + (v69 + v67 * v15 + v68 * v14), v76, v77);
    TLOAD(v65, v78);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %first_b_inline1283__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v79 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v12, v20);
    // pto: %first_b_inline1283__tile
    ;
    uint64_t v80 = (uint64_t) v11;
    TASSIGN(v79, v80);
    // pto: %22
    ;
    int64_t v81 = v52 < v19 ? v19 : v52;
    // pto: %wkv__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v82 = PTOAS__GLOBAL_TENSOR_DATA(v38);
    // pto: %wkv__ssa_v0_pview
    ;
    const int64_t v83 = 0;
    // pto: %wkv__ssa_v0_pview
    ;
    const int64_t v84 = 4096;
    // pto: %wkv__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 256> v85 = pto::Shape<1, 1, 1, 32, 256>();
    // pto: %wkv__ssa_v0_pview
    ;
    pto::Stride<131072, 131072, 131072, 4096, 1> v86 = pto::Stride<131072, 131072, 131072, 4096, 1>();
    // pto: %wkv__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v87 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v82 + (v83 + v81 * v84 + v68), v85, v86);
    TLOAD(v79, v87);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    // pto: %first_b_inline1283__tile_t
    ;
    Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v12);
    // pto: %first_b_inline1283__tile_t
    ;
    uint64_t v89 = (uint64_t) v11;
    TASSIGN(v88, v89);
    // pto: %first_a_inline1287__tile_Left
    ;
    Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v54, v20);
    // pto: %first_a_inline1287__tile_Left
    ;
    uint64_t v91 = (uint64_t) v10;
    TASSIGN(v90, v91);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    TMOV(v90, v65);
    // pto: %first_b_inline1283__tile_t_Right
    ;
    Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v92 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v12);
    // pto: %first_b_inline1283__tile_t_Right
    ;
    uint64_t v93 = (uint64_t) v10;
    TASSIGN(v92, v93);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
    TMOV(v92, v88);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    // pto: %wide_tile_inline1294__tile
    ;
    Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v94 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v54, v12);
    // pto: %wide_tile_inline1294__tile
    ;
    uint64_t v95 = (uint64_t) v10;
    TASSIGN(v94, v95);
    wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
    TMATMUL(v94, v90, v92);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    for (int64_t v96 = v14; v96 < v13; v96 += v14) {
      // pto: %25, %k_block_inline1289__tile
      ;
      int32_t v97 = (v1)[(int64_t) ((uint64_t) v52 + (uint64_t) v96)];
      // pto: %26
      ;
      int64_t v98 = (int64_t) v97;
      // pto: %27
      ;
      int64_t v99 = v98 < v19 ? v19 : v98;
      // pto: %28
      ;
      int64_t v100 = (int64_t) ((uint64_t) v99 * (uint64_t) v20);
      // pto: %a_inline1265__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v54, v20);
      // pto: %a_inline1265__tile
      ;
      uint64_t v102 = (uint64_t) v10;
      TASSIGN(v101, v102);
      // pto: %30
      ;
      int64_t v103 = v100 < v19 ? v19 : v100;
      // pto: %31
      ;
      const int64_t v104 = 0;
      // pto: %31
      ;
      __gm__ bfloat16_t* v105 = PTOAS__GLOBAL_TENSOR_DATA(v30);
      // pto: %31
      ;
      const int64_t v106 = 1;
      // pto: %31
      ;
      const int64_t v107 = 1;
      // pto: %31
      ;
      const int64_t v108 = 1;
      // pto: %31
      ;
      int64_t v109 = v54 * v15;
      // pto: %31
      ;
      int64_t v110 = v108 * v109;
      // pto: %31
      ;
      pto::Shape<1, 1, 1, -1, 256> v111 = pto::Shape<1, 1, 1, -1, 256>(v106, v107, v108, v54, v20);
      // pto: %31
      ;
      pto::Stride<-1, -1, -1, -1, -1> v112 = pto::Stride<-1, -1, -1, -1, -1>(v107 * v110, v110, v109, v15, v14);
      // pto: %31
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v113 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v105 + (v104 + v67 * v15 + v103 * v14), v111, v112);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v101, v113);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      // pto: %b_inline1260__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v12, v20);
      // pto: %b_inline1260__tile
      ;
      uint64_t v115 = (uint64_t) v11;
      TASSIGN(v114, v115);
      // pto: %34
      ;
      __gm__ bfloat16_t* v116 = PTOAS__GLOBAL_TENSOR_DATA(v38);
      // pto: %34
      ;
      const int64_t v117 = 0;
      // pto: %34
      ;
      const int64_t v118 = 4096;
      // pto: %34
      ;
      pto::Shape<1, 1, 1, 32, 256> v119 = pto::Shape<1, 1, 1, 32, 256>();
      // pto: %34
      ;
      pto::Stride<131072, 131072, 131072, 4096, 1> v120 = pto::Stride<131072, 131072, 131072, 4096, 1>();
      // pto: %34
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v121 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v116 + (v117 + v81 * v118 + v103), v119, v120);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      TLOAD(v114, v121);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %b_inline1260__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v12);
      // pto: %b_inline1260__tile_t
      ;
      uint64_t v123 = (uint64_t) v11;
      TASSIGN(v122, v123);
      // pto: %a_inline1265__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v54, v20);
      // pto: %a_inline1265__tile_Left
      ;
      uint64_t v125 = (uint64_t) v10;
      TASSIGN(v124, v125);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      TMOV(v124, v101);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %b_inline1260__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v126 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v12);
      // pto: %b_inline1260__tile_t_Right
      ;
      uint64_t v127 = (uint64_t) v10;
      TASSIGN(v126, v127);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      TMOV(v126, v122);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v94, v94, v124, v126);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
    };
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    // pto: %accum_inline1275__ssa_v0_pview
    ;
    const int64_t v128 = 0;
    // pto: %accum_inline1275__ssa_v0_pview
    ;
    __gm__ float* v129 = PTOAS__GLOBAL_TENSOR_DATA(v47);
    // pto: %accum_inline1275__ssa_v0_pview
    ;
    const int64_t v130 = 1;
    // pto: %accum_inline1275__ssa_v0_pview
    ;
    const int64_t v131 = 1;
    // pto: %accum_inline1275__ssa_v0_pview
    ;
    const int64_t v132 = 1;
    // pto: %accum_inline1275__ssa_v0_pview
    ;
    int64_t v133 = v54 * v16;
    // pto: %accum_inline1275__ssa_v0_pview
    ;
    int64_t v134 = v132 * v133;
    // pto: %accum_inline1275__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 32> v135 = pto::Shape<1, 1, 1, -1, 32>(v130, v131, v132, v54, v12);
    // pto: %accum_inline1275__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v136 = pto::Stride<-1, -1, -1, -1, -1>(v131 * v134, v134, v133, v16, v14);
    // pto: %accum_inline1275__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v137 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v129 + (v128 + v67 * v16 + v81 * v14), v135, v136);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
    TSTORE(v137, v94);
  } else {
    for (int64_t v138 = v19; v138 < v18; v138 += v14) {
      // pto: %37, %38
      ;
      int64_t v139 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v51 + (uint64_t) v138) * (uint64_t) v13);
      // pto: %narrow_first_block_inline1257__tile
      ;
      int32_t v140 = (v1)[v139];
      // pto: %41
      ;
      int64_t v141 = (int64_t) v140;
      // pto: %42
      ;
      int64_t v142 = v141 < v19 ? v19 : v141;
      // pto: %43
      ;
      int64_t v143 = (int64_t) ((uint64_t) v142 * (uint64_t) v20);
      // pto: %narrow_first_a_inline1253__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v144 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v54, v20);
      // pto: %narrow_first_a_inline1253__tile
      ;
      uint64_t v145 = (uint64_t) v10;
      TASSIGN(v144, v145);
      // pto: %44
      ;
      int64_t v146 = v49 < v19 ? v19 : v49;
      // pto: %45
      ;
      int64_t v147 = v143 < v19 ? v19 : v143;
      // pto: %46
      ;
      const int64_t v148 = 0;
      // pto: %46
      ;
      __gm__ bfloat16_t* v149 = PTOAS__GLOBAL_TENSOR_DATA(v30);
      // pto: %46
      ;
      const int64_t v150 = 1;
      // pto: %46
      ;
      const int64_t v151 = 1;
      // pto: %46
      ;
      const int64_t v152 = 1;
      // pto: %46
      ;
      int64_t v153 = v54 * v15;
      // pto: %46
      ;
      int64_t v154 = v152 * v153;
      // pto: %46
      ;
      pto::Shape<1, 1, 1, -1, 256> v155 = pto::Shape<1, 1, 1, -1, 256>(v150, v151, v152, v54, v20);
      // pto: %46
      ;
      pto::Stride<-1, -1, -1, -1, -1> v156 = pto::Stride<-1, -1, -1, -1, -1>(v151 * v154, v154, v153, v15, v14);
      // pto: %46
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v157 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v149 + (v148 + v146 * v15 + v147 * v14), v155, v156);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v144, v157);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      // pto: %narrow_first_b_inline1252__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v158 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v13, v20);
      // pto: %narrow_first_b_inline1252__tile
      ;
      uint64_t v159 = (uint64_t) v11;
      TASSIGN(v158, v159);
      // pto: %47
      ;
      int64_t v160 = v139 < v19 ? v19 : v139;
      // pto: %49
      ;
      __gm__ bfloat16_t* v161 = PTOAS__GLOBAL_TENSOR_DATA(v38);
      // pto: %49
      ;
      const int64_t v162 = 0;
      // pto: %49
      ;
      const int64_t v163 = 4096;
      // pto: %49
      ;
      pto::Shape<1, 1, 1, 16, 256> v164 = pto::Shape<1, 1, 1, 16, 256>();
      // pto: %49
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v165 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %49
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v166 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v161 + (v162 + v160 * v163 + v147), v164, v165);
      TLOAD(v158, v166);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      // pto: %narrow_first_b_inline1252__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v13);
      // pto: %narrow_first_b_inline1252__tile_t
      ;
      uint64_t v168 = (uint64_t) v11;
      TASSIGN(v167, v168);
      // pto: %narrow_first_a_inline1253__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v54, v20);
      // pto: %narrow_first_a_inline1253__tile_Left
      ;
      uint64_t v170 = (uint64_t) v10;
      TASSIGN(v169, v170);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      TMOV(v169, v144);
      // pto: %narrow_first_b_inline1252__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v171 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v13);
      // pto: %narrow_first_b_inline1252__tile_t_Right
      ;
      uint64_t v172 = (uint64_t) v10;
      TASSIGN(v171, v172);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
      TMOV(v171, v167);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
      // pto: %narrow_tile_inline1251__tile
      ;
      Tile<TileType::Acc, float, 64, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v173 = Tile<TileType::Acc, float, 64, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v54, v13);
      // pto: %narrow_tile_inline1251__tile
      ;
      uint64_t v174 = (uint64_t) v10;
      TASSIGN(v173, v174);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
      TMATMUL(v173, v169, v171);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      for (int64_t v175 = v14; v175 < v13; v175 += v14) {
        // pto: %51, %narrow_block_inline1256__tile
        ;
        int32_t v176 = (v1)[(int64_t) ((uint64_t) v139 + (uint64_t) v175)];
        // pto: %52
        ;
        int64_t v177 = (int64_t) v176;
        // pto: %53
        ;
        int64_t v178 = v177 < v19 ? v19 : v177;
        // pto: %54
        ;
        int64_t v179 = (int64_t) ((uint64_t) v178 * (uint64_t) v20);
        // pto: %narrow_a_inline1249__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v180 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v54, v20);
        // pto: %narrow_a_inline1249__tile
        ;
        uint64_t v181 = (uint64_t) v10;
        TASSIGN(v180, v181);
        // pto: %56
        ;
        int64_t v182 = v179 < v19 ? v19 : v179;
        // pto: %57
        ;
        const int64_t v183 = 0;
        // pto: %57
        ;
        __gm__ bfloat16_t* v184 = PTOAS__GLOBAL_TENSOR_DATA(v30);
        // pto: %57
        ;
        const int64_t v185 = 1;
        // pto: %57
        ;
        const int64_t v186 = 1;
        // pto: %57
        ;
        const int64_t v187 = 1;
        // pto: %57
        ;
        int64_t v188 = v54 * v15;
        // pto: %57
        ;
        int64_t v189 = v187 * v188;
        // pto: %57
        ;
        pto::Shape<1, 1, 1, -1, 256> v190 = pto::Shape<1, 1, 1, -1, 256>(v185, v186, v187, v54, v20);
        // pto: %57
        ;
        pto::Stride<-1, -1, -1, -1, -1> v191 = pto::Stride<-1, -1, -1, -1, -1>(v186 * v189, v189, v188, v15, v14);
        // pto: %57
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v192 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v184 + (v183 + v146 * v15 + v182 * v14), v190, v191);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        TLOAD(v180, v192);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        // pto: %narrow_b_inline1259__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v193 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v13, v20);
        // pto: %narrow_b_inline1259__tile
        ;
        uint64_t v194 = (uint64_t) v11;
        TASSIGN(v193, v194);
        // pto: %60
        ;
        __gm__ bfloat16_t* v195 = PTOAS__GLOBAL_TENSOR_DATA(v38);
        // pto: %60
        ;
        const int64_t v196 = 0;
        // pto: %60
        ;
        const int64_t v197 = 4096;
        // pto: %60
        ;
        pto::Shape<1, 1, 1, 16, 256> v198 = pto::Shape<1, 1, 1, 16, 256>();
        // pto: %60
        ;
        pto::Stride<65536, 65536, 65536, 4096, 1> v199 = pto::Stride<65536, 65536, 65536, 4096, 1>();
        // pto: %60
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v200 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v195 + (v196 + v160 * v197 + v182), v198, v199);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
        TLOAD(v193, v200);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        // pto: %narrow_b_inline1259__tile_t
        ;
        Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v13);
        // pto: %narrow_b_inline1259__tile_t
        ;
        uint64_t v202 = (uint64_t) v11;
        TASSIGN(v201, v202);
        // pto: %narrow_a_inline1249__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v203 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v54, v20);
        // pto: %narrow_a_inline1249__tile_Left
        ;
        uint64_t v204 = (uint64_t) v10;
        TASSIGN(v203, v204);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        TMOV(v203, v180);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        // pto: %narrow_b_inline1259__tile_t_Right
        ;
        Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v20, v13);
        // pto: %narrow_b_inline1259__tile_t_Right
        ;
        uint64_t v206 = (uint64_t) v10;
        TASSIGN(v205, v206);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        TMOV(v205, v201);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        TMATMUL_ACC(v173, v173, v203, v205);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      // pto: %accum_inline1275__iter_v3_pview
      ;
      const int64_t v207 = 0;
      // pto: %accum_inline1275__iter_v3_pview
      ;
      __gm__ float* v208 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %accum_inline1275__iter_v3_pview
      ;
      const int64_t v209 = 1;
      // pto: %accum_inline1275__iter_v3_pview
      ;
      const int64_t v210 = 1;
      // pto: %accum_inline1275__iter_v3_pview
      ;
      const int64_t v211 = 1;
      // pto: %accum_inline1275__iter_v3_pview
      ;
      int64_t v212 = v54 * v16;
      // pto: %accum_inline1275__iter_v3_pview
      ;
      int64_t v213 = v211 * v212;
      // pto: %accum_inline1275__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, -1, 16> v214 = pto::Shape<1, 1, 1, -1, 16>(v209, v210, v211, v54, v13);
      // pto: %accum_inline1275__iter_v3_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v215 = pto::Stride<-1, -1, -1, -1, -1>(v210 * v213, v213, v212, v16, v14);
      // pto: %accum_inline1275__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v216 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v208 + (v207 + v146 * v16 + v160 * v14), v214, v215);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      TSTORE(v216, v173);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}