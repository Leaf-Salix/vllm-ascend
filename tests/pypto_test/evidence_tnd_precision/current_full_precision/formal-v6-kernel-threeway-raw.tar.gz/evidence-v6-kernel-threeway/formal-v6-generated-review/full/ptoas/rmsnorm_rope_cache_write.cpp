#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void rmsnorm_rope_cache_write(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ int32_t* v3, __gm__ float* v4, __gm__ float* v5, __gm__ float* v6, __gm__ float* v7, __gm__ bfloat16_t* v8, __gm__ bfloat16_t* v9, __gm__ float* v10, __gm__ int32_t* v11, int64_t v12, int64_t v13, int64_t v14, int64_t v15, int64_t v16, int32_t v17, int32_t v18) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v19 = 256;
  // pto: %c0_i64
  const int64_t v20 = 0;
  // pto: %c4096_i64
  const int64_t v21 = 4096;
  // pto: %c8192_i64
  const int64_t v22 = 8192;
  // pto: %c24576_i64
  const int64_t v23 = 24576;
  const int64_t v24 = 8704;
  const int64_t v25 = 8448;
  // pto: %c40960_i64
  const int64_t v26 = 40960;
  // pto: %c45056_i64
  const int64_t v27 = 45056;
  // pto: %c49152_i64
  const int64_t v28 = 49152;
  // pto: %c49408_i64
  const int64_t v29 = 49408;
  // pto: %c1_index
  const int64_t v30 = 1;
  // pto: %c64_index
  const int64_t v31 = 64;
  // pto: %c384_index
  const int64_t v32 = 384;
  // pto: %c512_index
  const int64_t v33 = 512;
  // pto: %c2_index
  const int64_t v34 = 2;
  // pto: %c16_index
  const int64_t v35 = 16;
  // pto: %cst_16
  const float v36 = 1.0f;
  // pto: %cst_17
  const float v37 = 0.0f;
  // pto: %c0_index
  const int64_t v38 = 0;
  // pto: %c1_i64
  const int64_t v39 = 1;
  // pto: %c4_i64
  const int64_t v40 = 4;
  // pto: %c256_index
  const int64_t v41 = 256;
  // pto: %c128_index
  const int64_t v42 = 128;
  // pto: %cst_23
  const float v43 = 0.001953125f;
  // pto: %cst_24
  const float v44 = 9.99999997E-7f;
  // pto: %c448_index
  const int64_t v45 = 448;
  // pto: %c192_index
  const int64_t v46 = 192;
  // pto: %c0_i32
  const int32_t v47 = 0;
  // pto: %cst_28
  const float v48 = 0.5f;
  // pto: %cst_29
  const float v49 = 2.0f;
  // pto: %c32_index
  const int64_t v50 = 32;
  // pto: %cmp_freqs_cos__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %cmp_freqs_cos__ssa_v0_view
  const int64_t v52 = 1;
  // pto: %cmp_freqs_cos__ssa_v0_view
  const int64_t v53 = 1;
  // pto: %cmp_freqs_cos__ssa_v0_view
  int64_t v54 = (int64_t) v15;
  // pto: %cmp_freqs_cos__ssa_v0_view
  int64_t v55 = v54 * v31;
  // pto: %cmp_freqs_cos__ssa_v0_view
  int64_t v56 = v53 * v55;
  // pto: %cmp_freqs_cos__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v57 = pto::Shape<1, 1, 1, -1, -1>(v51, v52, v53, v54, v31);
  // pto: %cmp_freqs_cos__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v58 = pto::Stride<-1, -1, -1, -1, -1>(v52 * v56, v56, v55, v31, v30);
  // pto: %cmp_freqs_cos__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v59 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v57, v58);
  // pto: %cmp_freqs_sin__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %cmp_freqs_sin__ssa_v0_view
  const int64_t v61 = 1;
  // pto: %cmp_freqs_sin__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %cmp_freqs_sin__ssa_v0_view
  int64_t v63 = (int64_t) v15;
  // pto: %cmp_freqs_sin__ssa_v0_view
  int64_t v64 = v63 * v31;
  // pto: %cmp_freqs_sin__ssa_v0_view
  int64_t v65 = v62 * v64;
  // pto: %cmp_freqs_sin__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v66 = pto::Shape<1, 1, 1, -1, -1>(v60, v61, v62, v63, v31);
  // pto: %cmp_freqs_sin__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v67 = pto::Stride<-1, -1, -1, -1, -1>(v61 * v65, v65, v64, v31, v30);
  // pto: %cmp_freqs_sin__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v68 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v66, v67);
  // pto: %pooled_kv_inline1347__rv_v2_view
  const int64_t v69 = 1;
  // pto: %pooled_kv_inline1347__rv_v2_view
  const int64_t v70 = 1;
  // pto: %pooled_kv_inline1347__rv_v2_view
  const int64_t v71 = 1;
  // pto: %pooled_kv_inline1347__rv_v2_view
  int64_t v72 = v32 * v33;
  // pto: %pooled_kv_inline1347__rv_v2_view
  int64_t v73 = v71 * v72;
  // pto: %pooled_kv_inline1347__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v74 = pto::Shape<1, 1, 1, -1, -1>(v69, v70, v71, v32, v33);
  // pto: %pooled_kv_inline1347__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v75 = pto::Stride<-1, -1, -1, -1, -1>(v70 * v73, v73, v72, v33, v30);
  // pto: %pooled_kv_inline1347__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v76 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v74, v75);
  // pto: %normed_kv_inline5319__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %normed_kv_inline5319__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %normed_kv_inline5319__ssa_v0_view
  const int64_t v79 = 1;
  // pto: %normed_kv_inline5319__ssa_v0_view
  int64_t v80 = v32 * v33;
  // pto: %normed_kv_inline5319__ssa_v0_view
  int64_t v81 = v79 * v80;
  // pto: %normed_kv_inline5319__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v82 = pto::Shape<1, 1, 1, -1, -1>(v77, v78, v79, v32, v33);
  // pto: %normed_kv_inline5319__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v83 = pto::Stride<-1, -1, -1, -1, -1>(v78 * v81, v81, v80, v33, v30);
  // pto: %normed_kv_inline5319__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v84 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v82, v83);
  // pto: %norm_w_2d_inline5321__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %norm_w_2d_inline5321__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %norm_w_2d_inline5321__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %norm_w_2d_inline5321__ssa_v0_view
  int64_t v88 = v30 * v33;
  // pto: %norm_w_2d_inline5321__ssa_v0_view
  int64_t v89 = v87 * v88;
  // pto: %norm_w_2d_inline5321__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v90 = pto::Shape<1, 1, 1, -1, -1>(v85, v86, v87, v30, v33);
  // pto: %norm_w_2d_inline5321__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v91 = pto::Stride<-1, -1, -1, -1, -1>(v86 * v89, v89, v88, v33, v30);
  // pto: %norm_w_2d_inline5321__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v92 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v90, v91);
  // pto: %96
  int64_t v93 = (int64_t) ((uint64_t) v16 * (uint64_t) v50);
  // pto: %cmp_kv_cache_flat_inline5334__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %cmp_kv_cache_flat_inline5334__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %cmp_kv_cache_flat_inline5334__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %cmp_kv_cache_flat_inline5334__ssa_v0_view
  int64_t v97 = v93 * v33;
  // pto: %cmp_kv_cache_flat_inline5334__ssa_v0_view
  int64_t v98 = v96 * v97;
  // pto: %cmp_kv_cache_flat_inline5334__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v99 = pto::Shape<1, 1, 1, -1, -1>(v94, v95, v96, v93, v33);
  // pto: %cmp_kv_cache_flat_inline5334__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v100 = pto::Stride<-1, -1, -1, -1, -1>(v95 * v98, v98, v97, v33, v30);
  // pto: %cmp_kv_cache_flat_inline5334__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v101 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v99, v100);
  // pto: %kv_flat_inline5342__ssa_v0_view
  const int64_t v102 = 1;
  // pto: %kv_flat_inline5342__ssa_v0_view
  const int64_t v103 = 1;
  // pto: %kv_flat_inline5342__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %kv_flat_inline5342__ssa_v0_view
  int64_t v105 = (int64_t) v13;
  // pto: %kv_flat_inline5342__ssa_v0_view
  int64_t v106 = v105 * v33;
  // pto: %kv_flat_inline5342__ssa_v0_view
  int64_t v107 = v104 * v106;
  // pto: %kv_flat_inline5342__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v108 = pto::Shape<1, 1, 1, -1, -1>(v102, v103, v104, v105, v33);
  // pto: %kv_flat_inline5342__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v109 = pto::Stride<-1, -1, -1, -1, -1>(v103 * v107, v107, v106, v33, v30);
  // pto: %kv_flat_inline5342__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v110 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v108, v109);
  // pto: %cosine_inline942_inline5317__phi_v5
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %cosine_inline942_inline5317__phi_v5
  uint64_t v112 = (uint64_t) v20;
  TASSIGN(v111, v112);
  // pto: %sine_inline941_inline5347__phi_v5
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %sine_inline941_inline5347__phi_v5
  uint64_t v114 = (uint64_t) v21;
  TASSIGN(v113, v114);
  // pto: %cosine_inline942_inline5317__phi_v4
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %cosine_inline942_inline5317__phi_v4
  uint64_t v116 = (uint64_t) v20;
  TASSIGN(v115, v116);
  // pto: %sine_inline941_inline5347__phi_v4
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %sine_inline941_inline5347__phi_v4
  uint64_t v118 = (uint64_t) v21;
  TASSIGN(v117, v118);
  // pto: %rms_blk_inline5350__ssa_v0, %23
  int64_t v119 = (int64_t) ((uint64_t) ((int64_t) v17) * (uint64_t) v35);
  // pto: %24
  int64_t v120 = (int64_t) ((uint64_t) v12 - (uint64_t) v119);
  // pto: %25
  int64_t v121 = v120 < v35 ? v120 : v35;
  // pto: %cosine_inline942_inline5317__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %cosine_inline942_inline5317__tile
  uint64_t v123 = (uint64_t) v20;
  TASSIGN(v122, v123);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  TEXPANDS(v122, v36);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %sine_inline941_inline5347__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %sine_inline941_inline5347__tile
  uint64_t v125 = (uint64_t) v21;
  TASSIGN(v124, v125);
  TEXPANDS(v124, v37);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  for (int64_t v126 = v38; v126 < v121; v126 += v30) {
    // pto: %26
    ;
    int64_t v127 = (int64_t) ((uint64_t) v119 + (uint64_t) v126);
    // pto: %position_inline938_inline5328__tile
    ;
    int64_t v128 = (v1)[v127];
    // pto: %27
    ;
    int32_t v129 = (v2)[v127];
    // pto: %28
    ;
    int64_t v130 = (int64_t) v129;
    // pto: %30
    ;
    int64_t v131 = (int64_t) ((uint64_t) v128 + (uint64_t) v39);
    // pto: %29, %31, %32, %33
    ;
    if (v130 >= v38 & v131 % v40 == v20) {
      // pto: %34
      ;
      int32_t v132 = (v3)[v130];
      // pto: %35, %39, %37
      ;
      int64_t v133 = (int64_t) ((uint64_t) ((int64_t) v132) + (uint64_t) (v131 / v40));
      // pto: %40, %41, %42
      ;
      if (v133 >= v38 & v133 < v15) {
        // pto: %gather_row_view
        ;
        int64_t v134 = (int64_t) ((uint64_t) v126 * (uint64_t) v19);
        // pto: %gather_row_view
        ;
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v135;
        // pto: %gather_row_view
        ;
        uint64_t v136 = (uint64_t) v134;
        TASSIGN(v135, v136);
        // pto: %43
        ;
        int64_t v137 = v133 < v38 ? v38 : v133;
        // pto: %cmp_freqs_cos__ssa_v0_pview
        ;
        __gm__ float* v138 = PTOAS__GLOBAL_TENSOR_DATA(v59);
        // pto: %cmp_freqs_cos__ssa_v0_pview
        ;
        const int64_t v139 = 0;
        // pto: %cmp_freqs_cos__ssa_v0_pview
        ;
        const int64_t v140 = 64;
        // pto: %cmp_freqs_cos__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 64> v141 = pto::Shape<1, 1, 1, 1, 64>();
        // pto: %cmp_freqs_cos__ssa_v0_pview
        ;
        pto::Stride<64, 64, 64, 64, 1> v142 = pto::Stride<64, 64, 64, 64, 1>();
        // pto: %cmp_freqs_cos__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v143 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v138 + (v139 + v137 * v140), v141, v142);
        TLOAD(v135, v143);
        // pto: %44
        ;
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v144;
        // pto: %44
        ;
        uint64_t v145 = (uint64_t) ((int64_t) (uint64_t) v134 + (uint64_t) v21);
        TASSIGN(v144, v145);
        // pto: %cmp_freqs_sin__ssa_v0_pview
        ;
        __gm__ float* v146 = PTOAS__GLOBAL_TENSOR_DATA(v68);
        // pto: %cmp_freqs_sin__ssa_v0_pview
        ;
        const int64_t v147 = 0;
        // pto: %cmp_freqs_sin__ssa_v0_pview
        ;
        const int64_t v148 = 64;
        // pto: %cmp_freqs_sin__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 64> v149 = pto::Shape<1, 1, 1, 1, 64>();
        // pto: %cmp_freqs_sin__ssa_v0_pview
        ;
        pto::Stride<64, 64, 64, 64, 1> v150 = pto::Stride<64, 64, 64, 64, 1>();
        // pto: %cmp_freqs_sin__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v151 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v146 + (v147 + v137 * v148), v149, v150);
        TLOAD(v144, v151);
      };
    };
  }
  // pto: %cos_b_inline5323__ssa_v0
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v152 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %cos_b_inline5323__ssa_v0
  uint64_t v153 = (uint64_t) v20;
  TASSIGN(v152, v153);
  // pto: %sin_b_inline5359__ssa_v0
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v154 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %sin_b_inline5359__ssa_v0
  uint64_t v155 = (uint64_t) v21;
  TASSIGN(v154, v155);
  // pto: %rms_low_inline5356__tile
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v156 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v41);
  // pto: %rms_low_inline5356__tile
  uint64_t v157 = (uint64_t) v22;
  TASSIGN(v156, v157);
  // pto: %46
  int64_t v158 = v119 < v38 ? v38 : v119;
  // pto: %pooled_kv_inline1347__rv_v2_pview
  __gm__ float* v159 = PTOAS__GLOBAL_TENSOR_DATA(v76);
  // pto: %pooled_kv_inline1347__rv_v2_pview
  const int64_t v160 = 0;
  // pto: %pooled_kv_inline1347__rv_v2_pview
  const int64_t v161 = 512;
  // pto: %pooled_kv_inline1347__rv_v2_pview
  pto::Shape<1, 1, 1, 16, 256> v162 = pto::Shape<1, 1, 1, 16, 256>();
  // pto: %pooled_kv_inline1347__rv_v2_pview
  pto::Stride<8192, 8192, 8192, 512, 1> v163 = pto::Stride<8192, 8192, 8192, 512, 1>();
  // pto: %pooled_kv_inline1347__rv_v2_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v164 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v159 + (v160 + v158 * v161), v162, v163);
  TLOAD(v156, v164);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %rms_high_inline5358__tile
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v41);
  // pto: %rms_high_inline5358__tile
  uint64_t v166 = (uint64_t) v23;
  TASSIGN(v165, v166);
  // pto: %48
  __gm__ float* v167 = PTOAS__GLOBAL_TENSOR_DATA(v76);
  // pto: %48
  const int64_t v168 = 256;
  // pto: %48
  const int64_t v169 = 512;
  // pto: %48
  pto::Shape<1, 1, 1, 16, 256> v170 = pto::Shape<1, 1, 1, 16, 256>();
  // pto: %48
  pto::Stride<8192, 8192, 8192, 512, 1> v171 = pto::Stride<8192, 8192, 8192, 512, 1>();
  // pto: %48
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v172 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v167 + (v168 + v158 * v169), v170, v171);
  TLOAD(v165, v172);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  // pto: %t__tile
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v173 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v41);
  // pto: %t__tile
  uint64_t v174 = (uint64_t) v22;
  TASSIGN(v173, v174);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  TMUL(v173, v156, v156);
  // pto: %2
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v41);
  // pto: %2
  uint64_t v176 = (uint64_t) v23;
  TASSIGN(v175, v176);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  TMUL(v175, v165, v165);
  // pto: %folded4_inline5330__tile
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v41);
  // pto: %folded4_inline5330__tile
  uint64_t v178 = (uint64_t) v22;
  TASSIGN(v177, v178);
  pipe_barrier(PIPE_V);
  TADD(v177, v173, v175);
  // pto: %3
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %3
  uint64_t v180 = (uint64_t) v22;
  TASSIGN(v179, v180);
  // pto: %slice_view
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, 16, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v181;
  // pto: %slice_view
  uint64_t v182 = (uint64_t) v22;
  TASSIGN(v181, v182);
  // pto: %4
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %4
  uint64_t v184 = (uint64_t) v24;
  TASSIGN(v183, v184);
  // pto: %49
  Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, 16, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v185;
  // pto: %49
  uint64_t v186 = (uint64_t) v24;
  TASSIGN(v185, v186);
  // pto: %folded2_inline5326__tile
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v187 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %folded2_inline5326__tile
  uint64_t v188 = (uint64_t) v22;
  TASSIGN(v187, v188);
  pipe_barrier(PIPE_V);
  TADD(v187, v181, v185);
  // pto: %5
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v189 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %5
  uint64_t v190 = (uint64_t) v22;
  TASSIGN(v189, v190);
  // pto: %50
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, 16, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v191;
  // pto: %50
  uint64_t v192 = (uint64_t) v22;
  TASSIGN(v191, v192);
  // pto: %6
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v193 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %6
  uint64_t v194 = (uint64_t) v25;
  TASSIGN(v193, v194);
  // pto: %51
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, 16, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v195;
  // pto: %51
  uint64_t v196 = (uint64_t) v25;
  TASSIGN(v195, v196);
  // pto: %folded1_inline5361__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v197 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %folded1_inline5361__tile
  uint64_t v198 = (uint64_t) v23;
  TASSIGN(v197, v198);
  pipe_barrier(PIPE_V);
  TADD(v197, v191, v195);
  // pto: %tmp_tile
  Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Vec, float, 16, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v42);
  // pto: %tmp_tile
  uint64_t v200 = (uint64_t) v22;
  TASSIGN(v199, v200);
  // pto: %square_sum_inline5352__tile
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v30);
  // pto: %square_sum_inline5352__tile
  uint64_t v202 = (uint64_t) v26;
  TASSIGN(v201, v202);
  pipe_barrier(PIPE_V);
  TROWSUM(v201, v197, v199);
  // pto: %t__rm_a0_tmp_v0
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v203 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v35);
  // pto: %t__rm_a0_tmp_v0
  uint64_t v204 = (uint64_t) v26;
  TASSIGN(v203, v204);
  // pto: %t__row_major_tmp_v1
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v35);
  // pto: %t__row_major_tmp_v1
  uint64_t v206 = (uint64_t) v22;
  TASSIGN(v205, v206);
  pipe_barrier(PIPE_V);
  TMULS(v205, v203, v43);
  // pto: %7
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v30);
  // pto: %7
  uint64_t v208 = (uint64_t) v22;
  TASSIGN(v207, v208);
  // pto: %variance_inline5366__rm_a0_tmp_v2
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v35);
  // pto: %variance_inline5366__rm_a0_tmp_v2
  uint64_t v210 = (uint64_t) v22;
  TASSIGN(v209, v210);
  // pto: %variance_inline5366__row_major_tmp_v3
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v35);
  // pto: %variance_inline5366__row_major_tmp_v3
  uint64_t v212 = (uint64_t) v22;
  TASSIGN(v211, v212);
  pipe_barrier(PIPE_V);
  TADDS(v211, v209, v44);
  // pto: %variance_inline5366__tile
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v30);
  // pto: %variance_inline5366__tile
  uint64_t v214 = (uint64_t) v22;
  TASSIGN(v213, v214);
  // pto: %rms_inline5367__rm_a0_tmp_v4
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v35);
  // pto: %rms_inline5367__rm_a0_tmp_v4
  uint64_t v216 = (uint64_t) v22;
  TASSIGN(v215, v216);
  // pto: %rms_inline5367__row_major_tmp_v5
  Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v35);
  // pto: %rms_inline5367__row_major_tmp_v5
  uint64_t v218 = (uint64_t) v27;
  TASSIGN(v217, v218);
  pipe_barrier(PIPE_V);
  TSQRT(v217, v215);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  // pto: %rms_inline5367__tile
  Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v219 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v30);
  // pto: %rms_inline5367__tile
  uint64_t v220 = (uint64_t) v27;
  TASSIGN(v219, v220);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  for (int64_t v221 = v38; v221 < v45; v221 += v31) {
    // pto: %kv_norm_chunk_inline5344__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
    // pto: %kv_norm_chunk_inline5344__tile
    ;
    uint64_t v223 = (uint64_t) v22;
    TASSIGN(v222, v223);
    // pto: %53
    ;
    int64_t v224 = v221 < v38 ? v38 : v221;
    // pto: %54
    ;
    __gm__ float* v225 = PTOAS__GLOBAL_TENSOR_DATA(v76);
    // pto: %54
    ;
    const int64_t v226 = 0;
    // pto: %54
    ;
    const int64_t v227 = 512;
    // pto: %54
    ;
    pto::Shape<1, 1, 1, 16, 64> v228 = pto::Shape<1, 1, 1, 16, 64>();
    // pto: %54
    ;
    pto::Stride<8192, 8192, 8192, 512, 1> v229 = pto::Stride<8192, 8192, 8192, 512, 1>();
    // pto: %54
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v230 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v225 + (v226 + v158 * v227 + v224), v228, v229);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v222, v230);
    // pto: %8
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v231 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %8
    ;
    uint64_t v232 = (uint64_t) v26;
    TASSIGN(v231, v232);
    // pto: %norm_w_2d_inline5321__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v233 = PTOAS__GLOBAL_TENSOR_DATA(v92);
    // pto: %norm_w_2d_inline5321__ssa_v0_pview
    ;
    const int64_t v234 = 0;
    // pto: %norm_w_2d_inline5321__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 64> v235 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %norm_w_2d_inline5321__ssa_v0_pview
    ;
    pto::Stride<512, 512, 512, 512, 1> v236 = pto::Stride<512, 512, 512, 512, 1>();
    // pto: %norm_w_2d_inline5321__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v237 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v233 + (v234 + v224), v235, v236);
    TLOAD(v231, v237);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %gamma_inline5362__tile
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %gamma_inline5362__tile
    ;
    uint64_t v239 = (uint64_t) v23;
    TASSIGN(v238, v239);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    RoundMode v240 = RoundMode::CAST_ROUND;
    SaturationMode v241 = SaturationMode::ON;
    TCVT(v238, v231, v240, v241);
    // pto: %9
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v242 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
    // pto: %9
    ;
    uint64_t v243 = (uint64_t) v22;
    TASSIGN(v242, v243);
    TROWEXPANDDIV(v242, v222, v219);
    // pto: %normed_chunk_inline5318__tile
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
    // pto: %normed_chunk_inline5318__tile
    ;
    uint64_t v245 = (uint64_t) v22;
    TASSIGN(v244, v245);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v244, v242, v238);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %normed_kv_inline5319__iter_v1_pview
    ;
    __gm__ float* v246 = PTOAS__GLOBAL_TENSOR_DATA(v84);
    // pto: %normed_kv_inline5319__iter_v1_pview
    ;
    const int64_t v247 = 0;
    // pto: %normed_kv_inline5319__iter_v1_pview
    ;
    const int64_t v248 = 512;
    // pto: %normed_kv_inline5319__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 64> v249 = pto::Shape<1, 1, 1, 16, 64>();
    // pto: %normed_kv_inline5319__iter_v1_pview
    ;
    pto::Stride<8192, 8192, 8192, 512, 1> v250 = pto::Stride<8192, 8192, 8192, 512, 1>();
    // pto: %normed_kv_inline5319__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v251 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v246 + (v247 + v158 * v248 + v224), v249, v250);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v251, v244);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  // pto: %kv_rope_norm_inline5370__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v252 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %kv_rope_norm_inline5370__tile
  uint64_t v253 = (uint64_t) v22;
  TASSIGN(v252, v253);
  // pto: %59
  __gm__ float* v254 = PTOAS__GLOBAL_TENSOR_DATA(v76);
  // pto: %59
  const int64_t v255 = 448;
  // pto: %59
  const int64_t v256 = 512;
  // pto: %59
  pto::Shape<1, 1, 1, 16, 64> v257 = pto::Shape<1, 1, 1, 16, 64>();
  // pto: %59
  pto::Stride<8192, 8192, 8192, 512, 1> v258 = pto::Stride<8192, 8192, 8192, 512, 1>();
  // pto: %59
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v259 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v254 + (v255 + v158 * v256), v257, v258);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  TLOAD(v252, v259);
  // pto: %10
  Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v260 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
  // pto: %10
  uint64_t v261 = (uint64_t) v26;
  TASSIGN(v260, v261);
  // pto: %60
  __gm__ bfloat16_t* v262 = PTOAS__GLOBAL_TENSOR_DATA(v92);
  // pto: %60
  unsigned v263 = 448;
  // pto: %60
  pto::Shape<1, 1, 1, 1, 64> v264 = pto::Shape<1, 1, 1, 1, 64>();
  // pto: %60
  pto::Stride<512, 512, 512, 512, 1> v265 = pto::Stride<512, 512, 512, 512, 1>();
  // pto: %60
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v266 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v262 + v263, v264, v265);
  TLOAD(v260, v266);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
  // pto: %gamma_rope_inline5369__tile
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v267 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
  // pto: %gamma_rope_inline5369__tile
  uint64_t v268 = (uint64_t) v23;
  TASSIGN(v267, v268);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
  RoundMode v269 = RoundMode::CAST_ROUND;
  SaturationMode v270 = SaturationMode::ON;
  TCVT(v267, v260, v269, v270);
  // pto: %11
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v271 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %11
  uint64_t v272 = (uint64_t) v22;
  TASSIGN(v271, v272);
  TROWEXPANDDIV(v271, v252, v219);
  // pto: %rope_normed_inline5371__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_normed_inline5371__tile
  uint64_t v274 = (uint64_t) v22;
  TASSIGN(v273, v274);
  pipe_barrier(PIPE_V);
  TCOLEXPANDMUL(v273, v271, v267);
  // pto: %rope_ones_inline5333__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_ones_inline5333__tile
  uint64_t v276 = (uint64_t) v23;
  TASSIGN(v275, v276);
  pipe_barrier(PIPE_V);
  TEXPANDS(v275, v36);
  // pto: %rope_index_inline5354__ci_tmp_v0
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v46);
  // pto: %rope_index_inline5354__ci_tmp_v0
  uint64_t v278 = (uint64_t) v26;
  TASSIGN(v277, v278);
  // pto: %rope_index_inline5354__tile
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
  // pto: %rope_index_inline5354__tile
  uint64_t v280 = (uint64_t) v27;
  TASSIGN(v279, v280);
  // pto: %ci_tmp_view
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v281;
  TRESHAPE(v281, v277);
  // pto: %ci_dst_view
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v282;
  TRESHAPE(v282, v279);
  TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v282, v47, v281);
  // pto: %rope_index_f_inline5373__tile
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v283 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
  // pto: %rope_index_f_inline5373__tile
  uint64_t v284 = (uint64_t) v26;
  TASSIGN(v283, v284);
  pipe_barrier(PIPE_V);
  RoundMode v285 = RoundMode::CAST_ROUND;
  SaturationMode v286 = SaturationMode::ON;
  TCVT(v283, v279, v285, v286);
  // pto: %rope_col_inline5374__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_col_inline5374__tile
  uint64_t v288 = (uint64_t) v23;
  TASSIGN(v287, v288);
  pipe_barrier(PIPE_V);
  TCOLEXPANDMUL(v287, v275, v283);
  // pto: %12
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %12
  uint64_t v290 = (uint64_t) v26;
  TASSIGN(v289, v290);
  pipe_barrier(PIPE_V);
  TMULS(v289, v287, v48);
  // pto: %13
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %13
  uint64_t v292 = (uint64_t) v26;
  TASSIGN(v291, v292);
  pipe_barrier(PIPE_V);
  RoundMode v293 = RoundMode::CAST_TRUNC;
  SaturationMode v294 = SaturationMode::ON;
  TCVT(v291, v289, v293, v294);
  // pto: %rope_dup_f_inline5375__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_dup_f_inline5375__tile
  uint64_t v296 = (uint64_t) v26;
  TASSIGN(v295, v296);
  pipe_barrier(PIPE_V);
  RoundMode v297 = RoundMode::CAST_ROUND;
  SaturationMode v298 = SaturationMode::ON;
  TCVT(v295, v291, v297, v298);
  // pto: %14
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %14
  uint64_t v300 = (uint64_t) v26;
  TASSIGN(v299, v300);
  pipe_barrier(PIPE_V);
  TMULS(v299, v295, v49);
  // pto: %rope_lane_inline5348__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_lane_inline5348__tile
  uint64_t v302 = (uint64_t) v26;
  TASSIGN(v301, v302);
  pipe_barrier(PIPE_V);
  TSUB(v301, v287, v299);
  // pto: %15
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %15
  uint64_t v304 = (uint64_t) v23;
  TASSIGN(v303, v304);
  pipe_barrier(PIPE_V);
  TADDS(v303, v287, v36);
  // pto: %16
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %16
  uint64_t v306 = (uint64_t) v27;
  TASSIGN(v305, v306);
  TMULS(v305, v301, v49);
  // pto: %17
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %17
  uint64_t v308 = (uint64_t) v23;
  TASSIGN(v307, v308);
  pipe_barrier(PIPE_V);
  TSUB(v307, v303, v305);
  // pto: %rope_swap_idx_inline5338__tile
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_swap_idx_inline5338__tile
  uint64_t v310 = (uint64_t) v23;
  TASSIGN(v309, v310);
  pipe_barrier(PIPE_V);
  RoundMode v311 = RoundMode::CAST_ROUND;
  SaturationMode v312 = SaturationMode::ON;
  TCVT(v309, v307, v311, v312);
  // pto: %gather_acc_init
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %gather_acc_init
  uint64_t v314 = (uint64_t) v27;
  TASSIGN(v313, v314);
  for (int64_t v315 = v38; v315 < v35; v315 += v30) {
    // pto: %gather_inp_row
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v316 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %gather_inp_row
    ;
    uint64_t v317 = (uint64_t) v22;
    TASSIGN(v316, v317);
    // pto: %61
    ;
    int64_t v318 = (int64_t) ((uint64_t) v315 * (uint64_t) v19);
    // pto: %61
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v319;
    // pto: %61
    ;
    uint64_t v320 = (uint64_t) ((int64_t) (uint64_t) v318 + (uint64_t) v22);
    TASSIGN(v319, v320);
    // pto: %gather_idx_row
    ;
    Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %gather_idx_row
    ;
    uint64_t v322 = (uint64_t) v23;
    TASSIGN(v321, v322);
    // pto: %62
    ;
    Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v323;
    // pto: %62
    ;
    uint64_t v324 = (uint64_t) ((int64_t) (uint64_t) v318 + (uint64_t) v23);
    TASSIGN(v323, v324);
    // pto: %gather_row_tmp
    ;
    Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v325 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %gather_row_tmp
    ;
    uint64_t v326 = (uint64_t) v28;
    TASSIGN(v325, v326);
    // pto: %gather_row
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v327 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %gather_row
    ;
    uint64_t v328 = (uint64_t) v29;
    TASSIGN(v327, v328);
    pipe_barrier(PIPE_V);
    TGATHER(v327, v319, v323, v325);
    // pto: %assemble_view
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v329;
    // pto: %assemble_view
    ;
    uint64_t v330 = (uint64_t) ((int64_t) (uint64_t) v318 + (uint64_t) v27);
    TASSIGN(v329, v330);
    pipe_barrier(PIPE_V);
    TMOV(v329, v327);
  }
  // pto: %swapped_inline5364__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v331 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %swapped_inline5364__tile
  uint64_t v332 = (uint64_t) v27;
  TASSIGN(v331, v332);
  // pto: %18
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v333 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %18
  uint64_t v334 = (uint64_t) v23;
  TASSIGN(v333, v334);
  pipe_barrier(PIPE_V);
  TMULS(v333, v301, v49);
  // pto: %19
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v335 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %19
  uint64_t v336 = (uint64_t) v23;
  TASSIGN(v335, v336);
  pipe_barrier(PIPE_V);
  TSUBS(v335, v333, v36);
  // pto: %sin_signed_inline5311__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v337 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %sin_signed_inline5311__tile
  uint64_t v338 = (uint64_t) v23;
  TASSIGN(v337, v338);
  pipe_barrier(PIPE_V);
  TMUL(v337, v154, v335);
  // pto: %20
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v339 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %20
  uint64_t v340 = (uint64_t) v22;
  TASSIGN(v339, v340);
  TMUL(v339, v273, v152);
  // pto: %21
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v341 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %21
  uint64_t v342 = (uint64_t) v23;
  TASSIGN(v341, v342);
  pipe_barrier(PIPE_V);
  TMUL(v341, v331, v337);
  // pto: %rope_rot_inline5310__tile
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v35, v31);
  // pto: %rope_rot_inline5310__tile
  uint64_t v344 = (uint64_t) v22;
  TASSIGN(v343, v344);
  pipe_barrier(PIPE_V);
  TADD(v343, v339, v341);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  // pto: %normed_kv_inline5319__rv_v2_pview
  __gm__ float* v345 = PTOAS__GLOBAL_TENSOR_DATA(v84);
  // pto: %normed_kv_inline5319__rv_v2_pview
  const int64_t v346 = 448;
  // pto: %normed_kv_inline5319__rv_v2_pview
  const int64_t v347 = 512;
  // pto: %normed_kv_inline5319__rv_v2_pview
  pto::Shape<1, 1, 1, 16, 64> v348 = pto::Shape<1, 1, 1, 16, 64>();
  // pto: %normed_kv_inline5319__rv_v2_pview
  pto::Stride<8192, 8192, 8192, 512, 1> v349 = pto::Stride<8192, 8192, 8192, 512, 1>();
  // pto: %normed_kv_inline5319__rv_v2_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v350 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 64>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v345 + (v346 + v158 * v347), v348, v349);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  TSTORE(v350, v343);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  for (int64_t v351 = v38; v351 < v121; v351 += v30) {
    // pto: %65
    ;
    int64_t v352 = (int64_t) ((uint64_t) v119 + (uint64_t) v351);
    // pto: %token_pos_inline5320__tile
    ;
    int64_t v353 = (v1)[v352];
    // pto: %66
    ;
    int32_t v354 = (v2)[v352];
    // pto: %67
    ;
    int64_t v355 = (int64_t) v354;
    // pto: %69
    ;
    int64_t v356 = (int64_t) ((uint64_t) v353 + (uint64_t) v39);
    // pto: %68, %70, %71, %72
    ;
    if (v355 >= v38 & v356 % v40 == v20) {
      // pto: %73
      ;
      int32_t v357 = (v3)[v355];
      // pto: %74, %78, %76
      ;
      int64_t v358 = (int64_t) ((uint64_t) ((int64_t) v357) + (uint64_t) (v356 / v40));
      // pto: %79, %80, %81
      ;
      if (v358 >= v38 & v358 < v15) {
        // pto: %flat_offset_mul
        ;
        int64_t v359 = (int64_t) ((uint64_t) v358 * (uint64_t) v34);
        // pto: %cache_page_inline5331__tile
        ;
        int32_t v360 = (v11)[v359];
        // pto: %83, %cache_offset_inline5315__tile
        ;
        int32_t v361 = (v11)[(int64_t) ((uint64_t) v359 + (uint64_t) v30)];
        // pto: %84
        ;
        int64_t v362 = (int64_t) v360;
        // pto: %86
        ;
        int64_t v363 = (int64_t) v361;
        // pto: %85, %87, %88
        ;
        if (v362 >= v38 & v363 >= v38) {
          // pto: %90, %92
          ;
          int64_t v364 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v362 * (uint64_t) v50) + (uint64_t) v363);
          // pto: %kv_row_fp32_inline5308__tile
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v365 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
          // pto: %kv_row_fp32_inline5308__tile
          ;
          uint64_t v366 = (uint64_t) v22;
          TASSIGN(v365, v366);
          // pto: %93
          ;
          int64_t v367 = v352 < v38 ? v38 : v352;
          // pto: %normed_kv_inline5319__tile_pview
          ;
          __gm__ float* v368 = PTOAS__GLOBAL_TENSOR_DATA(v84);
          // pto: %normed_kv_inline5319__tile_pview
          ;
          const int64_t v369 = 0;
          // pto: %normed_kv_inline5319__tile_pview
          ;
          const int64_t v370 = 512;
          // pto: %normed_kv_inline5319__tile_pview
          ;
          pto::Shape<1, 1, 1, 1, 512> v371 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %normed_kv_inline5319__tile_pview
          ;
          pto::Stride<512, 512, 512, 512, 1> v372 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %normed_kv_inline5319__tile_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v373 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v368 + (v369 + v367 * v370), v371, v372);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          TLOAD(v365, v373);
          set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
          // pto: %kv_flat_inline5342__iter_v1_pview
          ;
          __gm__ float* v374 = PTOAS__GLOBAL_TENSOR_DATA(v110);
          // pto: %kv_flat_inline5342__iter_v1_pview
          ;
          const int64_t v375 = 0;
          // pto: %kv_flat_inline5342__iter_v1_pview
          ;
          const int64_t v376 = 512;
          // pto: %kv_flat_inline5342__iter_v1_pview
          ;
          pto::Shape<1, 1, 1, 1, 512> v377 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %kv_flat_inline5342__iter_v1_pview
          ;
          pto::Stride<512, 512, 512, 512, 1> v378 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %kv_flat_inline5342__iter_v1_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v379 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v374 + (v375 + v367 * v376), v377, v378);
          wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
          TSTORE(v379, v365);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
          // pto: %22
          ;
          Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v380 = Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
          // pto: %22
          ;
          uint64_t v381 = (uint64_t) v22;
          TASSIGN(v380, v381);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
          RoundMode v382 = RoundMode::CAST_RINT;
          SaturationMode v383 = SaturationMode::ON;
          TCVT(v380, v365, v382, v383);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          // pto: %95
          ;
          int64_t v384 = v364 < v38 ? v38 : v364;
          // pto: %cmp_kv_cache_flat_inline5334__iter_v1_pview
          ;
          __gm__ bfloat16_t* v385 = PTOAS__GLOBAL_TENSOR_DATA(v101);
          // pto: %cmp_kv_cache_flat_inline5334__iter_v1_pview
          ;
          const int64_t v386 = 0;
          // pto: %cmp_kv_cache_flat_inline5334__iter_v1_pview
          ;
          const int64_t v387 = 512;
          // pto: %cmp_kv_cache_flat_inline5334__iter_v1_pview
          ;
          pto::Shape<1, 1, 1, 1, 512> v388 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %cmp_kv_cache_flat_inline5334__iter_v1_pview
          ;
          pto::Stride<512, 512, 512, 512, 1> v389 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %cmp_kv_cache_flat_inline5334__iter_v1_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v390 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v385 + (v386 + v384 * v387), v388, v389);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          TSTORE(v390, v380);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        };
      };
    };
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}