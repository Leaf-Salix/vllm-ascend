#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void csa_slots_build_valid_qk_plan(__gm__ float* v1, __gm__ int32_t* v2, __gm__ int64_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ int32_t* v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int64_t v12, int32_t v13, int32_t v14) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int32_t v15 = 1;
  // pto: %c1536_i64
  const int64_t v16 = 1536;
  // pto: %c17920_i64
  const int64_t v17 = 17920;
  // pto: %c0_i64
  const int64_t v18 = 0;
  // pto: %c512_i64
  const int64_t v19 = 512;
  // pto: %c1024_i64
  const int64_t v20 = 1024;
  // pto: %c1024_index
  const int64_t v21 = 1024;
  // pto: %c1_index
  const int64_t v22 = 1;
  // pto: %c512_index
  const int64_t v23 = 512;
  // pto: %c16_index
  const int64_t v24 = 16;
  // pto: %c8_index
  const int64_t v25 = 8;
  // pto: %c256_index
  const int64_t v26 = 256;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %c128_index
  const int64_t v28 = 128;
  // pto: %c32_index
  const int64_t v29 = 32;
  // pto: %c192_index
  const int64_t v30 = 192;
  const int32_t v31 = 0;
  // pto: %cst_16
  const float v32 = 0.0f;
  // pto: %c5_index
  const int64_t v33 = 5;
  // pto: %cst_18
  const float v34 = 1.0f;
  // pto: %cst_19
  const float v35 = 1.00000002E+20f;
  // pto: %c384_index
  const int64_t v36 = 384;
  // pto: %cst_21
  const float v37 = -1.00000002E+20f;
  // pto: %sparse_bias_inline5804__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %sparse_bias_inline5804__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %sparse_bias_inline5804__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %sparse_bias_inline5804__ssa_v0_view
  int64_t v41 = (int64_t) v9;
  // pto: %sparse_bias_inline5804__ssa_v0_view
  int64_t v42 = v41 * v21;
  // pto: %sparse_bias_inline5804__ssa_v0_view
  int64_t v43 = v40 * v42;
  // pto: %sparse_bias_inline5804__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v44 = pto::Shape<1, 1, 1, -1, -1>(v38, v39, v40, v41, v21);
  // pto: %sparse_bias_inline5804__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v45 = pto::Stride<-1, -1, -1, -1, -1>(v39 * v43, v43, v42, v21, v22);
  // pto: %sparse_bias_inline5804__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v46 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v44, v45);
  // pto: %cmp_sparse_indices_inline5818__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %cmp_sparse_indices_inline5818__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %cmp_sparse_indices_inline5818__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %cmp_sparse_indices_inline5818__ssa_v0_view
  int64_t v50 = (int64_t) v9;
  // pto: %cmp_sparse_indices_inline5818__ssa_v0_view
  int64_t v51 = v50 * v23;
  // pto: %cmp_sparse_indices_inline5818__ssa_v0_view
  int64_t v52 = v49 * v51;
  // pto: %cmp_sparse_indices_inline5818__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v47, v48, v49, v50, v23);
  // pto: %cmp_sparse_indices_inline5818__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v48 * v52, v52, v51, v23, v22);
  // pto: %cmp_sparse_indices_inline5818__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v53, v54);
  // pto: %v_valid_inline5780__phi_v5
  Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
  // pto: %v_valid_inline5780__phi_v5
  uint64_t v57 = (uint64_t) v18;
  TASSIGN(v56, v57);
  // pto: %v_valid_inline5780__phi_v4
  Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
  // pto: %v_valid_inline5780__phi_v4
  uint64_t v59 = (uint64_t) v18;
  TASSIGN(v58, v59);
  // pto: %plan_worker_inline5790__ssa_v0, %14
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v60 = (int64_t) ((uint64_t) ((int64_t) v13) * (uint64_t) v25); v60 < v9; v60 += v26) {
    // pto: %15
    ;
    int64_t v61 = (int64_t) ((uint64_t) v9 - (uint64_t) v60);
    // pto: %16
    ;
    int64_t v62 = v61 < v25 ? v61 : v25;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    for (int64_t v63 = v27; v63 < v62; v63 += v22) {
      // pto: %17
      ;
      int64_t v64 = (int64_t) ((uint64_t) v60 + (uint64_t) v63);
      // pto: %18
      ;
      int32_t v65 = (v2)[v64];
      // pto: %19
      ;
      int64_t v66 = (int64_t) v65;
      // pto: %20
      ;
      int64_t v67 = v66 < v27 ? v27 : v66;
      // pto: %21
      ;
      int64_t v68 = (v3)[v64];
      // pto: %t__tile
      ;
      Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v69 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v23);
      // pto: %t__tile
      ;
      uint64_t v70 = (uint64_t) v16;
      TASSIGN(v69, v70);
      // pto: %23
      ;
      int64_t v71 = v64 < v27 ? v27 : v64;
      // pto: %cmp_sparse_indices_inline5818__ssa_v0_pview
      ;
      __gm__ int32_t* v72 = PTOAS__GLOBAL_TENSOR_DATA(v55);
      // pto: %cmp_sparse_indices_inline5818__ssa_v0_pview
      ;
      const int64_t v73 = 0;
      // pto: %cmp_sparse_indices_inline5818__ssa_v0_pview
      ;
      const int64_t v74 = 512;
      // pto: %cmp_sparse_indices_inline5818__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v75 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %cmp_sparse_indices_inline5818__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 512, 1> v76 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %cmp_sparse_indices_inline5818__ssa_v0_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v77 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v72 + (v73 + v71 * v74), v75, v76);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      TLOAD(v69, v77);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %c_out_inline5782__tile
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v23);
      // pto: %c_out_inline5782__tile
      ;
      uint64_t v79 = (uint64_t) v16;
      TASSIGN(v78, v79);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      RoundMode v80 = RoundMode::CAST_ROUND;
      SaturationMode v81 = SaturationMode::ON;
      TCVT(v78, v69, v80, v81);
      // pto: %24
      ;
      int64_t v82 = (int64_t) ((uint64_t) v68 + (uint64_t) v22);
      // pto: %25
      ;
      int64_t v83 = v82 < v28 ? v82 : v28;
      // pto: %26
      ;
      int32_t v84 = (v2)[v64];
      // pto: %27
      ;
      int32_t v85 = (v5)[v67];
      // pto: %28, %29, %30, %31, %32, %v_length_inline5890__phi_v2
      ;
      int64_t v86 = (int64_t) v84 < v27 | (int64_t) v85 <= v27 ? v27 : v83;
      // pto: %34, %35
      ;
      int64_t v87 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v68 - (uint64_t) v86) + (uint64_t) v22);
      // pto: %t__ci_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v30);
      // pto: %t__ci_tmp_v0
      ;
      uint64_t v89 = (uint64_t) v17;
      TASSIGN(v88, v89);
      // pto: %0
      ;
      Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
      // pto: %0
      ;
      uint64_t v91 = (uint64_t) v18;
      TASSIGN(v90, v91);
      // pto: %ci_tmp_view
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v92;
      TRESHAPE(v92, v88);
      // pto: %ci_dst_view
      ;
      Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v93;
      TRESHAPE(v93, v90);
      TCI<Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v93, v31, v92);
      // pto: %v_columns_inline5832__tile
      ;
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
      // pto: %v_columns_inline5832__tile
      ;
      uint64_t v95 = (uint64_t) v17;
      TASSIGN(v94, v95);
      pipe_barrier(PIPE_V);
      RoundMode v96 = RoundMode::CAST_ROUND;
      SaturationMode v97 = SaturationMode::ON;
      TCVT(v94, v90, v96, v97);
      // pto: %v_valid_inline5780__tile
      ;
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
      // pto: %v_valid_inline5780__tile
      ;
      uint64_t v99 = (uint64_t) v18;
      TASSIGN(v98, v99);
      pipe_barrier(PIPE_V);
      TEXPANDS(v98, v32);
      // pto: %v_block_valid_inline5844__rv_v2
      ;
      int32_t v100;
      v100 = v31;
      for (int64_t v101 = v27; v101 < v33; v101 += v22) {
        // pto: %38, %39, %36
        ;
        int64_t v102 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v101 * (uint64_t) v29) - (uint64_t) (v87 % v29));
        // pto: %40
        ;
        int64_t v103 = v102 < v27 ? v27 : v102;
        // pto: %43
        ;
        int64_t v104 = (int64_t) ((uint64_t) v102 + (uint64_t) v29);
        // pto: %44
        ;
        int64_t v105 = v104 < v86 ? v104 : v86;
        // pto: %45
        ;
        // pto: %v_block_valid_inline5844__phi_v5
        ;
        int32_t v106;
        if (v103 < v105) {
          // pto: %48, %49, %46, %47, %v_page_inline5816__tile
          ;
          int32_t v107 = (v6)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v67 * (uint64_t) v12) + (uint64_t) ((int64_t) ((uint64_t) v87 + (uint64_t) v103) / v29))];
          // pto: %50, %51
          ;
          bool v108 = (int64_t) v107 >= v27;
          // pto: %v_block_valid_inline5844__phi_v4
          ;
          int32_t v109 = v108 ? v15 : v100;
          if (v108) {
            // pto: %53, %54
            ;
            float v110 = (float) ((int32_t) v103);
            // pto: %55, %56
            ;
            float v111 = (float) ((int32_t) v105);
            // pto: %1
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %1
            ;
            uint64_t v113 = (uint64_t) v19;
            TASSIGN(v112, v113);
            pipe_barrier(PIPE_V);
            TSUBS(v112, v94, v110);
            // pto: %2
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %2
            ;
            uint64_t v115 = (uint64_t) v19;
            TASSIGN(v114, v115);
            pipe_barrier(PIPE_V);
            TADDS(v114, v112, v34);
            // pto: %3
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %3
            ;
            uint64_t v117 = (uint64_t) v19;
            TASSIGN(v116, v117);
            pipe_barrier(PIPE_V);
            TMAXS(v116, v114, v32);
            // pto: %v_ge_inline5871__tile
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %v_ge_inline5871__tile
            ;
            uint64_t v119 = (uint64_t) v19;
            TASSIGN(v118, v119);
            pipe_barrier(PIPE_V);
            TMINS(v118, v116, v34);
            // pto: %4
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %4
            ;
            uint64_t v121 = (uint64_t) v20;
            TASSIGN(v120, v121);
            TNEG(v120, v94);
            // pto: %5
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %5
            ;
            uint64_t v123 = (uint64_t) v20;
            TASSIGN(v122, v123);
            pipe_barrier(PIPE_V);
            TADDS(v122, v120, v111);
            // pto: %6
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %6
            ;
            uint64_t v125 = (uint64_t) v20;
            TASSIGN(v124, v125);
            pipe_barrier(PIPE_V);
            TMAXS(v124, v122, v32);
            // pto: %v_lt_inline5779__tile
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v126 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %v_lt_inline5779__tile
            ;
            uint64_t v127 = (uint64_t) v20;
            TASSIGN(v126, v127);
            pipe_barrier(PIPE_V);
            TMINS(v126, v124, v34);
            // pto: %7
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v128 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %7
            ;
            uint64_t v129 = (uint64_t) v19;
            TASSIGN(v128, v129);
            pipe_barrier(PIPE_V);
            TMUL(v128, v118, v126);
            // pto: %8
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
            // pto: %8
            ;
            uint64_t v131 = (uint64_t) v18;
            TASSIGN(v130, v131);
            pipe_barrier(PIPE_V);
            TADD(v130, v98, v128);
          };
          v106 = v109;
        } else {
          v106 = v100;
        };
        v100 = v106;
      };
      // pto: %57
      ;
      int64_t v132 = (int64_t) ((uint64_t) v64 * (uint64_t) v24);
      (v7)[v132] = v100;
      // pto: %9
      ;
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
      // pto: %9
      ;
      uint64_t v134 = (uint64_t) v17;
      TASSIGN(v133, v134);
      pipe_barrier(PIPE_V);
      TSUBS(v133, v98, v34);
      // pto: %10
      ;
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v28);
      // pto: %10
      ;
      uint64_t v136 = (uint64_t) v17;
      TASSIGN(v135, v136);
      pipe_barrier(PIPE_V);
      TMULS(v135, v133, v35);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %sparse_bias_inline5804__iter_v3_pview
      ;
      __gm__ float* v137 = PTOAS__GLOBAL_TENSOR_DATA(v46);
      // pto: %sparse_bias_inline5804__iter_v3_pview
      ;
      const int64_t v138 = 0;
      // pto: %sparse_bias_inline5804__iter_v3_pview
      ;
      const int64_t v139 = 1024;
      // pto: %sparse_bias_inline5804__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 1, 128> v140 = pto::Shape<1, 1, 1, 1, 128>();
      // pto: %sparse_bias_inline5804__iter_v3_pview
      ;
      pto::Stride<1024, 1024, 1024, 1024, 1> v141 = pto::Stride<1024, 1024, 1024, 1024, 1>();
      // pto: %sparse_bias_inline5804__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v142 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v137 + (v138 + v71 * v139), v140, v141);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v142, v135);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      // pto: %11
      ;
      Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v143 = Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v36);
      // pto: %11
      ;
      uint64_t v144 = (uint64_t) v17;
      TASSIGN(v143, v144);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      TEXPANDS(v143, v37);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      // pto: %sparse_bias_inline5804__tile_pview
      ;
      __gm__ float* v145 = PTOAS__GLOBAL_TENSOR_DATA(v46);
      // pto: %sparse_bias_inline5804__tile_pview
      ;
      const int64_t v146 = 128;
      // pto: %sparse_bias_inline5804__tile_pview
      ;
      const int64_t v147 = 1024;
      // pto: %sparse_bias_inline5804__tile_pview
      ;
      pto::Shape<1, 1, 1, 1, 384> v148 = pto::Shape<1, 1, 1, 1, 384>();
      // pto: %sparse_bias_inline5804__tile_pview
      ;
      pto::Stride<1024, 1024, 1024, 1024, 1> v149 = pto::Stride<1024, 1024, 1024, 1024, 1>();
      // pto: %sparse_bias_inline5804__tile_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 384>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v150 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 384>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v145 + (v146 + v71 * v147), v148, v149);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      TSTORE(v150, v143);
      // pto: %12
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v151 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v23);
      // pto: %12
      ;
      uint64_t v152 = (uint64_t) v16;
      TASSIGN(v151, v152);
      TMINS(v151, v78, v32);
      // pto: %13
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v23);
      // pto: %13
      ;
      uint64_t v154 = (uint64_t) v16;
      TASSIGN(v153, v154);
      pipe_barrier(PIPE_V);
      TMULS(v153, v151, v35);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      // pto: %64
      ;
      __gm__ float* v155 = PTOAS__GLOBAL_TENSOR_DATA(v46);
      // pto: %64
      ;
      const int64_t v156 = 512;
      // pto: %64
      ;
      const int64_t v157 = 1024;
      // pto: %64
      ;
      pto::Shape<1, 1, 1, 1, 512> v158 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %64
      ;
      pto::Stride<1024, 1024, 1024, 1024, 1> v159 = pto::Stride<1024, 1024, 1024, 1024, 1>();
      // pto: %64
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v160 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v155 + (v156 + v71 * v157), v158, v159);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v160, v153);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    // pto: %c_blk_tmp_inline5773__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v23);
    // pto: %c_blk_tmp_inline5773__ssa_v0
    ;
    uint64_t v162 = (uint64_t) v16;
    TASSIGN(v161, v162);
    // pto: %t__tmp_v986
    ;
    Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v163 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v23);
    // pto: %t__tmp_v986
    ;
    uint64_t v164 = (uint64_t) v17;
    TASSIGN(v163, v164);
    // pto: %65
    ;
    int64_t v165 = v60 < v27 ? v27 : v60;
    // pto: %67
    ;
    const int64_t v166 = 0;
    // pto: %67
    ;
    __gm__ int32_t* v167 = PTOAS__GLOBAL_TENSOR_DATA(v55);
    // pto: %67
    ;
    const int64_t v168 = 1;
    // pto: %67
    ;
    const int64_t v169 = 1;
    // pto: %67
    ;
    const int64_t v170 = 1;
    // pto: %67
    ;
    int64_t v171 = v62 * v23;
    // pto: %67
    ;
    int64_t v172 = v170 * v171;
    // pto: %67
    ;
    pto::Shape<1, 1, 1, -1, 512> v173 = pto::Shape<1, 1, 1, -1, 512>(v168, v169, v170, v62, v23);
    // pto: %67
    ;
    pto::Stride<-1, -1, -1, -1, -1> v174 = pto::Stride<-1, -1, -1, -1, -1>(v169 * v172, v172, v171, v23, v22);
    // pto: %67
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v175 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v167 + (v166 + v165 * v23 + v27 * v22), v173, v174);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    TLOAD(v163, v175);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %c_block_slots_inline5904__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v176 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v23);
    // pto: %c_block_slots_inline5904__ssa_v0
    ;
    uint64_t v177 = (uint64_t) v17;
    TASSIGN(v176, v177);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    RoundMode v178 = RoundMode::CAST_ROUND;
    SaturationMode v179 = SaturationMode::ON;
    TCVT(v176, v163, v178, v179);
    // pto: %t__tmp_v987
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v180 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v23);
    // pto: %t__tmp_v987
    ;
    uint64_t v181 = (uint64_t) v17;
    TASSIGN(v180, v181);
    pipe_barrier(PIPE_V);
    TADDS(v180, v176, v34);
    // pto: %t__tmp_v988
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v182 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v23);
    // pto: %t__tmp_v988
    ;
    uint64_t v183 = (uint64_t) v17;
    TASSIGN(v182, v183);
    pipe_barrier(PIPE_V);
    TMAXS(v182, v180, v32);
    // pto: %t__tmp_v989
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v23);
    // pto: %t__tmp_v989
    ;
    uint64_t v185 = (uint64_t) v17;
    TASSIGN(v184, v185);
    pipe_barrier(PIPE_V);
    TMINS(v184, v182, v34);
    // pto: %c_blk_valid_inline5770__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v186 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v22);
    // pto: %c_blk_valid_inline5770__ssa_v0
    ;
    uint64_t v187 = (uint64_t) v18;
    TASSIGN(v186, v187);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    TROWMAX(v186, v184, v161);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    for (int64_t v188 = v27; v188 < v62; v188 += v22) {
      // pto: %t__tmp_v990
      ;
      float v189 = v186.GetValue(v188);
      // pto: %70
      ;
      int32_t v190 = (int32_t) v189;
      // pto: %71, %72, %73
      ;
      int64_t v191 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v60 + (uint64_t) v188) * (uint64_t) v24) + (uint64_t) v22);
      (v7)[v191] = v190;
    };
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  #endif // __DAV_VEC__

  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}