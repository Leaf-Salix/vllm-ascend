#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_topk_query_merge(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ int32_t* v3, __gm__ int32_t* v4, __gm__ float* v5, __gm__ float* v6, __gm__ int32_t* v7, int64_t v8, int64_t v9, int64_t v10, int32_t v11, int32_t v12) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  pto::MrgSortExecutedNumList v13 = pto::MrgSortExecutedNumList{0, 0, 0, 0};
  // pto: %c36864_i64
  const int64_t v14 = 36864;
  // pto: %c40960_i64
  const int64_t v15 = 40960;
  // pto: %c45056_i64
  const int64_t v16 = 45056;
  // pto: %c0_i64
  const int64_t v17 = 0;
  // pto: %c4096_i64
  const int64_t v18 = 4096;
  // pto: %c20480_i64
  const int64_t v19 = 20480;
  // pto: %c1_index
  const int64_t v20 = 1;
  // pto: %c27648_index
  const int64_t v21 = 27648;
  // pto: %c1024_index
  const int64_t v22 = 1024;
  // pto: %c512_index
  const int64_t v23 = 512;
  // pto: %c0_index
  const int64_t v24 = 0;
  // pto: %c5_index
  const int64_t v25 = 5;
  // pto: %c6_index
  const int64_t v26 = 6;
  // pto: %c4_index
  const int64_t v27 = 4;
  // pto: %c2_index
  const int64_t v28 = 2;
  // pto: %c262144_index
  const int64_t v29 = 262144;
  // pto: %c1023_index
  const int64_t v30 = 1023;
  // pto: %c8191_index
  const int64_t v31 = 8191;
  // pto: %c8192_index
  const int64_t v32 = 8192;
  // pto: %c3_index
  const int64_t v33 = 3;
  // pto: %c48_index
  const int64_t v34 = 48;
  // pto: %c24_index
  const int64_t v35 = 24;
  // pto: %c32_index
  const int64_t v36 = 32;
  // pto: %c8_index
  const int64_t v37 = 8;
  // pto: %c1_i64
  const int64_t v38 = 1;
  // pto: %c4_i64
  const int64_t v39 = 4;
  // pto: %c64_index
  const int64_t v40 = 64;
  // pto: %c4096_index
  const int64_t v41 = 4096;
  // pto: %c3072_index
  const int64_t v42 = 3072;
  // pto: %c2048_index
  const int64_t v43 = 2048;
  // pto: %cn1_i32
  const int32_t v44 = -1;
  // pto: %cst_31
  const float v45 = -3.40282347E+38f;
  // pto: %pair_arena__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %pair_arena__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %pair_arena__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %pair_arena__ssa_v0_view
  int64_t v49 = v21 * v22;
  // pto: %pair_arena__ssa_v0_view
  int64_t v50 = v48 * v49;
  // pto: %pair_arena__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v51 = pto::Shape<1, 1, 1, -1, -1>(v46, v47, v48, v21, v22);
  // pto: %pair_arena__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v52 = pto::Stride<-1, -1, -1, -1, -1>(v47 * v50, v50, v49, v22, v20);
  // pto: %pair_arena__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v53 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v51, v52);
  // pto: %topk_scores__ssa_v0_view
  const int64_t v54 = 1;
  // pto: %topk_scores__ssa_v0_view
  const int64_t v55 = 1;
  // pto: %topk_scores__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %topk_scores__ssa_v0_view
  int64_t v57 = (int64_t) v8;
  // pto: %topk_scores__ssa_v0_view
  int64_t v58 = v57 * v23;
  // pto: %topk_scores__ssa_v0_view
  int64_t v59 = v56 * v58;
  // pto: %topk_scores__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v60 = pto::Shape<1, 1, 1, -1, -1>(v54, v55, v56, v57, v23);
  // pto: %topk_scores__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v61 = pto::Stride<-1, -1, -1, -1, -1>(v55 * v59, v59, v58, v23, v20);
  // pto: %topk_scores__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v62 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v60, v61);
  // pto: %topk_indices__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %topk_indices__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %topk_indices__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %topk_indices__ssa_v0_view
  int64_t v66 = (int64_t) v8;
  // pto: %topk_indices__ssa_v0_view
  int64_t v67 = v66 * v23;
  // pto: %topk_indices__ssa_v0_view
  int64_t v68 = v65 * v67;
  // pto: %topk_indices__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v69 = pto::Shape<1, 1, 1, -1, -1>(v63, v64, v65, v66, v23);
  // pto: %topk_indices__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v70 = pto::Stride<-1, -1, -1, -1, -1>(v64 * v68, v68, v67, v23, v20);
  // pto: %topk_indices__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v71 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v69, v70);
  // pto: %root_inline3451__phi_v7
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v72 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
  // pto: %root_inline3451__phi_v7
  uint64_t v73 = (uint64_t) v14;
  TASSIGN(v72, v73);
  // pto: %root_inline3451__phi_v6
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v74 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
  // pto: %root_inline3451__phi_v6
  uint64_t v75 = (uint64_t) v14;
  TASSIGN(v74, v75);
  // pto: %worker__ssa_v0
  set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_S, PIPE_V, EVENT_ID1);
  // pto: %count_inline353__rv_v2
  int64_t v76;
  v76 = v24;
  for (int64_t v77 = v24; v77 < v9; v77 += v20) {
    // pto: %t__tile
    ;
    int32_t v78 = (v4)[v77];
    // pto: %3, %2
    ;
    int32_t v79 = (v4)[(int64_t) ((uint64_t) v77 + (uint64_t) v20)];
    // pto: %5
    ;
    int32_t v80 = (v2)[v77];
    // pto: %6, %7
    ;
    // pto: %count_inline353__phi_v4
    ;
    int64_t v81;
    if ((int64_t) v80 > v24) {
      // pto: %11
      ;
      uint64_t v82 = (uint64_t) v76;
      // pto: %4, %8, %1, %9, %10, %11
      ;
      v81 = (int64_t) (v82 + (uint64_t) ((int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v79) - (uint64_t) ((int64_t) v78)) + (uint64_t) v25) / v26));
    } else {
      v81 = v76;
    };
    v76 = v81;
  }
  // pto: %12
  bool v83 = v76 >= v27;
  // pto: %max_cache_count__rv_v2
  int64_t v84;
  v84 = v24;
  for (int64_t v85 = v24; v85 < v9; v85 += v20) {
    // pto: %14
    ;
    int32_t v86 = (v2)[v85];
    // pto: %15, %16
    ;
    int64_t v87 = (int64_t) v86 / v27;
    // pto: %17
    ;
    bool v88 = v84 < v87;
    // pto: %17
    ;
    int64_t v89 = v88 ? v87 : v84;
    v84 = v89;
  }
  // pto: %count_inline357__rv_v2
  int64_t v90;
  v90 = v24;
  for (int64_t v91 = v24; v91 < v9; v91 += v20) {
    // pto: %19
    ;
    int32_t v92 = (v4)[v91];
    // pto: %22, %21
    ;
    int32_t v93 = (v4)[(int64_t) ((uint64_t) v91 + (uint64_t) v20)];
    // pto: %24
    ;
    int32_t v94 = (v2)[v91];
    // pto: %25, %26
    ;
    // pto: %count_inline357__phi_v4
    ;
    int64_t v95;
    if ((int64_t) v94 > v24) {
      // pto: %30
      ;
      uint64_t v96 = (uint64_t) v90;
      // pto: %23, %27, %20, %28, %29, %30
      ;
      v95 = (int64_t) (v96 + (uint64_t) ((int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v93) - (uint64_t) ((int64_t) v92)) + (uint64_t) v20) / v28));
    } else {
      v95 = v90;
    };
    v90 = v95;
  }
  // pto: %13, %31
  bool v97 = (int64_t) v83 == v20;
  // pto: %query_groups__phi_v2
  int64_t v98 = v97 ? v76 : v90;
  // pto: %32
  bool v99 = v84 < v29;
  // pto: %32
  int64_t v100 = v99 ? v84 : v29;
  // pto: %33, %34
  int64_t v101 = (int64_t) ((uint64_t) v100 + (uint64_t) v30) / v22;
  // pto: %36, %37
  int64_t v102 = (int64_t) ((uint64_t) v100 + (uint64_t) v31) / v32;
  // pto: %38
  int64_t v103 = v102 < v20 ? v20 : v102;
  // pto: %39
  int64_t v104 = (int64_t) ((uint64_t) v98 * (uint64_t) v33);
  // pto: %40
  // pto: %leaf_multiple_inline360__phi_v6
  int64_t v105;
  if (v104 == v34) {
    v105 = v33;
  } else {
    // pto: %42
    ;
    // pto: %leaf_multiple_inline360__phi_v5
    ;
    int64_t v106;
    if (v104 == v35) {
      v106 = v33;
    } else {
      // pto: %43, %44, %leaf_multiple_inline360__phi_v4
      ;
      v106 = (int64_t) ((uint64_t) v98 * (uint64_t) v26) == v35 ? v26 : v20;
    };
    v105 = v106;
  }
  // pto: %45
  bool v107 = v105 > v20;
  // pto: %extra_leaves_inline359__phi_v3
  int64_t v108;
  // pto: %leaf_tiles_inline361__phi_v3
  int64_t v109;
  if (v107) {
    // pto: %46
    ;
    uint64_t v110 = (uint64_t) v105;
    // pto: %46, %47, %48
    ;
    int64_t v111 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v103 + v110) - (uint64_t) v20) / v105;
    // pto: %49
    ;
    uint64_t v112 = (uint64_t) v105;
    // pto: %49
    ;
    int64_t v113 = (int64_t) ((uint64_t) v111 * v112);
    // pto: %50
    ;
    // pto: %extra_leaves_inline359__phi_v2
    ;
    int64_t v114;
    // pto: %leaf_tiles_inline361__phi_v2
    ;
    int64_t v115;
    if (v113 <= v36) {
      // pto: %51
      ;
      int64_t v116 = v101 / v113;
      // pto: %52
      ;
      // pto: %53
      ;
      v114 = v101 % v113;
      v115 = v116 < v20 ? v20 : v116;
    } else {
      v114 = v24;
      v115 = v37;
    };
    v108 = v114;
    v109 = v115;
  } else {
    v108 = v24;
    v109 = v37;
  }
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t v117 = (int64_t) v11; v117 < v8; v117 += v34) {
    // pto: %54
    ;
    int32_t v118 = (v3)[v117];
    // pto: %55
    ;
    int64_t v119 = (int64_t) v118;
    // pto: %position_inline369__tile
    ;
    int64_t v120 = (v1)[v117];
    // pto: %57
    ;
    int64_t v121 = v119 < v24 ? v24 : v119;
    // pto: %56
    ;
    int32_t v122 = (v2)[v121];
    // pto: %60, %58, %59, %cache_len_inline380__phi_v2
    ;
    int64_t v123 = v119 < v24 ? v24 : (int64_t) v122 / v27;
    // pto: %61, %62
    ;
    int64_t v124 = (int64_t) ((uint64_t) v120 + (uint64_t) v38) / v39;
    // pto: %64
    ;
    int64_t v125 = v123 < v124 ? v123 : v124;
    // pto: %65
    ;
    int64_t v126 = v125 < v29 ? v125 : v29;
    // pto: %66
    ;
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    if (v126 > v24) {
      // pto: %67, %68
      ;
      int64_t v127 = (int64_t) ((uint64_t) v126 + (uint64_t) v30) / v22;
      // pto: %69
      ;
      uint64_t v128 = (uint64_t) v109;
      // pto: %69
      ;
      int64_t v129 = (int64_t) (v128 + (uint64_t) v20);
      // pto: %70
      ;
      uint64_t v130 = (uint64_t) v108;
      // pto: %71
      ;
      uint64_t v131 = (uint64_t) v109;
      // pto: %71, %73
      ;
      int64_t v132 = (int64_t) ((uint64_t) v127 + v131) / v129;
      // pto: %74
      ;
      bool v133 = v108 < v132;
      // pto: %74
      ;
      int64_t v134 = v133 ? v108 : v132;
      // pto: %75, %70
      ;
      int64_t v135 = (int64_t) ((uint64_t) v127 - (uint64_t) ((int64_t) v130 * (uint64_t) v129));
      // pto: %76
      ;
      int64_t v136 = v135 < v24 ? v24 : v135;
      // pto: %77
      ;
      uint64_t v137 = (uint64_t) v109;
      // pto: %77, %78, %79
      ;
      int64_t v138 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v136 + v137) - (uint64_t) v20) / v109;
      // pto: %80
      ;
      int64_t v139 = (int64_t) ((uint64_t) v134 + (uint64_t) v138);
      // pto: %81, %half_count_inline379__phi_v2
      ;
      int64_t v140 = v97 ? v139 : (int64_t) ((uint64_t) v139 * (uint64_t) v28);
      // pto: %83
      ;
      int64_t v141 = (int64_t) ((uint64_t) v117 * (uint64_t) v40);
      // pto: %root_inline3451__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v142 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
      // pto: %root_inline3451__ssa_v0
      ;
      uint64_t v143 = (uint64_t) v14;
      TASSIGN(v142, v143);
      // pto: %84
      ;
      int64_t v144 = v141 < v24 ? v24 : v141;
      // pto: %pair_arena__ssa_v0_pview
      ;
      __gm__ float* v145 = PTOAS__GLOBAL_TENSOR_DATA(v53);
      // pto: %pair_arena__ssa_v0_pview
      ;
      const int64_t v146 = 0;
      // pto: %pair_arena__ssa_v0_pview
      ;
      const int64_t v147 = 1024;
      // pto: %pair_arena__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 1024> v148 = pto::Shape<1, 1, 1, 1, 1024>();
      // pto: %pair_arena__ssa_v0_pview
      ;
      pto::Stride<1024, 1024, 1024, 1024, 1> v149 = pto::Stride<1024, 1024, 1024, 1024, 1>();
      // pto: %pair_arena__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v150 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v145 + (v146 + v144 * v147), v148, v149);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      TLOAD(v142, v150);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
      pipe_barrier(PIPE_ALL);
      for (int64_t v151 = v20; v151 < v140; v151 += v33) {
        // pto: %incoming1_inline3448__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v152 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
        // pto: %incoming1_inline3448__ssa_v0
        ;
        uint64_t v153 = (uint64_t) v15;
        TASSIGN(v152, v153);
        // pto: %85
        ;
        int64_t v154 = (int64_t) ((uint64_t) v141 + (uint64_t) v151);
        // pto: %86
        ;
        int64_t v155 = v154 < v24 ? v24 : v154;
        // pto: %87
        ;
        __gm__ float* v156 = PTOAS__GLOBAL_TENSOR_DATA(v53);
        // pto: %87
        ;
        const int64_t v157 = 0;
        // pto: %87
        ;
        const int64_t v158 = 1024;
        // pto: %87
        ;
        pto::Shape<1, 1, 1, 1, 1024> v159 = pto::Shape<1, 1, 1, 1, 1024>();
        // pto: %87
        ;
        pto::Stride<1024, 1024, 1024, 1024, 1> v160 = pto::Stride<1024, 1024, 1024, 1024, 1>();
        // pto: %87
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v161 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v156 + (v157 + v155 * v158), v159, v160);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
        TLOAD(v152, v161);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %88, %89
        ;
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        if ((int64_t) ((uint64_t) v151 + (uint64_t) v28) < v140) {
          // pto: %incoming2_inline3449__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v162 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
          // pto: %incoming2_inline3449__ssa_v0
          ;
          uint64_t v163 = (uint64_t) v16;
          TASSIGN(v162, v163);
          // pto: %91
          ;
          int64_t v164 = (int64_t) ((uint64_t) v154 + (uint64_t) v20);
          // pto: %92
          ;
          int64_t v165 = v164 < v24 ? v24 : v164;
          // pto: %93
          ;
          __gm__ float* v166 = PTOAS__GLOBAL_TENSOR_DATA(v53);
          // pto: %93
          ;
          const int64_t v167 = 0;
          // pto: %93
          ;
          const int64_t v168 = 1024;
          // pto: %93
          ;
          pto::Shape<1, 1, 1, 1, 1024> v169 = pto::Shape<1, 1, 1, 1, 1024>();
          // pto: %93
          ;
          pto::Stride<1024, 1024, 1024, 1024, 1> v170 = pto::Stride<1024, 1024, 1024, 1024, 1>();
          // pto: %93
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v171 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v166 + (v167 + v165 * v168), v169, v170);
          TLOAD(v162, v171);
          // pto: %incoming3_inline3446__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v172 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
          // pto: %incoming3_inline3446__ssa_v0
          ;
          uint64_t v173 = (uint64_t) v17;
          TASSIGN(v172, v173);
          // pto: %95
          ;
          int64_t v174 = (int64_t) ((uint64_t) v154 + (uint64_t) v28);
          // pto: %96
          ;
          int64_t v175 = v174 < v24 ? v24 : v174;
          // pto: %97
          ;
          __gm__ float* v176 = PTOAS__GLOBAL_TENSOR_DATA(v53);
          // pto: %97
          ;
          const int64_t v177 = 0;
          // pto: %97
          ;
          const int64_t v178 = 1024;
          // pto: %97
          ;
          pto::Shape<1, 1, 1, 1, 1024> v179 = pto::Shape<1, 1, 1, 1, 1024>();
          // pto: %97
          ;
          pto::Stride<1024, 1024, 1024, 1024, 1> v180 = pto::Stride<1024, 1024, 1024, 1024, 1>();
          // pto: %97
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v181 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v176 + (v177 + v175 * v178), v179, v180);
          TLOAD(v172, v181);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          // pto: %merge_tmp4_inline3445__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v182 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v41);
          // pto: %merge_tmp4_inline3445__ssa_v0
          ;
          uint64_t v183 = (uint64_t) v18;
          TASSIGN(v182, v183);
          // pto: %merged4_inline3444__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v41);
          // pto: %merged4_inline3444__ssa_v0
          ;
          uint64_t v185 = (uint64_t) v19;
          TASSIGN(v184, v185);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          pipe_barrier(PIPE_V);
          TMRGSORT<Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, true>(v184, v13, v182, v172, v162, v152, v142);
          // pto: %root_inline3451__ssa_v3
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v186 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
          // pto: %root_inline3451__ssa_v3
          ;
          uint64_t v187 = (uint64_t) v14;
          TASSIGN(v186, v187);
          pipe_barrier(PIPE_V);
          uint16_t v188 = static_cast<uint16_t>(v24);
          uint16_t v189 = static_cast<uint16_t>(v24);
          TEXTRACT(v186, v184, v188, v189);
        } else {
          // pto: %98, %99
          ;
          if ((int64_t) ((uint64_t) v151 + (uint64_t) v20) < v140) {
            // pto: %incoming2_inline3449__ssa_v1
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v190 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
            // pto: %incoming2_inline3449__ssa_v1
            ;
            uint64_t v191 = (uint64_t) v16;
            TASSIGN(v190, v191);
            // pto: %101
            ;
            int64_t v192 = (int64_t) ((uint64_t) v154 + (uint64_t) v20);
            // pto: %102
            ;
            int64_t v193 = v192 < v24 ? v24 : v192;
            // pto: %103
            ;
            __gm__ float* v194 = PTOAS__GLOBAL_TENSOR_DATA(v53);
            // pto: %103
            ;
            const int64_t v195 = 0;
            // pto: %103
            ;
            const int64_t v196 = 1024;
            // pto: %103
            ;
            pto::Shape<1, 1, 1, 1, 1024> v197 = pto::Shape<1, 1, 1, 1, 1024>();
            // pto: %103
            ;
            pto::Stride<1024, 1024, 1024, 1024, 1> v198 = pto::Stride<1024, 1024, 1024, 1024, 1>();
            // pto: %103
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v199 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v194 + (v195 + v193 * v196), v197, v198);
            TLOAD(v190, v199);
            set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
            // pto: %merge_tmp3_inline3447__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v200 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v42);
            // pto: %merge_tmp3_inline3447__ssa_v0
            ;
            uint64_t v201 = (uint64_t) v18;
            TASSIGN(v200, v201);
            // pto: %merged3_inline3443__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v202 = Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v42);
            // pto: %merged3_inline3443__ssa_v0
            ;
            uint64_t v203 = (uint64_t) v19;
            TASSIGN(v202, v203);
            wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
            pipe_barrier(PIPE_V);
            TMRGSORT<Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 3072, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, true>(v202, v13, v200, v190, v152, v142);
            // pto: %root_inline3451__ssa_v4
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v204 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
            // pto: %root_inline3451__ssa_v4
            ;
            uint64_t v205 = (uint64_t) v14;
            TASSIGN(v204, v205);
            pipe_barrier(PIPE_V);
            uint16_t v206 = static_cast<uint16_t>(v24);
            uint16_t v207 = static_cast<uint16_t>(v24);
            TEXTRACT(v204, v202, v206, v207);
          } else {
            // pto: %merge_tmp2_inline3442__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v208 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v43);
            // pto: %merge_tmp2_inline3442__ssa_v0
            ;
            uint64_t v209 = (uint64_t) v18;
            TASSIGN(v208, v209);
            // pto: %merged2_inline3441__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v43);
            // pto: %merged2_inline3441__ssa_v0
            ;
            uint64_t v211 = (uint64_t) v19;
            TASSIGN(v210, v211);
            pipe_barrier(PIPE_V);
            TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, false>(v210, v13, v208, v152, v142);
            // pto: %root_inline3451__ssa_v5
            ;
            Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v212 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
            // pto: %root_inline3451__ssa_v5
            ;
            uint64_t v213 = (uint64_t) v14;
            TASSIGN(v212, v213);
            pipe_barrier(PIPE_V);
            uint16_t v214 = static_cast<uint16_t>(v24);
            uint16_t v215 = static_cast<uint16_t>(v24);
            TEXTRACT(v212, v210, v214, v215);
          };
        };
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      };
      // pto: %root_pairs_inline382__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v22);
      // pto: %root_pairs_inline382__ssa_v0
      ;
      uint64_t v217 = (uint64_t) v14;
      TASSIGN(v216, v217);
      // pto: %root_scores_inline368__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v23);
      // pto: %root_scores_inline368__ssa_v0
      ;
      uint64_t v219 = (uint64_t) v18;
      TASSIGN(v218, v219);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      pipe_barrier(PIPE_ALL);
      wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
      TGATHER<Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, MaskPattern::P0101>(v218, v216);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %106
      ;
      int64_t v220 = v117 < v24 ? v24 : v117;
      // pto: %topk_scores__ssa_v0_pview
      ;
      __gm__ float* v221 = PTOAS__GLOBAL_TENSOR_DATA(v62);
      // pto: %topk_scores__ssa_v0_pview
      ;
      const int64_t v222 = 0;
      // pto: %topk_scores__ssa_v0_pview
      ;
      const int64_t v223 = 512;
      // pto: %topk_scores__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v224 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %topk_scores__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 512, 1> v225 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %topk_scores__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v226 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v221 + (v222 + v220 * v223), v224, v225);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v226, v218);
      // pto: %root_indices_inline366__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v23);
      // pto: %root_indices_inline366__ssa_v0
      ;
      uint64_t v228 = (uint64_t) v18;
      TASSIGN(v227, v228);
      pipe_barrier(PIPE_ALL);
      TGATHER<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, MaskPattern::P1010>(v227, v216);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      set_flag(PIPE_V, PIPE_S, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      // pto: %107
      ;
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
      if (v126 >= v23) {
        // pto: %topk_indices__ssa_v0_pview
        ;
        __gm__ int32_t* v229 = PTOAS__GLOBAL_TENSOR_DATA(v71);
        // pto: %topk_indices__ssa_v0_pview
        ;
        const int64_t v230 = 0;
        // pto: %topk_indices__ssa_v0_pview
        ;
        const int64_t v231 = 512;
        // pto: %topk_indices__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 512> v232 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %topk_indices__ssa_v0_pview
        ;
        pto::Stride<512, 512, 512, 512, 1> v233 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %topk_indices__ssa_v0_pview
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v234 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v229 + (v230 + v220 * v231), v232, v233);
        TSTORE(v234, v227);
      } else {
        // pto: %output_indices_inline364__ssa_v0
        ;
        Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v23);
        // pto: %output_indices_inline364__ssa_v0
        ;
        uint64_t v236 = (uint64_t) v19;
        TASSIGN(v235, v236);
        TEXPANDS(v235, v44);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        set_flag(PIPE_V, PIPE_S, EVENT_ID1);
        wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
        for (int64_t v237 = v24; v237 < v126; v237 += v20) {
          // pto: %t__tmp_v12
          ;
          int32_t v238 = v227.GetValue(v237);
          v235.SetValue(v237, v238);
        };
        set_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
        // pto: %112
        ;
        __gm__ int32_t* v239 = PTOAS__GLOBAL_TENSOR_DATA(v71);
        // pto: %112
        ;
        const int64_t v240 = 0;
        // pto: %112
        ;
        const int64_t v241 = 512;
        // pto: %112
        ;
        pto::Shape<1, 1, 1, 1, 512> v242 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %112
        ;
        pto::Stride<512, 512, 512, 512, 1> v243 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %112
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v244 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v239 + (v240 + v220 * v241), v242, v243);
        wait_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v244, v235);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
      set_flag(PIPE_S, PIPE_V, EVENT_ID1);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    } else {
      // pto: %t__tmp_v13
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v245 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v23);
      // pto: %t__tmp_v13
      ;
      uint64_t v246 = (uint64_t) v18;
      TASSIGN(v245, v246);
      pipe_barrier(PIPE_V);
      pipe_barrier(PIPE_ALL);
      TEXPANDS(v245, v45);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      // pto: %113
      ;
      int64_t v247 = v117 < v24 ? v24 : v117;
      // pto: %114
      ;
      __gm__ float* v248 = PTOAS__GLOBAL_TENSOR_DATA(v62);
      // pto: %114
      ;
      const int64_t v249 = 0;
      // pto: %114
      ;
      const int64_t v250 = 512;
      // pto: %114
      ;
      pto::Shape<1, 1, 1, 1, 512> v251 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %114
      ;
      pto::Stride<512, 512, 512, 512, 1> v252 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %114
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v253 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v248 + (v249 + v247 * v250), v251, v252);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      TSTORE(v253, v245);
      // pto: %t__tmp_v14
      ;
      Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v254 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v23);
      // pto: %t__tmp_v14
      ;
      uint64_t v255 = (uint64_t) v18;
      TASSIGN(v254, v255);
      pipe_barrier(PIPE_ALL);
      TEXPANDS(v254, v44);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
      // pto: %116
      ;
      __gm__ int32_t* v256 = PTOAS__GLOBAL_TENSOR_DATA(v71);
      // pto: %116
      ;
      const int64_t v257 = 0;
      // pto: %116
      ;
      const int64_t v258 = 512;
      // pto: %116
      ;
      pto::Shape<1, 1, 1, 1, 512> v259 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %116
      ;
      pto::Stride<512, 512, 512, 512, 1> v260 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %116
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v261 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v256 + (v257 + v247 * v258), v259, v260);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
      TSTORE(v261, v254);
    };
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}