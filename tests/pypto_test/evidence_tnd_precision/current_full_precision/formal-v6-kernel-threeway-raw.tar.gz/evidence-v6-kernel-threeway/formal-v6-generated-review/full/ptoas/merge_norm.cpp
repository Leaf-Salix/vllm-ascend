#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void merge_norm(__gm__ int32_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ float* v4, __gm__ float* v5, __gm__ bfloat16_t* v6, int64_t v7, int64_t v8, int64_t v9, int32_t v10, int32_t v11) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c8192_i64
  const int64_t v12 = 8192;
  // pto: %c40960_i64
  const int64_t v13 = 40960;
  // pto: %c0_i64
  const int64_t v14 = 0;
  // pto: %c4096_i64
  const int64_t v15 = 4096;
  // pto: %c57344_i64
  const int64_t v16 = 57344;
  // pto: %c57600_i64
  const int64_t v17 = 57600;
  // pto: %c57856_i64
  const int64_t v18 = 57856;
  // pto: %c61952_i64
  const int64_t v19 = 61952;
  const int64_t v20 = 16384;
  // pto: %c1_index
  const int64_t v21 = 1;
  // pto: %c512_index
  const int64_t v22 = 512;
  // pto: %c64_index
  const int64_t v23 = 64;
  // pto: %c384_index
  const int64_t v24 = 384;
  // pto: %c3072_index
  const int64_t v25 = 3072;
  // pto: %c4096_index
  const int64_t v26 = 4096;
  // pto: %c192_index
  const int64_t v27 = 192;
  // pto: %c0_i32
  const int32_t v28 = 0;
  // pto: %c2_i32
  const int32_t v29 = 2;
  // pto: %c449_i32
  const int32_t v30 = 449;
  // pto: %c16_index
  const int64_t v31 = 16;
  // pto: %c512_i32
  const int32_t v32 = 512;
  // pto: %c4_index
  const int64_t v33 = 4;
  // pto: %c48_index
  const int64_t v34 = 48;
  // pto: %c0_index
  const int64_t v35 = 0;
  // pto: %c448_index
  const int64_t v36 = 448;
  // pto: %cst_25
  const bfloat16_t v37 = 0.0f;
  // pto: %c2_index
  const int64_t v38 = 2;
  // pto: %c8_index
  const int64_t v39 = 8;
  // pto: %attn_li_inline1383__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %attn_li_inline1383__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %attn_li_inline1383__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %attn_li_inline1383__ssa_v0_view
  int64_t v43 = (int64_t) v9;
  // pto: %attn_li_inline1383__ssa_v0_view
  int64_t v44 = v43 * v21;
  // pto: %attn_li_inline1383__ssa_v0_view
  int64_t v45 = v42 * v44;
  // pto: %attn_li_inline1383__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v46 = pto::Shape<1, 1, 1, -1, -1>(v40, v41, v42, v43, v21);
  // pto: %attn_li_inline1383__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v47 = pto::Stride<-1, -1, -1, -1, -1>(v41 * v45, v45, v44, v21, (int64_t) v9);
  // pto: %attn_li_inline1383__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v48 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v2, v46, v47);
  // pto: %attn_oi_inline1384__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %attn_oi_inline1384__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %attn_oi_inline1384__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %attn_oi_inline1384__ssa_v0_view
  int64_t v52 = (int64_t) v9;
  // pto: %attn_oi_inline1384__ssa_v0_view
  int64_t v53 = v52 * v22;
  // pto: %attn_oi_inline1384__ssa_v0_view
  int64_t v54 = v51 * v53;
  // pto: %attn_oi_inline1384__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v55 = pto::Shape<1, 1, 1, -1, -1>(v49, v50, v51, v52, v22);
  // pto: %attn_oi_inline1384__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v56 = pto::Stride<-1, -1, -1, -1, -1>(v50 * v54, v54, v53, v22, v21);
  // pto: %attn_oi_inline1384__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v57 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v55, v56);
  // pto: %rope_cos_il_inline1391__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %rope_cos_il_inline1391__ssa_v0_view
  const int64_t v59 = 1;
  // pto: %rope_cos_il_inline1391__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %rope_cos_il_inline1391__ssa_v0_view
  int64_t v61 = (int64_t) v8;
  // pto: %rope_cos_il_inline1391__ssa_v0_view
  int64_t v62 = v61 * v23;
  // pto: %rope_cos_il_inline1391__ssa_v0_view
  int64_t v63 = v60 * v62;
  // pto: %rope_cos_il_inline1391__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v64 = pto::Shape<1, 1, 1, -1, -1>(v58, v59, v60, v61, v23);
  // pto: %rope_cos_il_inline1391__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v65 = pto::Stride<-1, -1, -1, -1, -1>(v59 * v63, v63, v62, v23, v21);
  // pto: %rope_cos_il_inline1391__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v66 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v64, v65);
  // pto: %rope_sin_signed_inline1394__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %rope_sin_signed_inline1394__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %rope_sin_signed_inline1394__ssa_v0_view
  const int64_t v69 = 1;
  // pto: %rope_sin_signed_inline1394__ssa_v0_view
  int64_t v70 = v24 * v23;
  // pto: %rope_sin_signed_inline1394__ssa_v0_view
  int64_t v71 = v69 * v70;
  // pto: %rope_sin_signed_inline1394__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v72 = pto::Shape<1, 1, 1, -1, -1>(v67, v68, v69, v24, v23);
  // pto: %rope_sin_signed_inline1394__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v73 = pto::Stride<-1, -1, -1, -1, -1>(v68 * v71, v71, v70, v23, v21);
  // pto: %rope_sin_signed_inline1394__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v74 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v72, v73);
  // pto: %o_packed_heads__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %o_packed_heads__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %o_packed_heads__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %o_packed_heads__ssa_v0_view
  int64_t v78 = v25 * v26;
  // pto: %o_packed_heads__ssa_v0_view
  int64_t v79 = v77 * v78;
  // pto: %o_packed_heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v80 = pto::Shape<1, 1, 1, -1, -1>(v75, v76, v77, v25, v26);
  // pto: %o_packed_heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v81 = pto::Stride<-1, -1, -1, -1, -1>(v76 * v79, v79, v78, v26, v21);
  // pto: %o_packed_heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v82 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v80, v81);
  // pto: %n_full_bf16_inline1367__phi_v2
  Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v83 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v22);
  // pto: %n_full_bf16_inline1367__phi_v2
  uint64_t v84 = (uint64_t) v12;
  TASSIGN(v83, v84);
  // pto: %m_worker_inline1390__ssa_v0
  // pto: %m_idx_inline1374__ci_tmp_v0
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v85 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
  // pto: %m_idx_inline1374__ci_tmp_v0
  uint64_t v86 = (uint64_t) v12;
  TASSIGN(v85, v86);
  // pto: %m_idx_inline1374__ssa_v0
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v23);
  // pto: %m_idx_inline1374__ssa_v0
  uint64_t v88 = (uint64_t) v13;
  TASSIGN(v87, v88);
  // pto: %ci_tmp_view
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v89;
  TRESHAPE(v89, v85);
  // pto: %ci_dst_view
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v90;
  TRESHAPE(v90, v87);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v90, v28, v89);
  // pto: %m_rem_tmp_inline1371__ssa_v0
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v91 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v23);
  // pto: %m_rem_tmp_inline1371__ssa_v0
  uint64_t v92 = (uint64_t) v12;
  TASSIGN(v91, v92);
  // pto: %m_lane_inline1396__ssa_v0
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v23);
  // pto: %m_lane_inline1396__ssa_v0
  uint64_t v94 = (uint64_t) v14;
  TASSIGN(v93, v94);
  pipe_barrier(PIPE_V);
  TREMS(v93, v87, v29, v91);
  // pto: %t__tmp_v1035
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v23);
  // pto: %t__tmp_v1035
  uint64_t v96 = (uint64_t) v12;
  TASSIGN(v95, v96);
  pipe_barrier(PIPE_V);
  TMULS(v95, v93, v29);
  // pto: %t__tmp_v1036
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v23);
  // pto: %t__tmp_v1036
  uint64_t v98 = (uint64_t) v12;
  TASSIGN(v97, v98);
  pipe_barrier(PIPE_V);
  TSUB(v97, v87, v95);
  // pto: %m_swap_row_inline1380__ssa_v0
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v23);
  // pto: %m_swap_row_inline1380__ssa_v0
  uint64_t v100 = (uint64_t) v13;
  TASSIGN(v99, v100);
  pipe_barrier(PIPE_V);
  TADDS(v99, v97, v30);
  // pto: %m_swap_base_inline1376__ssa_v0
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v23);
  // pto: %m_swap_base_inline1376__ssa_v0
  uint64_t v102 = (uint64_t) v12;
  TASSIGN(v101, v102);
  // pto: %m_swap_source_inline1404__ssa_v0
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v23);
  // pto: %m_swap_source_inline1404__ssa_v0
  uint64_t v104 = (uint64_t) v12;
  TASSIGN(v103, v104);
  pipe_barrier(PIPE_V);
  TCOLEXPAND(v103, v99);
  // pto: %t__ci_tmp_v1
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v105 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
  // pto: %t__ci_tmp_v1
  uint64_t v106 = (uint64_t) v13;
  TASSIGN(v105, v106);
  // pto: %t__tmp_v1037
  Tile<TileType::Vec, int32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v107 = Tile<TileType::Vec, int32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v31);
  // pto: %t__tmp_v1037
  uint64_t v108 = (uint64_t) v14;
  TASSIGN(v107, v108);
  // pto: %0
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v109;
  TRESHAPE(v109, v105);
  // pto: %1
  Tile<TileType::Vec, int32_t, 1, 16, BLayout::RowMajor, 1, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v110;
  TRESHAPE(v110, v107);
  pipe_barrier(PIPE_V);
  TCI<Tile<TileType::Vec, int32_t, 1, 16, BLayout::RowMajor, 1, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v110, v28, v109);
  // pto: %m_row_offsets_inline1397__ssa_v0
  Tile<TileType::Vec, int32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Vec, int32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v31);
  // pto: %m_row_offsets_inline1397__ssa_v0
  uint64_t v112 = (uint64_t) v13;
  TASSIGN(v111, v112);
  pipe_barrier(PIPE_V);
  TMULS(v111, v107, v32);
  // pto: %t__tmp_v1038
  Tile<TileType::Vec, int32_t, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v113 = Tile<TileType::Vec, int32_t, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v21);
  // pto: %t__tmp_v1038
  uint64_t v114 = (uint64_t) v13;
  TASSIGN(v113, v114);
  // pto: %m_swap_idx_inline1398__ssa_v0
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v23);
  // pto: %m_swap_idx_inline1398__ssa_v0
  uint64_t v116 = (uint64_t) v14;
  TASSIGN(v115, v116);
  pipe_barrier(PIPE_V);
  TROWEXPANDADD(v115, v103, v113);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %m_gather_tmp_inline1393__ssa_v0
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v23);
  // pto: %m_gather_tmp_inline1393__ssa_v0
  uint64_t v118 = (uint64_t) v15;
  TASSIGN(v117, v118);
  // pto: %2
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v119 = (int64_t) v10; v119 < ((int64_t) ((uint64_t) v7 * (uint64_t) v33)); v119 += v34) {
    // pto: %3
    ;
    int64_t v120 = v119 / v33;
    // pto: %7
    ;
    int64_t v121 = (int64_t) ((uint64_t) v119 * (uint64_t) v31);
    // pto: %t__tile
    ;
    int32_t v122 = (v1)[v120];
    // pto: %8, %9
    ;
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    if ((int64_t) v122 >= v35) {
      // pto: %m_li_inline1378__ssa_v0
      ;
      Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v123 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v21);
      // pto: %m_li_inline1378__ssa_v0
      ;
      uint64_t v124 = (uint64_t) v13;
      TASSIGN(v123, v124);
      // pto: %10
      ;
      int64_t v125 = v121 < v35 ? v35 : v121;
      // pto: %attn_li_inline1383__ssa_v0_pview
      ;
      int64_t v126 = (int64_t) v9;
      // pto: %attn_li_inline1383__ssa_v0_pview
      ;
      const int64_t v127 = 0;
      // pto: %attn_li_inline1383__ssa_v0_pview
      ;
      __gm__ float* v128 = PTOAS__GLOBAL_TENSOR_DATA(v48);
      // pto: %attn_li_inline1383__ssa_v0_pview
      ;
      const int64_t v129 = 1;
      // pto: %attn_li_inline1383__ssa_v0_pview
      ;
      const int64_t v130 = 1;
      // pto: %attn_li_inline1383__ssa_v0_pview
      ;
      const int64_t v131 = 1;
      // pto: %attn_li_inline1383__ssa_v0_pview
      ;
      int64_t v132 = v31 * v21;
      // pto: %attn_li_inline1383__ssa_v0_pview
      ;
      int64_t v133 = v131 * v132;
      // pto: %attn_li_inline1383__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 1> v134 = pto::Shape<1, 1, 1, 16, 1>(v129, v130, v131, v31, v21);
      // pto: %attn_li_inline1383__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v135 = pto::Stride<-1, -1, -1, -1, -1>(v130 * v133, v133, v132, v21, v126);
      // pto: %attn_li_inline1383__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v136 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v128 + (v127 + v125 * v21 + v35 * v126), v134, v135);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      TLOAD(v123, v136);
      // pto: %m_oi_inline1402__ssa_v0
      ;
      Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v22);
      // pto: %m_oi_inline1402__ssa_v0
      ;
      uint64_t v138 = (uint64_t) v12;
      TASSIGN(v137, v138);
      // pto: %attn_oi_inline1384__ssa_v0_pview
      ;
      __gm__ float* v139 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %attn_oi_inline1384__ssa_v0_pview
      ;
      const int64_t v140 = 0;
      // pto: %attn_oi_inline1384__ssa_v0_pview
      ;
      const int64_t v141 = 512;
      // pto: %attn_oi_inline1384__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 512> v142 = pto::Shape<1, 1, 1, 16, 512>();
      // pto: %attn_oi_inline1384__ssa_v0_pview
      ;
      pto::Stride<8192, 8192, 8192, 512, 1> v143 = pto::Stride<8192, 8192, 8192, 512, 1>();
      // pto: %attn_oi_inline1384__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v144 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v139 + (v140 + v125 * v141), v142, v143);
      TLOAD(v137, v144);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %n_full_inline1403__ssa_v0
      ;
      Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v22);
      // pto: %n_full_inline1403__ssa_v0
      ;
      uint64_t v146 = (uint64_t) v12;
      TASSIGN(v145, v146);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      TROWEXPANDDIV(v145, v137, v123);
      // pto: %n_bf16_inline1405__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v22);
      // pto: %n_bf16_inline1405__ssa_v0
      ;
      uint64_t v148 = (uint64_t) v13;
      TASSIGN(v147, v148);
      pipe_barrier(PIPE_V);
      RoundMode v149 = RoundMode::CAST_RINT;
      SaturationMode v150 = SaturationMode::ON;
      TCVT(v147, v145, v149, v150);
      // pto: %n_rounded_inline1385__ssa_v0
      ;
      Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v151 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v22);
      // pto: %n_rounded_inline1385__ssa_v0
      ;
      uint64_t v152 = (uint64_t) v12;
      TASSIGN(v151, v152);
      pipe_barrier(PIPE_V);
      RoundMode v153 = RoundMode::CAST_ROUND;
      SaturationMode v154 = SaturationMode::ON;
      TCVT(v151, v147, v153, v154);
      // pto: %m_cos_il_inline1377__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v23);
      // pto: %m_cos_il_inline1377__ssa_v0
      ;
      uint64_t v156 = (uint64_t) v16;
      TASSIGN(v155, v156);
      // pto: %12
      ;
      int64_t v157 = v120 < v35 ? v35 : v120;
      // pto: %rope_cos_il_inline1391__ssa_v0_pview
      ;
      __gm__ float* v158 = PTOAS__GLOBAL_TENSOR_DATA(v66);
      // pto: %rope_cos_il_inline1391__ssa_v0_pview
      ;
      const int64_t v159 = 0;
      // pto: %rope_cos_il_inline1391__ssa_v0_pview
      ;
      const int64_t v160 = 64;
      // pto: %rope_cos_il_inline1391__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 64> v161 = pto::Shape<1, 1, 1, 1, 64>();
      // pto: %rope_cos_il_inline1391__ssa_v0_pview
      ;
      pto::Stride<64, 64, 64, 64, 1> v162 = pto::Stride<64, 64, 64, 64, 1>();
      // pto: %rope_cos_il_inline1391__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v163 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v158 + (v159 + v157 * v160), v161, v162);
      TLOAD(v155, v163);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %m_sin_signed_inline1369__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v164 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v23);
      // pto: %m_sin_signed_inline1369__ssa_v0
      ;
      uint64_t v165 = (uint64_t) v17;
      TASSIGN(v164, v165);
      // pto: %rope_sin_signed_inline1394__ssa_v0_pview
      ;
      __gm__ float* v166 = PTOAS__GLOBAL_TENSOR_DATA(v74);
      // pto: %rope_sin_signed_inline1394__ssa_v0_pview
      ;
      const int64_t v167 = 0;
      // pto: %rope_sin_signed_inline1394__ssa_v0_pview
      ;
      const int64_t v168 = 64;
      // pto: %rope_sin_signed_inline1394__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 64> v169 = pto::Shape<1, 1, 1, 1, 64>();
      // pto: %rope_sin_signed_inline1394__ssa_v0_pview
      ;
      pto::Stride<64, 64, 64, 64, 1> v170 = pto::Stride<64, 64, 64, 64, 1>();
      // pto: %rope_sin_signed_inline1394__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v171 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v166 + (v167 + v157 * v168), v169, v170);
      TLOAD(v164, v171);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %m_swapped_inline1368__ssa_v0
      ;
      Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v172 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v23);
      // pto: %m_swapped_inline1368__ssa_v0
      ;
      uint64_t v173 = (uint64_t) v18;
      TASSIGN(v172, v173);
      pipe_barrier(PIPE_V);
      TGATHER(v172, v151, v115, v117);
      // pto: %m_rope_inline1370__ssa_v0_textract
      ;
      Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v23);
      // pto: %m_rope_inline1370__ssa_v0_textract
      ;
      uint64_t v175 = (uint64_t) v19;
      TASSIGN(v174, v175);
      uint16_t v176 = static_cast<uint16_t>(v35);
      uint16_t v177 = static_cast<uint16_t>(v36);
      TEXTRACT(v174, v151, v176, v177);
      // pto: %t__tmp_v1040
      ;
      Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v178 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v23);
      // pto: %t__tmp_v1040
      ;
      uint64_t v179 = (uint64_t) v12;
      TASSIGN(v178, v179);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      TCOLEXPANDMUL(v178, v174, v155);
      // pto: %t__tmp_v1041
      ;
      Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v180 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v23);
      // pto: %t__tmp_v1041
      ;
      uint64_t v181 = (uint64_t) v18;
      TASSIGN(v180, v181);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      TCOLEXPANDMUL(v180, v172, v164);
      // pto: %m_rot_inline1392__ssa_v0
      ;
      Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v182 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v23);
      // pto: %m_rot_inline1392__ssa_v0
      ;
      uint64_t v183 = (uint64_t) v12;
      TASSIGN(v182, v183);
      pipe_barrier(PIPE_V);
      TADD(v182, v178, v180);
      // pto: %n_rope_bf16_inline1381__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v23);
      // pto: %n_rope_bf16_inline1381__ssa_v0
      ;
      uint64_t v185 = (uint64_t) v18;
      TASSIGN(v184, v185);
      pipe_barrier(PIPE_V);
      RoundMode v186 = RoundMode::CAST_RINT;
      SaturationMode v187 = SaturationMode::ON;
      TCVT(v184, v182, v186, v187);
      // pto: %t__tmp_v1042
      ;
      Tile<TileType::Vec, bfloat16_t, 16, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v188 = Tile<TileType::Vec, bfloat16_t, 16, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v36);
      // pto: %t__tmp_v1042
      ;
      uint64_t v189 = (uint64_t) v13;
      TASSIGN(v188, v189);
      // pto: %slice_view
      ;
      Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, 16, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v190;
      // pto: %slice_view
      ;
      uint64_t v191 = (uint64_t) v13;
      TASSIGN(v190, v191);
      // pto: %n_full_bf16_inline1367__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v22);
      // pto: %n_full_bf16_inline1367__ssa_v0
      ;
      uint64_t v193 = (uint64_t) v12;
      TASSIGN(v192, v193);
      pipe_barrier(PIPE_V);
      TCONCAT(v192, v190, v184);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    } else {
      // pto: %n_full_bf16_inline1367__ssa_v1
      ;
      Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v194 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v22);
      // pto: %n_full_bf16_inline1367__ssa_v1
      ;
      uint64_t v195 = (uint64_t) v12;
      TASSIGN(v194, v195);
      pipe_barrier(PIPE_V);
      TEXPANDS(v194, v37);
    };
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %n_group_bf16_inline1366__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 2, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Vec, bfloat16_t, 2, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v26);
    // pto: %n_group_bf16_inline1366__ssa_v0
    ;
    uint64_t v197 = (uint64_t) v12;
    TASSIGN(v196, v197);
    // pto: %n_pack_first_inline1365__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v198 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v26);
    // pto: %n_pack_first_inline1365__ssa_v0
    ;
    uint64_t v199 = (uint64_t) v12;
    TASSIGN(v198, v199);
    // pto: %14
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v200;
    // pto: %14
    ;
    uint64_t v201 = (uint64_t) v12;
    TASSIGN(v200, v201);
    // pto: %n_pack_second_inline1400__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v202 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v26);
    // pto: %n_pack_second_inline1400__ssa_v0
    ;
    uint64_t v203 = (uint64_t) v20;
    TASSIGN(v202, v203);
    // pto: %15
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v204;
    // pto: %15
    ;
    uint64_t v205 = (uint64_t) v20;
    TASSIGN(v204, v205);
    // pto: %5, %4, %6, %16, %17, %18
    ;
    int64_t v206 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v119 - (uint64_t) ((int64_t) (uint64_t) v120 * (uint64_t) v33)) * (uint64_t) v31) / v39) * (uint64_t) v24) + (uint64_t) v120);
    // pto: %19
    ;
    int64_t v207 = (int64_t) ((uint64_t) v206 + (uint64_t) v24);
    // pto: %20
    ;
    int64_t v208 = v206 < v35 ? v35 : v206;
    // pto: %o_packed_heads__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v209 = PTOAS__GLOBAL_TENSOR_DATA(v82);
    // pto: %o_packed_heads__ssa_v0_pview
    ;
    const int64_t v210 = 0;
    // pto: %o_packed_heads__ssa_v0_pview
    ;
    const int64_t v211 = 4096;
    // pto: %o_packed_heads__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 4096> v212 = pto::Shape<1, 1, 1, 1, 4096>();
    // pto: %o_packed_heads__ssa_v0_pview
    ;
    pto::Stride<4096, 4096, 4096, 4096, 1> v213 = pto::Stride<4096, 4096, 4096, 4096, 1>();
    // pto: %o_packed_heads__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v214 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v209 + (v210 + v208 * v211), v212, v213);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v214, v200);
    // pto: %21
    ;
    int64_t v215 = v207 < v35 ? v35 : v207;
    // pto: %22
    ;
    __gm__ bfloat16_t* v216 = PTOAS__GLOBAL_TENSOR_DATA(v82);
    // pto: %22
    ;
    const int64_t v217 = 0;
    // pto: %22
    ;
    const int64_t v218 = 4096;
    // pto: %22
    ;
    pto::Shape<1, 1, 1, 1, 4096> v219 = pto::Shape<1, 1, 1, 1, 4096>();
    // pto: %22
    ;
    pto::Stride<4096, 4096, 4096, 4096, 1> v220 = pto::Stride<4096, 4096, 4096, 4096, 1>();
    // pto: %22
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v221 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v216 + (v217 + v215 * v218), v219, v220);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v221, v204);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}