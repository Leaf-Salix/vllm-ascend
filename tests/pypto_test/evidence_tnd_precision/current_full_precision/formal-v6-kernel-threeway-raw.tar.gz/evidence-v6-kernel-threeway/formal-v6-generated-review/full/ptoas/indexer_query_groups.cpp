#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_query_groups(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ float* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ int32_t* v7, __gm__ int32_t* v8, __gm__ int32_t* v9, __gm__ int32_t* v10, __gm__ int32_t* v11, __gm__ int32_t* v12, int64_t v13, int64_t v14, int64_t v15) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v16 = 0;
  // pto: %c1_index
  const int64_t v17 = 1;
  // pto: %c512_index
  const int64_t v18 = 512;
  // pto: %c0_index
  const int64_t v19 = 0;
  // pto: %cst_5
  const float v20 = -3.40282347E+38f;
  // pto: %cn1_i32
  const int32_t v21 = -1;
  // pto: %c5_index
  const int64_t v22 = 5;
  // pto: %c6_index
  const int64_t v23 = 6;
  // pto: %c2_index
  const int64_t v24 = 2;
  // pto: %idx_topk_scores__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %idx_topk_scores__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %idx_topk_scores__ssa_v0_view
  const int64_t v27 = 1;
  // pto: %idx_topk_scores__ssa_v0_view
  int64_t v28 = (int64_t) v13;
  // pto: %idx_topk_scores__ssa_v0_view
  int64_t v29 = v28 * v18;
  // pto: %idx_topk_scores__ssa_v0_view
  int64_t v30 = v27 * v29;
  // pto: %idx_topk_scores__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v31 = pto::Shape<1, 1, 1, -1, -1>(v25, v26, v27, v28, v18);
  // pto: %idx_topk_scores__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v32 = pto::Stride<-1, -1, -1, -1, -1>(v26 * v30, v30, v29, v18, v17);
  // pto: %idx_topk_scores__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v33 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v31, v32);
  // pto: %idx_topk__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %idx_topk__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %idx_topk__ssa_v0_view
  const int64_t v36 = 1;
  // pto: %idx_topk__ssa_v0_view
  int64_t v37 = (int64_t) v13;
  // pto: %idx_topk__ssa_v0_view
  int64_t v38 = v37 * v18;
  // pto: %idx_topk__ssa_v0_view
  int64_t v39 = v36 * v38;
  // pto: %idx_topk__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v40 = pto::Shape<1, 1, 1, -1, -1>(v34, v35, v36, v37, v18);
  // pto: %idx_topk__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v41 = pto::Stride<-1, -1, -1, -1, -1>(v35 * v39, v39, v38, v18, v17);
  // pto: %idx_topk__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v42 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v40, v41);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t v43 = v19; v43 < v13; v43 += v17) {
    // pto: %t__tile
    ;
    int32_t v44 = (v2)[v43];
    // pto: %0, %1
    ;
    if ((int64_t) v44 < v19) {
      // pto: %t__tmp_v407
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v45 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
      // pto: %t__tmp_v407
      ;
      uint64_t v46 = (uint64_t) v16;
      TASSIGN(v45, v46);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      TEXPANDS(v45, v20);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %2
      ;
      int64_t v47 = v43 < v19 ? v19 : v43;
      // pto: %idx_topk_scores__ssa_v0_pview
      ;
      __gm__ float* v48 = PTOAS__GLOBAL_TENSOR_DATA(v33);
      // pto: %idx_topk_scores__ssa_v0_pview
      ;
      const int64_t v49 = 0;
      // pto: %idx_topk_scores__ssa_v0_pview
      ;
      const int64_t v50 = 512;
      // pto: %idx_topk_scores__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v51 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %idx_topk_scores__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 512, 1> v52 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %idx_topk_scores__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v53 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v48 + (v49 + v47 * v50), v51, v52);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v53, v45);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      // pto: %t__tmp_v408
      ;
      Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v54 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v18);
      // pto: %t__tmp_v408
      ;
      uint64_t v55 = (uint64_t) v16;
      TASSIGN(v54, v55);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      TEXPANDS(v54, v21);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      // pto: %idx_topk__ssa_v0_pview
      ;
      __gm__ int32_t* v56 = PTOAS__GLOBAL_TENSOR_DATA(v42);
      // pto: %idx_topk__ssa_v0_pview
      ;
      const int64_t v57 = 0;
      // pto: %idx_topk__ssa_v0_pview
      ;
      const int64_t v58 = 512;
      // pto: %idx_topk__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v59 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %idx_topk__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 512, 1> v60 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %idx_topk__ssa_v0_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v61 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v56 + (v57 + v47 * v58), v59, v60);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      TSTORE(v61, v54);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    };
  }
  // pto: %count_inline8558__rv_v2
  int64_t v62;
  v62 = v19;
  for (int64_t v63 = v19; v63 < v14; v63 += v17) {
    // pto: %5
    ;
    int32_t v64 = (v6)[v63];
    // pto: %6
    ;
    int64_t v65 = (int64_t) v64;
    // pto: %8, %7
    ;
    int32_t v66 = (v6)[(int64_t) ((uint64_t) v63 + (uint64_t) v17)];
    // pto: %9
    ;
    int64_t v67 = (int64_t) v66;
    // pto: %10
    ;
    int32_t v68 = (v5)[v63];
    // pto: %11, %12
    ;
    // pto: %groups_here_inline8554__phi_v2
    ;
    int64_t v69;
    if ((int64_t) v68 > v19) {
      // pto: %13, %14, %15
      ;
      v69 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v67 - (uint64_t) v65) + (uint64_t) v22) / v23;
    } else {
      v69 = v19;
    };
    for (int64_t v70 = v19; v70 < v69; v70 += v17) {
      // pto: %17, %16
      ;
      int64_t v71 = (int64_t) ((uint64_t) v65 + (uint64_t) ((int64_t) (uint64_t) v70 * (uint64_t) v23));
      // pto: %18
      ;
      int32_t v72 = (int32_t) v71;
      // pto: %19
      ;
      uint64_t v73 = (uint64_t) v62;
      // pto: %19
      ;
      int64_t v74 = (int64_t) (v73 + (uint64_t) v70);
      (v7)[v74] = v72;
      // pto: %20
      ;
      int64_t v75 = (int64_t) ((uint64_t) v67 - (uint64_t) v71);
      // pto: %21
      ;
      int64_t v76 = v75 < v23 ? v75 : v23;
      // pto: %22
      ;
      int32_t v77 = (int32_t) v76;
      (v8)[v74] = v77;
    };
    // pto: %24
    ;
    uint64_t v78 = (uint64_t) v62;
    // pto: %24
    ;
    uint64_t v79 = (uint64_t) v69;
    // pto: %24
    ;
    v62 = (int64_t) (v78 + v79);
  }
  // pto: %25
  int32_t v80 = (int32_t) v62;
  (v9)[v19] = v80;
  // pto: %count_inline8565__rv_v2
  int64_t v81;
  v81 = v19;
  for (int64_t v82 = v19; v82 < v14; v82 += v17) {
    // pto: %27
    ;
    int32_t v83 = (v6)[v82];
    // pto: %28
    ;
    int64_t v84 = (int64_t) v83;
    // pto: %30, %29
    ;
    int32_t v85 = (v6)[(int64_t) ((uint64_t) v82 + (uint64_t) v17)];
    // pto: %31
    ;
    int64_t v86 = (int64_t) v85;
    // pto: %32
    ;
    int32_t v87 = (v5)[v82];
    // pto: %33, %34
    ;
    // pto: %groups_here_inline8560__phi_v2
    ;
    int64_t v88;
    if ((int64_t) v87 > v19) {
      // pto: %35, %36, %37
      ;
      v88 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v86 - (uint64_t) v84) + (uint64_t) v17) / v24;
    } else {
      v88 = v19;
    };
    for (int64_t v89 = v19; v89 < v88; v89 += v17) {
      // pto: %39, %38
      ;
      int64_t v90 = (int64_t) ((uint64_t) v84 + (uint64_t) ((int64_t) (uint64_t) v89 * (uint64_t) v24));
      // pto: %40
      ;
      int32_t v91 = (int32_t) v90;
      // pto: %41
      ;
      uint64_t v92 = (uint64_t) v81;
      // pto: %41
      ;
      int64_t v93 = (int64_t) (v92 + (uint64_t) v89);
      (v10)[v93] = v91;
      // pto: %42
      ;
      int64_t v94 = (int64_t) ((uint64_t) v86 - (uint64_t) v90);
      // pto: %43
      ;
      int64_t v95 = v94 < v24 ? v94 : v24;
      // pto: %44
      ;
      int32_t v96 = (int32_t) v95;
      (v11)[v93] = v96;
    };
    // pto: %46
    ;
    uint64_t v97 = (uint64_t) v81;
    // pto: %46
    ;
    uint64_t v98 = (uint64_t) v88;
    // pto: %46
    ;
    v81 = (int64_t) (v97 + v98);
  }
  // pto: %47
  int32_t v99 = (int32_t) v81;
  (v12)[v19] = v99;
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  #endif // __DAV_VEC__

  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}