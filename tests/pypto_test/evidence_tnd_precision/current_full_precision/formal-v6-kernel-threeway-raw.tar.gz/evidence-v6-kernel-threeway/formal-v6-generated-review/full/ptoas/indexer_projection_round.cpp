#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_projection_round(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, __gm__ half* v4, int64_t v5, int64_t v6, int64_t v7, int32_t v8, int32_t v9) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v10 = 0;
  // pto: %c4096_i64
  const int64_t v11 = 4096;
  // pto: %c64_index
  const int64_t v12 = 64;
  // pto: %c1_index
  const int64_t v13 = 1;
  // pto: %c16_index
  const int64_t v14 = 16;
  // pto: %c0_index
  const int64_t v15 = 0;
  // pto: %cst_6
  const float v16 = 0.0110485433f;
  // pto: %7
  int64_t v17 = (int64_t) ((uint64_t) v6 * (uint64_t) v14);
  // pto: %accum_inline1306__ssa_v1_view
  const int64_t v18 = 1;
  // pto: %accum_inline1306__ssa_v1_view
  const int64_t v19 = 1;
  // pto: %accum_inline1306__ssa_v1_view
  const int64_t v20 = 1;
  // pto: %accum_inline1306__ssa_v1_view
  int64_t v21 = v17 * v12;
  // pto: %accum_inline1306__ssa_v1_view
  int64_t v22 = v20 * v21;
  // pto: %accum_inline1306__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v23 = pto::Shape<1, 1, 1, -1, -1>(v18, v19, v20, v17, v12);
  // pto: %accum_inline1306__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v24 = pto::Stride<-1, -1, -1, -1, -1>(v19 * v22, v22, v21, v12, v13);
  // pto: %accum_inline1306__ssa_v1_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v25 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v23, v24);
  // pto: %indexer_raw__ssa_v0_view
  const int64_t v26 = 1;
  // pto: %indexer_raw__ssa_v0_view
  const int64_t v27 = 1;
  // pto: %indexer_raw__ssa_v0_view
  const int64_t v28 = 1;
  // pto: %indexer_raw__ssa_v0_view
  int64_t v29 = (int64_t) v7;
  // pto: %indexer_raw__ssa_v0_view
  int64_t v30 = v29 * v12;
  // pto: %indexer_raw__ssa_v0_view
  int64_t v31 = v28 * v30;
  // pto: %indexer_raw__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v32 = pto::Shape<1, 1, 1, -1, -1>(v26, v27, v28, v29, v12);
  // pto: %indexer_raw__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v33 = pto::Stride<-1, -1, -1, -1, -1>(v27 * v31, v31, v30, v12, v13);
  // pto: %indexer_raw__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v34 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v32, v33);
  // pto: %indexer_scaled__ssa_v0_view
  const int64_t v35 = 1;
  // pto: %indexer_scaled__ssa_v0_view
  const int64_t v36 = 1;
  // pto: %indexer_scaled__ssa_v0_view
  const int64_t v37 = 1;
  // pto: %indexer_scaled__ssa_v0_view
  int64_t v38 = (int64_t) v7;
  // pto: %indexer_scaled__ssa_v0_view
  int64_t v39 = v38 * v12;
  // pto: %indexer_scaled__ssa_v0_view
  int64_t v40 = v37 * v39;
  // pto: %indexer_scaled__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v41 = pto::Shape<1, 1, 1, -1, -1>(v35, v36, v37, v38, v12);
  // pto: %indexer_scaled__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v42 = pto::Stride<-1, -1, -1, -1, -1>(v36 * v40, v40, v39, v12, v13);
  // pto: %indexer_scaled__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v43 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v41, v42);
  // pto: %indexer_weights__ssa_v0_view
  const int64_t v44 = 1;
  // pto: %indexer_weights__ssa_v0_view
  const int64_t v45 = 1;
  // pto: %indexer_weights__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %indexer_weights__ssa_v0_view
  int64_t v47 = (int64_t) v7;
  // pto: %indexer_weights__ssa_v0_view
  int64_t v48 = v47 * v12;
  // pto: %indexer_weights__ssa_v0_view
  int64_t v49 = v46 * v48;
  // pto: %indexer_weights__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v50 = pto::Shape<1, 1, 1, -1, -1>(v44, v45, v46, v47, v12);
  // pto: %indexer_weights__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v51 = pto::Stride<-1, -1, -1, -1, -1>(v45 * v49, v49, v48, v12, v13);
  // pto: %indexer_weights__ssa_v0_view
  GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v52 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v50, v51);
  // pto: %block_inline1299__ssa_v0, %0
  int64_t v53 = (int64_t) ((uint64_t) ((int64_t) v8) * (uint64_t) v14);
  // pto: %1
  int64_t v54 = (int64_t) ((uint64_t) v5 - (uint64_t) v53);
  // pto: %2
  int64_t v55 = v54 < v14 ? v54 : v14;
  // pto: %value_inline1305__ssa_v0
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v55, v12);
  // pto: %value_inline1305__ssa_v0
  uint64_t v57 = (uint64_t) v10;
  TASSIGN(v56, v57);
  // pto: %3
  int64_t v58 = v53 < v15 ? v15 : v53;
  // pto: %accum_inline1306__ssa_v1_pview
  const int64_t v59 = 0;
  // pto: %accum_inline1306__ssa_v1_pview
  __gm__ float* v60 = PTOAS__GLOBAL_TENSOR_DATA(v25);
  // pto: %accum_inline1306__ssa_v1_pview
  const int64_t v61 = 1;
  // pto: %accum_inline1306__ssa_v1_pview
  const int64_t v62 = 1;
  // pto: %accum_inline1306__ssa_v1_pview
  const int64_t v63 = 1;
  // pto: %accum_inline1306__ssa_v1_pview
  int64_t v64 = v55 * v12;
  // pto: %accum_inline1306__ssa_v1_pview
  int64_t v65 = v63 * v64;
  // pto: %accum_inline1306__ssa_v1_pview
  pto::Shape<1, 1, 1, -1, 64> v66 = pto::Shape<1, 1, 1, -1, 64>(v61, v62, v63, v55, v12);
  // pto: %accum_inline1306__ssa_v1_pview
  pto::Stride<-1, -1, -1, -1, -1> v67 = pto::Stride<-1, -1, -1, -1, -1>(v62 * v65, v65, v64, v12, v13);
  // pto: %accum_inline1306__ssa_v1_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v68 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v60 + (v59 + v58 * v12 + v15 * v13), v66, v67);
  TLOAD(v56, v68);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %projected_inline1298__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v69 = Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v55, v12);
  // pto: %projected_inline1298__ssa_v0
  uint64_t v70 = (uint64_t) v11;
  TASSIGN(v69, v70);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  RoundMode v71 = RoundMode::CAST_RINT;
  SaturationMode v72 = SaturationMode::ON;
  TCVT(v69, v56, v71, v72);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %indexer_raw__ssa_v0_pview
  const int64_t v73 = 0;
  // pto: %indexer_raw__ssa_v0_pview
  __gm__ bfloat16_t* v74 = PTOAS__GLOBAL_TENSOR_DATA(v34);
  // pto: %indexer_raw__ssa_v0_pview
  const int64_t v75 = 1;
  // pto: %indexer_raw__ssa_v0_pview
  const int64_t v76 = 1;
  // pto: %indexer_raw__ssa_v0_pview
  const int64_t v77 = 1;
  // pto: %indexer_raw__ssa_v0_pview
  int64_t v78 = v55 * v12;
  // pto: %indexer_raw__ssa_v0_pview
  int64_t v79 = v77 * v78;
  // pto: %indexer_raw__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 64> v80 = pto::Shape<1, 1, 1, -1, 64>(v75, v76, v77, v55, v12);
  // pto: %indexer_raw__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v81 = pto::Stride<-1, -1, -1, -1, -1>(v76 * v79, v79, v78, v12, v13);
  // pto: %indexer_raw__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v82 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v74 + (v73 + v58 * v12 + v15 * v13), v80, v81);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v82, v69);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  // pto: %value_v1_inline1297__ssa_v0
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v83 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v55, v12);
  // pto: %value_v1_inline1297__ssa_v0
  uint64_t v84 = (uint64_t) v10;
  TASSIGN(v83, v84);
  pipe_barrier(PIPE_V);
  RoundMode v85 = RoundMode::CAST_ROUND;
  SaturationMode v86 = SaturationMode::ON;
  TCVT(v83, v69, v85, v86);
  // pto: %value_v2_inline1312__ssa_v0
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v87 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v55, v12);
  // pto: %value_v2_inline1312__ssa_v0
  uint64_t v88 = (uint64_t) v10;
  TASSIGN(v87, v88);
  pipe_barrier(PIPE_V);
  TMULS(v87, v83, v16);
  // pto: %weighted_inline1296__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v89 = Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v55, v12);
  // pto: %weighted_inline1296__ssa_v0
  uint64_t v90 = (uint64_t) v11;
  TASSIGN(v89, v90);
  pipe_barrier(PIPE_V);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  RoundMode v91 = RoundMode::CAST_RINT;
  SaturationMode v92 = SaturationMode::ON;
  TCVT(v89, v87, v91, v92);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  // pto: %indexer_scaled__ssa_v0_pview
  const int64_t v93 = 0;
  // pto: %indexer_scaled__ssa_v0_pview
  __gm__ bfloat16_t* v94 = PTOAS__GLOBAL_TENSOR_DATA(v43);
  // pto: %indexer_scaled__ssa_v0_pview
  const int64_t v95 = 1;
  // pto: %indexer_scaled__ssa_v0_pview
  const int64_t v96 = 1;
  // pto: %indexer_scaled__ssa_v0_pview
  const int64_t v97 = 1;
  // pto: %indexer_scaled__ssa_v0_pview
  int64_t v98 = v55 * v12;
  // pto: %indexer_scaled__ssa_v0_pview
  int64_t v99 = v97 * v98;
  // pto: %indexer_scaled__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 64> v100 = pto::Shape<1, 1, 1, -1, 64>(v95, v96, v97, v55, v12);
  // pto: %indexer_scaled__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v101 = pto::Stride<-1, -1, -1, -1, -1>(v96 * v99, v99, v98, v12, v13);
  // pto: %indexer_scaled__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v102 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v94 + (v93 + v58 * v12 + v15 * v13), v100, v101);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  TSTORE(v102, v89);
  // pto: %result_inline1302__cast_fp32_tmp_v0
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v55, v12);
  // pto: %result_inline1302__cast_fp32_tmp_v0
  uint64_t v104 = (uint64_t) v10;
  TASSIGN(v103, v104);
  pipe_barrier(PIPE_V);
  RoundMode v105 = RoundMode::CAST_RINT;
  SaturationMode v106 = SaturationMode::ON;
  TCVT(v103, v89, v105, v106);
  // pto: %result_inline1302__ssa_v0
  Tile<TileType::Vec, half, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v107 = Tile<TileType::Vec, half, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v55, v12);
  // pto: %result_inline1302__ssa_v0
  uint64_t v108 = (uint64_t) v10;
  TASSIGN(v107, v108);
  pipe_barrier(PIPE_V);
  RoundMode v109 = RoundMode::CAST_RINT;
  SaturationMode v110 = SaturationMode::ON;
  TCVT(v107, v103, v109, v110);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
  // pto: %indexer_weights__ssa_v0_pview
  const int64_t v111 = 0;
  // pto: %indexer_weights__ssa_v0_pview
  __gm__ half* v112 = PTOAS__GLOBAL_TENSOR_DATA(v52);
  // pto: %indexer_weights__ssa_v0_pview
  const int64_t v113 = 1;
  // pto: %indexer_weights__ssa_v0_pview
  const int64_t v114 = 1;
  // pto: %indexer_weights__ssa_v0_pview
  const int64_t v115 = 1;
  // pto: %indexer_weights__ssa_v0_pview
  int64_t v116 = v55 * v12;
  // pto: %indexer_weights__ssa_v0_pview
  int64_t v117 = v115 * v116;
  // pto: %indexer_weights__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 64> v118 = pto::Shape<1, 1, 1, -1, 64>(v113, v114, v115, v55, v12);
  // pto: %indexer_weights__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v119 = pto::Stride<-1, -1, -1, -1, -1>(v114 * v117, v117, v116, v12, v13);
  // pto: %indexer_weights__ssa_v0_pview
  GlobalTensor<half, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v120 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v112 + (v111 + v58 * v12 + v15 * v13), v118, v119);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
  TSTORE(v120, v107);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}