#include "pto/pto-inst.hpp"
using namespace pto;

enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void csa_row_offsets(__gm__ int32_t* v1, __gm__ int32_t* v2, __gm__ int32_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ int32_t* v7, __gm__ int32_t* v8, int64_t v9, int64_t v10, int64_t v11) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int32_t v12 = -1;
  // pto: %c1_index
  const int64_t v13 = 1;
  // pto: %c0_index
  const int64_t v14 = 0;
  // pto: %c4_index
  const int64_t v15 = 4;
  // pto: %prefix_inline1325__rv_v2
  int64_t v16;
  v16 = v14;
  for (int64_t v17 = v14; v17 < v9; v17 += v13) {
    // pto: %begin_inline1323__tile
    ;
    int32_t v18 = (v2)[v17];
    // pto: %1, %end_inline1322__tile
    ;
    int32_t v19 = (v2)[(int64_t) ((uint64_t) v17 + (uint64_t) v13)];
    // pto: %length_inline1321__tile
    ;
    int32_t v20 = (v1)[v17];
    // pto: %2, %3, %4, %5
    ;
    int64_t v21 = (int64_t) ((int32_t) (uint32_t) ((int32_t) (uint32_t) v20 + (uint32_t) v18) - (uint32_t) v19) / v15;
    // pto: %6
    ;
    uint64_t v22 = (uint64_t) v16;
    // pto: %6, %7, %8
    ;
    int32_t v23 = (int32_t) ((int64_t) (uint64_t) ((int64_t) v22 - (uint64_t) v21) - (uint64_t) v13);
    (v3)[v17] = v23;
    // pto: %11
    ;
    uint64_t v24 = (uint64_t) v16;
    // pto: %9, %10, %11, %14
    ;
    v16 = (int64_t) ((uint64_t) ((int64_t) v24 + (uint64_t) ((int64_t) v20 / v15)) - (uint64_t) v21);
  }
  // pto: %prefix_inline1331__rv_v2
  int64_t v25;
  v25 = v14;
  for (int64_t v26 = v14; v26 < v9; v26 += v13) {
    // pto: %begin_inline1329__tile
    ;
    int32_t v27 = (v5)[v26];
    // pto: %16, %end_inline1328__tile
    ;
    int32_t v28 = (v5)[(int64_t) ((uint64_t) v26 + (uint64_t) v13)];
    // pto: %length_inline1327__tile
    ;
    int32_t v29 = (v4)[v26];
    // pto: %17, %18, %19, %20
    ;
    int64_t v30 = (int64_t) ((int32_t) (uint32_t) ((int32_t) (uint32_t) v29 + (uint32_t) v27) - (uint32_t) v28) / v15;
    // pto: %21
    ;
    uint64_t v31 = (uint64_t) v25;
    // pto: %21, %22, %23
    ;
    int32_t v32 = (int32_t) ((int64_t) (uint64_t) ((int64_t) v31 - (uint64_t) v30) - (uint64_t) v13);
    (v6)[v26] = v32;
    // pto: %26
    ;
    uint64_t v33 = (uint64_t) v25;
    // pto: %24, %25, %26, %29
    ;
    v25 = (int64_t) ((uint64_t) ((int64_t) v33 + (uint64_t) ((int64_t) v29 / v15)) - (uint64_t) v30);
  }
  for (int64_t v34 = v14; v34 < v11; v34 += v13) {
    (v7)[v34] = v12;
  }
  for (int64_t v35 = v14; v35 < v9; v35 += v13) {
    // pto: %t__tile
    ;
    int32_t v36 = (v8)[v35];
    // pto: %31
    ;
    // pto: %33, %32
    ;
    int32_t v37 = (v8)[(int64_t) ((uint64_t) v35 + (uint64_t) v13)];
    // pto: %34
    ;
    // pto: %35
    ;
    int32_t v38 = (v4)[v35];
    // pto: %36, %37
    ;
    if ((int64_t) v38 > v14) {
      for (int64_t v39 = (int64_t) v36; v39 < ((int64_t) v37); v39 += v13) {
        // pto: %38
        ;
        int32_t v40 = (int32_t) v35;
        (v7)[v39] = v40;
      };
    };
  }
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  #endif // __DAV_VEC__

  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}