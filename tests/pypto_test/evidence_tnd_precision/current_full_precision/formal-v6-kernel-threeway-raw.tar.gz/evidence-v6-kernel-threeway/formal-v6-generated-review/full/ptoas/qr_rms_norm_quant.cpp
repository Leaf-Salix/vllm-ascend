#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qr_rms_norm_quant(__gm__ int8_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ int8_t* v4, __gm__ float* v5, __gm__ bfloat16_t* v6, int64_t v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int64_t v12, int32_t v13, int32_t v14) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c17504_i64
  const int64_t v15 = 17504;
  // pto: %c50272_i64
  const int64_t v16 = 50272;
  const int64_t v17 = 19552;
  const int64_t v18 = 18528;
  const int64_t v19 = 18016;
  const int64_t v20 = 17760;
  // pto: %c1088_i64
  const int64_t v21 = 1088;
  // pto: %c9280_i64
  const int64_t v22 = 9280;
  // pto: %c0_i64
  const int64_t v23 = 0;
  // pto: %c32_i64
  const int64_t v24 = 32;
  // pto: %c64_i64
  const int64_t v25 = 64;
  // pto: %c576_i64
  const int64_t v26 = 576;
  // pto: %c17472_i64
  const int64_t v27 = 17472;
  // pto: %c512_index
  const int64_t v28 = 512;
  // pto: %c1024_index
  const int64_t v29 = 1024;
  // pto: %c1_index
  const int64_t v30 = 1;
  // pto: %c8_index
  const int64_t v31 = 8;
  // pto: %c0_index
  const int64_t v32 = 0;
  // pto: %c256_index
  const int64_t v33 = 256;
  // pto: %c128_index
  const int64_t v34 = 128;
  // pto: %c64_index
  const int64_t v35 = 64;
  // pto: %cst_21
  const float v36 = 9.765625E-4f;
  // pto: %cst_22
  const float v37 = 9.99999997E-7f;
  // pto: %c0_i32
  const int32_t v38 = 0;
  // pto: %c8388608_index
  const int64_t v39 = 8388608;
  // pto: %c2139095040_i64
  const int64_t v40 = 2139095040;
  // pto: %c8388608_i64
  const int64_t v41 = 8388608;
  // pto: %c2_index
  const int64_t v42 = 2;
  // pto: %c2_i64
  const int64_t v43 = 2;
  // pto: %c152_i64
  const int64_t v44 = 152;
  // pto: %c1_i64
  const int64_t v45 = 1;
  // pto: %cst_31
  const float v46 = 0.0f;
  // pto: %cst_32
  const float v47 = 1.0f;
  // pto: %cst_33
  const float v48 = 9.99999974E-5f;
  // pto: %cst_34
  const float v49 = 127.0f;
  // pto: %qr_i8_matmul_inline5149__iter_v1_view
  const int64_t v50 = 1;
  // pto: %qr_i8_matmul_inline5149__iter_v1_view
  const int64_t v51 = 1;
  // pto: %qr_i8_matmul_inline5149__iter_v1_view
  const int64_t v52 = 1;
  // pto: %qr_i8_matmul_inline5149__iter_v1_view
  int64_t v53 = v28 * v29;
  // pto: %qr_i8_matmul_inline5149__iter_v1_view
  int64_t v54 = v52 * v53;
  // pto: %qr_i8_matmul_inline5149__iter_v1_view
  pto::Shape<1, 1, 1, -1, -1> v55 = pto::Shape<1, 1, 1, -1, -1>(v50, v51, v52, v28, v29);
  // pto: %qr_i8_matmul_inline5149__iter_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v56 = pto::Stride<-1, -1, -1, -1, -1>(v51 * v54, v54, v53, v29, v30);
  // pto: %qr_i8_matmul_inline5149__iter_v1_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v57 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v55, v56);
  // pto: %qr_scale_pad_store_inline5159__iter_v1_view
  const int64_t v58 = 1;
  // pto: %qr_scale_pad_store_inline5159__iter_v1_view
  const int64_t v59 = 1;
  // pto: %qr_scale_pad_store_inline5159__iter_v1_view
  const int64_t v60 = 1;
  // pto: %qr_scale_pad_store_inline5159__iter_v1_view
  int64_t v61 = v28 * v30;
  // pto: %qr_scale_pad_store_inline5159__iter_v1_view
  int64_t v62 = v60 * v61;
  // pto: %qr_scale_pad_store_inline5159__iter_v1_view
  pto::Shape<1, 1, 1, -1, -1> v63 = pto::Shape<1, 1, 1, -1, -1>(v58, v59, v60, v28, v30);
  // pto: %qr_scale_pad_store_inline5159__iter_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v59 * v62, v62, v61, v30, v28);
  // pto: %qr_scale_pad_store_inline5159__iter_v1_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v65 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v2, v63, v64);
  // pto: %qr_scale_view_inline8385__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %qr_scale_view_inline8385__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %qr_scale_view_inline8385__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %qr_scale_view_inline8385__ssa_v0_view
  int64_t v69 = (int64_t) v11;
  // pto: %qr_scale_view_inline8385__ssa_v0_view
  int64_t v70 = v69 * v30;
  // pto: %qr_scale_view_inline8385__ssa_v0_view
  int64_t v71 = v68 * v70;
  // pto: %qr_scale_view_inline8385__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v72 = pto::Shape<1, 1, 1, -1, -1>(v66, v67, v68, v69, v30);
  // pto: %qr_scale_view_inline8385__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v73 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v71, v71, v70, v30, (int64_t) v11);
  // pto: %qr_scale_view_inline8385__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v74 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v3, v72, v73);
  // pto: %qr_view_inline8377__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %qr_view_inline8377__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %qr_view_inline8377__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %qr_view_inline8377__ssa_v0_view
  int64_t v78 = (int64_t) v11;
  // pto: %qr_view_inline8377__ssa_v0_view
  int64_t v79 = v78 * v29;
  // pto: %qr_view_inline8377__ssa_v0_view
  int64_t v80 = v77 * v79;
  // pto: %qr_view_inline8377__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v81 = pto::Shape<1, 1, 1, -1, -1>(v75, v76, v77, v78, v29);
  // pto: %qr_view_inline8377__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v82 = pto::Stride<-1, -1, -1, -1, -1>(v76 * v80, v80, v79, v29, v30);
  // pto: %qr_view_inline8377__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v83 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v81, v82);
  // pto: %qr_fp32_inline174_inline5151__rv_v10_view
  const int64_t v84 = 1;
  // pto: %qr_fp32_inline174_inline5151__rv_v10_view
  const int64_t v85 = 1;
  // pto: %qr_fp32_inline174_inline5151__rv_v10_view
  const int64_t v86 = 1;
  // pto: %qr_fp32_inline174_inline5151__rv_v10_view
  int64_t v87 = (int64_t) v12;
  // pto: %qr_fp32_inline174_inline5151__rv_v10_view
  int64_t v88 = v87 * v29;
  // pto: %qr_fp32_inline174_inline5151__rv_v10_view
  int64_t v89 = v86 * v88;
  // pto: %qr_fp32_inline174_inline5151__rv_v10_view
  pto::Shape<1, 1, 1, -1, -1> v90 = pto::Shape<1, 1, 1, -1, -1>(v84, v85, v86, v87, v29);
  // pto: %qr_fp32_inline174_inline5151__rv_v10_view
  pto::Stride<-1, -1, -1, -1, -1> v91 = pto::Stride<-1, -1, -1, -1, -1>(v85 * v89, v89, v88, v29, v30);
  // pto: %qr_fp32_inline174_inline5151__rv_v10_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v92 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v90, v91);
  // pto: %gamma_cq__ssa_v0_view
  const int64_t v93 = 1;
  // pto: %gamma_cq__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %gamma_cq__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %gamma_cq__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %gamma_cq__ssa_v0_view
  int64_t v97 = v29 * v30;
  // pto: %gamma_cq__ssa_v0_view
  int64_t v98 = v96 * v97;
  // pto: %gamma_cq__ssa_v0_view
  int64_t v99 = v95 * v98;
  // pto: %gamma_cq__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v100 = pto::Shape<1, 1, 1, 1, -1>(v93, v94, v95, v96, v29);
  // pto: %gamma_cq__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v101 = pto::Stride<-1, -1, -1, -1, -1>(v94 * v99, v99, v98, v97, v30);
  // pto: %gamma_cq__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v102 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v100, v101);
  // pto: %tg_idx_worker_inline8381__ssa_v0
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  for (int64_t v103 = (int64_t) v13; v103 < v7; v103 += v8) {
    // pto: %49
    ;
    int64_t v104 = (int64_t) ((uint64_t) v103 * (uint64_t) v31);
    // pto: %50
    ;
    int64_t v105 = (int64_t) ((uint64_t) v9 - (uint64_t) v104);
    // pto: %51
    ;
    int64_t v106 = v105 < v31 ? v105 : v31;
    // pto: %52
    ;
    int64_t v107 = (int64_t) ((uint64_t) v10 + (uint64_t) v104);
    // pto: %t__tile
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v29);
    // pto: %t__tile
    ;
    uint64_t v109 = (uint64_t) v15;
    TASSIGN(v108, v109);
    // pto: %53
    ;
    int64_t v110 = v104 < v32 ? v32 : v104;
    // pto: %qr_fp32_inline174_inline5151__rv_v10_pview
    ;
    __gm__ float* v111 = PTOAS__GLOBAL_TENSOR_DATA(v92);
    // pto: %qr_fp32_inline174_inline5151__rv_v10_pview
    ;
    const int64_t v112 = 0;
    // pto: %qr_fp32_inline174_inline5151__rv_v10_pview
    ;
    const int64_t v113 = 1024;
    // pto: %qr_fp32_inline174_inline5151__rv_v10_pview
    ;
    pto::Shape<1, 1, 1, 8, 1024> v114 = pto::Shape<1, 1, 1, 8, 1024>();
    // pto: %qr_fp32_inline174_inline5151__rv_v10_pview
    ;
    pto::Stride<8192, 8192, 8192, 1024, 1> v115 = pto::Stride<8192, 8192, 8192, 1024, 1>();
    // pto: %qr_fp32_inline174_inline5151__rv_v10_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1024>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v116 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1024>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v111 + (v112 + v110 * v113), v114, v115);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v108, v116);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v29);
    // pto: %0
    ;
    uint64_t v118 = (uint64_t) v16;
    TASSIGN(v117, v118);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    RoundMode v119 = RoundMode::CAST_RINT;
    SaturationMode v120 = SaturationMode::ON;
    TCVT(v117, v108, v119, v120);
    // pto: %qr_rms_full_inline202_inline8376__tile
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v29);
    // pto: %qr_rms_full_inline202_inline8376__tile
    ;
    uint64_t v122 = (uint64_t) v15;
    TASSIGN(v121, v122);
    pipe_barrier(PIPE_V);
    RoundMode v123 = RoundMode::CAST_ROUND;
    SaturationMode v124 = SaturationMode::ON;
    TCVT(v121, v117, v123, v124);
    // pto: %qr_square_full_inline203_inline8411__tile
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v29);
    // pto: %qr_square_full_inline203_inline8411__tile
    ;
    uint64_t v126 = (uint64_t) v15;
    TASSIGN(v125, v126);
    pipe_barrier(PIPE_V);
    TMUL(v125, v121, v121);
    // pto: %1
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v28);
    // pto: %1
    ;
    uint64_t v128 = (uint64_t) v15;
    TASSIGN(v127, v128);
    // pto: %slice_view
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, 8, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v129;
    // pto: %slice_view
    ;
    uint64_t v130 = (uint64_t) v15;
    TASSIGN(v129, v130);
    // pto: %2
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v28);
    // pto: %2
    ;
    uint64_t v132 = (uint64_t) v17;
    TASSIGN(v131, v132);
    // pto: %54
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, 8, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v133;
    // pto: %54
    ;
    uint64_t v134 = (uint64_t) v17;
    TASSIGN(v133, v134);
    // pto: %qr_square_half_inline201_inline8390__tile
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v28);
    // pto: %qr_square_half_inline201_inline8390__tile
    ;
    uint64_t v136 = (uint64_t) v15;
    TASSIGN(v135, v136);
    pipe_barrier(PIPE_V);
    TADD(v135, v129, v133);
    // pto: %3
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
    // pto: %3
    ;
    uint64_t v138 = (uint64_t) v15;
    TASSIGN(v137, v138);
    // pto: %55
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v139;
    // pto: %55
    ;
    uint64_t v140 = (uint64_t) v15;
    TASSIGN(v139, v140);
    // pto: %4
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
    // pto: %4
    ;
    uint64_t v142 = (uint64_t) v18;
    TASSIGN(v141, v142);
    // pto: %56
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v143;
    // pto: %56
    ;
    uint64_t v144 = (uint64_t) v18;
    TASSIGN(v143, v144);
    // pto: %qr_square_quarter_inline197_inline8372__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
    // pto: %qr_square_quarter_inline197_inline8372__tile
    ;
    uint64_t v146 = (uint64_t) v15;
    TASSIGN(v145, v146);
    pipe_barrier(PIPE_V);
    TADD(v145, v139, v143);
    // pto: %5
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v34);
    // pto: %5
    ;
    uint64_t v148 = (uint64_t) v15;
    TASSIGN(v147, v148);
    // pto: %57
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, 8, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v149;
    // pto: %57
    ;
    uint64_t v150 = (uint64_t) v15;
    TASSIGN(v149, v150);
    // pto: %6
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v151 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v34);
    // pto: %6
    ;
    uint64_t v152 = (uint64_t) v19;
    TASSIGN(v151, v152);
    // pto: %58
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, 8, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v153;
    // pto: %58
    ;
    uint64_t v154 = (uint64_t) v19;
    TASSIGN(v153, v154);
    // pto: %qr_square_eighth_inline204_inline8380__tile
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v34);
    // pto: %qr_square_eighth_inline204_inline8380__tile
    ;
    uint64_t v156 = (uint64_t) v15;
    TASSIGN(v155, v156);
    pipe_barrier(PIPE_V);
    TADD(v155, v149, v153);
    // pto: %7
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v35);
    // pto: %7
    ;
    uint64_t v158 = (uint64_t) v15;
    TASSIGN(v157, v158);
    // pto: %59
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v159;
    // pto: %59
    ;
    uint64_t v160 = (uint64_t) v15;
    TASSIGN(v159, v160);
    // pto: %8
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v35);
    // pto: %8
    ;
    uint64_t v162 = (uint64_t) v20;
    TASSIGN(v161, v162);
    // pto: %60
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v163;
    // pto: %60
    ;
    uint64_t v164 = (uint64_t) v20;
    TASSIGN(v163, v164);
    // pto: %qr_square_sixteenth_inline196_inline8370__tile
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v35);
    // pto: %qr_square_sixteenth_inline196_inline8370__tile
    ;
    uint64_t v166 = (uint64_t) v16;
    TASSIGN(v165, v166);
    pipe_barrier(PIPE_V);
    TADD(v165, v159, v163);
    // pto: %tmp_tile
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v34);
    // pto: %tmp_tile
    ;
    uint64_t v168 = (uint64_t) v15;
    TASSIGN(v167, v168);
    // pto: %9
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v30);
    // pto: %9
    ;
    uint64_t v170 = (uint64_t) v21;
    TASSIGN(v169, v170);
    pipe_barrier(PIPE_V);
    TROWSUM(v169, v165, v167);
    // pto: %qr_sq_sum_inline205_inline8367__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v171 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_sq_sum_inline205_inline8367__tile
    ;
    uint64_t v172 = (uint64_t) v21;
    TASSIGN(v171, v172);
    // pto: %10
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v173 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %10
    ;
    uint64_t v174 = (uint64_t) v15;
    TASSIGN(v173, v174);
    pipe_barrier(PIPE_V);
    TMULS(v173, v171, v36);
    // pto: %qr_variance_inline191_inline8369__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_variance_inline191_inline8369__tile
    ;
    uint64_t v176 = (uint64_t) v15;
    TASSIGN(v175, v176);
    pipe_barrier(PIPE_V);
    TADDS(v175, v173, v37);
    // pto: %qr_rms_approx_inline189_inline8379__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_rms_approx_inline189_inline8379__tile
    ;
    uint64_t v178 = (uint64_t) v16;
    TASSIGN(v177, v178);
    pipe_barrier(PIPE_V);
    TSQRT(v177, v175);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %qr_variance_bits_inline195_inline8364__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_variance_bits_inline195_inline8364__tile
    ;
    uint64_t v180 = (uint64_t) v15;
    TASSIGN(v179, v180);
    // pto: %qr_approx_bits_inline190_inline8374__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_approx_bits_inline190_inline8374__tile
    ;
    uint64_t v182 = (uint64_t) v16;
    TASSIGN(v181, v182);
    // pto: %qr_rounded_bits_inline199_inline8363__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_rounded_bits_inline199_inline8363__tile
    ;
    uint64_t v184 = (uint64_t) v22;
    TASSIGN(v183, v184);
    TEXPANDS(v183, v38);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    for (int64_t v185 = v32; v185 < v31; v185 += v30) {
      // pto: %61
      ;
      int32_t v186 = v179.GetValue(v185);
      // pto: %62
      ;
      int64_t v187 = (int64_t) v186;
      // pto: %63
      ;
      int32_t v188 = v181.GetValue(v185);
      // pto: %66
      ;
      // pto: %68, %69, %70
      ;
      if ((int64_t) v186 >= v39 & v187 < v40) {
        // pto: %71
        ;
        int64_t v189 = v187 / v41;
        // pto: %72, %73
        ;
        int64_t v190 = (int64_t) ((uint64_t) (v187 % v41) + (uint64_t) v41);
        // pto: %qr_y_bits_inline193_inline8361__rv_v2
        ;
        int64_t v191;
        v191 = (int64_t) v188;
        for (int64_t v192 = v32; v192 < v42; v192 += v30) {
          // pto: %74
          ;
          int64_t v193 = v191 / v41;
          // pto: %75
          ;
          int64_t v194 = v191 % v41;
          // pto: %76, %77, %79
          ;
          int64_t v195 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v194 + (uint64_t) v41) * (uint64_t) v43) + (uint64_t) v30);
          // pto: %80
          ;
          int64_t v196 = (int64_t) ((uint64_t) v195 * (uint64_t) v195);
          // pto: %84, %82, %81, %83
          ;
          int64_t v197 = (int64_t) ((uint64_t) v190 << (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v189 - (uint64_t) ((int64_t) (uint64_t) v193 * (uint64_t) v43)) + (uint64_t) v44));
          // pto: %85
          ;
          uint64_t v198 = (uint64_t) v191;
          // pto: %85
          ;
          int64_t v199 = (int64_t) (v198 - (uint64_t) v45);
          // pto: %87, %88, %89, %91
          ;
          int64_t v200 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) (v199 % v41) + (uint64_t) v41) * (uint64_t) v43) + (uint64_t) v30);
          // pto: %92
          ;
          int64_t v201 = (int64_t) ((uint64_t) v200 * (uint64_t) v200);
          // pto: %96, %94, %86, %93, %95
          ;
          int64_t v202 = (int64_t) ((uint64_t) v190 << (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v189 - (uint64_t) ((int64_t) (uint64_t) (v199 / v41) * (uint64_t) v43)) + (uint64_t) v44));
          // pto: %101
          ;
          int64_t v203 = v191 % v43;
          // pto: %102
          ;
          bool v204 = v203 == v45;
          // pto: %98, %100, %103, %104
          ;
          // pto: %qr_y_bits_inline193_inline8361__phi_v6
          ;
          int64_t v205;
          if (v196 < v197 | v197 == v196 & v204) {
            // pto: %105
            ;
            uint64_t v206 = (uint64_t) v191;
            // pto: %105
            ;
            v205 = (int64_t) (v206 + (uint64_t) v45);
          } else {
            // pto: %107, %109, %112, %113, %qr_y_bits_inline193_inline8361__phi_v5
            ;
            int64_t v207 = v202 < v201 | v202 == v201 & v204 ? v199 : v191;
            v205 = v207;
          };
          v191 = v205;
        };
        // pto: %115
        ;
        int32_t v208 = (int32_t) v191;
        v183.SetValue(v185, v208);
      } else {
        v183.SetValue(v185, v188);
      };
    };
    set_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
    // pto: %qr_rms_inline200_inline8392__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_rms_inline200_inline8392__tile
    ;
    uint64_t v210 = (uint64_t) v22;
    TASSIGN(v209, v210);
    // pto: %qr_inv_rms_inline194_inline8410__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_inv_rms_inline194_inline8410__tile
    ;
    uint64_t v212 = (uint64_t) v23;
    TASSIGN(v211, v212);
    TEXPANDS(v211, v46);
    set_flag(PIPE_V, PIPE_S, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
    for (int64_t v213 = v32; v213 < v31; v213 += v30) {
      // pto: %qr_rms_value_inline186_inline8365__tile
      ;
      float v214 = v209.GetValue(v213);
      // pto: %123
      ;
      float v215 = v47 / v214;
      v211.SetValue(v213, v215);
    };
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    // pto: %_qr_sq_sum_inline8399__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %_qr_sq_sum_inline8399__ssa_v0
    ;
    uint64_t v217 = (uint64_t) v21;
    TASSIGN(v216, v217);
    // pto: %qr_inv_rms_inline8397__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_inv_rms_inline8397__ssa_v0
    ;
    uint64_t v219 = (uint64_t) v23;
    TASSIGN(v218, v219);
    // pto: %_qr_rms_inline8414__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %_qr_rms_inline8414__ssa_v0
    ;
    uint64_t v221 = (uint64_t) v22;
    TASSIGN(v220, v221);
    // pto: %qr_inv_rms_t_inline8407__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v30);
    // pto: %qr_inv_rms_t_inline8407__tile
    ;
    uint64_t v223 = (uint64_t) v23;
    TASSIGN(v222, v223);
    // pto: %qr_tile_amax_inline8403__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_tile_amax_inline8403__tile
    ;
    uint64_t v225 = (uint64_t) v24;
    TASSIGN(v224, v225);
    TEXPANDS(v224, v48);
    wait_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    for (int64_t v226 = v32; v226 < v29; v226 += v28) {
      // pto: %11
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %11
      ;
      uint64_t v228 = (uint64_t) v15;
      TASSIGN(v227, v228);
      // pto: %127
      ;
      int64_t v229 = v226 < v32 ? v32 : v226;
      // pto: %128
      ;
      __gm__ float* v230 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %128
      ;
      const int64_t v231 = 0;
      // pto: %128
      ;
      const int64_t v232 = 1024;
      // pto: %128
      ;
      pto::Shape<1, 1, 1, 8, 256> v233 = pto::Shape<1, 1, 1, 8, 256>();
      // pto: %128
      ;
      pto::Stride<8192, 8192, 8192, 1024, 1> v234 = pto::Stride<8192, 8192, 8192, 1024, 1>();
      // pto: %128
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v235 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v230 + (v231 + v110 * v232 + v229), v233, v234);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      TLOAD(v227, v235);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %12
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %12
      ;
      uint64_t v237 = (uint64_t) v25;
      TASSIGN(v236, v237);
      // pto: %gamma_cq__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v238 = PTOAS__GLOBAL_TENSOR_DATA(v102);
      // pto: %gamma_cq__ssa_v0_pview
      ;
      const int64_t v239 = 0;
      // pto: %gamma_cq__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 256> v240 = pto::Shape<1, 1, 1, 1, 256>();
      // pto: %gamma_cq__ssa_v0_pview
      ;
      pto::Stride<256, 256, 256, 256, 1> v241 = pto::Stride<256, 256, 256, 256, 1>();
      // pto: %gamma_cq__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v242 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v238 + (v239 + v229), v240, v241);
      TLOAD(v236, v242);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %13
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %13
      ;
      uint64_t v244 = (uint64_t) v16;
      TASSIGN(v243, v244);
      // pto: %131
      ;
      int64_t v245 = (int64_t) ((uint64_t) v226 + (uint64_t) v33);
      // pto: %132
      ;
      int64_t v246 = v245 < v32 ? v32 : v245;
      // pto: %133
      ;
      __gm__ float* v247 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %133
      ;
      const int64_t v248 = 0;
      // pto: %133
      ;
      const int64_t v249 = 1024;
      // pto: %133
      ;
      pto::Shape<1, 1, 1, 8, 256> v250 = pto::Shape<1, 1, 1, 8, 256>();
      // pto: %133
      ;
      pto::Stride<8192, 8192, 8192, 1024, 1> v251 = pto::Stride<8192, 8192, 8192, 1024, 1>();
      // pto: %133
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v252 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v247 + (v248 + v110 * v249 + v246), v250, v251);
      TLOAD(v243, v252);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %14
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v253 = Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %14
      ;
      uint64_t v254 = (uint64_t) v26;
      TASSIGN(v253, v254);
      // pto: %136
      ;
      __gm__ bfloat16_t* v255 = PTOAS__GLOBAL_TENSOR_DATA(v102);
      // pto: %136
      ;
      const int64_t v256 = 0;
      // pto: %136
      ;
      pto::Shape<1, 1, 1, 1, 256> v257 = pto::Shape<1, 1, 1, 1, 256>();
      // pto: %136
      ;
      pto::Stride<256, 256, 256, 256, 1> v258 = pto::Stride<256, 256, 256, 256, 1>();
      // pto: %136
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v259 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v255 + (v256 + v246), v257, v258);
      TLOAD(v253, v259);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      // pto: %15
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v260 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %15
      ;
      uint64_t v261 = (uint64_t) v21;
      TASSIGN(v260, v261);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      RoundMode v262 = RoundMode::CAST_RINT;
      SaturationMode v263 = SaturationMode::ON;
      TCVT(v260, v227, v262, v263);
      // pto: %qr_max_chunk_inline8419__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v264 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_max_chunk_inline8419__tile
      ;
      uint64_t v265 = (uint64_t) v15;
      TASSIGN(v264, v265);
      pipe_barrier(PIPE_V);
      RoundMode v266 = RoundMode::CAST_ROUND;
      SaturationMode v267 = SaturationMode::ON;
      TCVT(v264, v260, v266, v267);
      // pto: %gamma_max_cast_inline8417__tile
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v268 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %gamma_max_cast_inline8417__tile
      ;
      uint64_t v269 = (uint64_t) v21;
      TASSIGN(v268, v269);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      RoundMode v270 = RoundMode::CAST_ROUND;
      SaturationMode v271 = SaturationMode::ON;
      TCVT(v268, v236, v270, v271);
      // pto: %gamma_max_chunk_inline8418__tile
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v272 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %gamma_max_chunk_inline8418__tile
      ;
      uint64_t v273 = (uint64_t) v21;
      TASSIGN(v272, v273);
      // pto: %16
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v274 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %16
      ;
      uint64_t v275 = (uint64_t) v15;
      TASSIGN(v274, v275);
      TROWEXPANDMUL(v274, v264, v222);
      // pto: %qr_normalized_inline8378__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v276 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_normalized_inline8378__tile
      ;
      uint64_t v277 = (uint64_t) v15;
      TASSIGN(v276, v277);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v276, v274, v272);
      // pto: %17
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v278 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %17
      ;
      uint64_t v279 = (uint64_t) v15;
      TASSIGN(v278, v279);
      pipe_barrier(PIPE_V);
      TABS(v278, v276);
      // pto: %18
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v280 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %18
      ;
      uint64_t v281 = (uint64_t) v21;
      TASSIGN(v280, v281);
      // pto: %19
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v282 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v30);
      // pto: %19
      ;
      uint64_t v283 = (uint64_t) v25;
      TASSIGN(v282, v283);
      pipe_barrier(PIPE_V);
      TROWMAX(v282, v278, v280);
      // pto: %qr_normalized_max_inline8387__tile
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v284 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
      // pto: %qr_normalized_max_inline8387__tile
      ;
      uint64_t v285 = (uint64_t) v25;
      TASSIGN(v284, v285);
      // pto: %20
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
      // pto: %20
      ;
      uint64_t v287 = (uint64_t) v15;
      TASSIGN(v286, v287);
      pipe_barrier(PIPE_V);
      TMAX(v286, v224, v284);
      // pto: %21
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v288 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %21
      ;
      uint64_t v289 = (uint64_t) v22;
      TASSIGN(v288, v289);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      RoundMode v290 = RoundMode::CAST_RINT;
      SaturationMode v291 = SaturationMode::ON;
      TCVT(v288, v243, v290, v291);
      // pto: %22
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v292 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %22
      ;
      uint64_t v293 = (uint64_t) v16;
      TASSIGN(v292, v293);
      pipe_barrier(PIPE_V);
      RoundMode v294 = RoundMode::CAST_ROUND;
      SaturationMode v295 = SaturationMode::ON;
      TCVT(v292, v288, v294, v295);
      // pto: %23
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %23
      ;
      uint64_t v297 = (uint64_t) v22;
      TASSIGN(v296, v297);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      RoundMode v298 = RoundMode::CAST_ROUND;
      SaturationMode v299 = SaturationMode::ON;
      TCVT(v296, v253, v298, v299);
      // pto: %24
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v300 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %24
      ;
      uint64_t v301 = (uint64_t) v22;
      TASSIGN(v300, v301);
      // pto: %25
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v302 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %25
      ;
      uint64_t v303 = (uint64_t) v16;
      TASSIGN(v302, v303);
      TROWEXPANDMUL(v302, v292, v222);
      // pto: %26
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v304 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %26
      ;
      uint64_t v305 = (uint64_t) v16;
      TASSIGN(v304, v305);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v304, v302, v300);
      // pto: %27
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %27
      ;
      uint64_t v307 = (uint64_t) v16;
      TASSIGN(v306, v307);
      pipe_barrier(PIPE_V);
      TABS(v306, v304);
      // pto: %28
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v308 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %28
      ;
      uint64_t v309 = (uint64_t) v22;
      TASSIGN(v308, v309);
      // pto: %29
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v310 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v30);
      // pto: %29
      ;
      uint64_t v311 = (uint64_t) v26;
      TASSIGN(v310, v311);
      pipe_barrier(PIPE_V);
      TROWMAX(v310, v306, v308);
      // pto: %30
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
      // pto: %30
      ;
      uint64_t v313 = (uint64_t) v26;
      TASSIGN(v312, v313);
      // pto: %31
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v314 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
      // pto: %31
      ;
      uint64_t v315 = (uint64_t) v24;
      TASSIGN(v314, v315);
      pipe_barrier(PIPE_V);
      TMAX(v314, v286, v312);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    };
    // pto: %qr_scale_quant_row_inline8408__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v316 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_scale_quant_row_inline8408__tile
    ;
    uint64_t v317 = (uint64_t) v27;
    TASSIGN(v316, v317);
    TEXPANDS(v316, v46);
    // pto: %qr_scale_dq_row_inline8412__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v318 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_scale_dq_row_inline8412__tile
    ;
    uint64_t v319 = (uint64_t) v15;
    TASSIGN(v318, v319);
    pipe_barrier(PIPE_V);
    TEXPANDS(v318, v46);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_V, PIPE_S, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID2);
    for (int64_t v320 = v32; v320 < v31; v320 += v30) {
      // pto: %qr_amax_value_inline8416__tile
      ;
      float v321 = v224.GetValue(v320);
      // pto: %139
      ;
      float v322 = v49 / v321;
      v316.SetValue(v320, v322);
      // pto: %142
      ;
      float v323 = v47 / v322;
      v318.SetValue(v320, v323);
    };
    set_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
    // pto: %qr_scale_quant_t_inline8355__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v324 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v30);
    // pto: %qr_scale_quant_t_inline8355__tile
    ;
    uint64_t v325 = (uint64_t) v27;
    TASSIGN(v324, v325);
    // pto: %qr_tile_scale_dq_inline8353__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v326 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v30);
    // pto: %qr_tile_scale_dq_inline8353__tile
    ;
    uint64_t v327 = (uint64_t) v15;
    TASSIGN(v326, v327);
    // pto: %qr_scale_pad_store_inline5159__iter_v3_pview
    ;
    __gm__ float* v328 = PTOAS__GLOBAL_TENSOR_DATA(v65);
    // pto: %qr_scale_pad_store_inline5159__iter_v3_pview
    ;
    const int64_t v329 = 0;
    // pto: %qr_scale_pad_store_inline5159__iter_v3_pview
    ;
    pto::Shape<1, 1, 1, 8, 1> v330 = pto::Shape<1, 1, 1, 8, 1>();
    // pto: %qr_scale_pad_store_inline5159__iter_v3_pview
    ;
    pto::Stride<8, 8, 8, 1, 512> v331 = pto::Stride<8, 8, 8, 1, 512>();
    // pto: %qr_scale_pad_store_inline5159__iter_v3_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN> v332 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN>(v328 + (v329 + v110), v330, v331);
    wait_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v332, v326);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    // pto: %146
    ;
    bool v333 = v106 == v31;
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    if (v333) {
      // pto: %147
      ;
      int64_t v334 = v107 < v32 ? v32 : v107;
      // pto: %qr_scale_view_inline8385__iter_v1_pview
      ;
      int64_t v335 = (int64_t) v11;
      // pto: %qr_scale_view_inline8385__iter_v1_pview
      ;
      const int64_t v336 = 0;
      // pto: %qr_scale_view_inline8385__iter_v1_pview
      ;
      __gm__ float* v337 = PTOAS__GLOBAL_TENSOR_DATA(v74);
      // pto: %qr_scale_view_inline8385__iter_v1_pview
      ;
      const int64_t v338 = 1;
      // pto: %qr_scale_view_inline8385__iter_v1_pview
      ;
      const int64_t v339 = 1;
      // pto: %qr_scale_view_inline8385__iter_v1_pview
      ;
      const int64_t v340 = 1;
      // pto: %qr_scale_view_inline8385__iter_v1_pview
      ;
      int64_t v341 = v31 * v30;
      // pto: %qr_scale_view_inline8385__iter_v1_pview
      ;
      int64_t v342 = v340 * v341;
      // pto: %qr_scale_view_inline8385__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, 8, 1> v343 = pto::Shape<1, 1, 1, 8, 1>(v338, v339, v340, v31, v30);
      // pto: %qr_scale_view_inline8385__iter_v1_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v344 = pto::Stride<-1, -1, -1, -1, -1>(v339 * v342, v342, v341, v30, v335);
      // pto: %qr_scale_view_inline8385__iter_v1_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v345 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v337 + (v336 + v334 * v30 + v32 * v335), v343, v344);
      TSTORE(v345, v326);
    } else {
      // pto: %qr_scale_tail_inline8396__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v346 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v106, v30);
      // pto: %qr_scale_tail_inline8396__ssa_v0
      ;
      uint64_t v347 = (uint64_t) v15;
      TASSIGN(v346, v347);
      // pto: %qr_scale_pad_store_inline5159__tile_pview
      ;
      const int64_t v348 = 0;
      // pto: %qr_scale_pad_store_inline5159__tile_pview
      ;
      __gm__ float* v349 = PTOAS__GLOBAL_TENSOR_DATA(v65);
      // pto: %qr_scale_pad_store_inline5159__tile_pview
      ;
      const int64_t v350 = 1;
      // pto: %qr_scale_pad_store_inline5159__tile_pview
      ;
      const int64_t v351 = 1;
      // pto: %qr_scale_pad_store_inline5159__tile_pview
      ;
      const int64_t v352 = 1;
      // pto: %qr_scale_pad_store_inline5159__tile_pview
      ;
      int64_t v353 = v106 * v30;
      // pto: %qr_scale_pad_store_inline5159__tile_pview
      ;
      int64_t v354 = v352 * v353;
      // pto: %qr_scale_pad_store_inline5159__tile_pview
      ;
      pto::Shape<1, 1, 1, -1, 1> v355 = pto::Shape<1, 1, 1, -1, 1>(v350, v351, v352, v106, v30);
      // pto: %qr_scale_pad_store_inline5159__tile_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v356 = pto::Stride<-1, -1, -1, -1, -1>(v351 * v354, v354, v353, v30, v28);
      // pto: %qr_scale_pad_store_inline5159__tile_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v357 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v349 + (v348 + v110 * v30 + v32 * v28), v355, v356);
      TLOAD(v346, v357);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
      // pto: %149
      ;
      int64_t v358 = v107 < v32 ? v32 : v107;
      // pto: %150
      ;
      int64_t v359 = (int64_t) v11;
      // pto: %150
      ;
      const int64_t v360 = 0;
      // pto: %150
      ;
      __gm__ float* v361 = PTOAS__GLOBAL_TENSOR_DATA(v74);
      // pto: %150
      ;
      const int64_t v362 = 1;
      // pto: %150
      ;
      const int64_t v363 = 1;
      // pto: %150
      ;
      const int64_t v364 = 1;
      // pto: %150
      ;
      int64_t v365 = v106 * v30;
      // pto: %150
      ;
      int64_t v366 = v364 * v365;
      // pto: %150
      ;
      pto::Shape<1, 1, 1, -1, 1> v367 = pto::Shape<1, 1, 1, -1, 1>(v362, v363, v364, v106, v30);
      // pto: %150
      ;
      pto::Stride<-1, -1, -1, -1, -1> v368 = pto::Stride<-1, -1, -1, -1, -1>(v363 * v366, v366, v365, v30, v359);
      // pto: %150
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v369 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v361 + (v360 + v358 * v30 + v32 * v359), v367, v368);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
      TSTORE(v369, v346);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    for (int64_t v370 = v32; v370 < v29; v370 += v28) {
      // pto: %32
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v371 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %32
      ;
      uint64_t v372 = (uint64_t) v15;
      TASSIGN(v371, v372);
      // pto: %152
      ;
      int64_t v373 = v370 < v32 ? v32 : v370;
      // pto: %153
      ;
      __gm__ float* v374 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %153
      ;
      const int64_t v375 = 0;
      // pto: %153
      ;
      const int64_t v376 = 1024;
      // pto: %153
      ;
      pto::Shape<1, 1, 1, 8, 256> v377 = pto::Shape<1, 1, 1, 8, 256>();
      // pto: %153
      ;
      pto::Stride<8192, 8192, 8192, 1024, 1> v378 = pto::Stride<8192, 8192, 8192, 1024, 1>();
      // pto: %153
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v379 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v374 + (v375 + v110 * v376 + v373), v377, v378);
      TLOAD(v371, v379);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      // pto: %33
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v380 = Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %33
      ;
      uint64_t v381 = (uint64_t) v25;
      TASSIGN(v380, v381);
      // pto: %155
      ;
      __gm__ bfloat16_t* v382 = PTOAS__GLOBAL_TENSOR_DATA(v102);
      // pto: %155
      ;
      const int64_t v383 = 0;
      // pto: %155
      ;
      pto::Shape<1, 1, 1, 1, 256> v384 = pto::Shape<1, 1, 1, 1, 256>();
      // pto: %155
      ;
      pto::Stride<256, 256, 256, 256, 1> v385 = pto::Stride<256, 256, 256, 256, 1>();
      // pto: %155
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v386 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v382 + (v383 + v373), v384, v385);
      TLOAD(v380, v386);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      // pto: %34
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v387 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %34
      ;
      uint64_t v388 = (uint64_t) v16;
      TASSIGN(v387, v388);
      // pto: %157
      ;
      int64_t v389 = (int64_t) ((uint64_t) v370 + (uint64_t) v33);
      // pto: %158
      ;
      int64_t v390 = v389 < v32 ? v32 : v389;
      // pto: %159
      ;
      __gm__ float* v391 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %159
      ;
      const int64_t v392 = 0;
      // pto: %159
      ;
      const int64_t v393 = 1024;
      // pto: %159
      ;
      pto::Shape<1, 1, 1, 8, 256> v394 = pto::Shape<1, 1, 1, 8, 256>();
      // pto: %159
      ;
      pto::Stride<8192, 8192, 8192, 1024, 1> v395 = pto::Stride<8192, 8192, 8192, 1024, 1>();
      // pto: %159
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v396 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v391 + (v392 + v110 * v393 + v390), v394, v395);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      TLOAD(v387, v396);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      // pto: %35
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v397 = Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %35
      ;
      uint64_t v398 = (uint64_t) v26;
      TASSIGN(v397, v398);
      // pto: %162
      ;
      __gm__ bfloat16_t* v399 = PTOAS__GLOBAL_TENSOR_DATA(v102);
      // pto: %162
      ;
      const int64_t v400 = 0;
      // pto: %162
      ;
      pto::Shape<1, 1, 1, 1, 256> v401 = pto::Shape<1, 1, 1, 1, 256>();
      // pto: %162
      ;
      pto::Stride<256, 256, 256, 256, 1> v402 = pto::Stride<256, 256, 256, 256, 1>();
      // pto: %162
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v403 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v399 + (v400 + v390), v401, v402);
      TLOAD(v397, v403);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %36
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v404 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %36
      ;
      uint64_t v405 = (uint64_t) v21;
      TASSIGN(v404, v405);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      RoundMode v406 = RoundMode::CAST_RINT;
      SaturationMode v407 = SaturationMode::ON;
      TCVT(v404, v371, v406, v407);
      // pto: %qr_chunk_inline8401__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v408 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_chunk_inline8401__tile
      ;
      uint64_t v409 = (uint64_t) v15;
      TASSIGN(v408, v409);
      pipe_barrier(PIPE_V);
      RoundMode v410 = RoundMode::CAST_ROUND;
      SaturationMode v411 = SaturationMode::ON;
      TCVT(v408, v404, v410, v411);
      // pto: %gamma_q_cast_inline8375__tile
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v412 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %gamma_q_cast_inline8375__tile
      ;
      uint64_t v413 = (uint64_t) v21;
      TASSIGN(v412, v413);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      RoundMode v414 = RoundMode::CAST_ROUND;
      SaturationMode v415 = SaturationMode::ON;
      TCVT(v412, v380, v414, v415);
      // pto: %gamma_q_chunk_inline8356__tile
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v416 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %gamma_q_chunk_inline8356__tile
      ;
      uint64_t v417 = (uint64_t) v21;
      TASSIGN(v416, v417);
      // pto: %37
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v418 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %37
      ;
      uint64_t v419 = (uint64_t) v15;
      TASSIGN(v418, v419);
      TROWEXPANDMUL(v418, v408, v222);
      // pto: %qr_q_normed_inline8366__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v420 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_q_normed_inline8366__tile
      ;
      uint64_t v421 = (uint64_t) v15;
      TASSIGN(v420, v421);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v420, v418, v416);
      // pto: %qr_q_scaled_inline8351__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v422 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_q_scaled_inline8351__tile
      ;
      uint64_t v423 = (uint64_t) v15;
      TASSIGN(v422, v423);
      pipe_barrier(PIPE_V);
      TROWEXPANDMUL(v422, v420, v324);
      // pto: %qr_q_i32_inline8354__tile
      ;
      Tile<TileType::Vec, int32_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v424 = Tile<TileType::Vec, int32_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_q_i32_inline8354__tile
      ;
      uint64_t v425 = (uint64_t) v15;
      TASSIGN(v424, v425);
      pipe_barrier(PIPE_V);
      RoundMode v426 = RoundMode::CAST_RINT;
      SaturationMode v427 = SaturationMode::ON;
      TCVT(v424, v422, v426, v427);
      // pto: %qr_q_half_inline8368__tile
      ;
      Tile<TileType::Vec, half, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v428 = Tile<TileType::Vec, half, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_q_half_inline8368__tile
      ;
      uint64_t v429 = (uint64_t) v15;
      TASSIGN(v428, v429);
      pipe_barrier(PIPE_V);
      RoundMode v430 = RoundMode::CAST_ROUND;
      SaturationMode v431 = SaturationMode::ON;
      TCVT(v428, v424, v430, v431);
      // pto: %qr_q_i8_inline8350__tile
      ;
      Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v432 = Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_q_i8_inline8350__tile
      ;
      uint64_t v433 = (uint64_t) v15;
      TASSIGN(v432, v433);
      pipe_barrier(PIPE_V);
      RoundMode v434 = RoundMode::CAST_TRUNC;
      SaturationMode v435 = SaturationMode::ON;
      TCVT(v432, v428, v434, v435);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      // pto: %qr_i8_matmul_inline5149__iter_v5_pview
      ;
      __gm__ int8_t* v436 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %qr_i8_matmul_inline5149__iter_v5_pview
      ;
      const int64_t v437 = 0;
      // pto: %qr_i8_matmul_inline5149__iter_v5_pview
      ;
      const int64_t v438 = 1024;
      // pto: %qr_i8_matmul_inline5149__iter_v5_pview
      ;
      pto::Shape<1, 1, 1, 8, 256> v439 = pto::Shape<1, 1, 1, 8, 256>();
      // pto: %qr_i8_matmul_inline5149__iter_v5_pview
      ;
      pto::Stride<8192, 8192, 8192, 1024, 1> v440 = pto::Stride<8192, 8192, 8192, 1024, 1>();
      // pto: %qr_i8_matmul_inline5149__iter_v5_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v441 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v436 + (v437 + v110 * v438 + v373), v439, v440);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v441, v432);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      if (v333) {
        // pto: %166
        ;
        int64_t v442 = v107 < v32 ? v32 : v107;
        // pto: %qr_view_inline8377__iter_v3_pview
        ;
        __gm__ int8_t* v443 = PTOAS__GLOBAL_TENSOR_DATA(v83);
        // pto: %qr_view_inline8377__iter_v3_pview
        ;
        const int64_t v444 = 0;
        // pto: %qr_view_inline8377__iter_v3_pview
        ;
        const int64_t v445 = 1024;
        // pto: %qr_view_inline8377__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 8, 256> v446 = pto::Shape<1, 1, 1, 8, 256>();
        // pto: %qr_view_inline8377__iter_v3_pview
        ;
        pto::Stride<8192, 8192, 8192, 1024, 1> v447 = pto::Stride<8192, 8192, 8192, 1024, 1>();
        // pto: %qr_view_inline8377__iter_v3_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v448 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v443 + (v444 + v442 * v445 + v373), v446, v447);
        TSTORE(v448, v432);
      } else {
        // pto: %qr_q_tail_inline8349__ssa_v0
        ;
        Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v449 = Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v106, v33);
        // pto: %qr_q_tail_inline8349__ssa_v0
        ;
        uint64_t v450 = (uint64_t) v15;
        TASSIGN(v449, v450);
        // pto: %qr_i8_matmul_inline5149__tile_pview
        ;
        const int64_t v451 = 0;
        // pto: %qr_i8_matmul_inline5149__tile_pview
        ;
        __gm__ int8_t* v452 = PTOAS__GLOBAL_TENSOR_DATA(v57);
        // pto: %qr_i8_matmul_inline5149__tile_pview
        ;
        const int64_t v453 = 1;
        // pto: %qr_i8_matmul_inline5149__tile_pview
        ;
        const int64_t v454 = 1;
        // pto: %qr_i8_matmul_inline5149__tile_pview
        ;
        const int64_t v455 = 1;
        // pto: %qr_i8_matmul_inline5149__tile_pview
        ;
        int64_t v456 = v106 * v29;
        // pto: %qr_i8_matmul_inline5149__tile_pview
        ;
        int64_t v457 = v455 * v456;
        // pto: %qr_i8_matmul_inline5149__tile_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v458 = pto::Shape<1, 1, 1, -1, 256>(v453, v454, v455, v106, v33);
        // pto: %qr_i8_matmul_inline5149__tile_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v459 = pto::Stride<-1, -1, -1, -1, -1>(v454 * v457, v457, v456, v29, v30);
        // pto: %qr_i8_matmul_inline5149__tile_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v460 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v452 + (v451 + v110 * v29 + v373 * v30), v458, v459);
        TLOAD(v449, v460);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
        // pto: %170
        ;
        int64_t v461 = v107 < v32 ? v32 : v107;
        // pto: %172
        ;
        const int64_t v462 = 0;
        // pto: %172
        ;
        __gm__ int8_t* v463 = PTOAS__GLOBAL_TENSOR_DATA(v83);
        // pto: %172
        ;
        const int64_t v464 = 1;
        // pto: %172
        ;
        const int64_t v465 = 1;
        // pto: %172
        ;
        const int64_t v466 = 1;
        // pto: %172
        ;
        int64_t v467 = v106 * v29;
        // pto: %172
        ;
        int64_t v468 = v466 * v467;
        // pto: %172
        ;
        pto::Shape<1, 1, 1, -1, 256> v469 = pto::Shape<1, 1, 1, -1, 256>(v464, v465, v466, v106, v33);
        // pto: %172
        ;
        pto::Stride<-1, -1, -1, -1, -1> v470 = pto::Stride<-1, -1, -1, -1, -1>(v465 * v468, v468, v467, v29, v30);
        // pto: %172
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v471 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v463 + (v462 + v461 * v29 + v373 * v30), v469, v470);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
        TSTORE(v471, v449);
      };
      // pto: %38
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %38
      ;
      uint64_t v473 = (uint64_t) v22;
      TASSIGN(v472, v473);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      RoundMode v474 = RoundMode::CAST_RINT;
      SaturationMode v475 = SaturationMode::ON;
      TCVT(v472, v387, v474, v475);
      // pto: %39
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v476 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %39
      ;
      uint64_t v477 = (uint64_t) v16;
      TASSIGN(v476, v477);
      pipe_barrier(PIPE_V);
      RoundMode v478 = RoundMode::CAST_ROUND;
      SaturationMode v479 = SaturationMode::ON;
      TCVT(v476, v472, v478, v479);
      // pto: %40
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v480 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %40
      ;
      uint64_t v481 = (uint64_t) v22;
      TASSIGN(v480, v481);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      RoundMode v482 = RoundMode::CAST_ROUND;
      SaturationMode v483 = SaturationMode::ON;
      TCVT(v480, v397, v482, v483);
      // pto: %41
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v484 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %41
      ;
      uint64_t v485 = (uint64_t) v22;
      TASSIGN(v484, v485);
      // pto: %42
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v486 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %42
      ;
      uint64_t v487 = (uint64_t) v16;
      TASSIGN(v486, v487);
      TROWEXPANDMUL(v486, v476, v222);
      // pto: %43
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v488 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %43
      ;
      uint64_t v489 = (uint64_t) v16;
      TASSIGN(v488, v489);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v488, v486, v484);
      // pto: %44
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v490 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %44
      ;
      uint64_t v491 = (uint64_t) v16;
      TASSIGN(v490, v491);
      pipe_barrier(PIPE_V);
      TROWEXPANDMUL(v490, v488, v324);
      // pto: %45
      ;
      Tile<TileType::Vec, int32_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v492 = Tile<TileType::Vec, int32_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %45
      ;
      uint64_t v493 = (uint64_t) v16;
      TASSIGN(v492, v493);
      pipe_barrier(PIPE_V);
      RoundMode v494 = RoundMode::CAST_RINT;
      SaturationMode v495 = SaturationMode::ON;
      TCVT(v492, v490, v494, v495);
      // pto: %46
      ;
      Tile<TileType::Vec, half, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v496 = Tile<TileType::Vec, half, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %46
      ;
      uint64_t v497 = (uint64_t) v16;
      TASSIGN(v496, v497);
      pipe_barrier(PIPE_V);
      RoundMode v498 = RoundMode::CAST_ROUND;
      SaturationMode v499 = SaturationMode::ON;
      TCVT(v496, v492, v498, v499);
      // pto: %47
      ;
      Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v500 = Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %47
      ;
      uint64_t v501 = (uint64_t) v16;
      TASSIGN(v500, v501);
      pipe_barrier(PIPE_V);
      RoundMode v502 = RoundMode::CAST_TRUNC;
      SaturationMode v503 = SaturationMode::ON;
      TCVT(v500, v496, v502, v503);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      // pto: %177
      ;
      __gm__ int8_t* v504 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %177
      ;
      const int64_t v505 = 0;
      // pto: %177
      ;
      const int64_t v506 = 1024;
      // pto: %177
      ;
      pto::Shape<1, 1, 1, 8, 256> v507 = pto::Shape<1, 1, 1, 8, 256>();
      // pto: %177
      ;
      pto::Stride<8192, 8192, 8192, 1024, 1> v508 = pto::Stride<8192, 8192, 8192, 1024, 1>();
      // pto: %177
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v509 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v504 + (v505 + v110 * v506 + v390), v507, v508);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v509, v500);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      if (v333) {
        // pto: %180
        ;
        int64_t v510 = v107 < v32 ? v32 : v107;
        // pto: %qr_view_inline8377__phi_v6_pview
        ;
        __gm__ int8_t* v511 = PTOAS__GLOBAL_TENSOR_DATA(v83);
        // pto: %qr_view_inline8377__phi_v6_pview
        ;
        const int64_t v512 = 0;
        // pto: %qr_view_inline8377__phi_v6_pview
        ;
        const int64_t v513 = 1024;
        // pto: %qr_view_inline8377__phi_v6_pview
        ;
        pto::Shape<1, 1, 1, 8, 256> v514 = pto::Shape<1, 1, 1, 8, 256>();
        // pto: %qr_view_inline8377__phi_v6_pview
        ;
        pto::Stride<8192, 8192, 8192, 1024, 1> v515 = pto::Stride<8192, 8192, 8192, 1024, 1>();
        // pto: %qr_view_inline8377__phi_v6_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v516 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v511 + (v512 + v510 * v513 + v390), v514, v515);
        TSTORE(v516, v500);
      } else {
        // pto: %48
        ;
        Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v517 = Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v106, v33);
        // pto: %48
        ;
        uint64_t v518 = (uint64_t) v16;
        TASSIGN(v517, v518);
        // pto: %186
        ;
        const int64_t v519 = 0;
        // pto: %186
        ;
        __gm__ int8_t* v520 = PTOAS__GLOBAL_TENSOR_DATA(v57);
        // pto: %186
        ;
        const int64_t v521 = 1;
        // pto: %186
        ;
        const int64_t v522 = 1;
        // pto: %186
        ;
        const int64_t v523 = 1;
        // pto: %186
        ;
        int64_t v524 = v106 * v29;
        // pto: %186
        ;
        int64_t v525 = v523 * v524;
        // pto: %186
        ;
        pto::Shape<1, 1, 1, -1, 256> v526 = pto::Shape<1, 1, 1, -1, 256>(v521, v522, v523, v106, v33);
        // pto: %186
        ;
        pto::Stride<-1, -1, -1, -1, -1> v527 = pto::Stride<-1, -1, -1, -1, -1>(v522 * v525, v525, v524, v29, v30);
        // pto: %186
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v528 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v520 + (v519 + v110 * v29 + v390 * v30), v526, v527);
        TLOAD(v517, v528);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
        // pto: %187
        ;
        int64_t v529 = v107 < v32 ? v32 : v107;
        // pto: %190
        ;
        const int64_t v530 = 0;
        // pto: %190
        ;
        __gm__ int8_t* v531 = PTOAS__GLOBAL_TENSOR_DATA(v83);
        // pto: %190
        ;
        const int64_t v532 = 1;
        // pto: %190
        ;
        const int64_t v533 = 1;
        // pto: %190
        ;
        const int64_t v534 = 1;
        // pto: %190
        ;
        int64_t v535 = v106 * v29;
        // pto: %190
        ;
        int64_t v536 = v534 * v535;
        // pto: %190
        ;
        pto::Shape<1, 1, 1, -1, 256> v537 = pto::Shape<1, 1, 1, -1, 256>(v532, v533, v534, v106, v33);
        // pto: %190
        ;
        pto::Stride<-1, -1, -1, -1, -1> v538 = pto::Stride<-1, -1, -1, -1, -1>(v533 * v536, v536, v535, v29, v30);
        // pto: %190
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v539 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v531 + (v530 + v529 * v29 + v390 * v30), v537, v538);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
        TSTORE(v539, v517);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}