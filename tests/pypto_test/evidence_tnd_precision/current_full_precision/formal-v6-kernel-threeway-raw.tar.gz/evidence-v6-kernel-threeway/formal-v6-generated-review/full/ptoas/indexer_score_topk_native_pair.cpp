#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_score_topk_native_pair_aic(__gm__ int32_t* v1, __gm__ int32_t* v2, __gm__ int64_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ int64_t* v7, __gm__ int8_t* v8, __gm__ half* v9, __gm__ int32_t* v10, __gm__ int8_t* v11, __gm__ int8_t* v12, __gm__ float* v13, __gm__ int8_t* v14, __gm__ float* v15, int64_t v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int64_t v22, int64_t v23, int32_t v24, int32_t v25) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v26 = 992;
  const int64_t v27 = 928;
  const int64_t v28 = 864;
  const int64_t v29 = 800;
  const int64_t v30 = 736;
  const int64_t v31 = 672;
  const int64_t v32 = 608;
  const int64_t v33 = 544;
  const int64_t v34 = 480;
  const int64_t v35 = 416;
  const int64_t v36 = 352;
  const int64_t v37 = 224;
  const int64_t v38 = 160;
  const int64_t v39 = 52224;
  const int64_t v40 = 96;
  const int64_t v41 = 51200;
  const int64_t v42 = 50176;
  // pto: %c0_i64
  const int64_t v43 = 0;
  // pto: %c65536_i64
  const int64_t v44 = 65536;
  // pto: %c49152_i64
  const int64_t v45 = 49152;
  // pto: %c16384_i64
  const int64_t v46 = 16384;
  // pto: %c8192_i64
  const int64_t v47 = 8192;
  // pto: %c98304_i64
  const int64_t v48 = 98304;
  // pto: %c1_index
  const int64_t v49 = 1;
  // pto: %c27648_index
  const int64_t v50 = 27648;
  const int64_t v51 = 128;
  // pto: %c1152_index
  const int64_t v52 = 1152;
  const int64_t v53 = 384;
  const int64_t v54 = 288;
  // pto: %c1024_index
  const int64_t v55 = 1024;
  const int64_t v56 = 0;
  // pto: %c4_index
  const int64_t v57 = 4;
  // pto: %c262144_index
  const int64_t v58 = 262144;
  // pto: %c1023_index
  const int64_t v59 = 1023;
  // pto: %c8191_index
  const int64_t v60 = 8191;
  // pto: %c8192_index
  const int64_t v61 = 8192;
  // pto: %c3_index
  const int64_t v62 = 3;
  // pto: %c48_index
  const int64_t v63 = 48;
  // pto: %c24_index
  const int64_t v64 = 24;
  // pto: %c6_index
  const int64_t v65 = 6;
  const int64_t v66 = 32;
  // pto: %c8_index
  const int64_t v67 = 8;
  // pto: %c1_i64
  const int64_t v68 = 1;
  // pto: %c4_i64
  const int64_t v69 = 4;
  const int64_t v70 = 512;
  // pto: %c4096_index
  const int64_t v71 = 4096;
  // pto: %c511_index
  const int64_t v72 = 511;
  const int64_t v73 = 64;
  // pto: %c16_index
  const int64_t v74 = 16;
  // pto: %c2_index
  const int64_t v75 = 2;
  // pto: %c12_index
  const int64_t v76 = 12;
  // pto: %c981467136_i64
  const int64_t v77 = 981467136;
  const int64_t v78 = 192;
  const int64_t v79 = 256;
  const int64_t v80 = 320;
  const int64_t v81 = 448;
  const int64_t v82 = 576;
  const int64_t v83 = 640;
  const int64_t v84 = 704;
  const int64_t v85 = 768;
  const int64_t v86 = 832;
  const int64_t v87 = 896;
  // pto: %c960_index
  const int64_t v88 = 960;
  // pto: %qr_hadamard_i8_inline1363__rv_v2_view
  const int64_t v89 = 1;
  // pto: %qr_hadamard_i8_inline1363__rv_v2_view
  const int64_t v90 = 1;
  // pto: %qr_hadamard_i8_inline1363__rv_v2_view
  const int64_t v91 = 1;
  // pto: %qr_hadamard_i8_inline1363__rv_v2_view
  int64_t v92 = v50 * v51;
  // pto: %qr_hadamard_i8_inline1363__rv_v2_view
  int64_t v93 = v91 * v92;
  // pto: %qr_hadamard_i8_inline1363__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v94 = pto::Shape<1, 1, 1, -1, -1>(v89, v90, v91, v50, v51);
  // pto: %qr_hadamard_i8_inline1363__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v95 = pto::Stride<-1, -1, -1, -1, -1>(v90 * v93, v93, v92, v51, v49);
  // pto: %qr_hadamard_i8_inline1363__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v96 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v94, v95);
  // pto: %coefficients_inline8650__ssa_v0_view
  const int64_t v97 = 1;
  // pto: %coefficients_inline8650__ssa_v0_view
  const int64_t v98 = 1;
  // pto: %coefficients_inline8650__ssa_v0_view
  const int64_t v99 = 1;
  // pto: %coefficients_inline8650__ssa_v0_view
  int64_t v100 = v52 * v53;
  // pto: %coefficients_inline8650__ssa_v0_view
  int64_t v101 = v99 * v100;
  // pto: %coefficients_inline8650__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v102 = pto::Shape<1, 1, 1, -1, -1>(v97, v98, v99, v52, v53);
  // pto: %coefficients_inline8650__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v103 = pto::Stride<-1, -1, -1, -1, -1>(v98 * v101, v101, v100, v53, v49);
  // pto: %coefficients_inline8650__ssa_v0_view
  GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v104 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v102, v103);
  // pto: %idx_kv_cache_inline8669__ssa_v0_view
  const int64_t v105 = 1;
  // pto: %idx_kv_cache_inline8669__ssa_v0_view
  const int64_t v106 = 1;
  // pto: %idx_kv_cache_inline8669__ssa_v0_view
  const int64_t v107 = 1;
  // pto: %idx_kv_cache_inline8669__ssa_v0_view
  int64_t v108 = (int64_t) v20;
  // pto: %idx_kv_cache_inline8669__ssa_v0_view
  int64_t v109 = v108 * v51;
  // pto: %idx_kv_cache_inline8669__ssa_v0_view
  int64_t v110 = v107 * v109;
  // pto: %idx_kv_cache_inline8669__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v111 = pto::Shape<1, 1, 1, -1, -1>(v105, v106, v107, v108, v51);
  // pto: %idx_kv_cache_inline8669__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v112 = pto::Stride<-1, -1, -1, -1, -1>(v106 * v110, v110, v109, v51, v49);
  // pto: %idx_kv_cache_inline8669__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v113 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v11, v111, v112);
  // pto: %idx_kv_cache_shift64_inline8652__ssa_v0_view
  const int64_t v114 = 1;
  // pto: %idx_kv_cache_shift64_inline8652__ssa_v0_view
  const int64_t v115 = 1;
  // pto: %idx_kv_cache_shift64_inline8652__ssa_v0_view
  const int64_t v116 = 1;
  // pto: %idx_kv_cache_shift64_inline8652__ssa_v0_view
  int64_t v117 = (int64_t) v21;
  // pto: %idx_kv_cache_shift64_inline8652__ssa_v0_view
  int64_t v118 = v117 * v51;
  // pto: %idx_kv_cache_shift64_inline8652__ssa_v0_view
  int64_t v119 = v116 * v118;
  // pto: %idx_kv_cache_shift64_inline8652__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v120 = pto::Shape<1, 1, 1, -1, -1>(v114, v115, v116, v117, v51);
  // pto: %idx_kv_cache_shift64_inline8652__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v121 = pto::Stride<-1, -1, -1, -1, -1>(v115 * v119, v119, v118, v51, v49);
  // pto: %idx_kv_cache_shift64_inline8652__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v122 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v12, v120, v121);
  // pto: %buf_score_transfer_inline8684__ssa_v0_view
  const int64_t v123 = 1;
  // pto: %buf_score_transfer_inline8684__ssa_v0_view
  const int64_t v124 = 1;
  // pto: %buf_score_transfer_inline8684__ssa_v0_view
  const int64_t v125 = 1;
  // pto: %buf_score_transfer_inline8684__ssa_v0_view
  int64_t v126 = v54 * v55;
  // pto: %buf_score_transfer_inline8684__ssa_v0_view
  int64_t v127 = v125 * v126;
  // pto: %buf_score_transfer_inline8684__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v128 = pto::Shape<1, 1, 1, -1, -1>(v123, v124, v125, v54, v55);
  // pto: %buf_score_transfer_inline8684__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v129 = pto::Stride<-1, -1, -1, -1, -1>(v124 * v127, v127, v126, v55, v49);
  // pto: %buf_score_transfer_inline8684__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v130 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v128, v129);
  // pto: %buf_key_l1_pool_inline8703__phi_v3
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v3
  uint64_t v132 = (uint64_t) v45;
  TASSIGN(v131, v132);
  // pto: %buf_key_l1_pool_inline8703__phi_v6
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v6
  uint64_t v134 = (uint64_t) v45;
  TASSIGN(v133, v134);
  // pto: %buf_key_l1_pool_inline8703__phi_v12
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v12
  uint64_t v136 = (uint64_t) v45;
  TASSIGN(v135, v136);
  // pto: %buf_key_l1_pool_inline8703__phi_v17
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v17
  uint64_t v138 = (uint64_t) v45;
  TASSIGN(v137, v138);
  // pto: %buf_key_l1_pool_inline8703__phi_v23
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v139 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v23
  uint64_t v140 = (uint64_t) v45;
  TASSIGN(v139, v140);
  // pto: %buf_key_l1_pool_inline8703__phi_v28
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v28
  uint64_t v142 = (uint64_t) v45;
  TASSIGN(v141, v142);
  // pto: %buf_key_l1_pool_inline8703__phi_v34
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v143 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v34
  uint64_t v144 = (uint64_t) v45;
  TASSIGN(v143, v144);
  // pto: %buf_key_l1_pool_inline8703__phi_v39
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v39
  uint64_t v146 = (uint64_t) v45;
  TASSIGN(v145, v146);
  // pto: %buf_key_l1_pool_inline8703__phi_v45
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v45
  uint64_t v148 = (uint64_t) v45;
  TASSIGN(v147, v148);
  // pto: %buf_key_l1_pool_inline8703__phi_v50
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v149 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v50
  uint64_t v150 = (uint64_t) v45;
  TASSIGN(v149, v150);
  // pto: %buf_key_l1_pool_inline8703__phi_v56
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v151 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v56
  uint64_t v152 = (uint64_t) v45;
  TASSIGN(v151, v152);
  // pto: %buf_key_l1_pool_inline8703__phi_v61
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v61
  uint64_t v154 = (uint64_t) v45;
  TASSIGN(v153, v154);
  // pto: %buf_key_l1_pool_inline8703__phi_v67
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v67
  uint64_t v156 = (uint64_t) v45;
  TASSIGN(v155, v156);
  // pto: %buf_key_l1_pool_inline8703__phi_v72
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v72
  uint64_t v158 = (uint64_t) v45;
  TASSIGN(v157, v158);
  // pto: %buf_key_l1_pool_inline8703__phi_v78
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v159 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v78
  uint64_t v160 = (uint64_t) v45;
  TASSIGN(v159, v160);
  // pto: %buf_key_l1_pool_inline8703__phi_v83
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v83
  uint64_t v162 = (uint64_t) v45;
  TASSIGN(v161, v162);
  // pto: %buf_key_l1_pool_inline8703__phi_v89
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v163 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v89
  uint64_t v164 = (uint64_t) v45;
  TASSIGN(v163, v164);
  // pto: %buf_key_l1_pool_inline8703__phi_v94
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v94
  uint64_t v166 = (uint64_t) v45;
  TASSIGN(v165, v166);
  // pto: %buf_key_l1_pool_inline8703__phi_v100
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v100
  uint64_t v168 = (uint64_t) v45;
  TASSIGN(v167, v168);
  // pto: %buf_key_l1_pool_inline8703__phi_v105
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v105
  uint64_t v170 = (uint64_t) v45;
  TASSIGN(v169, v170);
  // pto: %buf_key_l1_pool_inline8703__phi_v111
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v171 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v111
  uint64_t v172 = (uint64_t) v45;
  TASSIGN(v171, v172);
  // pto: %buf_key_l1_pool_inline8703__phi_v116
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v173 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v116
  uint64_t v174 = (uint64_t) v45;
  TASSIGN(v173, v174);
  // pto: %buf_key_l1_pool_inline8703__phi_v122
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v122
  uint64_t v176 = (uint64_t) v45;
  TASSIGN(v175, v176);
  // pto: %buf_key_l1_pool_inline8703__phi_v127
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v127
  uint64_t v178 = (uint64_t) v45;
  TASSIGN(v177, v178);
  // pto: %buf_key_l1_pool_inline8703__phi_v133
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v133
  uint64_t v180 = (uint64_t) v45;
  TASSIGN(v179, v180);
  // pto: %buf_key_l1_pool_inline8703__phi_v138
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v138
  uint64_t v182 = (uint64_t) v45;
  TASSIGN(v181, v182);
  // pto: %buf_key_l1_pool_inline8703__phi_v144
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v144
  uint64_t v184 = (uint64_t) v45;
  TASSIGN(v183, v184);
  // pto: %buf_key_l1_pool_inline8703__phi_v149
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v185 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v149
  uint64_t v186 = (uint64_t) v45;
  TASSIGN(v185, v186);
  // pto: %buf_key_l1_pool_inline8703__phi_v155
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v187 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v155
  uint64_t v188 = (uint64_t) v45;
  TASSIGN(v187, v188);
  // pto: %buf_key_l1_pool_inline8703__phi_v160
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v189 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v160
  uint64_t v190 = (uint64_t) v45;
  TASSIGN(v189, v190);
  // pto: %buf_key_l1_pool_inline8703__phi_v166
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v191 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v166
  uint64_t v192 = (uint64_t) v45;
  TASSIGN(v191, v192);
  // pto: %buf_key_l1_pool_inline8703__phi_v171
  Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v193 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
  // pto: %buf_key_l1_pool_inline8703__phi_v171
  uint64_t v194 = (uint64_t) v45;
  TASSIGN(v193, v194);
  // pto: %buf_worker_inline8627__ssa_v0
  int64_t v195 = (int64_t) v24;
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  // pto: %buf_max_cache_len_inline8692__rv_v2
  int64_t v196;
  v196 = v56;
  for (int64_t v197 = v56; v197 < v17; v197 += v49) {
    // pto: %t__tile
    ;
    int32_t v198 = (v1)[v197];
    // pto: %0, %1
    ;
    int64_t v199 = (int64_t) v198 / v57;
    // pto: %2
    ;
    bool v200 = v196 < v199;
    // pto: %2
    ;
    int64_t v201 = v200 ? v199 : v196;
    v196 = v201;
  }
  // pto: %3
  bool v202 = v196 < v58;
  // pto: %3
  int64_t v203 = v202 ? v196 : v58;
  // pto: %4
  int32_t v204 = (v2)[v56];
  // pto: %5
  int64_t v205 = (int64_t) v204;
  // pto: %6, %7
  int64_t v206 = (int64_t) ((uint64_t) v203 + (uint64_t) v59) / v55;
  // pto: %8, %9
  int64_t v207 = (int64_t) ((uint64_t) v203 + (uint64_t) v60) / v61;
  // pto: %10
  int64_t v208 = v207 < v49 ? v49 : v207;
  // pto: %11
  int64_t v209 = (int64_t) ((uint64_t) v205 * (uint64_t) v62);
  // pto: %12
  // pto: %leaf_multiple_inline2601_inline8700__phi_v6
  int64_t v210;
  if (v209 == v63) {
    v210 = v62;
  } else {
    // pto: %14
    ;
    // pto: %leaf_multiple_inline2601_inline8700__phi_v5
    ;
    int64_t v211;
    if (v209 == v64) {
      v211 = v62;
    } else {
      // pto: %15, %16, %leaf_multiple_inline2601_inline8700__phi_v4
      ;
      v211 = (int64_t) ((uint64_t) v205 * (uint64_t) v65) == v64 ? v65 : v49;
    };
    v210 = v211;
  }
  // pto: %17
  bool v212 = v210 > v49;
  // pto: %extra_leaves_inline2600_inline8711__phi_v3
  int64_t v213;
  // pto: %leaf_count_inline2603_inline8599__phi_v3
  int64_t v214;
  // pto: %leaf_tiles_inline2602_inline8714__phi_v3
  int64_t v215;
  if (v212) {
    // pto: %18
    ;
    uint64_t v216 = (uint64_t) v210;
    // pto: %18, %19, %20
    ;
    int64_t v217 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v208 + v216) - (uint64_t) v49) / v210;
    // pto: %21
    ;
    uint64_t v218 = (uint64_t) v210;
    // pto: %21
    ;
    int64_t v219 = (int64_t) ((uint64_t) v217 * v218);
    // pto: %22
    ;
    bool v220 = v219 <= v66;
    // pto: %extra_leaves_inline2600_inline8711__phi_v2
    ;
    // pto: %leaf_count_inline2603_inline8599__phi_v2
    ;
    int64_t v221;
    // pto: %leaf_tiles_inline2602_inline8714__phi_v2
    ;
    int64_t v222;
    if (v220) {
      // pto: %23
      ;
      int64_t v223 = v206 / v219;
      // pto: %24
      ;
      // pto: %25
      ;
      v221 = v206 % v219;
      v222 = v223 < v49 ? v49 : v223;
    } else {
      v221 = v56;
      v222 = v67;
    };
    v213 = v221;
    v214 = v220 ? v219 : v208;
    v215 = v222;
  } else {
    v213 = v56;
    v214 = v208;
    v215 = v67;
  }
  uint64_t v224 = reinterpret_cast<uint64_t>(v3);
  set_ffts_base_addr(v224);
  // pto: %26
  uint64_t v225 = (uint64_t) v214;
  // pto: %26
  for (int64_t v226 = v195; v226 < ((int64_t) ((uint64_t) v205 * v225)); v226 += v64) {
    // pto: %27
    ;
    // pto: %buf_group_inline8855__phi_v2
    ;
    int64_t v227;
    // pto: %buf_leaf_inline8680__phi_v2
    ;
    int64_t v228;
    if (v205 < v64) {
      // pto: %28
      ;
      // pto: %29
      ;
      v227 = v226 % v205;
      v228 = v226 / v205;
    } else {
      // pto: %30
      ;
      int64_t v229 = v226 / v214;
      // pto: %31
      ;
      int64_t v230 = v226 % v214;
      v227 = v229;
      v228 = v230;
    };
    // pto: %32
    ;
    int32_t v231 = (v4)[v227];
    // pto: %33
    ;
    int64_t v232 = (int64_t) v231;
    // pto: %34
    ;
    int32_t v233 = (v5)[v227];
    // pto: %36
    ;
    int32_t v234 = (v6)[v232];
    // pto: %37
    ;
    int64_t v235 = (int64_t) v234;
    // pto: %38, %35, %39, %buf_last_position_inline8723__tile
    ;
    int64_t v236 = (v7)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v232 + (uint64_t) ((int64_t) v233)) - (uint64_t) v49)];
    // pto: %40
    ;
    int32_t v237 = (v1)[v235];
    // pto: %41, %42
    ;
    int64_t v238 = (int64_t) v237 / v57;
    // pto: %43, %44
    ;
    int64_t v239 = (int64_t) ((uint64_t) v236 + (uint64_t) v68) / v69;
    // pto: %46
    ;
    int64_t v240 = v238 < v239 ? v238 : v239;
    // pto: %47
    ;
    int64_t v241 = v240 < v58 ? v240 : v58;
    // pto: %48
    ;
    int64_t v242 = v241 < v56 ? v56 : v241;
    // pto: %49
    ;
    uint64_t v243 = (uint64_t) v228;
    // pto: %49
    ;
    uint64_t v244 = (uint64_t) v215;
    // pto: %50
    ;
    bool v245 = v228 < v213;
    // pto: %50
    ;
    int64_t v246 = v245 ? v228 : v213;
    // pto: %49, %51, %52
    ;
    int64_t v247 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v243 * v244) + (uint64_t) v246) * (uint64_t) v55);
    // pto: %53
    ;
    bool v248 = v228 < v213;
    // pto: %55
    ;
    uint64_t v249 = (uint64_t) v215;
    // pto: %54, %55, %56
    ;
    int64_t v250 = (int64_t) ((uint64_t) ((int64_t) v249 + (uint64_t) ((int64_t) v248)) * (uint64_t) v55);
    // pto: %57
    ;
    if (v247 < v242) {
      // pto: %58
      ;
      int64_t v251 = (int64_t) ((uint64_t) v242 - (uint64_t) v247);
      // pto: %59
      ;
      int64_t v252 = v250 < v251 ? v250 : v251;
      // pto: %60, %61, %62
      ;
      int64_t v253 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v252 + (uint64_t) v59) / v55) * (uint64_t) v70);
      // pto: %63
      ;
      int64_t v254 = v253 < v71 ? v253 : v71;
      // pto: %64, %65
      ;
      int64_t v255 = (int64_t) ((uint64_t) v254 + (uint64_t) v72) / v70;
      // pto: %buf_query_vector_inline8658__ssa_v0
      ;
      Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v256 = Tile<TileType::Mat, int8_t, 384, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v51);
      // pto: %buf_query_vector_inline8658__ssa_v0
      ;
      uint64_t v257 = (uint64_t) v43;
      TASSIGN(v256, v257);
      // pto: %66
      ;
      int64_t v258 = (int64_t) ((uint64_t) v232 * (uint64_t) v73);
      // pto: %67
      ;
      int64_t v259 = v258 < v56 ? v56 : v258;
      // pto: %qr_hadamard_i8_inline1363__rv_v2_pview
      ;
      __gm__ int8_t* v260 = PTOAS__GLOBAL_TENSOR_DATA(v96);
      // pto: %qr_hadamard_i8_inline1363__rv_v2_pview
      ;
      const int64_t v261 = 0;
      // pto: %qr_hadamard_i8_inline1363__rv_v2_pview
      ;
      const int64_t v262 = 128;
      // pto: %qr_hadamard_i8_inline1363__rv_v2_pview
      ;
      pto::Shape<1, 1, 1, 384, 128> v263 = pto::Shape<1, 1, 1, 384, 128>();
      // pto: %qr_hadamard_i8_inline1363__rv_v2_pview
      ;
      pto::Stride<49152, 49152, 49152, 128, 1> v264 = pto::Stride<49152, 49152, 49152, 128, 1>();
      // pto: %qr_hadamard_i8_inline1363__rv_v2_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 384, 128>, pto::Stride<49152, 49152, 49152, 128, 1>, pto::Layout::ND> v265 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 384, 128>, pto::Stride<49152, 49152, 49152, 128, 1>, pto::Layout::ND>(v260 + (v261 + v259 * v262), v263, v264);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v256, v265);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %buf_coefficients_l1_inline8832__ssa_v0
      ;
      Tile<TileType::Mat, half, 16, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Mat, half, 16, 384, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v74, v53);
      // pto: %buf_coefficients_l1_inline8832__ssa_v0
      ;
      uint64_t v267 = (uint64_t) v44;
      TASSIGN(v266, v267);
      // pto: %68
      ;
      uint64_t v268 = (uint64_t) v227;
      // pto: %68
      ;
      int64_t v269 = (int64_t) (v268 * (uint64_t) v74);
      // pto: %69
      ;
      int64_t v270 = v269 < v56 ? v56 : v269;
      // pto: %coefficients_inline8650__ssa_v0_pview
      ;
      __gm__ half* v271 = PTOAS__GLOBAL_TENSOR_DATA(v104);
      // pto: %coefficients_inline8650__ssa_v0_pview
      ;
      const int64_t v272 = 0;
      // pto: %coefficients_inline8650__ssa_v0_pview
      ;
      const int64_t v273 = 384;
      // pto: %coefficients_inline8650__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 384> v274 = pto::Shape<1, 1, 1, 16, 384>();
      // pto: %coefficients_inline8650__ssa_v0_pview
      ;
      pto::Stride<6144, 6144, 6144, 384, 1> v275 = pto::Stride<6144, 6144, 6144, 384, 1>();
      // pto: %coefficients_inline8650__ssa_v0_pview
      ;
      GlobalTensor<half, pto::Shape<1, 1, 1, 16, 384>, pto::Stride<6144, 6144, 6144, 384, 1>, pto::Layout::ND> v276 = GlobalTensor<half, pto::Shape<1, 1, 1, 16, 384>, pto::Stride<6144, 6144, 6144, 384, 1>, pto::Layout::ND>(v271 + (v272 + v270 * v273), v274, v275);
      TLOAD(v266, v276);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %buf_query_left_inline8595__ssa_v0
      ;
      Tile<TileType::Left, int8_t, 384, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Left, int8_t, 384, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v51);
      // pto: %buf_query_left_inline8595__ssa_v0
      ;
      uint64_t v278 = (uint64_t) v43;
      TASSIGN(v277, v278);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      TMOV(v277, v256);
      // pto: %buf_coefficient_pair_inline8643__ssa_v0
      ;
      Tile<TileType::Left, half, 16, 384, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Left, half, 16, 384, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v74, v53);
      // pto: %buf_coefficient_pair_inline8643__ssa_v0
      ;
      uint64_t v280 = (uint64_t) v45;
      TASSIGN(v279, v280);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v279, v266);
      for (int64_t v281 = v56; v281 < v255; v281 += v49) {
        // pto: %70
        ;
        if (v281 >= v75) {
          int32_t v282 = (int32_t) v49;
          wait_flag_dev(v282);
        };
        // pto: %72, %75, %73, %74
        ;
        int64_t v283 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v195 * (uint64_t) v76) + (uint64_t) ((int64_t) (uint64_t) (v281 % v75) * (uint64_t) v65));
        // pto: %buf_key_l1_pool_inline8703__ssa_v0
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v284 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %buf_key_l1_pool_inline8703__ssa_v0
        ;
        uint64_t v285 = (uint64_t) v45;
        TASSIGN(v284, v285);
        // pto: %76, %71
        ;
        int64_t v286 = (int64_t) ((uint64_t) v247 + (uint64_t) ((int64_t) (uint64_t) v281 * (uint64_t) v55));
        // pto: %78
        ;
        int64_t v287 = v286 / v66;
        // pto: %79, %80
        ;
        int64_t v288 = (int64_t) ((uint64_t) v238 - (uint64_t) v49) / v66;
        // pto: %81
        ;
        int64_t v289 = v288 < v56 ? v56 : v288;
        // pto: %82
        ;
        int64_t v290 = v287 < v289 ? v287 : v289;
        // pto: %flat_offset_mul
        ;
        int64_t v291 = (int64_t) ((uint64_t) v235 * (uint64_t) v19);
        // pto: %flat_offset, %83
        ;
        int32_t v292 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v290)];
        // pto: %84
        ;
        int64_t v293 = (int64_t) v292;
        // pto: %85
        ;
        int64_t v294 = v293 < v56 ? v56 : v293;
        // pto: %86
        ;
        int64_t v295 = (int64_t) ((uint64_t) v294 * (uint64_t) v16);
        // pto: %87, %88
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        if (v295 % v51 == v56) {
          // pto: %gather_row_view
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v296;
          // pto: %gather_row_view
          ;
          uint64_t v297 = (uint64_t) v45;
          TASSIGN(v296, v297);
          // pto: %89
          ;
          int64_t v298 = v295 / v51;
          // pto: %90
          ;
          int64_t v299 = v298 < v56 ? v56 : v298;
          // pto: %idx_kv_cache_inline8669__ssa_v0_pview
          ;
          __gm__ int8_t* v300 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %idx_kv_cache_inline8669__ssa_v0_pview
          ;
          const int64_t v301 = 0;
          // pto: %idx_kv_cache_inline8669__ssa_v0_pview
          ;
          const int64_t v302 = 128;
          // pto: %idx_kv_cache_inline8669__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 32, 128> v303 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %idx_kv_cache_inline8669__ssa_v0_pview
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v304 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %idx_kv_cache_inline8669__ssa_v0_pview
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v305 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v300 + (v301 + v299 * v302), v303, v304);
          TLOAD(v296, v305);
        } else {
          // pto: %91
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v306;
          // pto: %91
          ;
          uint64_t v307 = (uint64_t) v45;
          TASSIGN(v306, v307);
          // pto: %92
          ;
          int64_t v308 = v295 / v51;
          // pto: %93
          ;
          int64_t v309 = v308 < v56 ? v56 : v308;
          // pto: %idx_kv_cache_shift64_inline8652__ssa_v0_pview
          ;
          __gm__ int8_t* v310 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %idx_kv_cache_shift64_inline8652__ssa_v0_pview
          ;
          const int64_t v311 = 0;
          // pto: %idx_kv_cache_shift64_inline8652__ssa_v0_pview
          ;
          const int64_t v312 = 128;
          // pto: %idx_kv_cache_shift64_inline8652__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 32, 128> v313 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %idx_kv_cache_shift64_inline8652__ssa_v0_pview
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v314 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %idx_kv_cache_shift64_inline8652__ssa_v0_pview
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v315 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v310 + (v311 + v309 * v312), v313, v314);
          TLOAD(v306, v315);
        };
        // pto: %96, %97
        ;
        int64_t v316 = (int64_t) ((uint64_t) v286 + (uint64_t) v66) / v66;
        // pto: %101
        ;
        int64_t v317 = v316 < v289 ? v316 : v289;
        // pto: %104, %102
        ;
        int32_t v318 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v317)];
        // pto: %105
        ;
        int64_t v319 = (int64_t) v318;
        // pto: %106
        ;
        int64_t v320 = v319 < v56 ? v56 : v319;
        // pto: %107
        ;
        int64_t v321 = (int64_t) ((uint64_t) v320 * (uint64_t) v16);
        // pto: %108, %109
        ;
        if (v321 % v51 == v56) {
          // pto: %110
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v322;
          // pto: %110
          ;
          uint64_t v323 = (uint64_t) v42;
          TASSIGN(v322, v323);
          // pto: %111
          ;
          int64_t v324 = v321 / v51;
          // pto: %112
          ;
          int64_t v325 = v324 < v56 ? v56 : v324;
          // pto: %113
          ;
          __gm__ int8_t* v326 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %113
          ;
          const int64_t v327 = 0;
          // pto: %113
          ;
          const int64_t v328 = 128;
          // pto: %113
          ;
          pto::Shape<1, 1, 1, 32, 128> v329 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %113
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v330 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %113
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v331 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v326 + (v327 + v325 * v328), v329, v330);
          TLOAD(v322, v331);
        } else {
          // pto: %114
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v332;
          // pto: %114
          ;
          uint64_t v333 = (uint64_t) v42;
          TASSIGN(v332, v333);
          // pto: %115
          ;
          int64_t v334 = v321 / v51;
          // pto: %116
          ;
          int64_t v335 = v334 < v56 ? v56 : v334;
          // pto: %117
          ;
          __gm__ int8_t* v336 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %117
          ;
          const int64_t v337 = 0;
          // pto: %117
          ;
          const int64_t v338 = 128;
          // pto: %117
          ;
          pto::Shape<1, 1, 1, 32, 128> v339 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %117
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v340 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %117
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v341 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v336 + (v337 + v335 * v338), v339, v340);
          TLOAD(v332, v341);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        // pto: %t__tmp_v445
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v342 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v445
        ;
        uint64_t v343 = (uint64_t) v45;
        TASSIGN(v342, v343);
        // pto: %buf_current_key_inline8632__ssa_v1
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v344 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8632__ssa_v1
        ;
        uint64_t v345 = (uint64_t) v46;
        TASSIGN(v344, v345);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v346 = static_cast<uint16_t>(v56);
        uint16_t v347 = static_cast<uint16_t>(v56);
        TEXTRACT(v344, v342, v346, v347);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %119, %120
        ;
        int64_t v348 = (int64_t) ((uint64_t) v286 + (uint64_t) v73) / v66;
        // pto: %124
        ;
        int64_t v349 = v348 < v289 ? v348 : v289;
        // pto: %127, %125
        ;
        int32_t v350 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v349)];
        // pto: %128
        ;
        int64_t v351 = (int64_t) v350;
        // pto: %129
        ;
        int64_t v352 = v351 < v56 ? v56 : v351;
        // pto: %130
        ;
        int64_t v353 = (int64_t) ((uint64_t) v352 * (uint64_t) v16);
        // pto: %131, %132
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v353 % v51 == v56) {
          // pto: %133
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v354;
          // pto: %133
          ;
          uint64_t v355 = (uint64_t) v41;
          TASSIGN(v354, v355);
          // pto: %134
          ;
          int64_t v356 = v353 / v51;
          // pto: %135
          ;
          int64_t v357 = v356 < v56 ? v56 : v356;
          // pto: %136
          ;
          __gm__ int8_t* v358 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %136
          ;
          const int64_t v359 = 0;
          // pto: %136
          ;
          const int64_t v360 = 128;
          // pto: %136
          ;
          pto::Shape<1, 1, 1, 32, 128> v361 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %136
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v362 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %136
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v363 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v358 + (v359 + v357 * v360), v361, v362);
          TLOAD(v354, v363);
        } else {
          // pto: %137
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v364;
          // pto: %137
          ;
          uint64_t v365 = (uint64_t) v41;
          TASSIGN(v364, v365);
          // pto: %138
          ;
          int64_t v366 = v353 / v51;
          // pto: %139
          ;
          int64_t v367 = v366 < v56 ? v56 : v366;
          // pto: %140
          ;
          __gm__ int8_t* v368 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %140
          ;
          const int64_t v369 = 0;
          // pto: %140
          ;
          const int64_t v370 = 128;
          // pto: %140
          ;
          pto::Shape<1, 1, 1, 32, 128> v371 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %140
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v372 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %140
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v373 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v368 + (v369 + v367 * v370), v371, v372);
          TLOAD(v364, v373);
        };
        // pto: %143, %144
        ;
        int64_t v374 = (int64_t) ((uint64_t) v286 + (uint64_t) v40) / v66;
        // pto: %148
        ;
        int64_t v375 = v374 < v289 ? v374 : v289;
        // pto: %151, %149
        ;
        int32_t v376 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v375)];
        // pto: %152
        ;
        int64_t v377 = (int64_t) v376;
        // pto: %153
        ;
        int64_t v378 = v377 < v56 ? v56 : v377;
        // pto: %154
        ;
        int64_t v379 = (int64_t) ((uint64_t) v378 * (uint64_t) v16);
        // pto: %155, %156
        ;
        if (v379 % v51 == v56) {
          // pto: %158
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v380;
          // pto: %158
          ;
          uint64_t v381 = (uint64_t) v39;
          TASSIGN(v380, v381);
          // pto: %159
          ;
          int64_t v382 = v379 / v51;
          // pto: %160
          ;
          int64_t v383 = v382 < v56 ? v56 : v382;
          // pto: %161
          ;
          __gm__ int8_t* v384 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %161
          ;
          const int64_t v385 = 0;
          // pto: %161
          ;
          const int64_t v386 = 128;
          // pto: %161
          ;
          pto::Shape<1, 1, 1, 32, 128> v387 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %161
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v388 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %161
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v389 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v384 + (v385 + v383 * v386), v387, v388);
          TLOAD(v380, v389);
        } else {
          // pto: %163
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v390;
          // pto: %163
          ;
          uint64_t v391 = (uint64_t) v39;
          TASSIGN(v390, v391);
          // pto: %164
          ;
          int64_t v392 = v379 / v51;
          // pto: %165
          ;
          int64_t v393 = v392 < v56 ? v56 : v392;
          // pto: %166
          ;
          __gm__ int8_t* v394 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %166
          ;
          const int64_t v395 = 0;
          // pto: %166
          ;
          const int64_t v396 = 128;
          // pto: %166
          ;
          pto::Shape<1, 1, 1, 32, 128> v397 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %166
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v398 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %166
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v399 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v394 + (v395 + v393 * v396), v397, v398);
          TLOAD(v390, v399);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
        // pto: %t__tmp_v448
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v400 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v448
        ;
        uint64_t v401 = (uint64_t) v45;
        TASSIGN(v400, v401);
        // pto: %buf_prefetched_key_inline8631__ssa_v1
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v402 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8631__ssa_v1
        ;
        uint64_t v403 = (uint64_t) v43;
        TASSIGN(v402, v403);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
        uint16_t v404 = static_cast<uint16_t>(v56);
        uint16_t v405 = static_cast<uint16_t>(v73);
        TEXTRACT(v402, v400, v404, v405);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        // pto: %buf_key_panel_inline8777__ssa_v0
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v406 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8777__ssa_v0
        ;
        uint64_t v407 = (uint64_t) v46;
        TASSIGN(v406, v407);
        // pto: %buf_scores_l1_inline8697__ssa_v0
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v408 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8697__ssa_v0
        ;
        uint64_t v409 = (uint64_t) v43;
        TASSIGN(v408, v409);
        // pto: %buf_scores_inline8611__ssa_v1
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v410 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8611__ssa_v1
        ;
        uint64_t v411 = (uint64_t) v43;
        TASSIGN(v410, v411);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        TMATMUL(v410, v277, v406);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v412 = static_cast<uint64_t>(v77);
        uint16_t v413 = static_cast<uint16_t>(v56);
        uint16_t v414 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v408, v410, v412, v413, v414);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        // pto: %buf_previous_l1_inline8635__ssa_v1
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v415 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8635__ssa_v1
        ;
        uint64_t v416 = (uint64_t) v43;
        TASSIGN(v415, v416);
        // pto: %buf_current_key_inline8632__ssa_v7
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v417 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8632__ssa_v7
        ;
        uint64_t v418 = (uint64_t) v43;
        TASSIGN(v417, v418);
        // pto: %168, %169
        ;
        int64_t v419 = (int64_t) ((uint64_t) v286 + (uint64_t) v51) / v66;
        // pto: %173
        ;
        int64_t v420 = v419 < v289 ? v419 : v289;
        // pto: %176, %174
        ;
        int32_t v421 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v420)];
        // pto: %177
        ;
        int64_t v422 = (int64_t) v421;
        // pto: %178
        ;
        int64_t v423 = v422 < v56 ? v56 : v422;
        // pto: %179
        ;
        int64_t v424 = (int64_t) ((uint64_t) v423 * (uint64_t) v16);
        // pto: %180, %181
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        if (v424 % v51 == v56) {
          // pto: %182
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v425;
          // pto: %182
          ;
          uint64_t v426 = (uint64_t) v45;
          TASSIGN(v425, v426);
          // pto: %183
          ;
          int64_t v427 = v424 / v51;
          // pto: %184
          ;
          int64_t v428 = v427 < v56 ? v56 : v427;
          // pto: %185
          ;
          __gm__ int8_t* v429 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %185
          ;
          const int64_t v430 = 0;
          // pto: %185
          ;
          const int64_t v431 = 128;
          // pto: %185
          ;
          pto::Shape<1, 1, 1, 32, 128> v432 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %185
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v433 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %185
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v434 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v429 + (v430 + v428 * v431), v432, v433);
          TLOAD(v425, v434);
        } else {
          // pto: %186
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v435;
          // pto: %186
          ;
          uint64_t v436 = (uint64_t) v45;
          TASSIGN(v435, v436);
          // pto: %187
          ;
          int64_t v437 = v424 / v51;
          // pto: %188
          ;
          int64_t v438 = v437 < v56 ? v56 : v437;
          // pto: %189
          ;
          __gm__ int8_t* v439 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %189
          ;
          const int64_t v440 = 0;
          // pto: %189
          ;
          const int64_t v441 = 128;
          // pto: %189
          ;
          pto::Shape<1, 1, 1, 32, 128> v442 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %189
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v443 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %189
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v444 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v439 + (v440 + v438 * v441), v442, v443);
          TLOAD(v435, v444);
        };
        // pto: %192, %193
        ;
        int64_t v445 = (int64_t) ((uint64_t) v286 + (uint64_t) v38) / v66;
        // pto: %197
        ;
        int64_t v446 = v445 < v289 ? v445 : v289;
        // pto: %200, %198
        ;
        int32_t v447 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v446)];
        // pto: %201
        ;
        int64_t v448 = (int64_t) v447;
        // pto: %202
        ;
        int64_t v449 = v448 < v56 ? v56 : v448;
        // pto: %203
        ;
        int64_t v450 = (int64_t) ((uint64_t) v449 * (uint64_t) v16);
        // pto: %204, %205
        ;
        if (v450 % v51 == v56) {
          // pto: %207
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v451;
          // pto: %207
          ;
          uint64_t v452 = (uint64_t) v42;
          TASSIGN(v451, v452);
          // pto: %208
          ;
          int64_t v453 = v450 / v51;
          // pto: %209
          ;
          int64_t v454 = v453 < v56 ? v56 : v453;
          // pto: %210
          ;
          __gm__ int8_t* v455 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %210
          ;
          const int64_t v456 = 0;
          // pto: %210
          ;
          const int64_t v457 = 128;
          // pto: %210
          ;
          pto::Shape<1, 1, 1, 32, 128> v458 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %210
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v459 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %210
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v460 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v455 + (v456 + v454 * v457), v458, v459);
          TLOAD(v451, v460);
        } else {
          // pto: %212
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v461;
          // pto: %212
          ;
          uint64_t v462 = (uint64_t) v42;
          TASSIGN(v461, v462);
          // pto: %213
          ;
          int64_t v463 = v450 / v51;
          // pto: %214
          ;
          int64_t v464 = v463 < v56 ? v56 : v463;
          // pto: %215
          ;
          __gm__ int8_t* v465 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %215
          ;
          const int64_t v466 = 0;
          // pto: %215
          ;
          const int64_t v467 = 128;
          // pto: %215
          ;
          pto::Shape<1, 1, 1, 32, 128> v468 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %215
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v469 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %215
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v470 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v465 + (v466 + v464 * v467), v468, v469);
          TLOAD(v461, v470);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
        // pto: %t__tmp_v451
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v471 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v451
        ;
        uint64_t v472 = (uint64_t) v45;
        TASSIGN(v471, v472);
        // pto: %buf_prefetched_key_inline8631__ssa_v6
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v473 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8631__ssa_v6
        ;
        uint64_t v474 = (uint64_t) v47;
        TASSIGN(v473, v474);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
        uint16_t v475 = static_cast<uint16_t>(v56);
        uint16_t v476 = static_cast<uint16_t>(v56);
        TEXTRACT(v473, v471, v475, v476);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        // pto: %buf_key_panel_inline8777__ssa_v3
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v477 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8777__ssa_v3
        ;
        uint64_t v478 = (uint64_t) v43;
        TASSIGN(v477, v478);
        // pto: %buf_scores_l1_inline8697__ssa_v4
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v479 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8697__ssa_v4
        ;
        uint64_t v480 = (uint64_t) v44;
        TASSIGN(v479, v480);
        // pto: %buf_previous_pair_inline8693__ssa_v1
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v481 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8693__ssa_v1
        ;
        uint64_t v482 = (uint64_t) v46;
        TASSIGN(v481, v482);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        uint16_t v483 = static_cast<uint16_t>(v56);
        uint16_t v484 = static_cast<uint16_t>(v56);
        TEXTRACT(v481, v415, v483, v484);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %buf_scores_inline8611__ssa_v3
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v485 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8611__ssa_v3
        ;
        uint64_t v486 = (uint64_t) v43;
        TASSIGN(v485, v486);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL(v485, v277, v477);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        // pto: %buf_reduced_pair_inline8798__ssa_v1
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v487 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8798__ssa_v1
        ;
        uint64_t v488 = (uint64_t) v48;
        TASSIGN(v487, v488);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        TMATMUL(v487, v279, v481);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        uint64_t v489 = static_cast<uint64_t>(v77);
        uint16_t v490 = static_cast<uint16_t>(v56);
        uint16_t v491 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v479, v485, v489, v490, v491);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID1);
        v487.SetValidShape(v65, v73);
        // pto: %216
        ;
        int64_t v492 = v283 < v56 ? v56 : v283;
        // pto: %buf_score_transfer_inline8684__ssa_v0_pview
        ;
        __gm__ float* v493 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %buf_score_transfer_inline8684__ssa_v0_pview
        ;
        const int64_t v494 = 0;
        // pto: %buf_score_transfer_inline8684__ssa_v0_pview
        ;
        const int64_t v495 = 1024;
        // pto: %buf_score_transfer_inline8684__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 6, 64> v496 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %buf_score_transfer_inline8684__ssa_v0_pview
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v497 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %buf_score_transfer_inline8684__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v498 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v493 + (v494 + v492 * v495), v496, v497);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        TSTORE(v498, v487);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
        // pto: %buf_previous_l1_inline8635__ssa_v2
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v499 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8635__ssa_v2
        ;
        uint64_t v500 = (uint64_t) v44;
        TASSIGN(v499, v500);
        // pto: %buf_current_key_inline8632__ssa_v14
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v501 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8632__ssa_v14
        ;
        uint64_t v502 = (uint64_t) v47;
        TASSIGN(v501, v502);
        // pto: %220, %221
        ;
        int64_t v503 = (int64_t) ((uint64_t) v286 + (uint64_t) v78) / v66;
        // pto: %225
        ;
        int64_t v504 = v503 < v289 ? v503 : v289;
        // pto: %228, %226
        ;
        int32_t v505 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v504)];
        // pto: %229
        ;
        int64_t v506 = (int64_t) v505;
        // pto: %230
        ;
        int64_t v507 = v506 < v56 ? v56 : v506;
        // pto: %231
        ;
        int64_t v508 = (int64_t) ((uint64_t) v507 * (uint64_t) v16);
        // pto: %232, %233
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        if (v508 % v51 == v56) {
          // pto: %234
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v509;
          // pto: %234
          ;
          uint64_t v510 = (uint64_t) v41;
          TASSIGN(v509, v510);
          // pto: %235
          ;
          int64_t v511 = v508 / v51;
          // pto: %236
          ;
          int64_t v512 = v511 < v56 ? v56 : v511;
          // pto: %237
          ;
          __gm__ int8_t* v513 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %237
          ;
          const int64_t v514 = 0;
          // pto: %237
          ;
          const int64_t v515 = 128;
          // pto: %237
          ;
          pto::Shape<1, 1, 1, 32, 128> v516 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %237
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v517 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %237
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v518 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v513 + (v514 + v512 * v515), v516, v517);
          TLOAD(v509, v518);
        } else {
          // pto: %238
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v519;
          // pto: %238
          ;
          uint64_t v520 = (uint64_t) v41;
          TASSIGN(v519, v520);
          // pto: %239
          ;
          int64_t v521 = v508 / v51;
          // pto: %240
          ;
          int64_t v522 = v521 < v56 ? v56 : v521;
          // pto: %241
          ;
          __gm__ int8_t* v523 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %241
          ;
          const int64_t v524 = 0;
          // pto: %241
          ;
          const int64_t v525 = 128;
          // pto: %241
          ;
          pto::Shape<1, 1, 1, 32, 128> v526 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %241
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v527 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %241
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v528 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v523 + (v524 + v522 * v525), v526, v527);
          TLOAD(v519, v528);
        };
        // pto: %244, %245
        ;
        int64_t v529 = (int64_t) ((uint64_t) v286 + (uint64_t) v37) / v66;
        // pto: %249
        ;
        int64_t v530 = v529 < v289 ? v529 : v289;
        // pto: %252, %250
        ;
        int32_t v531 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v530)];
        // pto: %253
        ;
        int64_t v532 = (int64_t) v531;
        // pto: %254
        ;
        int64_t v533 = v532 < v56 ? v56 : v532;
        // pto: %255
        ;
        int64_t v534 = (int64_t) ((uint64_t) v533 * (uint64_t) v16);
        // pto: %256, %257
        ;
        if (v534 % v51 == v56) {
          // pto: %259
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v535;
          // pto: %259
          ;
          uint64_t v536 = (uint64_t) v39;
          TASSIGN(v535, v536);
          // pto: %260
          ;
          int64_t v537 = v534 / v51;
          // pto: %261
          ;
          int64_t v538 = v537 < v56 ? v56 : v537;
          // pto: %262
          ;
          __gm__ int8_t* v539 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %262
          ;
          const int64_t v540 = 0;
          // pto: %262
          ;
          const int64_t v541 = 128;
          // pto: %262
          ;
          pto::Shape<1, 1, 1, 32, 128> v542 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %262
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v543 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %262
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v544 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v539 + (v540 + v538 * v541), v542, v543);
          TLOAD(v535, v544);
        } else {
          // pto: %264
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v545;
          // pto: %264
          ;
          uint64_t v546 = (uint64_t) v39;
          TASSIGN(v545, v546);
          // pto: %265
          ;
          int64_t v547 = v534 / v51;
          // pto: %266
          ;
          int64_t v548 = v547 < v56 ? v56 : v547;
          // pto: %267
          ;
          __gm__ int8_t* v549 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %267
          ;
          const int64_t v550 = 0;
          // pto: %267
          ;
          const int64_t v551 = 128;
          // pto: %267
          ;
          pto::Shape<1, 1, 1, 32, 128> v552 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %267
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v553 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %267
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v554 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v549 + (v550 + v548 * v551), v552, v553);
          TLOAD(v545, v554);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        // pto: %t__tmp_v455
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v555 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v455
        ;
        uint64_t v556 = (uint64_t) v45;
        TASSIGN(v555, v556);
        // pto: %buf_prefetched_key_inline8631__ssa_v11
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v557 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8631__ssa_v11
        ;
        uint64_t v558 = (uint64_t) v43;
        TASSIGN(v557, v558);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v559 = static_cast<uint16_t>(v56);
        uint16_t v560 = static_cast<uint16_t>(v73);
        TEXTRACT(v557, v555, v559, v560);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        // pto: %buf_key_panel_inline8777__ssa_v6
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v561 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8777__ssa_v6
        ;
        uint64_t v562 = (uint64_t) v47;
        TASSIGN(v561, v562);
        // pto: %buf_scores_l1_inline8697__ssa_v8
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v563 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8697__ssa_v8
        ;
        uint64_t v564 = (uint64_t) v43;
        TASSIGN(v563, v564);
        // pto: %buf_previous_pair_inline8693__ssa_v2
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v565 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8693__ssa_v2
        ;
        uint64_t v566 = (uint64_t) v46;
        TASSIGN(v565, v566);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v567 = static_cast<uint16_t>(v56);
        uint16_t v568 = static_cast<uint16_t>(v56);
        TEXTRACT(v565, v499, v567, v568);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        // pto: %buf_scores_inline8611__ssa_v6
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v569 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8611__ssa_v6
        ;
        uint64_t v570 = (uint64_t) v43;
        TASSIGN(v569, v570);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v569, v277, v561);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
        // pto: %buf_reduced_pair_inline8798__ssa_v2
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v571 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8798__ssa_v2
        ;
        uint64_t v572 = (uint64_t) v48;
        TASSIGN(v571, v572);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
        TMATMUL(v571, v279, v565);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
        uint64_t v573 = static_cast<uint64_t>(v77);
        uint16_t v574 = static_cast<uint16_t>(v56);
        uint16_t v575 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v563, v569, v573, v574, v575);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID2);
        v571.SetValidShape(v65, v73);
        // pto: %271
        ;
        __gm__ float* v576 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %271
        ;
        const int64_t v577 = 64;
        // pto: %271
        ;
        const int64_t v578 = 1024;
        // pto: %271
        ;
        pto::Shape<1, 1, 1, 6, 64> v579 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %271
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v580 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %271
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v581 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v576 + (v577 + v492 * v578), v579, v580);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        TSTORE(v581, v571);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
        // pto: %buf_previous_l1_inline8635__ssa_v3
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v582 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8635__ssa_v3
        ;
        uint64_t v583 = (uint64_t) v43;
        TASSIGN(v582, v583);
        // pto: %buf_current_key_inline8632__ssa_v21
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v584 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8632__ssa_v21
        ;
        uint64_t v585 = (uint64_t) v43;
        TASSIGN(v584, v585);
        // pto: %273, %274
        ;
        int64_t v586 = (int64_t) ((uint64_t) v286 + (uint64_t) v79) / v66;
        // pto: %278
        ;
        int64_t v587 = v586 < v289 ? v586 : v289;
        // pto: %281, %279
        ;
        int32_t v588 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v587)];
        // pto: %282
        ;
        int64_t v589 = (int64_t) v588;
        // pto: %283
        ;
        int64_t v590 = v589 < v56 ? v56 : v589;
        // pto: %284
        ;
        int64_t v591 = (int64_t) ((uint64_t) v590 * (uint64_t) v16);
        // pto: %285, %286
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        if (v591 % v51 == v56) {
          // pto: %287
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v592;
          // pto: %287
          ;
          uint64_t v593 = (uint64_t) v45;
          TASSIGN(v592, v593);
          // pto: %288
          ;
          int64_t v594 = v591 / v51;
          // pto: %289
          ;
          int64_t v595 = v594 < v56 ? v56 : v594;
          // pto: %290
          ;
          __gm__ int8_t* v596 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %290
          ;
          const int64_t v597 = 0;
          // pto: %290
          ;
          const int64_t v598 = 128;
          // pto: %290
          ;
          pto::Shape<1, 1, 1, 32, 128> v599 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %290
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v600 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %290
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v601 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v596 + (v597 + v595 * v598), v599, v600);
          TLOAD(v592, v601);
        } else {
          // pto: %291
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v602;
          // pto: %291
          ;
          uint64_t v603 = (uint64_t) v45;
          TASSIGN(v602, v603);
          // pto: %292
          ;
          int64_t v604 = v591 / v51;
          // pto: %293
          ;
          int64_t v605 = v604 < v56 ? v56 : v604;
          // pto: %294
          ;
          __gm__ int8_t* v606 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %294
          ;
          const int64_t v607 = 0;
          // pto: %294
          ;
          const int64_t v608 = 128;
          // pto: %294
          ;
          pto::Shape<1, 1, 1, 32, 128> v609 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %294
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v610 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %294
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v611 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v606 + (v607 + v605 * v608), v609, v610);
          TLOAD(v602, v611);
        };
        // pto: %297, %298
        ;
        int64_t v612 = (int64_t) ((uint64_t) v286 + (uint64_t) v54) / v66;
        // pto: %302
        ;
        int64_t v613 = v612 < v289 ? v612 : v289;
        // pto: %305, %303
        ;
        int32_t v614 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v613)];
        // pto: %306
        ;
        int64_t v615 = (int64_t) v614;
        // pto: %307
        ;
        int64_t v616 = v615 < v56 ? v56 : v615;
        // pto: %308
        ;
        int64_t v617 = (int64_t) ((uint64_t) v616 * (uint64_t) v16);
        // pto: %309, %310
        ;
        if (v617 % v51 == v56) {
          // pto: %312
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v618;
          // pto: %312
          ;
          uint64_t v619 = (uint64_t) v42;
          TASSIGN(v618, v619);
          // pto: %313
          ;
          int64_t v620 = v617 / v51;
          // pto: %314
          ;
          int64_t v621 = v620 < v56 ? v56 : v620;
          // pto: %315
          ;
          __gm__ int8_t* v622 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %315
          ;
          const int64_t v623 = 0;
          // pto: %315
          ;
          const int64_t v624 = 128;
          // pto: %315
          ;
          pto::Shape<1, 1, 1, 32, 128> v625 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %315
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v626 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %315
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v627 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v622 + (v623 + v621 * v624), v625, v626);
          TLOAD(v618, v627);
        } else {
          // pto: %317
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v628;
          // pto: %317
          ;
          uint64_t v629 = (uint64_t) v42;
          TASSIGN(v628, v629);
          // pto: %318
          ;
          int64_t v630 = v617 / v51;
          // pto: %319
          ;
          int64_t v631 = v630 < v56 ? v56 : v630;
          // pto: %320
          ;
          __gm__ int8_t* v632 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %320
          ;
          const int64_t v633 = 0;
          // pto: %320
          ;
          const int64_t v634 = 128;
          // pto: %320
          ;
          pto::Shape<1, 1, 1, 32, 128> v635 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %320
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v636 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %320
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v637 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v632 + (v633 + v631 * v634), v635, v636);
          TLOAD(v628, v637);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        // pto: %t__tmp_v459
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v638 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v459
        ;
        uint64_t v639 = (uint64_t) v45;
        TASSIGN(v638, v639);
        // pto: %buf_prefetched_key_inline8631__ssa_v16
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v640 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8631__ssa_v16
        ;
        uint64_t v641 = (uint64_t) v47;
        TASSIGN(v640, v641);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        uint16_t v642 = static_cast<uint16_t>(v56);
        uint16_t v643 = static_cast<uint16_t>(v56);
        TEXTRACT(v640, v638, v642, v643);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
        // pto: %buf_key_panel_inline8777__ssa_v9
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v644 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8777__ssa_v9
        ;
        uint64_t v645 = (uint64_t) v43;
        TASSIGN(v644, v645);
        // pto: %buf_scores_l1_inline8697__ssa_v12
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v646 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8697__ssa_v12
        ;
        uint64_t v647 = (uint64_t) v44;
        TASSIGN(v646, v647);
        // pto: %buf_previous_pair_inline8693__ssa_v3
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v648 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8693__ssa_v3
        ;
        uint64_t v649 = (uint64_t) v46;
        TASSIGN(v648, v649);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        uint16_t v650 = static_cast<uint16_t>(v56);
        uint16_t v651 = static_cast<uint16_t>(v56);
        TEXTRACT(v648, v582, v650, v651);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        // pto: %buf_scores_inline8611__ssa_v9
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v652 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8611__ssa_v9
        ;
        uint64_t v653 = (uint64_t) v43;
        TASSIGN(v652, v653);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
        TMATMUL(v652, v277, v644);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
        // pto: %buf_reduced_pair_inline8798__ssa_v3
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v654 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8798__ssa_v3
        ;
        uint64_t v655 = (uint64_t) v48;
        TASSIGN(v654, v655);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
        TMATMUL(v654, v279, v648);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID6);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
        uint64_t v656 = static_cast<uint64_t>(v77);
        uint16_t v657 = static_cast<uint16_t>(v56);
        uint16_t v658 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v646, v652, v656, v657, v658);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID3);
        v654.SetValidShape(v65, v73);
        // pto: %324
        ;
        __gm__ float* v659 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %324
        ;
        const int64_t v660 = 128;
        // pto: %324
        ;
        const int64_t v661 = 1024;
        // pto: %324
        ;
        pto::Shape<1, 1, 1, 6, 64> v662 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %324
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v663 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %324
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v664 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v659 + (v660 + v492 * v661), v662, v663);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID6);
        TSTORE(v664, v654);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        // pto: %buf_previous_l1_inline8635__ssa_v4
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v665 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8635__ssa_v4
        ;
        uint64_t v666 = (uint64_t) v44;
        TASSIGN(v665, v666);
        // pto: %buf_current_key_inline8632__ssa_v28
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v667 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8632__ssa_v28
        ;
        uint64_t v668 = (uint64_t) v47;
        TASSIGN(v667, v668);
        // pto: %326, %327
        ;
        int64_t v669 = (int64_t) ((uint64_t) v286 + (uint64_t) v80) / v66;
        // pto: %331
        ;
        int64_t v670 = v669 < v289 ? v669 : v289;
        // pto: %334, %332
        ;
        int32_t v671 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v670)];
        // pto: %335
        ;
        int64_t v672 = (int64_t) v671;
        // pto: %336
        ;
        int64_t v673 = v672 < v56 ? v56 : v672;
        // pto: %337
        ;
        int64_t v674 = (int64_t) ((uint64_t) v673 * (uint64_t) v16);
        // pto: %338, %339
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
        if (v674 % v51 == v56) {
          // pto: %340
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v675;
          // pto: %340
          ;
          uint64_t v676 = (uint64_t) v41;
          TASSIGN(v675, v676);
          // pto: %341
          ;
          int64_t v677 = v674 / v51;
          // pto: %342
          ;
          int64_t v678 = v677 < v56 ? v56 : v677;
          // pto: %343
          ;
          __gm__ int8_t* v679 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %343
          ;
          const int64_t v680 = 0;
          // pto: %343
          ;
          const int64_t v681 = 128;
          // pto: %343
          ;
          pto::Shape<1, 1, 1, 32, 128> v682 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %343
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v683 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %343
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v684 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v679 + (v680 + v678 * v681), v682, v683);
          TLOAD(v675, v684);
        } else {
          // pto: %344
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v685;
          // pto: %344
          ;
          uint64_t v686 = (uint64_t) v41;
          TASSIGN(v685, v686);
          // pto: %345
          ;
          int64_t v687 = v674 / v51;
          // pto: %346
          ;
          int64_t v688 = v687 < v56 ? v56 : v687;
          // pto: %347
          ;
          __gm__ int8_t* v689 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %347
          ;
          const int64_t v690 = 0;
          // pto: %347
          ;
          const int64_t v691 = 128;
          // pto: %347
          ;
          pto::Shape<1, 1, 1, 32, 128> v692 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %347
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v693 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %347
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v694 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v689 + (v690 + v688 * v691), v692, v693);
          TLOAD(v685, v694);
        };
        // pto: %350, %351
        ;
        int64_t v695 = (int64_t) ((uint64_t) v286 + (uint64_t) v36) / v66;
        // pto: %355
        ;
        int64_t v696 = v695 < v289 ? v695 : v289;
        // pto: %358, %356
        ;
        int32_t v697 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v696)];
        // pto: %359
        ;
        int64_t v698 = (int64_t) v697;
        // pto: %360
        ;
        int64_t v699 = v698 < v56 ? v56 : v698;
        // pto: %361
        ;
        int64_t v700 = (int64_t) ((uint64_t) v699 * (uint64_t) v16);
        // pto: %362, %363
        ;
        if (v700 % v51 == v56) {
          // pto: %365
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v701;
          // pto: %365
          ;
          uint64_t v702 = (uint64_t) v39;
          TASSIGN(v701, v702);
          // pto: %366
          ;
          int64_t v703 = v700 / v51;
          // pto: %367
          ;
          int64_t v704 = v703 < v56 ? v56 : v703;
          // pto: %368
          ;
          __gm__ int8_t* v705 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %368
          ;
          const int64_t v706 = 0;
          // pto: %368
          ;
          const int64_t v707 = 128;
          // pto: %368
          ;
          pto::Shape<1, 1, 1, 32, 128> v708 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %368
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v709 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %368
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v710 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v705 + (v706 + v704 * v707), v708, v709);
          TLOAD(v701, v710);
        } else {
          // pto: %370
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v711;
          // pto: %370
          ;
          uint64_t v712 = (uint64_t) v39;
          TASSIGN(v711, v712);
          // pto: %371
          ;
          int64_t v713 = v700 / v51;
          // pto: %372
          ;
          int64_t v714 = v713 < v56 ? v56 : v713;
          // pto: %373
          ;
          __gm__ int8_t* v715 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %373
          ;
          const int64_t v716 = 0;
          // pto: %373
          ;
          const int64_t v717 = 128;
          // pto: %373
          ;
          pto::Shape<1, 1, 1, 32, 128> v718 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %373
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v719 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %373
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v720 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v715 + (v716 + v714 * v717), v718, v719);
          TLOAD(v711, v720);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        // pto: %t__tmp_v463
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v721 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v463
        ;
        uint64_t v722 = (uint64_t) v45;
        TASSIGN(v721, v722);
        // pto: %buf_prefetched_key_inline8631__ssa_v21
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v723 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8631__ssa_v21
        ;
        uint64_t v724 = (uint64_t) v43;
        TASSIGN(v723, v724);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        uint16_t v725 = static_cast<uint16_t>(v56);
        uint16_t v726 = static_cast<uint16_t>(v73);
        TEXTRACT(v723, v721, v725, v726);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        // pto: %buf_key_panel_inline8777__ssa_v12
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v727 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8777__ssa_v12
        ;
        uint64_t v728 = (uint64_t) v47;
        TASSIGN(v727, v728);
        // pto: %buf_scores_l1_inline8697__ssa_v16
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v729 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8697__ssa_v16
        ;
        uint64_t v730 = (uint64_t) v43;
        TASSIGN(v729, v730);
        // pto: %buf_previous_pair_inline8693__ssa_v4
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v731 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8693__ssa_v4
        ;
        uint64_t v732 = (uint64_t) v46;
        TASSIGN(v731, v732);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID3);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        uint16_t v733 = static_cast<uint16_t>(v56);
        uint16_t v734 = static_cast<uint16_t>(v56);
        TEXTRACT(v731, v665, v733, v734);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        // pto: %buf_scores_inline8611__ssa_v12
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v735 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8611__ssa_v12
        ;
        uint64_t v736 = (uint64_t) v43;
        TASSIGN(v735, v736);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
        TMATMUL(v735, v277, v727);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID7);
        // pto: %buf_reduced_pair_inline8798__ssa_v4
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v737 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8798__ssa_v4
        ;
        uint64_t v738 = (uint64_t) v48;
        TASSIGN(v737, v738);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        TMATMUL(v737, v279, v731);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID7);
        uint64_t v739 = static_cast<uint64_t>(v77);
        uint16_t v740 = static_cast<uint16_t>(v56);
        uint16_t v741 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v729, v735, v739, v740, v741);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID4);
        v737.SetValidShape(v65, v73);
        // pto: %377
        ;
        __gm__ float* v742 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %377
        ;
        const int64_t v743 = 192;
        // pto: %377
        ;
        const int64_t v744 = 1024;
        // pto: %377
        ;
        pto::Shape<1, 1, 1, 6, 64> v745 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %377
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v746 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %377
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v747 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v742 + (v743 + v492 * v744), v745, v746);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        TSTORE(v747, v737);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8635__ssa_v5
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v748 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8635__ssa_v5
        ;
        uint64_t v749 = (uint64_t) v43;
        TASSIGN(v748, v749);
        // pto: %buf_current_key_inline8632__ssa_v35
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v750 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8632__ssa_v35
        ;
        uint64_t v751 = (uint64_t) v43;
        TASSIGN(v750, v751);
        // pto: %379, %380
        ;
        int64_t v752 = (int64_t) ((uint64_t) v286 + (uint64_t) v53) / v66;
        // pto: %384
        ;
        int64_t v753 = v752 < v289 ? v752 : v289;
        // pto: %387, %385
        ;
        int32_t v754 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v753)];
        // pto: %388
        ;
        int64_t v755 = (int64_t) v754;
        // pto: %389
        ;
        int64_t v756 = v755 < v56 ? v56 : v755;
        // pto: %390
        ;
        int64_t v757 = (int64_t) ((uint64_t) v756 * (uint64_t) v16);
        // pto: %391, %392
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        if (v757 % v51 == v56) {
          // pto: %393
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v758;
          // pto: %393
          ;
          uint64_t v759 = (uint64_t) v45;
          TASSIGN(v758, v759);
          // pto: %394
          ;
          int64_t v760 = v757 / v51;
          // pto: %395
          ;
          int64_t v761 = v760 < v56 ? v56 : v760;
          // pto: %396
          ;
          __gm__ int8_t* v762 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %396
          ;
          const int64_t v763 = 0;
          // pto: %396
          ;
          const int64_t v764 = 128;
          // pto: %396
          ;
          pto::Shape<1, 1, 1, 32, 128> v765 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %396
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v766 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %396
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v767 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v762 + (v763 + v761 * v764), v765, v766);
          TLOAD(v758, v767);
        } else {
          // pto: %397
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v768;
          // pto: %397
          ;
          uint64_t v769 = (uint64_t) v45;
          TASSIGN(v768, v769);
          // pto: %398
          ;
          int64_t v770 = v757 / v51;
          // pto: %399
          ;
          int64_t v771 = v770 < v56 ? v56 : v770;
          // pto: %400
          ;
          __gm__ int8_t* v772 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %400
          ;
          const int64_t v773 = 0;
          // pto: %400
          ;
          const int64_t v774 = 128;
          // pto: %400
          ;
          pto::Shape<1, 1, 1, 32, 128> v775 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %400
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v776 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %400
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v777 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v772 + (v773 + v771 * v774), v775, v776);
          TLOAD(v768, v777);
        };
        // pto: %403, %404
        ;
        int64_t v778 = (int64_t) ((uint64_t) v286 + (uint64_t) v35) / v66;
        // pto: %408
        ;
        int64_t v779 = v778 < v289 ? v778 : v289;
        // pto: %411, %409
        ;
        int32_t v780 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v779)];
        // pto: %412
        ;
        int64_t v781 = (int64_t) v780;
        // pto: %413
        ;
        int64_t v782 = v781 < v56 ? v56 : v781;
        // pto: %414
        ;
        int64_t v783 = (int64_t) ((uint64_t) v782 * (uint64_t) v16);
        // pto: %415, %416
        ;
        if (v783 % v51 == v56) {
          // pto: %418
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v784;
          // pto: %418
          ;
          uint64_t v785 = (uint64_t) v42;
          TASSIGN(v784, v785);
          // pto: %419
          ;
          int64_t v786 = v783 / v51;
          // pto: %420
          ;
          int64_t v787 = v786 < v56 ? v56 : v786;
          // pto: %421
          ;
          __gm__ int8_t* v788 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %421
          ;
          const int64_t v789 = 0;
          // pto: %421
          ;
          const int64_t v790 = 128;
          // pto: %421
          ;
          pto::Shape<1, 1, 1, 32, 128> v791 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %421
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v792 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %421
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v793 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v788 + (v789 + v787 * v790), v791, v792);
          TLOAD(v784, v793);
        } else {
          // pto: %423
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v794;
          // pto: %423
          ;
          uint64_t v795 = (uint64_t) v42;
          TASSIGN(v794, v795);
          // pto: %424
          ;
          int64_t v796 = v783 / v51;
          // pto: %425
          ;
          int64_t v797 = v796 < v56 ? v56 : v796;
          // pto: %426
          ;
          __gm__ int8_t* v798 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %426
          ;
          const int64_t v799 = 0;
          // pto: %426
          ;
          const int64_t v800 = 128;
          // pto: %426
          ;
          pto::Shape<1, 1, 1, 32, 128> v801 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %426
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v802 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %426
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v803 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v798 + (v799 + v797 * v800), v801, v802);
          TLOAD(v794, v803);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v467
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v804 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v467
        ;
        uint64_t v805 = (uint64_t) v45;
        TASSIGN(v804, v805);
        // pto: %buf_prefetched_key_inline8631__ssa_v26
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v806 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8631__ssa_v26
        ;
        uint64_t v807 = (uint64_t) v47;
        TASSIGN(v806, v807);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v808 = static_cast<uint16_t>(v56);
        uint16_t v809 = static_cast<uint16_t>(v56);
        TEXTRACT(v806, v804, v808, v809);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline8777__ssa_v15
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v810 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8777__ssa_v15
        ;
        uint64_t v811 = (uint64_t) v43;
        TASSIGN(v810, v811);
        // pto: %buf_scores_l1_inline8697__ssa_v20
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v812 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8697__ssa_v20
        ;
        uint64_t v813 = (uint64_t) v44;
        TASSIGN(v812, v813);
        // pto: %buf_previous_pair_inline8693__ssa_v5
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v814 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8693__ssa_v5
        ;
        uint64_t v815 = (uint64_t) v46;
        TASSIGN(v814, v815);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID4);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v816 = static_cast<uint16_t>(v56);
        uint16_t v817 = static_cast<uint16_t>(v56);
        TEXTRACT(v814, v748, v816, v817);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        // pto: %buf_scores_inline8611__ssa_v15
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v818 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8611__ssa_v15
        ;
        uint64_t v819 = (uint64_t) v43;
        TASSIGN(v818, v819);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v818, v277, v810);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8798__ssa_v5
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v820 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8798__ssa_v5
        ;
        uint64_t v821 = (uint64_t) v48;
        TASSIGN(v820, v821);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v820, v279, v814);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v822 = static_cast<uint64_t>(v77);
        uint16_t v823 = static_cast<uint16_t>(v56);
        uint16_t v824 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v812, v818, v822, v823, v824);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID5);
        v820.SetValidShape(v65, v73);
        // pto: %430
        ;
        __gm__ float* v825 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %430
        ;
        const int64_t v826 = 256;
        // pto: %430
        ;
        const int64_t v827 = 1024;
        // pto: %430
        ;
        pto::Shape<1, 1, 1, 6, 64> v828 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %430
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v829 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %430
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v830 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v825 + (v826 + v492 * v827), v828, v829);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v830, v820);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8635__ssa_v6
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v831 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8635__ssa_v6
        ;
        uint64_t v832 = (uint64_t) v44;
        TASSIGN(v831, v832);
        // pto: %buf_current_key_inline8632__ssa_v42
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v833 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8632__ssa_v42
        ;
        uint64_t v834 = (uint64_t) v47;
        TASSIGN(v833, v834);
        // pto: %432, %433
        ;
        int64_t v835 = (int64_t) ((uint64_t) v286 + (uint64_t) v81) / v66;
        // pto: %437
        ;
        int64_t v836 = v835 < v289 ? v835 : v289;
        // pto: %440, %438
        ;
        int32_t v837 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v836)];
        // pto: %441
        ;
        int64_t v838 = (int64_t) v837;
        // pto: %442
        ;
        int64_t v839 = v838 < v56 ? v56 : v838;
        // pto: %443
        ;
        int64_t v840 = (int64_t) ((uint64_t) v839 * (uint64_t) v16);
        // pto: %444, %445
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v840 % v51 == v56) {
          // pto: %446
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v841;
          // pto: %446
          ;
          uint64_t v842 = (uint64_t) v41;
          TASSIGN(v841, v842);
          // pto: %447
          ;
          int64_t v843 = v840 / v51;
          // pto: %448
          ;
          int64_t v844 = v843 < v56 ? v56 : v843;
          // pto: %449
          ;
          __gm__ int8_t* v845 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %449
          ;
          const int64_t v846 = 0;
          // pto: %449
          ;
          const int64_t v847 = 128;
          // pto: %449
          ;
          pto::Shape<1, 1, 1, 32, 128> v848 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %449
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v849 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %449
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v850 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v845 + (v846 + v844 * v847), v848, v849);
          TLOAD(v841, v850);
        } else {
          // pto: %450
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v851;
          // pto: %450
          ;
          uint64_t v852 = (uint64_t) v41;
          TASSIGN(v851, v852);
          // pto: %451
          ;
          int64_t v853 = v840 / v51;
          // pto: %452
          ;
          int64_t v854 = v853 < v56 ? v56 : v853;
          // pto: %453
          ;
          __gm__ int8_t* v855 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %453
          ;
          const int64_t v856 = 0;
          // pto: %453
          ;
          const int64_t v857 = 128;
          // pto: %453
          ;
          pto::Shape<1, 1, 1, 32, 128> v858 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %453
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v859 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %453
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v860 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v855 + (v856 + v854 * v857), v858, v859);
          TLOAD(v851, v860);
        };
        // pto: %456, %457
        ;
        int64_t v861 = (int64_t) ((uint64_t) v286 + (uint64_t) v34) / v66;
        // pto: %461
        ;
        int64_t v862 = v861 < v289 ? v861 : v289;
        // pto: %464, %462
        ;
        int32_t v863 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v862)];
        // pto: %465
        ;
        int64_t v864 = (int64_t) v863;
        // pto: %466
        ;
        int64_t v865 = v864 < v56 ? v56 : v864;
        // pto: %467
        ;
        int64_t v866 = (int64_t) ((uint64_t) v865 * (uint64_t) v16);
        // pto: %468, %469
        ;
        if (v866 % v51 == v56) {
          // pto: %471
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v867;
          // pto: %471
          ;
          uint64_t v868 = (uint64_t) v39;
          TASSIGN(v867, v868);
          // pto: %472
          ;
          int64_t v869 = v866 / v51;
          // pto: %473
          ;
          int64_t v870 = v869 < v56 ? v56 : v869;
          // pto: %474
          ;
          __gm__ int8_t* v871 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %474
          ;
          const int64_t v872 = 0;
          // pto: %474
          ;
          const int64_t v873 = 128;
          // pto: %474
          ;
          pto::Shape<1, 1, 1, 32, 128> v874 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %474
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v875 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %474
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v876 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v871 + (v872 + v870 * v873), v874, v875);
          TLOAD(v867, v876);
        } else {
          // pto: %476
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v877;
          // pto: %476
          ;
          uint64_t v878 = (uint64_t) v39;
          TASSIGN(v877, v878);
          // pto: %477
          ;
          int64_t v879 = v866 / v51;
          // pto: %478
          ;
          int64_t v880 = v879 < v56 ? v56 : v879;
          // pto: %479
          ;
          __gm__ int8_t* v881 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %479
          ;
          const int64_t v882 = 0;
          // pto: %479
          ;
          const int64_t v883 = 128;
          // pto: %479
          ;
          pto::Shape<1, 1, 1, 32, 128> v884 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %479
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v885 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %479
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v886 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v881 + (v882 + v880 * v883), v884, v885);
          TLOAD(v877, v886);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v471
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v887 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v471
        ;
        uint64_t v888 = (uint64_t) v45;
        TASSIGN(v887, v888);
        // pto: %buf_prefetched_key_inline8631__ssa_v31
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v889 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8631__ssa_v31
        ;
        uint64_t v890 = (uint64_t) v43;
        TASSIGN(v889, v890);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v891 = static_cast<uint16_t>(v56);
        uint16_t v892 = static_cast<uint16_t>(v73);
        TEXTRACT(v889, v887, v891, v892);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline8777__ssa_v18
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v893 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8777__ssa_v18
        ;
        uint64_t v894 = (uint64_t) v47;
        TASSIGN(v893, v894);
        // pto: %buf_scores_l1_inline8697__ssa_v24
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v895 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8697__ssa_v24
        ;
        uint64_t v896 = (uint64_t) v43;
        TASSIGN(v895, v896);
        // pto: %buf_previous_pair_inline8693__ssa_v6
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v897 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8693__ssa_v6
        ;
        uint64_t v898 = (uint64_t) v46;
        TASSIGN(v897, v898);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v899 = static_cast<uint16_t>(v56);
        uint16_t v900 = static_cast<uint16_t>(v56);
        TEXTRACT(v897, v831, v899, v900);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        // pto: %buf_scores_inline8611__ssa_v18
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v901 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8611__ssa_v18
        ;
        uint64_t v902 = (uint64_t) v43;
        TASSIGN(v901, v902);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v901, v277, v893);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8798__ssa_v6
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v903 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8798__ssa_v6
        ;
        uint64_t v904 = (uint64_t) v48;
        TASSIGN(v903, v904);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v903, v279, v897);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v905 = static_cast<uint64_t>(v77);
        uint16_t v906 = static_cast<uint16_t>(v56);
        uint16_t v907 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v895, v901, v905, v906, v907);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID6);
        v903.SetValidShape(v65, v73);
        // pto: %483
        ;
        __gm__ float* v908 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %483
        ;
        const int64_t v909 = 320;
        // pto: %483
        ;
        const int64_t v910 = 1024;
        // pto: %483
        ;
        pto::Shape<1, 1, 1, 6, 64> v911 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %483
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v912 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %483
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v913 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v908 + (v909 + v492 * v910), v911, v912);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v913, v903);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8635__ssa_v7
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v914 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8635__ssa_v7
        ;
        uint64_t v915 = (uint64_t) v43;
        TASSIGN(v914, v915);
        // pto: %buf_current_key_inline8632__ssa_v49
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v916 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8632__ssa_v49
        ;
        uint64_t v917 = (uint64_t) v43;
        TASSIGN(v916, v917);
        // pto: %485, %486
        ;
        int64_t v918 = (int64_t) ((uint64_t) v286 + (uint64_t) v70) / v66;
        // pto: %490
        ;
        int64_t v919 = v918 < v289 ? v918 : v289;
        // pto: %493, %491
        ;
        int32_t v920 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v919)];
        // pto: %494
        ;
        int64_t v921 = (int64_t) v920;
        // pto: %495
        ;
        int64_t v922 = v921 < v56 ? v56 : v921;
        // pto: %496
        ;
        int64_t v923 = (int64_t) ((uint64_t) v922 * (uint64_t) v16);
        // pto: %497, %498
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v923 % v51 == v56) {
          // pto: %499
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v924;
          // pto: %499
          ;
          uint64_t v925 = (uint64_t) v45;
          TASSIGN(v924, v925);
          // pto: %500
          ;
          int64_t v926 = v923 / v51;
          // pto: %501
          ;
          int64_t v927 = v926 < v56 ? v56 : v926;
          // pto: %502
          ;
          __gm__ int8_t* v928 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %502
          ;
          const int64_t v929 = 0;
          // pto: %502
          ;
          const int64_t v930 = 128;
          // pto: %502
          ;
          pto::Shape<1, 1, 1, 32, 128> v931 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %502
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v932 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %502
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v933 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v928 + (v929 + v927 * v930), v931, v932);
          TLOAD(v924, v933);
        } else {
          // pto: %503
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v934;
          // pto: %503
          ;
          uint64_t v935 = (uint64_t) v45;
          TASSIGN(v934, v935);
          // pto: %504
          ;
          int64_t v936 = v923 / v51;
          // pto: %505
          ;
          int64_t v937 = v936 < v56 ? v56 : v936;
          // pto: %506
          ;
          __gm__ int8_t* v938 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %506
          ;
          const int64_t v939 = 0;
          // pto: %506
          ;
          const int64_t v940 = 128;
          // pto: %506
          ;
          pto::Shape<1, 1, 1, 32, 128> v941 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %506
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v942 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %506
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v943 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v938 + (v939 + v937 * v940), v941, v942);
          TLOAD(v934, v943);
        };
        // pto: %509, %510
        ;
        int64_t v944 = (int64_t) ((uint64_t) v286 + (uint64_t) v33) / v66;
        // pto: %514
        ;
        int64_t v945 = v944 < v289 ? v944 : v289;
        // pto: %517, %515
        ;
        int32_t v946 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v945)];
        // pto: %518
        ;
        int64_t v947 = (int64_t) v946;
        // pto: %519
        ;
        int64_t v948 = v947 < v56 ? v56 : v947;
        // pto: %520
        ;
        int64_t v949 = (int64_t) ((uint64_t) v948 * (uint64_t) v16);
        // pto: %521, %522
        ;
        if (v949 % v51 == v56) {
          // pto: %524
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v950;
          // pto: %524
          ;
          uint64_t v951 = (uint64_t) v42;
          TASSIGN(v950, v951);
          // pto: %525
          ;
          int64_t v952 = v949 / v51;
          // pto: %526
          ;
          int64_t v953 = v952 < v56 ? v56 : v952;
          // pto: %527
          ;
          __gm__ int8_t* v954 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %527
          ;
          const int64_t v955 = 0;
          // pto: %527
          ;
          const int64_t v956 = 128;
          // pto: %527
          ;
          pto::Shape<1, 1, 1, 32, 128> v957 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %527
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v958 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %527
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v959 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v954 + (v955 + v953 * v956), v957, v958);
          TLOAD(v950, v959);
        } else {
          // pto: %529
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v960;
          // pto: %529
          ;
          uint64_t v961 = (uint64_t) v42;
          TASSIGN(v960, v961);
          // pto: %530
          ;
          int64_t v962 = v949 / v51;
          // pto: %531
          ;
          int64_t v963 = v962 < v56 ? v56 : v962;
          // pto: %532
          ;
          __gm__ int8_t* v964 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %532
          ;
          const int64_t v965 = 0;
          // pto: %532
          ;
          const int64_t v966 = 128;
          // pto: %532
          ;
          pto::Shape<1, 1, 1, 32, 128> v967 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %532
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v968 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %532
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v969 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v964 + (v965 + v963 * v966), v967, v968);
          TLOAD(v960, v969);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v475
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v970 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v475
        ;
        uint64_t v971 = (uint64_t) v45;
        TASSIGN(v970, v971);
        // pto: %buf_prefetched_key_inline8631__ssa_v36
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v972 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8631__ssa_v36
        ;
        uint64_t v973 = (uint64_t) v47;
        TASSIGN(v972, v973);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v974 = static_cast<uint16_t>(v56);
        uint16_t v975 = static_cast<uint16_t>(v56);
        TEXTRACT(v972, v970, v974, v975);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline8777__ssa_v21
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v976 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8777__ssa_v21
        ;
        uint64_t v977 = (uint64_t) v43;
        TASSIGN(v976, v977);
        // pto: %buf_scores_l1_inline8697__ssa_v28
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v978 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8697__ssa_v28
        ;
        uint64_t v979 = (uint64_t) v44;
        TASSIGN(v978, v979);
        // pto: %buf_previous_pair_inline8693__ssa_v7
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v980 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8693__ssa_v7
        ;
        uint64_t v981 = (uint64_t) v46;
        TASSIGN(v980, v981);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID6);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v982 = static_cast<uint16_t>(v56);
        uint16_t v983 = static_cast<uint16_t>(v56);
        TEXTRACT(v980, v914, v982, v983);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline8611__ssa_v21
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v984 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8611__ssa_v21
        ;
        uint64_t v985 = (uint64_t) v43;
        TASSIGN(v984, v985);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v984, v277, v976);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8798__ssa_v7
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v986 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8798__ssa_v7
        ;
        uint64_t v987 = (uint64_t) v48;
        TASSIGN(v986, v987);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v986, v279, v980);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v988 = static_cast<uint64_t>(v77);
        uint16_t v989 = static_cast<uint16_t>(v56);
        uint16_t v990 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v978, v984, v988, v989, v990);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID7);
        v986.SetValidShape(v65, v73);
        // pto: %536
        ;
        __gm__ float* v991 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %536
        ;
        const int64_t v992 = 384;
        // pto: %536
        ;
        const int64_t v993 = 1024;
        // pto: %536
        ;
        pto::Shape<1, 1, 1, 6, 64> v994 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %536
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v995 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %536
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v996 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v991 + (v992 + v492 * v993), v994, v995);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v996, v986);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8635__ssa_v8
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v997 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8635__ssa_v8
        ;
        uint64_t v998 = (uint64_t) v44;
        TASSIGN(v997, v998);
        // pto: %buf_current_key_inline8632__ssa_v56
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v999 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8632__ssa_v56
        ;
        uint64_t v1000 = (uint64_t) v47;
        TASSIGN(v999, v1000);
        // pto: %538, %539
        ;
        int64_t v1001 = (int64_t) ((uint64_t) v286 + (uint64_t) v82) / v66;
        // pto: %543
        ;
        int64_t v1002 = v1001 < v289 ? v1001 : v289;
        // pto: %546, %544
        ;
        int32_t v1003 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v1002)];
        // pto: %547
        ;
        int64_t v1004 = (int64_t) v1003;
        // pto: %548
        ;
        int64_t v1005 = v1004 < v56 ? v56 : v1004;
        // pto: %549
        ;
        int64_t v1006 = (int64_t) ((uint64_t) v1005 * (uint64_t) v16);
        // pto: %550, %551
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v1006 % v51 == v56) {
          // pto: %552
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1007;
          // pto: %552
          ;
          uint64_t v1008 = (uint64_t) v41;
          TASSIGN(v1007, v1008);
          // pto: %553
          ;
          int64_t v1009 = v1006 / v51;
          // pto: %554
          ;
          int64_t v1010 = v1009 < v56 ? v56 : v1009;
          // pto: %555
          ;
          __gm__ int8_t* v1011 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %555
          ;
          const int64_t v1012 = 0;
          // pto: %555
          ;
          const int64_t v1013 = 128;
          // pto: %555
          ;
          pto::Shape<1, 1, 1, 32, 128> v1014 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %555
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1015 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %555
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1016 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1011 + (v1012 + v1010 * v1013), v1014, v1015);
          TLOAD(v1007, v1016);
        } else {
          // pto: %556
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1017;
          // pto: %556
          ;
          uint64_t v1018 = (uint64_t) v41;
          TASSIGN(v1017, v1018);
          // pto: %557
          ;
          int64_t v1019 = v1006 / v51;
          // pto: %558
          ;
          int64_t v1020 = v1019 < v56 ? v56 : v1019;
          // pto: %559
          ;
          __gm__ int8_t* v1021 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %559
          ;
          const int64_t v1022 = 0;
          // pto: %559
          ;
          const int64_t v1023 = 128;
          // pto: %559
          ;
          pto::Shape<1, 1, 1, 32, 128> v1024 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %559
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1025 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %559
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1026 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1021 + (v1022 + v1020 * v1023), v1024, v1025);
          TLOAD(v1017, v1026);
        };
        // pto: %562, %563
        ;
        int64_t v1027 = (int64_t) ((uint64_t) v286 + (uint64_t) v32) / v66;
        // pto: %567
        ;
        int64_t v1028 = v1027 < v289 ? v1027 : v289;
        // pto: %570, %568
        ;
        int32_t v1029 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v1028)];
        // pto: %571
        ;
        int64_t v1030 = (int64_t) v1029;
        // pto: %572
        ;
        int64_t v1031 = v1030 < v56 ? v56 : v1030;
        // pto: %573
        ;
        int64_t v1032 = (int64_t) ((uint64_t) v1031 * (uint64_t) v16);
        // pto: %574, %575
        ;
        if (v1032 % v51 == v56) {
          // pto: %577
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1033;
          // pto: %577
          ;
          uint64_t v1034 = (uint64_t) v39;
          TASSIGN(v1033, v1034);
          // pto: %578
          ;
          int64_t v1035 = v1032 / v51;
          // pto: %579
          ;
          int64_t v1036 = v1035 < v56 ? v56 : v1035;
          // pto: %580
          ;
          __gm__ int8_t* v1037 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %580
          ;
          const int64_t v1038 = 0;
          // pto: %580
          ;
          const int64_t v1039 = 128;
          // pto: %580
          ;
          pto::Shape<1, 1, 1, 32, 128> v1040 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %580
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1041 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %580
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1042 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1037 + (v1038 + v1036 * v1039), v1040, v1041);
          TLOAD(v1033, v1042);
        } else {
          // pto: %582
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1043;
          // pto: %582
          ;
          uint64_t v1044 = (uint64_t) v39;
          TASSIGN(v1043, v1044);
          // pto: %583
          ;
          int64_t v1045 = v1032 / v51;
          // pto: %584
          ;
          int64_t v1046 = v1045 < v56 ? v56 : v1045;
          // pto: %585
          ;
          __gm__ int8_t* v1047 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %585
          ;
          const int64_t v1048 = 0;
          // pto: %585
          ;
          const int64_t v1049 = 128;
          // pto: %585
          ;
          pto::Shape<1, 1, 1, 32, 128> v1050 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %585
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1051 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %585
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1052 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1047 + (v1048 + v1046 * v1049), v1050, v1051);
          TLOAD(v1043, v1052);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v479
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1053 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v479
        ;
        uint64_t v1054 = (uint64_t) v45;
        TASSIGN(v1053, v1054);
        // pto: %buf_prefetched_key_inline8631__ssa_v41
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1055 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8631__ssa_v41
        ;
        uint64_t v1056 = (uint64_t) v43;
        TASSIGN(v1055, v1056);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1057 = static_cast<uint16_t>(v56);
        uint16_t v1058 = static_cast<uint16_t>(v73);
        TEXTRACT(v1055, v1053, v1057, v1058);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline8777__ssa_v24
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1059 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8777__ssa_v24
        ;
        uint64_t v1060 = (uint64_t) v47;
        TASSIGN(v1059, v1060);
        // pto: %buf_scores_l1_inline8697__ssa_v32
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1061 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8697__ssa_v32
        ;
        uint64_t v1062 = (uint64_t) v43;
        TASSIGN(v1061, v1062);
        // pto: %buf_previous_pair_inline8693__ssa_v8
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1063 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8693__ssa_v8
        ;
        uint64_t v1064 = (uint64_t) v46;
        TASSIGN(v1063, v1064);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID7);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1065 = static_cast<uint16_t>(v56);
        uint16_t v1066 = static_cast<uint16_t>(v56);
        TEXTRACT(v1063, v997, v1065, v1066);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline8611__ssa_v24
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1067 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8611__ssa_v24
        ;
        uint64_t v1068 = (uint64_t) v43;
        TASSIGN(v1067, v1068);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1067, v277, v1059);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8798__ssa_v8
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1069 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8798__ssa_v8
        ;
        uint64_t v1070 = (uint64_t) v48;
        TASSIGN(v1069, v1070);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1069, v279, v1063);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1071 = static_cast<uint64_t>(v77);
        uint16_t v1072 = static_cast<uint16_t>(v56);
        uint16_t v1073 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1061, v1067, v1071, v1072, v1073);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1069.SetValidShape(v65, v73);
        // pto: %589
        ;
        __gm__ float* v1074 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %589
        ;
        const int64_t v1075 = 448;
        // pto: %589
        ;
        const int64_t v1076 = 1024;
        // pto: %589
        ;
        pto::Shape<1, 1, 1, 6, 64> v1077 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %589
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1078 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %589
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1079 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1074 + (v1075 + v492 * v1076), v1077, v1078);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1079, v1069);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8635__ssa_v9
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1080 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8635__ssa_v9
        ;
        uint64_t v1081 = (uint64_t) v43;
        TASSIGN(v1080, v1081);
        // pto: %buf_current_key_inline8632__ssa_v63
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1082 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8632__ssa_v63
        ;
        uint64_t v1083 = (uint64_t) v43;
        TASSIGN(v1082, v1083);
        // pto: %591, %592
        ;
        int64_t v1084 = (int64_t) ((uint64_t) v286 + (uint64_t) v83) / v66;
        // pto: %596
        ;
        int64_t v1085 = v1084 < v289 ? v1084 : v289;
        // pto: %599, %597
        ;
        int32_t v1086 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v1085)];
        // pto: %600
        ;
        int64_t v1087 = (int64_t) v1086;
        // pto: %601
        ;
        int64_t v1088 = v1087 < v56 ? v56 : v1087;
        // pto: %602
        ;
        int64_t v1089 = (int64_t) ((uint64_t) v1088 * (uint64_t) v16);
        // pto: %603, %604
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v1089 % v51 == v56) {
          // pto: %605
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1090;
          // pto: %605
          ;
          uint64_t v1091 = (uint64_t) v45;
          TASSIGN(v1090, v1091);
          // pto: %606
          ;
          int64_t v1092 = v1089 / v51;
          // pto: %607
          ;
          int64_t v1093 = v1092 < v56 ? v56 : v1092;
          // pto: %608
          ;
          __gm__ int8_t* v1094 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %608
          ;
          const int64_t v1095 = 0;
          // pto: %608
          ;
          const int64_t v1096 = 128;
          // pto: %608
          ;
          pto::Shape<1, 1, 1, 32, 128> v1097 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %608
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1098 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %608
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1099 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1094 + (v1095 + v1093 * v1096), v1097, v1098);
          TLOAD(v1090, v1099);
        } else {
          // pto: %609
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1100;
          // pto: %609
          ;
          uint64_t v1101 = (uint64_t) v45;
          TASSIGN(v1100, v1101);
          // pto: %610
          ;
          int64_t v1102 = v1089 / v51;
          // pto: %611
          ;
          int64_t v1103 = v1102 < v56 ? v56 : v1102;
          // pto: %612
          ;
          __gm__ int8_t* v1104 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %612
          ;
          const int64_t v1105 = 0;
          // pto: %612
          ;
          const int64_t v1106 = 128;
          // pto: %612
          ;
          pto::Shape<1, 1, 1, 32, 128> v1107 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %612
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1108 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %612
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1109 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1104 + (v1105 + v1103 * v1106), v1107, v1108);
          TLOAD(v1100, v1109);
        };
        // pto: %615, %616
        ;
        int64_t v1110 = (int64_t) ((uint64_t) v286 + (uint64_t) v31) / v66;
        // pto: %620
        ;
        int64_t v1111 = v1110 < v289 ? v1110 : v289;
        // pto: %623, %621
        ;
        int32_t v1112 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v1111)];
        // pto: %624
        ;
        int64_t v1113 = (int64_t) v1112;
        // pto: %625
        ;
        int64_t v1114 = v1113 < v56 ? v56 : v1113;
        // pto: %626
        ;
        int64_t v1115 = (int64_t) ((uint64_t) v1114 * (uint64_t) v16);
        // pto: %627, %628
        ;
        if (v1115 % v51 == v56) {
          // pto: %630
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1116;
          // pto: %630
          ;
          uint64_t v1117 = (uint64_t) v42;
          TASSIGN(v1116, v1117);
          // pto: %631
          ;
          int64_t v1118 = v1115 / v51;
          // pto: %632
          ;
          int64_t v1119 = v1118 < v56 ? v56 : v1118;
          // pto: %633
          ;
          __gm__ int8_t* v1120 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %633
          ;
          const int64_t v1121 = 0;
          // pto: %633
          ;
          const int64_t v1122 = 128;
          // pto: %633
          ;
          pto::Shape<1, 1, 1, 32, 128> v1123 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %633
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1124 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %633
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1125 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1120 + (v1121 + v1119 * v1122), v1123, v1124);
          TLOAD(v1116, v1125);
        } else {
          // pto: %635
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1126;
          // pto: %635
          ;
          uint64_t v1127 = (uint64_t) v42;
          TASSIGN(v1126, v1127);
          // pto: %636
          ;
          int64_t v1128 = v1115 / v51;
          // pto: %637
          ;
          int64_t v1129 = v1128 < v56 ? v56 : v1128;
          // pto: %638
          ;
          __gm__ int8_t* v1130 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %638
          ;
          const int64_t v1131 = 0;
          // pto: %638
          ;
          const int64_t v1132 = 128;
          // pto: %638
          ;
          pto::Shape<1, 1, 1, 32, 128> v1133 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %638
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1134 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %638
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1135 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1130 + (v1131 + v1129 * v1132), v1133, v1134);
          TLOAD(v1126, v1135);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v483
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1136 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v483
        ;
        uint64_t v1137 = (uint64_t) v45;
        TASSIGN(v1136, v1137);
        // pto: %buf_prefetched_key_inline8631__ssa_v46
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1138 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8631__ssa_v46
        ;
        uint64_t v1139 = (uint64_t) v47;
        TASSIGN(v1138, v1139);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1140 = static_cast<uint16_t>(v56);
        uint16_t v1141 = static_cast<uint16_t>(v56);
        TEXTRACT(v1138, v1136, v1140, v1141);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline8777__ssa_v27
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1142 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8777__ssa_v27
        ;
        uint64_t v1143 = (uint64_t) v43;
        TASSIGN(v1142, v1143);
        // pto: %buf_scores_l1_inline8697__ssa_v36
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1144 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8697__ssa_v36
        ;
        uint64_t v1145 = (uint64_t) v44;
        TASSIGN(v1144, v1145);
        // pto: %buf_previous_pair_inline8693__ssa_v9
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1146 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8693__ssa_v9
        ;
        uint64_t v1147 = (uint64_t) v46;
        TASSIGN(v1146, v1147);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1148 = static_cast<uint16_t>(v56);
        uint16_t v1149 = static_cast<uint16_t>(v56);
        TEXTRACT(v1146, v1080, v1148, v1149);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline8611__ssa_v27
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1150 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8611__ssa_v27
        ;
        uint64_t v1151 = (uint64_t) v43;
        TASSIGN(v1150, v1151);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1150, v277, v1142);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8798__ssa_v9
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1152 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8798__ssa_v9
        ;
        uint64_t v1153 = (uint64_t) v48;
        TASSIGN(v1152, v1153);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1152, v279, v1146);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1154 = static_cast<uint64_t>(v77);
        uint16_t v1155 = static_cast<uint16_t>(v56);
        uint16_t v1156 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1144, v1150, v1154, v1155, v1156);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1152.SetValidShape(v65, v73);
        // pto: %642
        ;
        __gm__ float* v1157 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %642
        ;
        const int64_t v1158 = 512;
        // pto: %642
        ;
        const int64_t v1159 = 1024;
        // pto: %642
        ;
        pto::Shape<1, 1, 1, 6, 64> v1160 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %642
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1161 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %642
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1162 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1157 + (v1158 + v492 * v1159), v1160, v1161);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1162, v1152);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8635__ssa_v10
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1163 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8635__ssa_v10
        ;
        uint64_t v1164 = (uint64_t) v44;
        TASSIGN(v1163, v1164);
        // pto: %buf_current_key_inline8632__ssa_v70
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1165 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8632__ssa_v70
        ;
        uint64_t v1166 = (uint64_t) v47;
        TASSIGN(v1165, v1166);
        // pto: %644, %645
        ;
        int64_t v1167 = (int64_t) ((uint64_t) v286 + (uint64_t) v84) / v66;
        // pto: %649
        ;
        int64_t v1168 = v1167 < v289 ? v1167 : v289;
        // pto: %652, %650
        ;
        int32_t v1169 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v1168)];
        // pto: %653
        ;
        int64_t v1170 = (int64_t) v1169;
        // pto: %654
        ;
        int64_t v1171 = v1170 < v56 ? v56 : v1170;
        // pto: %655
        ;
        int64_t v1172 = (int64_t) ((uint64_t) v1171 * (uint64_t) v16);
        // pto: %656, %657
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v1172 % v51 == v56) {
          // pto: %658
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1173;
          // pto: %658
          ;
          uint64_t v1174 = (uint64_t) v41;
          TASSIGN(v1173, v1174);
          // pto: %659
          ;
          int64_t v1175 = v1172 / v51;
          // pto: %660
          ;
          int64_t v1176 = v1175 < v56 ? v56 : v1175;
          // pto: %661
          ;
          __gm__ int8_t* v1177 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %661
          ;
          const int64_t v1178 = 0;
          // pto: %661
          ;
          const int64_t v1179 = 128;
          // pto: %661
          ;
          pto::Shape<1, 1, 1, 32, 128> v1180 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %661
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1181 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %661
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1182 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1177 + (v1178 + v1176 * v1179), v1180, v1181);
          TLOAD(v1173, v1182);
        } else {
          // pto: %662
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1183;
          // pto: %662
          ;
          uint64_t v1184 = (uint64_t) v41;
          TASSIGN(v1183, v1184);
          // pto: %663
          ;
          int64_t v1185 = v1172 / v51;
          // pto: %664
          ;
          int64_t v1186 = v1185 < v56 ? v56 : v1185;
          // pto: %665
          ;
          __gm__ int8_t* v1187 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %665
          ;
          const int64_t v1188 = 0;
          // pto: %665
          ;
          const int64_t v1189 = 128;
          // pto: %665
          ;
          pto::Shape<1, 1, 1, 32, 128> v1190 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %665
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1191 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %665
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1192 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1187 + (v1188 + v1186 * v1189), v1190, v1191);
          TLOAD(v1183, v1192);
        };
        // pto: %668, %669
        ;
        int64_t v1193 = (int64_t) ((uint64_t) v286 + (uint64_t) v30) / v66;
        // pto: %673
        ;
        int64_t v1194 = v1193 < v289 ? v1193 : v289;
        // pto: %676, %674
        ;
        int32_t v1195 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v1194)];
        // pto: %677
        ;
        int64_t v1196 = (int64_t) v1195;
        // pto: %678
        ;
        int64_t v1197 = v1196 < v56 ? v56 : v1196;
        // pto: %679
        ;
        int64_t v1198 = (int64_t) ((uint64_t) v1197 * (uint64_t) v16);
        // pto: %680, %681
        ;
        if (v1198 % v51 == v56) {
          // pto: %683
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1199;
          // pto: %683
          ;
          uint64_t v1200 = (uint64_t) v39;
          TASSIGN(v1199, v1200);
          // pto: %684
          ;
          int64_t v1201 = v1198 / v51;
          // pto: %685
          ;
          int64_t v1202 = v1201 < v56 ? v56 : v1201;
          // pto: %686
          ;
          __gm__ int8_t* v1203 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %686
          ;
          const int64_t v1204 = 0;
          // pto: %686
          ;
          const int64_t v1205 = 128;
          // pto: %686
          ;
          pto::Shape<1, 1, 1, 32, 128> v1206 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %686
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1207 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %686
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1208 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1203 + (v1204 + v1202 * v1205), v1206, v1207);
          TLOAD(v1199, v1208);
        } else {
          // pto: %688
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1209;
          // pto: %688
          ;
          uint64_t v1210 = (uint64_t) v39;
          TASSIGN(v1209, v1210);
          // pto: %689
          ;
          int64_t v1211 = v1198 / v51;
          // pto: %690
          ;
          int64_t v1212 = v1211 < v56 ? v56 : v1211;
          // pto: %691
          ;
          __gm__ int8_t* v1213 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %691
          ;
          const int64_t v1214 = 0;
          // pto: %691
          ;
          const int64_t v1215 = 128;
          // pto: %691
          ;
          pto::Shape<1, 1, 1, 32, 128> v1216 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %691
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1217 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %691
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1218 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1213 + (v1214 + v1212 * v1215), v1216, v1217);
          TLOAD(v1209, v1218);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v487
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1219 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v487
        ;
        uint64_t v1220 = (uint64_t) v45;
        TASSIGN(v1219, v1220);
        // pto: %buf_prefetched_key_inline8631__ssa_v51
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1221 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8631__ssa_v51
        ;
        uint64_t v1222 = (uint64_t) v43;
        TASSIGN(v1221, v1222);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1223 = static_cast<uint16_t>(v56);
        uint16_t v1224 = static_cast<uint16_t>(v73);
        TEXTRACT(v1221, v1219, v1223, v1224);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline8777__ssa_v30
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1225 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8777__ssa_v30
        ;
        uint64_t v1226 = (uint64_t) v47;
        TASSIGN(v1225, v1226);
        // pto: %buf_scores_l1_inline8697__ssa_v40
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1227 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8697__ssa_v40
        ;
        uint64_t v1228 = (uint64_t) v43;
        TASSIGN(v1227, v1228);
        // pto: %buf_previous_pair_inline8693__ssa_v10
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1229 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8693__ssa_v10
        ;
        uint64_t v1230 = (uint64_t) v46;
        TASSIGN(v1229, v1230);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1231 = static_cast<uint16_t>(v56);
        uint16_t v1232 = static_cast<uint16_t>(v56);
        TEXTRACT(v1229, v1163, v1231, v1232);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline8611__ssa_v30
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1233 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8611__ssa_v30
        ;
        uint64_t v1234 = (uint64_t) v43;
        TASSIGN(v1233, v1234);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1233, v277, v1225);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8798__ssa_v10
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1235 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8798__ssa_v10
        ;
        uint64_t v1236 = (uint64_t) v48;
        TASSIGN(v1235, v1236);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1235, v279, v1229);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1237 = static_cast<uint64_t>(v77);
        uint16_t v1238 = static_cast<uint16_t>(v56);
        uint16_t v1239 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1227, v1233, v1237, v1238, v1239);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1235.SetValidShape(v65, v73);
        // pto: %695
        ;
        __gm__ float* v1240 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %695
        ;
        const int64_t v1241 = 576;
        // pto: %695
        ;
        const int64_t v1242 = 1024;
        // pto: %695
        ;
        pto::Shape<1, 1, 1, 6, 64> v1243 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %695
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1244 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %695
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1245 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1240 + (v1241 + v492 * v1242), v1243, v1244);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1245, v1235);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8635__ssa_v11
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1246 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8635__ssa_v11
        ;
        uint64_t v1247 = (uint64_t) v43;
        TASSIGN(v1246, v1247);
        // pto: %buf_current_key_inline8632__ssa_v77
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1248 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8632__ssa_v77
        ;
        uint64_t v1249 = (uint64_t) v43;
        TASSIGN(v1248, v1249);
        // pto: %697, %698
        ;
        int64_t v1250 = (int64_t) ((uint64_t) v286 + (uint64_t) v85) / v66;
        // pto: %702
        ;
        int64_t v1251 = v1250 < v289 ? v1250 : v289;
        // pto: %705, %703
        ;
        int32_t v1252 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v1251)];
        // pto: %706
        ;
        int64_t v1253 = (int64_t) v1252;
        // pto: %707
        ;
        int64_t v1254 = v1253 < v56 ? v56 : v1253;
        // pto: %708
        ;
        int64_t v1255 = (int64_t) ((uint64_t) v1254 * (uint64_t) v16);
        // pto: %709, %710
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v1255 % v51 == v56) {
          // pto: %711
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1256;
          // pto: %711
          ;
          uint64_t v1257 = (uint64_t) v45;
          TASSIGN(v1256, v1257);
          // pto: %712
          ;
          int64_t v1258 = v1255 / v51;
          // pto: %713
          ;
          int64_t v1259 = v1258 < v56 ? v56 : v1258;
          // pto: %714
          ;
          __gm__ int8_t* v1260 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %714
          ;
          const int64_t v1261 = 0;
          // pto: %714
          ;
          const int64_t v1262 = 128;
          // pto: %714
          ;
          pto::Shape<1, 1, 1, 32, 128> v1263 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %714
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1264 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %714
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1265 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1260 + (v1261 + v1259 * v1262), v1263, v1264);
          TLOAD(v1256, v1265);
        } else {
          // pto: %715
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1266;
          // pto: %715
          ;
          uint64_t v1267 = (uint64_t) v45;
          TASSIGN(v1266, v1267);
          // pto: %716
          ;
          int64_t v1268 = v1255 / v51;
          // pto: %717
          ;
          int64_t v1269 = v1268 < v56 ? v56 : v1268;
          // pto: %718
          ;
          __gm__ int8_t* v1270 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %718
          ;
          const int64_t v1271 = 0;
          // pto: %718
          ;
          const int64_t v1272 = 128;
          // pto: %718
          ;
          pto::Shape<1, 1, 1, 32, 128> v1273 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %718
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1274 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %718
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1275 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1270 + (v1271 + v1269 * v1272), v1273, v1274);
          TLOAD(v1266, v1275);
        };
        // pto: %721, %722
        ;
        int64_t v1276 = (int64_t) ((uint64_t) v286 + (uint64_t) v29) / v66;
        // pto: %726
        ;
        int64_t v1277 = v1276 < v289 ? v1276 : v289;
        // pto: %729, %727
        ;
        int32_t v1278 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v1277)];
        // pto: %730
        ;
        int64_t v1279 = (int64_t) v1278;
        // pto: %731
        ;
        int64_t v1280 = v1279 < v56 ? v56 : v1279;
        // pto: %732
        ;
        int64_t v1281 = (int64_t) ((uint64_t) v1280 * (uint64_t) v16);
        // pto: %733, %734
        ;
        if (v1281 % v51 == v56) {
          // pto: %736
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1282;
          // pto: %736
          ;
          uint64_t v1283 = (uint64_t) v42;
          TASSIGN(v1282, v1283);
          // pto: %737
          ;
          int64_t v1284 = v1281 / v51;
          // pto: %738
          ;
          int64_t v1285 = v1284 < v56 ? v56 : v1284;
          // pto: %739
          ;
          __gm__ int8_t* v1286 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %739
          ;
          const int64_t v1287 = 0;
          // pto: %739
          ;
          const int64_t v1288 = 128;
          // pto: %739
          ;
          pto::Shape<1, 1, 1, 32, 128> v1289 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %739
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1290 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %739
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1291 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1286 + (v1287 + v1285 * v1288), v1289, v1290);
          TLOAD(v1282, v1291);
        } else {
          // pto: %741
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1292;
          // pto: %741
          ;
          uint64_t v1293 = (uint64_t) v42;
          TASSIGN(v1292, v1293);
          // pto: %742
          ;
          int64_t v1294 = v1281 / v51;
          // pto: %743
          ;
          int64_t v1295 = v1294 < v56 ? v56 : v1294;
          // pto: %744
          ;
          __gm__ int8_t* v1296 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %744
          ;
          const int64_t v1297 = 0;
          // pto: %744
          ;
          const int64_t v1298 = 128;
          // pto: %744
          ;
          pto::Shape<1, 1, 1, 32, 128> v1299 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %744
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1300 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %744
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1301 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1296 + (v1297 + v1295 * v1298), v1299, v1300);
          TLOAD(v1292, v1301);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v491
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1302 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v491
        ;
        uint64_t v1303 = (uint64_t) v45;
        TASSIGN(v1302, v1303);
        // pto: %buf_prefetched_key_inline8631__ssa_v56
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1304 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8631__ssa_v56
        ;
        uint64_t v1305 = (uint64_t) v47;
        TASSIGN(v1304, v1305);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1306 = static_cast<uint16_t>(v56);
        uint16_t v1307 = static_cast<uint16_t>(v56);
        TEXTRACT(v1304, v1302, v1306, v1307);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline8777__ssa_v33
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1308 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8777__ssa_v33
        ;
        uint64_t v1309 = (uint64_t) v43;
        TASSIGN(v1308, v1309);
        // pto: %buf_scores_l1_inline8697__ssa_v44
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1310 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8697__ssa_v44
        ;
        uint64_t v1311 = (uint64_t) v44;
        TASSIGN(v1310, v1311);
        // pto: %buf_previous_pair_inline8693__ssa_v11
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1312 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8693__ssa_v11
        ;
        uint64_t v1313 = (uint64_t) v46;
        TASSIGN(v1312, v1313);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1314 = static_cast<uint16_t>(v56);
        uint16_t v1315 = static_cast<uint16_t>(v56);
        TEXTRACT(v1312, v1246, v1314, v1315);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline8611__ssa_v33
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1316 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8611__ssa_v33
        ;
        uint64_t v1317 = (uint64_t) v43;
        TASSIGN(v1316, v1317);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1316, v277, v1308);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8798__ssa_v11
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1318 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8798__ssa_v11
        ;
        uint64_t v1319 = (uint64_t) v48;
        TASSIGN(v1318, v1319);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1318, v279, v1312);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1320 = static_cast<uint64_t>(v77);
        uint16_t v1321 = static_cast<uint16_t>(v56);
        uint16_t v1322 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1310, v1316, v1320, v1321, v1322);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1318.SetValidShape(v65, v73);
        // pto: %748
        ;
        __gm__ float* v1323 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %748
        ;
        const int64_t v1324 = 640;
        // pto: %748
        ;
        const int64_t v1325 = 1024;
        // pto: %748
        ;
        pto::Shape<1, 1, 1, 6, 64> v1326 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %748
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1327 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %748
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1328 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1323 + (v1324 + v492 * v1325), v1326, v1327);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1328, v1318);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8635__ssa_v12
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1329 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8635__ssa_v12
        ;
        uint64_t v1330 = (uint64_t) v44;
        TASSIGN(v1329, v1330);
        // pto: %buf_current_key_inline8632__ssa_v84
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1331 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8632__ssa_v84
        ;
        uint64_t v1332 = (uint64_t) v47;
        TASSIGN(v1331, v1332);
        // pto: %750, %751
        ;
        int64_t v1333 = (int64_t) ((uint64_t) v286 + (uint64_t) v86) / v66;
        // pto: %755
        ;
        int64_t v1334 = v1333 < v289 ? v1333 : v289;
        // pto: %758, %756
        ;
        int32_t v1335 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v1334)];
        // pto: %759
        ;
        int64_t v1336 = (int64_t) v1335;
        // pto: %760
        ;
        int64_t v1337 = v1336 < v56 ? v56 : v1336;
        // pto: %761
        ;
        int64_t v1338 = (int64_t) ((uint64_t) v1337 * (uint64_t) v16);
        // pto: %762, %763
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v1338 % v51 == v56) {
          // pto: %764
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1339;
          // pto: %764
          ;
          uint64_t v1340 = (uint64_t) v41;
          TASSIGN(v1339, v1340);
          // pto: %765
          ;
          int64_t v1341 = v1338 / v51;
          // pto: %766
          ;
          int64_t v1342 = v1341 < v56 ? v56 : v1341;
          // pto: %767
          ;
          __gm__ int8_t* v1343 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %767
          ;
          const int64_t v1344 = 0;
          // pto: %767
          ;
          const int64_t v1345 = 128;
          // pto: %767
          ;
          pto::Shape<1, 1, 1, 32, 128> v1346 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %767
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1347 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %767
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1348 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1343 + (v1344 + v1342 * v1345), v1346, v1347);
          TLOAD(v1339, v1348);
        } else {
          // pto: %768
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1349;
          // pto: %768
          ;
          uint64_t v1350 = (uint64_t) v41;
          TASSIGN(v1349, v1350);
          // pto: %769
          ;
          int64_t v1351 = v1338 / v51;
          // pto: %770
          ;
          int64_t v1352 = v1351 < v56 ? v56 : v1351;
          // pto: %771
          ;
          __gm__ int8_t* v1353 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %771
          ;
          const int64_t v1354 = 0;
          // pto: %771
          ;
          const int64_t v1355 = 128;
          // pto: %771
          ;
          pto::Shape<1, 1, 1, 32, 128> v1356 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %771
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1357 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %771
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1358 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1353 + (v1354 + v1352 * v1355), v1356, v1357);
          TLOAD(v1349, v1358);
        };
        // pto: %774, %775
        ;
        int64_t v1359 = (int64_t) ((uint64_t) v286 + (uint64_t) v28) / v66;
        // pto: %779
        ;
        int64_t v1360 = v1359 < v289 ? v1359 : v289;
        // pto: %782, %780
        ;
        int32_t v1361 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v1360)];
        // pto: %783
        ;
        int64_t v1362 = (int64_t) v1361;
        // pto: %784
        ;
        int64_t v1363 = v1362 < v56 ? v56 : v1362;
        // pto: %785
        ;
        int64_t v1364 = (int64_t) ((uint64_t) v1363 * (uint64_t) v16);
        // pto: %786, %787
        ;
        if (v1364 % v51 == v56) {
          // pto: %789
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1365;
          // pto: %789
          ;
          uint64_t v1366 = (uint64_t) v39;
          TASSIGN(v1365, v1366);
          // pto: %790
          ;
          int64_t v1367 = v1364 / v51;
          // pto: %791
          ;
          int64_t v1368 = v1367 < v56 ? v56 : v1367;
          // pto: %792
          ;
          __gm__ int8_t* v1369 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %792
          ;
          const int64_t v1370 = 0;
          // pto: %792
          ;
          const int64_t v1371 = 128;
          // pto: %792
          ;
          pto::Shape<1, 1, 1, 32, 128> v1372 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %792
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1373 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %792
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1374 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1369 + (v1370 + v1368 * v1371), v1372, v1373);
          TLOAD(v1365, v1374);
        } else {
          // pto: %794
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1375;
          // pto: %794
          ;
          uint64_t v1376 = (uint64_t) v39;
          TASSIGN(v1375, v1376);
          // pto: %795
          ;
          int64_t v1377 = v1364 / v51;
          // pto: %796
          ;
          int64_t v1378 = v1377 < v56 ? v56 : v1377;
          // pto: %797
          ;
          __gm__ int8_t* v1379 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %797
          ;
          const int64_t v1380 = 0;
          // pto: %797
          ;
          const int64_t v1381 = 128;
          // pto: %797
          ;
          pto::Shape<1, 1, 1, 32, 128> v1382 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %797
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1383 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %797
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1384 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1379 + (v1380 + v1378 * v1381), v1382, v1383);
          TLOAD(v1375, v1384);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v495
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1385 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v495
        ;
        uint64_t v1386 = (uint64_t) v45;
        TASSIGN(v1385, v1386);
        // pto: %buf_prefetched_key_inline8631__ssa_v61
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1387 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8631__ssa_v61
        ;
        uint64_t v1388 = (uint64_t) v43;
        TASSIGN(v1387, v1388);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1389 = static_cast<uint16_t>(v56);
        uint16_t v1390 = static_cast<uint16_t>(v73);
        TEXTRACT(v1387, v1385, v1389, v1390);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline8777__ssa_v36
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1391 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8777__ssa_v36
        ;
        uint64_t v1392 = (uint64_t) v47;
        TASSIGN(v1391, v1392);
        // pto: %buf_scores_l1_inline8697__ssa_v48
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1393 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8697__ssa_v48
        ;
        uint64_t v1394 = (uint64_t) v43;
        TASSIGN(v1393, v1394);
        // pto: %buf_previous_pair_inline8693__ssa_v12
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1395 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8693__ssa_v12
        ;
        uint64_t v1396 = (uint64_t) v46;
        TASSIGN(v1395, v1396);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1397 = static_cast<uint16_t>(v56);
        uint16_t v1398 = static_cast<uint16_t>(v56);
        TEXTRACT(v1395, v1329, v1397, v1398);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline8611__ssa_v36
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1399 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8611__ssa_v36
        ;
        uint64_t v1400 = (uint64_t) v43;
        TASSIGN(v1399, v1400);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1399, v277, v1391);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8798__ssa_v12
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1401 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8798__ssa_v12
        ;
        uint64_t v1402 = (uint64_t) v48;
        TASSIGN(v1401, v1402);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1401, v279, v1395);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1403 = static_cast<uint64_t>(v77);
        uint16_t v1404 = static_cast<uint16_t>(v56);
        uint16_t v1405 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1393, v1399, v1403, v1404, v1405);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1401.SetValidShape(v65, v73);
        // pto: %801
        ;
        __gm__ float* v1406 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %801
        ;
        const int64_t v1407 = 704;
        // pto: %801
        ;
        const int64_t v1408 = 1024;
        // pto: %801
        ;
        pto::Shape<1, 1, 1, 6, 64> v1409 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %801
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1410 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %801
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1411 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1406 + (v1407 + v492 * v1408), v1409, v1410);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1411, v1401);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8635__ssa_v13
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1412 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8635__ssa_v13
        ;
        uint64_t v1413 = (uint64_t) v43;
        TASSIGN(v1412, v1413);
        // pto: %buf_current_key_inline8632__ssa_v91
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1414 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8632__ssa_v91
        ;
        uint64_t v1415 = (uint64_t) v43;
        TASSIGN(v1414, v1415);
        // pto: %803, %804
        ;
        int64_t v1416 = (int64_t) ((uint64_t) v286 + (uint64_t) v87) / v66;
        // pto: %808
        ;
        int64_t v1417 = v1416 < v289 ? v1416 : v289;
        // pto: %811, %809
        ;
        int32_t v1418 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v1417)];
        // pto: %812
        ;
        int64_t v1419 = (int64_t) v1418;
        // pto: %813
        ;
        int64_t v1420 = v1419 < v56 ? v56 : v1419;
        // pto: %814
        ;
        int64_t v1421 = (int64_t) ((uint64_t) v1420 * (uint64_t) v16);
        // pto: %815, %816
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v1421 % v51 == v56) {
          // pto: %817
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1422;
          // pto: %817
          ;
          uint64_t v1423 = (uint64_t) v45;
          TASSIGN(v1422, v1423);
          // pto: %818
          ;
          int64_t v1424 = v1421 / v51;
          // pto: %819
          ;
          int64_t v1425 = v1424 < v56 ? v56 : v1424;
          // pto: %820
          ;
          __gm__ int8_t* v1426 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %820
          ;
          const int64_t v1427 = 0;
          // pto: %820
          ;
          const int64_t v1428 = 128;
          // pto: %820
          ;
          pto::Shape<1, 1, 1, 32, 128> v1429 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %820
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1430 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %820
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1431 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1426 + (v1427 + v1425 * v1428), v1429, v1430);
          TLOAD(v1422, v1431);
        } else {
          // pto: %821
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1432;
          // pto: %821
          ;
          uint64_t v1433 = (uint64_t) v45;
          TASSIGN(v1432, v1433);
          // pto: %822
          ;
          int64_t v1434 = v1421 / v51;
          // pto: %823
          ;
          int64_t v1435 = v1434 < v56 ? v56 : v1434;
          // pto: %824
          ;
          __gm__ int8_t* v1436 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %824
          ;
          const int64_t v1437 = 0;
          // pto: %824
          ;
          const int64_t v1438 = 128;
          // pto: %824
          ;
          pto::Shape<1, 1, 1, 32, 128> v1439 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %824
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1440 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %824
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1441 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1436 + (v1437 + v1435 * v1438), v1439, v1440);
          TLOAD(v1432, v1441);
        };
        // pto: %827, %828
        ;
        int64_t v1442 = (int64_t) ((uint64_t) v286 + (uint64_t) v27) / v66;
        // pto: %832
        ;
        int64_t v1443 = v1442 < v289 ? v1442 : v289;
        // pto: %835, %833
        ;
        int32_t v1444 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v1443)];
        // pto: %836
        ;
        int64_t v1445 = (int64_t) v1444;
        // pto: %837
        ;
        int64_t v1446 = v1445 < v56 ? v56 : v1445;
        // pto: %838
        ;
        int64_t v1447 = (int64_t) ((uint64_t) v1446 * (uint64_t) v16);
        // pto: %839, %840
        ;
        if (v1447 % v51 == v56) {
          // pto: %842
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1448;
          // pto: %842
          ;
          uint64_t v1449 = (uint64_t) v42;
          TASSIGN(v1448, v1449);
          // pto: %843
          ;
          int64_t v1450 = v1447 / v51;
          // pto: %844
          ;
          int64_t v1451 = v1450 < v56 ? v56 : v1450;
          // pto: %845
          ;
          __gm__ int8_t* v1452 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %845
          ;
          const int64_t v1453 = 0;
          // pto: %845
          ;
          const int64_t v1454 = 128;
          // pto: %845
          ;
          pto::Shape<1, 1, 1, 32, 128> v1455 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %845
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1456 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %845
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1457 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1452 + (v1453 + v1451 * v1454), v1455, v1456);
          TLOAD(v1448, v1457);
        } else {
          // pto: %847
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1458;
          // pto: %847
          ;
          uint64_t v1459 = (uint64_t) v42;
          TASSIGN(v1458, v1459);
          // pto: %848
          ;
          int64_t v1460 = v1447 / v51;
          // pto: %849
          ;
          int64_t v1461 = v1460 < v56 ? v56 : v1460;
          // pto: %850
          ;
          __gm__ int8_t* v1462 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %850
          ;
          const int64_t v1463 = 0;
          // pto: %850
          ;
          const int64_t v1464 = 128;
          // pto: %850
          ;
          pto::Shape<1, 1, 1, 32, 128> v1465 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %850
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1466 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %850
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1467 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1462 + (v1463 + v1461 * v1464), v1465, v1466);
          TLOAD(v1458, v1467);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v499
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1468 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v499
        ;
        uint64_t v1469 = (uint64_t) v45;
        TASSIGN(v1468, v1469);
        // pto: %buf_prefetched_key_inline8631__ssa_v66
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1470 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8631__ssa_v66
        ;
        uint64_t v1471 = (uint64_t) v47;
        TASSIGN(v1470, v1471);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1472 = static_cast<uint16_t>(v56);
        uint16_t v1473 = static_cast<uint16_t>(v56);
        TEXTRACT(v1470, v1468, v1472, v1473);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        // pto: %buf_key_panel_inline8777__ssa_v39
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1474 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8777__ssa_v39
        ;
        uint64_t v1475 = (uint64_t) v43;
        TASSIGN(v1474, v1475);
        // pto: %buf_scores_l1_inline8697__ssa_v52
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1476 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8697__ssa_v52
        ;
        uint64_t v1477 = (uint64_t) v44;
        TASSIGN(v1476, v1477);
        // pto: %buf_previous_pair_inline8693__ssa_v13
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1478 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8693__ssa_v13
        ;
        uint64_t v1479 = (uint64_t) v46;
        TASSIGN(v1478, v1479);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1480 = static_cast<uint16_t>(v56);
        uint16_t v1481 = static_cast<uint16_t>(v56);
        TEXTRACT(v1478, v1412, v1480, v1481);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline8611__ssa_v39
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1482 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8611__ssa_v39
        ;
        uint64_t v1483 = (uint64_t) v43;
        TASSIGN(v1482, v1483);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1482, v277, v1474);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8798__ssa_v13
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1484 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8798__ssa_v13
        ;
        uint64_t v1485 = (uint64_t) v48;
        TASSIGN(v1484, v1485);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1484, v279, v1478);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1486 = static_cast<uint64_t>(v77);
        uint16_t v1487 = static_cast<uint16_t>(v56);
        uint16_t v1488 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1476, v1482, v1486, v1487, v1488);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1484.SetValidShape(v65, v73);
        // pto: %854
        ;
        __gm__ float* v1489 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %854
        ;
        const int64_t v1490 = 768;
        // pto: %854
        ;
        const int64_t v1491 = 1024;
        // pto: %854
        ;
        pto::Shape<1, 1, 1, 6, 64> v1492 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %854
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1493 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %854
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1494 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1489 + (v1490 + v492 * v1491), v1492, v1493);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1494, v1484);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8635__ssa_v14
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1495 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8635__ssa_v14
        ;
        uint64_t v1496 = (uint64_t) v44;
        TASSIGN(v1495, v1496);
        // pto: %buf_current_key_inline8632__ssa_v98
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1497 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8632__ssa_v98
        ;
        uint64_t v1498 = (uint64_t) v47;
        TASSIGN(v1497, v1498);
        // pto: %856, %857
        ;
        int64_t v1499 = (int64_t) ((uint64_t) v286 + (uint64_t) v88) / v66;
        // pto: %861
        ;
        int64_t v1500 = v1499 < v289 ? v1499 : v289;
        // pto: %864, %862
        ;
        int32_t v1501 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v1500)];
        // pto: %865
        ;
        int64_t v1502 = (int64_t) v1501;
        // pto: %866
        ;
        int64_t v1503 = v1502 < v56 ? v56 : v1502;
        // pto: %867
        ;
        int64_t v1504 = (int64_t) ((uint64_t) v1503 * (uint64_t) v16);
        // pto: %868, %869
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        if (v1504 % v51 == v56) {
          // pto: %870
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1505;
          // pto: %870
          ;
          uint64_t v1506 = (uint64_t) v41;
          TASSIGN(v1505, v1506);
          // pto: %871
          ;
          int64_t v1507 = v1504 / v51;
          // pto: %872
          ;
          int64_t v1508 = v1507 < v56 ? v56 : v1507;
          // pto: %873
          ;
          __gm__ int8_t* v1509 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %873
          ;
          const int64_t v1510 = 0;
          // pto: %873
          ;
          const int64_t v1511 = 128;
          // pto: %873
          ;
          pto::Shape<1, 1, 1, 32, 128> v1512 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %873
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1513 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %873
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1514 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1509 + (v1510 + v1508 * v1511), v1512, v1513);
          TLOAD(v1505, v1514);
        } else {
          // pto: %874
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1515;
          // pto: %874
          ;
          uint64_t v1516 = (uint64_t) v41;
          TASSIGN(v1515, v1516);
          // pto: %875
          ;
          int64_t v1517 = v1504 / v51;
          // pto: %876
          ;
          int64_t v1518 = v1517 < v56 ? v56 : v1517;
          // pto: %877
          ;
          __gm__ int8_t* v1519 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %877
          ;
          const int64_t v1520 = 0;
          // pto: %877
          ;
          const int64_t v1521 = 128;
          // pto: %877
          ;
          pto::Shape<1, 1, 1, 32, 128> v1522 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %877
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1523 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %877
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1524 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1519 + (v1520 + v1518 * v1521), v1522, v1523);
          TLOAD(v1515, v1524);
        };
        // pto: %881
        ;
        int64_t v1525 = (int64_t) ((uint64_t) v286 + (uint64_t) v26) / v66;
        // pto: %885
        ;
        int64_t v1526 = v1525 < v289 ? v1525 : v289;
        // pto: %888, %886
        ;
        int32_t v1527 = (v10)[(int64_t) ((uint64_t) v291 + (uint64_t) v1526)];
        // pto: %889
        ;
        int64_t v1528 = (int64_t) v1527;
        // pto: %890
        ;
        int64_t v1529 = v1528 < v56 ? v56 : v1528;
        // pto: %891
        ;
        int64_t v1530 = (int64_t) ((uint64_t) v1529 * (uint64_t) v16);
        // pto: %892, %893
        ;
        if (v1530 % v51 == v56) {
          // pto: %895
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1531;
          // pto: %895
          ;
          uint64_t v1532 = (uint64_t) v39;
          TASSIGN(v1531, v1532);
          // pto: %896
          ;
          int64_t v1533 = v1530 / v51;
          // pto: %897
          ;
          int64_t v1534 = v1533 < v56 ? v56 : v1533;
          // pto: %898
          ;
          __gm__ int8_t* v1535 = PTOAS__GLOBAL_TENSOR_DATA(v113);
          // pto: %898
          ;
          const int64_t v1536 = 0;
          // pto: %898
          ;
          const int64_t v1537 = 128;
          // pto: %898
          ;
          pto::Shape<1, 1, 1, 32, 128> v1538 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %898
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1539 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %898
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1540 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1535 + (v1536 + v1534 * v1537), v1538, v1539);
          TLOAD(v1531, v1540);
        } else {
          // pto: %900
          ;
          Tile<TileType::Mat, int8_t, 128, 128, BLayout::ColMajor, 32, 128, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1541;
          // pto: %900
          ;
          uint64_t v1542 = (uint64_t) v39;
          TASSIGN(v1541, v1542);
          // pto: %901
          ;
          int64_t v1543 = v1530 / v51;
          // pto: %902
          ;
          int64_t v1544 = v1543 < v56 ? v56 : v1543;
          // pto: %903
          ;
          __gm__ int8_t* v1545 = PTOAS__GLOBAL_TENSOR_DATA(v122);
          // pto: %903
          ;
          const int64_t v1546 = 0;
          // pto: %903
          ;
          const int64_t v1547 = 128;
          // pto: %903
          ;
          pto::Shape<1, 1, 1, 32, 128> v1548 = pto::Shape<1, 1, 1, 32, 128>();
          // pto: %903
          ;
          pto::Stride<4096, 4096, 4096, 128, 1> v1549 = pto::Stride<4096, 4096, 4096, 128, 1>();
          // pto: %903
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v1550 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v1545 + (v1546 + v1544 * v1547), v1548, v1549);
          TLOAD(v1541, v1550);
        };
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %t__tmp_v503
        ;
        Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1551 = Tile<TileType::Mat, int8_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v51);
        // pto: %t__tmp_v503
        ;
        uint64_t v1552 = (uint64_t) v45;
        TASSIGN(v1551, v1552);
        // pto: %buf_prefetched_key_inline8631__ssa_v71
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1553 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_prefetched_key_inline8631__ssa_v71
        ;
        uint64_t v1554 = (uint64_t) v43;
        TASSIGN(v1553, v1554);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1555 = static_cast<uint16_t>(v56);
        uint16_t v1556 = static_cast<uint16_t>(v73);
        TEXTRACT(v1553, v1551, v1555, v1556);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        // pto: %buf_key_panel_inline8777__ssa_v42
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1557 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8777__ssa_v42
        ;
        uint64_t v1558 = (uint64_t) v47;
        TASSIGN(v1557, v1558);
        // pto: %buf_scores_l1_inline8697__ssa_v56
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1559 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8697__ssa_v56
        ;
        uint64_t v1560 = (uint64_t) v43;
        TASSIGN(v1559, v1560);
        // pto: %buf_previous_pair_inline8693__ssa_v14
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1561 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8693__ssa_v14
        ;
        uint64_t v1562 = (uint64_t) v46;
        TASSIGN(v1561, v1562);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        uint16_t v1563 = static_cast<uint16_t>(v56);
        uint16_t v1564 = static_cast<uint16_t>(v56);
        TEXTRACT(v1561, v1495, v1563, v1564);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline8611__ssa_v42
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1565 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8611__ssa_v42
        ;
        uint64_t v1566 = (uint64_t) v43;
        TASSIGN(v1565, v1566);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1565, v277, v1557);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8798__ssa_v14
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1567 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8798__ssa_v14
        ;
        uint64_t v1568 = (uint64_t) v48;
        TASSIGN(v1567, v1568);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1567, v279, v1561);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1569 = static_cast<uint64_t>(v77);
        uint16_t v1570 = static_cast<uint16_t>(v56);
        uint16_t v1571 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1559, v1565, v1569, v1570, v1571);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1567.SetValidShape(v65, v73);
        // pto: %907
        ;
        __gm__ float* v1572 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %907
        ;
        const int64_t v1573 = 832;
        // pto: %907
        ;
        const int64_t v1574 = 1024;
        // pto: %907
        ;
        pto::Shape<1, 1, 1, 6, 64> v1575 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %907
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1576 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %907
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1577 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1572 + (v1573 + v492 * v1574), v1575, v1576);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1577, v1567);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %buf_previous_l1_inline8635__ssa_v15
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1578 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8635__ssa_v15
        ;
        uint64_t v1579 = (uint64_t) v43;
        TASSIGN(v1578, v1579);
        // pto: %buf_current_key_inline8632__ssa_v105
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1580 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_current_key_inline8632__ssa_v105
        ;
        uint64_t v1581 = (uint64_t) v43;
        TASSIGN(v1580, v1581);
        // pto: %buf_key_panel_inline8777__ssa_v45
        ;
        Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1582 = Tile<TileType::Right, int8_t, 128, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v51, v73);
        // pto: %buf_key_panel_inline8777__ssa_v45
        ;
        uint64_t v1583 = (uint64_t) v43;
        TASSIGN(v1582, v1583);
        // pto: %buf_scores_l1_inline8697__ssa_v60
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1584 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_l1_inline8697__ssa_v60
        ;
        uint64_t v1585 = (uint64_t) v44;
        TASSIGN(v1584, v1585);
        // pto: %buf_previous_pair_inline8693__ssa_v15
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1586 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_pair_inline8693__ssa_v15
        ;
        uint64_t v1587 = (uint64_t) v46;
        TASSIGN(v1586, v1587);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1588 = static_cast<uint16_t>(v56);
        uint16_t v1589 = static_cast<uint16_t>(v56);
        TEXTRACT(v1586, v1578, v1588, v1589);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_scores_inline8611__ssa_v45
        ;
        Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1590 = Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_scores_inline8611__ssa_v45
        ;
        uint64_t v1591 = (uint64_t) v43;
        TASSIGN(v1590, v1591);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        TMATMUL(v1590, v277, v1582);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %buf_reduced_pair_inline8798__ssa_v15
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1592 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_reduced_pair_inline8798__ssa_v15
        ;
        uint64_t v1593 = (uint64_t) v48;
        TASSIGN(v1592, v1593);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v1592, v279, v1586);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        uint64_t v1594 = static_cast<uint64_t>(v77);
        uint16_t v1595 = static_cast<uint16_t>(v56);
        uint16_t v1596 = static_cast<uint16_t>(v56);
        TINSERT<Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Acc, int32_t, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>, ReluPreMode::NormalRelu>(v1584, v1590, v1594, v1595, v1596);
        set_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        v1592.SetValidShape(v65, v73);
        // pto: %911
        ;
        __gm__ float* v1597 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %911
        ;
        const int64_t v1598 = 896;
        // pto: %911
        ;
        const int64_t v1599 = 1024;
        // pto: %911
        ;
        pto::Shape<1, 1, 1, 6, 64> v1600 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %911
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1601 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %911
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1602 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1597 + (v1598 + v492 * v1599), v1600, v1601);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        TSTORE(v1602, v1592);
        // pto: %buf_previous_l1_inline8635__ssa_v16
        ;
        Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v1603 = Tile<TileType::Mat, half, 384, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_previous_l1_inline8635__ssa_v16
        ;
        uint64_t v1604 = (uint64_t) v44;
        TASSIGN(v1603, v1604);
        // pto: %buf_last_pair_inline8668__ssa_v0
        ;
        Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v1605 = Tile<TileType::Right, half, 384, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v53, v73);
        // pto: %buf_last_pair_inline8668__ssa_v0
        ;
        uint64_t v1606 = (uint64_t) v46;
        TASSIGN(v1605, v1606);
        wait_flag(PIPE_FIX, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        uint16_t v1607 = static_cast<uint16_t>(v56);
        uint16_t v1608 = static_cast<uint16_t>(v56);
        TEXTRACT(v1605, v1603, v1607, v1608);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %buf_last_scores_inline8664__ssa_v0
        ;
        Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v1609 = Tile<TileType::Acc, float, 16, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v74, v73);
        // pto: %buf_last_scores_inline8664__ssa_v0
        ;
        uint64_t v1610 = (uint64_t) v43;
        TASSIGN(v1609, v1610);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        TMATMUL(v1609, v279, v1605);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        v1609.SetValidShape(v65, v73);
        // pto: %913
        ;
        __gm__ float* v1611 = PTOAS__GLOBAL_TENSOR_DATA(v130);
        // pto: %913
        ;
        const int64_t v1612 = 960;
        // pto: %913
        ;
        const int64_t v1613 = 1024;
        // pto: %913
        ;
        pto::Shape<1, 1, 1, 6, 64> v1614 = pto::Shape<1, 1, 1, 6, 64>();
        // pto: %913
        ;
        pto::Stride<6144, 6144, 6144, 1024, 1> v1615 = pto::Stride<6144, 6144, 6144, 1024, 1>();
        // pto: %913
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND> v1616 = GlobalTensor<float, pto::Shape<1, 1, 1, 6, 64>, pto::Stride<6144, 6144, 6144, 1024, 1>, pto::Layout::ND>(v1611 + (v1612 + v492 * v1613), v1614, v1615);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        pipe_barrier(PIPE_FIX);
        TSTORE(v1616, v1609);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        uint16_t v1617 = getFFTSMsg(FFTS_MODE_VAL, v56);
        ffts_cross_core_sync(PIPE_FIX, v1617);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      // pto: %914
      ;
      for (int64_t v1618 = v56; v1618 < (v255 < v75 ? v255 : v75); v1618 += v49) {
        int32_t v1619 = (int32_t) v49;
        wait_flag_dev(v1619);
      };
    };
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void indexer_score_topk_native_pair_aiv(__gm__ int32_t* v1, __gm__ int32_t* v2, __gm__ int64_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ int64_t* v7, __gm__ int8_t* v8, __gm__ half* v9, __gm__ int32_t* v10, __gm__ int8_t* v11, __gm__ int8_t* v12, __gm__ float* v13, __gm__ int8_t* v14, __gm__ float* v15, int64_t v16, int64_t v17, int64_t v18, int64_t v19, int64_t v20, int64_t v21, int64_t v22, int64_t v23, int32_t v24, int32_t v25, int32_t v26) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v27 = 8192;
  const int64_t v28 = 4096;
  pto::MrgSortExecutedNumList v29 = pto::MrgSortExecutedNumList{0, 0, 0, 0};
  // pto: %c0_i64
  const int64_t v30 = 0;
  // pto: %c12288_i64
  const int64_t v31 = 12288;
  // pto: %c57344_i64
  const int64_t v32 = 57344;
  // pto: %c73728_i64
  const int64_t v33 = 73728;
  // pto: %c40960_i64
  const int64_t v34 = 40960;
  // pto: %c49152_i64
  const int64_t v35 = 49152;
  // pto: %c36864_i64
  const int64_t v36 = 36864;
  const int64_t v37 = 77824;
  // pto: %c1_index
  const int64_t v38 = 1;
  // pto: %c27648_index
  const int64_t v39 = 27648;
  // pto: %c288_index
  const int64_t v40 = 288;
  // pto: %c1024_index
  const int64_t v41 = 1024;
  // pto: %c0_index
  const int64_t v42 = 0;
  // pto: %c4_index
  const int64_t v43 = 4;
  // pto: %c262144_index
  const int64_t v44 = 262144;
  // pto: %c1023_index
  const int64_t v45 = 1023;
  // pto: %c8191_index
  const int64_t v46 = 8191;
  // pto: %c8192_index
  const int64_t v47 = 8192;
  // pto: %c3_index
  const int64_t v48 = 3;
  // pto: %c48_index
  const int64_t v49 = 48;
  // pto: %c24_index
  const int64_t v50 = 24;
  // pto: %c6_index
  const int64_t v51 = 6;
  // pto: %c32_index
  const int64_t v52 = 32;
  // pto: %c8_index
  const int64_t v53 = 8;
  // pto: %c1_i64
  const int64_t v54 = 1;
  // pto: %c4_i64
  const int64_t v55 = 4;
  // pto: %cst_30
  const float v56 = -3.40282347E+38f;
  // pto: %c12_index
  const int64_t v57 = 12;
  // pto: %c2_index
  const int64_t v58 = 2;
  // pto: %c2048_index
  const int64_t v59 = 2048;
  // pto: %c64_index
  const int64_t v60 = 64;
  // pto: %c4096_index
  const int64_t v61 = 4096;
  // pto: %c512_index
  const int64_t v62 = 512;
  // pto: %c192_index
  const int64_t v63 = 192;
  // pto: %c0_i32
  const int32_t v64 = 0;
  // pto: %c64_i32
  const int32_t v65 = 64;
  // pto: %c256_i32
  const int32_t v66 = 256;
  // pto: %c1024_i32
  const int32_t v67 = 1024;
  // pto: %buf_score_transfer_inline8684__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %buf_score_transfer_inline8684__ssa_v0_view
  const int64_t v69 = 1;
  // pto: %buf_score_transfer_inline8684__ssa_v0_view
  const int64_t v70 = 1;
  // pto: %buf_score_transfer_inline8684__ssa_v0_view
  int64_t v71 = v40 * v41;
  // pto: %buf_score_transfer_inline8684__ssa_v0_view
  int64_t v72 = v70 * v71;
  // pto: %buf_score_transfer_inline8684__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v73 = pto::Shape<1, 1, 1, -1, -1>(v68, v69, v70, v40, v41);
  // pto: %buf_score_transfer_inline8684__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v74 = pto::Stride<-1, -1, -1, -1, -1>(v69 * v72, v72, v71, v41, v38);
  // pto: %buf_score_transfer_inline8684__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v75 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v73, v74);
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v76 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v77 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  const int64_t v78 = 1;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v79 = (int64_t) v22;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v80 = (int64_t) v23;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v81 = v79 * v80;
  // pto: %idx_native_kv_cache__rv_v2_view
  int64_t v82 = v78 * v81;
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v83 = pto::Shape<1, 1, 1, -1, -1>(v76, v77, v78, v79, (int64_t) v23);
  // pto: %idx_native_kv_cache__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v84 = pto::Stride<-1, -1, -1, -1, -1>(v77 * v82, v82, v81, v80, v38);
  // pto: %idx_native_kv_cache__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v85 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v83, v84);
  // pto: %pair_arena_inline2969_inline5683__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %pair_arena_inline2969_inline5683__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %pair_arena_inline2969_inline5683__ssa_v0_view
  const int64_t v88 = 1;
  // pto: %pair_arena_inline2969_inline5683__ssa_v0_view
  int64_t v89 = v39 * v41;
  // pto: %pair_arena_inline2969_inline5683__ssa_v0_view
  int64_t v90 = v88 * v89;
  // pto: %pair_arena_inline2969_inline5683__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v91 = pto::Shape<1, 1, 1, -1, -1>(v86, v87, v88, v39, v41);
  // pto: %pair_arena_inline2969_inline5683__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v92 = pto::Stride<-1, -1, -1, -1, -1>(v87 * v90, v90, v89, v41, v38);
  // pto: %pair_arena_inline2969_inline5683__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v93 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v91, v92);
  // pto: %single_roots_inline8618__phi_v15
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline8618__phi_v15
  uint64_t v95 = (uint64_t) v30;
  TASSIGN(v94, v95);
  // pto: %single_roots_inline8618__phi_v6
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline8618__phi_v6
  uint64_t v97 = (uint64_t) v30;
  TASSIGN(v96, v97);
  // pto: %single_new_root_inline8707__phi_v4
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
  // pto: %single_new_root_inline8707__phi_v4
  uint64_t v99 = (uint64_t) v36;
  TASSIGN(v98, v99);
  // pto: %single_new_root_inline8707__phi_v3
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
  // pto: %single_new_root_inline8707__phi_v3
  uint64_t v101 = (uint64_t) v36;
  TASSIGN(v100, v101);
  // pto: %single_roots_inline8618__phi_v5
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline8618__phi_v5
  uint64_t v103 = (uint64_t) v30;
  TASSIGN(v102, v103);
  // pto: %single_roots_inline8618__phi_v10
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline8618__phi_v10
  uint64_t v105 = (uint64_t) v30;
  TASSIGN(v104, v105);
  // pto: %single_new_root_inline8707__phi_v9
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
  // pto: %single_new_root_inline8707__phi_v9
  uint64_t v107 = (uint64_t) v36;
  TASSIGN(v106, v107);
  // pto: %single_new_root_inline8707__phi_v8
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
  // pto: %single_new_root_inline8707__phi_v8
  uint64_t v109 = (uint64_t) v36;
  TASSIGN(v108, v109);
  // pto: %single_roots_inline8618__phi_v9
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline8618__phi_v9
  uint64_t v111 = (uint64_t) v30;
  TASSIGN(v110, v111);
  // pto: %single_roots_inline8618__phi_v14
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline8618__phi_v14
  uint64_t v113 = (uint64_t) v30;
  TASSIGN(v112, v113);
  // pto: %single_new_root_inline8707__phi_v14
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
  // pto: %single_new_root_inline8707__phi_v14
  uint64_t v115 = (uint64_t) v36;
  TASSIGN(v114, v115);
  // pto: %single_new_root_inline8707__phi_v13
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
  // pto: %single_new_root_inline8707__phi_v13
  uint64_t v117 = (uint64_t) v36;
  TASSIGN(v116, v117);
  // pto: %single_roots_inline8618__phi_v13
  Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
  // pto: %single_roots_inline8618__phi_v13
  uint64_t v119 = (uint64_t) v30;
  TASSIGN(v118, v119);
  // pto: %buf_worker_inline8627__ssa_v0
  int64_t v120 = (int64_t) v24;
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %buf_max_cache_len_inline8692__rv_v2
  int64_t v121;
  v121 = v42;
  for (int64_t v122 = v42; v122 < v17; v122 += v38) {
    // pto: %t__tile
    ;
    int32_t v123 = (v1)[v122];
    // pto: %0, %1
    ;
    int64_t v124 = (int64_t) v123 / v43;
    // pto: %2
    ;
    bool v125 = v121 < v124;
    // pto: %2
    ;
    int64_t v126 = v125 ? v124 : v121;
    v121 = v126;
  }
  // pto: %3
  bool v127 = v121 < v44;
  // pto: %3
  int64_t v128 = v127 ? v121 : v44;
  // pto: %4
  int32_t v129 = (v2)[v42];
  // pto: %5
  int64_t v130 = (int64_t) v129;
  // pto: %6, %7
  int64_t v131 = (int64_t) ((uint64_t) v128 + (uint64_t) v45) / v41;
  // pto: %8, %9
  int64_t v132 = (int64_t) ((uint64_t) v128 + (uint64_t) v46) / v47;
  // pto: %10
  int64_t v133 = v132 < v38 ? v38 : v132;
  // pto: %11
  int64_t v134 = (int64_t) ((uint64_t) v130 * (uint64_t) v48);
  // pto: %12
  // pto: %leaf_multiple_inline2601_inline8700__phi_v6
  int64_t v135;
  if (v134 == v49) {
    v135 = v48;
  } else {
    // pto: %14
    ;
    // pto: %leaf_multiple_inline2601_inline8700__phi_v5
    ;
    int64_t v136;
    if (v134 == v50) {
      v136 = v48;
    } else {
      // pto: %15, %16, %leaf_multiple_inline2601_inline8700__phi_v4
      ;
      v136 = (int64_t) ((uint64_t) v130 * (uint64_t) v51) == v50 ? v51 : v38;
    };
    v135 = v136;
  }
  // pto: %17
  bool v137 = v135 > v38;
  // pto: %extra_leaves_inline2600_inline8711__phi_v3
  int64_t v138;
  // pto: %leaf_count_inline2603_inline8599__phi_v3
  int64_t v139;
  // pto: %leaf_tiles_inline2602_inline8714__phi_v3
  int64_t v140;
  if (v137) {
    // pto: %18
    ;
    uint64_t v141 = (uint64_t) v135;
    // pto: %18, %19, %20
    ;
    int64_t v142 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v133 + v141) - (uint64_t) v38) / v135;
    // pto: %21
    ;
    uint64_t v143 = (uint64_t) v135;
    // pto: %21
    ;
    int64_t v144 = (int64_t) ((uint64_t) v142 * v143);
    // pto: %22
    ;
    bool v145 = v144 <= v52;
    // pto: %extra_leaves_inline2600_inline8711__phi_v2
    ;
    // pto: %leaf_count_inline2603_inline8599__phi_v2
    ;
    int64_t v146;
    // pto: %leaf_tiles_inline2602_inline8714__phi_v2
    ;
    int64_t v147;
    if (v145) {
      // pto: %23
      ;
      int64_t v148 = v131 / v144;
      // pto: %24
      ;
      // pto: %25
      ;
      v146 = v131 % v144;
      v147 = v148 < v38 ? v38 : v148;
    } else {
      v146 = v42;
      v147 = v53;
    };
    v138 = v146;
    v139 = v145 ? v144 : v133;
    v140 = v147;
  } else {
    v138 = v42;
    v139 = v133;
    v140 = v53;
  }
  uint64_t v149 = reinterpret_cast<uint64_t>(v3);
  set_ffts_base_addr(v149);
  // pto: %buf_score_lane_inline8610__ssa_v0
  int64_t v150 = (int64_t) v26;
  // pto: %26
  uint64_t v151 = (uint64_t) v139;
  // pto: %26
  for (int64_t v152 = v120; v152 < ((int64_t) ((uint64_t) v130 * v151)); v152 += v50) {
    // pto: %27
    ;
    // pto: %single_group_inline8639__phi_v2
    ;
    int64_t v153;
    // pto: %single_leaf_inline8608__phi_v2
    ;
    int64_t v154;
    if (v130 < v50) {
      // pto: %28
      ;
      // pto: %29
      ;
      v153 = v152 % v130;
      v154 = v152 / v130;
    } else {
      // pto: %30
      ;
      int64_t v155 = v152 / v139;
      // pto: %31
      ;
      int64_t v156 = v152 % v139;
      v153 = v155;
      v154 = v156;
    };
    // pto: %32
    ;
    int32_t v157 = (v4)[v153];
    // pto: %33
    ;
    int64_t v158 = (int64_t) v157;
    // pto: %34
    ;
    int32_t v159 = (v5)[v153];
    // pto: %35
    ;
    int64_t v160 = (int64_t) v159;
    // pto: %36
    ;
    int32_t v161 = (v6)[v158];
    // pto: %37
    ;
    int64_t v162 = (int64_t) v161;
    // pto: %38
    ;
    int32_t v163 = (v1)[v162];
    // pto: %39, %40
    ;
    int64_t v164 = (int64_t) v163 / v43;
    // pto: %41, %42, %single_last_position_inline8837__tile
    ;
    int64_t v165 = (v7)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v158 + (uint64_t) v160) - (uint64_t) v38)];
    // pto: %43, %44
    ;
    int64_t v166 = (int64_t) ((uint64_t) v165 + (uint64_t) v54) / v55;
    // pto: %46
    ;
    int64_t v167 = v164 < v166 ? v164 : v166;
    // pto: %47
    ;
    int64_t v168 = v167 < v44 ? v167 : v44;
    // pto: %48
    ;
    int64_t v169 = v168 < v42 ? v42 : v168;
    // pto: %49
    ;
    uint64_t v170 = (uint64_t) v154;
    // pto: %49
    ;
    uint64_t v171 = (uint64_t) v140;
    // pto: %50
    ;
    bool v172 = v154 < v138;
    // pto: %50
    ;
    int64_t v173 = v172 ? v154 : v138;
    // pto: %49, %51, %52
    ;
    int64_t v174 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v170 * v171) + (uint64_t) v173) * (uint64_t) v41);
    // pto: %53
    ;
    bool v175 = v154 < v138;
    // pto: %55
    ;
    uint64_t v176 = (uint64_t) v140;
    // pto: %54, %55, %56
    ;
    int64_t v177 = (int64_t) ((uint64_t) ((int64_t) v176 + (uint64_t) ((int64_t) v175)) * (uint64_t) v41);
    // pto: %57
    ;
    if (v174 < v169) {
      // pto: %58
      ;
      int64_t v178 = (int64_t) ((uint64_t) v169 - (uint64_t) v174);
      // pto: %59
      ;
      int64_t v179 = v177 < v178 ? v177 : v178;
      // pto: %60, %61
      ;
      int64_t v180 = (int64_t) ((uint64_t) v179 + (uint64_t) v45) / v41;
      // pto: %single_roots_inline8618__ssa_v0
      ;
      Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
      // pto: %single_roots_inline8618__ssa_v0
      ;
      uint64_t v182 = (uint64_t) v30;
      TASSIGN(v181, v182);
      pipe_barrier(PIPE_V);
      TEXPANDS(v181, v56);
      // pto: %single_segments_inline8625__ssa_v0
      ;
      Tile<TileType::Vec, float, 6, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Vec, float, 6, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v51, v41);
      // pto: %single_segments_inline8625__ssa_v0
      ;
      uint64_t v184 = (uint64_t) v31;
      TASSIGN(v183, v184);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      TEXPANDS(v183, v56);
      for (int64_t v185 = v42; v185 < v180; v185 += v38) {
        // pto: %65
        ;
        int64_t v186 = v185 % v58;
        // pto: %68
        ;
        int64_t v187 = (int64_t) ((uint64_t) v150 * (uint64_t) v48);
        // pto: %64, %67, %66, %69
        ;
        int64_t v188 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v120 * (uint64_t) v57) + (uint64_t) ((int64_t) (uint64_t) v186 * (uint64_t) v51)) + (uint64_t) v187);
        // pto: %single_scale_bytes_inline8600__ssa_v0
        ;
        Tile<TileType::Vec, int8_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v189 = Tile<TileType::Vec, int8_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
        // pto: %single_scale_bytes_inline8600__ssa_v0
        ;
        uint64_t v190 = (uint64_t) v32;
        TASSIGN(v189, v190);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
        for (int64_t v191 = v42; v191 < v52; v191 += v38) {
          // pto: %63, %62, %70, %71
          ;
          int64_t v192 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v174 + (uint64_t) ((int64_t) (uint64_t) v185 * (uint64_t) v41)) / v52) + (uint64_t) v191);
          // pto: %72, %73
          ;
          int64_t v193 = (int64_t) ((uint64_t) v164 - (uint64_t) v38) / v52;
          // pto: %74
          ;
          int64_t v194 = v193 < v42 ? v42 : v193;
          // pto: %75
          ;
          int64_t v195 = v192 < v194 ? v192 : v194;
          // pto: %flat_offset_mul, %flat_offset, %76
          ;
          int32_t v196 = (v10)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v162 * (uint64_t) v19) + (uint64_t) v195)];
          // pto: %77
          ;
          int64_t v197 = (int64_t) v196;
          // pto: %78
          ;
          int64_t v198 = v197 < v42 ? v42 : v197;
          // pto: %gather_row_view
          ;
          Tile<TileType::Vec, int8_t, 1, 2048, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v199;
          // pto: %79, %gather_row_view
          ;
          uint64_t v200 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v191 * (uint64_t) v60) + (uint64_t) v32);
          TASSIGN(v199, v200);
          // pto: %80
          ;
          int64_t v201 = v198 < v42 ? v42 : v198;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v202 = (int64_t) v23;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v203 = 0;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          __gm__ int8_t* v204 = PTOAS__GLOBAL_TENSOR_DATA(v85);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v205 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v206 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          const int64_t v207 = 1;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v208 = v38 * v202;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          int64_t v209 = v207 * v208;
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          pto::Shape<1, 1, 1, 1, 64> v210 = pto::Shape<1, 1, 1, 1, 64>(v205, v206, v207, v38, v60);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v211 = pto::Stride<-1, -1, -1, -1, -1>(v206 * v209, v209, v208, v202, v38);
          // pto: %idx_native_kv_cache__rv_v2_pview
          ;
          GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v212 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v204 + (v203 + v201 * v202 + v61 * v38), v210, v211);
          TLOAD(v199, v212);
        };
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %single_scale_half_inline8596__ssa_v0
        ;
        Tile<TileType::Vec, half, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Vec, half, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_scale_half_inline8596__ssa_v0
        ;
        uint64_t v214 = (uint64_t) v32;
        TASSIGN(v213, v214);
        // pto: %single_kv_scale_inline8594__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_kv_scale_inline8594__ssa_v0
        ;
        uint64_t v216 = (uint64_t) v33;
        TASSIGN(v215, v216);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        RoundMode v217 = RoundMode::CAST_ROUND;
        SaturationMode v218 = SaturationMode::ON;
        TCVT(v215, v213, v217, v218);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        int32_t v219 = (int32_t) v42;
        wait_flag_dev(v219);
        // pto: %single_scores_inline8655__ssa_v0
        ;
        Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Vec, float, 3, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v41);
        // pto: %single_scores_inline8655__ssa_v0
        ;
        uint64_t v221 = (uint64_t) v32;
        TASSIGN(v220, v221);
        // pto: %81
        ;
        int64_t v222 = v188 < v42 ? v42 : v188;
        // pto: %buf_score_transfer_inline8684__ssa_v0_pview
        ;
        __gm__ float* v223 = PTOAS__GLOBAL_TENSOR_DATA(v75);
        // pto: %buf_score_transfer_inline8684__ssa_v0_pview
        ;
        const int64_t v224 = 0;
        // pto: %buf_score_transfer_inline8684__ssa_v0_pview
        ;
        const int64_t v225 = 1024;
        // pto: %buf_score_transfer_inline8684__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 3, 1024> v226 = pto::Shape<1, 1, 1, 3, 1024>();
        // pto: %buf_score_transfer_inline8684__ssa_v0_pview
        ;
        pto::Stride<3072, 3072, 3072, 1024, 1> v227 = pto::Stride<3072, 3072, 3072, 1024, 1>();
        // pto: %buf_score_transfer_inline8684__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 3, 1024>, pto::Stride<3072, 3072, 3072, 1024, 1>, pto::Layout::ND> v228 = GlobalTensor<float, pto::Shape<1, 1, 1, 3, 1024>, pto::Stride<3072, 3072, 3072, 1024, 1>, pto::Layout::ND>(v223 + (v224 + v222 * v225), v226, v227);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        TLOAD(v220, v228);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        uint16_t v229 = getFFTSMsg(FFTS_MODE_VAL, v38);
        ffts_cross_core_sync(PIPE_MTE2, v229);
        // pto: %single_score_row_inline8694__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v230 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_score_row_inline8694__ssa_v0
        ;
        uint64_t v231 = (uint64_t) v34;
        TASSIGN(v230, v231);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        uint16_t v232 = static_cast<uint16_t>(v42);
        uint16_t v233 = static_cast<uint16_t>(v42);
        TEXTRACT(v230, v220, v232, v233);
        // pto: %single_scaled_inline8778__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_scaled_inline8778__ssa_v0
        ;
        uint64_t v235 = (uint64_t) v34;
        TASSIGN(v234, v235);
        pipe_barrier(PIPE_V);
        TMUL(v234, v230, v215);
        // pto: %assemble_view
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v236;
        // pto: %assemble_view
        ;
        uint64_t v237 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v186 * (uint64_t) v28) + (uint64_t) v31);
        TASSIGN(v236, v237);
        pipe_barrier(PIPE_V);
        TMOV(v236, v234);
        // pto: %single_score_row_inline8694__ssa_v1
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_score_row_inline8694__ssa_v1
        ;
        uint64_t v239 = (uint64_t) v34;
        TASSIGN(v238, v239);
        pipe_barrier(PIPE_V);
        uint16_t v240 = static_cast<uint16_t>(v38);
        uint16_t v241 = static_cast<uint16_t>(v42);
        TEXTRACT(v238, v220, v240, v241);
        // pto: %single_scaled_inline8778__ssa_v1
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v242 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_scaled_inline8778__ssa_v1
        ;
        uint64_t v243 = (uint64_t) v34;
        TASSIGN(v242, v243);
        pipe_barrier(PIPE_V);
        TMUL(v242, v238, v215);
        // pto: %85
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v244;
        // pto: %84, %85
        ;
        uint64_t v245 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v186 + (uint64_t) v58) * (uint64_t) v28) + (uint64_t) v31);
        TASSIGN(v244, v245);
        pipe_barrier(PIPE_V);
        TMOV(v244, v242);
        // pto: %single_score_row_inline8694__ssa_v2
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_score_row_inline8694__ssa_v2
        ;
        uint64_t v247 = (uint64_t) v34;
        TASSIGN(v246, v247);
        pipe_barrier(PIPE_V);
        uint16_t v248 = static_cast<uint16_t>(v58);
        uint16_t v249 = static_cast<uint16_t>(v42);
        TEXTRACT(v246, v220, v248, v249);
        // pto: %single_scaled_inline8778__ssa_v2
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v250 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_scaled_inline8778__ssa_v2
        ;
        uint64_t v251 = (uint64_t) v32;
        TASSIGN(v250, v251);
        pipe_barrier(PIPE_V);
        TMUL(v250, v246, v215);
        // pto: %88
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v252;
        // pto: %87, %88
        ;
        uint64_t v253 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v186 + (uint64_t) v43) * (uint64_t) v28) + (uint64_t) v31);
        TASSIGN(v252, v253);
        pipe_barrier(PIPE_V);
        TMOV(v252, v250);
        // pto: %90, %91, %92, %93
        ;
        if (v186 == v38 | (int64_t) ((uint64_t) v185 + (uint64_t) v38) == v180) {
          // pto: %96, %94, %95
          ;
          int64_t v254 = (int64_t) ((uint64_t) v174 + (uint64_t) ((int64_t) (uint64_t) (v185 / v58) * (uint64_t) v59));
          // pto: %98, %99
          ;
          int64_t v255 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v186 * (uint64_t) v41) + (uint64_t) v41);
          // pto: %single_segment_rows_inline8674__ssa_v0
          ;
          Tile<TileType::Vec, float, 3, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v256 = Tile<TileType::Vec, float, 3, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v48, v59);
          // pto: %single_segment_rows_inline8674__ssa_v0
          ;
          uint64_t v257 = (uint64_t) v31;
          TASSIGN(v256, v257);
          // pto: %102
          ;
          int64_t v258 = (int64_t) ((uint64_t) v160 - (uint64_t) v38);
          // pto: %103
          ;
          int64_t v259 = v187 < v258 ? v187 : v258;
          // pto: %104, %single_position_inline8737__tile
          ;
          int64_t v260 = (v7)[(int64_t) ((uint64_t) v158 + (uint64_t) v259)];
          // pto: %105, %106
          ;
          int64_t v261 = (int64_t) ((uint64_t) v260 + (uint64_t) v54) / v55;
          // pto: %108
          ;
          int64_t v262 = v164 < v261 ? v164 : v261;
          // pto: %109
          ;
          int64_t v263 = v262 < v44 ? v262 : v44;
          // pto: %110
          ;
          int64_t v264 = v263 < v42 ? v42 : v263;
          // pto: %111
          ;
          int64_t v265 = (int64_t) ((uint64_t) v264 - (uint64_t) v254);
          // pto: %112
          ;
          int64_t v266 = v265 < v255 ? v265 : v255;
          // pto: %113
          ;
          int64_t v267 = v266 < v42 ? v42 : v266;
          // pto: %114, %101, %115
          ;
          if (v267 > v42 & v187 < v160) {
            // pto: %single_segment_data_inline8739__ssa_v0
            ;
            Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v268 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
            // pto: %single_segment_data_inline8739__ssa_v0
            ;
            uint64_t v269 = (uint64_t) v32;
            TASSIGN(v268, v269);
            pipe_barrier(PIPE_V);
            uint16_t v270 = static_cast<uint16_t>(v42);
            uint16_t v271 = static_cast<uint16_t>(v42);
            TEXTRACT(v268, v256, v270, v271);
            // pto: %116
            ;
            int32_t v272 = (int32_t) v254;
            // pto: %117
            ;
            if (v267 <= v62) {
              // pto: %t__ci_tmp_v0
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
              // pto: %t__ci_tmp_v0
              ;
              uint64_t v274 = (uint64_t) v34;
              TASSIGN(v273, v274);
              // pto: %t__tmp_v512
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v512
              ;
              uint64_t v276 = (uint64_t) v33;
              TASSIGN(v275, v276);
              // pto: %ci_tmp_view
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277;
              TRESHAPE(v277, v273);
              // pto: %ci_dst_view
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v278;
              TRESHAPE(v278, v275);
              TCI<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v278, v64, v277);
              // pto: %tiny_indices_inline8686__ssa_v0
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %tiny_indices_inline8686__ssa_v0
              ;
              uint64_t v280 = (uint64_t) v34;
              TASSIGN(v279, v280);
              pipe_barrier(PIPE_V);
              TADDS(v279, v275, v272);
              // pto: %tiny_tile_inline8740__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %tiny_tile_inline8740__ssa_v0
              ;
              uint64_t v282 = (uint64_t) v33;
              TASSIGN(v281, v282);
              pipe_barrier(PIPE_V);
              uint16_t v283 = static_cast<uint16_t>(v42);
              uint16_t v284 = static_cast<uint16_t>(v42);
              TEXTRACT(v281, v268, v283, v284);
              v281.SetValidShape(v38, v267);
              // pto: %t__tmp_v513
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v285 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v513
              ;
              uint64_t v286 = (uint64_t) v33;
              TASSIGN(v285, v286);
              pipe_barrier(PIPE_V);
              TFILLPAD<pto::TFillPadMode::InPlace>(v285, v281);
              // pto: %tiny_scores_inline8746__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v287 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v62);
              // pto: %tiny_scores_inline8746__ssa_v0
              ;
              uint64_t v288 = (uint64_t) v35;
              TASSIGN(v287, v288);
              pipe_barrier(PIPE_V);
              TMAXS(v287, v285, v56);
              // pto: %t__tmp_v514
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v514
              ;
              uint64_t v290 = (uint64_t) v34;
              TASSIGN(v289, v290);
              // pto: %tiny_pairs_inline8653__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v291 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_inline8653__ssa_v0
              ;
              uint64_t v292 = (uint64_t) v33;
              TASSIGN(v291, v292);
              // pto: %sort32_src_view
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v293;
              TRESHAPE(v293, v287);
              // pto: %sort32_idx_view
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v294;
              TRESHAPE(v294, v289);
              // pto: %sort32_dst_view
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v295;
              TRESHAPE(v295, v291);
              pipe_barrier(PIPE_V);
              TSORT32(v295, v293, v294);
              // pto: %tiny_pairs_v1_inline8748__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v296 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_v1_inline8748__ssa_v0
              ;
              uint64_t v297 = (uint64_t) v34;
              TASSIGN(v296, v297);
              pipe_barrier(PIPE_V);
              TMRGSORT(v296, v291, v65);
              // pto: %tiny_pairs_v2_inline8749__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v298 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_v2_inline8749__ssa_v0
              ;
              uint64_t v299 = (uint64_t) v33;
              TASSIGN(v298, v299);
              pipe_barrier(PIPE_V);
              TMRGSORT(v298, v296, v66);
              // pto: %single_new_root_inline8707__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v300 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_new_root_inline8707__ssa_v0
              ;
              uint64_t v301 = (uint64_t) v36;
              TASSIGN(v300, v301);
              pipe_barrier(PIPE_V);
              uint16_t v302 = static_cast<uint16_t>(v42);
              uint16_t v303 = static_cast<uint16_t>(v42);
              TEXTRACT(v300, v298, v302, v303);
            } else {
              // pto: %118
              ;
              if (v267 <= v41) {
                // pto: %t__ci_tmp_v1
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v304 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
                // pto: %t__ci_tmp_v1
                ;
                uint64_t v305 = (uint64_t) v34;
                TASSIGN(v304, v305);
                // pto: %t__tmp_v515
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v515
                ;
                uint64_t v307 = (uint64_t) v33;
                TASSIGN(v306, v307);
                // pto: %119
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v308;
                TRESHAPE(v308, v304);
                // pto: %120
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309;
                TRESHAPE(v309, v306);
                TCI<Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v309, v64, v308);
                // pto: %small_indices_inline8657__ssa_v0
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v310 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %small_indices_inline8657__ssa_v0
                ;
                uint64_t v311 = (uint64_t) v34;
                TASSIGN(v310, v311);
                pipe_barrier(PIPE_V);
                TADDS(v310, v306, v272);
                // pto: %small_tile_inline8753__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %small_tile_inline8753__ssa_v0
                ;
                uint64_t v313 = (uint64_t) v33;
                TASSIGN(v312, v313);
                pipe_barrier(PIPE_V);
                uint16_t v314 = static_cast<uint16_t>(v42);
                uint16_t v315 = static_cast<uint16_t>(v42);
                TEXTRACT(v312, v268, v314, v315);
                v312.SetValidShape(v38, v267);
                // pto: %t__tmp_v516
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v316 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v516
                ;
                uint64_t v317 = (uint64_t) v33;
                TASSIGN(v316, v317);
                pipe_barrier(PIPE_V);
                TFILLPAD<pto::TFillPadMode::InPlace>(v316, v312);
                // pto: %small_scores_inline8687__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v318 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_scores_inline8687__ssa_v0
                ;
                uint64_t v319 = (uint64_t) v35;
                TASSIGN(v318, v319);
                pipe_barrier(PIPE_V);
                TMAXS(v318, v316, v56);
                // pto: %t__tmp_v517
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v320 = Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v517
                ;
                uint64_t v321 = (uint64_t) v34;
                TASSIGN(v320, v321);
                // pto: %small_pairs_inline8756__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v322 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_inline8756__ssa_v0
                ;
                uint64_t v323 = (uint64_t) v33;
                TASSIGN(v322, v323);
                // pto: %121
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v324;
                TRESHAPE(v324, v318);
                // pto: %122
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v325;
                TRESHAPE(v325, v320);
                // pto: %123
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v326;
                TRESHAPE(v326, v322);
                pipe_barrier(PIPE_V);
                TSORT32(v326, v324, v325);
                // pto: %small_pairs_v1_inline8757__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v327 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_v1_inline8757__ssa_v0
                ;
                uint64_t v328 = (uint64_t) v34;
                TASSIGN(v327, v328);
                pipe_barrier(PIPE_V);
                TMRGSORT(v327, v322, v65);
                // pto: %small_pairs_v2_inline8780__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v329 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_v2_inline8780__ssa_v0
                ;
                uint64_t v330 = (uint64_t) v33;
                TASSIGN(v329, v330);
                pipe_barrier(PIPE_V);
                TMRGSORT(v329, v327, v66);
                // pto: %small_left_inline8758__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v331 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_left_inline8758__ssa_v0
                ;
                uint64_t v332 = (uint64_t) v33;
                TASSIGN(v331, v332);
                // pto: %slice_view
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v333;
                // pto: %slice_view
                ;
                uint64_t v334 = (uint64_t) v33;
                TASSIGN(v333, v334);
                // pto: %small_right_inline8719__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v335 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_right_inline8719__ssa_v0
                ;
                uint64_t v336 = (uint64_t) v37;
                TASSIGN(v335, v336);
                // pto: %124
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v337;
                // pto: %124
                ;
                uint64_t v338 = (uint64_t) v37;
                TASSIGN(v337, v338);
                // pto: %small_tmp_inline8788__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v339 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %small_tmp_inline8788__ssa_v0
                ;
                uint64_t v340 = (uint64_t) v34;
                TASSIGN(v339, v340);
                // pto: %small_merged_inline8762__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v341 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_merged_inline8762__ssa_v0
                ;
                uint64_t v342 = (uint64_t) v35;
                TASSIGN(v341, v342);
                pipe_barrier(PIPE_V);
                TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v341, v29, v339, v333, v337);
                // pto: %single_new_root_inline8707__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v343 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline8707__ssa_v1
                ;
                uint64_t v344 = (uint64_t) v36;
                TASSIGN(v343, v344);
                pipe_barrier(PIPE_V);
                uint16_t v345 = static_cast<uint16_t>(v42);
                uint16_t v346 = static_cast<uint16_t>(v42);
                TEXTRACT(v343, v341, v345, v346);
              } else {
                // pto: %t__ci_tmp_v2
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
                // pto: %t__ci_tmp_v2
                ;
                uint64_t v348 = (uint64_t) v34;
                TASSIGN(v347, v348);
                // pto: %t__tmp_v518
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v349 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v518
                ;
                uint64_t v350 = (uint64_t) v33;
                TASSIGN(v349, v350);
                // pto: %125
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v351;
                TRESHAPE(v351, v347);
                // pto: %126
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v352;
                TRESHAPE(v352, v349);
                TCI<Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v352, v64, v351);
                // pto: %large_indices_inline8763__ssa_v0
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v353 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %large_indices_inline8763__ssa_v0
                ;
                uint64_t v354 = (uint64_t) v33;
                TASSIGN(v353, v354);
                pipe_barrier(PIPE_V);
                TADDS(v353, v349, v272);
                // pto: %large_tile_inline8701__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v355 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %large_tile_inline8701__ssa_v0
                ;
                uint64_t v356 = (uint64_t) v34;
                TASSIGN(v355, v356);
                uint16_t v357 = static_cast<uint16_t>(v42);
                uint16_t v358 = static_cast<uint16_t>(v42);
                TEXTRACT(v355, v268, v357, v358);
                v355.SetValidShape(v38, v267);
                // pto: %t__tmp_v519
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v359 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v519
                ;
                uint64_t v360 = (uint64_t) v32;
                TASSIGN(v359, v360);
                pipe_barrier(PIPE_V);
                TFILLPAD(v359, v355);
                // pto: %large_scores_inline8679__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v361 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %large_scores_inline8679__ssa_v0
                ;
                uint64_t v362 = (uint64_t) v34;
                TASSIGN(v361, v362);
                pipe_barrier(PIPE_V);
                TMAXS(v361, v359, v56);
                // pto: %t__tmp_v520
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v363 = Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v520
                ;
                uint64_t v364 = (uint64_t) v33;
                TASSIGN(v363, v364);
                // pto: %large_pairs_inline8767__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v365 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_inline8767__ssa_v0
                ;
                uint64_t v366 = (uint64_t) v32;
                TASSIGN(v365, v366);
                // pto: %127
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v367;
                TRESHAPE(v367, v361);
                // pto: %128
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v368;
                TRESHAPE(v368, v363);
                // pto: %129
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v369;
                TRESHAPE(v369, v365);
                pipe_barrier(PIPE_V);
                TSORT32(v369, v367, v368);
                // pto: %large_pairs_v1_inline8769__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v370 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v1_inline8769__ssa_v0
                ;
                uint64_t v371 = (uint64_t) v33;
                TASSIGN(v370, v371);
                pipe_barrier(PIPE_V);
                TMRGSORT(v370, v365, v65);
                // pto: %large_pairs_v2_inline8622__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v372 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v2_inline8622__ssa_v0
                ;
                uint64_t v373 = (uint64_t) v32;
                TASSIGN(v372, v373);
                pipe_barrier(PIPE_V);
                TMRGSORT(v372, v370, v66);
                // pto: %large_pairs_v3_inline8634__ssa_v0
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v374 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v3_inline8634__ssa_v0
                ;
                uint64_t v375 = (uint64_t) v33;
                TASSIGN(v374, v375);
                pipe_barrier(PIPE_V);
                TMRGSORT(v374, v372, v67);
                // pto: %single_new_root_inline8707__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v376 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline8707__ssa_v2
                ;
                uint64_t v377 = (uint64_t) v34;
                TASSIGN(v376, v377);
                pipe_barrier(PIPE_V);
                uint16_t v378 = static_cast<uint16_t>(v42);
                uint16_t v379 = static_cast<uint16_t>(v42);
                TEXTRACT(v376, v374, v378, v379);
                // pto: %single_new_root_inline8707__ssa_v2_mv
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v380 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline8707__ssa_v2_mv
                ;
                uint64_t v381 = (uint64_t) v36;
                TASSIGN(v380, v381);
                pipe_barrier(PIPE_V);
                TMOV(v380, v376);
              };
            };
            // pto: %130
            ;
            if (v185 < v58) {
              // pto: %131
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v382;
              // pto: %131
              ;
              uint64_t v383 = (uint64_t) v30;
              TASSIGN(v382, v383);
              pipe_barrier(PIPE_V);
              TMOV(v382, v98);
            } else {
              // pto: %single_old_root_inline8772__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v384 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_old_root_inline8772__ssa_v0
              ;
              uint64_t v385 = (uint64_t) v35;
              TASSIGN(v384, v385);
              pipe_barrier(PIPE_V);
              uint16_t v386 = static_cast<uint16_t>(v42);
              uint16_t v387 = static_cast<uint16_t>(v42);
              TEXTRACT(v384, v181, v386, v387);
              // pto: %single_merge_tmp_inline8629__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v388 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
              // pto: %single_merge_tmp_inline8629__ssa_v0
              ;
              uint64_t v389 = (uint64_t) v32;
              TASSIGN(v388, v389);
              // pto: %single_merged_inline8773__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v390 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
              // pto: %single_merged_inline8773__ssa_v0
              ;
              uint64_t v391 = (uint64_t) v33;
              TASSIGN(v390, v391);
              pipe_barrier(PIPE_V);
              TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, false>(v390, v29, v388, v98, v384);
              // pto: %single_next_root_inline8838__ssa_v0
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v392 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_next_root_inline8838__ssa_v0
              ;
              uint64_t v393 = (uint64_t) v32;
              TASSIGN(v392, v393);
              pipe_barrier(PIPE_V);
              uint16_t v394 = static_cast<uint16_t>(v42);
              uint16_t v395 = static_cast<uint16_t>(v42);
              TEXTRACT(v392, v390, v394, v395);
              // pto: %133
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v396;
              // pto: %133
              ;
              uint64_t v397 = (uint64_t) v30;
              TASSIGN(v396, v397);
              pipe_barrier(PIPE_V);
              TMOV(v396, v392);
            };
          };
          // pto: %135
          ;
          int64_t v398 = (int64_t) ((uint64_t) v187 + (uint64_t) v38);
          // pto: %139
          ;
          int64_t v399 = v398 < v258 ? v398 : v258;
          // pto: %140, %137
          ;
          int64_t v400 = (v7)[(int64_t) ((uint64_t) v158 + (uint64_t) v399)];
          // pto: %141, %142
          ;
          int64_t v401 = (int64_t) ((uint64_t) v400 + (uint64_t) v54) / v55;
          // pto: %144
          ;
          int64_t v402 = v164 < v401 ? v164 : v401;
          // pto: %145
          ;
          int64_t v403 = v402 < v44 ? v402 : v44;
          // pto: %146
          ;
          int64_t v404 = v403 < v42 ? v42 : v403;
          // pto: %147
          ;
          int64_t v405 = (int64_t) ((uint64_t) v404 - (uint64_t) v254);
          // pto: %148
          ;
          int64_t v406 = v405 < v255 ? v405 : v255;
          // pto: %149
          ;
          int64_t v407 = v406 < v42 ? v42 : v406;
          // pto: %150, %136, %151
          ;
          if (v407 > v42 & v398 < v160) {
            // pto: %single_segment_data_inline8739__ssa_v1
            ;
            Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v408 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
            // pto: %single_segment_data_inline8739__ssa_v1
            ;
            uint64_t v409 = (uint64_t) v32;
            TASSIGN(v408, v409);
            pipe_barrier(PIPE_V);
            uint16_t v410 = static_cast<uint16_t>(v38);
            uint16_t v411 = static_cast<uint16_t>(v42);
            TEXTRACT(v408, v256, v410, v411);
            // pto: %152
            ;
            int32_t v412 = (int32_t) v254;
            // pto: %153
            ;
            if (v407 <= v62) {
              // pto: %t__ci_tmp_v3
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v413 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
              // pto: %t__ci_tmp_v3
              ;
              uint64_t v414 = (uint64_t) v34;
              TASSIGN(v413, v414);
              // pto: %t__tmp_v521
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v415 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v521
              ;
              uint64_t v416 = (uint64_t) v33;
              TASSIGN(v415, v416);
              // pto: %154
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v417;
              TRESHAPE(v417, v413);
              // pto: %155
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v418;
              TRESHAPE(v418, v415);
              TCI<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v418, v64, v417);
              // pto: %tiny_indices_inline8686__ssa_v1
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v419 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %tiny_indices_inline8686__ssa_v1
              ;
              uint64_t v420 = (uint64_t) v34;
              TASSIGN(v419, v420);
              pipe_barrier(PIPE_V);
              TADDS(v419, v415, v412);
              // pto: %tiny_tile_inline8740__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v421 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %tiny_tile_inline8740__ssa_v1
              ;
              uint64_t v422 = (uint64_t) v33;
              TASSIGN(v421, v422);
              pipe_barrier(PIPE_V);
              uint16_t v423 = static_cast<uint16_t>(v42);
              uint16_t v424 = static_cast<uint16_t>(v42);
              TEXTRACT(v421, v408, v423, v424);
              v421.SetValidShape(v38, v407);
              // pto: %t__tmp_v522
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v425 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v522
              ;
              uint64_t v426 = (uint64_t) v33;
              TASSIGN(v425, v426);
              pipe_barrier(PIPE_V);
              TFILLPAD<pto::TFillPadMode::InPlace>(v425, v421);
              // pto: %tiny_scores_inline8746__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v427 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v62);
              // pto: %tiny_scores_inline8746__ssa_v1
              ;
              uint64_t v428 = (uint64_t) v35;
              TASSIGN(v427, v428);
              pipe_barrier(PIPE_V);
              TMAXS(v427, v425, v56);
              // pto: %t__tmp_v523
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v429 = Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v523
              ;
              uint64_t v430 = (uint64_t) v34;
              TASSIGN(v429, v430);
              // pto: %tiny_pairs_inline8653__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v431 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_inline8653__ssa_v1
              ;
              uint64_t v432 = (uint64_t) v33;
              TASSIGN(v431, v432);
              // pto: %156
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v433;
              TRESHAPE(v433, v427);
              // pto: %157
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v434;
              TRESHAPE(v434, v429);
              // pto: %158
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v435;
              TRESHAPE(v435, v431);
              pipe_barrier(PIPE_V);
              TSORT32(v435, v433, v434);
              // pto: %tiny_pairs_v1_inline8748__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v436 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_v1_inline8748__ssa_v1
              ;
              uint64_t v437 = (uint64_t) v34;
              TASSIGN(v436, v437);
              pipe_barrier(PIPE_V);
              TMRGSORT(v436, v431, v65);
              // pto: %tiny_pairs_v2_inline8749__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v438 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_v2_inline8749__ssa_v1
              ;
              uint64_t v439 = (uint64_t) v33;
              TASSIGN(v438, v439);
              pipe_barrier(PIPE_V);
              TMRGSORT(v438, v436, v66);
              // pto: %single_new_root_inline8707__ssa_v5
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v440 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_new_root_inline8707__ssa_v5
              ;
              uint64_t v441 = (uint64_t) v36;
              TASSIGN(v440, v441);
              pipe_barrier(PIPE_V);
              uint16_t v442 = static_cast<uint16_t>(v42);
              uint16_t v443 = static_cast<uint16_t>(v42);
              TEXTRACT(v440, v438, v442, v443);
            } else {
              // pto: %159
              ;
              if (v407 <= v41) {
                // pto: %t__ci_tmp_v4
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v444 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
                // pto: %t__ci_tmp_v4
                ;
                uint64_t v445 = (uint64_t) v34;
                TASSIGN(v444, v445);
                // pto: %t__tmp_v524
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v446 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v524
                ;
                uint64_t v447 = (uint64_t) v33;
                TASSIGN(v446, v447);
                // pto: %160
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v448;
                TRESHAPE(v448, v444);
                // pto: %161
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v449;
                TRESHAPE(v449, v446);
                TCI<Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v449, v64, v448);
                // pto: %small_indices_inline8657__ssa_v1
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v450 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %small_indices_inline8657__ssa_v1
                ;
                uint64_t v451 = (uint64_t) v34;
                TASSIGN(v450, v451);
                pipe_barrier(PIPE_V);
                TADDS(v450, v446, v412);
                // pto: %small_tile_inline8753__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v452 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %small_tile_inline8753__ssa_v1
                ;
                uint64_t v453 = (uint64_t) v33;
                TASSIGN(v452, v453);
                pipe_barrier(PIPE_V);
                uint16_t v454 = static_cast<uint16_t>(v42);
                uint16_t v455 = static_cast<uint16_t>(v42);
                TEXTRACT(v452, v408, v454, v455);
                v452.SetValidShape(v38, v407);
                // pto: %t__tmp_v525
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v456 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v525
                ;
                uint64_t v457 = (uint64_t) v33;
                TASSIGN(v456, v457);
                pipe_barrier(PIPE_V);
                TFILLPAD<pto::TFillPadMode::InPlace>(v456, v452);
                // pto: %small_scores_inline8687__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v458 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_scores_inline8687__ssa_v1
                ;
                uint64_t v459 = (uint64_t) v35;
                TASSIGN(v458, v459);
                pipe_barrier(PIPE_V);
                TMAXS(v458, v456, v56);
                // pto: %t__tmp_v526
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v460 = Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v526
                ;
                uint64_t v461 = (uint64_t) v34;
                TASSIGN(v460, v461);
                // pto: %small_pairs_inline8756__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v462 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_inline8756__ssa_v1
                ;
                uint64_t v463 = (uint64_t) v33;
                TASSIGN(v462, v463);
                // pto: %162
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v464;
                TRESHAPE(v464, v458);
                // pto: %163
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v465;
                TRESHAPE(v465, v460);
                // pto: %164
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v466;
                TRESHAPE(v466, v462);
                pipe_barrier(PIPE_V);
                TSORT32(v466, v464, v465);
                // pto: %small_pairs_v1_inline8757__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v467 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_v1_inline8757__ssa_v1
                ;
                uint64_t v468 = (uint64_t) v34;
                TASSIGN(v467, v468);
                pipe_barrier(PIPE_V);
                TMRGSORT(v467, v462, v65);
                // pto: %small_pairs_v2_inline8780__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v469 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_v2_inline8780__ssa_v1
                ;
                uint64_t v470 = (uint64_t) v33;
                TASSIGN(v469, v470);
                pipe_barrier(PIPE_V);
                TMRGSORT(v469, v467, v66);
                // pto: %small_left_inline8758__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v471 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_left_inline8758__ssa_v1
                ;
                uint64_t v472 = (uint64_t) v33;
                TASSIGN(v471, v472);
                // pto: %165
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v473;
                // pto: %165
                ;
                uint64_t v474 = (uint64_t) v33;
                TASSIGN(v473, v474);
                // pto: %small_right_inline8719__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v475 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_right_inline8719__ssa_v1
                ;
                uint64_t v476 = (uint64_t) v37;
                TASSIGN(v475, v476);
                // pto: %166
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v477;
                // pto: %166
                ;
                uint64_t v478 = (uint64_t) v37;
                TASSIGN(v477, v478);
                // pto: %small_tmp_inline8788__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v479 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %small_tmp_inline8788__ssa_v1
                ;
                uint64_t v480 = (uint64_t) v34;
                TASSIGN(v479, v480);
                // pto: %small_merged_inline8762__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v481 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_merged_inline8762__ssa_v1
                ;
                uint64_t v482 = (uint64_t) v35;
                TASSIGN(v481, v482);
                pipe_barrier(PIPE_V);
                TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v481, v29, v479, v473, v477);
                // pto: %single_new_root_inline8707__ssa_v6
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v483 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline8707__ssa_v6
                ;
                uint64_t v484 = (uint64_t) v36;
                TASSIGN(v483, v484);
                pipe_barrier(PIPE_V);
                uint16_t v485 = static_cast<uint16_t>(v42);
                uint16_t v486 = static_cast<uint16_t>(v42);
                TEXTRACT(v483, v481, v485, v486);
              } else {
                // pto: %t__ci_tmp_v5
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v487 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
                // pto: %t__ci_tmp_v5
                ;
                uint64_t v488 = (uint64_t) v34;
                TASSIGN(v487, v488);
                // pto: %t__tmp_v527
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v489 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v527
                ;
                uint64_t v490 = (uint64_t) v33;
                TASSIGN(v489, v490);
                // pto: %168
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v491;
                TRESHAPE(v491, v487);
                // pto: %169
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v492;
                TRESHAPE(v492, v489);
                TCI<Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v492, v64, v491);
                // pto: %large_indices_inline8763__ssa_v1
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v493 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %large_indices_inline8763__ssa_v1
                ;
                uint64_t v494 = (uint64_t) v33;
                TASSIGN(v493, v494);
                pipe_barrier(PIPE_V);
                TADDS(v493, v489, v412);
                // pto: %large_tile_inline8701__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v495 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %large_tile_inline8701__ssa_v1
                ;
                uint64_t v496 = (uint64_t) v34;
                TASSIGN(v495, v496);
                uint16_t v497 = static_cast<uint16_t>(v42);
                uint16_t v498 = static_cast<uint16_t>(v42);
                TEXTRACT(v495, v408, v497, v498);
                v495.SetValidShape(v38, v407);
                // pto: %t__tmp_v528
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v499 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v528
                ;
                uint64_t v500 = (uint64_t) v32;
                TASSIGN(v499, v500);
                pipe_barrier(PIPE_V);
                TFILLPAD(v499, v495);
                // pto: %large_scores_inline8679__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v501 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %large_scores_inline8679__ssa_v1
                ;
                uint64_t v502 = (uint64_t) v34;
                TASSIGN(v501, v502);
                pipe_barrier(PIPE_V);
                TMAXS(v501, v499, v56);
                // pto: %t__tmp_v529
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v503 = Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v529
                ;
                uint64_t v504 = (uint64_t) v33;
                TASSIGN(v503, v504);
                // pto: %large_pairs_inline8767__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v505 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_inline8767__ssa_v1
                ;
                uint64_t v506 = (uint64_t) v32;
                TASSIGN(v505, v506);
                // pto: %170
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v507;
                TRESHAPE(v507, v501);
                // pto: %171
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v508;
                TRESHAPE(v508, v503);
                // pto: %172
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v509;
                TRESHAPE(v509, v505);
                pipe_barrier(PIPE_V);
                TSORT32(v509, v507, v508);
                // pto: %large_pairs_v1_inline8769__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v510 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v1_inline8769__ssa_v1
                ;
                uint64_t v511 = (uint64_t) v33;
                TASSIGN(v510, v511);
                pipe_barrier(PIPE_V);
                TMRGSORT(v510, v505, v65);
                // pto: %large_pairs_v2_inline8622__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v512 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v2_inline8622__ssa_v1
                ;
                uint64_t v513 = (uint64_t) v32;
                TASSIGN(v512, v513);
                pipe_barrier(PIPE_V);
                TMRGSORT(v512, v510, v66);
                // pto: %large_pairs_v3_inline8634__ssa_v1
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v514 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v3_inline8634__ssa_v1
                ;
                uint64_t v515 = (uint64_t) v33;
                TASSIGN(v514, v515);
                pipe_barrier(PIPE_V);
                TMRGSORT(v514, v512, v67);
                // pto: %single_new_root_inline8707__ssa_v7
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v516 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline8707__ssa_v7
                ;
                uint64_t v517 = (uint64_t) v34;
                TASSIGN(v516, v517);
                pipe_barrier(PIPE_V);
                uint16_t v518 = static_cast<uint16_t>(v42);
                uint16_t v519 = static_cast<uint16_t>(v42);
                TEXTRACT(v516, v514, v518, v519);
                // pto: %single_new_root_inline8707__ssa_v7_mv
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v520 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline8707__ssa_v7_mv
                ;
                uint64_t v521 = (uint64_t) v36;
                TASSIGN(v520, v521);
                pipe_barrier(PIPE_V);
                TMOV(v520, v516);
              };
            };
            // pto: %173
            ;
            if (v185 < v58) {
              // pto: %174
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v522;
              // pto: %174
              ;
              uint64_t v523 = (uint64_t) v28;
              TASSIGN(v522, v523);
              pipe_barrier(PIPE_V);
              TMOV(v522, v106);
            } else {
              // pto: %single_old_root_inline8772__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v524 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_old_root_inline8772__ssa_v1
              ;
              uint64_t v525 = (uint64_t) v35;
              TASSIGN(v524, v525);
              pipe_barrier(PIPE_V);
              uint16_t v526 = static_cast<uint16_t>(v38);
              uint16_t v527 = static_cast<uint16_t>(v42);
              TEXTRACT(v524, v96, v526, v527);
              // pto: %single_merge_tmp_inline8629__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v528 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
              // pto: %single_merge_tmp_inline8629__ssa_v1
              ;
              uint64_t v529 = (uint64_t) v32;
              TASSIGN(v528, v529);
              // pto: %single_merged_inline8773__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v530 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
              // pto: %single_merged_inline8773__ssa_v1
              ;
              uint64_t v531 = (uint64_t) v33;
              TASSIGN(v530, v531);
              pipe_barrier(PIPE_V);
              TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, false>(v530, v29, v528, v106, v524);
              // pto: %single_next_root_inline8838__ssa_v1
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v532 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_next_root_inline8838__ssa_v1
              ;
              uint64_t v533 = (uint64_t) v32;
              TASSIGN(v532, v533);
              pipe_barrier(PIPE_V);
              uint16_t v534 = static_cast<uint16_t>(v42);
              uint16_t v535 = static_cast<uint16_t>(v42);
              TEXTRACT(v532, v530, v534, v535);
              // pto: %176
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v536;
              // pto: %176
              ;
              uint64_t v537 = (uint64_t) v28;
              TASSIGN(v536, v537);
              pipe_barrier(PIPE_V);
              TMOV(v536, v532);
            };
          };
          // pto: %178
          ;
          int64_t v538 = (int64_t) ((uint64_t) v187 + (uint64_t) v58);
          // pto: %182
          ;
          int64_t v539 = v538 < v258 ? v538 : v258;
          // pto: %183, %180
          ;
          int64_t v540 = (v7)[(int64_t) ((uint64_t) v158 + (uint64_t) v539)];
          // pto: %184, %185
          ;
          int64_t v541 = (int64_t) ((uint64_t) v540 + (uint64_t) v54) / v55;
          // pto: %187
          ;
          int64_t v542 = v164 < v541 ? v164 : v541;
          // pto: %188
          ;
          int64_t v543 = v542 < v44 ? v542 : v44;
          // pto: %189
          ;
          int64_t v544 = v543 < v42 ? v42 : v543;
          // pto: %190
          ;
          int64_t v545 = (int64_t) ((uint64_t) v544 - (uint64_t) v254);
          // pto: %191
          ;
          int64_t v546 = v545 < v255 ? v545 : v255;
          // pto: %192
          ;
          int64_t v547 = v546 < v42 ? v42 : v546;
          // pto: %193, %179, %194
          ;
          if (v547 > v42 & v538 < v160) {
            // pto: %single_segment_data_inline8739__ssa_v2
            ;
            Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v548 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
            // pto: %single_segment_data_inline8739__ssa_v2
            ;
            uint64_t v549 = (uint64_t) v32;
            TASSIGN(v548, v549);
            pipe_barrier(PIPE_V);
            uint16_t v550 = static_cast<uint16_t>(v58);
            uint16_t v551 = static_cast<uint16_t>(v42);
            TEXTRACT(v548, v256, v550, v551);
            // pto: %195
            ;
            int32_t v552 = (int32_t) v254;
            // pto: %196
            ;
            if (v547 <= v62) {
              // pto: %t__ci_tmp_v6
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v553 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
              // pto: %t__ci_tmp_v6
              ;
              uint64_t v554 = (uint64_t) v34;
              TASSIGN(v553, v554);
              // pto: %t__tmp_v530
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v555 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v530
              ;
              uint64_t v556 = (uint64_t) v33;
              TASSIGN(v555, v556);
              // pto: %197
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v557;
              TRESHAPE(v557, v553);
              // pto: %198
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v558;
              TRESHAPE(v558, v555);
              TCI<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v558, v64, v557);
              // pto: %tiny_indices_inline8686__ssa_v2
              ;
              Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v559 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %tiny_indices_inline8686__ssa_v2
              ;
              uint64_t v560 = (uint64_t) v34;
              TASSIGN(v559, v560);
              pipe_barrier(PIPE_V);
              TADDS(v559, v555, v552);
              // pto: %tiny_tile_inline8740__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v561 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %tiny_tile_inline8740__ssa_v2
              ;
              uint64_t v562 = (uint64_t) v33;
              TASSIGN(v561, v562);
              pipe_barrier(PIPE_V);
              uint16_t v563 = static_cast<uint16_t>(v42);
              uint16_t v564 = static_cast<uint16_t>(v42);
              TEXTRACT(v561, v548, v563, v564);
              v561.SetValidShape(v38, v547);
              // pto: %t__tmp_v531
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v565 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v531
              ;
              uint64_t v566 = (uint64_t) v33;
              TASSIGN(v565, v566);
              pipe_barrier(PIPE_V);
              TFILLPAD<pto::TFillPadMode::InPlace>(v565, v561);
              // pto: %tiny_scores_inline8746__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v567 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v62);
              // pto: %tiny_scores_inline8746__ssa_v2
              ;
              uint64_t v568 = (uint64_t) v35;
              TASSIGN(v567, v568);
              pipe_barrier(PIPE_V);
              TMAXS(v567, v565, v56);
              // pto: %t__tmp_v532
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v569 = Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v62);
              // pto: %t__tmp_v532
              ;
              uint64_t v570 = (uint64_t) v34;
              TASSIGN(v569, v570);
              // pto: %tiny_pairs_inline8653__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v571 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_inline8653__ssa_v2
              ;
              uint64_t v572 = (uint64_t) v33;
              TASSIGN(v571, v572);
              // pto: %199
              ;
              Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v573;
              TRESHAPE(v573, v567);
              // pto: %200
              ;
              Tile<TileType::Vec, uint32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v574;
              TRESHAPE(v574, v569);
              // pto: %201
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v575;
              TRESHAPE(v575, v571);
              pipe_barrier(PIPE_V);
              TSORT32(v575, v573, v574);
              // pto: %tiny_pairs_v1_inline8748__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v576 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_v1_inline8748__ssa_v2
              ;
              uint64_t v577 = (uint64_t) v34;
              TASSIGN(v576, v577);
              pipe_barrier(PIPE_V);
              TMRGSORT(v576, v571, v65);
              // pto: %tiny_pairs_v2_inline8749__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v578 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
              // pto: %tiny_pairs_v2_inline8749__ssa_v2
              ;
              uint64_t v579 = (uint64_t) v33;
              TASSIGN(v578, v579);
              pipe_barrier(PIPE_V);
              TMRGSORT(v578, v576, v66);
              // pto: %single_new_root_inline8707__ssa_v10
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v580 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_new_root_inline8707__ssa_v10
              ;
              uint64_t v581 = (uint64_t) v36;
              TASSIGN(v580, v581);
              pipe_barrier(PIPE_V);
              uint16_t v582 = static_cast<uint16_t>(v42);
              uint16_t v583 = static_cast<uint16_t>(v42);
              TEXTRACT(v580, v578, v582, v583);
            } else {
              // pto: %202
              ;
              if (v547 <= v41) {
                // pto: %t__ci_tmp_v7
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v584 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
                // pto: %t__ci_tmp_v7
                ;
                uint64_t v585 = (uint64_t) v34;
                TASSIGN(v584, v585);
                // pto: %t__tmp_v533
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v586 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v533
                ;
                uint64_t v587 = (uint64_t) v33;
                TASSIGN(v586, v587);
                // pto: %203
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v588;
                TRESHAPE(v588, v584);
                // pto: %204
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v589;
                TRESHAPE(v589, v586);
                TCI<Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v589, v64, v588);
                // pto: %small_indices_inline8657__ssa_v2
                ;
                Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v590 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %small_indices_inline8657__ssa_v2
                ;
                uint64_t v591 = (uint64_t) v34;
                TASSIGN(v590, v591);
                pipe_barrier(PIPE_V);
                TADDS(v590, v586, v552);
                // pto: %small_tile_inline8753__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v592 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %small_tile_inline8753__ssa_v2
                ;
                uint64_t v593 = (uint64_t) v33;
                TASSIGN(v592, v593);
                pipe_barrier(PIPE_V);
                uint16_t v594 = static_cast<uint16_t>(v42);
                uint16_t v595 = static_cast<uint16_t>(v42);
                TEXTRACT(v592, v548, v594, v595);
                v592.SetValidShape(v38, v547);
                // pto: %t__tmp_v534
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v596 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v534
                ;
                uint64_t v597 = (uint64_t) v33;
                TASSIGN(v596, v597);
                pipe_barrier(PIPE_V);
                TFILLPAD<pto::TFillPadMode::InPlace>(v596, v592);
                // pto: %small_scores_inline8687__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v598 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_scores_inline8687__ssa_v2
                ;
                uint64_t v599 = (uint64_t) v35;
                TASSIGN(v598, v599);
                pipe_barrier(PIPE_V);
                TMAXS(v598, v596, v56);
                // pto: %t__tmp_v535
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v600 = Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %t__tmp_v535
                ;
                uint64_t v601 = (uint64_t) v34;
                TASSIGN(v600, v601);
                // pto: %small_pairs_inline8756__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v602 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_inline8756__ssa_v2
                ;
                uint64_t v603 = (uint64_t) v33;
                TASSIGN(v602, v603);
                // pto: %205
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v604;
                TRESHAPE(v604, v598);
                // pto: %206
                ;
                Tile<TileType::Vec, uint32_t, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v605;
                TRESHAPE(v605, v600);
                // pto: %207
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v606;
                TRESHAPE(v606, v602);
                pipe_barrier(PIPE_V);
                TSORT32(v606, v604, v605);
                // pto: %small_pairs_v1_inline8757__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v607 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_v1_inline8757__ssa_v2
                ;
                uint64_t v608 = (uint64_t) v34;
                TASSIGN(v607, v608);
                pipe_barrier(PIPE_V);
                TMRGSORT(v607, v602, v65);
                // pto: %small_pairs_v2_inline8780__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v609 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_pairs_v2_inline8780__ssa_v2
                ;
                uint64_t v610 = (uint64_t) v33;
                TASSIGN(v609, v610);
                pipe_barrier(PIPE_V);
                TMRGSORT(v609, v607, v66);
                // pto: %small_left_inline8758__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v611 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_left_inline8758__ssa_v2
                ;
                uint64_t v612 = (uint64_t) v33;
                TASSIGN(v611, v612);
                // pto: %208
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v613;
                // pto: %208
                ;
                uint64_t v614 = (uint64_t) v33;
                TASSIGN(v613, v614);
                // pto: %small_right_inline8719__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v615 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v41);
                // pto: %small_right_inline8719__ssa_v2
                ;
                uint64_t v616 = (uint64_t) v37;
                TASSIGN(v615, v616);
                // pto: %209
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v617;
                // pto: %209
                ;
                uint64_t v618 = (uint64_t) v37;
                TASSIGN(v617, v618);
                // pto: %small_tmp_inline8788__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v619 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %small_tmp_inline8788__ssa_v2
                ;
                uint64_t v620 = (uint64_t) v34;
                TASSIGN(v619, v620);
                // pto: %small_merged_inline8762__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v621 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %small_merged_inline8762__ssa_v2
                ;
                uint64_t v622 = (uint64_t) v35;
                TASSIGN(v621, v622);
                pipe_barrier(PIPE_V);
                TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v621, v29, v619, v613, v617);
                // pto: %single_new_root_inline8707__ssa_v11
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v623 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline8707__ssa_v11
                ;
                uint64_t v624 = (uint64_t) v36;
                TASSIGN(v623, v624);
                pipe_barrier(PIPE_V);
                uint16_t v625 = static_cast<uint16_t>(v42);
                uint16_t v626 = static_cast<uint16_t>(v42);
                TEXTRACT(v623, v621, v625, v626);
              } else {
                // pto: %t__ci_tmp_v8
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v627 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v63);
                // pto: %t__ci_tmp_v8
                ;
                uint64_t v628 = (uint64_t) v34;
                TASSIGN(v627, v628);
                // pto: %t__tmp_v536
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v629 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v536
                ;
                uint64_t v630 = (uint64_t) v33;
                TASSIGN(v629, v630);
                // pto: %211
                ;
                Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v631;
                TRESHAPE(v631, v627);
                // pto: %212
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v632;
                TRESHAPE(v632, v629);
                TCI<Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v632, v64, v631);
                // pto: %large_indices_inline8763__ssa_v2
                ;
                Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v633 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %large_indices_inline8763__ssa_v2
                ;
                uint64_t v634 = (uint64_t) v33;
                TASSIGN(v633, v634);
                pipe_barrier(PIPE_V);
                TADDS(v633, v629, v552);
                // pto: %large_tile_inline8701__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v635 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %large_tile_inline8701__ssa_v2
                ;
                uint64_t v636 = (uint64_t) v34;
                TASSIGN(v635, v636);
                uint16_t v637 = static_cast<uint16_t>(v42);
                uint16_t v638 = static_cast<uint16_t>(v42);
                TEXTRACT(v635, v548, v637, v638);
                v635.SetValidShape(v38, v547);
                // pto: %t__tmp_v537
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v639 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v537
                ;
                uint64_t v640 = (uint64_t) v32;
                TASSIGN(v639, v640);
                pipe_barrier(PIPE_V);
                TFILLPAD(v639, v635);
                // pto: %large_scores_inline8679__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v641 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v59);
                // pto: %large_scores_inline8679__ssa_v2
                ;
                uint64_t v642 = (uint64_t) v34;
                TASSIGN(v641, v642);
                pipe_barrier(PIPE_V);
                TMAXS(v641, v639, v56);
                // pto: %t__tmp_v538
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v643 = Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
                // pto: %t__tmp_v538
                ;
                uint64_t v644 = (uint64_t) v33;
                TASSIGN(v643, v644);
                // pto: %large_pairs_inline8767__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v645 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_inline8767__ssa_v2
                ;
                uint64_t v646 = (uint64_t) v32;
                TASSIGN(v645, v646);
                // pto: %213
                ;
                Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v647;
                TRESHAPE(v647, v641);
                // pto: %214
                ;
                Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v648;
                TRESHAPE(v648, v643);
                // pto: %215
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v649;
                TRESHAPE(v649, v645);
                pipe_barrier(PIPE_V);
                TSORT32(v649, v647, v648);
                // pto: %large_pairs_v1_inline8769__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v650 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v1_inline8769__ssa_v2
                ;
                uint64_t v651 = (uint64_t) v33;
                TASSIGN(v650, v651);
                pipe_barrier(PIPE_V);
                TMRGSORT(v650, v645, v65);
                // pto: %large_pairs_v2_inline8622__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v652 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v2_inline8622__ssa_v2
                ;
                uint64_t v653 = (uint64_t) v32;
                TASSIGN(v652, v653);
                pipe_barrier(PIPE_V);
                TMRGSORT(v652, v650, v66);
                // pto: %large_pairs_v3_inline8634__ssa_v2
                ;
                Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v654 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v38, v61);
                // pto: %large_pairs_v3_inline8634__ssa_v2
                ;
                uint64_t v655 = (uint64_t) v33;
                TASSIGN(v654, v655);
                pipe_barrier(PIPE_V);
                TMRGSORT(v654, v652, v67);
                // pto: %single_new_root_inline8707__ssa_v12
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v656 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline8707__ssa_v12
                ;
                uint64_t v657 = (uint64_t) v34;
                TASSIGN(v656, v657);
                pipe_barrier(PIPE_V);
                uint16_t v658 = static_cast<uint16_t>(v42);
                uint16_t v659 = static_cast<uint16_t>(v42);
                TEXTRACT(v656, v654, v658, v659);
                // pto: %single_new_root_inline8707__ssa_v12_mv
                ;
                Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v660 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
                // pto: %single_new_root_inline8707__ssa_v12_mv
                ;
                uint64_t v661 = (uint64_t) v36;
                TASSIGN(v660, v661);
                pipe_barrier(PIPE_V);
                TMOV(v660, v656);
              };
            };
            // pto: %216
            ;
            if (v185 < v58) {
              // pto: %217
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v662;
              // pto: %217
              ;
              uint64_t v663 = (uint64_t) v27;
              TASSIGN(v662, v663);
              pipe_barrier(PIPE_V);
              TMOV(v662, v114);
            } else {
              // pto: %single_old_root_inline8772__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v664 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_old_root_inline8772__ssa_v2
              ;
              uint64_t v665 = (uint64_t) v35;
              TASSIGN(v664, v665);
              pipe_barrier(PIPE_V);
              uint16_t v666 = static_cast<uint16_t>(v58);
              uint16_t v667 = static_cast<uint16_t>(v42);
              TEXTRACT(v664, v104, v666, v667);
              // pto: %single_merge_tmp_inline8629__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v668 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
              // pto: %single_merge_tmp_inline8629__ssa_v2
              ;
              uint64_t v669 = (uint64_t) v32;
              TASSIGN(v668, v669);
              // pto: %single_merged_inline8773__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v670 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v59);
              // pto: %single_merged_inline8773__ssa_v2
              ;
              uint64_t v671 = (uint64_t) v33;
              TASSIGN(v670, v671);
              pipe_barrier(PIPE_V);
              TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, false>(v670, v29, v668, v114, v664);
              // pto: %single_next_root_inline8838__ssa_v2
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v672 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
              // pto: %single_next_root_inline8838__ssa_v2
              ;
              uint64_t v673 = (uint64_t) v32;
              TASSIGN(v672, v673);
              pipe_barrier(PIPE_V);
              uint16_t v674 = static_cast<uint16_t>(v42);
              uint16_t v675 = static_cast<uint16_t>(v42);
              TEXTRACT(v672, v670, v674, v675);
              // pto: %219
              ;
              Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v676;
              // pto: %219
              ;
              uint64_t v677 = (uint64_t) v27;
              TASSIGN(v676, v677);
              pipe_barrier(PIPE_V);
              TMOV(v676, v672);
            };
          };
        };
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      };
      // pto: %220
      ;
      int64_t v678 = (int64_t) ((uint64_t) v150 * (uint64_t) v48);
      // pto: %221
      ;
      if (v678 < v160) {
        // pto: %single_root_inline8734__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v679 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_root_inline8734__ssa_v0
        ;
        uint64_t v680 = (uint64_t) v31;
        TASSIGN(v679, v680);
        pipe_barrier(PIPE_V);
        uint16_t v681 = static_cast<uint16_t>(v42);
        uint16_t v682 = static_cast<uint16_t>(v42);
        TEXTRACT(v679, v181, v681, v682);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %224
        ;
        uint64_t v683 = (uint64_t) v154;
        // pto: %222, %223, %224
        ;
        int64_t v684 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v158 + (uint64_t) v678) * (uint64_t) v60) + v683);
        // pto: %225
        ;
        int64_t v685 = v684 < v42 ? v42 : v684;
        // pto: %pair_arena_inline2969_inline5683__ssa_v0_pview
        ;
        __gm__ float* v686 = PTOAS__GLOBAL_TENSOR_DATA(v93);
        // pto: %pair_arena_inline2969_inline5683__ssa_v0_pview
        ;
        const int64_t v687 = 0;
        // pto: %pair_arena_inline2969_inline5683__ssa_v0_pview
        ;
        const int64_t v688 = 1024;
        // pto: %pair_arena_inline2969_inline5683__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 1024> v689 = pto::Shape<1, 1, 1, 1, 1024>();
        // pto: %pair_arena_inline2969_inline5683__ssa_v0_pview
        ;
        pto::Stride<1024, 1024, 1024, 1024, 1> v690 = pto::Stride<1024, 1024, 1024, 1024, 1>();
        // pto: %pair_arena_inline2969_inline5683__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v691 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v686 + (v687 + v685 * v688), v689, v690);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v691, v679);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      // pto: %227
      ;
      int64_t v692 = (int64_t) ((uint64_t) v678 + (uint64_t) v38);
      // pto: %228
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      if (v692 < v160) {
        // pto: %single_root_inline8734__ssa_v1
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v693 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_root_inline8734__ssa_v1
        ;
        uint64_t v694 = (uint64_t) v31;
        TASSIGN(v693, v694);
        pipe_barrier(PIPE_V);
        uint16_t v695 = static_cast<uint16_t>(v38);
        uint16_t v696 = static_cast<uint16_t>(v42);
        TEXTRACT(v693, v181, v695, v696);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        // pto: %231
        ;
        uint64_t v697 = (uint64_t) v154;
        // pto: %229, %230, %231
        ;
        int64_t v698 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v158 + (uint64_t) v692) * (uint64_t) v60) + v697);
        // pto: %232
        ;
        int64_t v699 = v698 < v42 ? v42 : v698;
        // pto: %233
        ;
        __gm__ float* v700 = PTOAS__GLOBAL_TENSOR_DATA(v93);
        // pto: %233
        ;
        const int64_t v701 = 0;
        // pto: %233
        ;
        const int64_t v702 = 1024;
        // pto: %233
        ;
        pto::Shape<1, 1, 1, 1, 1024> v703 = pto::Shape<1, 1, 1, 1, 1024>();
        // pto: %233
        ;
        pto::Stride<1024, 1024, 1024, 1024, 1> v704 = pto::Stride<1024, 1024, 1024, 1024, 1>();
        // pto: %233
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v705 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v700 + (v701 + v699 * v702), v703, v704);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v705, v693);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      // pto: %235
      ;
      int64_t v706 = (int64_t) ((uint64_t) v678 + (uint64_t) v58);
      // pto: %236
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      if (v706 < v160) {
        // pto: %single_root_inline8734__ssa_v2
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v707 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v38, v41);
        // pto: %single_root_inline8734__ssa_v2
        ;
        uint64_t v708 = (uint64_t) v31;
        TASSIGN(v707, v708);
        pipe_barrier(PIPE_V);
        uint16_t v709 = static_cast<uint16_t>(v58);
        uint16_t v710 = static_cast<uint16_t>(v42);
        TEXTRACT(v707, v181, v709, v710);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        // pto: %239
        ;
        uint64_t v711 = (uint64_t) v154;
        // pto: %237, %238, %239
        ;
        int64_t v712 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v158 + (uint64_t) v706) * (uint64_t) v60) + v711);
        // pto: %240
        ;
        int64_t v713 = v712 < v42 ? v42 : v712;
        // pto: %241
        ;
        __gm__ float* v714 = PTOAS__GLOBAL_TENSOR_DATA(v93);
        // pto: %241
        ;
        const int64_t v715 = 0;
        // pto: %241
        ;
        const int64_t v716 = 1024;
        // pto: %241
        ;
        pto::Shape<1, 1, 1, 1, 1024> v717 = pto::Shape<1, 1, 1, 1, 1024>();
        // pto: %241
        ;
        pto::Stride<1024, 1024, 1024, 1024, 1> v718 = pto::Stride<1024, 1024, 1024, 1024, 1>();
        // pto: %241
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v719 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 1024>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v714 + (v715 + v713 * v716), v717, v718);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v719, v707);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    };
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}