#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void input_rms_fused(__gm__ bfloat16_t* v1, __gm__ float* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, int64_t v5, int32_t v6, int32_t v7) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c24608_i64
  const int64_t v8 = 24608;
  // pto: %c8224_i64
  const int64_t v9 = 8224;
  const int64_t v10 = 32800;
  const int64_t v11 = 28704;
  const int64_t v12 = 26656;
  const int64_t v13 = 25632;
  const int64_t v14 = 25120;
  const int64_t v15 = 24864;
  // pto: %c32_i64
  const int64_t v16 = 32;
  // pto: %c0_i64
  const int64_t v17 = 0;
  // pto: %c4096_index
  const int64_t v18 = 4096;
  // pto: %c1_index
  const int64_t v19 = 1;
  // pto: %c8_index
  const int64_t v20 = 8;
  // pto: %c0_index
  const int64_t v21 = 0;
  // pto: %c2048_index
  const int64_t v22 = 2048;
  // pto: %c1024_index
  const int64_t v23 = 1024;
  // pto: %c512_index
  const int64_t v24 = 512;
  // pto: %c256_index
  const int64_t v25 = 256;
  // pto: %c128_index
  const int64_t v26 = 128;
  // pto: %c64_index
  const int64_t v27 = 64;
  // pto: %cst_20
  const float v28 = 1.0f;
  // pto: %cst_21
  const float v29 = 2.44140625E-4f;
  // pto: %cst_22
  const float v30 = 9.99999997E-7f;
  // pto: %c8388608_index
  const int64_t v31 = 8388608;
  // pto: %c2139095040_i64
  const int64_t v32 = 2139095040;
  // pto: %c8388608_i64
  const int64_t v33 = 8388608;
  // pto: %c2_index
  const int64_t v34 = 2;
  // pto: %c2_i64
  const int64_t v35 = 2;
  // pto: %c152_i64
  const int64_t v36 = 152;
  // pto: %c1_i64
  const int64_t v37 = 1;
  // pto: %c0_i32
  const int32_t v38 = 0;
  // pto: %mixed__rv_v2_view
  const int64_t v39 = 1;
  // pto: %mixed__rv_v2_view
  const int64_t v40 = 1;
  // pto: %mixed__rv_v2_view
  const int64_t v41 = 1;
  // pto: %mixed__rv_v2_view
  int64_t v42 = (int64_t) v5;
  // pto: %mixed__rv_v2_view
  int64_t v43 = v42 * v18;
  // pto: %mixed__rv_v2_view
  int64_t v44 = v41 * v43;
  // pto: %mixed__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v45 = pto::Shape<1, 1, 1, -1, -1>(v39, v40, v41, v42, v18);
  // pto: %mixed__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v40 * v44, v44, v43, v18, v19);
  // pto: %mixed__rv_v2_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v47 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v45, v46);
  // pto: %rstd__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %rstd__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %rstd__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %rstd__ssa_v0_view
  int64_t v51 = (int64_t) v5;
  // pto: %rstd__ssa_v0_view
  int64_t v52 = v51 * v20;
  // pto: %rstd__ssa_v0_view
  int64_t v53 = v50 * v52;
  // pto: %rstd__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v54 = pto::Shape<1, 1, 1, -1, -1>(v48, v49, v50, v51, v20);
  // pto: %rstd__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v55 = pto::Stride<-1, -1, -1, -1, -1>(v49 * v53, v53, v52, v20, v19);
  // pto: %rstd__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v56 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v54, v55);
  // pto: %weight_view_inline1233__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %weight_view_inline1233__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %weight_view_inline1233__ssa_v0_view
  const int64_t v59 = 1;
  // pto: %weight_view_inline1233__ssa_v0_view
  int64_t v60 = v19 * v18;
  // pto: %weight_view_inline1233__ssa_v0_view
  int64_t v61 = v59 * v60;
  // pto: %weight_view_inline1233__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v62 = pto::Shape<1, 1, 1, -1, -1>(v57, v58, v59, v19, v18);
  // pto: %weight_view_inline1233__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v63 = pto::Stride<-1, -1, -1, -1, -1>(v58 * v61, v61, v60, v18, v19);
  // pto: %weight_view_inline1233__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v64 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v62, v63);
  // pto: %normed__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %normed__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %normed__ssa_v0_view
  int64_t v68 = (int64_t) v5;
  // pto: %normed__ssa_v0_view
  int64_t v69 = v68 * v18;
  // pto: %normed__ssa_v0_view
  int64_t v70 = v67 * v69;
  // pto: %normed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v71 = pto::Shape<1, 1, 1, -1, -1>(v65, v66, v67, v68, v18);
  // pto: %normed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v66 * v70, v70, v69, v18, v19);
  // pto: %normed__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v71, v72);
  // pto: %row_inline1229__ssa_v0
  int64_t v74 = (int64_t) v6;
  // pto: %raw_inline1223__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v18);
  // pto: %raw_inline1223__ssa_v0
  uint64_t v76 = (uint64_t) v8;
  TASSIGN(v75, v76);
  // pto: %2
  int64_t v77 = v74 < v21 ? v21 : v74;
  // pto: %mixed__rv_v2_pview
  __gm__ bfloat16_t* v78 = PTOAS__GLOBAL_TENSOR_DATA(v47);
  // pto: %mixed__rv_v2_pview
  const int64_t v79 = 0;
  // pto: %mixed__rv_v2_pview
  const int64_t v80 = 4096;
  // pto: %mixed__rv_v2_pview
  pto::Shape<1, 1, 1, 1, 4096> v81 = pto::Shape<1, 1, 1, 1, 4096>();
  // pto: %mixed__rv_v2_pview
  pto::Stride<4096, 4096, 4096, 4096, 1> v82 = pto::Stride<4096, 4096, 4096, 4096, 1>();
  // pto: %mixed__rv_v2_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v83 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v78 + (v79 + v77 * v80), v81, v82);
  TLOAD(v75, v83);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %wide_inline1222__ssa_v0
  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v84 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v18);
  // pto: %wide_inline1222__ssa_v0
  uint64_t v85 = (uint64_t) v9;
  TASSIGN(v84, v85);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  RoundMode v86 = RoundMode::CAST_ROUND;
  SaturationMode v87 = SaturationMode::ON;
  TCVT(v84, v75, v86, v87);
  // pto: %square_inline1224__ssa_v0
  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v88 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v18);
  // pto: %square_inline1224__ssa_v0
  uint64_t v89 = (uint64_t) v8;
  TASSIGN(v88, v89);
  pipe_barrier(PIPE_V);
  TMUL(v88, v84, v84);
  // pto: %t__tmp_v63
  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v90 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v22);
  // pto: %t__tmp_v63
  uint64_t v91 = (uint64_t) v8;
  TASSIGN(v90, v91);
  // pto: %slice_view
  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v92;
  // pto: %slice_view
  uint64_t v93 = (uint64_t) v8;
  TASSIGN(v92, v93);
  // pto: %t__tmp_v64
  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v94 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v22);
  // pto: %t__tmp_v64
  uint64_t v95 = (uint64_t) v10;
  TASSIGN(v94, v95);
  // pto: %3
  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v96;
  // pto: %3
  uint64_t v97 = (uint64_t) v10;
  TASSIGN(v96, v97);
  // pto: %fold2048_inline1217__ssa_v0
  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v22);
  // pto: %fold2048_inline1217__ssa_v0
  uint64_t v99 = (uint64_t) v8;
  TASSIGN(v98, v99);
  pipe_barrier(PIPE_V);
  TADD(v98, v92, v96);
  // pto: %t__tmp_v65
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v23);
  // pto: %t__tmp_v65
  uint64_t v101 = (uint64_t) v8;
  TASSIGN(v100, v101);
  // pto: %4
  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v102;
  // pto: %4
  uint64_t v103 = (uint64_t) v8;
  TASSIGN(v102, v103);
  // pto: %t__tmp_v66
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v23);
  // pto: %t__tmp_v66
  uint64_t v105 = (uint64_t) v11;
  TASSIGN(v104, v105);
  // pto: %5
  Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v106;
  // pto: %5
  uint64_t v107 = (uint64_t) v11;
  TASSIGN(v106, v107);
  // pto: %fold1024_inline1231__ssa_v0
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v23);
  // pto: %fold1024_inline1231__ssa_v0
  uint64_t v109 = (uint64_t) v8;
  TASSIGN(v108, v109);
  pipe_barrier(PIPE_V);
  TADD(v108, v102, v106);
  // pto: %t__tmp_v67
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v24);
  // pto: %t__tmp_v67
  uint64_t v111 = (uint64_t) v8;
  TASSIGN(v110, v111);
  // pto: %6
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v112;
  // pto: %6
  uint64_t v113 = (uint64_t) v8;
  TASSIGN(v112, v113);
  // pto: %t__tmp_v68
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v24);
  // pto: %t__tmp_v68
  uint64_t v115 = (uint64_t) v12;
  TASSIGN(v114, v115);
  // pto: %7
  Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116;
  // pto: %7
  uint64_t v117 = (uint64_t) v12;
  TASSIGN(v116, v117);
  // pto: %fold512_inline1218__ssa_v0
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v24);
  // pto: %fold512_inline1218__ssa_v0
  uint64_t v119 = (uint64_t) v8;
  TASSIGN(v118, v119);
  pipe_barrier(PIPE_V);
  TADD(v118, v112, v116);
  // pto: %t__tmp_v69
  Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v25);
  // pto: %t__tmp_v69
  uint64_t v121 = (uint64_t) v8;
  TASSIGN(v120, v121);
  // pto: %8
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v122;
  // pto: %8
  uint64_t v123 = (uint64_t) v8;
  TASSIGN(v122, v123);
  // pto: %t__tmp_v70
  Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v25);
  // pto: %t__tmp_v70
  uint64_t v125 = (uint64_t) v13;
  TASSIGN(v124, v125);
  // pto: %9
  Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v126;
  // pto: %9
  uint64_t v127 = (uint64_t) v13;
  TASSIGN(v126, v127);
  // pto: %fold256_inline1234__ssa_v0
  Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v128 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v25);
  // pto: %fold256_inline1234__ssa_v0
  uint64_t v129 = (uint64_t) v8;
  TASSIGN(v128, v129);
  pipe_barrier(PIPE_V);
  TADD(v128, v122, v126);
  // pto: %t__tmp_v71
  Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v26);
  // pto: %t__tmp_v71
  uint64_t v131 = (uint64_t) v8;
  TASSIGN(v130, v131);
  // pto: %10
  Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v132;
  // pto: %10
  uint64_t v133 = (uint64_t) v8;
  TASSIGN(v132, v133);
  // pto: %t__tmp_v72
  Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v26);
  // pto: %t__tmp_v72
  uint64_t v135 = (uint64_t) v14;
  TASSIGN(v134, v135);
  // pto: %11
  Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v136;
  // pto: %11
  uint64_t v137 = (uint64_t) v14;
  TASSIGN(v136, v137);
  // pto: %fold128_inline1220__ssa_v0
  Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v26);
  // pto: %fold128_inline1220__ssa_v0
  uint64_t v139 = (uint64_t) v8;
  TASSIGN(v138, v139);
  pipe_barrier(PIPE_V);
  TADD(v138, v132, v136);
  // pto: %t__tmp_v73
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v140 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v27);
  // pto: %t__tmp_v73
  uint64_t v141 = (uint64_t) v8;
  TASSIGN(v140, v141);
  // pto: %12
  Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v142;
  // pto: %12
  uint64_t v143 = (uint64_t) v8;
  TASSIGN(v142, v143);
  // pto: %t__tmp_v74
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v144 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v27);
  // pto: %t__tmp_v74
  uint64_t v145 = (uint64_t) v15;
  TASSIGN(v144, v145);
  // pto: %13
  Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v146;
  // pto: %13
  uint64_t v147 = (uint64_t) v15;
  TASSIGN(v146, v147);
  // pto: %fold64_inline1211__ssa_v0
  Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v148 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v27);
  // pto: %fold64_inline1211__ssa_v0
  uint64_t v149 = (uint64_t) v16;
  TASSIGN(v148, v149);
  pipe_barrier(PIPE_V);
  TADD(v148, v142, v146);
  // pto: %t__tmp_v75
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v150 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v27);
  // pto: %t__tmp_v75
  uint64_t v151 = (uint64_t) v8;
  TASSIGN(v150, v151);
  // pto: %repeated_inline1237__ssa_v0
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v152 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v27);
  // pto: %repeated_inline1237__ssa_v0
  uint64_t v153 = (uint64_t) v8;
  TASSIGN(v152, v153);
  pipe_barrier(PIPE_V);
  TCOLEXPAND(v152, v148);
  // pto: %t__tmp_v76
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v154 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v27);
  // pto: %t__tmp_v76
  uint64_t v155 = (uint64_t) v16;
  TASSIGN(v154, v155);
  // pto: %total_inline1242__ssa_v0
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v156 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v20, v19);
  // pto: %total_inline1242__ssa_v0
  uint64_t v157 = (uint64_t) v17;
  TASSIGN(v156, v157);
  pipe_barrier(PIPE_V);
  TROWSUM(v156, v152, v154);
  set_flag(PIPE_V, PIPE_S, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
  // pto: %total_scalar_inline1239__ssa_v0
  float v158 = v156.GetValue(v21);
  // pto: %t__tile
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v159 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v20);
  // pto: %t__tile
  uint64_t v160 = (uint64_t) v8;
  TASSIGN(v159, v160);
  pipe_barrier(PIPE_V);
  TEXPANDS(v159, v28);
  // pto: %total_vector_inline1241__tile
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v20);
  // pto: %total_vector_inline1241__tile
  uint64_t v162 = (uint64_t) v8;
  TASSIGN(v161, v162);
  pipe_barrier(PIPE_V);
  TMULS(v161, v159, v158);
  // pto: %0
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v163 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v20);
  // pto: %0
  uint64_t v164 = (uint64_t) v8;
  TASSIGN(v163, v164);
  pipe_barrier(PIPE_V);
  TMULS(v163, v161, v29);
  // pto: %variance_inline1225__tile
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v20);
  // pto: %variance_inline1225__tile
  uint64_t v166 = (uint64_t) v8;
  TASSIGN(v165, v166);
  pipe_barrier(PIPE_V);
  TADDS(v165, v163, v30);
  set_flag(PIPE_V, PIPE_S, EVENT_ID1);
  // pto: %root_value_inline1210__tile
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v20);
  // pto: %root_value_inline1210__tile
  uint64_t v168 = (uint64_t) v16;
  TASSIGN(v167, v168);
  pipe_barrier(PIPE_V);
  TSQRT(v167, v165);
  set_flag(PIPE_V, PIPE_S, EVENT_ID2);
  // pto: %variance_bits_inline1219__tile
  Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v20);
  // pto: %variance_bits_inline1219__tile
  uint64_t v170 = (uint64_t) v8;
  TASSIGN(v169, v170);
  // pto: %approx_bits_inline1227__tile
  Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v171 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v20);
  // pto: %approx_bits_inline1227__tile
  uint64_t v172 = (uint64_t) v16;
  TASSIGN(v171, v172);
  wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
  // pto: %14
  int32_t v173 = v169.GetValue(v21);
  set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  // pto: %15
  int64_t v174 = (int64_t) v173;
  wait_flag(PIPE_V, PIPE_S, EVENT_ID2);
  // pto: %16
  int32_t v175 = v171.GetValue(v21);
  set_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
  // pto: %17
  int64_t v176 = (int64_t) v175;
  // pto: %19, %20, %21
  // pto: %y_bits_inline1212__phi_v7
  int64_t v177;
  if ((int64_t) v173 >= v31 & v174 < v32) {
    // pto: %22
    ;
    int64_t v178 = v174 / v33;
    // pto: %23, %24
    ;
    int64_t v179 = (int64_t) ((uint64_t) (v174 % v33) + (uint64_t) v33);
    // pto: %y_bits_inline1212__rv_v2
    ;
    int64_t v180;
    v180 = v176;
    for (int64_t v181 = v21; v181 < v34; v181 += v19) {
      // pto: %25
      ;
      int64_t v182 = v180 / v33;
      // pto: %26
      ;
      int64_t v183 = v180 % v33;
      // pto: %27, %28, %30
      ;
      int64_t v184 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v183 + (uint64_t) v33) * (uint64_t) v35) + (uint64_t) v19);
      // pto: %31
      ;
      int64_t v185 = (int64_t) ((uint64_t) v184 * (uint64_t) v184);
      // pto: %35, %33, %32, %34
      ;
      int64_t v186 = (int64_t) ((uint64_t) v179 << (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v178 - (uint64_t) ((int64_t) (uint64_t) v182 * (uint64_t) v35)) + (uint64_t) v36));
      // pto: %36
      ;
      uint64_t v187 = (uint64_t) v180;
      // pto: %36
      ;
      int64_t v188 = (int64_t) (v187 - (uint64_t) v37);
      // pto: %38, %39, %40, %42
      ;
      int64_t v189 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) (v188 % v33) + (uint64_t) v33) * (uint64_t) v35) + (uint64_t) v19);
      // pto: %43
      ;
      int64_t v190 = (int64_t) ((uint64_t) v189 * (uint64_t) v189);
      // pto: %47, %45, %37, %44, %46
      ;
      int64_t v191 = (int64_t) ((uint64_t) v179 << (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v178 - (uint64_t) ((int64_t) (uint64_t) (v188 / v33) * (uint64_t) v35)) + (uint64_t) v36));
      // pto: %52
      ;
      int64_t v192 = v180 % v35;
      // pto: %53
      ;
      bool v193 = v192 == v37;
      // pto: %49, %51, %54, %55
      ;
      // pto: %y_bits_inline1212__phi_v6
      ;
      int64_t v194;
      if (v185 < v186 | v186 == v185 & v193) {
        // pto: %56
        ;
        uint64_t v195 = (uint64_t) v180;
        // pto: %56
        ;
        v194 = (int64_t) (v195 + (uint64_t) v37);
      } else {
        // pto: %58, %60, %63, %64, %y_bits_inline1212__phi_v5
        ;
        int64_t v196 = v191 < v190 | v191 == v190 & v193 ? v188 : v180;
        v194 = v196;
      };
      v180 = v194;
    };
    v177 = v180;
  } else {
    v177 = v176;
  }
  // pto: %rounded_bits_inline1215__tile
  Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v197 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v20);
  // pto: %rounded_bits_inline1215__tile
  uint64_t v198 = (uint64_t) v8;
  TASSIGN(v197, v198);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
  pipe_barrier(PIPE_V);
  TEXPANDS(v197, v38);
  set_flag(PIPE_V, PIPE_S, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_S, EVENT_ID3);
  for (int64_t v199 = v21; v199 < v20; v199 += v19) {
    // pto: %66
    ;
    int32_t v200 = (int32_t) v177;
    v197.SetValue(v199, v200);
  }
  // pto: %rounded_root_inline1230__tile
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v20);
  // pto: %rounded_root_inline1230__tile
  uint64_t v202 = (uint64_t) v8;
  TASSIGN(v201, v202);
  // pto: %scalar_root_value_inline1202__tile
  float v203 = v201.GetValue(v21);
  set_flag(PIPE_S, PIPE_V, EVENT_ID1);
  // pto: %67
  float v204 = v28 / v203;
  // pto: %1
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v20);
  // pto: %1
  uint64_t v206 = (uint64_t) v8;
  TASSIGN(v205, v206);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
  TEXPANDS(v205, v28);
  // pto: %inverse_inline1221__tile
  Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v20);
  // pto: %inverse_inline1221__tile
  uint64_t v208 = (uint64_t) v17;
  TASSIGN(v207, v208);
  pipe_barrier(PIPE_V);
  TMULS(v207, v205, v204);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  set_flag(PIPE_V, PIPE_S, EVENT_ID4);
  // pto: %rstd__ssa_v0_pview
  __gm__ float* v209 = PTOAS__GLOBAL_TENSOR_DATA(v56);
  // pto: %rstd__ssa_v0_pview
  const int64_t v210 = 0;
  // pto: %rstd__ssa_v0_pview
  const int64_t v211 = 8;
  // pto: %rstd__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 8> v212 = pto::Shape<1, 1, 1, 1, 8>();
  // pto: %rstd__ssa_v0_pview
  pto::Stride<8, 8, 8, 8, 1> v213 = pto::Stride<8, 8, 8, 8, 1>();
  // pto: %rstd__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v214 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v209 + (v210 + v77 * v211), v212, v213);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v214, v207);
  // pto: %apply_value_inline1240__ssa_v0
  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v18);
  // pto: %apply_value_inline1240__ssa_v0
  uint64_t v216 = (uint64_t) v9;
  TASSIGN(v215, v216);
  // pto: %w_raw_inline1201__ssa_v0
  Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v18);
  // pto: %w_raw_inline1201__ssa_v0
  uint64_t v218 = (uint64_t) v16;
  TASSIGN(v217, v218);
  // pto: %weight_view_inline1233__ssa_v0_pview
  __gm__ bfloat16_t* v219 = PTOAS__GLOBAL_TENSOR_DATA(v64);
  // pto: %weight_view_inline1233__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 4096> v220 = pto::Shape<1, 1, 1, 1, 4096>();
  // pto: %weight_view_inline1233__ssa_v0_pview
  pto::Stride<4096, 4096, 4096, 4096, 1> v221 = pto::Stride<4096, 4096, 4096, 4096, 1>();
  // pto: %weight_view_inline1233__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v222 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v219, v220, v221);
  wait_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
  TLOAD(v217, v222);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  // pto: %w_inline1200__ssa_v0
  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v223 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v18);
  // pto: %w_inline1200__ssa_v0
  uint64_t v224 = (uint64_t) v8;
  TASSIGN(v223, v224);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
  pipe_barrier(PIPE_V);
  RoundMode v225 = RoundMode::CAST_ROUND;
  SaturationMode v226 = SaturationMode::ON;
  TCVT(v223, v217, v225, v226);
  wait_flag(PIPE_V, PIPE_S, EVENT_ID4);
  // pto: %inv_inline1199__tile
  float v227 = v207.GetValue(v21);
  // pto: %scaled_inline1198__ssa_v0
  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v228 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v18);
  // pto: %scaled_inline1198__ssa_v0
  uint64_t v229 = (uint64_t) v9;
  TASSIGN(v228, v229);
  TMULS(v228, v215, v227);
  // pto: %result_inline1197__ssa_v0
  Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v230 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v18);
  // pto: %result_inline1197__ssa_v0
  uint64_t v231 = (uint64_t) v9;
  TASSIGN(v230, v231);
  pipe_barrier(PIPE_V);
  TCOLEXPANDMUL(v230, v228, v223);
  // pto: %t__tmp_v82
  Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v19, v18);
  // pto: %t__tmp_v82
  uint64_t v233 = (uint64_t) v9;
  TASSIGN(v232, v233);
  pipe_barrier(PIPE_V);
  RoundMode v234 = RoundMode::CAST_RINT;
  SaturationMode v235 = SaturationMode::ON;
  TCVT(v232, v230, v234, v235);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  // pto: %normed__ssa_v0_pview
  __gm__ bfloat16_t* v236 = PTOAS__GLOBAL_TENSOR_DATA(v73);
  // pto: %normed__ssa_v0_pview
  const int64_t v237 = 0;
  // pto: %normed__ssa_v0_pview
  const int64_t v238 = 4096;
  // pto: %normed__ssa_v0_pview
  pto::Shape<1, 1, 1, 1, 4096> v239 = pto::Shape<1, 1, 1, 1, 4096>();
  // pto: %normed__ssa_v0_pview
  pto::Stride<4096, 4096, 4096, 4096, 1> v240 = pto::Stride<4096, 4096, 4096, 4096, 1>();
  // pto: %normed__ssa_v0_pview
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v241 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v236 + (v237 + v77 * v238), v239, v240);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
  TSTORE(v241, v232);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}