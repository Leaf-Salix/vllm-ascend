# 最终四项组合 V6：私有验收候选

该包只用于验证，不直接修改正式 checkout。V4 已提交备份，三项 V5 保留且未提交 NPU。

## 组成与边界

- `checked48`：仅重新分配每行 checked-index 整数工作，保持 slots planner 与依赖。
- `hybrid192`：T≥192 使用已验收的 O-proj seed 路径，较小 T 使用 V4 路径。
- `KV reuse2-v2`：保留 K512 内最后两个 K128 KV 面板供 PV 使用，保持计算、归约、舍入顺序。
- `HC64`：大 T 使用 M64 HC linear；较小 T 保留 M16。只从已验收 V4 HC 文件替换唯一 linear 调用段，保留其它函数、注释和 public scalar 测试入口。

相对 V5 只有 `hc_pre.py` 与 `hc_pre_panel.py` 改变，另外九个 patch 文件逐字节不变。Root 仍为 62 参数。原数学资格、真实 TND、确定性 Native、首差停止的门禁保留。

## 已有证据与待完成事项

每个单因素都已有 Native 位比较门禁；HC64 的 T6/T144/T240 各 27 项通过。原始结果由 `selection.json`、`HC_PRIVATE_HW_RECEIPTS.json` 绑定。组合仍需新的单层 T1、混合 1～6 行与大 T，以及 8K/B40、128K/B24 整模型 192-token 验收，不能把单因素结果当组合验收。

`candidate-math.json` 是完整 11-file patch SHA。`prepare_snapshot.py` 从原始不可变源码复制私有 snapshot 后覆盖这些 patch。单层 runner 与 whole-model helper 各自绑定实际 snapshot manifest 及 43 个 runtime 源文件 SHA。整模型默认 192-token warmup + 3×192-token measured，复用已有 Native，单任务上限 780 秒。

## 无设备准备与提交顺序

1. 在私有目录执行 `prepare_snapshot.py`。
2. 使用 `formal-v6-scaffold/bind_runner.py` 绑定单层 runner；`bind_whole.py --repeats 3` 绑定整模型助手。
3. 执行两档 `preflight.sh`，核对 source/runtime/bank/hooks。
4. 使用 `compile_formal.py --roots full` 执行实际 orchestration GCC 与全核 CCEC，审查实际生成物。
5. 主线程按 T1 → mixed21 → 大 T 执行单层门禁；发现首差立即停止。
6. 单层通过后执行 8K；精度通过再执行 128K。完整记录每轮 token/events、实际入场、资格、warmup 和测量轮。

该文件不包含 NPU 执行结果；结果必须绑定实际任务输出身份。
