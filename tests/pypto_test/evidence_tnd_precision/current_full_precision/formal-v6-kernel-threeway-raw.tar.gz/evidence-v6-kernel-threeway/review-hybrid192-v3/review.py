"""Independent actual generated identity/scope review; no compile or NPU."""
from pathlib import Path
import re,hashlib,json
P=Path(__file__).resolve().parent;B=P.parent/'math/oproj-woa-hybrid192-v3';G=B/'generated-review'
def core(p,name):
 s=p.read_text();a=s.index('static __aicore__ void '+name+'(');z=s.index('\nextern "C"',a);s=s[a:z].replace(name,'ROOT');return re.sub(r'\s+','',re.sub(r'//[^\n]*','',s))
assert hashlib.sha256((B/'candidate_o_proj.py').read_bytes()).hexdigest()=='a0ddb5470ea1950d985038bcfe5ba9669c4106d04d89b2513bdd5d827b9794d9'
assert core(G/'baseline/kernels/aic/oproj_a.cpp','oproj_a')==core(G/'candidate/kernels/aic/oproj_a_0.cpp','oproj_a_0')
for n in ('oproj_a_bf16','oproj_quant','oproj_b','oproj_b64','oproj_b_dequant'):
 f='aic' if n in ('oproj_b','oproj_b64') else 'aiv';assert core(G/f'baseline/kernels/{f}/{n}.cpp',n)==core(G/f'candidate/kernels/{f}/{n}.cpp',n)
s=(G/'candidate/orchestration/_o_proj_test.cpp').read_text();assert s.index('const Tensor& accum = alloc_0.get_ref(0);')<s.index('if ((192 <= T))')
assert s.count('add_output(accum)')==2 and s.count('accum__phi_v21 = accum;')==2 and 'params_t2.add_input(accum__phi_v21);' in s
assert s.index('params_t2.add_input(accum__phi_v21);')>s.index('accum__phi_v21 = accum;',s.index('} else {'))
c=(G/'candidate/kernels/aic/oproj_a.cpp').read_text();assert 'int64_t v118 = v117 < v25 ? v117 : v25;' in c
assert 'CompactMode::Normal>(v118, v25)' in c and 'TSTORE(v426, v413);' in c
assert 'wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);' in c and 'set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);' in c
result={'pass':True,'scope':'independent static review of actual generated code; not NPU acceptance','T_lt192_A_core_exact_identity':True,'all_round_quant_B_dequant_cores_exact_identity':True,'common_parent_GM_accum_descriptor':True,'both_branches_publish_same_descriptor_before_BF16':True,'no_L0C_escapes_orchestration_branch':True,'M128_tail_real_valid_rows_and_GM_TSTORE_consistent':True,'L0C_FIX_to_M_reuse_fence_present':True,'risk':'K256 seed contractual equivalence/calibration still requires existing per-stage Native hardware gates and final model retest; static review alone is insufficient'}
(P/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
