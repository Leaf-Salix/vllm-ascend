"""Read-only proof of public questions, actual chat suffixes and own fixed bank."""
import hashlib
import importlib.util
import json
from pathlib import Path

from safetensors import safe_open
from tokenizers import Tokenizer
import vllm
from low_acceptance_20261001.prepare_mixed import questions
from offline_pd.prefix import cache_contract

job = Path(__file__).resolve().parent
old = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/low-acceptance-20261010')
bank = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/low-acceptance-128k-b24-20261014/banks/fixed131072')
plan = json.loads((bank/'plan.json').read_text())
public = json.loads((job/'reference/mixed8k_cases.json').read_text())['cases']
owned = json.loads((old/'questions8192.json').read_text())['cases']
if len(public) != 40 or public != owned or list(questions()) != [(c['kind'], c['question']) for c in public]:
    raise ValueError('Public question content/order or local preparation differs')
encoding_file = Path(vllm.__file__).parent/'tokenizers/deepseek_v4_encoding.py'
spec = importlib.util.spec_from_file_location('bank_chat_encoding', encoding_file)
encoding = importlib.util.module_from_spec(spec)
spec.loader.exec_module(encoding)
model = Path(plan['model'])
tokenizer = Tokenizer.from_file(str(model/'tokenizer.json'))
contract = cache_contract(json.loads((model/'config.json').read_text()))
rows = []
for public_case, case in zip(public[:24], plan['cases'], strict=True):
    rendered = encoding.encode_messages([{'role':'user','content':public_case['question']}], thinking_mode='chat')
    suffix = tokenizer.encode('\n\n'+rendered.removeprefix(encoding.bos_token), add_special_tokens=False).ids
    tokens_file = bank/case['tokens']
    tokens = json.loads(tokens_file.read_text())
    if (case['key'] != public_case['key'].replace('8192','131072') or case['question_kind'] != public_case['kind']
            or len(suffix) != public_case['suffix_tokens'] or tokens[131072:] != suffix
            or len(tokens) != case['history']+1 or case['decode_suffix_tokens'] != 1):
        raise ValueError('Actual prompt suffix/history differs: '+case['key'])
    folder = bank/case['key']/'tp0'
    manifest_file = folder/'manifest.json'
    manifest = json.loads(manifest_file.read_text())
    cache_file = folder/'cache.safetensors'
    if manifest['history'] != case['history'] or manifest['p_dp_rank'] != case['p_dp_rank'] or manifest['p_tp_rank'] != 0:
        raise ValueError('Native bank owner/history differs')
    with safe_open(cache_file, framework='pt', device='cpu') as payload:
        if set(payload.keys()) != set(manifest['entries']) or set(payload.keys()) != set(contract):
            raise ValueError('Incomplete target/draft bank')
        for name, entry in manifest['entries'].items():
            if payload.get_slice(name).get_shape() != [len(entry['logical_blocks']), *entry['shape']] or entry['compress_ratio'] != contract[name]:
                raise ValueError('Cache header shape mismatch')
    rows.append({'key':case['key'],'history':case['history'],'question_sha256':hashlib.sha256(public_case['question'].encode()).hexdigest(),
                 'tokens_sha256':hashlib.sha256(tokens_file.read_bytes()).hexdigest(),
                 'manifest_sha256':hashlib.sha256(manifest_file.read_bytes()).hexdigest(),
                 'cache_bytes':cache_file.stat().st_size,'cache_mtime_ns':cache_file.stat().st_mtime_ns})
proof = {'pass':True,'questions_exact_public_all40':True,'chat_suffix_tokens_exact_main24':True,
         'all_target_draft_headers_valid':True,'bank':str(bank),'cases':rows,
         'bank_plan_sha256':hashlib.sha256((bank/'plan.json').read_bytes()).hexdigest(),
         'tokenizer_sha256':hashlib.sha256((model/'tokenizer.json').read_bytes()).hexdigest(),
         'encoding_sha256':hashlib.sha256(encoding_file.read_bytes()).hexdigest(),
         'scope':'public questions/order/chat suffix exact; own Native cache; original nalinaly prefix/cache byte identity not verified; payload header/stat only, no full tensor hash'}
output = job/'bank-input-128k-qualified.json'
if output.exists() and json.loads(output.read_text()) != proof:
    raise ValueError('Frozen bank identity changed since preflight')
output.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in proof.items() if k != 'cases'}))
