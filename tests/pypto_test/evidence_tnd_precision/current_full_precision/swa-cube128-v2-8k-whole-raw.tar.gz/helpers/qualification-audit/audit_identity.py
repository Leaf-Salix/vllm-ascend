"""Explicit source identity for read-only CPU replay of saved whole-model evidence."""
import argparse
import ast
import hashlib
import json
from pathlib import Path

sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def arguments(case):
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--expected-repeats',type=int,choices=(1,2,3),default=3)
    parser.add_argument('--identity',required=True)
    parser.add_argument('--expected-source-manifest',required=True)
    parser.add_argument('--candidate-math',type=Path,required=True)
    parser.add_argument('--expected-file-count',type=int,default=3365)
    return parser.parse_args()

def formal_identity(config,args):
    source=Path(config['snapshot']);manifest=Path(config['snapshot_manifest'])
    assert sha(manifest)==config['source_manifest_sha256']==args.expected_source_manifest
    files=json.loads(manifest.read_text())['files'];assert len(files)==args.expected_file_count
    expected=json.loads(args.candidate_math.read_text())
    assert config['candidate_math_files']==expected
    assert all(files.get(name)==digest for name,digest in expected.items())
    packages=('deepseek_v4_flash_csa_tnd_precision','deepseek_v4_flash_csa_tnd_full_precision')
    paths={p for package in packages for p in (source/'vllm_ascend/ops/pypto'/package).rglob('*.py')}
    paths.update((source/'vllm_ascend/ops/pypto/variant.py',source/'vllm_ascend/ops/dsv4_csa.py'))
    tested={str(p.relative_to(source)):sha(p) for p in sorted(paths)}
    assert len(tested)==43 and all(files.get(name)==digest for name,digest in tested.items())
    package=source/'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision'
    service=ast.parse((package/'service.py').read_text())
    cls=next(n for n in service.body if isinstance(n,ast.ClassDef) and n.name=='CSAServiceRuntime')
    init=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='__init__')
    assert ast.unparse(init.body[0].test)=='torch.npu.is_current_stream_capturing()'
    gates=[n for n in init.body if isinstance(n,ast.Assign) and any(ast.unparse(t)=='self.hc_weight_qualification' for t in n.targets)]
    assert len(gates)==1 and ast.unparse(gates[0].value)=='qualify_hc_pre_weight(layer.hc_attn_fn, self.layer_name)'
    assert any(isinstance(n,ast.ImportFrom) and n.level==1 and n.module=='hc_pre_contract' and any(a.name=='qualify_hc_pre_weight' for a in n.names) for n in service.body)
    contract=ast.parse((package/'hc_pre_contract.py').read_text())
    qualify=next(n for n in contract.body if isinstance(n,ast.FunctionDef) and n.name=='qualify_hc_pre_weight')
    finite=next(i for i,n in enumerate(qualify.body) if isinstance(n,ast.If) and 'np.isfinite(raw).all()' in ast.unparse(n.test))
    rounded=next(i for i,n in enumerate(qualify.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='rounded_bits' for t in n.targets))
    assert finite<rounded
    return {'identity':args.identity,'source_manifest_sha256':sha(manifest),'source_file_count':len(files),'tested_sources':tested,
            'source_enforced_HC_weight_gate':True,'HC_weight_gate_scope':'checked constructor/contract source and 21 initialized runtime capture evidence; per-layer loaded-weight summaries not exported by whole helper, no CPU re-evaluation of weights'}
