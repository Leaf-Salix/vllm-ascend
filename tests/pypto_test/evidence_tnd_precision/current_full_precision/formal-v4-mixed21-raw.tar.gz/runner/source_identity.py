"""Read and hash the actual formal source; no device or model initialization."""
import hashlib
import json
import os
from pathlib import Path
import sys

EXPECTED_MANIFEST = '6107e6ed747925793dcfe0e5188dee8486c3a8b91d0c1b7e073b62d38215bc28'
PACKAGES = ('deepseek_v4_flash_csa_tnd_precision', 'deepseek_v4_flash_csa_tnd_full_precision')

def source_identity():
    source = Path(os.environ['SOURCE_ROOT']).resolve()
    whole_helper = source.parent.parent
    assert source.name == 'source' and source.parent.name == 'snapshot'
    assert all(Path(path or '.').resolve() != whole_helper for path in sys.path), 'whole-model helper directory on sys.path'
    custom = sys.modules.get('sitecustomize')
    if custom is not None and getattr(custom, '__file__', None):
        assert Path(custom.__file__).resolve().parent != whole_helper, 'whole-model sitecustomize was imported'
    raw = (source.parent / 'manifest.json').read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert digest == EXPECTED_MANIFEST, 'formal source manifest identity mismatch'
    manifest = json.loads(raw)
    assert len(manifest['files']) == 3365
    for name, expected in manifest['files'].items():
        assert hashlib.sha256((source/name).read_bytes()).hexdigest() == expected, name
    paths = {path for package in PACKAGES for path in (source/'vllm_ascend/ops/pypto'/package).rglob('*.py')}
    paths.update((source/'vllm_ascend/ops/pypto/variant.py', source/'vllm_ascend/ops/dsv4_csa.py'))
    tested = {str(path.relative_to(source)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(paths)}
    assert all(manifest['files'].get(name) == value for name,value in tested.items())
    return {'source_manifest_sha256':digest, 'source_file_count':len(manifest['files']),
            'tested_sources':tested, 'source_root':str(source), 'whole_model_sitecustomize':False}
