"""The two-arm adaptation retains every V4 precision/graph assertion."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
P=Path(__file__).resolve().parent
old=ast.parse((P.parent/'csa-combo-v4/probe_csa.py').read_text())
new=ast.parse((P/'probe_csa.py').read_text())
dump=lambda n:ast.dump(n,include_attributes=False)
asserts=lambda t:Counter(dump(n) for n in ast.walk(t) if isinstance(n,ast.Assert))
assert not (asserts(old)-asserts(new)), 'Original V4 gate weakened or removed'
for name in ('exact','metric','NativeHalf','PTOHalf','RequirePTO'):
    find=lambda t:next(n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==name)
    assert dump(find(old))==dump(find(new)),name
# Main numerical config and timing loop remain unchanged; only the arm list differs.
for t in (old,new):
    pass
find_cfg=lambda t:next(n for n in t.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='config' for x in n.targets))
assert dump(find_cfg(old))==dump(find_cfg(new))
find_timing=lambda t:next(n for n in ast.walk(t) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='round_id')
assert dump(find_timing(old))==dump(find_timing(new))
text=(P/'probe_csa.py').read_text()
assert "for arm in ('native','candidate')" in text
assert 'from candidate_' not in text and 'from baseline_' not in text
assert 'formal_csa_v4::attention' in text and 'hc_weight_qualification' in text
assert '-witness.pt' not in text
assert (P/'ragged_fixture.py').read_bytes()==(P.parent/'csa-combo-v4/ragged_fixture.py').read_bytes()
for f in P.glob('*.py'):compile(f.read_text(),str(f),'exec')
out={'pass':True,'NPU_executed':False,'all_original_V4_assertions_retained':True,'precision_metric_and_model_wrappers_AST_unchanged':True,'EngineArgs_AST_unchanged':True,'timing_loop_AST_unchanged':True,'arms':['native','candidate'],'candidate':'formal relative module root; own namespace','success_large_witness_saved':False,'formal_source_manifest':'6107e6ed747925793dcfe0e5188dee8486c3a8b91d0c1b7e073b62d38215bc28'}
(P/'cpu-results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
