# 本轮测量复现入口（验收前草案）

## 冻结身份

- 基准 commit `1d6dbd02700cf8686fd1e82a87558c188fcbdf5d`；V6 source manifest `6d9656de4580ba5f768881c417f3093a7744808ac6518c594e9db881971e7ab2`。
- 最终SWA候选：source manifest `639b1280dc682dad23195509ddd51970d0d16da55fa11efa302e9edc97da7e03`、Sparse `248d8b11bb0a045f7863c0b264d962845dcabafa51cbf1e5fafee413fa8dc6d5`。
- 正式仓库/基准未覆盖；所有新运行位于独立 `qkpv-measurement-20261019-codex`。

## 设备、环境和精度口径

只在227 yejia任务队列执行，逻辑device0映射到TASK_DEVICE。Python3.12、Torch2.10.0+cpu、Torch-NPU2.10.0.post2、vLLM0.25.1、CANN/ATB9.2.0-beta.2；SDK固定PyPTO3e87a843和Simplera54c0509。PTOAS0.66由显式PTOAS_ROOT指定，调度命令兼容标签0.63不替代实际import/toolchain检查。

每项任务`--max-time 780`，单层内部timeout750；显式PYTHONNOUSERSITE=1、ASCEND_HOME_PATH、PTOAS_ROOT、CCACHE_DIR、CMAKE_BUILD_PARALLEL_LEVEL=4。不重装SDK或框架。

Native启用deterministic level1、HCCL_DETERMINISTIC=true。真正TND、单62Tensor入口、HC-pre到HC-post全PTO、纯DSL；HCA/FFN原生。NZ2/SK0，EPLB关闭，不强制接收步长3.8。

单层Native金值和候选cache完全独立，真实L4权重+synthetic hidden/history；实际FULL graph replay，8边界逐字节，A/B/ABA、poison、guard、复用资格、每轮state drift检查。短query/混合长度不按请求padding到S6。

整模型复用原40条公开问题及本机Native生成的固定8K/128K prefix/cache银行；没有证明nalinaly原始bank字节相同。192token预热+3次192token，每次实际入场轨迹匹配，16rank逐request token和接受事件精确相等，零抢占。128K/B24为提交24、实际21活跃3等待；126有效行进入144图桶。原Native性能窗为历史记录，不是同卡交错A/B。

## 顺序

1. program-mode原TND、Nal、单因素候选，固定同bank，读取PMU2及独立PMU6。PMU每进程仅一个窗口。
2. 两次B4及两次B40 sparse诊断root的无DFX graph A/B；每任务20轮×100replay，71门禁；80对全部正收益才扩大。
3. v1完整CSA mixed21/T1/T240；最终v2只是格式化换行，AST同，但仍用v2真源另跑mixed21。
4. v2整模型无设备preflight8K；mixed通过后只提交8K。精度/audit通过后再preflight128K、提交128K。发现首差停止后续矩阵。
5. 原始JSON/源码/生成物/助手SHA归档，再运行现有current-evidence CPU重放，不放宽原门禁。

## 后续运行入口

远端实验根记作`EXP=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/qkpv-measurement-20261019-codex`。

- 最终单层：`bash "$EXP/full-csa-gate-v2/run-csa.sh" mixed21 1,2,3,4,5,6 4 8191`。
- 整模型无设备预检：`bash "$EXP/whole-swa-cube-v2/preflight.sh" 8k`，之后128k。
- 16卡调度内命令：`bash "$EXP/whole-swa-cube-v2/run-case.sh" 8k pto`，通过后128k；PERF_REPEATS=3。
- 新输出不得覆盖：`/data/pyptouser/yejia/lc128/perf-swa-cube-20261019-v2-{8k,128k}-pto`。
- 独立CPU审计使用原通用`independent8k.py`及`independent128k_phase_matched.py`，传新source manifest、candidate-math、identity=SWA_Cube128_V2、repeats=3。
- 原128K phase policy fa3be8...与七项正负fixture保持原字节；首测对Native第1窗、后两次对Native第2窗，除了call不排除字段，不归一化input_ids_cpu。

最终交付文档必须补实际任务/结果/两档完整指标和原始证据SHA；当前草案不代表whole通过。
