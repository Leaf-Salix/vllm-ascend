def test_swa_reproduction_profile_is_bound_to_actual_npu_package():
    """The public replay command must select the recorded source and helpers."""
    import runpy

    m = _manifest()
    tool = _ROOT / "tests/pypto_test/prepare_tnd_precision_performance_repro.py"
    profile = runpy.run_path(str(tool))["PROFILES"]["swa128"]
    assert profile["source_sha"] == m["source_manifest_sha256"]
    for run in m["whole_model"]:
        _artifact(run["archive"])
        with tarfile.open(_EVIDENCE / run["archive"]["path"]) as bundle:
            cfg = json.load(bundle.extractfile("results/configuration.json"))
        assert profile["helper_sha"] == cfg["helper_manifest_sha256"]
        assert profile["old_job"] == str(Path(cfg["snapshot"]).parents[1])
        assert profile["job_expression"] == profile["old_job"]
