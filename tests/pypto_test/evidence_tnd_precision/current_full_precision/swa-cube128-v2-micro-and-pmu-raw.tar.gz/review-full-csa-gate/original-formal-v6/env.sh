#!/usr/bin/env bash
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/tnd-precision-delivery-20261018/env.sh"
job=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overnight-20261019/formal-csa-v6
export SOURCE_ROOT=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overnight-20261019/whole-formal-v6/snapshot/source
export PYTHONPATH="$job:$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
export PYPTO_PROG_BUILD_DIR="$job/build" PYPTO_CACHE_DIR="$job/cache"
# Deliberately do not source whole-formal-v4/env.sh or prepend its helper folder.
