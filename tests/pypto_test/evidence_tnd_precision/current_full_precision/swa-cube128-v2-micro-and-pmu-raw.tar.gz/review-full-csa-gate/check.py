"""Independent CPU review of the copied full-CSA gate and formatted sparse source."""
import ast
import hashlib
import json
from pathlib import Path

R = Path(__file__).resolve().parent.parent
HERE = Path(__file__).resolve().parent
OLD = HERE/'original-formal-v6'
NEW = R/'full-csa-gate'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
old_probe = ast.parse((OLD/'probe_csa.py').read_text())
new_probe = ast.parse((NEW/'probe_csa.py').read_text())
class Labels(ast.NodeTransformer):
    def visit_Constant(self, node):
        values = {'swa-cube128-v1':'formal-csa-v6',
                  'formal SWA Cube128 source with unchanged V6 HC weight qualification':
                  'formal relative-import V6 source with load-time HC weight qualification'}
        if isinstance(node.value,str): node.value=values.get(node.value,node.value)
        return node
assert ast.dump(old_probe,include_attributes=False)==ast.dump(Labels().visit(new_probe),include_attributes=False)
private = ast.parse((R/'candidate-swa-cube/candidate_sparse.py').read_text())
formal = ast.parse((HERE/'formal_candidate_sparse.py').read_text())
class Imports(ast.NodeTransformer):
    def visit_ImportFrom(self,node):
        prefix='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.'
        if node.module and node.module.startswith(prefix):
            node.module=node.module.removeprefix(prefix);node.level=1
        return node
assert ast.dump(Imports().visit(private),include_attributes=False)==ast.dump(formal,include_attributes=False)
old_binding=json.loads((OLD/'binding.json').read_text())
new_binding=json.loads((NEW/'binding.json').read_text())
sparse='vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision/decode_sparse_attn_csa.py'
changed=[n for n,h in old_binding['tested_sources'].items() if h!=new_binding['tested_sources'][n]]
assert changed==[sparse]
assert sha(HERE/'formal_candidate_sparse.py')==new_binding['tested_sources'][sparse]
old_manifest=json.loads((OLD/'manifest.json').read_text())
new_manifest=json.loads((NEW/'manifest.json').read_text())
assert all(sha(OLD/n)==h for n,h in old_manifest.items())
assert all(sha(NEW/n)==h for n,h in new_manifest.items())
for name in ('ragged_fixture.py','source_identity.py','preflight.py'):
    assert (OLD/name).read_bytes()==(NEW/name).read_bytes()
result={'static_review_pass':True,'hardware_executed':False,'formal_source_modified':False,
        'original_remote_helper_manifest_sha256':sha(OLD/'manifest.json'),
        'candidate_helper_manifest_sha256':sha(NEW/'manifest.json'),
        'candidate_source_manifest_sha256':new_binding['source_manifest_sha256'],
        'formal_candidate_sparse_sha256':sha(HERE/'formal_candidate_sparse.py'),
        'only_tested_source_changed':changed,'probe_ast_identical_after_two_report_labels':True,
        'formal_candidate_ast_identical_to_private_after_import_relocation':True,
        'identical_files':['ragged_fixture.py','source_identity.py','preflight.py'],
        'probe_assert_count':sum(isinstance(n,ast.Assert) for n in ast.walk(old_probe)),
        'candidate_helper_files':{n:sha(NEW/n) for n in new_manifest},
        'remaining_hardware_gates':['T21 lengths1,2,3,4,5,6','T1','T240 lengths6x40'],
        'scope':'complete CSA Native/PTO single-layer FULL graph real weights synthetic hidden/history; no whole model claim'}
(HERE/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('static_review_pass','probe_assert_count','candidate_source_manifest_sha256','formal_candidate_sparse_sha256')}))
