# 完整 CSA 门禁适配独立审查

结论：**静态审查通过。** 本次从227只读取回原 `formal-csa-v6` 的助手文件，核验原 manifest 后逐行和 AST 对照新助手；没有修改正式源码或 SDK，没有提交设备任务。

## 源码身份

- 新 snapshot manifest：`2c1f3bc97187e6c6f2cac4bdee086a631bae2a2b7a1b023bb0e99b28a1bd6b72`。
- 新正式 sparse：`0b6c0af7100bcb87010a9a7fc19690d48f074648a9b1f6b3d8c124384af14149`。
- 原 binding 的43个 tested source 与新 binding 比较，仅上述 sparse 文件SHA改变。
- 已读取新 snapshot 的该 sparse 文件；恢复私有候选的包内相对 import 后，正式新文件与已审 `8f3ddd...` 私有候选完整 AST 一致。格式化和移回正式模块没有改数学。
- 原助手、新助手各自 manifest 全部文件实际SHA匹配。完整3365文件及43个运行源码仍由原样 `source_identity()` 在本次 preflight/执行时重哈，未删除此门禁。

## 助手变化范围

- `probe_csa.py` 只有两个报告字符串变化。还原这两字符串后完整 AST 相同，全部27个 assert、所有显式抛错分支及数值比较均保留。
- `ragged_fixture.py`、`source_identity.py`、`preflight.py` 与原文件字节完全相同。
- `env.sh` 只更新实验 job 与 SOURCE_ROOT；仍不 source whole-model 环境或引入其 sitecustomize。
- `run-csa.sh` 只更新 env 路径并在原 probe 调用前增加 `timeout 750s`。外层 task 的780秒上限仍由主线程设置。

## 关键门禁未弱化

1. Native 设置 deterministic algorithms、NPU deterministic level1，环境 HCCL_DETERMINISTIC 保留。
2. `RequirePTO.eligible()` 不合格直接抛错，入口先显式 assert eligible；实际 guarded dispatch 次数必须大于零；root schema 名称和62 Tensor ABI都检查。没有把 Native fallback 当作候选通过。
3. Native 和 candidate fixture 的 hidden/positions/初始 cache逐字一致；双方各自 cache/state，参数和真实权重相同。
4. 真实 `torch.compile(...fullgraph=True,dynamic=False)` + `npugraph_ex`；每臂恰好一个实际 graph，禁止 host updated nodes。context 明确 FULL。
5. output NaN、TopK poison 后 raw replay必须恢复，并与 compiled状态逐字相同；八类外部边界对 Native 全 bit比较，首差立即抛错。
6. B输入必须实际改变输出；B的所有边界也与 Native逐bit对拍；guards检查；A恢复须完全回到原状态。
7. HC权重资格、静态包metadata SHA/reselect边界与正式root相对导入保持。
8. 每个计时轮后状态必须等于本臂已验收状态，guard必须通过；失败不会写complete/pass为true。

## 本次待验收范围

按计划依次验证 T21（请求行数1、2、3、4、5、6）、T1、T240（40请求各6行）；短请求不padding到S6。任何首差应停止后续档位，先定位。

这是**真实单层权重、合成hidden/history的完整 HC-pre至HC-post CSA FULL graph** 门禁，不是整模型token验收。即使三档通过，性能结论也只针对同报告的单层配置；正式合入前仍需相应整模型精度验证。

可复核命令：`python3 check.py`。源码与助手身份、assert数量及剩余硬件门禁见 `results.json`。
