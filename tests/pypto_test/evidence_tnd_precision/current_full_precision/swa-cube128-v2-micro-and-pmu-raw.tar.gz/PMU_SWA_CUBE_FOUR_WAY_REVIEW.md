# SWA Cube 缩短后的四方计数复核

## 结论

同 bank 的 program-mode PMU 已支持第一个优化判断：**SWA 的无效 Cube 计算和相应 MTE1 工作已明显消除，候选这两项计数已与 Nal 相当。剩余最明确的差距在 AIV Vector 工作量；尚不能量出同步等待的独立耗时。**

候选通过59项 Native/原版 FP32 统计及重复字节检查。无 DFX 的 sparse graph 两次独立任务中，40组配对均同向更快；这是 sparse 局部优化的性能证据，尚不是整层 CSA 或整模型收益。

## 实测指标

前三个 PTO 根使用同一 bank：`66158da293867dc48626083df47404b919ee859fb9719c8d55c0f88f4809668e`。单位为每 core/task 的平均千 cycles。PTO 的 AIC/AIV 各24/48条；Native 为三条 `SparseAttnSharedkv` 的 `aic_total_cycles / 24`、`aiv_total_cycles / 48` 再取均值。

| 指标 | Native CANN | Nal BSH program | TND 原版 program | TND SWA128 Cube program |
|---|---:|---:|---:|---:|
| AIC total | 90.05 | 78.44 | 138.21 | **117.25** |
| AIC Cube busy | 13.63%¹ | 11.78 | 18.52 | **11.58** |
| AIC MTE1 busy | 17.53%¹ | 13.56 | 21.69 | **13.56** |
| AIC MTE2 busy | 53.23%¹ | 17.34 | 25.65 | 23.27 |
| AIC Scalar busy | 57.20%¹ | 36.37 | 23.24 | 21.27 |
| AIV total | 96.28 | 87.89 | 142.23 | **121.67** |
| AIV Vector busy | 8.70%¹ | **21.11** | 34.69 | 35.32 |
| AIV MTE2 busy | 37.30%¹ | 24.09 | 22.52 | 21.42 |
| AIV MTE3 busy | 15.37%¹ | 10.53 | 16.46 | 17.68 |
| AIV Scalar busy | 43.10%¹ | 45.61 | 46.53 | 41.58 |

¹ Native 的 CSV 提供各 pipeline 的时间及舍入后的占比，没有本表所需的原始 busy cycle，因此保留其原始占比，不用假定频率换算成 cycles。Native 的均摊 total cycles 可以由原始整数直接计算；这不把其 duration 与 PTO total cycles 强拼为统一计时。

**范围不同：** Nal 的 `qk_pv` 还包含 inverse RoPE 和输出发布；该实验用 cos=1/sin=0。TND 的 `qk_pv` 不包含该 inverse RoPE/最终发布。Native 是 CANN 静态混合核、PTO 是 program-mode task，采集包装不同。此表用于工作量/路径诊断，不声称为受控的整层性能排名。Native CANN三次kernel duration为55.760/55.800/55.040µs，也不能直接与以上 cycles 相除比较。

Nal 三次输出相对 Native 的 relative L2 都为0.00254394（0.2544%）；其 `pass=true` 表示该测量过程完成，**不表示通过逐 bit 精度验收**。

## 这次优化证实了什么

- 相比原 TND，候选 Cube busy 降37.48%、MTE1 busy降37.47%；分别到11.58k与13.56k，接近 Nal 的11.78k/13.56k。此前这两项工作量差异主要来自SWA padding extent的判断得到支持。
- 候选 AIC/AIV total 分别降15.16%/14.46%；不能把这两个数字直接解释为最终 graph 收益，因为这是有 PMU 的另一种执行模式。
- 目前仍比 Nal 多约14.22k Vector busy（+67.4%），尽管 Nal 的核体还做额外逆RoPE/发布。相比之下，候选 AIV Scalar busy、MTE2 busy均小于 Nal。**优先检查精确 softmax/归约/统计路径的 Vector 指令差异，比继续泛称Cube或内存瓶颈更有依据。** 但不能仅凭这张表决定删除任何Native对齐边界。
- AIV total 仍差33.78k，不能把其中14.22k称为已解释的互斥耗时，也不能把余下19.56k称为等待；busy counter可能重叠，两个核体/采集时机也不同。

## 无插桩 graph 验证

同卡原版/候选、每臂20轮×100次 replay，PMU/DFX/dep-gen均关闭；两个任务的 bank、stats金值、helper manifest及候选源码SHA均一致。

| 独立任务 | 原版均值µs | 候选均值µs | 延迟下降 | 配对方向 |
|---|---:|---:|---:|---|
| r1 | 236.487 | 217.648 | 7.97% | 20/20更快 |
| r2 | 227.034 | 219.317 | 3.40% | 20/20更快 |

原版跨任务均值漂移明显，因此不把两次不同降幅平均成一个稳定百分比。候选在两个任务都稳定更快，是当前可以保留、继续扩大门禁的依据；还需大T与真实整模型验证。

## 数据身份

`PMU_FOUR_WAY_INDEPENDENT.json` 保存四份原始CSV SHA、result SHA、逐函数均值及检查数量。来源：

- `sparse-program-results-pass/data`：原TND，47项检查。
- `candidate-swa-cube-results/data`：候选，59项检查。
- `nal-sparse-results/data`：同bank Nal，误差只记录。
- `pmu-pilot-results/data/pmu/native/**/kernel_details.csv`：Native CANN三条静态Sparse核。
- `sparse-graph-results-r1/data/result.json`、`sparse-graph-results-r2/data/result.json`：上述无插桩计时。

本轮仅独立读结果并复算，没有改算子或提交设备任务。
