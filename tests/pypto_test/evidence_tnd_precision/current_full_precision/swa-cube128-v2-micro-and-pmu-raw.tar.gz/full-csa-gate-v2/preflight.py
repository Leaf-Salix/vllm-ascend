"""无设备只读环境、冻结源码及探针身份检查。"""
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys
import types

from source_identity import source_identity
identity=source_identity()
root=Path(os.environ['SOURCE_ROOT'])
print('FORMAL_SOURCE_SHA',identity['source_manifest_sha256'],'count',identity['source_file_count'],'tested_sources',len(identity['tested_sources']),flush=True)
for name in ('torch','torch_npu','vllm','vllm_ascend','pypto','simpler','npugraph_ex'):
    module=importlib.import_module(name)
    print('MODULE',name,getattr(module,'__version__',None),module.__file__,flush=True)
    if name=='vllm_ascend':
        assert Path(module.__file__).is_relative_to(root)
    if name=='pypto':
        assert Path(module.__file__).resolve().is_relative_to(Path(os.environ['LOW_ACCEPTANCE_RUNTIME_PACKAGE']).resolve()/'pypto')
    if name=='simpler':
        expected=Path('/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/python/simpler')
        assert Path(module.__file__).resolve().is_relative_to(expected.resolve())
for name in ('PTOAS_ROOT','ASCEND_HOME_PATH','ATB_HOME_PATH','CCACHE_DIR'):
    assert os.environ.get(name),name
    print('ENV',name,os.environ[name],flush=True)
from pypto.jit._toolchain import capture_toolchain
assert capture_toolchain('a2a3','tensormap_and_ringbuffer').usable
meta=Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE'])/'metadata.json'
assert hashlib.sha256(meta.read_bytes()).hexdigest()=='863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
job=Path(__file__).parent
helpers=json.loads((job/'manifest.json').read_text())
for name,sha in helpers.items():
    assert hashlib.sha256((job/name).read_bytes()).hexdigest()==sha,name
importlib.import_module('vllm_ascend.ops.dsv4_csa')
import torch
assert hasattr(torch.ops.vllm,'dsv4_csa_forward')
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.decode_csa import decode_csa_tp1_layer_test
import vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.service as formal_service
assert Path(formal_service.__file__).resolve().is_relative_to(root.resolve())
assert hasattr(formal_service, 'qualify_hc_pre_weight')
for helper in ('dsv4_csa_single_layer','dsv4_csa_native_case'):
    assert Path(importlib.import_module(helper).__file__).resolve().is_relative_to(root.resolve())
assert os.environ['HCCL_DETERMINISTIC']=='true'
assert len(decode_csa_tp1_layer_test.param_names)==62
print('TND_SINGLE_ROOT_ABI',len(decode_csa_tp1_layer_test.param_names),flush=True)
print('PREFLIGHT_PASS frozen_source_files='+str(identity['source_file_count'])+' helper_files='+str(len(helpers)),flush=True)
(job/'preflight-result.json').write_text(json.dumps(dict(identity,pass_without_NPU=True,root_ABI=62,helper_files=helpers),indent=2)+'\n')
