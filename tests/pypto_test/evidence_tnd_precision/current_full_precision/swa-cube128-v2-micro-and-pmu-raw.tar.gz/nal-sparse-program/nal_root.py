"""固定 a919 Nal sparse；与 TND 使用同一 Native Q/cache/TopK bank。"""
import sys
import types
from pathlib import Path
import pypto.language as pl

package = types.ModuleType("historical_pypto")
package.__path__ = [str(Path(__file__).resolve().parent / "bsh-source/vllm_ascend/ops/pypto")]
sys.modules["historical_pypto"] = package
from historical_pypto.deepseek_v4_flash_csa.decode_sparse_attn_csa import (
    sparse_attn_csa, T_DYN, B_DYN, ORI_BLOCK_NUM_DYN, CMP_BLOCK_NUM_DYN,
    H, HEAD_DIM, ROPE_DIM, IDX_TOPK, BLOCK_SIZE, T_PAD, O_GROUPS, O_GROUP_IN,
)
from historical_pypto.deepseek_v4_flash_csa.layout import (
    ORIGINAL_TABLE_COLUMNS_DYN, COMPRESSED_TABLE_COLUMNS_DYN,
)


def _nal_sparse_probe(
    q: pl.Tensor[[T_DYN, H, HEAD_DIM], pl.BF16],
    ori_kv: pl.Tensor[[ORI_BLOCK_NUM_DYN, BLOCK_SIZE, 1, HEAD_DIM], pl.BF16],
    ori_table: pl.Tensor[[B_DYN, ORIGINAL_TABLE_COLUMNS_DYN], pl.INT32],
    cmp_kv: pl.Tensor[[CMP_BLOCK_NUM_DYN, BLOCK_SIZE, 1, HEAD_DIM], pl.BF16],
    cmp_table: pl.Tensor[[B_DYN, COMPRESSED_TABLE_COLUMNS_DYN], pl.INT32],
    topk: pl.Tensor[[T_DYN, IDX_TOPK], pl.INT32],
    positions: pl.Tensor[[T_DYN, 1], pl.INT64],
    lengths: pl.Tensor[[B_DYN], pl.INT32],
    sink: pl.Tensor[[H], pl.FP32],
    cos: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32],
    sin: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32],
    packed: pl.Out[pl.Tensor[[O_GROUPS * T_PAD, O_GROUP_IN], pl.BF16]],
):
    q.bind_dynamic(0, T_DYN)
    ori_kv.bind_dynamic(0, ORI_BLOCK_NUM_DYN)
    ori_table.bind_dynamic(0, B_DYN)
    ori_table.bind_dynamic(1, ORIGINAL_TABLE_COLUMNS_DYN)
    cmp_kv.bind_dynamic(0, CMP_BLOCK_NUM_DYN)
    cmp_table.bind_dynamic(0, B_DYN)
    cmp_table.bind_dynamic(1, COMPRESSED_TABLE_COLUMNS_DYN)
    topk.bind_dynamic(0, T_DYN)
    positions.bind_dynamic(0, T_DYN)
    lengths.bind_dynamic(0, B_DYN)
    cos.bind_dynamic(0, T_DYN)
    sin.bind_dynamic(0, T_DYN)
    result, ready = sparse_attn_csa(q, ori_kv, ori_table, cmp_kv, cmp_table, topk,
                                  positions, lengths, sink, cos, sin, packed)
    return result


nal_sparse_probe = pl.jit(_nal_sparse_probe)
