"""Nal sparse 的独立 program PMU；误差只记录，不作为 TND 黄金。"""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import torch
from pypto.ir import CompiledProgram
from pypto.runtime import RunConfig

parser = argparse.ArgumentParser()
parser.add_argument("--bank", type=Path, required=True)
parser.add_argument("--bank-sha", required=True)
parser.add_argument("--out", type=Path, required=True)
parser.add_argument("--event", type=int, choices=(2, 6), default=2)
args = parser.parse_args()
args.out.mkdir()
assert hashlib.sha256(args.bank.read_bytes()).hexdigest() == args.bank_sha
assert not os.environ.get("SIMPLER_PMU_EVENT_TYPE")
bank = torch.load(args.bank, map_location="cpu", weights_only=False)
kwargs = bank["kwargs"]
here = Path(__file__).resolve().parent
manifest = json.loads((here / "frozen-manifest.json").read_text())
for name, sha in manifest.items():
    assert hashlib.sha256((here / "frozen-artifact" / name).read_bytes()).hexdigest() == sha
compiled = CompiledProgram.from_dir(here / "frozen-artifact", platform="a2a3")
q = bank["q"]
tokens = q.shape[0]
assert all(length == 6 for length in bank["lengths"]), "Nal BSH S6 only"
inputs = [q, kwargs["ori_kv"], kwargs["ori_block_table"], kwargs["cmp_kv"],
          kwargs["cmp_block_table"], kwargs["cmp_sparse_indices"].reshape(tokens, 512),
          bank["positions"].reshape(tokens, 1), kwargs["seqused_kv"].reshape(-1),
          kwargs["sinks"].reshape(64), torch.ones(tokens, 64), torch.zeros(tokens, 64)]
assert all(value.device.type == "cpu" and value.is_contiguous() for value in inputs)
output = torch.empty(8 * 384, 4096, dtype=torch.bfloat16)
report = {"pass": False, "complete": False, "bank_sha": args.bank_sha, "event": args.event,
          "nal_commit": "a919f11942d93627441c8fa694e310dcbd1c671b",
          "scope": "same Native Q/cache/TopK, Nal original sparse including inverse RoPE with cos=1/sin=0; no accuracy acceptance claim",
          "checks": [], "readonly_scope": "Host argument bytes only", "runs": []}


def save():
    (args.out / "result.json").write_text(json.dumps(report, indent=2) + "\n")


def equal(a, b):
    return torch.equal(a.contiguous().view(torch.uint8), b.contiguous().view(torch.uint8))


save()
gold = None
for index, pmu in enumerate((0, 0, args.event)):
    output.fill_(float("nan"))
    before = [value.clone() for value in inputs]
    source = Path(compiled.output_dir) / "dfx_outputs/pmu.csv"
    if pmu and source.exists():
        shutil.move(source, args.out / f"pmu-before-{index}.csv")
    compiled(*inputs, output, config=RunConfig(platform="a2a3", device_id=0, aicpu_thread_num=4,
        enable_pmu=pmu, enable_chip_swimlane=0, enable_dep_gen=False, enable_dump_args=0))
    heads = output.reshape(8, 384, 8, 512)[:, :tokens].permute(1, 0, 2, 3).reshape(tokens, 64, 512).contiguous()
    assert bool(torch.isfinite(heads).all()), "Nal nonfinite valid heads"
    native = bank["native_heads"].reshape(tokens, 64, 512)
    delta = heads.float() - native.float()
    report["checks"].append({"run": index, "Native_bit_equal": equal(heads, native),
        "relative_l2": float(torch.linalg.vector_norm(delta) / torch.linalg.vector_norm(native.float())),
        "max_abs": float(delta.abs().max())})
    assert all(equal(a, b) for a, b in zip(inputs, before)), "Host input changed"
    if gold is not None:
        assert equal(heads, gold), "FIRST_BIT_DIFFERENCE Nal repeat"
    else:
        gold = heads.clone()
    if pmu:
        assert source.is_file(), "missing fresh PMU"
        rows = list(csv.DictReader(source.open()))
        assert rows and any(int(row["pmu_total_cycles"]) > 0 for row in rows)
        shutil.copy2(source, args.out / f"pmu-{index}.csv")
        report["runs"].append({"index": index, "rows": len(rows)})
    save()
report["pass"] = report["complete"] = True
save()
print("NAL_SPARSE_PMU_PASS", flush=True)
