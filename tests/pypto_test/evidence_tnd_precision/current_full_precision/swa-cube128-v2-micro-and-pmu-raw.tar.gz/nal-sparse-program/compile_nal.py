"""仅生成固定 Nal sparse 诊断入口。"""
import json
from pathlib import Path
from pypto.runtime import RunConfig
from nal_root import nal_sparse_probe

here = Path(__file__).resolve().parent
compiled = nal_sparse_probe.compile(config=RunConfig(
    platform="a2a3", save_kernels=True, save_kernels_dir=str(here / "artifact"),
))
(here / "compiled.json").write_text(json.dumps({"output_dir": str(compiled.output_dir),
    "hardware_executed": False, "params": list(nal_sparse_probe.param_names)}, indent=2) + "\n")
print("NAL_SPARSE_GENERATED", compiled.output_dir, flush=True)
