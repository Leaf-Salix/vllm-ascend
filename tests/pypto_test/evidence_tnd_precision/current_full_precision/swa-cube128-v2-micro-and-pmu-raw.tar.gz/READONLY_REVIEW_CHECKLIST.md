# QK/PV 可观测性：只读核验清单

- [x] 固定当前 PyPTO/Simpler API 和源路径；不改环境。
- [x] 核验已有 DFX 的 task 生命周期、核内标记、cycle/PMU/timestamp API。
- [x] 核验当前 CANN msprof 工具存在、help/分析能力及限制，不运行设备采集。
- [x] 对 QK/PV 计算、搬运、同步给出可测方案和盲区；不把 ablation 差值相加。
- [x] 输出中文技术 review，所有结论区分已核工具/API与仍待设备门禁。

保留生产基准1d6dbd027；本项不提交NPU、不安装软件、不改SDK/codegen/C++helper或正式源码。

已核实工具与API，不表示已有新的硬件PMU采集结果。PMU pilot只做独立源码/接口审查，未由本线程提交或运行NPU。
