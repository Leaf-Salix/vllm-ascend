#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qk_pv_aic(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, __gm__ int32_t* v4, __gm__ bfloat16_t* v5, __gm__ float* v6, __gm__ bfloat16_t* v7, __gm__ float* v8, __gm__ float* v9, __gm__ float* v10, __gm__ float* v11, __gm__ int64_t* v12, __gm__ int32_t* v13, __gm__ bfloat16_t* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, __gm__ bfloat16_t* v17, __gm__ float* v18, __gm__ float* v19, __gm__ float* v20, __gm__ float* v21, __gm__ float* v22, __gm__ float* v23, int64_t v24, int64_t v25, int64_t v26, int64_t v27, int64_t v28, int64_t v29, int64_t v30, int64_t v31, int64_t v32, int32_t v33, int32_t v34) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v35 = 32;
  // pto: %c0_i64
  const int64_t v36 = 0;
  // pto: %c393216_i64
  const int64_t v37 = 393216;
  // pto: %c16384_i64
  const int64_t v38 = 16384;
  // pto: %c32768_i64
  const int64_t v39 = 32768;
  // pto: %c458752_i64
  const int64_t v40 = 458752;
  // pto: %c1_index
  const int64_t v41 = 1;
  // pto: %c512_index
  const int64_t v42 = 512;
  // pto: %c16_index
  const int64_t v43 = 16;
  // pto: %c12288_index
  const int64_t v44 = 12288;
  // pto: %c1536_index
  const int64_t v45 = 1536;
  // pto: %c64_index
  const int64_t v46 = 64;
  // pto: %c384_index
  const int64_t v47 = 384;
  // pto: %c24_index
  const int64_t v48 = 24;
  // pto: %c0_index
  const int64_t v49 = 0;
  // pto: %c2_index
  const int64_t v50 = 2;
  // pto: %c4_index
  const int64_t v51 = 4;
  // pto: %c128_index
  const int64_t v52 = 128;
  // pto: %c256_index
  const int64_t v53 = 256;
  // pto: %cn128_index
  const int64_t v54 = -128;
  // pto: %c32_index
  const int64_t v55 = 32;
  // pto: %cn32_index
  const int64_t v56 = -32;
  // pto: %c3_index
  const int64_t v57 = 3;
  // pto: %q_flat_inline64__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %q_flat_inline64__ssa_v0_view
  const int64_t v59 = 1;
  // pto: %q_flat_inline64__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %q_flat_inline64__ssa_v0_view
  int64_t v61 = (int64_t) v26;
  // pto: %q_flat_inline64__ssa_v0_view
  int64_t v62 = v61 * v42;
  // pto: %q_flat_inline64__ssa_v0_view
  int64_t v63 = v60 * v62;
  // pto: %q_flat_inline64__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v64 = pto::Shape<1, 1, 1, -1, -1>(v58, v59, v60, v61, v42);
  // pto: %q_flat_inline64__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v65 = pto::Stride<-1, -1, -1, -1, -1>(v59 * v63, v63, v62, v42, v41);
  // pto: %q_flat_inline64__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v66 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v64, v65);
  // pto: %kv_transfer_inline91__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %kv_transfer_inline91__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %kv_transfer_inline91__ssa_v0_view
  const int64_t v69 = 1;
  // pto: %kv_transfer_inline91__ssa_v0_view
  int64_t v70 = v44 * v42;
  // pto: %kv_transfer_inline91__ssa_v0_view
  int64_t v71 = v69 * v70;
  // pto: %kv_transfer_inline91__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v72 = pto::Shape<1, 1, 1, -1, -1>(v67, v68, v69, v44, v42);
  // pto: %kv_transfer_inline91__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v73 = pto::Stride<-1, -1, -1, -1, -1>(v68 * v71, v71, v70, v42, v41);
  // pto: %kv_transfer_inline91__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v74 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v72, v73);
  // pto: %score_transfer_inline58__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %score_transfer_inline58__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %score_transfer_inline58__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %score_transfer_inline58__ssa_v0_view
  int64_t v78 = v45 * v42;
  // pto: %score_transfer_inline58__ssa_v0_view
  int64_t v79 = v77 * v78;
  // pto: %score_transfer_inline58__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v80 = pto::Shape<1, 1, 1, -1, -1>(v75, v76, v77, v45, v42);
  // pto: %score_transfer_inline58__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v81 = pto::Stride<-1, -1, -1, -1, -1>(v76 * v79, v79, v78, v42, v41);
  // pto: %score_transfer_inline58__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v82 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v80, v81);
  // pto: %probability_transfer_inline129__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %probability_transfer_inline129__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %probability_transfer_inline129__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %probability_transfer_inline129__ssa_v0_view
  int64_t v86 = v45 * v42;
  // pto: %probability_transfer_inline129__ssa_v0_view
  int64_t v87 = v85 * v86;
  // pto: %probability_transfer_inline129__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v88 = pto::Shape<1, 1, 1, -1, -1>(v83, v84, v85, v45, v42);
  // pto: %probability_transfer_inline129__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v89 = pto::Stride<-1, -1, -1, -1, -1>(v84 * v87, v87, v86, v42, v41);
  // pto: %probability_transfer_inline129__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v90 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v88, v89);
  // pto: %pv_transfer_inline148__ssa_v0_view
  const int64_t v91 = 1;
  // pto: %pv_transfer_inline148__ssa_v0_view
  const int64_t v92 = 1;
  // pto: %pv_transfer_inline148__ssa_v0_view
  const int64_t v93 = 1;
  // pto: %pv_transfer_inline148__ssa_v0_view
  int64_t v94 = v45 * v42;
  // pto: %pv_transfer_inline148__ssa_v0_view
  int64_t v95 = v93 * v94;
  // pto: %pv_transfer_inline148__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v96 = pto::Shape<1, 1, 1, -1, -1>(v91, v92, v93, v45, v42);
  // pto: %pv_transfer_inline148__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v97 = pto::Stride<-1, -1, -1, -1, -1>(v92 * v95, v95, v94, v42, v41);
  // pto: %pv_transfer_inline148__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v98 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v96, v97);
  // pto: %qk_l1_inline135__phi_v12
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v42);
  // pto: %qk_l1_inline135__phi_v12
  uint64_t v100 = (uint64_t) v36;
  TASSIGN(v99, v100);
  // pto: %qk_l1_inline135__phi_v11
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v42);
  // pto: %qk_l1_inline135__phi_v11
  uint64_t v102 = (uint64_t) v36;
  TASSIGN(v101, v102);
  // pto: %qk_core_inline128__ssa_v0
  int64_t v103 = (int64_t) v33;
  // pto: %6
  int64_t v104 = (int64_t) ((uint64_t) v103 * (uint64_t) v42);
  // pto: %7
  int64_t v105 = (int64_t) ((uint64_t) v103 * (uint64_t) v46);
  uint64_t v106 = reinterpret_cast<uint64_t>(v1);
  set_ffts_base_addr(v106);
  // pto: %qk_l1_inline135__ssa_v0
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v107 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v42);
  // pto: %qk_l1_inline135__ssa_v0
  uint64_t v108 = (uint64_t) v36;
  TASSIGN(v107, v108);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  for (int64_t v109 = v103; v109 < v24; v109 += v48) {
    // pto: %qk_q_inline139__ssa_v0
    ;
    Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v42);
    // pto: %qk_q_inline139__ssa_v0
    ;
    uint64_t v111 = (uint64_t) v37;
    TASSIGN(v110, v111);
    // pto: %8
    ;
    int64_t v112 = (int64_t) ((uint64_t) v109 * (uint64_t) v46);
    // pto: %9
    ;
    int64_t v113 = v112 < v49 ? v49 : v112;
    // pto: %q_flat_inline64__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v114 = PTOAS__GLOBAL_TENSOR_DATA(v66);
    // pto: %q_flat_inline64__ssa_v0_pview
    ;
    const int64_t v115 = 0;
    // pto: %q_flat_inline64__ssa_v0_pview
    ;
    const int64_t v116 = 512;
    // pto: %q_flat_inline64__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 64, 512> v117 = pto::Shape<1, 1, 1, 64, 512>();
    // pto: %q_flat_inline64__ssa_v0_pview
    ;
    pto::Stride<32768, 32768, 32768, 512, 1> v118 = pto::Stride<32768, 32768, 32768, 512, 1>();
    // pto: %q_flat_inline64__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v119 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v114 + (v115 + v113 * v116), v117, v118);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v110, v119);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    for (int64_t v120 = v49; v120 < v50; v120 += v41) {
      // pto: %flat_offset_mul, %flat_offset, %t__tile
      ;
      int32_t v121 = (v4)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v109 * (uint64_t) v43) + (uint64_t) v120)];
      // pto: %10, %11
      ;
      if ((int64_t) v121 > v49) {
        int32_t v122 = (int32_t) v49;
        wait_flag_dev(v122);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        for (int64_t v123 = v49; v123 < v51; v123 += v41) {
          // pto: %12
          ;
          int64_t v124 = (int64_t) ((uint64_t) v123 * (uint64_t) v52);
          // pto: %13
          ;
          int64_t v125 = (int64_t) ((uint64_t) v123 - (uint64_t) v41);
          // pto: %14
          ;
          int64_t v126 = v125 < v49 ? v49 : v125;
          // pto: %15
          ;
          int64_t v127 = (int64_t) ((uint64_t) v126 * (uint64_t) v52);
          // pto: %gather_row_view
          ;
          Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, 128, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v128;
          // pto: %gather_row_view
          ;
          uint64_t v129 = (uint64_t) ((int64_t) (uint64_t) v127 * (uint64_t) v35);
          TASSIGN(v128, v129);
          // pto: %16
          ;
          int64_t v130 = (int64_t) ((uint64_t) v104 + (uint64_t) v124);
          // pto: %17
          ;
          int64_t v131 = v130 < v49 ? v49 : v130;
          // pto: %kv_transfer_inline91__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v132 = PTOAS__GLOBAL_TENSOR_DATA(v74);
          // pto: %kv_transfer_inline91__ssa_v0_pview
          ;
          const int64_t v133 = 0;
          // pto: %kv_transfer_inline91__ssa_v0_pview
          ;
          const int64_t v134 = 512;
          // pto: %kv_transfer_inline91__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 128, 512> v135 = pto::Shape<1, 1, 1, 128, 512>();
          // pto: %kv_transfer_inline91__ssa_v0_pview
          ;
          pto::Stride<65536, 65536, 65536, 512, 1> v136 = pto::Stride<65536, 65536, 65536, 512, 1>();
          // pto: %kv_transfer_inline91__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND> v137 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND>(v132 + (v133 + v131 * v134), v135, v136);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          TLOAD(v128, v137);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %qk_l1_t_inline153__ssa_v0
          ;
          Tile<TileType::Mat, bfloat16_t, 512, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Mat, bfloat16_t, 512, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v42, v47);
          // pto: %qk_l1_t_inline153__ssa_v0
          ;
          uint64_t v139 = (uint64_t) v36;
          TASSIGN(v138, v139);
          // pto: %qk_scores_inline123__ssa_v0_l0_init
          ;
          Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v140 = Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v46, v52);
          // pto: %qk_scores_inline123__ssa_v0_l0_init
          ;
          uint64_t v141 = (uint64_t) v36;
          TASSIGN(v140, v141);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
          for (int64_t v142 = v49; v142 < v42; v142 += v53) {
            // pto: %qk_scores_inline123__ssa_v0_l0_a
            ;
            Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v143 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v52);
            // pto: %qk_scores_inline123__ssa_v0_l0_a
            ;
            uint64_t v144 = (uint64_t) v36;
            TASSIGN(v143, v144);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            pipe_barrier(PIPE_MTE1);
            uint16_t v145 = static_cast<uint16_t>(v49);
            uint16_t v146 = static_cast<uint16_t>(v142);
            TEXTRACT(v143, v110, v145, v146);
            // pto: %qk_scores_inline123__ssa_v0_l0_b
            ;
            Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v52, v52);
            // pto: %qk_scores_inline123__ssa_v0_l0_b
            ;
            uint64_t v148 = (uint64_t) v36;
            TASSIGN(v147, v148);
            uint16_t v149 = static_cast<uint16_t>(v142);
            uint16_t v150 = static_cast<uint16_t>(v127);
            TEXTRACT(v147, v138, v149, v150);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            // pto: %0
            ;
            Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v151 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v52);
            // pto: %0
            ;
            uint64_t v152 = (uint64_t) v38;
            TASSIGN(v151, v152);
            // pto: %18
            ;
            int64_t v153 = (int64_t) ((uint64_t) v142 + (uint64_t) v52);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            uint16_t v154 = static_cast<uint16_t>(v49);
            uint16_t v155 = static_cast<uint16_t>(v153);
            TEXTRACT(v151, v110, v154, v155);
            // pto: %1
            ;
            Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v156 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v52, v52);
            // pto: %1
            ;
            uint64_t v157 = (uint64_t) v39;
            TASSIGN(v156, v157);
            uint16_t v158 = static_cast<uint16_t>(v153);
            uint16_t v159 = static_cast<uint16_t>(v127);
            TEXTRACT(v156, v138, v158, v159);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
            // pto: %20
            ;
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            if (v142 == v49) {
              pipe_barrier(PIPE_M);
              TMATMUL(v140, v143, v147);
            } else {
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v140, v140, v143, v147);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            // pto: %21
            ;
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
            if (v142 == v54) {
              pipe_barrier(PIPE_M);
              TMATMUL(v140, v151, v156);
            } else {
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v140, v140, v151, v156);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          };
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          // pto: %22
          ;
          int64_t v160 = v105 < v49 ? v49 : v105;
          // pto: %23
          ;
          int64_t v161 = v124 < v49 ? v49 : v124;
          // pto: %score_transfer_inline58__ssa_v0_pview
          ;
          __gm__ float* v162 = PTOAS__GLOBAL_TENSOR_DATA(v82);
          // pto: %score_transfer_inline58__ssa_v0_pview
          ;
          const int64_t v163 = 0;
          // pto: %score_transfer_inline58__ssa_v0_pview
          ;
          const int64_t v164 = 512;
          // pto: %score_transfer_inline58__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 64, 128> v165 = pto::Shape<1, 1, 1, 64, 128>();
          // pto: %score_transfer_inline58__ssa_v0_pview
          ;
          pto::Stride<32768, 32768, 32768, 512, 1> v166 = pto::Stride<32768, 32768, 32768, 512, 1>();
          // pto: %score_transfer_inline58__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v167 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v162 + (v163 + v160 * v164 + v161), v165, v166);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
          pipe_barrier(PIPE_FIX);
          TSTORE(v167, v140);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        uint16_t v168 = getFFTSMsg(FFTS_MODE_VAL, v41);
        ffts_cross_core_sync(PIPE_FIX, v168);
        int32_t v169 = (int32_t) v50;
        wait_flag_dev(v169);
        // pto: %pv_acc_inline156__ssa_v0
        ;
        Tile<TileType::Acc, float, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v170 = Tile<TileType::Acc, float, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v46, v42);
        // pto: %pv_acc_inline156__ssa_v0
        ;
        uint64_t v171 = (uint64_t) v36;
        TASSIGN(v170, v171);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        for (int64_t v172 = v49; v172 < v51; v172 += v41) {
          // pto: %24
          ;
          int64_t v173 = (int64_t) ((uint64_t) v172 * (uint64_t) v52);
          // pto: %pv_probability_inline159__ssa_v0
          ;
          Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v52);
          // pto: %pv_probability_inline159__ssa_v0
          ;
          uint64_t v175 = (uint64_t) v40;
          TASSIGN(v174, v175);
          // pto: %25
          ;
          int64_t v176 = v105 < v49 ? v49 : v105;
          // pto: %26
          ;
          int64_t v177 = v173 < v49 ? v49 : v173;
          // pto: %probability_transfer_inline129__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v178 = PTOAS__GLOBAL_TENSOR_DATA(v90);
          // pto: %probability_transfer_inline129__ssa_v0_pview
          ;
          const int64_t v179 = 0;
          // pto: %probability_transfer_inline129__ssa_v0_pview
          ;
          const int64_t v180 = 512;
          // pto: %probability_transfer_inline129__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 64, 128> v181 = pto::Shape<1, 1, 1, 64, 128>();
          // pto: %probability_transfer_inline129__ssa_v0_pview
          ;
          pto::Stride<32768, 32768, 32768, 512, 1> v182 = pto::Stride<32768, 32768, 32768, 512, 1>();
          // pto: %probability_transfer_inline129__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v183 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v178 + (v179 + v176 * v180 + v177), v181, v182);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
          TLOAD(v174, v183);
          // pto: %27
          ;
          int64_t v184 = (int64_t) ((uint64_t) v172 - (uint64_t) v41);
          // pto: %28
          ;
          int64_t v185 = v184 < v49 ? v49 : v184;
          // pto: %29
          ;
          int64_t v186 = (int64_t) ((uint64_t) v185 * (uint64_t) v52);
          // pto: %30
          ;
          if (v172 < v50) {
            // pto: %31
            ;
            Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, 128, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v187;
            // pto: %31
            ;
            uint64_t v188 = (uint64_t) ((int64_t) (uint64_t) v186 * (uint64_t) v35);
            TASSIGN(v187, v188);
            // pto: %32
            ;
            int64_t v189 = (int64_t) ((uint64_t) v104 + (uint64_t) v173);
            // pto: %33
            ;
            int64_t v190 = v189 < v49 ? v49 : v189;
            // pto: %34
            ;
            __gm__ bfloat16_t* v191 = PTOAS__GLOBAL_TENSOR_DATA(v74);
            // pto: %34
            ;
            const int64_t v192 = 0;
            // pto: %34
            ;
            const int64_t v193 = 512;
            // pto: %34
            ;
            pto::Shape<1, 1, 1, 128, 512> v194 = pto::Shape<1, 1, 1, 128, 512>();
            // pto: %34
            ;
            pto::Stride<65536, 65536, 65536, 512, 1> v195 = pto::Stride<65536, 65536, 65536, 512, 1>();
            // pto: %34
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND> v196 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND>(v191 + (v192 + v190 * v193), v194, v195);
            TLOAD(v187, v196);
          };
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          for (int64_t v197 = v49; v197 < v52; v197 += v46) {
            // pto: %pv_acc_inline156__ssa_v3_l0_a
            ;
            Tile<TileType::Left, bfloat16_t, 64, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v198 = Tile<TileType::Left, bfloat16_t, 64, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v55);
            // pto: %pv_acc_inline156__ssa_v3_l0_a
            ;
            uint64_t v199 = (uint64_t) v36;
            TASSIGN(v198, v199);
            pipe_barrier(PIPE_MTE1);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
            uint16_t v200 = static_cast<uint16_t>(v49);
            uint16_t v201 = static_cast<uint16_t>(v197);
            TEXTRACT(v198, v174, v200, v201);
            // pto: %pv_acc_inline156__ssa_v3_l0_b
            ;
            Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v202 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v55, v42);
            // pto: %pv_acc_inline156__ssa_v3_l0_b
            ;
            uint64_t v203 = (uint64_t) v36;
            TASSIGN(v202, v203);
            // pto: %35
            ;
            int64_t v204 = (int64_t) ((uint64_t) v197 + (uint64_t) v186);
            uint16_t v205 = static_cast<uint16_t>(v204);
            uint16_t v206 = static_cast<uint16_t>(v49);
            TEXTRACT(v202, v101, v205, v206);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
            // pto: %3
            ;
            Tile<TileType::Left, bfloat16_t, 64, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Left, bfloat16_t, 64, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v55);
            // pto: %3
            ;
            uint64_t v208 = (uint64_t) v38;
            TASSIGN(v207, v208);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
            uint16_t v209 = static_cast<uint16_t>(v49);
            // pto: %36
            ;
            uint16_t v210 = static_cast<uint16_t>((int64_t) ((uint64_t) v197 + (uint64_t) v55));
            TEXTRACT(v207, v174, v209, v210);
            // pto: %4
            ;
            Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v55, v42);
            // pto: %4
            ;
            uint64_t v212 = (uint64_t) v39;
            TASSIGN(v211, v212);
            // pto: %38
            ;
            uint16_t v213 = static_cast<uint16_t>((int64_t) ((uint64_t) v204 + (uint64_t) v55));
            uint16_t v214 = static_cast<uint16_t>(v49);
            TEXTRACT(v211, v101, v213, v214);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
            // pto: %39
            ;
            bool v215 = v172 == v49;
            // pto: %40, %41
            ;
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
            if (v215 & v197 == v49) {
              pipe_barrier(PIPE_M);
              TMATMUL(v170, v198, v202);
            } else {
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v170, v170, v198, v202);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
            // pto: %43, %44
            ;
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
            if (v215 & v197 == v56) {
              pipe_barrier(PIPE_M);
              TMATMUL(v170, v207, v211);
            } else {
              pipe_barrier(PIPE_M);
              TMATMUL_ACC(v170, v170, v207, v211);
            };
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          };
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        };
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        // pto: %45
        ;
        int64_t v216 = v105 < v49 ? v49 : v105;
        // pto: %pv_transfer_inline148__ssa_v0_pview
        ;
        __gm__ float* v217 = PTOAS__GLOBAL_TENSOR_DATA(v98);
        // pto: %pv_transfer_inline148__ssa_v0_pview
        ;
        const int64_t v218 = 0;
        // pto: %pv_transfer_inline148__ssa_v0_pview
        ;
        const int64_t v219 = 512;
        // pto: %pv_transfer_inline148__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 64, 512> v220 = pto::Shape<1, 1, 1, 64, 512>();
        // pto: %pv_transfer_inline148__ssa_v0_pview
        ;
        pto::Stride<32768, 32768, 32768, 512, 1> v221 = pto::Stride<32768, 32768, 32768, 512, 1>();
        // pto: %pv_transfer_inline148__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v222 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v217 + (v218 + v216 * v219), v220, v221);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        pipe_barrier(PIPE_FIX);
        TSTORE(v222, v170);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        uint16_t v223 = getFFTSMsg(FFTS_MODE_VAL, v57);
        ffts_cross_core_sync(PIPE_FIX, v223);
      };
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    uint64_t v224 = reinterpret_cast<uint64_t>(v1);
    set_ffts_base_addr(v224);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void qk_pv_aiv(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, __gm__ int32_t* v4, __gm__ bfloat16_t* v5, __gm__ float* v6, __gm__ bfloat16_t* v7, __gm__ float* v8, __gm__ float* v9, __gm__ float* v10, __gm__ float* v11, __gm__ int64_t* v12, __gm__ int32_t* v13, __gm__ bfloat16_t* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, __gm__ bfloat16_t* v17, __gm__ float* v18, __gm__ float* v19, __gm__ float* v20, __gm__ float* v21, __gm__ float* v22, __gm__ float* v23, int64_t v24, int64_t v25, int64_t v26, int64_t v27, int64_t v28, int64_t v29, int64_t v30, int64_t v31, int64_t v32, int32_t v33, int32_t v34, int32_t v35) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v36 = 1024;
  // pto: %c128_i64
  const int64_t v37 = 128;
  // pto: %c16512_i64
  const int64_t v38 = 16512;
  // pto: %c82304_i64
  const int64_t v39 = 82304;
  // pto: %c16640_i64
  const int64_t v40 = 16640;
  // pto: %c16768_i64
  const int64_t v41 = 16768;
  // pto: %c49536_i64
  const int64_t v42 = 49536;
  // pto: %c98688_i64
  const int64_t v43 = 98688;
  // pto: %c98720_i64
  const int64_t v44 = 98720;
  // pto: %c117120_i64
  const int64_t v45 = 117120;
  // pto: %c117152_i64
  const int64_t v46 = 117152;
  // pto: %c117184_i64
  const int64_t v47 = 117184;
  // pto: %c117216_i64
  const int64_t v48 = 117216;
  // pto: %c100736_i64
  const int64_t v49 = 100736;
  // pto: %c101504_i64
  const int64_t v50 = 101504;
  const int64_t v51 = 82560;
  // pto: %c102784_i64
  const int64_t v52 = 102784;
  // pto: %c106880_i64
  const int64_t v53 = 106880;
  // pto: %c107136_i64
  const int64_t v54 = 107136;
  // pto: %c104832_i64
  const int64_t v55 = 104832;
  const int64_t v56 = 82816;
  // pto: %c108928_i64
  const int64_t v57 = 108928;
  // pto: %c109184_i64
  const int64_t v58 = 109184;
  const int64_t v59 = 83072;
  const int64_t v60 = 83328;
  const int64_t v61 = 83584;
  const int64_t v62 = 83840;
  const int64_t v63 = 84096;
  // pto: %c105088_i64
  const int64_t v64 = 105088;
  // pto: %c115072_i64
  const int64_t v65 = 115072;
  // pto: %c98944_i64
  const int64_t v66 = 98944;
  // pto: %c0_i64
  const int64_t v67 = 0;
  // pto: %c1_index
  const int64_t v68 = 1;
  // pto: %c512_index
  const int64_t v69 = 512;
  // pto: %c16_index
  const int64_t v70 = 16;
  // pto: %c12288_index
  const int64_t v71 = 12288;
  // pto: %c1536_index
  const int64_t v72 = 1536;
  // pto: %c64_index
  const int64_t v73 = 64;
  // pto: %c1024_index
  const int64_t v74 = 1024;
  // pto: %c24_index
  const int64_t v75 = 24;
  // pto: %c0_index
  const int64_t v76 = 0;
  // pto: %c32_index
  const int64_t v77 = 32;
  // pto: %c8_index
  const int64_t v78 = 8;
  // pto: %cst_42
  const float v79 = 0.0f;
  // pto: %cst_43
  const float v80 = 1.0f;
  // pto: %c256_index
  const int64_t v81 = 256;
  // pto: %c2_index
  const int64_t v82 = 2;
  // pto: %c4_index
  const int64_t v83 = 4;
  // pto: %c128_index
  const int64_t v84 = 128;
  // pto: %cst_48
  const bfloat16_t v85 = 0.0f;
  // pto: %c96_index
  const int64_t v86 = 96;
  // pto: %c160_index
  const int64_t v87 = 160;
  // pto: %cst_51
  const float v88 = 0.0441941731f;
  // pto: %c192_index
  const int64_t v89 = 192;
  // pto: %c0_i32
  const int32_t v90 = 0;
  // pto: %c320_index
  const int64_t v91 = 320;
  // pto: %c384_index
  const int64_t v92 = 384;
  // pto: %c448_index
  const int64_t v93 = 448;
  // pto: %c3_index
  const int64_t v94 = 3;
  // pto: %kv_transfer_inline91__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %kv_transfer_inline91__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %kv_transfer_inline91__ssa_v0_view
  const int64_t v97 = 1;
  // pto: %kv_transfer_inline91__ssa_v0_view
  int64_t v98 = v71 * v69;
  // pto: %kv_transfer_inline91__ssa_v0_view
  int64_t v99 = v97 * v98;
  // pto: %kv_transfer_inline91__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v100 = pto::Shape<1, 1, 1, -1, -1>(v95, v96, v97, v71, v69);
  // pto: %kv_transfer_inline91__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v101 = pto::Stride<-1, -1, -1, -1, -1>(v96 * v99, v99, v98, v69, v68);
  // pto: %kv_transfer_inline91__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v102 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v100, v101);
  // pto: %score_transfer_inline58__ssa_v0_view
  const int64_t v103 = 1;
  // pto: %score_transfer_inline58__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %score_transfer_inline58__ssa_v0_view
  const int64_t v105 = 1;
  // pto: %score_transfer_inline58__ssa_v0_view
  int64_t v106 = v72 * v69;
  // pto: %score_transfer_inline58__ssa_v0_view
  int64_t v107 = v105 * v106;
  // pto: %score_transfer_inline58__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v108 = pto::Shape<1, 1, 1, -1, -1>(v103, v104, v105, v72, v69);
  // pto: %score_transfer_inline58__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v109 = pto::Stride<-1, -1, -1, -1, -1>(v104 * v107, v107, v106, v69, v68);
  // pto: %score_transfer_inline58__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v110 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v108, v109);
  // pto: %probability_transfer_inline129__ssa_v0_view
  const int64_t v111 = 1;
  // pto: %probability_transfer_inline129__ssa_v0_view
  const int64_t v112 = 1;
  // pto: %probability_transfer_inline129__ssa_v0_view
  const int64_t v113 = 1;
  // pto: %probability_transfer_inline129__ssa_v0_view
  int64_t v114 = v72 * v69;
  // pto: %probability_transfer_inline129__ssa_v0_view
  int64_t v115 = v113 * v114;
  // pto: %probability_transfer_inline129__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v116 = pto::Shape<1, 1, 1, -1, -1>(v111, v112, v113, v72, v69);
  // pto: %probability_transfer_inline129__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v117 = pto::Stride<-1, -1, -1, -1, -1>(v112 * v115, v115, v114, v69, v68);
  // pto: %probability_transfer_inline129__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v118 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v116, v117);
  // pto: %pv_transfer_inline148__ssa_v0_view
  const int64_t v119 = 1;
  // pto: %pv_transfer_inline148__ssa_v0_view
  const int64_t v120 = 1;
  // pto: %pv_transfer_inline148__ssa_v0_view
  const int64_t v121 = 1;
  // pto: %pv_transfer_inline148__ssa_v0_view
  int64_t v122 = v72 * v69;
  // pto: %pv_transfer_inline148__ssa_v0_view
  int64_t v123 = v121 * v122;
  // pto: %pv_transfer_inline148__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v124 = pto::Shape<1, 1, 1, -1, -1>(v119, v120, v121, v72, v69);
  // pto: %pv_transfer_inline148__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v125 = pto::Stride<-1, -1, -1, -1, -1>(v120 * v123, v123, v122, v69, v68);
  // pto: %pv_transfer_inline148__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v126 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v124, v125);
  // pto: %attn_sink_col_inline115__ssa_v0_view
  const int64_t v127 = 1;
  // pto: %attn_sink_col_inline115__ssa_v0_view
  const int64_t v128 = 1;
  // pto: %attn_sink_col_inline115__ssa_v0_view
  const int64_t v129 = 1;
  // pto: %attn_sink_col_inline115__ssa_v0_view
  int64_t v130 = v73 * v68;
  // pto: %attn_sink_col_inline115__ssa_v0_view
  int64_t v131 = v129 * v130;
  // pto: %attn_sink_col_inline115__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v132 = pto::Shape<1, 1, 1, -1, -1>(v127, v128, v129, v73, v68);
  // pto: %attn_sink_col_inline115__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v133 = pto::Stride<-1, -1, -1, -1, -1>(v128 * v131, v131, v130, v68, v73);
  // pto: %attn_sink_col_inline115__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v134 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v9, v132, v133);
  // pto: %mi_transfer_inline133__ssa_v0_view
  const int64_t v135 = 1;
  // pto: %mi_transfer_inline133__ssa_v0_view
  const int64_t v136 = 1;
  // pto: %mi_transfer_inline133__ssa_v0_view
  const int64_t v137 = 1;
  // pto: %mi_transfer_inline133__ssa_v0_view
  int64_t v138 = v72 * v68;
  // pto: %mi_transfer_inline133__ssa_v0_view
  int64_t v139 = v137 * v138;
  // pto: %mi_transfer_inline133__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v140 = pto::Shape<1, 1, 1, -1, -1>(v135, v136, v137, v72, v68);
  // pto: %mi_transfer_inline133__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v141 = pto::Stride<-1, -1, -1, -1, -1>(v136 * v139, v139, v138, v68, v72);
  // pto: %mi_transfer_inline133__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v142 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v10, v140, v141);
  // pto: %li_transfer_inline138__ssa_v0_view
  const int64_t v143 = 1;
  // pto: %li_transfer_inline138__ssa_v0_view
  const int64_t v144 = 1;
  // pto: %li_transfer_inline138__ssa_v0_view
  const int64_t v145 = 1;
  // pto: %li_transfer_inline138__ssa_v0_view
  int64_t v146 = v72 * v68;
  // pto: %li_transfer_inline138__ssa_v0_view
  int64_t v147 = v145 * v146;
  // pto: %li_transfer_inline138__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v148 = pto::Shape<1, 1, 1, -1, -1>(v143, v144, v145, v72, v68);
  // pto: %li_transfer_inline138__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v149 = pto::Stride<-1, -1, -1, -1, -1>(v144 * v147, v147, v146, v68, v72);
  // pto: %li_transfer_inline138__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v150 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v11, v148, v149);
  // pto: %254
  int64_t v151 = (int64_t) ((uint64_t) v30 * (uint64_t) v77);
  // pto: %ori_kv_flat_inline146__ssa_v1_view
  const int64_t v152 = 1;
  // pto: %ori_kv_flat_inline146__ssa_v1_view
  const int64_t v153 = 1;
  // pto: %ori_kv_flat_inline146__ssa_v1_view
  const int64_t v154 = 1;
  // pto: %ori_kv_flat_inline146__ssa_v1_view
  int64_t v155 = v151 * v69;
  // pto: %ori_kv_flat_inline146__ssa_v1_view
  int64_t v156 = v154 * v155;
  // pto: %ori_kv_flat_inline146__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v157 = pto::Shape<1, 1, 1, -1, -1>(v152, v153, v154, v151, v69);
  // pto: %ori_kv_flat_inline146__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v158 = pto::Stride<-1, -1, -1, -1, -1>(v153 * v156, v156, v155, v69, v68);
  // pto: %ori_kv_flat_inline146__ssa_v1_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v159 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v157, v158);
  // pto: %255
  int64_t v160 = (int64_t) ((uint64_t) v32 * (uint64_t) v77);
  // pto: %cmp_kv_flat_inline100__ssa_v0_view
  const int64_t v161 = 1;
  // pto: %cmp_kv_flat_inline100__ssa_v0_view
  const int64_t v162 = 1;
  // pto: %cmp_kv_flat_inline100__ssa_v0_view
  const int64_t v163 = 1;
  // pto: %cmp_kv_flat_inline100__ssa_v0_view
  int64_t v164 = v160 * v69;
  // pto: %cmp_kv_flat_inline100__ssa_v0_view
  int64_t v165 = v163 * v164;
  // pto: %cmp_kv_flat_inline100__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v166 = pto::Shape<1, 1, 1, -1, -1>(v161, v162, v163, v160, v69);
  // pto: %cmp_kv_flat_inline100__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v167 = pto::Stride<-1, -1, -1, -1, -1>(v162 * v165, v165, v164, v69, v68);
  // pto: %cmp_kv_flat_inline100__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v168 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v17, v166, v167);
  // pto: %sparse_bias_inline110__rv_v2_view
  const int64_t v169 = 1;
  // pto: %sparse_bias_inline110__rv_v2_view
  const int64_t v170 = 1;
  // pto: %sparse_bias_inline110__rv_v2_view
  const int64_t v171 = 1;
  // pto: %sparse_bias_inline110__rv_v2_view
  int64_t v172 = (int64_t) v27;
  // pto: %sparse_bias_inline110__rv_v2_view
  int64_t v173 = v172 * v74;
  // pto: %sparse_bias_inline110__rv_v2_view
  int64_t v174 = v171 * v173;
  // pto: %sparse_bias_inline110__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v175 = pto::Shape<1, 1, 1, -1, -1>(v169, v170, v171, v172, v74);
  // pto: %sparse_bias_inline110__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v176 = pto::Stride<-1, -1, -1, -1, -1>(v170 * v174, v174, v173, v74, v68);
  // pto: %sparse_bias_inline110__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v177 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v18, v175, v176);
  // pto: %softmax_copy64_inline94__ssa_v0_view
  const int64_t v178 = 1;
  // pto: %softmax_copy64_inline94__ssa_v0_view
  const int64_t v179 = 1;
  // pto: %softmax_copy64_inline94__ssa_v0_view
  const int64_t v180 = 1;
  // pto: %softmax_copy64_inline94__ssa_v0_view
  int64_t v181 = v72 * v73;
  // pto: %softmax_copy64_inline94__ssa_v0_view
  int64_t v182 = v180 * v181;
  // pto: %softmax_copy64_inline94__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v183 = pto::Shape<1, 1, 1, -1, -1>(v178, v179, v180, v72, v73);
  // pto: %softmax_copy64_inline94__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v184 = pto::Stride<-1, -1, -1, -1, -1>(v179 * v182, v182, v181, v73, v68);
  // pto: %softmax_copy64_inline94__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v185 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v19, v183, v184);
  // pto: %alpha_transfer_inline49__ssa_v0_view
  const int64_t v186 = 1;
  // pto: %alpha_transfer_inline49__ssa_v0_view
  const int64_t v187 = 1;
  // pto: %alpha_transfer_inline49__ssa_v0_view
  const int64_t v188 = 1;
  // pto: %alpha_transfer_inline49__ssa_v0_view
  int64_t v189 = v72 * v68;
  // pto: %alpha_transfer_inline49__ssa_v0_view
  int64_t v190 = v188 * v189;
  // pto: %alpha_transfer_inline49__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v191 = pto::Shape<1, 1, 1, -1, -1>(v186, v187, v188, v72, v68);
  // pto: %alpha_transfer_inline49__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v192 = pto::Stride<-1, -1, -1, -1, -1>(v187 * v190, v190, v189, v68, v72);
  // pto: %alpha_transfer_inline49__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v193 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v20, v191, v192);
  // pto: %attn_mi_inline68__ssa_v0_view
  const int64_t v194 = 1;
  // pto: %attn_mi_inline68__ssa_v0_view
  const int64_t v195 = 1;
  // pto: %attn_mi_inline68__ssa_v0_view
  const int64_t v196 = 1;
  // pto: %attn_mi_inline68__ssa_v0_view
  int64_t v197 = (int64_t) v26;
  // pto: %attn_mi_inline68__ssa_v0_view
  int64_t v198 = v197 * v68;
  // pto: %attn_mi_inline68__ssa_v0_view
  int64_t v199 = v196 * v198;
  // pto: %attn_mi_inline68__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v200 = pto::Shape<1, 1, 1, -1, -1>(v194, v195, v196, v197, v68);
  // pto: %attn_mi_inline68__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v201 = pto::Stride<-1, -1, -1, -1, -1>(v195 * v199, v199, v198, v68, (int64_t) v26);
  // pto: %attn_mi_inline68__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v202 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v21, v200, v201);
  // pto: %attn_li_inline47__ssa_v0_view
  const int64_t v203 = 1;
  // pto: %attn_li_inline47__ssa_v0_view
  const int64_t v204 = 1;
  // pto: %attn_li_inline47__ssa_v0_view
  const int64_t v205 = 1;
  // pto: %attn_li_inline47__ssa_v0_view
  int64_t v206 = (int64_t) v26;
  // pto: %attn_li_inline47__ssa_v0_view
  int64_t v207 = v206 * v68;
  // pto: %attn_li_inline47__ssa_v0_view
  int64_t v208 = v205 * v207;
  // pto: %attn_li_inline47__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v209 = pto::Shape<1, 1, 1, -1, -1>(v203, v204, v205, v206, v68);
  // pto: %attn_li_inline47__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v210 = pto::Stride<-1, -1, -1, -1, -1>(v204 * v208, v208, v207, v68, (int64_t) v26);
  // pto: %attn_li_inline47__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v211 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v22, v209, v210);
  // pto: %attn_oi_inline61__ssa_v0_view
  const int64_t v212 = 1;
  // pto: %attn_oi_inline61__ssa_v0_view
  const int64_t v213 = 1;
  // pto: %attn_oi_inline61__ssa_v0_view
  const int64_t v214 = 1;
  // pto: %attn_oi_inline61__ssa_v0_view
  int64_t v215 = (int64_t) v26;
  // pto: %attn_oi_inline61__ssa_v0_view
  int64_t v216 = v215 * v69;
  // pto: %attn_oi_inline61__ssa_v0_view
  int64_t v217 = v214 * v216;
  // pto: %attn_oi_inline61__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v218 = pto::Shape<1, 1, 1, -1, -1>(v212, v213, v214, v215, v69);
  // pto: %attn_oi_inline61__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v219 = pto::Stride<-1, -1, -1, -1, -1>(v213 * v217, v217, v216, v69, v68);
  // pto: %attn_oi_inline61__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v220 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v23, v218, v219);
  // pto: %m_after_inline140__rv_v0
  Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v221 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v77, v68);
  // pto: %m_after_inline140__rv_v0
  uint64_t v222 = (uint64_t) v38;
  TASSIGN(v221, v222);
  // pto: %l_after_inline101__rv_v0
  Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v223 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v77, v68);
  // pto: %l_after_inline101__rv_v0
  uint64_t v224 = (uint64_t) v40;
  TASSIGN(v223, v224);
  // pto: %left_after_inline53__rv_v0
  Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v225 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v77, v81);
  // pto: %left_after_inline53__rv_v0
  uint64_t v226 = (uint64_t) v41;
  TASSIGN(v225, v226);
  // pto: %right_after_inline84__rv_v0
  Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v77, v81);
  // pto: %right_after_inline84__rv_v0
  uint64_t v228 = (uint64_t) v42;
  TASSIGN(v227, v228);
  // pto: %qk_kv_half_inline170__phi_v22
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v229 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v69);
  // pto: %qk_kv_half_inline170__phi_v22
  uint64_t v230 = (uint64_t) v39;
  TASSIGN(v229, v230);
  // pto: %qk_kv_half_inline170__phi_v3
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v231 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v69);
  // pto: %qk_kv_half_inline170__phi_v3
  uint64_t v232 = (uint64_t) v39;
  TASSIGN(v231, v232);
  // pto: %qk_kv_half_inline170__phi_v2
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v69);
  // pto: %qk_kv_half_inline170__phi_v2
  uint64_t v234 = (uint64_t) v39;
  TASSIGN(v233, v234);
  // pto: %qk_kv_half_inline170__phi_v6
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v69);
  // pto: %qk_kv_half_inline170__phi_v6
  uint64_t v236 = (uint64_t) v39;
  TASSIGN(v235, v236);
  // pto: %qk_kv_half_inline170__phi_v5
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v237 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v69);
  // pto: %qk_kv_half_inline170__phi_v5
  uint64_t v238 = (uint64_t) v39;
  TASSIGN(v237, v238);
  // pto: %qk_kv_half_inline170__phi_v9
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v239 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v69);
  // pto: %qk_kv_half_inline170__phi_v9
  uint64_t v240 = (uint64_t) v39;
  TASSIGN(v239, v240);
  // pto: %qk_kv_half_inline170__phi_v8
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v241 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v69);
  // pto: %qk_kv_half_inline170__phi_v8
  uint64_t v242 = (uint64_t) v39;
  TASSIGN(v241, v242);
  // pto: %qk_kv_half_inline170__phi_v12
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v69);
  // pto: %qk_kv_half_inline170__phi_v12
  uint64_t v244 = (uint64_t) v39;
  TASSIGN(v243, v244);
  // pto: %qk_kv_half_inline170__phi_v11
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v245 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v69);
  // pto: %qk_kv_half_inline170__phi_v11
  uint64_t v246 = (uint64_t) v39;
  TASSIGN(v245, v246);
  // pto: %qk_kv_half_inline170__phi_v15
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v247 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v69);
  // pto: %qk_kv_half_inline170__phi_v15
  uint64_t v248 = (uint64_t) v39;
  TASSIGN(v247, v248);
  // pto: %qk_kv_half_inline170__phi_v14
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v249 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v69);
  // pto: %qk_kv_half_inline170__phi_v14
  uint64_t v250 = (uint64_t) v39;
  TASSIGN(v249, v250);
  // pto: %qk_kv_half_inline170__phi_v21
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v251 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v69);
  // pto: %qk_kv_half_inline170__phi_v21
  uint64_t v252 = (uint64_t) v39;
  TASSIGN(v251, v252);
  // pto: %qk_kv_half_inline170__phi_v20
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v253 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v69);
  // pto: %qk_kv_half_inline170__phi_v20
  uint64_t v254 = (uint64_t) v39;
  TASSIGN(v253, v254);
  // pto: %qk_kv_half_inline170__phi_v19
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v69);
  // pto: %qk_kv_half_inline170__phi_v19
  uint64_t v256 = (uint64_t) v39;
  TASSIGN(v255, v256);
  // pto: %sm_block_sum_inline28__phi_v4
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v257 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v68);
  // pto: %sm_block_sum_inline28__phi_v4
  uint64_t v258 = (uint64_t) v48;
  TASSIGN(v257, v258);
  // pto: %sm_block_sum_inline28__phi_v3
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v259 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v68);
  // pto: %sm_block_sum_inline28__phi_v3
  uint64_t v260 = (uint64_t) v48;
  TASSIGN(v259, v260);
  // pto: %sm_fold64_inline57__phi_v4
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v261 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %sm_fold64_inline57__phi_v4
  uint64_t v262 = (uint64_t) v55;
  TASSIGN(v261, v262);
  // pto: %sm_fold64_inline57__phi_v3
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v263 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %sm_fold64_inline57__phi_v3
  uint64_t v264 = (uint64_t) v55;
  TASSIGN(v263, v264);
  // pto: %sm_fold64_inline57__phi_v8
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v265 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %sm_fold64_inline57__phi_v8
  uint64_t v266 = (uint64_t) v53;
  TASSIGN(v265, v266);
  // pto: %sm_fold64_inline57__phi_v7
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v267 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %sm_fold64_inline57__phi_v7
  uint64_t v268 = (uint64_t) v53;
  TASSIGN(v267, v268);
  // pto: %sm_fold64_inline57__phi_v12
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %sm_fold64_inline57__phi_v12
  uint64_t v270 = (uint64_t) v55;
  TASSIGN(v269, v270);
  // pto: %sm_fold64_inline57__phi_v11
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v271 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %sm_fold64_inline57__phi_v11
  uint64_t v272 = (uint64_t) v55;
  TASSIGN(v271, v272);
  // pto: %sm_fold64_inline57__phi_v16
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %sm_fold64_inline57__phi_v16
  uint64_t v274 = (uint64_t) v53;
  TASSIGN(v273, v274);
  // pto: %sm_fold64_inline57__phi_v15
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %sm_fold64_inline57__phi_v15
  uint64_t v276 = (uint64_t) v53;
  TASSIGN(v275, v276);
  // pto: %sm_fold64_inline57__phi_v20
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %sm_fold64_inline57__phi_v20
  uint64_t v278 = (uint64_t) v55;
  TASSIGN(v277, v278);
  // pto: %sm_fold64_inline57__phi_v19
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %sm_fold64_inline57__phi_v19
  uint64_t v280 = (uint64_t) v55;
  TASSIGN(v279, v280);
  // pto: %sm_fold64_inline57__phi_v24
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %sm_fold64_inline57__phi_v24
  uint64_t v282 = (uint64_t) v53;
  TASSIGN(v281, v282);
  // pto: %sm_fold64_inline57__phi_v23
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v283 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %sm_fold64_inline57__phi_v23
  uint64_t v284 = (uint64_t) v53;
  TASSIGN(v283, v284);
  // pto: %sm_fold64_inline57__phi_v28
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %sm_fold64_inline57__phi_v28
  uint64_t v286 = (uint64_t) v43;
  TASSIGN(v285, v286);
  // pto: %qk_core_inline128__ssa_v0
  int64_t v287 = (int64_t) v33;
  uint64_t v288 = reinterpret_cast<uint64_t>(v1);
  set_ffts_base_addr(v288);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  for (int64_t v289 = v287; v289 < v24; v289 += v75) {
    // pto: %t__tile
    ;
    int32_t v290 = (v2)[v289];
    // pto: %3
    ;
    int64_t v291 = (int64_t) v290;
    // pto: %4
    ;
    int64_t v292 = v291 < v76 ? v76 : v291;
    // pto: %qk_aiv_inline163__ssa_v0
    ;
    int64_t v293 = (int64_t) v35;
    uint64_t v294 = reinterpret_cast<uint64_t>(v1);
    set_ffts_base_addr(v294);
    // pto: %5
    ;
    int64_t v295 = (int64_t) ((uint64_t) v293 * (uint64_t) v77);
    // pto: %qk_reduce_tmp_inline82__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v69);
    // pto: %qk_reduce_tmp_inline82__ssa_v0
    ;
    uint64_t v297 = (uint64_t) v37;
    TASSIGN(v296, v297);
    // pto: %running_m_inline166__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v77, v68);
    // pto: %running_m_inline166__ssa_v0
    ;
    uint64_t v299 = (uint64_t) v38;
    TASSIGN(v298, v299);
    // pto: %7
    ;
    int64_t v300 = v295 < v76 ? v76 : v295;
    // pto: %attn_sink_col_inline115__ssa_v0_pview
    ;
    __gm__ float* v301 = PTOAS__GLOBAL_TENSOR_DATA(v134);
    // pto: %attn_sink_col_inline115__ssa_v0_pview
    ;
    const int64_t v302 = 0;
    // pto: %attn_sink_col_inline115__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 1> v303 = pto::Shape<1, 1, 1, 32, 1>();
    // pto: %attn_sink_col_inline115__ssa_v0_pview
    ;
    pto::Stride<32, 32, 32, 1, 64> v304 = pto::Stride<32, 32, 32, 1, 64>();
    // pto: %attn_sink_col_inline115__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 64>, pto::Layout::DN> v305 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 64>, pto::Layout::DN>(v301 + (v302 + v300), v303, v304);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v298, v305);
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %t__rm_a0_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v77);
    // pto: %t__rm_a0_tmp_v0
    ;
    uint64_t v307 = (uint64_t) v38;
    TASSIGN(v306, v307);
    // pto: %t__row_major_tmp_v1
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v308 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v77);
    // pto: %t__row_major_tmp_v1
    ;
    uint64_t v309 = (uint64_t) v39;
    TASSIGN(v308, v309);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    TMULS(v308, v306, v79);
    // pto: %t__tmp_v43
    ;
    Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v310 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v77, v68);
    // pto: %t__tmp_v43
    ;
    uint64_t v311 = (uint64_t) v39;
    TASSIGN(v310, v311);
    // pto: %running_l_inline134__rm_a0_tmp_v2
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v77);
    // pto: %running_l_inline134__rm_a0_tmp_v2
    ;
    uint64_t v313 = (uint64_t) v39;
    TASSIGN(v312, v313);
    // pto: %running_l_inline134__row_major_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v314 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v77);
    // pto: %running_l_inline134__row_major_tmp_v3
    ;
    uint64_t v315 = (uint64_t) v40;
    TASSIGN(v314, v315);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    TADDS(v314, v312, v80);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %running_l_inline134__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v316 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v77, v68);
    // pto: %running_l_inline134__ssa_v0
    ;
    uint64_t v317 = (uint64_t) v40;
    TASSIGN(v316, v317);
    // pto: %running_left_inline168__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v318 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v77, v81);
    // pto: %running_left_inline168__ssa_v0
    ;
    uint64_t v319 = (uint64_t) v41;
    TASSIGN(v318, v319);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    TEXPANDS(v318, v79);
    // pto: %running_right_inline46__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v320 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v77, v81);
    // pto: %running_right_inline46__ssa_v0
    ;
    uint64_t v321 = (uint64_t) v42;
    TASSIGN(v320, v321);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    TEXPANDS(v320, v79);
    // pto: %2, %8
    ;
    int64_t v322 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v287 * (uint64_t) v73) + (uint64_t) v295);
    // pto: %9
    ;
    int64_t v323 = v322 < v76 ? v76 : v322;
    // pto: %mi_transfer_inline133__ssa_v0_pview
    ;
    __gm__ float* v324 = PTOAS__GLOBAL_TENSOR_DATA(v142);
    // pto: %mi_transfer_inline133__ssa_v0_pview
    ;
    const int64_t v325 = 0;
    // pto: %mi_transfer_inline133__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 1> v326 = pto::Shape<1, 1, 1, 32, 1>();
    // pto: %mi_transfer_inline133__ssa_v0_pview
    ;
    pto::Stride<32, 32, 32, 1, 1536> v327 = pto::Stride<32, 32, 32, 1, 1536>();
    // pto: %mi_transfer_inline133__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN> v328 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN>(v324 + (v325 + v323), v326, v327);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    TSTORE(v328, v298);
    // pto: %li_transfer_inline138__ssa_v0_pview
    ;
    __gm__ float* v329 = PTOAS__GLOBAL_TENSOR_DATA(v150);
    // pto: %li_transfer_inline138__ssa_v0_pview
    ;
    const int64_t v330 = 0;
    // pto: %li_transfer_inline138__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 1> v331 = pto::Shape<1, 1, 1, 32, 1>();
    // pto: %li_transfer_inline138__ssa_v0_pview
    ;
    pto::Stride<32, 32, 32, 1, 1536> v332 = pto::Stride<32, 32, 32, 1, 1536>();
    // pto: %li_transfer_inline138__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN> v333 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN>(v329 + (v330 + v323), v331, v332);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v333, v316);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    for (int64_t v334 = v76; v334 < v82; v334 += v68) {
      // pto: %flat_offset_mul, %flat_offset, %12
      ;
      int32_t v335 = (v4)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v289 * (uint64_t) v70) + (uint64_t) v334)];
      // pto: %13, %14
      ;
      if ((int64_t) v335 > v76) {
        for (int64_t v336 = v76; v336 < v83; v336 += v68) {
          // pto: %15, %16, %6
          ;
          int64_t v337 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v336 * (uint64_t) v84) + (uint64_t) ((int64_t) (uint64_t) v293 * (uint64_t) v73));
          // pto: %0
          ;
          Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v338 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v69);
          // pto: %0
          ;
          uint64_t v339 = (uint64_t) v39;
          TASSIGN(v338, v339);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
          TEXPANDS(v338, v85);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          // pto: %17
          ;
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          if (v334 == v76) {
            // pto: %18
            ;
            int64_t v340 = (v12)[v289];
            // pto: %22
            ;
            int64_t v341 = (int64_t) ((uint64_t) v340 + (uint64_t) v68);
            // pto: %23
            ;
            int64_t v342 = v341 < v84 ? v341 : v84;
            // pto: %24, %25
            ;
            int64_t v343 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v340 - (uint64_t) v342) + (uint64_t) v68);
            // pto: %26
            ;
            int64_t v344 = v343 % v77;
            // pto: %27
            ;
            int64_t v345 = (int64_t) ((uint64_t) v342 - (uint64_t) v337);
            // pto: %28
            ;
            int64_t v346 = v345 < v76 ? v76 : v345;
            // pto: %29
            ;
            int64_t v347 = v346 < v73 ? v346 : v73;
            // pto: %30, %31
            ;
            int64_t v348 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v77 - (uint64_t) v344) - (uint64_t) v337);
            // pto: %32
            ;
            int64_t v349 = v348 < v347 ? v348 : v347;
            // pto: %33
            ;
            if (v349 > v76) {
              // pto: %34
              ;
              int64_t v350 = (int64_t) ((uint64_t) v343 + (uint64_t) v337);
              // pto: %37, %38, %36, %qk_raw_page_inline179__tile
              ;
              int32_t v351 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v292 * (uint64_t) v29) + (uint64_t) (v350 / v77))];
              // pto: %39
              ;
              int64_t v352 = (int64_t) v351;
              // pto: %40
              ;
              if (v352 >= v76) {
                // pto: %42, %44, %43
                ;
                int64_t v353 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v352 * (uint64_t) v77) + (uint64_t) (v350 % v77));
                // pto: %gather_row_view
                ;
                Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v354 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v349);
                // pto: %gather_row_view
                ;
                uint64_t v355 = (uint64_t) v39;
                TASSIGN(v354, v355);
                // pto: %46
                ;
                int64_t v356 = v353 < v76 ? v76 : v353;
                // pto: %ori_kv_flat_inline146__ssa_v1_pview
                ;
                const int64_t v357 = 0;
                // pto: %ori_kv_flat_inline146__ssa_v1_pview
                ;
                __gm__ bfloat16_t* v358 = PTOAS__GLOBAL_TENSOR_DATA(v159);
                // pto: %ori_kv_flat_inline146__ssa_v1_pview
                ;
                const int64_t v359 = 1;
                // pto: %ori_kv_flat_inline146__ssa_v1_pview
                ;
                const int64_t v360 = 1;
                // pto: %ori_kv_flat_inline146__ssa_v1_pview
                ;
                const int64_t v361 = 1;
                // pto: %ori_kv_flat_inline146__ssa_v1_pview
                ;
                int64_t v362 = v349 * v69;
                // pto: %ori_kv_flat_inline146__ssa_v1_pview
                ;
                int64_t v363 = v361 * v362;
                // pto: %ori_kv_flat_inline146__ssa_v1_pview
                ;
                pto::Shape<1, 1, 1, -1, 512> v364 = pto::Shape<1, 1, 1, -1, 512>(v359, v360, v361, v349, v69);
                // pto: %ori_kv_flat_inline146__ssa_v1_pview
                ;
                pto::Stride<-1, -1, -1, -1, -1> v365 = pto::Stride<-1, -1, -1, -1, -1>(v360 * v363, v363, v362, v69, v68);
                // pto: %ori_kv_flat_inline146__ssa_v1_pview
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v366 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v358 + (v357 + v356 * v69 + v76 * v68), v364, v365);
                TLOAD(v354, v366);
              };
            };
            // pto: %49
            ;
            int64_t v367 = v348 < v76 ? v76 : v348;
            // pto: %50, %51
            ;
            int64_t v368 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v73 - (uint64_t) v344) - (uint64_t) v337);
            // pto: %52
            ;
            int64_t v369 = v368 < v347 ? v368 : v347;
            // pto: %53
            ;
            if (v367 < v369) {
              // pto: %54, %55
              ;
              int64_t v370 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v343 + (uint64_t) v337) + (uint64_t) v367);
              // pto: %58, %59, %57, %56
              ;
              int32_t v371 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v292 * (uint64_t) v29) + (uint64_t) (v370 / v77))];
              // pto: %60
              ;
              int64_t v372 = (int64_t) v371;
              // pto: %61
              ;
              if (v372 >= v76) {
                // pto: %63, %65, %64
                ;
                int64_t v373 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v372 * (uint64_t) v77) + (uint64_t) (v370 % v77));
                // pto: %66
                ;
                int64_t v374 = (int64_t) ((uint64_t) v369 - (uint64_t) v367);
                // pto: %67
                ;
                Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v375 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v374);
                // pto: %67
                ;
                uint64_t v376 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v367 * (uint64_t) v36) + (uint64_t) v39);
                TASSIGN(v375, v376);
                // pto: %68
                ;
                int64_t v377 = v373 < v76 ? v76 : v373;
                // pto: %69
                ;
                const int64_t v378 = 0;
                // pto: %69
                ;
                __gm__ bfloat16_t* v379 = PTOAS__GLOBAL_TENSOR_DATA(v159);
                // pto: %69
                ;
                const int64_t v380 = 1;
                // pto: %69
                ;
                const int64_t v381 = 1;
                // pto: %69
                ;
                const int64_t v382 = 1;
                // pto: %69
                ;
                int64_t v383 = v374 * v69;
                // pto: %69
                ;
                int64_t v384 = v382 * v383;
                // pto: %69
                ;
                pto::Shape<1, 1, 1, -1, 512> v385 = pto::Shape<1, 1, 1, -1, 512>(v380, v381, v382, v374, v69);
                // pto: %69
                ;
                pto::Stride<-1, -1, -1, -1, -1> v386 = pto::Stride<-1, -1, -1, -1, -1>(v381 * v384, v384, v383, v69, v68);
                // pto: %69
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v387 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v379 + (v378 + v377 * v69 + v76 * v68), v385, v386);
                TLOAD(v375, v387);
              };
            };
            // pto: %72
            ;
            int64_t v388 = v368 < v76 ? v76 : v368;
            // pto: %73, %74
            ;
            int64_t v389 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v86 - (uint64_t) v344) - (uint64_t) v337);
            // pto: %75
            ;
            int64_t v390 = v389 < v347 ? v389 : v347;
            // pto: %76
            ;
            if (v388 < v390) {
              // pto: %77, %78
              ;
              int64_t v391 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v343 + (uint64_t) v337) + (uint64_t) v388);
              // pto: %81, %82, %80, %79
              ;
              int32_t v392 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v292 * (uint64_t) v29) + (uint64_t) (v391 / v77))];
              // pto: %83
              ;
              int64_t v393 = (int64_t) v392;
              // pto: %84
              ;
              if (v393 >= v76) {
                // pto: %86, %88, %87
                ;
                int64_t v394 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v393 * (uint64_t) v77) + (uint64_t) (v391 % v77));
                // pto: %89
                ;
                int64_t v395 = (int64_t) ((uint64_t) v390 - (uint64_t) v388);
                // pto: %90
                ;
                Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v396 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v395);
                // pto: %90
                ;
                uint64_t v397 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v388 * (uint64_t) v36) + (uint64_t) v39);
                TASSIGN(v396, v397);
                // pto: %91
                ;
                int64_t v398 = v394 < v76 ? v76 : v394;
                // pto: %92
                ;
                const int64_t v399 = 0;
                // pto: %92
                ;
                __gm__ bfloat16_t* v400 = PTOAS__GLOBAL_TENSOR_DATA(v159);
                // pto: %92
                ;
                const int64_t v401 = 1;
                // pto: %92
                ;
                const int64_t v402 = 1;
                // pto: %92
                ;
                const int64_t v403 = 1;
                // pto: %92
                ;
                int64_t v404 = v395 * v69;
                // pto: %92
                ;
                int64_t v405 = v403 * v404;
                // pto: %92
                ;
                pto::Shape<1, 1, 1, -1, 512> v406 = pto::Shape<1, 1, 1, -1, 512>(v401, v402, v403, v395, v69);
                // pto: %92
                ;
                pto::Stride<-1, -1, -1, -1, -1> v407 = pto::Stride<-1, -1, -1, -1, -1>(v402 * v405, v405, v404, v69, v68);
                // pto: %92
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v408 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v400 + (v399 + v398 * v69 + v76 * v68), v406, v407);
                TLOAD(v396, v408);
              };
            };
            // pto: %95
            ;
            int64_t v409 = v389 < v76 ? v76 : v389;
            // pto: %96, %97
            ;
            int64_t v410 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v84 - (uint64_t) v344) - (uint64_t) v337);
            // pto: %98
            ;
            int64_t v411 = v410 < v347 ? v410 : v347;
            // pto: %99
            ;
            if (v409 < v411) {
              // pto: %100, %101
              ;
              int64_t v412 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v343 + (uint64_t) v337) + (uint64_t) v409);
              // pto: %104, %105, %103, %102
              ;
              int32_t v413 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v292 * (uint64_t) v29) + (uint64_t) (v412 / v77))];
              // pto: %106
              ;
              int64_t v414 = (int64_t) v413;
              // pto: %107
              ;
              if (v414 >= v76) {
                // pto: %109, %111, %110
                ;
                int64_t v415 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v414 * (uint64_t) v77) + (uint64_t) (v412 % v77));
                // pto: %112
                ;
                int64_t v416 = (int64_t) ((uint64_t) v411 - (uint64_t) v409);
                // pto: %113
                ;
                Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v417 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v416);
                // pto: %113
                ;
                uint64_t v418 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v409 * (uint64_t) v36) + (uint64_t) v39);
                TASSIGN(v417, v418);
                // pto: %114
                ;
                int64_t v419 = v415 < v76 ? v76 : v415;
                // pto: %115
                ;
                const int64_t v420 = 0;
                // pto: %115
                ;
                __gm__ bfloat16_t* v421 = PTOAS__GLOBAL_TENSOR_DATA(v159);
                // pto: %115
                ;
                const int64_t v422 = 1;
                // pto: %115
                ;
                const int64_t v423 = 1;
                // pto: %115
                ;
                const int64_t v424 = 1;
                // pto: %115
                ;
                int64_t v425 = v416 * v69;
                // pto: %115
                ;
                int64_t v426 = v424 * v425;
                // pto: %115
                ;
                pto::Shape<1, 1, 1, -1, 512> v427 = pto::Shape<1, 1, 1, -1, 512>(v422, v423, v424, v416, v69);
                // pto: %115
                ;
                pto::Stride<-1, -1, -1, -1, -1> v428 = pto::Stride<-1, -1, -1, -1, -1>(v423 * v426, v426, v425, v69, v68);
                // pto: %115
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v429 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v421 + (v420 + v419 * v69 + v76 * v68), v427, v428);
                TLOAD(v417, v429);
              };
            };
            // pto: %118
            ;
            int64_t v430 = v410 < v76 ? v76 : v410;
            // pto: %119, %120
            ;
            int64_t v431 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v87 - (uint64_t) v344) - (uint64_t) v337);
            // pto: %121
            ;
            int64_t v432 = v431 < v347 ? v431 : v347;
            // pto: %122
            ;
            if (v430 < v432) {
              // pto: %123, %124
              ;
              int64_t v433 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v343 + (uint64_t) v337) + (uint64_t) v430);
              // pto: %127, %128, %126, %125
              ;
              int32_t v434 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v292 * (uint64_t) v29) + (uint64_t) (v433 / v77))];
              // pto: %129
              ;
              int64_t v435 = (int64_t) v434;
              // pto: %130
              ;
              if (v435 >= v76) {
                // pto: %132, %134, %133
                ;
                int64_t v436 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v435 * (uint64_t) v77) + (uint64_t) (v433 % v77));
                // pto: %135
                ;
                int64_t v437 = (int64_t) ((uint64_t) v432 - (uint64_t) v430);
                // pto: %136
                ;
                Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v438 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v437);
                // pto: %136
                ;
                uint64_t v439 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v430 * (uint64_t) v36) + (uint64_t) v39);
                TASSIGN(v438, v439);
                // pto: %137
                ;
                int64_t v440 = v436 < v76 ? v76 : v436;
                // pto: %138
                ;
                const int64_t v441 = 0;
                // pto: %138
                ;
                __gm__ bfloat16_t* v442 = PTOAS__GLOBAL_TENSOR_DATA(v159);
                // pto: %138
                ;
                const int64_t v443 = 1;
                // pto: %138
                ;
                const int64_t v444 = 1;
                // pto: %138
                ;
                const int64_t v445 = 1;
                // pto: %138
                ;
                int64_t v446 = v437 * v69;
                // pto: %138
                ;
                int64_t v447 = v445 * v446;
                // pto: %138
                ;
                pto::Shape<1, 1, 1, -1, 512> v448 = pto::Shape<1, 1, 1, -1, 512>(v443, v444, v445, v437, v69);
                // pto: %138
                ;
                pto::Stride<-1, -1, -1, -1, -1> v449 = pto::Stride<-1, -1, -1, -1, -1>(v444 * v447, v447, v446, v69, v68);
                // pto: %138
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v450 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v442 + (v441 + v440 * v69 + v76 * v68), v448, v449);
                TLOAD(v438, v450);
              };
            };
          } else {
            pipe_barrier(PIPE_V);
            TEXPANDS(v338, v85);
            set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
            wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
            for (int64_t v451 = v76; v451 < v73; v451 += v68) {
              // pto: %139, %140, %141, %142
              ;
              int64_t v452 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v334 - (uint64_t) v68) * (uint64_t) v69) + (uint64_t) v337) + (uint64_t) v451);
              // pto: %143
              ;
              if (v452 < v69) {
                // pto: %144, %145, %qk_ridx_inline41__tile
                ;
                int32_t v453 = (v15)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v289 * (uint64_t) v69) + (uint64_t) v452)];
                // pto: %146
                ;
                int64_t v454 = (int64_t) v453;
                // pto: %147
                ;
                if (v454 >= v76) {
                  // pto: %151, %152, %150, %148
                  ;
                  int32_t v455 = (v16)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v292 * (uint64_t) v31) + (uint64_t) (v454 / v77))];
                  // pto: %153
                  ;
                  int64_t v456 = (int64_t) v455;
                  // pto: %154
                  ;
                  if (v456 >= v76) {
                    // pto: %155, %158, %157
                    ;
                    int64_t v457 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v456 * (uint64_t) v77) + (uint64_t) (v454 % v77));
                    // pto: %159
                    ;
                    Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v458;
                    // pto: %159
                    ;
                    uint64_t v459 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v451 * (uint64_t) v36) + (uint64_t) v39);
                    TASSIGN(v458, v459);
                    // pto: %160
                    ;
                    int64_t v460 = v457 < v76 ? v76 : v457;
                    // pto: %cmp_kv_flat_inline100__ssa_v0_pview
                    ;
                    __gm__ bfloat16_t* v461 = PTOAS__GLOBAL_TENSOR_DATA(v168);
                    // pto: %cmp_kv_flat_inline100__ssa_v0_pview
                    ;
                    const int64_t v462 = 0;
                    // pto: %cmp_kv_flat_inline100__ssa_v0_pview
                    ;
                    const int64_t v463 = 512;
                    // pto: %cmp_kv_flat_inline100__ssa_v0_pview
                    ;
                    pto::Shape<1, 1, 1, 1, 512> v464 = pto::Shape<1, 1, 1, 1, 512>();
                    // pto: %cmp_kv_flat_inline100__ssa_v0_pview
                    ;
                    pto::Stride<512, 512, 512, 512, 1> v465 = pto::Stride<512, 512, 512, 512, 1>();
                    // pto: %cmp_kv_flat_inline100__ssa_v0_pview
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v466 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v461 + (v462 + v460 * v463), v464, v465);
                    TLOAD(v458, v466);
                  };
                };
              };
            };
          };
          set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
          // pto: %1, %161
          ;
          int64_t v467 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v287 * (uint64_t) v69) + (uint64_t) v337);
          // pto: %162
          ;
          int64_t v468 = v467 < v76 ? v76 : v467;
          // pto: %kv_transfer_inline91__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v469 = PTOAS__GLOBAL_TENSOR_DATA(v102);
          // pto: %kv_transfer_inline91__ssa_v0_pview
          ;
          const int64_t v470 = 0;
          // pto: %kv_transfer_inline91__ssa_v0_pview
          ;
          const int64_t v471 = 512;
          // pto: %kv_transfer_inline91__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 64, 512> v472 = pto::Shape<1, 1, 1, 64, 512>();
          // pto: %kv_transfer_inline91__ssa_v0_pview
          ;
          pto::Stride<32768, 32768, 32768, 512, 1> v473 = pto::Stride<32768, 32768, 32768, 512, 1>();
          // pto: %kv_transfer_inline91__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v474 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v469 + (v470 + v468 * v471), v472, v473);
          wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
          TSTORE(v474, v229);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        };
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
        uint16_t v475 = getFFTSMsg(FFTS_MODE_VAL, v76);
        ffts_cross_core_sync(PIPE_MTE3, v475);
        int32_t v476 = (int32_t) v68;
        wait_flag_dev(v476);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
        for (int64_t v477 = v76; v477 < v83; v477 += v68) {
          // pto: %165, %163
          ;
          int64_t v478 = (int64_t) ((uint64_t) v322 + (uint64_t) ((int64_t) (uint64_t) v477 * (uint64_t) v78));
          // pto: %sm_scores_inline59__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v479 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v69);
          // pto: %sm_scores_inline59__ssa_v0
          ;
          uint64_t v480 = (uint64_t) v39;
          TASSIGN(v479, v480);
          // pto: %166
          ;
          int64_t v481 = v478 < v76 ? v76 : v478;
          // pto: %score_transfer_inline58__ssa_v0_pview
          ;
          __gm__ float* v482 = PTOAS__GLOBAL_TENSOR_DATA(v110);
          // pto: %score_transfer_inline58__ssa_v0_pview
          ;
          const int64_t v483 = 0;
          // pto: %score_transfer_inline58__ssa_v0_pview
          ;
          const int64_t v484 = 512;
          // pto: %score_transfer_inline58__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 8, 512> v485 = pto::Shape<1, 1, 1, 8, 512>();
          // pto: %score_transfer_inline58__ssa_v0_pview
          ;
          pto::Stride<4096, 4096, 4096, 512, 1> v486 = pto::Stride<4096, 4096, 4096, 512, 1>();
          // pto: %score_transfer_inline58__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND> v487 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND>(v482 + (v483 + v481 * v484), v485, v486);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          TLOAD(v479, v487);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          // pto: %sm_bias_inline160__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v488 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v69);
          // pto: %sm_bias_inline160__ssa_v0
          ;
          uint64_t v489 = (uint64_t) v43;
          TASSIGN(v488, v489);
          // pto: %167
          ;
          int64_t v490 = v289 < v76 ? v76 : v289;
          // pto: %168
          ;
          int64_t v491 = (int64_t) ((uint64_t) v334 * (uint64_t) v69);
          // pto: %169
          ;
          int64_t v492 = v491 < v76 ? v76 : v491;
          // pto: %sparse_bias_inline110__rv_v2_pview
          ;
          __gm__ float* v493 = PTOAS__GLOBAL_TENSOR_DATA(v177);
          // pto: %sparse_bias_inline110__rv_v2_pview
          ;
          const int64_t v494 = 0;
          // pto: %sparse_bias_inline110__rv_v2_pview
          ;
          const int64_t v495 = 1024;
          // pto: %sparse_bias_inline110__rv_v2_pview
          ;
          pto::Shape<1, 1, 1, 1, 512> v496 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %sparse_bias_inline110__rv_v2_pview
          ;
          pto::Stride<1024, 1024, 1024, 1024, 1> v497 = pto::Stride<1024, 1024, 1024, 1024, 1>();
          // pto: %sparse_bias_inline110__rv_v2_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v498 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v493 + (v494 + v490 * v495 + v492), v496, v497);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
          TLOAD(v488, v498);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          // pto: %t__tmp_v47
          ;
          Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v499 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v69);
          // pto: %t__tmp_v47
          ;
          uint64_t v500 = (uint64_t) v39;
          TASSIGN(v499, v500);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          TMULS(v499, v479, v88);
          // pto: %sm_masked_inline38__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v501 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v69);
          // pto: %sm_masked_inline38__ssa_v0
          ;
          uint64_t v502 = (uint64_t) v39;
          TASSIGN(v501, v502);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          TCOLEXPANDADD(v501, v499, v488);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
          // pto: %sm_block_max_inline36__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v503 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v68);
          // pto: %sm_block_max_inline36__ssa_v0
          ;
          uint64_t v504 = (uint64_t) v43;
          TASSIGN(v503, v504);
          pipe_barrier(PIPE_V);
          TROWMAX(v503, v501, v296);
          // pto: %sm_old_m_inline162__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v505 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v68);
          // pto: %sm_old_m_inline162__ssa_v0
          ;
          uint64_t v506 = (uint64_t) v44;
          TASSIGN(v505, v506);
          // pto: %171
          ;
          __gm__ float* v507 = PTOAS__GLOBAL_TENSOR_DATA(v142);
          // pto: %171
          ;
          const int64_t v508 = 0;
          // pto: %171
          ;
          pto::Shape<1, 1, 1, 8, 1> v509 = pto::Shape<1, 1, 1, 8, 1>();
          // pto: %171
          ;
          pto::Stride<8, 8, 8, 1, 1536> v510 = pto::Stride<8, 8, 8, 1, 1536>();
          // pto: %171
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN> v511 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN>(v507 + (v508 + v481), v509, v510);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
          TLOAD(v505, v511);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          // pto: %sm_old_l_inline35__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v512 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v68);
          // pto: %sm_old_l_inline35__ssa_v0
          ;
          uint64_t v513 = (uint64_t) v45;
          TASSIGN(v512, v513);
          // pto: %173
          ;
          __gm__ float* v514 = PTOAS__GLOBAL_TENSOR_DATA(v150);
          // pto: %173
          ;
          const int64_t v515 = 0;
          // pto: %173
          ;
          pto::Shape<1, 1, 1, 8, 1> v516 = pto::Shape<1, 1, 1, 8, 1>();
          // pto: %173
          ;
          pto::Stride<8, 8, 8, 1, 1536> v517 = pto::Stride<8, 8, 8, 1, 1536>();
          // pto: %173
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN> v518 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN>(v514 + (v515 + v481), v516, v517);
          TLOAD(v512, v518);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
          // pto: %sm_max_inline34__rm_a0_tmp_v4
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v519 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v78);
          // pto: %sm_max_inline34__rm_a0_tmp_v4
          ;
          uint64_t v520 = (uint64_t) v44;
          TASSIGN(v519, v520);
          // pto: %sm_max_inline34__rm_a1_tmp_v5
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v521 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v78);
          // pto: %sm_max_inline34__rm_a1_tmp_v5
          ;
          uint64_t v522 = (uint64_t) v43;
          TASSIGN(v521, v522);
          // pto: %sm_max_inline34__row_major_tmp_v6
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v523 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v78);
          // pto: %sm_max_inline34__row_major_tmp_v6
          ;
          uint64_t v524 = (uint64_t) v46;
          TASSIGN(v523, v524);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          pipe_barrier(PIPE_V);
          TMAX(v523, v519, v521);
          // pto: %sm_max_inline34__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v525 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v68);
          // pto: %sm_max_inline34__ssa_v0
          ;
          uint64_t v526 = (uint64_t) v46;
          TASSIGN(v525, v526);
          // pto: %t__rm_a0_tmp_v7
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v527 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v78);
          // pto: %t__rm_a0_tmp_v7
          ;
          uint64_t v528 = (uint64_t) v44;
          TASSIGN(v527, v528);
          // pto: %t__rm_a1_tmp_v8
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v529 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v78);
          // pto: %t__rm_a1_tmp_v8
          ;
          uint64_t v530 = (uint64_t) v46;
          TASSIGN(v529, v530);
          // pto: %t__row_major_tmp_v9
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v531 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v78);
          // pto: %t__row_major_tmp_v9
          ;
          uint64_t v532 = (uint64_t) v43;
          TASSIGN(v531, v532);
          pipe_barrier(PIPE_V);
          TSUB(v531, v527, v529);
          // pto: %t__tmp_v48
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v533 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v68);
          // pto: %t__tmp_v48
          ;
          uint64_t v534 = (uint64_t) v43;
          TASSIGN(v533, v534);
          // pto: %sm_alpha_inline33__rm_a0_tmp_v10
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v535 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v78);
          // pto: %sm_alpha_inline33__rm_a0_tmp_v10
          ;
          uint64_t v536 = (uint64_t) v43;
          TASSIGN(v535, v536);
          // pto: %sm_alpha_inline33__row_major_tmp_v11
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v537 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v78);
          // pto: %sm_alpha_inline33__row_major_tmp_v11
          ;
          uint64_t v538 = (uint64_t) v47;
          TASSIGN(v537, v538);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
          TEXP(v537, v535);
          // pto: %sm_alpha_inline33__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v539 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v68);
          // pto: %sm_alpha_inline33__ssa_v0
          ;
          uint64_t v540 = (uint64_t) v47;
          TASSIGN(v539, v540);
          // pto: %t__tmp_v49
          ;
          Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v541 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v69);
          // pto: %t__tmp_v49
          ;
          uint64_t v542 = (uint64_t) v39;
          TASSIGN(v541, v542);
          TROWEXPANDSUB(v541, v501, v525);
          // pto: %sm_exp_inline32__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v543 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v69);
          // pto: %sm_exp_inline32__ssa_v0
          ;
          uint64_t v544 = (uint64_t) v39;
          TASSIGN(v543, v544);
          pipe_barrier(PIPE_V);
          TEXP(v543, v541);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          // pto: %174
          ;
          int64_t v545 = (v12)[v289];
          // pto: %178
          ;
          // pto: %sm_key_count_inline97__phi_v2
          ;
          int64_t v546;
          if (v334 == v76) {
            // pto: %179
            ;
            int64_t v547 = (int64_t) ((uint64_t) v545 + (uint64_t) v68);
            // pto: %180
            ;
            v546 = v547 < v84 ? v547 : v84;
          } else {
            // pto: %181, %182
            ;
            int64_t v548 = (int64_t) ((uint64_t) v545 + (uint64_t) v68) / v83;
            // pto: %183
            ;
            v546 = v548 < v69 ? v548 : v69;
          };
          // pto: %184
          ;
          bool v549 = v546 < v73;
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          if (v549) {
            // pto: %sm_short_inline29__ssa_v0
            ;
            Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v550 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v546);
            // pto: %sm_short_inline29__ssa_v0
            ;
            uint64_t v551 = (uint64_t) v39;
            TASSIGN(v550, v551);
            // pto: %slice_view
            ;
            Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v552 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v546);
            // pto: %slice_view
            ;
            uint64_t v553 = (uint64_t) v39;
            TASSIGN(v552, v553);
            // pto: %t__tmp_v51
            ;
            Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v554 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
            // pto: %t__tmp_v51
            ;
            uint64_t v555 = (uint64_t) v43;
            TASSIGN(v554, v555);
            // pto: %sm_block_sum_inline28__ssa_v0
            ;
            Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v556 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v68);
            // pto: %sm_block_sum_inline28__ssa_v0
            ;
            uint64_t v557 = (uint64_t) v48;
            TASSIGN(v556, v557);
            pipe_barrier(PIPE_V);
            TROWSUM(v556, v552, v554);
          } else {
            // pto: %185
            ;
            bool v558 = v546 < v69;
            if (v558) {
              // pto: %t__tmp_v52
              ;
              Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v559 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
              // pto: %t__tmp_v52
              ;
              uint64_t v560 = (uint64_t) v43;
              TASSIGN(v559, v560);
              TEXPANDS(v559, v79);
              // pto: %t__ci_tmp_v0
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v561 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v89);
              // pto: %t__ci_tmp_v0
              ;
              uint64_t v562 = (uint64_t) v49;
              TASSIGN(v561, v562);
              // pto: %t__tmp_v53
              ;
              Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v563 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v73);
              // pto: %t__tmp_v53
              ;
              uint64_t v564 = (uint64_t) v50;
              TASSIGN(v563, v564);
              // pto: %ci_tmp_view
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v565;
              TRESHAPE(v565, v561);
              // pto: %ci_dst_view
              ;
              Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v566;
              TRESHAPE(v566, v563);
              TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v566, v90, v565);
              // pto: %t__tmp_v54
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v567 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v73);
              // pto: %t__tmp_v54
              ;
              uint64_t v568 = (uint64_t) v49;
              TASSIGN(v567, v568);
              pipe_barrier(PIPE_V);
              RoundMode v569 = RoundMode::CAST_ROUND;
              SaturationMode v570 = SaturationMode::ON;
              TCVT(v567, v563, v569, v570);
              // pto: %sm_columns_inline27__ssa_v0
              ;
              Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v571 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
              // pto: %sm_columns_inline27__ssa_v0
              ;
              uint64_t v572 = (uint64_t) v43;
              TASSIGN(v571, v572);
              pipe_barrier(PIPE_V);
              TCOLEXPANDADD(v571, v559, v567);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
              // pto: %t__tmp_v55
              ;
              Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v573 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
              // pto: %t__tmp_v55
              ;
              uint64_t v574 = (uint64_t) v39;
              TASSIGN(v573, v574);
              // pto: %186
              ;
              Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v575;
              // pto: %186
              ;
              uint64_t v576 = (uint64_t) v39;
              TASSIGN(v575, v576);
              // pto: %softmax_copy64_inline94__ssa_v0_pview
              ;
              __gm__ float* v577 = PTOAS__GLOBAL_TENSOR_DATA(v185);
              // pto: %softmax_copy64_inline94__ssa_v0_pview
              ;
              const int64_t v578 = 0;
              // pto: %softmax_copy64_inline94__ssa_v0_pview
              ;
              const int64_t v579 = 64;
              // pto: %softmax_copy64_inline94__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 8, 64> v580 = pto::Shape<1, 1, 1, 8, 64>();
              // pto: %softmax_copy64_inline94__ssa_v0_pview
              ;
              pto::Stride<512, 512, 512, 64, 1> v581 = pto::Stride<512, 512, 512, 64, 1>();
              // pto: %softmax_copy64_inline94__ssa_v0_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v582 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v577 + (v578 + v481 * v579), v580, v581);
              TSTORE(v582, v575);
              set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
              // pto: %sm_fold64_inline57__ssa_v0
              ;
              Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v583 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
              // pto: %sm_fold64_inline57__ssa_v0
              ;
              uint64_t v584 = (uint64_t) v49;
              TASSIGN(v583, v584);
              wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
              TLOAD(v583, v582);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
              // pto: %190
              ;
              bool v585 = v546 > v73;
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
              if (v585) {
                // pto: %t__tmp_v56
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v586 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %t__tmp_v56
                ;
                uint64_t v587 = (uint64_t) v51;
                TASSIGN(v586, v587);
                // pto: %191
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v588;
                // pto: %191
                ;
                uint64_t v589 = (uint64_t) v51;
                TASSIGN(v588, v589);
                // pto: %sm_added_inline25__ssa_v0
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v590 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %sm_added_inline25__ssa_v0
                ;
                uint64_t v591 = (uint64_t) v52;
                TASSIGN(v590, v591);
                TADD(v590, v583, v588);
                // pto: %192
                ;
                bool v592 = v546 < v84;
                if (v592) {
                  // pto: %193
                  ;
                  uint64_t v593 = (uint64_t) v546;
                  // pto: %193, %194, %195
                  ;
                  float v594 = (float) ((int32_t) (int64_t) (v593 - (uint64_t) v73));
                  // pto: %sm_tail_mask_inline24__ssa_v0
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v595 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v78);
                  // pto: %sm_tail_mask_inline24__ssa_v0
                  ;
                  uint64_t v596 = (uint64_t) v53;
                  TASSIGN(v595, v596);
                  CmpMode v597 = CmpMode::LT;
                  TCMPS(v595, v571, v594, v597);
                  // pto: %t__tmp_v57
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v598 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v70);
                  // pto: %t__tmp_v57
                  ;
                  uint64_t v599 = (uint64_t) v54;
                  TASSIGN(v598, v599);
                  // pto: %sm_fold64_inline57__ssa_v1
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v600 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %sm_fold64_inline57__ssa_v1
                  ;
                  uint64_t v601 = (uint64_t) v55;
                  TASSIGN(v600, v601);
                  pipe_barrier(PIPE_V);
                  TSEL(v600, v595, v590, v583, v598);
                } else {
                  // pto: %sm_fold64_inline57__ssa_v2
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v602 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %sm_fold64_inline57__ssa_v2
                  ;
                  uint64_t v603 = (uint64_t) v52;
                  TASSIGN(v602, v603);
                  // pto: %sm_fold64_inline57__ssa_v2_mv
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v604 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %sm_fold64_inline57__ssa_v2_mv
                  ;
                  uint64_t v605 = (uint64_t) v55;
                  TASSIGN(v604, v605);
                  pipe_barrier(PIPE_V);
                  TMOV(v604, v602);
                };
              } else {
                // pto: %sm_fold64_inline57__ssa_v0_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v606 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %sm_fold64_inline57__ssa_v0_mv
                ;
                uint64_t v607 = (uint64_t) v55;
                TASSIGN(v606, v607);
                TMOV(v606, v583);
              };
              // pto: %196
              ;
              bool v608 = v546 > v84;
              if (v608) {
                // pto: %t__tmp_v58
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v609 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %t__tmp_v58
                ;
                uint64_t v610 = (uint64_t) v56;
                TASSIGN(v609, v610);
                // pto: %197
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v611;
                // pto: %197
                ;
                uint64_t v612 = (uint64_t) v56;
                TASSIGN(v611, v612);
                // pto: %sm_added_inline25__ssa_v1
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v613 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %sm_added_inline25__ssa_v1
                ;
                uint64_t v614 = (uint64_t) v49;
                TASSIGN(v613, v614);
                pipe_barrier(PIPE_V);
                TADD(v613, v261, v611);
                // pto: %198
                ;
                bool v615 = v546 < v89;
                if (v615) {
                  // pto: %199
                  ;
                  uint64_t v616 = (uint64_t) v546;
                  // pto: %199, %200, %201
                  ;
                  float v617 = (float) ((int32_t) (int64_t) (v616 - (uint64_t) v84));
                  // pto: %sm_tail_mask_inline24__ssa_v1
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v618 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v78);
                  // pto: %sm_tail_mask_inline24__ssa_v1
                  ;
                  uint64_t v619 = (uint64_t) v57;
                  TASSIGN(v618, v619);
                  CmpMode v620 = CmpMode::LT;
                  TCMPS(v618, v571, v617, v620);
                  // pto: %t__tmp_v59
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v621 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v70);
                  // pto: %t__tmp_v59
                  ;
                  uint64_t v622 = (uint64_t) v58;
                  TASSIGN(v621, v622);
                  // pto: %sm_fold64_inline57__ssa_v5
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v623 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %sm_fold64_inline57__ssa_v5
                  ;
                  uint64_t v624 = (uint64_t) v53;
                  TASSIGN(v623, v624);
                  pipe_barrier(PIPE_V);
                  TSEL(v623, v618, v613, v261, v621);
                } else {
                  // pto: %sm_fold64_inline57__ssa_v6
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v625 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %sm_fold64_inline57__ssa_v6
                  ;
                  uint64_t v626 = (uint64_t) v49;
                  TASSIGN(v625, v626);
                  // pto: %sm_fold64_inline57__ssa_v6_mv
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v627 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %sm_fold64_inline57__ssa_v6_mv
                  ;
                  uint64_t v628 = (uint64_t) v53;
                  TASSIGN(v627, v628);
                  pipe_barrier(PIPE_V);
                  TMOV(v627, v625);
                };
              } else {
                // pto: %sm_fold64_inline57__phi_v4_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v629 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %sm_fold64_inline57__phi_v4_mv
                ;
                uint64_t v630 = (uint64_t) v53;
                TASSIGN(v629, v630);
                pipe_barrier(PIPE_V);
                TMOV(v629, v261);
              };
              // pto: %202
              ;
              bool v631 = v546 > v89;
              if (v631) {
                // pto: %t__tmp_v60
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v632 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %t__tmp_v60
                ;
                uint64_t v633 = (uint64_t) v59;
                TASSIGN(v632, v633);
                // pto: %203
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v634;
                // pto: %203
                ;
                uint64_t v635 = (uint64_t) v59;
                TASSIGN(v634, v635);
                // pto: %sm_added_inline25__ssa_v2
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v636 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %sm_added_inline25__ssa_v2
                ;
                uint64_t v637 = (uint64_t) v52;
                TASSIGN(v636, v637);
                pipe_barrier(PIPE_V);
                TADD(v636, v265, v634);
                // pto: %204
                ;
                bool v638 = v546 < v81;
                if (v638) {
                  // pto: %205
                  ;
                  uint64_t v639 = (uint64_t) v546;
                  // pto: %205, %206, %207
                  ;
                  float v640 = (float) ((int32_t) (int64_t) (v639 - (uint64_t) v89));
                  // pto: %sm_tail_mask_inline24__ssa_v2
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v641 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v78);
                  // pto: %sm_tail_mask_inline24__ssa_v2
                  ;
                  uint64_t v642 = (uint64_t) v57;
                  TASSIGN(v641, v642);
                  CmpMode v643 = CmpMode::LT;
                  TCMPS(v641, v571, v640, v643);
                  // pto: %t__tmp_v61
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v644 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v70);
                  // pto: %t__tmp_v61
                  ;
                  uint64_t v645 = (uint64_t) v58;
                  TASSIGN(v644, v645);
                  // pto: %sm_fold64_inline57__ssa_v9
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v646 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %sm_fold64_inline57__ssa_v9
                  ;
                  uint64_t v647 = (uint64_t) v55;
                  TASSIGN(v646, v647);
                  pipe_barrier(PIPE_V);
                  TSEL(v646, v641, v636, v265, v644);
                } else {
                  // pto: %sm_fold64_inline57__ssa_v10
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v648 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %sm_fold64_inline57__ssa_v10
                  ;
                  uint64_t v649 = (uint64_t) v52;
                  TASSIGN(v648, v649);
                  // pto: %sm_fold64_inline57__ssa_v10_mv
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v650 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %sm_fold64_inline57__ssa_v10_mv
                  ;
                  uint64_t v651 = (uint64_t) v55;
                  TASSIGN(v650, v651);
                  pipe_barrier(PIPE_V);
                  TMOV(v650, v648);
                };
              } else {
                // pto: %sm_fold64_inline57__phi_v8_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v652 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %sm_fold64_inline57__phi_v8_mv
                ;
                uint64_t v653 = (uint64_t) v55;
                TASSIGN(v652, v653);
                pipe_barrier(PIPE_V);
                TMOV(v652, v265);
              };
              // pto: %208
              ;
              bool v654 = v546 > v81;
              if (v654) {
                // pto: %t__tmp_v62
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v655 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %t__tmp_v62
                ;
                uint64_t v656 = (uint64_t) v60;
                TASSIGN(v655, v656);
                // pto: %209
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v657;
                // pto: %209
                ;
                uint64_t v658 = (uint64_t) v60;
                TASSIGN(v657, v658);
                // pto: %sm_added_inline25__ssa_v3
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v659 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %sm_added_inline25__ssa_v3
                ;
                uint64_t v660 = (uint64_t) v49;
                TASSIGN(v659, v660);
                pipe_barrier(PIPE_V);
                TADD(v659, v269, v657);
                // pto: %210
                ;
                bool v661 = v546 < v91;
                if (v661) {
                  // pto: %211
                  ;
                  uint64_t v662 = (uint64_t) v546;
                  // pto: %211, %212, %213
                  ;
                  float v663 = (float) ((int32_t) (int64_t) (v662 - (uint64_t) v81));
                  // pto: %sm_tail_mask_inline24__ssa_v3
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v664 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v78);
                  // pto: %sm_tail_mask_inline24__ssa_v3
                  ;
                  uint64_t v665 = (uint64_t) v57;
                  TASSIGN(v664, v665);
                  CmpMode v666 = CmpMode::LT;
                  TCMPS(v664, v571, v663, v666);
                  // pto: %t__tmp_v63
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v667 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v70);
                  // pto: %t__tmp_v63
                  ;
                  uint64_t v668 = (uint64_t) v58;
                  TASSIGN(v667, v668);
                  // pto: %sm_fold64_inline57__ssa_v13
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v669 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %sm_fold64_inline57__ssa_v13
                  ;
                  uint64_t v670 = (uint64_t) v53;
                  TASSIGN(v669, v670);
                  pipe_barrier(PIPE_V);
                  TSEL(v669, v664, v659, v269, v667);
                } else {
                  // pto: %sm_fold64_inline57__ssa_v14
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v671 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %sm_fold64_inline57__ssa_v14
                  ;
                  uint64_t v672 = (uint64_t) v49;
                  TASSIGN(v671, v672);
                  // pto: %sm_fold64_inline57__ssa_v14_mv
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v673 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %sm_fold64_inline57__ssa_v14_mv
                  ;
                  uint64_t v674 = (uint64_t) v53;
                  TASSIGN(v673, v674);
                  pipe_barrier(PIPE_V);
                  TMOV(v673, v671);
                };
              } else {
                // pto: %sm_fold64_inline57__phi_v12_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v675 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %sm_fold64_inline57__phi_v12_mv
                ;
                uint64_t v676 = (uint64_t) v53;
                TASSIGN(v675, v676);
                pipe_barrier(PIPE_V);
                TMOV(v675, v269);
              };
              // pto: %214
              ;
              bool v677 = v546 > v91;
              if (v677) {
                // pto: %t__tmp_v64
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v678 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %t__tmp_v64
                ;
                uint64_t v679 = (uint64_t) v61;
                TASSIGN(v678, v679);
                // pto: %215
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v680;
                // pto: %215
                ;
                uint64_t v681 = (uint64_t) v61;
                TASSIGN(v680, v681);
                // pto: %sm_added_inline25__ssa_v4
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v682 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %sm_added_inline25__ssa_v4
                ;
                uint64_t v683 = (uint64_t) v52;
                TASSIGN(v682, v683);
                pipe_barrier(PIPE_V);
                TADD(v682, v273, v680);
                // pto: %216
                ;
                bool v684 = v546 < v92;
                if (v684) {
                  // pto: %217
                  ;
                  uint64_t v685 = (uint64_t) v546;
                  // pto: %217, %218, %219
                  ;
                  float v686 = (float) ((int32_t) (int64_t) (v685 - (uint64_t) v91));
                  // pto: %sm_tail_mask_inline24__ssa_v4
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v687 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v78);
                  // pto: %sm_tail_mask_inline24__ssa_v4
                  ;
                  uint64_t v688 = (uint64_t) v57;
                  TASSIGN(v687, v688);
                  CmpMode v689 = CmpMode::LT;
                  TCMPS(v687, v571, v686, v689);
                  // pto: %t__tmp_v65
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v690 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v70);
                  // pto: %t__tmp_v65
                  ;
                  uint64_t v691 = (uint64_t) v58;
                  TASSIGN(v690, v691);
                  // pto: %sm_fold64_inline57__ssa_v17
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v692 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %sm_fold64_inline57__ssa_v17
                  ;
                  uint64_t v693 = (uint64_t) v55;
                  TASSIGN(v692, v693);
                  pipe_barrier(PIPE_V);
                  TSEL(v692, v687, v682, v273, v690);
                } else {
                  // pto: %sm_fold64_inline57__ssa_v18
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v694 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %sm_fold64_inline57__ssa_v18
                  ;
                  uint64_t v695 = (uint64_t) v52;
                  TASSIGN(v694, v695);
                  // pto: %sm_fold64_inline57__ssa_v18_mv
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v696 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %sm_fold64_inline57__ssa_v18_mv
                  ;
                  uint64_t v697 = (uint64_t) v55;
                  TASSIGN(v696, v697);
                  pipe_barrier(PIPE_V);
                  TMOV(v696, v694);
                };
              } else {
                // pto: %sm_fold64_inline57__phi_v16_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v698 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %sm_fold64_inline57__phi_v16_mv
                ;
                uint64_t v699 = (uint64_t) v55;
                TASSIGN(v698, v699);
                pipe_barrier(PIPE_V);
                TMOV(v698, v273);
              };
              // pto: %220
              ;
              bool v700 = v546 > v92;
              if (v700) {
                // pto: %t__tmp_v66
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v701 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %t__tmp_v66
                ;
                uint64_t v702 = (uint64_t) v62;
                TASSIGN(v701, v702);
                // pto: %221
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v703;
                // pto: %221
                ;
                uint64_t v704 = (uint64_t) v62;
                TASSIGN(v703, v704);
                // pto: %sm_added_inline25__ssa_v5
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v705 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %sm_added_inline25__ssa_v5
                ;
                uint64_t v706 = (uint64_t) v49;
                TASSIGN(v705, v706);
                pipe_barrier(PIPE_V);
                TADD(v705, v277, v703);
                // pto: %222
                ;
                bool v707 = v546 < v93;
                if (v707) {
                  // pto: %223
                  ;
                  uint64_t v708 = (uint64_t) v546;
                  // pto: %223, %224, %225
                  ;
                  float v709 = (float) ((int32_t) (int64_t) (v708 - (uint64_t) v92));
                  // pto: %sm_tail_mask_inline24__ssa_v5
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v710 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v78);
                  // pto: %sm_tail_mask_inline24__ssa_v5
                  ;
                  uint64_t v711 = (uint64_t) v57;
                  TASSIGN(v710, v711);
                  CmpMode v712 = CmpMode::LT;
                  TCMPS(v710, v571, v709, v712);
                  // pto: %t__tmp_v67
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v713 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v70);
                  // pto: %t__tmp_v67
                  ;
                  uint64_t v714 = (uint64_t) v58;
                  TASSIGN(v713, v714);
                  // pto: %sm_fold64_inline57__ssa_v21
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v715 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %sm_fold64_inline57__ssa_v21
                  ;
                  uint64_t v716 = (uint64_t) v53;
                  TASSIGN(v715, v716);
                  pipe_barrier(PIPE_V);
                  TSEL(v715, v710, v705, v277, v713);
                } else {
                  // pto: %sm_fold64_inline57__ssa_v22
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v717 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %sm_fold64_inline57__ssa_v22
                  ;
                  uint64_t v718 = (uint64_t) v49;
                  TASSIGN(v717, v718);
                  // pto: %sm_fold64_inline57__ssa_v22_mv
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v719 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %sm_fold64_inline57__ssa_v22_mv
                  ;
                  uint64_t v720 = (uint64_t) v53;
                  TASSIGN(v719, v720);
                  pipe_barrier(PIPE_V);
                  TMOV(v719, v717);
                };
              } else {
                // pto: %sm_fold64_inline57__phi_v20_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v721 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %sm_fold64_inline57__phi_v20_mv
                ;
                uint64_t v722 = (uint64_t) v53;
                TASSIGN(v721, v722);
                pipe_barrier(PIPE_V);
                TMOV(v721, v277);
              };
              // pto: %226
              ;
              bool v723 = v546 > v93;
              if (v723) {
                // pto: %t__tmp_v68
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v724 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %t__tmp_v68
                ;
                uint64_t v725 = (uint64_t) v63;
                TASSIGN(v724, v725);
                // pto: %227
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v726;
                // pto: %227
                ;
                uint64_t v727 = (uint64_t) v63;
                TASSIGN(v726, v727);
                // pto: %sm_added_inline25__ssa_v6
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v728 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %sm_added_inline25__ssa_v6
                ;
                uint64_t v729 = (uint64_t) v52;
                TASSIGN(v728, v729);
                pipe_barrier(PIPE_V);
                TADD(v728, v281, v726);
                // pto: %228
                ;
                uint64_t v730 = (uint64_t) v546;
                // pto: %228, %229, %230
                ;
                float v731 = (float) ((int32_t) (int64_t) (v730 - (uint64_t) v93));
                // pto: %sm_tail_mask_inline24__ssa_v6
                ;
                Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v732 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v78);
                // pto: %sm_tail_mask_inline24__ssa_v6
                ;
                uint64_t v733 = (uint64_t) v55;
                TASSIGN(v732, v733);
                CmpMode v734 = CmpMode::LT;
                TCMPS(v732, v571, v731, v734);
                // pto: %t__tmp_v69
                ;
                Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v735 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v70);
                // pto: %t__tmp_v69
                ;
                uint64_t v736 = (uint64_t) v64;
                TASSIGN(v735, v736);
                // pto: %sm_fold64_inline57__ssa_v25
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v737 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %sm_fold64_inline57__ssa_v25
                ;
                uint64_t v738 = (uint64_t) v43;
                TASSIGN(v737, v738);
                pipe_barrier(PIPE_V);
                TSEL(v737, v732, v728, v281, v735);
              } else {
                // pto: %sm_fold64_inline57__phi_v24_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v739 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                // pto: %sm_fold64_inline57__phi_v24_mv
                ;
                uint64_t v740 = (uint64_t) v43;
                TASSIGN(v739, v740);
                pipe_barrier(PIPE_V);
                TMOV(v739, v281);
              };
              // pto: %sm_groups64_inline37__ssa_v0
              ;
              Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v741 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v78);
              // pto: %sm_groups64_inline37__ssa_v0
              ;
              uint64_t v742 = (uint64_t) v43;
              TASSIGN(v741, v742);
              // pto: %t__tmp_v70
              ;
              Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v743 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v78);
              // pto: %t__tmp_v70
              ;
              uint64_t v744 = (uint64_t) v49;
              TASSIGN(v743, v744);
              // pto: %sm_sum8_inline23__ssa_v0
              ;
              Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v745 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v68);
              // pto: %sm_sum8_inline23__ssa_v0
              ;
              uint64_t v746 = (uint64_t) v52;
              TASSIGN(v745, v746);
              pipe_barrier(PIPE_V);
              TROWSUM(v745, v741, v743);
              // pto: %sm_final8_inline69__ssa_v0
              ;
              Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v747 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v78);
              // pto: %sm_final8_inline69__ssa_v0
              ;
              uint64_t v748 = (uint64_t) v52;
              TASSIGN(v747, v748);
              // pto: %t__tmp_v71
              ;
              Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v749 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v78);
              // pto: %t__tmp_v71
              ;
              uint64_t v750 = (uint64_t) v43;
              TASSIGN(v749, v750);
              // pto: %sm_block_sum_inline28__ssa_v1
              ;
              Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v751 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v68);
              // pto: %sm_block_sum_inline28__ssa_v1
              ;
              uint64_t v752 = (uint64_t) v48;
              TASSIGN(v751, v752);
              pipe_barrier(PIPE_V);
              TROWSUM(v751, v747, v749);
            } else {
              // pto: %sm_groups8_inline144__ssa_v0
              ;
              Tile<TileType::Vec, float, 512, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v753 = Tile<TileType::Vec, float, 512, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v78);
              // pto: %sm_groups8_inline144__ssa_v0
              ;
              uint64_t v754 = (uint64_t) v39;
              TASSIGN(v753, v754);
              // pto: %t__tmp_v72
              ;
              Tile<TileType::Vec, float, 512, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v755 = Tile<TileType::Vec, float, 512, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v78);
              // pto: %t__tmp_v72
              ;
              uint64_t v756 = (uint64_t) v43;
              TASSIGN(v755, v756);
              // pto: %sm_sum64_inline141__ssa_v0
              ;
              Tile<TileType::Vec, float, 512, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v757 = Tile<TileType::Vec, float, 512, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v68);
              // pto: %sm_sum64_inline141__ssa_v0
              ;
              uint64_t v758 = (uint64_t) v65;
              TASSIGN(v757, v758);
              pipe_barrier(PIPE_V);
              TROWSUM(v757, v753, v755);
              // pto: %sm_groups64_inline37__ssa_v1
              ;
              Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v759 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v78);
              // pto: %sm_groups64_inline37__ssa_v1
              ;
              uint64_t v760 = (uint64_t) v65;
              TASSIGN(v759, v760);
              // pto: %t__tmp_v73
              ;
              Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v761 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v78);
              // pto: %t__tmp_v73
              ;
              uint64_t v762 = (uint64_t) v43;
              TASSIGN(v761, v762);
              // pto: %sm_sum8_inline23__ssa_v1
              ;
              Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v763 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v68);
              // pto: %sm_sum8_inline23__ssa_v1
              ;
              uint64_t v764 = (uint64_t) v49;
              TASSIGN(v763, v764);
              pipe_barrier(PIPE_V);
              TROWSUM(v763, v759, v761);
              // pto: %sm_final8_inline69__ssa_v1
              ;
              Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v765 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v78);
              // pto: %sm_final8_inline69__ssa_v1
              ;
              uint64_t v766 = (uint64_t) v49;
              TASSIGN(v765, v766);
              // pto: %t__tmp_v74
              ;
              Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v767 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v78);
              // pto: %t__tmp_v74
              ;
              uint64_t v768 = (uint64_t) v43;
              TASSIGN(v767, v768);
              // pto: %sm_block_sum_inline28__ssa_v2
              ;
              Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v769 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v68);
              // pto: %sm_block_sum_inline28__ssa_v2
              ;
              uint64_t v770 = (uint64_t) v66;
              TASSIGN(v769, v770);
              pipe_barrier(PIPE_V);
              TROWSUM(v769, v765, v767);
              // pto: %sm_block_sum_inline28__ssa_v2_mv
              ;
              Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v771 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v68);
              // pto: %sm_block_sum_inline28__ssa_v2_mv
              ;
              uint64_t v772 = (uint64_t) v48;
              TASSIGN(v771, v772);
              pipe_barrier(PIPE_V);
              TMOV(v771, v769);
            };
          };
          // pto: %t__rm_a0_tmp_v12
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v773 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v78);
          // pto: %t__rm_a0_tmp_v12
          ;
          uint64_t v774 = (uint64_t) v45;
          TASSIGN(v773, v774);
          // pto: %t__rm_a1_tmp_v13
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v775 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v78);
          // pto: %t__rm_a1_tmp_v13
          ;
          uint64_t v776 = (uint64_t) v47;
          TASSIGN(v775, v776);
          // pto: %t__row_major_tmp_v14
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v777 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v78);
          // pto: %t__row_major_tmp_v14
          ;
          uint64_t v778 = (uint64_t) v43;
          TASSIGN(v777, v778);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
          TMUL(v777, v773, v775);
          // pto: %t__tmp_v75
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v779 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v68);
          // pto: %t__tmp_v75
          ;
          uint64_t v780 = (uint64_t) v43;
          TASSIGN(v779, v780);
          // pto: %sm_sum_inline22__rm_a0_tmp_v15
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v781 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v78);
          // pto: %sm_sum_inline22__rm_a0_tmp_v15
          ;
          uint64_t v782 = (uint64_t) v43;
          TASSIGN(v781, v782);
          // pto: %sm_sum_inline22__rm_a1_tmp_v16
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v783 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v78);
          // pto: %sm_sum_inline22__rm_a1_tmp_v16
          ;
          uint64_t v784 = (uint64_t) v48;
          TASSIGN(v783, v784);
          // pto: %sm_sum_inline22__row_major_tmp_v17
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v785 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v68, v78);
          // pto: %sm_sum_inline22__row_major_tmp_v17
          ;
          uint64_t v786 = (uint64_t) v43;
          TASSIGN(v785, v786);
          pipe_barrier(PIPE_V);
          TADD(v785, v781, v783);
          // pto: %sm_sum_inline22__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v787 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v68);
          // pto: %sm_sum_inline22__ssa_v0
          ;
          uint64_t v788 = (uint64_t) v43;
          TASSIGN(v787, v788);
          // pto: %sm_probability_inline137__ssa_v0
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v789 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v69);
          // pto: %sm_probability_inline137__ssa_v0
          ;
          uint64_t v790 = (uint64_t) v39;
          TASSIGN(v789, v790);
          RoundMode v791 = RoundMode::CAST_ROUND;
          SaturationMode v792 = SaturationMode::ON;
          TCVT(v789, v543, v791, v792);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
          // pto: %probability_transfer_inline129__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v793 = PTOAS__GLOBAL_TENSOR_DATA(v118);
          // pto: %probability_transfer_inline129__ssa_v0_pview
          ;
          const int64_t v794 = 0;
          // pto: %probability_transfer_inline129__ssa_v0_pview
          ;
          const int64_t v795 = 512;
          // pto: %probability_transfer_inline129__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 8, 512> v796 = pto::Shape<1, 1, 1, 8, 512>();
          // pto: %probability_transfer_inline129__ssa_v0_pview
          ;
          pto::Stride<4096, 4096, 4096, 512, 1> v797 = pto::Stride<4096, 4096, 4096, 512, 1>();
          // pto: %probability_transfer_inline129__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND> v798 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND>(v793 + (v794 + v481 * v795), v796, v797);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
          TSTORE(v798, v789);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          TSTORE(v511, v525);
          TSTORE(v518, v787);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
          // pto: %alpha_transfer_inline49__ssa_v0_pview
          ;
          __gm__ float* v799 = PTOAS__GLOBAL_TENSOR_DATA(v193);
          // pto: %alpha_transfer_inline49__ssa_v0_pview
          ;
          const int64_t v800 = 0;
          // pto: %alpha_transfer_inline49__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 8, 1> v801 = pto::Shape<1, 1, 1, 8, 1>();
          // pto: %alpha_transfer_inline49__ssa_v0_pview
          ;
          pto::Stride<8, 8, 8, 1, 1536> v802 = pto::Stride<8, 8, 8, 1, 1536>();
          // pto: %alpha_transfer_inline49__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN> v803 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN>(v799 + (v800 + v481), v801, v802);
          TSTORE(v803, v539);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
        };
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        uint16_t v804 = getFFTSMsg(FFTS_MODE_VAL, v82);
        ffts_cross_core_sync(PIPE_MTE3, v804);
        int32_t v805 = (int32_t) v94;
        wait_flag_dev(v805);
        // pto: %next_m_inline21__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v806 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v77, v68);
        // pto: %next_m_inline21__ssa_v0
        ;
        uint64_t v807 = (uint64_t) v38;
        TASSIGN(v806, v807);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        TLOAD(v806, v328);
        // pto: %next_l_inline50__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v808 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v77, v68);
        // pto: %next_l_inline50__ssa_v0
        ;
        uint64_t v809 = (uint64_t) v40;
        TASSIGN(v808, v809);
        TLOAD(v808, v333);
        // pto: %alpha_inline152__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v810 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v77, v68);
        // pto: %alpha_inline152__ssa_v0
        ;
        uint64_t v811 = (uint64_t) v67;
        TASSIGN(v810, v811);
        // pto: %243
        ;
        __gm__ float* v812 = PTOAS__GLOBAL_TENSOR_DATA(v193);
        // pto: %243
        ;
        const int64_t v813 = 0;
        // pto: %243
        ;
        pto::Shape<1, 1, 1, 32, 1> v814 = pto::Shape<1, 1, 1, 32, 1>();
        // pto: %243
        ;
        pto::Stride<32, 32, 32, 1, 1536> v815 = pto::Stride<32, 32, 32, 1, 1536>();
        // pto: %243
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN> v816 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN>(v812 + (v813 + v323), v814, v815);
        TLOAD(v810, v816);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        // pto: %pv_left_inline20__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v817 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v77, v81);
        // pto: %pv_left_inline20__ssa_v0
        ;
        uint64_t v818 = (uint64_t) v39;
        TASSIGN(v817, v818);
        // pto: %pv_transfer_inline148__ssa_v0_pview
        ;
        __gm__ float* v819 = PTOAS__GLOBAL_TENSOR_DATA(v126);
        // pto: %pv_transfer_inline148__ssa_v0_pview
        ;
        const int64_t v820 = 0;
        // pto: %pv_transfer_inline148__ssa_v0_pview
        ;
        const int64_t v821 = 512;
        // pto: %pv_transfer_inline148__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 32, 256> v822 = pto::Shape<1, 1, 1, 32, 256>();
        // pto: %pv_transfer_inline148__ssa_v0_pview
        ;
        pto::Stride<16384, 16384, 16384, 512, 1> v823 = pto::Stride<16384, 16384, 16384, 512, 1>();
        // pto: %pv_transfer_inline148__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v824 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v819 + (v820 + v323 * v821), v822, v823);
        TLOAD(v817, v824);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        // pto: %t__tmp_v76
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v825 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v77, v81);
        // pto: %t__tmp_v76
        ;
        uint64_t v826 = (uint64_t) v65;
        TASSIGN(v825, v826);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v825, v318, v810);
        // pto: %next_left_inline181__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v827 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v77, v81);
        // pto: %next_left_inline181__ssa_v0
        ;
        uint64_t v828 = (uint64_t) v41;
        TASSIGN(v827, v828);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        TADD(v827, v825, v817);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
        // pto: %pv_right_inline19__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v829 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v77, v81);
        // pto: %pv_right_inline19__ssa_v0
        ;
        uint64_t v830 = (uint64_t) v39;
        TASSIGN(v829, v830);
        // pto: %246
        ;
        __gm__ float* v831 = PTOAS__GLOBAL_TENSOR_DATA(v126);
        // pto: %246
        ;
        const int64_t v832 = 256;
        // pto: %246
        ;
        const int64_t v833 = 512;
        // pto: %246
        ;
        pto::Shape<1, 1, 1, 32, 256> v834 = pto::Shape<1, 1, 1, 32, 256>();
        // pto: %246
        ;
        pto::Stride<16384, 16384, 16384, 512, 1> v835 = pto::Stride<16384, 16384, 16384, 512, 1>();
        // pto: %246
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v836 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v831 + (v832 + v323 * v833), v834, v835);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
        TLOAD(v829, v836);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %t__tmp_v77
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v837 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v77, v81);
        // pto: %t__tmp_v77
        ;
        uint64_t v838 = (uint64_t) v65;
        TASSIGN(v837, v838);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v837, v320, v810);
        // pto: %next_right_inline18__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v839 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v77, v81);
        // pto: %next_right_inline18__ssa_v0
        ;
        uint64_t v840 = (uint64_t) v42;
        TASSIGN(v839, v840);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        TADD(v839, v837, v829);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
      };
    };
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    // pto: %247, %248
    ;
    int64_t v841 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v289 * (uint64_t) v73) + (uint64_t) v295);
    // pto: %249
    ;
    int64_t v842 = v841 < v76 ? v76 : v841;
    // pto: %attn_mi_inline68__ssa_v0_pview
    ;
    int64_t v843 = (int64_t) v26;
    // pto: %attn_mi_inline68__ssa_v0_pview
    ;
    const int64_t v844 = 0;
    // pto: %attn_mi_inline68__ssa_v0_pview
    ;
    __gm__ float* v845 = PTOAS__GLOBAL_TENSOR_DATA(v202);
    // pto: %attn_mi_inline68__ssa_v0_pview
    ;
    const int64_t v846 = 1;
    // pto: %attn_mi_inline68__ssa_v0_pview
    ;
    const int64_t v847 = 1;
    // pto: %attn_mi_inline68__ssa_v0_pview
    ;
    const int64_t v848 = 1;
    // pto: %attn_mi_inline68__ssa_v0_pview
    ;
    int64_t v849 = v77 * v68;
    // pto: %attn_mi_inline68__ssa_v0_pview
    ;
    int64_t v850 = v848 * v849;
    // pto: %attn_mi_inline68__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 1> v851 = pto::Shape<1, 1, 1, 32, 1>(v846, v847, v848, v77, v68);
    // pto: %attn_mi_inline68__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v852 = pto::Stride<-1, -1, -1, -1, -1>(v847 * v850, v850, v849, v68, v843);
    // pto: %attn_mi_inline68__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v853 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v845 + (v844 + v842 * v68 + v76 * v843), v851, v852);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
    TSTORE(v853, v298);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    // pto: %attn_li_inline47__ssa_v0_pview
    ;
    int64_t v854 = (int64_t) v26;
    // pto: %attn_li_inline47__ssa_v0_pview
    ;
    const int64_t v855 = 0;
    // pto: %attn_li_inline47__ssa_v0_pview
    ;
    __gm__ float* v856 = PTOAS__GLOBAL_TENSOR_DATA(v211);
    // pto: %attn_li_inline47__ssa_v0_pview
    ;
    const int64_t v857 = 1;
    // pto: %attn_li_inline47__ssa_v0_pview
    ;
    const int64_t v858 = 1;
    // pto: %attn_li_inline47__ssa_v0_pview
    ;
    const int64_t v859 = 1;
    // pto: %attn_li_inline47__ssa_v0_pview
    ;
    int64_t v860 = v77 * v68;
    // pto: %attn_li_inline47__ssa_v0_pview
    ;
    int64_t v861 = v859 * v860;
    // pto: %attn_li_inline47__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 1> v862 = pto::Shape<1, 1, 1, 32, 1>(v857, v858, v859, v77, v68);
    // pto: %attn_li_inline47__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v863 = pto::Stride<-1, -1, -1, -1, -1>(v858 * v861, v861, v860, v68, v854);
    // pto: %attn_li_inline47__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v864 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v856 + (v855 + v842 * v68 + v76 * v854), v862, v863);
    TSTORE(v864, v316);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    // pto: %attn_oi_inline61__ssa_v0_pview
    ;
    __gm__ float* v865 = PTOAS__GLOBAL_TENSOR_DATA(v220);
    // pto: %attn_oi_inline61__ssa_v0_pview
    ;
    const int64_t v866 = 0;
    // pto: %attn_oi_inline61__ssa_v0_pview
    ;
    const int64_t v867 = 512;
    // pto: %attn_oi_inline61__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 256> v868 = pto::Shape<1, 1, 1, 32, 256>();
    // pto: %attn_oi_inline61__ssa_v0_pview
    ;
    pto::Stride<16384, 16384, 16384, 512, 1> v869 = pto::Stride<16384, 16384, 16384, 512, 1>();
    // pto: %attn_oi_inline61__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v870 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v865 + (v866 + v842 * v867), v868, v869);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v870, v318);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    // pto: %253
    ;
    __gm__ float* v871 = PTOAS__GLOBAL_TENSOR_DATA(v220);
    // pto: %253
    ;
    const int64_t v872 = 256;
    // pto: %253
    ;
    const int64_t v873 = 512;
    // pto: %253
    ;
    pto::Shape<1, 1, 1, 32, 256> v874 = pto::Shape<1, 1, 1, 32, 256>();
    // pto: %253
    ;
    pto::Stride<16384, 16384, 16384, 512, 1> v875 = pto::Stride<16384, 16384, 16384, 512, 1>();
    // pto: %253
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v876 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v871 + (v872 + v842 * v873), v874, v875);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v876, v320);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}