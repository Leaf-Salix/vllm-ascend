#include "pto/pto-inst.hpp"
using namespace pto;

enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void csa_checked_indices(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ int32_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, int64_t v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int32_t v12, int32_t v13) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int32_t v14 = 0;
  const int32_t v15 = -1;
  // pto: %c1_index
  const int64_t v16 = 1;
  // pto: %c512_index
  const int64_t v17 = 512;
  // pto: %c48_index
  const int64_t v18 = 48;
  // pto: %c0_index
  const int64_t v19 = 0;
  // pto: %c256_index
  const int64_t v20 = 256;
  // pto: %c2_index
  const int64_t v21 = 2;
  // pto: %c4_index
  const int64_t v22 = 4;
  // pto: %c32_index
  const int64_t v23 = 32;
  // pto: %c1024_index
  const int64_t v24 = 1024;
  // pto: %c2147483647_index
  const int64_t v25 = 2147483647;
  // pto: %checked_worker_inline102__ssa_v0
  for (int64_t v26 = (int64_t) v12; v26 < v11; v26 += v18) {
    // pto: %t__tile
    ;
    int64_t v27 = (v1)[v26];
    // pto: %c_request_inline99__tile
    ;
    int32_t v28 = (v2)[v26];
    for (int64_t v29 = v19; v29 < v20; v29 += v16) {
      // pto: %1
      ;
      int64_t v30 = (int64_t) ((uint64_t) v29 * (uint64_t) v21);
      // pto: %3
      ;
      int64_t v31 = (int64_t) v28;
      // pto: %4, %6, %7
      ;
      // pto: %checked_inline189__phi_v6
      ;
      int32_t v32;
      // pto: %checked_inline189__phi_v6
      ;
      int32_t v33;
      if (v31 >= v19 & v31 < v9) {
        // pto: %8
        ;
        int32_t v34 = (v3)[v31];
        // pto: %9, %10
        ;
        bool v35 = (int64_t) v34 > v19;
        // pto: %checked_inline187__phi_v5
        ;
        int32_t v36;
        if (v35) {
          // pto: %12, %13
          ;
          int64_t v37 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v26 * (uint64_t) v17) + (uint64_t) v30);
          // pto: %11
          ;
          int32_t v38 = (v4)[v37];
          // pto: %17
          ;
          int64_t v39 = (int64_t) v38;
          // pto: %18, %20, %21, %22, %23
          ;
          // pto: %checked_inline187__phi_v4
          ;
          int32_t v40;
          if (v39 >= v19 & v39 < (int64_t) ((uint64_t) v27 + (uint64_t) v16) / v22) {
            // pto: %24
            ;
            int32_t v41 = (v4)[v37];
            // pto: %27, %28
            ;
            int64_t v42 = (int64_t) v41 / v23;
            // pto: %29
            ;
            // pto: %checked_inline187__phi_v3
            ;
            int32_t v43;
            if (v42 < v10) {
              // pto: %32, %33, %30
              ;
              int32_t v44 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v31 * (uint64_t) v10) + (uint64_t) v42)];
              // pto: %34, %35
              ;
              // pto: %checked_inline187__phi_v2
              ;
              int32_t v45;
              if ((int64_t) v44 >= v19) {
                // pto: %checked_inline187__tile
                ;
                int32_t v46 = (v4)[v37];
                v45 = v46;
              } else {
                v45 = v15;
              };
              v43 = v45;
            } else {
              v43 = v15;
            };
            v40 = v43;
          } else {
            v40 = v15;
          };
          v36 = v40;
        } else {
          v36 = v15;
        };
        // pto: %checked_inline189__phi_v5
        ;
        int32_t v47;
        if (v35) {
          // pto: %50, %51, %49
          ;
          int64_t v48 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v26 * (uint64_t) v17) + (uint64_t) ((int64_t) (uint64_t) v30 + (uint64_t) v16));
          // pto: %48
          ;
          int32_t v49 = (v4)[v48];
          // pto: %56
          ;
          int64_t v50 = (int64_t) v49;
          // pto: %57, %59, %60, %61, %62
          ;
          // pto: %checked_inline189__phi_v4
          ;
          int32_t v51;
          if (v50 >= v19 & v50 < (int64_t) ((uint64_t) v27 + (uint64_t) v16) / v22) {
            // pto: %63
            ;
            int32_t v52 = (v4)[v48];
            // pto: %67, %68
            ;
            int64_t v53 = (int64_t) v52 / v23;
            // pto: %69
            ;
            // pto: %checked_inline189__phi_v3
            ;
            int32_t v54;
            if (v53 < v10) {
              // pto: %72, %73, %70
              ;
              int32_t v55 = (v5)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v31 * (uint64_t) v10) + (uint64_t) v53)];
              // pto: %74, %75
              ;
              // pto: %checked_inline189__phi_v2
              ;
              int32_t v56;
              if ((int64_t) v55 >= v19) {
                // pto: %checked_inline189__tile
                ;
                int32_t v57 = (v4)[v48];
                v56 = v57;
              } else {
                v56 = v15;
              };
              v54 = v56;
            } else {
              v54 = v15;
            };
            v51 = v54;
          } else {
            v51 = v15;
          };
          v47 = v51;
        } else {
          v47 = v15;
        };
        v32 = v36;
        v33 = v47;
      } else {
        v32 = v15;
        v33 = v15;
      };
      // pto: %80
      ;
      int64_t v58 = (int64_t) v32;
      // pto: %81
      ;
      int64_t v59 = (int64_t) v33;
      // pto: %83, %85, %86
      ;
      // pto: %swap_inline197__phi_v5
      ;
      int32_t v60;
      if (v58 >= v19 & v59 >= v19) {
        // pto: %80
        ;
        int64_t v61 = (int64_t) v32;
        // pto: %88, %89
        ;
        int64_t v62 = (int64_t) ((uint64_t) v27 + (uint64_t) v16) / v22;
        // pto: %81
        ;
        int64_t v63 = (int64_t) v33;
        // pto: %87, %90, %91, %94, %95
        ;
        // pto: %swap_inline197__phi_v4
        ;
        int32_t v64;
        if ((int64_t) ((uint64_t) v61 + (uint64_t) v16) < v62 & (int64_t) ((uint64_t) v63 + (uint64_t) v16) < v62) {
          // pto: %80
          ;
          int64_t v65 = (int64_t) v32;
          // pto: %99
          ;
          int64_t v66 = (int64_t) ((uint64_t) v31 * (uint64_t) v10);
          // pto: %100, %98, %96
          ;
          int32_t v67 = (v5)[(int64_t) ((uint64_t) v66 + (uint64_t) (v65 / v23))];
          // pto: %81
          ;
          int64_t v68 = (int64_t) v33;
          // pto: %106, %104, %102
          ;
          int32_t v69 = (v5)[(int64_t) ((uint64_t) v66 + (uint64_t) (v68 / v23))];
          // pto: %80
          ;
          int64_t v70 = (int64_t) v32;
          // pto: %101, %108, %110, %109
          ;
          int64_t v71 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v67) * (uint64_t) v23) + (uint64_t) (v70 % v23));
          // pto: %81
          ;
          int64_t v72 = (int64_t) v33;
          // pto: %107, %111, %113, %112
          ;
          int64_t v73 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v69) * (uint64_t) v23) + (uint64_t) (v72 % v23));
          // pto: %114
          ;
          // pto: %swap_inline197__phi_v3
          ;
          int32_t v74;
          if (v73 < v71) {
            // pto: %115, %116, %117, %118, %swap_inline197__phi_v2
            ;
            v74 = (int32_t) ((int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v71 - (uint64_t) v73) - (uint64_t) v16) * (uint64_t) v24) < v25);
          } else {
            v74 = v14;
          };
          v64 = v74;
        } else {
          v64 = v14;
        };
        v60 = v64;
      } else {
        v60 = v14;
      };
      // pto: %120
      ;
      int64_t v75 = (int64_t) v60;
      // pto: %121
      ;
      if (v75 > v19) {
        // pto: %122
        ;
        int64_t v76 = (int64_t) ((uint64_t) v26 * (uint64_t) v17);
        // pto: %123
        ;
        int64_t v77 = (int64_t) ((uint64_t) v76 + (uint64_t) v30);
        (v6)[v77] = v33;
        // pto: %126, %124
        ;
        int64_t v78 = (int64_t) ((uint64_t) v76 + (uint64_t) ((int64_t) (uint64_t) v30 + (uint64_t) v16));
        (v6)[v78] = v32;
      } else {
        // pto: %127
        ;
        int64_t v79 = (int64_t) ((uint64_t) v26 * (uint64_t) v17);
        // pto: %128
        ;
        int64_t v80 = (int64_t) ((uint64_t) v79 + (uint64_t) v30);
        (v6)[v80] = v32;
        // pto: %131, %129
        ;
        int64_t v81 = (int64_t) ((uint64_t) v79 + (uint64_t) ((int64_t) (uint64_t) v30 + (uint64_t) v16));
        (v6)[v81] = v33;
      };
    };
  }
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  #endif // __DAV_VEC__

  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}