#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
here=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "$here/pin-v6.sh"
source "$here/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
unset SIMPLER_PMU_EVENT_TYPE
label="${1:?new label}";shift
[[ "$label" =~ ^[A-Za-z0-9_.-]+$ ]]
mkdir -p "$here/program-results"
mkdir "$here/program-results/$label"
python "$here/preflight.py" > "$here/program-results/$label/preflight.log" 2>&1
# No PMU/DFX; same-card interleaved actual ACL graph.
timeout --signal=TERM --kill-after=15s 750s python "$here/graph_ab.py" \
 --bank /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/qkpv-measurement-20261019-codex/capture-b4/csa-results/native-sparse-bank/data/native-sparse-bank.pt \
 --bank-sha 66158da293867dc48626083df47404b919ee859fb9719c8d55c0f88f4809668e \
 --stats /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/qkpv-measurement-20261019-codex/sparse-program/program-results/b4-stats-gold-device/data/stats-gold.pt \
 --stats-sha eb43040864b3b1209d1533f8ce0f2de68b6cee6be322905f45fba6b44e82feb2 \
 --out "$here/program-results/$label/data" "$@" > "$here/program-results/$label/run.log" 2>&1
