# SWA Cube 单因素整模型快照准备工具审查

日期：2026-10-19。结论：**允许静态准备，不代表允许声明整模型已验收**。本审查未执行工具、提交任务或修改正式源码。

## 已核对

- 复制的正式 `prepare_tnd_precision_performance_repro.py` 与当前 checkout 对应工具逐字节相同。
- `prepare(..., profile="v6")` 固定核验 source6d965、helper6e3d，逐项 hash 验证后只复制 manifest 白名单文件；拒绝 symlink、路径穿越、重叠目标和已有目标。relocation 次数不符时在 mkdir 前失败。
- 新工具仅写一个正式 Sparse Python 文件，其余 source 由固定3365文件白名单复制。新文件 raw SHA 确为8f3ddd，三处 absolute package import 转成 relative 后解析通过、无残留 absolute package import，预期 SHA 为 `0b6c0af7100bcb87010a9a7fc19690d48f074648a9b1f6b3d8c124384af14149`。
- source manifest、candidate-math、patch 和43运行源绑定同步更新，并逐文件重新核验；helper manifest 也重算已改 JSON/helper 与新增 reference/repro-tools 文件。
- micro-gates 的四个 label/result SHA 均不同，原始 result.json 在本地存在且 SHA 逐一相符；B4与B40各两次，每次71 checks、20 paired全部正收益。没有将同一结果重复当成四次。
- FINAL_SOURCE_BOUND 新记录明确 static binding、NPU_executed=false、wholepending；历史 JSON 另存 reference 副本。不应把这里的静态 pass 解释为新 whole PASS。
- run-case 的 Native gold、bank、phase观测和数学门禁沿用；source/helper/config记录改为新快照。旧 read-only audit 使用显式新 `--expected-source-manifest`、新 `--candidate-math`、独立 `--identity` 即可继续使用，3365文件/资格/Native token事件/metadata严格比较规则不需放宽。

## 必须据实标注的来源

`PACKAGE_READY.json` 继承的 selection_sha256 与 canonical_identity_sha256 仍指 V6 旧 selection/canonical，而 selected_options 已追加 swa。新 scope 虽已说明 static-only，归档时仍建议把两者标成 baseline/reference，并另写本轮单文件转换 receipt，避免误读为新候选完整 canonical 证明。这不阻断白名单复制本身。

`reference-reproduction.json` 是通用prepare生成的“V6迁移到新地址”记录副本，不是未经改动的历史 reference job 原 reproduction；可保留，但说明这一点。

当前本地 scaffold env/run脚本并非最终 V6 helper hash，不能用 scaffold 推断真实 relocation 一定成功；工具按固定 helper 真值做 replace 计数，若不符会安全失败。准备成功后应审最终 env/source_preflight/configuration，确认实际 SOURCE_ROOT/import 指向新地址而非历史 job。历史 gold/reference 绝对路径则属于有意保留，不应误删。

## 结果身份

工具 SHA、四个原始 micro 结果 SHA 和转换后新 Sparse SHA 记录在同目录 `results.json`。本轮未将任何整模型结果重新标记为 PASS，未运行 NPU。
