# Native Sparse 输入 bank 捕获助手独立审查

日期：2026-10-19。只读审查 `capture-b4/probe_threeway.py` 相对 `pmu-pilot/probe_threeway.py`；未提交设备任务或修改源码。

## 结论

**具备执行捕获任务的条件，未发现阻断；后续 PMU 须保留下述观测范围。** 本地 Python AST 解析通过，helper manifest 54 项逐 SHA 全部一致。源差异与 SHA 记录见同目录 `source.diff` 和 `results.json`。

- Native 原 FULL graph 门禁及 A/B/A 原样保留；后面新增的 eager 捕获只执行 Native 一臂，未改变正式模型代码。
- `DeviceOperator.get_dsa_sparse_attn_op` 本来就是 staticmethod。保存原函数、替换 getter、在 finally 包回 staticmethod 恢复，调用语义正确。
- 包装器先调用实际 Sparse op，再 synchronize，再将 Q/kwargs/output[0] 转 CPU 并 contiguous。复制发生在返回 self-attn 的 inverse RoPE 后续处理之前，因此保存的 `native_heads` 是 Sparse op 的 BF16 结果。CPU副本独立于后续 NPU 写入。
- 捕获只允许一次 op；再次调用会 assert。当前 ratio4 Native 路径是动态读取 getter，因此能拦截实际 Sparse 调用。
- 捕获后八边界对 Native FULL 逐 bit，通过才保存 bank；bank/result 写入后 `SystemExit(0)`，不会继续执行继承的计时/PMU段。Exception 分支不接管 SystemExit，但正常退出码确实为0；Python contextmanager 正常清理。

## 范围限定

1. `collect_state` 保存最终 HC 输出、TopK 和 cache 视图。它未直接保存 FULL graph 内部的 Q 与 pre-inverse-RoPE heads，因此八边界相同不能逻辑推出所有这些内部 tensor 逐 bit 相同。bank 应准确称为“同 fixture 的 eager Native Sparse 实参/结果，外部八边界与已验收 FULL 一致”。不得称为直接从 FULL replay 截获内部实参。
2. `.cpu().contiguous()` 保留值但可能改变原 NPU 的 stride/storage_offset。当前 summary 只有 shape/dtype/SHA。建议补记每个原 tensor 的 device/stride/storage_offset 以及 bank stride；若原始本就连续，也应据实记录。后续搬运 PMU 若采用另一布局，必须披露这一差异。
3. 正式做 isolated Sparse PMU 前，先用 bank 原样回放实际 Sparse op，与保存 `native_heads` 逐 bit 对齐。它是最直接的输入/结果归属门禁；不要仅以整层最终输出相等代替。

## 两项小加固建议

- 将 `restore(f)` 放进 monkeypatch 后的 try 内，避免 restore 自身抛异常时 getter 来不及恢复。
- 捕获 eager 完成后再检查 `guard_checks(f)` 及 hidden/positions 只读一致；八个数值边界没有覆盖 allocation 保护区和所有只读 metadata。当前 FULL 路径已有这些门禁，但新增 eager 捕获应独立保留。

以上两项不改变算子数值；本轮仅提供建议，未修改已冻结助手。
