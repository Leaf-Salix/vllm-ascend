"""8K真实权重、单层整CSA FULL图三方对拍；首差停止。"""
import argparse
import contextlib
import hashlib
import importlib
import json
import os
from pathlib import Path
import statistics
import sys
import types

import torch
import torch_npu
import pypto.torch
import vllm_ascend.ops.dsv4_csa as csa_dispatch
from vllm.config import CUDAGraphMode
from vllm.engine.arg_utils import EngineArgs
from vllm.forward_context import get_forward_context
from vllm.platforms import current_platform
from vllm_ascend.ascend_forward_context import set_ascend_forward_context
from dsv4_csa_native_case import native_session
from dsv4_csa_single_layer import make_layer, restore, collect_state, guard_checks
from ragged_fixture import make_ragged_fixture
from npugraph_ex._acl_concrete_graph.acl_graph import AclGraph

ROOT = Path(__file__).resolve().parent
BASE = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
META_SHA = '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--batch',type=int,choices=(4,40),required=True)
parser.add_argument('--timing-iters',type=int,choices=(10,20),default=10)
parser.add_argument('--device',type=int)
args = parser.parse_args()
lengths = [6]*args.batch
tokens, batch = sum(lengths), len(lengths)
assert all(1<=q<=6 for q in lengths) and batch<=40 and tokens<=256
assert not (args.out/'result.json').exists()
args.out.mkdir(parents=True,exist_ok=True)
report = {'complete':False,'pass':False,'scope':'real L4 weights, synthetic hidden/history8191, complete HC-pre through HC-post; BSH precision recorded only; not whole model',
          'lengths':lengths,'true_tokens':tokens,'physical_graph_tokens':tokens,'per_request_padding':0,
          'hypothetical_s6_tokens':batch*6,'hypothetical_s6_extra_rows':batch*6-tokens,
          'tnd_source':'explicit TRI_VARIANT_DIR/ENV/MANIFEST/ROOTMODULE',
          'bsh_commit':'a919f11942d93627441c8fa694e310dcbd1c671b','graphs':{},'comparisons':{},'static':{},
          'timing_rounds':8,'timing_iters':args.timing_iters,'SK':0,'NZ':2,'DFX':False,'depgen':False}
def save():
    (args.out/'result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
def exact(x,y):
    return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def metric(x,y):
    if x.shape!=y.shape or x.dtype!=y.dtype:
        return {'bit_equal':False,'shapes':[list(x.shape),list(y.shape)],'dtypes':[str(x.dtype),str(y.dtype)]}
    equal=exact(x,y)
    delta=x.float()-y.float()
    byte_diff=x.contiguous().view(torch.uint8)!=y.contiguous().view(torch.uint8)
    bit_diff=byte_diff.reshape(*x.shape,x.element_size()).any(-1)
    return {'bit_equal':equal,'different_elements':int(bit_diff.sum()),'max_abs':float(delta.abs().max()),
            'relative_l2':float(torch.linalg.vector_norm(delta)/torch.linalg.vector_norm(y.float()).clamp_min(1e-30)),
            'first_coordinates':bit_diff.nonzero()[:6].tolist()}

from tri_identity import identity
variant_identity,tnd_root=identity()
report['variant_identity']=variant_identity
report['root_abi']={'tnd':{'param_names':list(tnd_root.param_names),'count':len(tnd_root.param_names)}}
assert len(tnd_root.param_names)==62

historical = types.ModuleType('historical_pypto')
historical.__path__=[str(ROOT/'bsh-source/vllm_ascend/ops/pypto')]
sys.modules['historical_pypto']=historical
bsh_adapter=importlib.import_module('historical_pypto.deepseek_v4_flash_csa.native_adapter')
bsh_service=importlib.import_module('historical_pypto.deepseek_v4_flash_csa.service')
assert Path(bsh_adapter.__file__).resolve().is_relative_to(ROOT/'bsh-source')
assert Path(bsh_service.__file__).resolve().is_relative_to(ROOT/'bsh-source')
report['root_abi']['bsh']={'param_names':list(bsh_adapter.decode_csa_tp1_layer_test.param_names),'count':len(bsh_adapter.decode_csa_tp1_layer_test.param_names),'adapter_file':str(Path(bsh_adapter.__file__).resolve())}
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.native_adapter import CSAOperators
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.service import CSAServiceRuntime

class NativeHalf(torch.nn.Module):
    def __init__(self,layer):
        super().__init__();self.layer=layer
    def forward(self,hidden,positions,output):
        l=self.layer
        mixed,post,comb=l.hc_pre(hidden,l.hc_attn_fn,l.hc_attn_scale,l.hc_attn_base)
        normed=l.input_layernorm(mixed)
        attended=l.self_attn(positions=positions,hidden_states=normed,llama_4_scaling=None)
        output.copy_(l.hc_post(attended,hidden,post,comb))
        return output

class PTOHalf(torch.nn.Module):
    def __init__(self,prefix):
        super().__init__();self.prefix=prefix
    def forward(self,hidden,positions,output):
        torch.ops.vllm.dsv4_csa_forward(hidden,positions,output,self.prefix)
        return output

class RequirePTO:
    def __init__(self,delegate):
        self.delegate,self.calls=delegate,0
    def eligible(self,*values):
        if not self.delegate.eligible(*values):
            raise RuntimeError('Unexpected PTO fallback')
        return True
    def __call__(self,*values,**kwargs):
        self.calls+=1
        return self.delegate(*values,**kwargs)

current_platform.pre_register_and_update()
torch.npu.set_device(0)
torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
assert torch.are_deterministic_algorithms_enabled()
from vllm_ascend import envs
assert envs.VLLM_ASCEND_ENABLE_NZ==2 and envs.VLLM_ASCEND_PTO_CSA_ATOMIC_ADD==0
assert envs.PTO_CSA_RUNTIME=='tensormap_and_ringbuffer' and os.environ['HCCL_DETERMINISTIC']=='true'
report['determinism']={'torch_algorithms':True,'npu_requested_level':1,'HCCL_DETERMINISTIC':True,'atomic':0}
from vllm_ascend.utils import enable_custom_op
assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,
 tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},
 max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,
 enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},
 compilation_config={'cudagraph_mode':'FULL_DECODE_ONLY','cudagraph_capture_sizes':[tokens],'cache_dir':str(args.out/'vllm-cache')},
 additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},
 'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()

states, fixtures, rows, keepalive = {}, {}, {}, []
save()
try:
 with native_session(config,0),torch.inference_mode():
    layer,details=make_layer(config,checkpoint,torch.device('npu:0'),4)
    report['weight_details']=details
    pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
    report['runtime_identities']={name:{'file':str(Path(importlib.import_module(name).__file__).resolve()),'version':str(getattr(importlib.import_module(name),'__version__',None))} for name in ('torch','torch_npu','vllm','vllm_ascend','pypto','simpler','npugraph_ex')}
    impl=layer.self_attn.dsa_attn.dsa_attn.impl
    observed={}
    original_qli=torch.ops._C_ascend.npu_vllm_quant_lightning_indexer
    def observe_qli(*values,**kwargs):
        result=original_qli(*values,**kwargs);observed['topk']=result[0];return result
    torch.ops._C_ascend.npu_vllm_quant_lightning_indexer=observe_qli
    # 保留原13包校验桥；只在首次真实reselect后复用选择，禁止捕获之后变更选择。
    selection=[]
    original_reselect=torch_npu.npu._aclnn_reselect_static_kernel
    def qualified_reselect(*values,**kwargs):
        assert hashlib.sha256((Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE'])/'metadata.json').read_bytes()).hexdigest()==META_SHA
        assert not values and not kwargs
        if not selection:
            selection.append(original_reselect())
            report['static']['actual_reselect_count']=1
        else:
            report['static']['validated_reuses']=report['static'].get('validated_reuses',0)+1
        report['static']['metadata_sha256']=META_SHA
        return selection[0]
    # 框架可能已from-import compile_static_kernel；在实际API边界观测，避免漏掉别名调用。
    torch_npu.npu._aclnn_reselect_static_kernel=qualified_reselect

    original_fallback=csa_dispatch._native_attention_half
    fallback_calls={}
    for arm in ('native',):
        print('ARM_START',arm,flush=True)
        fallback_calls[arm]=0
        if arm=='native':
            csa_dispatch._native_attention_half=original_fallback
        else:
            def reject_fallback(*values,**kwargs):
                fallback_calls[arm]+=1
                raise RuntimeError('Unexpected Native fallback during '+arm)
            csa_dispatch._native_attention_half=reject_fallback
        torch._dynamo.reset()
        f=make_ragged_fixture(config,layer.self_attn,batch,8191,1024,torch.device('npu:0'),lengths)
        fixtures[arm]=f
        if arm!='native':
            for field in ('hidden','positions'):
                assert exact(f[field],fixtures['native'][field]),(arm,field)
            for name,g in f['groups'].items():
                assert exact(g['initial'],fixtures['native']['groups'][name]['initial']),(arm,name)
        runtime=None
        if arm=='tnd':
            op=pypto.torch.register(tnd_root,'tri_parameterized_tnd::attention')
            runtime=CSAServiceRuntime(layer.self_attn,CSAOperators(op),40,layer)
            assert selection,'Native graph did not install and select static packages'
            runtime.qualify_static_wkv(metadata_sha256=META_SHA,reselected=True)
        elif arm=='bsh':
            op=pypto.torch.register(bsh_adapter.decode_csa_tp1_layer_test,'tri_parameterized_bsh_a919f::attention')
            runtime=bsh_service.CSAServiceRuntime(layer.self_attn,bsh_adapter.CSAOperators(op),40,layer)
        @contextlib.contextmanager
        def context():
            with set_ascend_forward_context(f['metadata'],config,num_tokens=tokens,num_actual_tokens=tokens,
                                            aclgraph_runtime_mode=CUDAGraphMode.FULL):
                assert get_forward_context().cudagraph_runtime_mode is CUDAGraphMode.FULL
                yield
        if runtime is not None:
            with context():
                eligible=runtime.eligible(get_forward_context(),f['hidden'],f['positions'])
            report.setdefault('entry',{})[arm]={'eligible':eligible,'route':'PTO' if eligible else 'Native fallback','metadata':{
                name:{'bounds':f['metadata'][g['prefix']].decode.query_start_loc.cpu().tolist(),
                      'max_q':f['metadata'][g['prefix']].decode.max_seqlen_q,
                      'num_decodes':f['metadata'][g['prefix']].num_decodes,
                      'actual_tokens':f['metadata'][g['prefix']].num_actual_tokens} for name,g in f['groups'].items()}}
            save()
            assert eligible,(arm,'uniform S6 must execute PTO, no fallback accepted')
            assert not getattr(runtime,'is_hbg',False),(arm,'unexpected host-build graph runtime')
            assert runtime.operators.attention is op,(arm,'registered root binding drift')
            guarded=RequirePTO(runtime)
            layer.self_attn.dsa_attn._pto_csa_runtime=guarded
        else:
            layer.self_attn.dsa_attn._pto_csa_runtime=None
        hidden_gold=f['hidden'].clone()
        positions_gold=f['positions'].clone()
        output=torch.empty_like(f['hidden'])
        module=NativeHalf(layer) if arm=='native' else PTOHalf(layer.self_attn.dsa_attn.prefix)
        restore(f)
        with context():module(f['hidden'],f['positions'],output)
        torch.npu.synchronize()
        eager_calls=guarded.calls if runtime is not None else 0
        if runtime is not None:assert eager_calls>0,(arm,'PTO delegate not called eagerly')
        instances={}
        old_run=AclGraph.run
        def record(owner,key,*values,**kwargs):
            instances[(id(owner),key)]=owner
            return old_run(owner,key,*values,**kwargs)
        AclGraph.run=record
        options={'force_eager':False,'inplace_pass':True,'clone_input':False,'clone_output':False,
                 'static_kernel_compile':True,'super_kernel_optimize':False}
        torch.npu.set_compile_mode(jit_compile=False)
        try:
            compiled=torch.compile(module,backend='npugraph_ex',fullgraph=True,dynamic=False,options=options)
            restore(f)
            with context():compiled(f['hidden'],f['positions'],output)
            torch.npu.synchronize()
            assert len(instances)==1,(arm,'not exactly one actual graph',len(instances))
            (_,key),owner=next(iter(instances.items()))
            assert not owner._updated_node_infos,'Host updated nodes invalidate raw replay test'
            graph=owner.graph[key]
        finally:
            AclGraph.run=old_run
        if runtime is not None:
            assert guarded.calls>eager_calls,(arm,'no actual PTO delegate execution in graph compilation/capture')
        report.setdefault('routes',{})[arm]={'runtime_module':runtime.__class__.__module__ if runtime is not None else None,'eager_PTO_calls':eager_calls,'capture_PTO_calls':guarded.calls-eager_calls if runtime is not None else 0,'Native_fallback_calls':fallback_calls[arm],'is_hbg':getattr(runtime,'is_hbg',False) if runtime is not None else False}
        assert fallback_calls[arm]==0
        topk=runtime.topk[:tokens] if runtime is not None and report['entry'][arm]['eligible'] else observed['topk']
        compiled_state=collect_state(f,output,topk)
        restore(f);output.fill_(float('nan'));topk.fill_(-12345);graph.replay();torch.npu.synchronize()
        actual=collect_state(f,output,topk)
        assert all(exact(value,compiled_state[name]) for name,value in actual.items()),(arm,'compiled/raw mismatch')
        finite_output=bool(torch.isfinite(output).all())
        if arm!='bsh':assert finite_output,(arm,'nonfinite output')
        else:report['bsh_finite_output']=finite_output
        assert exact(f['hidden'],hidden_gold) and exact(f['positions'],positions_gold),(arm,'readonly input changed')
        guards=guard_checks(f)
        assert all(value['status']=='PASS' for value in guards.values()),(arm,'guard',guards)
        states[arm]=actual
        rows[arm]=(graph,f,output,topk)
        keepalive.append((compiled,module,owner,runtime))
        report['graphs'][arm]={'actual_acl_graph':True,'fullgraph':True,'options':options,
                                'true_tokens':tokens,'graph_tokens':tokens,'guards':guards,'compiled_raw_equal':True,
                                'topk_poison_replay_restored':True,'native_super_kernel_optimize':False}
        if arm!='native':
            checks={name:metric(value,states['native'][name]) for name,value in actual.items()}
            report['comparisons'][arm]=checks
            save()
            if not all(check['bit_equal'] for check in checks.values()):
                report['first_failed_arm']=arm
                report['failed_boundaries']=[name for name,m in checks.items() if not m['bit_equal']]
                if arm=='tnd':
                    raise RuntimeError(arm+': first bit difference; stop matrix and timing')
                report['bsh_precision_not_a_performance_gate']=True
        before=f['hidden'].clone()
        restore(f);f['hidden'].add_(0.125);graph.replay();torch.npu.synchronize()
        assert not exact(output.cpu(),actual['x_out']),(arm,'stale input graph')
        assert all(value['status']=='PASS' for value in guard_checks(f).values()),(arm,'B guards')
        f['hidden'].copy_(before);restore(f);graph.replay();torch.npu.synchronize()
        restored=collect_state(f,output,topk)
        assert all(exact(value,actual[name]) for name,value in restored.items()),(arm,'A restore')
        report['graphs'][arm]['live_input_ABA']=True
        assert exact(f['hidden'],hidden_gold) and exact(f['positions'],positions_gold),(arm,'ABA readonly input changed')
        save()
        print('ARM_PASS',arm,flush=True)
        from vllm_ascend.device.device_op import DeviceOperator
        original_get_sparse = DeviceOperator.get_dsa_sparse_attn_op
        actual_sparse = original_get_sparse()
        captured = {}
        def capture_sparse(q, **kwargs):
            result = actual_sparse(q, **kwargs)
            torch.npu.synchronize()
            assert not captured, 'more than one sparse attention call'
            captured['original_layout']={k:{'shape':list(v.shape),'stride':list(v.stride()),'storage_offset':v.storage_offset(),'device':str(v.device),'contiguous':v.is_contiguous()} for k,v in {'q':q,'native_heads':result[0],**kwargs}.items() if isinstance(v,torch.Tensor)}
            captured.update(q=q.detach().cpu().contiguous(),
                kwargs={k:(v.detach().cpu().contiguous() if isinstance(v,torch.Tensor) else v) for k,v in kwargs.items()},
                native_heads=result[0].detach().cpu().contiguous(),
                positions=f['positions'].detach().cpu().contiguous(),
                lengths=lengths, layer=4, history=8191, seed=1024,
                source_identity=variant_identity, static_sha256=META_SHA)
            return result
        DeviceOperator.get_dsa_sparse_attn_op = staticmethod(lambda: capture_sparse)
        try:
            restore(f)
            with context():module(f['hidden'],f['positions'],output)
        finally:
            DeviceOperator.get_dsa_sparse_attn_op = staticmethod(original_get_sparse)
        torch.npu.synchronize()
        assert all(v['status']=='PASS' for v in guard_checks(f).values()), 'capture guards'
        assert exact(f['hidden'],hidden_gold) and exact(f['positions'],positions_gold), 'capture readonly inputs'
        captured_state=collect_state(f,output,observed['topk'])
        capture_checks={key:metric(value,states['native'][key]) for key,value in captured_state.items()}
        report['capture_matches_Native_FULL']=capture_checks
        save()
        assert all(v['bit_equal'] for v in capture_checks.values()), 'FIRST_BIT_DIFFERENCE capture vs actual Native FULL graph'
        assert arm == 'native' and captured
        target=args.out/'native-sparse-bank.pt'
        torch.save(captured,target)
        tensor_summary={}
        for key,value in {'q':captured['q'],'native_heads':captured['native_heads'],'positions':captured['positions'],**captured['kwargs']}.items():
            if isinstance(value,torch.Tensor):
                tensor_summary[key]={'shape':list(value.shape),'dtype':str(value.dtype),'sha256':hashlib.sha256(value.view(torch.uint8).numpy().tobytes()).hexdigest()}
        report['captured_bank']={'file':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'tensors':tensor_summary,
            'scope':'eager Native sparse call after real L4 preparation, plus Native FULL graph ABA/guard checks; tensor bank remains remote'}
        report['pass']=report['complete']=True
        save()
        print('CAPTURE_COMPLETE',json.dumps(report['captured_bank']),flush=True)
        raise SystemExit(0)

    # 精度先行；全部通过才运行短计时，避免几十分钟重复回放。
    samples={arm:[] for arm in rows}
    for round_index in range(8):
        for arm in (tuple(rows) if round_index%2==0 else tuple(reversed(rows))):
            graph,f,output,topk=rows[arm]
            restore(f);torch.npu.synchronize()
            begin,end=torch.npu.Event(enable_timing=True),torch.npu.Event(enable_timing=True)
            begin.record()
            for _ in range(args.timing_iters):graph.replay()
            end.record();torch.npu.synchronize()
            samples[arm].append(begin.elapsed_time(end)*1000/args.timing_iters)
            final=collect_state(f,output,topk)
            assert all(exact(v,states[arm][k]) for k,v in final.items()),(arm,'timing changed state')
            assert all(value['status']=='PASS' for value in guard_checks(f).values()),(arm,'timing guards')
    # PMU pilot: preserve uninstrumented timing above; collect separate replay.
    report['pmu']={'metric':'PipeUtilization','level':2,'replays_per_arm':3,'arms':{},
                   'scope':'CANN launch-level counters; inner PTO function attribution must be inspected, never assumed'}
    for arm in rows:
        graph,f,output,topk=rows[arm]
        restore(f);torch.npu.synchronize()
        profile_dir=args.out/'pmu'/arm
        with torch_npu.profiler.profile(
            activities=[torch_npu.profiler.ProfilerActivity.CPU,torch_npu.profiler.ProfilerActivity.NPU],
            schedule=torch_npu.profiler.schedule(wait=0,warmup=0,active=1,repeat=1),
            record_shapes=False,profile_memory=False,with_stack=False,with_modules=False,
            experimental_config=torch_npu.profiler._ExperimentalConfig(
                profiler_level=torch_npu.profiler.ProfilerLevel.Level2,
                aic_metrics=torch_npu.profiler.AiCMetrics.PipeUtilization),
            on_trace_ready=torch_npu.profiler.tensorboard_trace_handler(str(profile_dir)),
        ) as prof:
            begin,end=torch.npu.Event(enable_timing=True),torch.npu.Event(enable_timing=True)
            begin.record()
            for _ in range(3):graph.replay()
            end.record();torch.npu.synchronize();prof.step()
        final=collect_state(f,output,topk)
        assert all(exact(v,states[arm][k]) for k,v in final.items()),(arm,'PMU state drift')
        assert all(v['status']=='PASS' for v in guard_checks(f).values()),(arm,'PMU guards')
        report['pmu']['arms'][arm]={'directory':str(profile_dir),
            'event_us_per_replay':begin.elapsed_time(end)*1000/3,
            'output_and_cache_unchanged':True}
        save()
    csa_dispatch._native_attention_half=original_fallback
    report['fallback_calls']=fallback_calls
    assert all(v==0 for v in fallback_calls.values())
    report['timing_us']={arm:{'min':min(v),'mean':statistics.mean(v),'max':max(v),'samples':v} for arm,v in samples.items()}
    report['complete']=report['pass']=True
    save()
except Exception as exc:
    report['error']=repr(exc)
    save()
    torch.save({'states':states,'inputs':{arm:{'hidden':f['hidden'].cpu(),'positions':f['positions'].cpu(),
                    'initial':{name:g['initial'] for name,g in f['groups'].items()}} for arm,f in fixtures.items()}},args.out/'first-difference.pt')
    raise
print('COMPLETE',json.dumps(report.get('timing_us',{})),flush=True)
