#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void diagnostic_publish(__gm__ float* v1, __gm__ float* v2, __gm__ float* v3, __gm__ float* v4, __gm__ float* v5, __gm__ float* v6, __gm__ float* v7, __gm__ bfloat16_t* v8, int64_t v9, int64_t v10, int64_t v11, int32_t v12, int32_t v13) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v14 = 0;
  // pto: %c32768_i64
  const int64_t v15 = 32768;
  // pto: %c64_index
  const int64_t v16 = 64;
  // pto: %c1_index
  const int64_t v17 = 1;
  // pto: %c512_index
  const int64_t v18 = 512;
  // pto: %c24_index
  const int64_t v19 = 24;
  // pto: %c0_index
  const int64_t v20 = 0;
  // pto: %c4_index
  const int64_t v21 = 4;
  // pto: %c16_index
  const int64_t v22 = 16;
  // pto: %mi_rows__ssa_v0_view
  const int64_t v23 = 1;
  // pto: %mi_rows__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %mi_rows__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %mi_rows__ssa_v0_view
  int64_t v26 = (int64_t) v10;
  // pto: %mi_rows__ssa_v0_view
  int64_t v27 = v26 * v16;
  // pto: %mi_rows__ssa_v0_view
  int64_t v28 = v25 * v27;
  // pto: %mi_rows__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v29 = pto::Shape<1, 1, 1, -1, -1>(v23, v24, v25, v26, v16);
  // pto: %mi_rows__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v30 = pto::Stride<-1, -1, -1, -1, -1>(v24 * v28, v28, v27, v16, v17);
  // pto: %mi_rows__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v31 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v29, v30);
  // pto: %mi_out__ssa_v0_view
  const int64_t v32 = 1;
  // pto: %mi_out__ssa_v0_view
  const int64_t v33 = 1;
  // pto: %mi_out__ssa_v0_view
  const int64_t v34 = 1;
  // pto: %mi_out__ssa_v0_view
  int64_t v35 = (int64_t) v10;
  // pto: %mi_out__ssa_v0_view
  int64_t v36 = v35 * v16;
  // pto: %mi_out__ssa_v0_view
  int64_t v37 = v34 * v36;
  // pto: %mi_out__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v38 = pto::Shape<1, 1, 1, -1, -1>(v32, v33, v34, v35, v16);
  // pto: %mi_out__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v39 = pto::Stride<-1, -1, -1, -1, -1>(v33 * v37, v37, v36, v16, v17);
  // pto: %mi_out__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v40 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v38, v39);
  // pto: %li_rows__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %li_rows__ssa_v0_view
  const int64_t v42 = 1;
  // pto: %li_rows__ssa_v0_view
  const int64_t v43 = 1;
  // pto: %li_rows__ssa_v0_view
  int64_t v44 = (int64_t) v10;
  // pto: %li_rows__ssa_v0_view
  int64_t v45 = v44 * v16;
  // pto: %li_rows__ssa_v0_view
  int64_t v46 = v43 * v45;
  // pto: %li_rows__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v47 = pto::Shape<1, 1, 1, -1, -1>(v41, v42, v43, v44, v16);
  // pto: %li_rows__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v48 = pto::Stride<-1, -1, -1, -1, -1>(v42 * v46, v46, v45, v16, v17);
  // pto: %li_rows__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v49 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v47, v48);
  // pto: %li_out__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %li_out__ssa_v0_view
  const int64_t v51 = 1;
  // pto: %li_out__ssa_v0_view
  const int64_t v52 = 1;
  // pto: %li_out__ssa_v0_view
  int64_t v53 = (int64_t) v10;
  // pto: %li_out__ssa_v0_view
  int64_t v54 = v53 * v16;
  // pto: %li_out__ssa_v0_view
  int64_t v55 = v52 * v54;
  // pto: %li_out__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v56 = pto::Shape<1, 1, 1, -1, -1>(v50, v51, v52, v53, v16);
  // pto: %li_out__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v57 = pto::Stride<-1, -1, -1, -1, -1>(v51 * v55, v55, v54, v16, v17);
  // pto: %li_out__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v58 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v56, v57);
  // pto: %oi__ssa_v0_view
  const int64_t v59 = 1;
  // pto: %oi__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %oi__ssa_v0_view
  const int64_t v61 = 1;
  // pto: %oi__ssa_v0_view
  int64_t v62 = (int64_t) v11;
  // pto: %oi__ssa_v0_view
  int64_t v63 = v62 * v18;
  // pto: %oi__ssa_v0_view
  int64_t v64 = v61 * v63;
  // pto: %oi__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v65 = pto::Shape<1, 1, 1, -1, -1>(v59, v60, v61, v62, v18);
  // pto: %oi__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v66 = pto::Stride<-1, -1, -1, -1, -1>(v60 * v64, v64, v63, v18, v17);
  // pto: %oi__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v67 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v65, v66);
  // pto: %li__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %li__ssa_v0_view
  const int64_t v69 = 1;
  // pto: %li__ssa_v0_view
  const int64_t v70 = 1;
  // pto: %li__ssa_v0_view
  int64_t v71 = (int64_t) v11;
  // pto: %li__ssa_v0_view
  int64_t v72 = v71 * v17;
  // pto: %li__ssa_v0_view
  int64_t v73 = v70 * v72;
  // pto: %li__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v74 = pto::Shape<1, 1, 1, -1, -1>(v68, v69, v70, v71, v17);
  // pto: %li__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v75 = pto::Stride<-1, -1, -1, -1, -1>(v69 * v73, v73, v72, v17, (int64_t) v11);
  // pto: %li__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v76 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v6, v74, v75);
  // pto: %10
  int64_t v77 = (int64_t) ((uint64_t) v10 * (uint64_t) v16);
  // pto: %oi_flat__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %oi_flat__ssa_v0_view
  const int64_t v79 = 1;
  // pto: %oi_flat__ssa_v0_view
  const int64_t v80 = 1;
  // pto: %oi_flat__ssa_v0_view
  int64_t v81 = v77 * v18;
  // pto: %oi_flat__ssa_v0_view
  int64_t v82 = v80 * v81;
  // pto: %oi_flat__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v83 = pto::Shape<1, 1, 1, -1, -1>(v78, v79, v80, v77, v18);
  // pto: %oi_flat__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v84 = pto::Stride<-1, -1, -1, -1, -1>(v79 * v82, v82, v81, v18, v17);
  // pto: %oi_flat__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v85 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v83, v84);
  // pto: %heads_flat__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %heads_flat__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %heads_flat__ssa_v0_view
  const int64_t v88 = 1;
  // pto: %heads_flat__ssa_v0_view
  int64_t v89 = v77 * v18;
  // pto: %heads_flat__ssa_v0_view
  int64_t v90 = v88 * v89;
  // pto: %heads_flat__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v91 = pto::Shape<1, 1, 1, -1, -1>(v86, v87, v88, v77, v18);
  // pto: %heads_flat__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v92 = pto::Stride<-1, -1, -1, -1, -1>(v87 * v90, v90, v89, v18, v17);
  // pto: %heads_flat__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v93 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v91, v92);
  // pto: %lane__ssa_v0
  int64_t v94 = (int64_t) v12;
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  for (int64_t v95 = v94; v95 < v10; v95 += v19) {
    // pto: %t__tmp_v86
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v96 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v16);
    // pto: %t__tmp_v86
    ;
    uint64_t v97 = (uint64_t) v14;
    TASSIGN(v96, v97);
    // pto: %0
    ;
    int64_t v98 = v95 < v20 ? v20 : v95;
    // pto: %mi_rows__ssa_v0_pview
    ;
    __gm__ float* v99 = PTOAS__GLOBAL_TENSOR_DATA(v31);
    // pto: %mi_rows__ssa_v0_pview
    ;
    const int64_t v100 = 0;
    // pto: %mi_rows__ssa_v0_pview
    ;
    const int64_t v101 = 64;
    // pto: %mi_rows__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 64> v102 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %mi_rows__ssa_v0_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v103 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %mi_rows__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v104 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v99 + (v100 + v98 * v101), v102, v103);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v96, v104);
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    // pto: %mi_out__ssa_v0_pview
    ;
    __gm__ float* v105 = PTOAS__GLOBAL_TENSOR_DATA(v40);
    // pto: %mi_out__ssa_v0_pview
    ;
    const int64_t v106 = 0;
    // pto: %mi_out__ssa_v0_pview
    ;
    const int64_t v107 = 64;
    // pto: %mi_out__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 64> v108 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %mi_out__ssa_v0_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v109 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %mi_out__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v110 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v105 + (v106 + v98 * v107), v108, v109);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    TSTORE(v110, v96);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    // pto: %t__tmp_v87
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v17, v16);
    // pto: %t__tmp_v87
    ;
    uint64_t v112 = (uint64_t) v14;
    TASSIGN(v111, v112);
    // pto: %li_rows__ssa_v0_pview
    ;
    __gm__ float* v113 = PTOAS__GLOBAL_TENSOR_DATA(v49);
    // pto: %li_rows__ssa_v0_pview
    ;
    const int64_t v114 = 0;
    // pto: %li_rows__ssa_v0_pview
    ;
    const int64_t v115 = 64;
    // pto: %li_rows__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 64> v116 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %li_rows__ssa_v0_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v117 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %li_rows__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v118 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v113 + (v114 + v98 * v115), v116, v117);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    TLOAD(v111, v118);
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
    // pto: %li_out__ssa_v0_pview
    ;
    __gm__ float* v119 = PTOAS__GLOBAL_TENSOR_DATA(v58);
    // pto: %li_out__ssa_v0_pview
    ;
    const int64_t v120 = 0;
    // pto: %li_out__ssa_v0_pview
    ;
    const int64_t v121 = 64;
    // pto: %li_out__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 64> v122 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %li_out__ssa_v0_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v123 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %li_out__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v124 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v119 + (v120 + v98 * v121), v122, v123);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
    TSTORE(v124, v111);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  // pto: %4
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  for (int64_t v125 = v94; v125 < ((int64_t) ((uint64_t) v10 * (uint64_t) v21)); v125 += v19) {
    // pto: %5
    ;
    int64_t v126 = (int64_t) ((uint64_t) v125 * (uint64_t) v22);
    // pto: %value__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v18);
    // pto: %value__ssa_v0
    ;
    uint64_t v128 = (uint64_t) v14;
    TASSIGN(v127, v128);
    // pto: %6
    ;
    int64_t v129 = v126 < v20 ? v20 : v126;
    // pto: %oi__ssa_v0_pview
    ;
    __gm__ float* v130 = PTOAS__GLOBAL_TENSOR_DATA(v67);
    // pto: %oi__ssa_v0_pview
    ;
    const int64_t v131 = 0;
    // pto: %oi__ssa_v0_pview
    ;
    const int64_t v132 = 512;
    // pto: %oi__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 16, 512> v133 = pto::Shape<1, 1, 1, 16, 512>();
    // pto: %oi__ssa_v0_pview
    ;
    pto::Stride<8192, 8192, 8192, 512, 1> v134 = pto::Stride<8192, 8192, 8192, 512, 1>();
    // pto: %oi__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v135 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v130 + (v131 + v129 * v132), v133, v134);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    TLOAD(v127, v135);
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
    // pto: %denominator__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v17);
    // pto: %denominator__ssa_v0
    ;
    uint64_t v137 = (uint64_t) v15;
    TASSIGN(v136, v137);
    // pto: %li__ssa_v0_pview
    ;
    int64_t v138 = (int64_t) v11;
    // pto: %li__ssa_v0_pview
    ;
    const int64_t v139 = 0;
    // pto: %li__ssa_v0_pview
    ;
    __gm__ float* v140 = PTOAS__GLOBAL_TENSOR_DATA(v76);
    // pto: %li__ssa_v0_pview
    ;
    const int64_t v141 = 1;
    // pto: %li__ssa_v0_pview
    ;
    const int64_t v142 = 1;
    // pto: %li__ssa_v0_pview
    ;
    const int64_t v143 = 1;
    // pto: %li__ssa_v0_pview
    ;
    int64_t v144 = v22 * v17;
    // pto: %li__ssa_v0_pview
    ;
    int64_t v145 = v143 * v144;
    // pto: %li__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 16, 1> v146 = pto::Shape<1, 1, 1, 16, 1>(v141, v142, v143, v22, v17);
    // pto: %li__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v147 = pto::Stride<-1, -1, -1, -1, -1>(v142 * v145, v145, v144, v17, v138);
    // pto: %li__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v148 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v140 + (v139 + v129 * v17 + v20 * v138), v146, v147);
    TLOAD(v136, v148);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %oi_flat__ssa_v0_pview
    ;
    __gm__ float* v149 = PTOAS__GLOBAL_TENSOR_DATA(v85);
    // pto: %oi_flat__ssa_v0_pview
    ;
    const int64_t v150 = 0;
    // pto: %oi_flat__ssa_v0_pview
    ;
    const int64_t v151 = 512;
    // pto: %oi_flat__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 16, 512> v152 = pto::Shape<1, 1, 1, 16, 512>();
    // pto: %oi_flat__ssa_v0_pview
    ;
    pto::Stride<8192, 8192, 8192, 512, 1> v153 = pto::Stride<8192, 8192, 8192, 512, 1>();
    // pto: %oi_flat__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v154 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v149 + (v150 + v129 * v151), v152, v153);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
    TSTORE(v154, v127);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    // pto: %t__tmp_v88
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v18);
    // pto: %t__tmp_v88
    ;
    uint64_t v156 = (uint64_t) v14;
    TASSIGN(v155, v156);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TROWEXPANDDIV(v155, v127, v136);
    // pto: %normalized__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v18);
    // pto: %normalized__ssa_v0
    ;
    uint64_t v158 = (uint64_t) v14;
    TASSIGN(v157, v158);
    pipe_barrier(PIPE_V);
    RoundMode v159 = RoundMode::CAST_RINT;
    SaturationMode v160 = SaturationMode::ON;
    TCVT(v157, v155, v159, v160);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %heads_flat__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v161 = PTOAS__GLOBAL_TENSOR_DATA(v93);
    // pto: %heads_flat__ssa_v0_pview
    ;
    const int64_t v162 = 0;
    // pto: %heads_flat__ssa_v0_pview
    ;
    const int64_t v163 = 512;
    // pto: %heads_flat__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 16, 512> v164 = pto::Shape<1, 1, 1, 16, 512>();
    // pto: %heads_flat__ssa_v0_pview
    ;
    pto::Stride<8192, 8192, 8192, 512, 1> v165 = pto::Stride<8192, 8192, 8192, 512, 1>();
    // pto: %heads_flat__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v166 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v161 + (v162 + v129 * v163), v164, v165);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v166, v157);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}