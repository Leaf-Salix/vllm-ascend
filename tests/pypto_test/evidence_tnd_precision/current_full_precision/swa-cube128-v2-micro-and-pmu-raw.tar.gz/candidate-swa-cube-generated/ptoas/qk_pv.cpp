#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qk_pv_aic(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, __gm__ int32_t* v4, __gm__ bfloat16_t* v5, __gm__ float* v6, __gm__ bfloat16_t* v7, __gm__ float* v8, __gm__ float* v9, __gm__ float* v10, __gm__ float* v11, __gm__ int64_t* v12, __gm__ int32_t* v13, __gm__ bfloat16_t* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, __gm__ bfloat16_t* v17, __gm__ float* v18, __gm__ float* v19, __gm__ float* v20, __gm__ float* v21, __gm__ float* v22, __gm__ float* v23, int64_t v24, int64_t v25, int64_t v26, int64_t v27, int64_t v28, int64_t v29, int64_t v30, int64_t v31, int64_t v32, int32_t v33, int32_t v34) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v35 = 32;
  // pto: %c0_i64
  const int64_t v36 = 0;
  // pto: %c393216_i64
  const int64_t v37 = 393216;
  // pto: %c16384_i64
  const int64_t v38 = 16384;
  // pto: %c32768_i64
  const int64_t v39 = 32768;
  // pto: %c458752_i64
  const int64_t v40 = 458752;
  // pto: %c1_index
  const int64_t v41 = 1;
  // pto: %c512_index
  const int64_t v42 = 512;
  // pto: %c16_index
  const int64_t v43 = 16;
  // pto: %c12288_index
  const int64_t v44 = 12288;
  // pto: %c1536_index
  const int64_t v45 = 1536;
  // pto: %c64_index
  const int64_t v46 = 64;
  // pto: %c384_index
  const int64_t v47 = 384;
  // pto: %c24_index
  const int64_t v48 = 24;
  // pto: %c0_index
  const int64_t v49 = 0;
  // pto: %c2_index
  const int64_t v50 = 2;
  // pto: %c4_index
  const int64_t v51 = 4;
  // pto: %c128_index
  const int64_t v52 = 128;
  // pto: %c256_index
  const int64_t v53 = 256;
  // pto: %cn128_index
  const int64_t v54 = -128;
  // pto: %c32_index
  const int64_t v55 = 32;
  // pto: %cn32_index
  const int64_t v56 = -32;
  // pto: %c3_index
  const int64_t v57 = 3;
  // pto: %q_flat_inline48__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %q_flat_inline48__ssa_v0_view
  const int64_t v59 = 1;
  // pto: %q_flat_inline48__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %q_flat_inline48__ssa_v0_view
  int64_t v61 = (int64_t) v26;
  // pto: %q_flat_inline48__ssa_v0_view
  int64_t v62 = v61 * v42;
  // pto: %q_flat_inline48__ssa_v0_view
  int64_t v63 = v60 * v62;
  // pto: %q_flat_inline48__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v64 = pto::Shape<1, 1, 1, -1, -1>(v58, v59, v60, v61, v42);
  // pto: %q_flat_inline48__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v65 = pto::Stride<-1, -1, -1, -1, -1>(v59 * v63, v63, v62, v42, v41);
  // pto: %q_flat_inline48__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v66 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v64, v65);
  // pto: %kv_transfer_inline43__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %kv_transfer_inline43__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %kv_transfer_inline43__ssa_v0_view
  const int64_t v69 = 1;
  // pto: %kv_transfer_inline43__ssa_v0_view
  int64_t v70 = v44 * v42;
  // pto: %kv_transfer_inline43__ssa_v0_view
  int64_t v71 = v69 * v70;
  // pto: %kv_transfer_inline43__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v72 = pto::Shape<1, 1, 1, -1, -1>(v67, v68, v69, v44, v42);
  // pto: %kv_transfer_inline43__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v73 = pto::Stride<-1, -1, -1, -1, -1>(v68 * v71, v71, v70, v42, v41);
  // pto: %kv_transfer_inline43__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v74 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v72, v73);
  // pto: %score_transfer_inline64__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %score_transfer_inline64__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %score_transfer_inline64__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %score_transfer_inline64__ssa_v0_view
  int64_t v78 = v45 * v42;
  // pto: %score_transfer_inline64__ssa_v0_view
  int64_t v79 = v77 * v78;
  // pto: %score_transfer_inline64__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v80 = pto::Shape<1, 1, 1, -1, -1>(v75, v76, v77, v45, v42);
  // pto: %score_transfer_inline64__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v81 = pto::Stride<-1, -1, -1, -1, -1>(v76 * v79, v79, v78, v42, v41);
  // pto: %score_transfer_inline64__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v82 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v80, v81);
  // pto: %probability_transfer_inline132__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %probability_transfer_inline132__ssa_v0_view
  const int64_t v84 = 1;
  // pto: %probability_transfer_inline132__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %probability_transfer_inline132__ssa_v0_view
  int64_t v86 = v45 * v42;
  // pto: %probability_transfer_inline132__ssa_v0_view
  int64_t v87 = v85 * v86;
  // pto: %probability_transfer_inline132__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v88 = pto::Shape<1, 1, 1, -1, -1>(v83, v84, v85, v45, v42);
  // pto: %probability_transfer_inline132__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v89 = pto::Stride<-1, -1, -1, -1, -1>(v84 * v87, v87, v86, v42, v41);
  // pto: %probability_transfer_inline132__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v90 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v88, v89);
  // pto: %pv_transfer_inline121__ssa_v0_view
  const int64_t v91 = 1;
  // pto: %pv_transfer_inline121__ssa_v0_view
  const int64_t v92 = 1;
  // pto: %pv_transfer_inline121__ssa_v0_view
  const int64_t v93 = 1;
  // pto: %pv_transfer_inline121__ssa_v0_view
  int64_t v94 = v45 * v42;
  // pto: %pv_transfer_inline121__ssa_v0_view
  int64_t v95 = v93 * v94;
  // pto: %pv_transfer_inline121__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v96 = pto::Shape<1, 1, 1, -1, -1>(v91, v92, v93, v45, v42);
  // pto: %pv_transfer_inline121__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v97 = pto::Stride<-1, -1, -1, -1, -1>(v92 * v95, v95, v94, v42, v41);
  // pto: %pv_transfer_inline121__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v98 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v96, v97);
  // pto: %qk_l1_inline141__phi_v13
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v42);
  // pto: %qk_l1_inline141__phi_v13
  uint64_t v100 = (uint64_t) v36;
  TASSIGN(v99, v100);
  // pto: %pv_acc_inline151__phi_v4
  Tile<TileType::Acc, float, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Acc, float, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v46, v42);
  // pto: %pv_acc_inline151__phi_v4
  uint64_t v102 = (uint64_t) v36;
  TASSIGN(v101, v102);
  // pto: %qk_l1_inline141__phi_v12
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v103 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v42);
  // pto: %qk_l1_inline141__phi_v12
  uint64_t v104 = (uint64_t) v36;
  TASSIGN(v103, v104);
  // pto: %qk_l1_inline141__phi_v11
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v105 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v42);
  // pto: %qk_l1_inline141__phi_v11
  uint64_t v106 = (uint64_t) v36;
  TASSIGN(v105, v106);
  // pto: %qk_core_inline135__ssa_v0
  int64_t v107 = (int64_t) v33;
  // pto: %6
  int64_t v108 = (int64_t) ((uint64_t) v107 * (uint64_t) v42);
  // pto: %7
  int64_t v109 = (int64_t) ((uint64_t) v107 * (uint64_t) v46);
  uint64_t v110 = reinterpret_cast<uint64_t>(v1);
  set_ffts_base_addr(v110);
  // pto: %qk_l1_inline141__ssa_v0
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v42);
  // pto: %qk_l1_inline141__ssa_v0
  uint64_t v112 = (uint64_t) v36;
  TASSIGN(v111, v112);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  for (int64_t v113 = v107; v113 < v24; v113 += v48) {
    // pto: %qk_q_inline85__ssa_v0
    ;
    Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v42);
    // pto: %qk_q_inline85__ssa_v0
    ;
    uint64_t v115 = (uint64_t) v37;
    TASSIGN(v114, v115);
    // pto: %8
    ;
    int64_t v116 = (int64_t) ((uint64_t) v113 * (uint64_t) v46);
    // pto: %9
    ;
    int64_t v117 = v116 < v49 ? v49 : v116;
    // pto: %q_flat_inline48__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v118 = PTOAS__GLOBAL_TENSOR_DATA(v66);
    // pto: %q_flat_inline48__ssa_v0_pview
    ;
    const int64_t v119 = 0;
    // pto: %q_flat_inline48__ssa_v0_pview
    ;
    const int64_t v120 = 512;
    // pto: %q_flat_inline48__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 64, 512> v121 = pto::Shape<1, 1, 1, 64, 512>();
    // pto: %q_flat_inline48__ssa_v0_pview
    ;
    pto::Stride<32768, 32768, 32768, 512, 1> v122 = pto::Stride<32768, 32768, 32768, 512, 1>();
    // pto: %q_flat_inline48__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v123 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v118 + (v119 + v117 * v120), v121, v122);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v114, v123);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    for (int64_t v124 = v49; v124 < v50; v124 += v41) {
      // pto: %flat_offset_mul, %flat_offset, %t__tile
      ;
      int32_t v125 = (v4)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v113 * (uint64_t) v43) + (uint64_t) v124)];
      // pto: %10, %11
      ;
      if ((int64_t) v125 > v49) {
        int32_t v126 = (int32_t) v49;
        wait_flag_dev(v126);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        for (int64_t v127 = v49; v127 < v51; v127 += v41) {
          // pto: %12
          ;
          int64_t v128 = (int64_t) ((uint64_t) v127 * (uint64_t) v52);
          // pto: %13
          ;
          int64_t v129 = (int64_t) ((uint64_t) v127 - (uint64_t) v41);
          // pto: %14
          ;
          int64_t v130 = v129 < v49 ? v49 : v129;
          // pto: %15
          ;
          int64_t v131 = (int64_t) ((uint64_t) v130 * (uint64_t) v52);
          // pto: %gather_row_view
          ;
          Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, 128, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v132;
          // pto: %gather_row_view
          ;
          uint64_t v133 = (uint64_t) ((int64_t) (uint64_t) v131 * (uint64_t) v35);
          TASSIGN(v132, v133);
          // pto: %16
          ;
          int64_t v134 = (int64_t) ((uint64_t) v108 + (uint64_t) v128);
          // pto: %17
          ;
          int64_t v135 = v134 < v49 ? v49 : v134;
          // pto: %kv_transfer_inline43__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v136 = PTOAS__GLOBAL_TENSOR_DATA(v74);
          // pto: %kv_transfer_inline43__ssa_v0_pview
          ;
          const int64_t v137 = 0;
          // pto: %kv_transfer_inline43__ssa_v0_pview
          ;
          const int64_t v138 = 512;
          // pto: %kv_transfer_inline43__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 128, 512> v139 = pto::Shape<1, 1, 1, 128, 512>();
          // pto: %kv_transfer_inline43__ssa_v0_pview
          ;
          pto::Stride<65536, 65536, 65536, 512, 1> v140 = pto::Stride<65536, 65536, 65536, 512, 1>();
          // pto: %kv_transfer_inline43__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND> v141 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND>(v136 + (v137 + v135 * v138), v139, v140);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          TLOAD(v132, v141);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %18, %19, %20
          ;
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          if (v124 > v49 | v127 == v49) {
            // pto: %qk_l1_t_inline150__ssa_v0
            ;
            Tile<TileType::Mat, bfloat16_t, 512, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v142 = Tile<TileType::Mat, bfloat16_t, 512, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v42, v47);
            // pto: %qk_l1_t_inline150__ssa_v0
            ;
            uint64_t v143 = (uint64_t) v36;
            TASSIGN(v142, v143);
            // pto: %qk_scores_inline49__ssa_v0_l0_init
            ;
            Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v144 = Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v46, v52);
            // pto: %qk_scores_inline49__ssa_v0_l0_init
            ;
            uint64_t v145 = (uint64_t) v36;
            TASSIGN(v144, v145);
            wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
            for (int64_t v146 = v49; v146 < v42; v146 += v53) {
              // pto: %qk_scores_inline49__ssa_v0_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v52);
              // pto: %qk_scores_inline49__ssa_v0_l0_a
              ;
              uint64_t v148 = (uint64_t) v36;
              TASSIGN(v147, v148);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              pipe_barrier(PIPE_MTE1);
              uint16_t v149 = static_cast<uint16_t>(v49);
              uint16_t v150 = static_cast<uint16_t>(v146);
              TEXTRACT(v147, v114, v149, v150);
              // pto: %qk_scores_inline49__ssa_v0_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v151 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v52, v52);
              // pto: %qk_scores_inline49__ssa_v0_l0_b
              ;
              uint64_t v152 = (uint64_t) v36;
              TASSIGN(v151, v152);
              uint16_t v153 = static_cast<uint16_t>(v146);
              uint16_t v154 = static_cast<uint16_t>(v131);
              TEXTRACT(v151, v142, v153, v154);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              // pto: %0
              ;
              Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v52);
              // pto: %0
              ;
              uint64_t v156 = (uint64_t) v38;
              TASSIGN(v155, v156);
              // pto: %21
              ;
              int64_t v157 = (int64_t) ((uint64_t) v146 + (uint64_t) v52);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              uint16_t v158 = static_cast<uint16_t>(v49);
              uint16_t v159 = static_cast<uint16_t>(v157);
              TEXTRACT(v155, v114, v158, v159);
              // pto: %1
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v160 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v52, v52);
              // pto: %1
              ;
              uint64_t v161 = (uint64_t) v39;
              TASSIGN(v160, v161);
              uint16_t v162 = static_cast<uint16_t>(v157);
              uint16_t v163 = static_cast<uint16_t>(v131);
              TEXTRACT(v160, v142, v162, v163);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              // pto: %23
              ;
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              if (v146 == v49) {
                pipe_barrier(PIPE_M);
                TMATMUL(v144, v147, v151);
              } else {
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v144, v144, v147, v151);
              };
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              // pto: %24
              ;
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              if (v146 == v54) {
                pipe_barrier(PIPE_M);
                TMATMUL(v144, v155, v160);
              } else {
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v144, v144, v155, v160);
              };
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            };
            set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
            // pto: %25
            ;
            int64_t v164 = v109 < v49 ? v49 : v109;
            // pto: %26
            ;
            int64_t v165 = v128 < v49 ? v49 : v128;
            // pto: %score_transfer_inline64__ssa_v0_pview
            ;
            __gm__ float* v166 = PTOAS__GLOBAL_TENSOR_DATA(v82);
            // pto: %score_transfer_inline64__ssa_v0_pview
            ;
            const int64_t v167 = 0;
            // pto: %score_transfer_inline64__ssa_v0_pview
            ;
            const int64_t v168 = 512;
            // pto: %score_transfer_inline64__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 64, 128> v169 = pto::Shape<1, 1, 1, 64, 128>();
            // pto: %score_transfer_inline64__ssa_v0_pview
            ;
            pto::Stride<32768, 32768, 32768, 512, 1> v170 = pto::Stride<32768, 32768, 32768, 512, 1>();
            // pto: %score_transfer_inline64__ssa_v0_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v171 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v166 + (v167 + v164 * v168 + v165), v169, v170);
            wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
            pipe_barrier(PIPE_FIX);
            TSTORE(v171, v144);
            set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
          };
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        uint16_t v172 = getFFTSMsg(FFTS_MODE_VAL, v41);
        ffts_cross_core_sync(PIPE_FIX, v172);
        int32_t v173 = (int32_t) v50;
        wait_flag_dev(v173);
        // pto: %pv_acc_inline151__ssa_v0
        ;
        Tile<TileType::Acc, float, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Acc, float, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v46, v42);
        // pto: %pv_acc_inline151__ssa_v0
        ;
        uint64_t v175 = (uint64_t) v36;
        TASSIGN(v174, v175);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        for (int64_t v176 = v49; v176 < v51; v176 += v41) {
          // pto: %28
          ;
          bool v177 = v176 == v49;
          // pto: %27, %29
          ;
          if (v124 > v49 | v177) {
            // pto: %30
            ;
            int64_t v178 = (int64_t) ((uint64_t) v176 * (uint64_t) v52);
            // pto: %pv_probability_inline123__ssa_v0
            ;
            Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v52);
            // pto: %pv_probability_inline123__ssa_v0
            ;
            uint64_t v180 = (uint64_t) v40;
            TASSIGN(v179, v180);
            // pto: %31
            ;
            int64_t v181 = v109 < v49 ? v49 : v109;
            // pto: %32
            ;
            int64_t v182 = v178 < v49 ? v49 : v178;
            // pto: %probability_transfer_inline132__ssa_v0_pview
            ;
            __gm__ bfloat16_t* v183 = PTOAS__GLOBAL_TENSOR_DATA(v90);
            // pto: %probability_transfer_inline132__ssa_v0_pview
            ;
            const int64_t v184 = 0;
            // pto: %probability_transfer_inline132__ssa_v0_pview
            ;
            const int64_t v185 = 512;
            // pto: %probability_transfer_inline132__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 64, 128> v186 = pto::Shape<1, 1, 1, 64, 128>();
            // pto: %probability_transfer_inline132__ssa_v0_pview
            ;
            pto::Stride<32768, 32768, 32768, 512, 1> v187 = pto::Stride<32768, 32768, 32768, 512, 1>();
            // pto: %probability_transfer_inline132__ssa_v0_pview
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v188 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v183 + (v184 + v181 * v185 + v182), v186, v187);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            TLOAD(v179, v188);
            // pto: %33
            ;
            int64_t v189 = (int64_t) ((uint64_t) v176 - (uint64_t) v41);
            // pto: %34
            ;
            int64_t v190 = v189 < v49 ? v49 : v189;
            // pto: %35
            ;
            int64_t v191 = (int64_t) ((uint64_t) v190 * (uint64_t) v52);
            // pto: %36
            ;
            if (v176 < v50) {
              // pto: %37
              ;
              Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, 128, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v192;
              // pto: %37
              ;
              uint64_t v193 = (uint64_t) ((int64_t) (uint64_t) v191 * (uint64_t) v35);
              TASSIGN(v192, v193);
              // pto: %38
              ;
              int64_t v194 = (int64_t) ((uint64_t) v108 + (uint64_t) v178);
              // pto: %39
              ;
              int64_t v195 = v194 < v49 ? v49 : v194;
              // pto: %40
              ;
              __gm__ bfloat16_t* v196 = PTOAS__GLOBAL_TENSOR_DATA(v74);
              // pto: %40
              ;
              const int64_t v197 = 0;
              // pto: %40
              ;
              const int64_t v198 = 512;
              // pto: %40
              ;
              pto::Shape<1, 1, 1, 128, 512> v199 = pto::Shape<1, 1, 1, 128, 512>();
              // pto: %40
              ;
              pto::Stride<65536, 65536, 65536, 512, 1> v200 = pto::Stride<65536, 65536, 65536, 512, 1>();
              // pto: %40
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND> v201 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND>(v196 + (v197 + v195 * v198), v199, v200);
              TLOAD(v192, v201);
            };
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
            for (int64_t v202 = v49; v202 < v52; v202 += v46) {
              // pto: %pv_acc_inline151__ssa_v3_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 64, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v203 = Tile<TileType::Left, bfloat16_t, 64, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v55);
              // pto: %pv_acc_inline151__ssa_v3_l0_a
              ;
              uint64_t v204 = (uint64_t) v36;
              TASSIGN(v203, v204);
              pipe_barrier(PIPE_MTE1);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
              uint16_t v205 = static_cast<uint16_t>(v49);
              uint16_t v206 = static_cast<uint16_t>(v202);
              TEXTRACT(v203, v179, v205, v206);
              // pto: %pv_acc_inline151__ssa_v3_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v55, v42);
              // pto: %pv_acc_inline151__ssa_v3_l0_b
              ;
              uint64_t v208 = (uint64_t) v36;
              TASSIGN(v207, v208);
              // pto: %41
              ;
              int64_t v209 = (int64_t) ((uint64_t) v202 + (uint64_t) v191);
              uint16_t v210 = static_cast<uint16_t>(v209);
              uint16_t v211 = static_cast<uint16_t>(v49);
              TEXTRACT(v207, v105, v210, v211);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
              // pto: %3
              ;
              Tile<TileType::Left, bfloat16_t, 64, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v212 = Tile<TileType::Left, bfloat16_t, 64, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v55);
              // pto: %3
              ;
              uint64_t v213 = (uint64_t) v38;
              TASSIGN(v212, v213);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
              uint16_t v214 = static_cast<uint16_t>(v49);
              // pto: %42
              ;
              uint16_t v215 = static_cast<uint16_t>((int64_t) ((uint64_t) v202 + (uint64_t) v55));
              TEXTRACT(v212, v179, v214, v215);
              // pto: %4
              ;
              Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v55, v42);
              // pto: %4
              ;
              uint64_t v217 = (uint64_t) v39;
              TASSIGN(v216, v217);
              // pto: %44
              ;
              uint16_t v218 = static_cast<uint16_t>((int64_t) ((uint64_t) v209 + (uint64_t) v55));
              uint16_t v219 = static_cast<uint16_t>(v49);
              TEXTRACT(v216, v105, v218, v219);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
              // pto: %46, %47
              ;
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
              if (v177 & v202 == v49) {
                pipe_barrier(PIPE_M);
                TMATMUL(v174, v203, v207);
              } else {
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v174, v174, v203, v207);
              };
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
              // pto: %49, %50
              ;
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
              if (v177 & v202 == v56) {
                pipe_barrier(PIPE_M);
                TMATMUL(v174, v212, v216);
              } else {
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v174, v174, v212, v216);
              };
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
          };
        };
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        // pto: %51
        ;
        int64_t v220 = v109 < v49 ? v49 : v109;
        // pto: %pv_transfer_inline121__ssa_v0_pview
        ;
        __gm__ float* v221 = PTOAS__GLOBAL_TENSOR_DATA(v98);
        // pto: %pv_transfer_inline121__ssa_v0_pview
        ;
        const int64_t v222 = 0;
        // pto: %pv_transfer_inline121__ssa_v0_pview
        ;
        const int64_t v223 = 512;
        // pto: %pv_transfer_inline121__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 64, 512> v224 = pto::Shape<1, 1, 1, 64, 512>();
        // pto: %pv_transfer_inline121__ssa_v0_pview
        ;
        pto::Stride<32768, 32768, 32768, 512, 1> v225 = pto::Stride<32768, 32768, 32768, 512, 1>();
        // pto: %pv_transfer_inline121__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v226 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v221 + (v222 + v220 * v223), v224, v225);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        pipe_barrier(PIPE_FIX);
        TSTORE(v226, v174);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        uint16_t v227 = getFFTSMsg(FFTS_MODE_VAL, v57);
        ffts_cross_core_sync(PIPE_FIX, v227);
      };
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    uint64_t v228 = reinterpret_cast<uint64_t>(v1);
    set_ffts_base_addr(v228);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void qk_pv_aiv(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, __gm__ int32_t* v4, __gm__ bfloat16_t* v5, __gm__ float* v6, __gm__ bfloat16_t* v7, __gm__ float* v8, __gm__ float* v9, __gm__ float* v10, __gm__ float* v11, __gm__ int64_t* v12, __gm__ int32_t* v13, __gm__ bfloat16_t* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, __gm__ bfloat16_t* v17, __gm__ float* v18, __gm__ float* v19, __gm__ float* v20, __gm__ float* v21, __gm__ float* v22, __gm__ float* v23, int64_t v24, int64_t v25, int64_t v26, int64_t v27, int64_t v28, int64_t v29, int64_t v30, int64_t v31, int64_t v32, int32_t v33, int32_t v34, int32_t v35) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v36 = 1024;
  // pto: %c128_i64
  const int64_t v37 = 128;
  // pto: %c16512_i64
  const int64_t v38 = 16512;
  // pto: %c82304_i64
  const int64_t v39 = 82304;
  // pto: %c16640_i64
  const int64_t v40 = 16640;
  // pto: %c16768_i64
  const int64_t v41 = 16768;
  // pto: %c49536_i64
  const int64_t v42 = 49536;
  // pto: %c110976_i64
  const int64_t v43 = 110976;
  // pto: %c98688_i64
  const int64_t v44 = 98688;
  // pto: %c98720_i64
  const int64_t v45 = 98720;
  // pto: %c117120_i64
  const int64_t v46 = 117120;
  // pto: %c117152_i64
  const int64_t v47 = 117152;
  // pto: %c117184_i64
  const int64_t v48 = 117184;
  // pto: %c117216_i64
  const int64_t v49 = 117216;
  // pto: %c100736_i64
  const int64_t v50 = 100736;
  // pto: %c101504_i64
  const int64_t v51 = 101504;
  const int64_t v52 = 82560;
  // pto: %c102784_i64
  const int64_t v53 = 102784;
  // pto: %c106880_i64
  const int64_t v54 = 106880;
  // pto: %c107136_i64
  const int64_t v55 = 107136;
  // pto: %c104832_i64
  const int64_t v56 = 104832;
  const int64_t v57 = 82816;
  // pto: %c108928_i64
  const int64_t v58 = 108928;
  // pto: %c109184_i64
  const int64_t v59 = 109184;
  const int64_t v60 = 83072;
  const int64_t v61 = 83328;
  const int64_t v62 = 83584;
  const int64_t v63 = 83840;
  const int64_t v64 = 84096;
  // pto: %c105088_i64
  const int64_t v65 = 105088;
  // pto: %c115072_i64
  const int64_t v66 = 115072;
  // pto: %c98944_i64
  const int64_t v67 = 98944;
  // pto: %c0_i64
  const int64_t v68 = 0;
  // pto: %c1_index
  const int64_t v69 = 1;
  // pto: %c512_index
  const int64_t v70 = 512;
  // pto: %c16_index
  const int64_t v71 = 16;
  // pto: %c12288_index
  const int64_t v72 = 12288;
  // pto: %c1536_index
  const int64_t v73 = 1536;
  // pto: %c64_index
  const int64_t v74 = 64;
  // pto: %c1024_index
  const int64_t v75 = 1024;
  // pto: %c24_index
  const int64_t v76 = 24;
  // pto: %c0_index
  const int64_t v77 = 0;
  // pto: %c32_index
  const int64_t v78 = 32;
  // pto: %c8_index
  const int64_t v79 = 8;
  // pto: %cst_43
  const float v80 = 0.0f;
  // pto: %cst_44
  const float v81 = 1.0f;
  // pto: %c256_index
  const int64_t v82 = 256;
  // pto: %c2_index
  const int64_t v83 = 2;
  // pto: %c4_index
  const int64_t v84 = 4;
  // pto: %c128_index
  const int64_t v85 = 128;
  // pto: %cst_49
  const bfloat16_t v86 = 0.0f;
  // pto: %c96_index
  const int64_t v87 = 96;
  // pto: %c160_index
  const int64_t v88 = 160;
  // pto: %c384_index
  const int64_t v89 = 384;
  // pto: %cst_53
  const float v90 = 0.0441941731f;
  // pto: %c192_index
  const int64_t v91 = 192;
  // pto: %c0_i32
  const int32_t v92 = 0;
  // pto: %c320_index
  const int64_t v93 = 320;
  // pto: %c448_index
  const int64_t v94 = 448;
  // pto: %c3_index
  const int64_t v95 = 3;
  // pto: %kv_transfer_inline43__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %kv_transfer_inline43__ssa_v0_view
  const int64_t v97 = 1;
  // pto: %kv_transfer_inline43__ssa_v0_view
  const int64_t v98 = 1;
  // pto: %kv_transfer_inline43__ssa_v0_view
  int64_t v99 = v72 * v70;
  // pto: %kv_transfer_inline43__ssa_v0_view
  int64_t v100 = v98 * v99;
  // pto: %kv_transfer_inline43__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v101 = pto::Shape<1, 1, 1, -1, -1>(v96, v97, v98, v72, v70);
  // pto: %kv_transfer_inline43__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v102 = pto::Stride<-1, -1, -1, -1, -1>(v97 * v100, v100, v99, v70, v69);
  // pto: %kv_transfer_inline43__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v103 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v101, v102);
  // pto: %score_transfer_inline64__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %score_transfer_inline64__ssa_v0_view
  const int64_t v105 = 1;
  // pto: %score_transfer_inline64__ssa_v0_view
  const int64_t v106 = 1;
  // pto: %score_transfer_inline64__ssa_v0_view
  int64_t v107 = v73 * v70;
  // pto: %score_transfer_inline64__ssa_v0_view
  int64_t v108 = v106 * v107;
  // pto: %score_transfer_inline64__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v109 = pto::Shape<1, 1, 1, -1, -1>(v104, v105, v106, v73, v70);
  // pto: %score_transfer_inline64__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v110 = pto::Stride<-1, -1, -1, -1, -1>(v105 * v108, v108, v107, v70, v69);
  // pto: %score_transfer_inline64__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v111 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v109, v110);
  // pto: %probability_transfer_inline132__ssa_v0_view
  const int64_t v112 = 1;
  // pto: %probability_transfer_inline132__ssa_v0_view
  const int64_t v113 = 1;
  // pto: %probability_transfer_inline132__ssa_v0_view
  const int64_t v114 = 1;
  // pto: %probability_transfer_inline132__ssa_v0_view
  int64_t v115 = v73 * v70;
  // pto: %probability_transfer_inline132__ssa_v0_view
  int64_t v116 = v114 * v115;
  // pto: %probability_transfer_inline132__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v117 = pto::Shape<1, 1, 1, -1, -1>(v112, v113, v114, v73, v70);
  // pto: %probability_transfer_inline132__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v118 = pto::Stride<-1, -1, -1, -1, -1>(v113 * v116, v116, v115, v70, v69);
  // pto: %probability_transfer_inline132__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v119 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v117, v118);
  // pto: %pv_transfer_inline121__ssa_v0_view
  const int64_t v120 = 1;
  // pto: %pv_transfer_inline121__ssa_v0_view
  const int64_t v121 = 1;
  // pto: %pv_transfer_inline121__ssa_v0_view
  const int64_t v122 = 1;
  // pto: %pv_transfer_inline121__ssa_v0_view
  int64_t v123 = v73 * v70;
  // pto: %pv_transfer_inline121__ssa_v0_view
  int64_t v124 = v122 * v123;
  // pto: %pv_transfer_inline121__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v125 = pto::Shape<1, 1, 1, -1, -1>(v120, v121, v122, v73, v70);
  // pto: %pv_transfer_inline121__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v126 = pto::Stride<-1, -1, -1, -1, -1>(v121 * v124, v124, v123, v70, v69);
  // pto: %pv_transfer_inline121__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v127 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v125, v126);
  // pto: %attn_sink_col_inline47__ssa_v0_view
  const int64_t v128 = 1;
  // pto: %attn_sink_col_inline47__ssa_v0_view
  const int64_t v129 = 1;
  // pto: %attn_sink_col_inline47__ssa_v0_view
  const int64_t v130 = 1;
  // pto: %attn_sink_col_inline47__ssa_v0_view
  int64_t v131 = v74 * v69;
  // pto: %attn_sink_col_inline47__ssa_v0_view
  int64_t v132 = v130 * v131;
  // pto: %attn_sink_col_inline47__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v133 = pto::Shape<1, 1, 1, -1, -1>(v128, v129, v130, v74, v69);
  // pto: %attn_sink_col_inline47__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v134 = pto::Stride<-1, -1, -1, -1, -1>(v129 * v132, v132, v131, v69, v74);
  // pto: %attn_sink_col_inline47__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v135 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v9, v133, v134);
  // pto: %mi_transfer_inline131__ssa_v0_view
  const int64_t v136 = 1;
  // pto: %mi_transfer_inline131__ssa_v0_view
  const int64_t v137 = 1;
  // pto: %mi_transfer_inline131__ssa_v0_view
  const int64_t v138 = 1;
  // pto: %mi_transfer_inline131__ssa_v0_view
  int64_t v139 = v73 * v69;
  // pto: %mi_transfer_inline131__ssa_v0_view
  int64_t v140 = v138 * v139;
  // pto: %mi_transfer_inline131__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v141 = pto::Shape<1, 1, 1, -1, -1>(v136, v137, v138, v73, v69);
  // pto: %mi_transfer_inline131__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v142 = pto::Stride<-1, -1, -1, -1, -1>(v137 * v140, v140, v139, v69, v73);
  // pto: %mi_transfer_inline131__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v143 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v10, v141, v142);
  // pto: %li_transfer_inline56__ssa_v0_view
  const int64_t v144 = 1;
  // pto: %li_transfer_inline56__ssa_v0_view
  const int64_t v145 = 1;
  // pto: %li_transfer_inline56__ssa_v0_view
  const int64_t v146 = 1;
  // pto: %li_transfer_inline56__ssa_v0_view
  int64_t v147 = v73 * v69;
  // pto: %li_transfer_inline56__ssa_v0_view
  int64_t v148 = v146 * v147;
  // pto: %li_transfer_inline56__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v149 = pto::Shape<1, 1, 1, -1, -1>(v144, v145, v146, v73, v69);
  // pto: %li_transfer_inline56__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v150 = pto::Stride<-1, -1, -1, -1, -1>(v145 * v148, v148, v147, v69, v73);
  // pto: %li_transfer_inline56__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v151 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v11, v149, v150);
  // pto: %257
  int64_t v152 = (int64_t) ((uint64_t) v30 * (uint64_t) v78);
  // pto: %ori_kv_flat_inline185__ssa_v1_view
  const int64_t v153 = 1;
  // pto: %ori_kv_flat_inline185__ssa_v1_view
  const int64_t v154 = 1;
  // pto: %ori_kv_flat_inline185__ssa_v1_view
  const int64_t v155 = 1;
  // pto: %ori_kv_flat_inline185__ssa_v1_view
  int64_t v156 = v152 * v70;
  // pto: %ori_kv_flat_inline185__ssa_v1_view
  int64_t v157 = v155 * v156;
  // pto: %ori_kv_flat_inline185__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v158 = pto::Shape<1, 1, 1, -1, -1>(v153, v154, v155, v152, v70);
  // pto: %ori_kv_flat_inline185__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v159 = pto::Stride<-1, -1, -1, -1, -1>(v154 * v157, v157, v156, v70, v69);
  // pto: %ori_kv_flat_inline185__ssa_v1_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v160 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v158, v159);
  // pto: %258
  int64_t v161 = (int64_t) ((uint64_t) v32 * (uint64_t) v78);
  // pto: %cmp_kv_flat_inline125__ssa_v0_view
  const int64_t v162 = 1;
  // pto: %cmp_kv_flat_inline125__ssa_v0_view
  const int64_t v163 = 1;
  // pto: %cmp_kv_flat_inline125__ssa_v0_view
  const int64_t v164 = 1;
  // pto: %cmp_kv_flat_inline125__ssa_v0_view
  int64_t v165 = v161 * v70;
  // pto: %cmp_kv_flat_inline125__ssa_v0_view
  int64_t v166 = v164 * v165;
  // pto: %cmp_kv_flat_inline125__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v167 = pto::Shape<1, 1, 1, -1, -1>(v162, v163, v164, v161, v70);
  // pto: %cmp_kv_flat_inline125__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v168 = pto::Stride<-1, -1, -1, -1, -1>(v163 * v166, v166, v165, v70, v69);
  // pto: %cmp_kv_flat_inline125__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v169 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v17, v167, v168);
  // pto: %sparse_bias_inline97__rv_v2_view
  const int64_t v170 = 1;
  // pto: %sparse_bias_inline97__rv_v2_view
  const int64_t v171 = 1;
  // pto: %sparse_bias_inline97__rv_v2_view
  const int64_t v172 = 1;
  // pto: %sparse_bias_inline97__rv_v2_view
  int64_t v173 = (int64_t) v27;
  // pto: %sparse_bias_inline97__rv_v2_view
  int64_t v174 = v173 * v75;
  // pto: %sparse_bias_inline97__rv_v2_view
  int64_t v175 = v172 * v174;
  // pto: %sparse_bias_inline97__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v176 = pto::Shape<1, 1, 1, -1, -1>(v170, v171, v172, v173, v75);
  // pto: %sparse_bias_inline97__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v177 = pto::Stride<-1, -1, -1, -1, -1>(v171 * v175, v175, v174, v75, v69);
  // pto: %sparse_bias_inline97__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v178 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v18, v176, v177);
  // pto: %softmax_copy64_inline74__ssa_v0_view
  const int64_t v179 = 1;
  // pto: %softmax_copy64_inline74__ssa_v0_view
  const int64_t v180 = 1;
  // pto: %softmax_copy64_inline74__ssa_v0_view
  const int64_t v181 = 1;
  // pto: %softmax_copy64_inline74__ssa_v0_view
  int64_t v182 = v73 * v74;
  // pto: %softmax_copy64_inline74__ssa_v0_view
  int64_t v183 = v181 * v182;
  // pto: %softmax_copy64_inline74__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v184 = pto::Shape<1, 1, 1, -1, -1>(v179, v180, v181, v73, v74);
  // pto: %softmax_copy64_inline74__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v185 = pto::Stride<-1, -1, -1, -1, -1>(v180 * v183, v183, v182, v74, v69);
  // pto: %softmax_copy64_inline74__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v186 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v19, v184, v185);
  // pto: %alpha_transfer_inline75__ssa_v0_view
  const int64_t v187 = 1;
  // pto: %alpha_transfer_inline75__ssa_v0_view
  const int64_t v188 = 1;
  // pto: %alpha_transfer_inline75__ssa_v0_view
  const int64_t v189 = 1;
  // pto: %alpha_transfer_inline75__ssa_v0_view
  int64_t v190 = v73 * v69;
  // pto: %alpha_transfer_inline75__ssa_v0_view
  int64_t v191 = v189 * v190;
  // pto: %alpha_transfer_inline75__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v192 = pto::Shape<1, 1, 1, -1, -1>(v187, v188, v189, v73, v69);
  // pto: %alpha_transfer_inline75__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v193 = pto::Stride<-1, -1, -1, -1, -1>(v188 * v191, v191, v190, v69, v73);
  // pto: %alpha_transfer_inline75__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v194 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v20, v192, v193);
  // pto: %attn_mi_inline91__ssa_v0_view
  const int64_t v195 = 1;
  // pto: %attn_mi_inline91__ssa_v0_view
  const int64_t v196 = 1;
  // pto: %attn_mi_inline91__ssa_v0_view
  const int64_t v197 = 1;
  // pto: %attn_mi_inline91__ssa_v0_view
  int64_t v198 = (int64_t) v26;
  // pto: %attn_mi_inline91__ssa_v0_view
  int64_t v199 = v198 * v69;
  // pto: %attn_mi_inline91__ssa_v0_view
  int64_t v200 = v197 * v199;
  // pto: %attn_mi_inline91__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v201 = pto::Shape<1, 1, 1, -1, -1>(v195, v196, v197, v198, v69);
  // pto: %attn_mi_inline91__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v202 = pto::Stride<-1, -1, -1, -1, -1>(v196 * v200, v200, v199, v69, (int64_t) v26);
  // pto: %attn_mi_inline91__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v203 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v21, v201, v202);
  // pto: %attn_li_inline106__ssa_v0_view
  const int64_t v204 = 1;
  // pto: %attn_li_inline106__ssa_v0_view
  const int64_t v205 = 1;
  // pto: %attn_li_inline106__ssa_v0_view
  const int64_t v206 = 1;
  // pto: %attn_li_inline106__ssa_v0_view
  int64_t v207 = (int64_t) v26;
  // pto: %attn_li_inline106__ssa_v0_view
  int64_t v208 = v207 * v69;
  // pto: %attn_li_inline106__ssa_v0_view
  int64_t v209 = v206 * v208;
  // pto: %attn_li_inline106__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v210 = pto::Shape<1, 1, 1, -1, -1>(v204, v205, v206, v207, v69);
  // pto: %attn_li_inline106__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v211 = pto::Stride<-1, -1, -1, -1, -1>(v205 * v209, v209, v208, v69, (int64_t) v26);
  // pto: %attn_li_inline106__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v212 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v22, v210, v211);
  // pto: %attn_oi_inline71__ssa_v0_view
  const int64_t v213 = 1;
  // pto: %attn_oi_inline71__ssa_v0_view
  const int64_t v214 = 1;
  // pto: %attn_oi_inline71__ssa_v0_view
  const int64_t v215 = 1;
  // pto: %attn_oi_inline71__ssa_v0_view
  int64_t v216 = (int64_t) v26;
  // pto: %attn_oi_inline71__ssa_v0_view
  int64_t v217 = v216 * v70;
  // pto: %attn_oi_inline71__ssa_v0_view
  int64_t v218 = v215 * v217;
  // pto: %attn_oi_inline71__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v219 = pto::Shape<1, 1, 1, -1, -1>(v213, v214, v215, v216, v70);
  // pto: %attn_oi_inline71__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v220 = pto::Stride<-1, -1, -1, -1, -1>(v214 * v218, v218, v217, v70, v69);
  // pto: %attn_oi_inline71__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v221 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v23, v219, v220);
  // pto: %m_after_inline167__rv_v0
  Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v69);
  // pto: %m_after_inline167__rv_v0
  uint64_t v223 = (uint64_t) v38;
  TASSIGN(v222, v223);
  // pto: %l_after_inline162__rv_v0
  Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v69);
  // pto: %l_after_inline162__rv_v0
  uint64_t v225 = (uint64_t) v40;
  TASSIGN(v224, v225);
  // pto: %left_after_inline169__rv_v0
  Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v226 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v82);
  // pto: %left_after_inline169__rv_v0
  uint64_t v227 = (uint64_t) v41;
  TASSIGN(v226, v227);
  // pto: %right_after_inline100__rv_v0
  Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v228 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v82);
  // pto: %right_after_inline100__rv_v0
  uint64_t v229 = (uint64_t) v42;
  TASSIGN(v228, v229);
  // pto: %qk_kv_half_inline172__phi_v22
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v230 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v70);
  // pto: %qk_kv_half_inline172__phi_v22
  uint64_t v231 = (uint64_t) v39;
  TASSIGN(v230, v231);
  // pto: %qk_kv_half_inline172__phi_v3
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v70);
  // pto: %qk_kv_half_inline172__phi_v3
  uint64_t v233 = (uint64_t) v39;
  TASSIGN(v232, v233);
  // pto: %qk_kv_half_inline172__phi_v2
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v70);
  // pto: %qk_kv_half_inline172__phi_v2
  uint64_t v235 = (uint64_t) v39;
  TASSIGN(v234, v235);
  // pto: %qk_kv_half_inline172__phi_v6
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v70);
  // pto: %qk_kv_half_inline172__phi_v6
  uint64_t v237 = (uint64_t) v39;
  TASSIGN(v236, v237);
  // pto: %qk_kv_half_inline172__phi_v5
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v70);
  // pto: %qk_kv_half_inline172__phi_v5
  uint64_t v239 = (uint64_t) v39;
  TASSIGN(v238, v239);
  // pto: %qk_kv_half_inline172__phi_v9
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v240 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v70);
  // pto: %qk_kv_half_inline172__phi_v9
  uint64_t v241 = (uint64_t) v39;
  TASSIGN(v240, v241);
  // pto: %qk_kv_half_inline172__phi_v8
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v242 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v70);
  // pto: %qk_kv_half_inline172__phi_v8
  uint64_t v243 = (uint64_t) v39;
  TASSIGN(v242, v243);
  // pto: %qk_kv_half_inline172__phi_v12
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v70);
  // pto: %qk_kv_half_inline172__phi_v12
  uint64_t v245 = (uint64_t) v39;
  TASSIGN(v244, v245);
  // pto: %qk_kv_half_inline172__phi_v11
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v70);
  // pto: %qk_kv_half_inline172__phi_v11
  uint64_t v247 = (uint64_t) v39;
  TASSIGN(v246, v247);
  // pto: %qk_kv_half_inline172__phi_v15
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v248 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v70);
  // pto: %qk_kv_half_inline172__phi_v15
  uint64_t v249 = (uint64_t) v39;
  TASSIGN(v248, v249);
  // pto: %qk_kv_half_inline172__phi_v14
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v250 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v70);
  // pto: %qk_kv_half_inline172__phi_v14
  uint64_t v251 = (uint64_t) v39;
  TASSIGN(v250, v251);
  // pto: %qk_kv_half_inline172__phi_v21
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v252 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v70);
  // pto: %qk_kv_half_inline172__phi_v21
  uint64_t v253 = (uint64_t) v39;
  TASSIGN(v252, v253);
  // pto: %qk_kv_half_inline172__phi_v20
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v254 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v70);
  // pto: %qk_kv_half_inline172__phi_v20
  uint64_t v255 = (uint64_t) v39;
  TASSIGN(v254, v255);
  // pto: %qk_kv_half_inline172__phi_v19
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v256 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v70);
  // pto: %qk_kv_half_inline172__phi_v19
  uint64_t v257 = (uint64_t) v39;
  TASSIGN(v256, v257);
  // pto: %sm_scores_inline154__phi_v2
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v258 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
  // pto: %sm_scores_inline154__phi_v2
  uint64_t v259 = (uint64_t) v39;
  TASSIGN(v258, v259);
  // pto: %sm_block_sum_inline36__phi_v4
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v260 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v69);
  // pto: %sm_block_sum_inline36__phi_v4
  uint64_t v261 = (uint64_t) v49;
  TASSIGN(v260, v261);
  // pto: %sm_block_sum_inline36__phi_v3
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v262 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v69);
  // pto: %sm_block_sum_inline36__phi_v3
  uint64_t v263 = (uint64_t) v49;
  TASSIGN(v262, v263);
  // pto: %sm_fold64_inline35__phi_v4
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v264 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
  // pto: %sm_fold64_inline35__phi_v4
  uint64_t v265 = (uint64_t) v56;
  TASSIGN(v264, v265);
  // pto: %sm_fold64_inline35__phi_v3
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
  // pto: %sm_fold64_inline35__phi_v3
  uint64_t v267 = (uint64_t) v56;
  TASSIGN(v266, v267);
  // pto: %sm_fold64_inline35__phi_v8
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v268 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
  // pto: %sm_fold64_inline35__phi_v8
  uint64_t v269 = (uint64_t) v54;
  TASSIGN(v268, v269);
  // pto: %sm_fold64_inline35__phi_v7
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
  // pto: %sm_fold64_inline35__phi_v7
  uint64_t v271 = (uint64_t) v54;
  TASSIGN(v270, v271);
  // pto: %sm_fold64_inline35__phi_v12
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v272 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
  // pto: %sm_fold64_inline35__phi_v12
  uint64_t v273 = (uint64_t) v56;
  TASSIGN(v272, v273);
  // pto: %sm_fold64_inline35__phi_v11
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v274 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
  // pto: %sm_fold64_inline35__phi_v11
  uint64_t v275 = (uint64_t) v56;
  TASSIGN(v274, v275);
  // pto: %sm_fold64_inline35__phi_v16
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v276 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
  // pto: %sm_fold64_inline35__phi_v16
  uint64_t v277 = (uint64_t) v54;
  TASSIGN(v276, v277);
  // pto: %sm_fold64_inline35__phi_v15
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v278 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
  // pto: %sm_fold64_inline35__phi_v15
  uint64_t v279 = (uint64_t) v54;
  TASSIGN(v278, v279);
  // pto: %sm_fold64_inline35__phi_v20
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v280 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
  // pto: %sm_fold64_inline35__phi_v20
  uint64_t v281 = (uint64_t) v56;
  TASSIGN(v280, v281);
  // pto: %sm_fold64_inline35__phi_v19
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v282 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
  // pto: %sm_fold64_inline35__phi_v19
  uint64_t v283 = (uint64_t) v56;
  TASSIGN(v282, v283);
  // pto: %sm_fold64_inline35__phi_v24
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v284 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
  // pto: %sm_fold64_inline35__phi_v24
  uint64_t v285 = (uint64_t) v54;
  TASSIGN(v284, v285);
  // pto: %sm_fold64_inline35__phi_v23
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
  // pto: %sm_fold64_inline35__phi_v23
  uint64_t v287 = (uint64_t) v54;
  TASSIGN(v286, v287);
  // pto: %sm_fold64_inline35__phi_v28
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v288 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
  // pto: %sm_fold64_inline35__phi_v28
  uint64_t v289 = (uint64_t) v44;
  TASSIGN(v288, v289);
  // pto: %qk_core_inline135__ssa_v0
  int64_t v290 = (int64_t) v33;
  uint64_t v291 = reinterpret_cast<uint64_t>(v1);
  set_ffts_base_addr(v291);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  for (int64_t v292 = v290; v292 < v24; v292 += v76) {
    // pto: %t__tile
    ;
    int32_t v293 = (v2)[v292];
    // pto: %3
    ;
    int64_t v294 = (int64_t) v293;
    // pto: %4
    ;
    int64_t v295 = v294 < v77 ? v77 : v294;
    // pto: %qk_aiv_inline156__ssa_v0
    ;
    int64_t v296 = (int64_t) v35;
    uint64_t v297 = reinterpret_cast<uint64_t>(v1);
    set_ffts_base_addr(v297);
    // pto: %5
    ;
    int64_t v298 = (int64_t) ((uint64_t) v296 * (uint64_t) v78);
    // pto: %qk_reduce_tmp_inline159__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %qk_reduce_tmp_inline159__ssa_v0
    ;
    uint64_t v300 = (uint64_t) v37;
    TASSIGN(v299, v300);
    // pto: %running_m_inline93__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v69);
    // pto: %running_m_inline93__ssa_v0
    ;
    uint64_t v302 = (uint64_t) v38;
    TASSIGN(v301, v302);
    // pto: %7
    ;
    int64_t v303 = v298 < v77 ? v77 : v298;
    // pto: %attn_sink_col_inline47__ssa_v0_pview
    ;
    __gm__ float* v304 = PTOAS__GLOBAL_TENSOR_DATA(v135);
    // pto: %attn_sink_col_inline47__ssa_v0_pview
    ;
    const int64_t v305 = 0;
    // pto: %attn_sink_col_inline47__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 1> v306 = pto::Shape<1, 1, 1, 32, 1>();
    // pto: %attn_sink_col_inline47__ssa_v0_pview
    ;
    pto::Stride<32, 32, 32, 1, 64> v307 = pto::Stride<32, 32, 32, 1, 64>();
    // pto: %attn_sink_col_inline47__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 64>, pto::Layout::DN> v308 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 64>, pto::Layout::DN>(v304 + (v305 + v303), v306, v307);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v301, v308);
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %t__rm_a0_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v78);
    // pto: %t__rm_a0_tmp_v0
    ;
    uint64_t v310 = (uint64_t) v38;
    TASSIGN(v309, v310);
    // pto: %t__row_major_tmp_v1
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v78);
    // pto: %t__row_major_tmp_v1
    ;
    uint64_t v312 = (uint64_t) v39;
    TASSIGN(v311, v312);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    TMULS(v311, v309, v80);
    // pto: %t__tmp_v43
    ;
    Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v69);
    // pto: %t__tmp_v43
    ;
    uint64_t v314 = (uint64_t) v39;
    TASSIGN(v313, v314);
    // pto: %running_l_inline171__rm_a0_tmp_v2
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v78);
    // pto: %running_l_inline171__rm_a0_tmp_v2
    ;
    uint64_t v316 = (uint64_t) v39;
    TASSIGN(v315, v316);
    // pto: %running_l_inline171__row_major_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v78);
    // pto: %running_l_inline171__row_major_tmp_v3
    ;
    uint64_t v318 = (uint64_t) v40;
    TASSIGN(v317, v318);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    TADDS(v317, v315, v81);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %running_l_inline171__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v319 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v69);
    // pto: %running_l_inline171__ssa_v0
    ;
    uint64_t v320 = (uint64_t) v40;
    TASSIGN(v319, v320);
    // pto: %running_left_inline143__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v82);
    // pto: %running_left_inline143__ssa_v0
    ;
    uint64_t v322 = (uint64_t) v41;
    TASSIGN(v321, v322);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    TEXPANDS(v321, v80);
    // pto: %running_right_inline163__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v323 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v82);
    // pto: %running_right_inline163__ssa_v0
    ;
    uint64_t v324 = (uint64_t) v42;
    TASSIGN(v323, v324);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    TEXPANDS(v323, v80);
    // pto: %2, %8
    ;
    int64_t v325 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v290 * (uint64_t) v74) + (uint64_t) v298);
    // pto: %9
    ;
    int64_t v326 = v325 < v77 ? v77 : v325;
    // pto: %mi_transfer_inline131__ssa_v0_pview
    ;
    __gm__ float* v327 = PTOAS__GLOBAL_TENSOR_DATA(v143);
    // pto: %mi_transfer_inline131__ssa_v0_pview
    ;
    const int64_t v328 = 0;
    // pto: %mi_transfer_inline131__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 1> v329 = pto::Shape<1, 1, 1, 32, 1>();
    // pto: %mi_transfer_inline131__ssa_v0_pview
    ;
    pto::Stride<32, 32, 32, 1, 1536> v330 = pto::Stride<32, 32, 32, 1, 1536>();
    // pto: %mi_transfer_inline131__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN> v331 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN>(v327 + (v328 + v326), v329, v330);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    TSTORE(v331, v301);
    // pto: %li_transfer_inline56__ssa_v0_pview
    ;
    __gm__ float* v332 = PTOAS__GLOBAL_TENSOR_DATA(v151);
    // pto: %li_transfer_inline56__ssa_v0_pview
    ;
    const int64_t v333 = 0;
    // pto: %li_transfer_inline56__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 1> v334 = pto::Shape<1, 1, 1, 32, 1>();
    // pto: %li_transfer_inline56__ssa_v0_pview
    ;
    pto::Stride<32, 32, 32, 1, 1536> v335 = pto::Stride<32, 32, 32, 1, 1536>();
    // pto: %li_transfer_inline56__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN> v336 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN>(v332 + (v333 + v326), v334, v335);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v336, v319);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    for (int64_t v337 = v77; v337 < v83; v337 += v69) {
      // pto: %flat_offset_mul, %flat_offset, %12
      ;
      int32_t v338 = (v4)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v292 * (uint64_t) v71) + (uint64_t) v337)];
      // pto: %13, %14
      ;
      if ((int64_t) v338 > v77) {
        for (int64_t v339 = v77; v339 < v84; v339 += v69) {
          // pto: %15, %16, %6
          ;
          int64_t v340 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v339 * (uint64_t) v85) + (uint64_t) ((int64_t) (uint64_t) v296 * (uint64_t) v74));
          // pto: %0
          ;
          Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v341 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v70);
          // pto: %0
          ;
          uint64_t v342 = (uint64_t) v39;
          TASSIGN(v341, v342);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
          TEXPANDS(v341, v86);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          // pto: %17
          ;
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          if (v337 == v77) {
            // pto: %18
            ;
            int64_t v343 = (v12)[v292];
            // pto: %22
            ;
            int64_t v344 = (int64_t) ((uint64_t) v343 + (uint64_t) v69);
            // pto: %23
            ;
            int64_t v345 = v344 < v85 ? v344 : v85;
            // pto: %24, %25
            ;
            int64_t v346 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v343 - (uint64_t) v345) + (uint64_t) v69);
            // pto: %26
            ;
            int64_t v347 = v346 % v78;
            // pto: %27
            ;
            int64_t v348 = (int64_t) ((uint64_t) v345 - (uint64_t) v340);
            // pto: %28
            ;
            int64_t v349 = v348 < v77 ? v77 : v348;
            // pto: %29
            ;
            int64_t v350 = v349 < v74 ? v349 : v74;
            // pto: %30, %31
            ;
            int64_t v351 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v78 - (uint64_t) v347) - (uint64_t) v340);
            // pto: %32
            ;
            int64_t v352 = v351 < v350 ? v351 : v350;
            // pto: %33
            ;
            if (v352 > v77) {
              // pto: %34
              ;
              int64_t v353 = (int64_t) ((uint64_t) v346 + (uint64_t) v340);
              // pto: %37, %38, %36, %qk_raw_page_inline108__tile
              ;
              int32_t v354 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v295 * (uint64_t) v29) + (uint64_t) (v353 / v78))];
              // pto: %39
              ;
              int64_t v355 = (int64_t) v354;
              // pto: %40
              ;
              if (v355 >= v77) {
                // pto: %42, %44, %43
                ;
                int64_t v356 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v355 * (uint64_t) v78) + (uint64_t) (v353 % v78));
                // pto: %gather_row_view
                ;
                Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v357 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v352);
                // pto: %gather_row_view
                ;
                uint64_t v358 = (uint64_t) v39;
                TASSIGN(v357, v358);
                // pto: %46
                ;
                int64_t v359 = v356 < v77 ? v77 : v356;
                // pto: %ori_kv_flat_inline185__ssa_v1_pview
                ;
                const int64_t v360 = 0;
                // pto: %ori_kv_flat_inline185__ssa_v1_pview
                ;
                __gm__ bfloat16_t* v361 = PTOAS__GLOBAL_TENSOR_DATA(v160);
                // pto: %ori_kv_flat_inline185__ssa_v1_pview
                ;
                const int64_t v362 = 1;
                // pto: %ori_kv_flat_inline185__ssa_v1_pview
                ;
                const int64_t v363 = 1;
                // pto: %ori_kv_flat_inline185__ssa_v1_pview
                ;
                const int64_t v364 = 1;
                // pto: %ori_kv_flat_inline185__ssa_v1_pview
                ;
                int64_t v365 = v352 * v70;
                // pto: %ori_kv_flat_inline185__ssa_v1_pview
                ;
                int64_t v366 = v364 * v365;
                // pto: %ori_kv_flat_inline185__ssa_v1_pview
                ;
                pto::Shape<1, 1, 1, -1, 512> v367 = pto::Shape<1, 1, 1, -1, 512>(v362, v363, v364, v352, v70);
                // pto: %ori_kv_flat_inline185__ssa_v1_pview
                ;
                pto::Stride<-1, -1, -1, -1, -1> v368 = pto::Stride<-1, -1, -1, -1, -1>(v363 * v366, v366, v365, v70, v69);
                // pto: %ori_kv_flat_inline185__ssa_v1_pview
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v369 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v361 + (v360 + v359 * v70 + v77 * v69), v367, v368);
                TLOAD(v357, v369);
              };
            };
            // pto: %49
            ;
            int64_t v370 = v351 < v77 ? v77 : v351;
            // pto: %50, %51
            ;
            int64_t v371 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v74 - (uint64_t) v347) - (uint64_t) v340);
            // pto: %52
            ;
            int64_t v372 = v371 < v350 ? v371 : v350;
            // pto: %53
            ;
            if (v370 < v372) {
              // pto: %54, %55
              ;
              int64_t v373 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v346 + (uint64_t) v340) + (uint64_t) v370);
              // pto: %58, %59, %57, %56
              ;
              int32_t v374 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v295 * (uint64_t) v29) + (uint64_t) (v373 / v78))];
              // pto: %60
              ;
              int64_t v375 = (int64_t) v374;
              // pto: %61
              ;
              if (v375 >= v77) {
                // pto: %63, %65, %64
                ;
                int64_t v376 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v375 * (uint64_t) v78) + (uint64_t) (v373 % v78));
                // pto: %66
                ;
                int64_t v377 = (int64_t) ((uint64_t) v372 - (uint64_t) v370);
                // pto: %67
                ;
                Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v378 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v377);
                // pto: %67
                ;
                uint64_t v379 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v370 * (uint64_t) v36) + (uint64_t) v39);
                TASSIGN(v378, v379);
                // pto: %68
                ;
                int64_t v380 = v376 < v77 ? v77 : v376;
                // pto: %69
                ;
                const int64_t v381 = 0;
                // pto: %69
                ;
                __gm__ bfloat16_t* v382 = PTOAS__GLOBAL_TENSOR_DATA(v160);
                // pto: %69
                ;
                const int64_t v383 = 1;
                // pto: %69
                ;
                const int64_t v384 = 1;
                // pto: %69
                ;
                const int64_t v385 = 1;
                // pto: %69
                ;
                int64_t v386 = v377 * v70;
                // pto: %69
                ;
                int64_t v387 = v385 * v386;
                // pto: %69
                ;
                pto::Shape<1, 1, 1, -1, 512> v388 = pto::Shape<1, 1, 1, -1, 512>(v383, v384, v385, v377, v70);
                // pto: %69
                ;
                pto::Stride<-1, -1, -1, -1, -1> v389 = pto::Stride<-1, -1, -1, -1, -1>(v384 * v387, v387, v386, v70, v69);
                // pto: %69
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v390 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v382 + (v381 + v380 * v70 + v77 * v69), v388, v389);
                TLOAD(v378, v390);
              };
            };
            // pto: %72
            ;
            int64_t v391 = v371 < v77 ? v77 : v371;
            // pto: %73, %74
            ;
            int64_t v392 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v87 - (uint64_t) v347) - (uint64_t) v340);
            // pto: %75
            ;
            int64_t v393 = v392 < v350 ? v392 : v350;
            // pto: %76
            ;
            if (v391 < v393) {
              // pto: %77, %78
              ;
              int64_t v394 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v346 + (uint64_t) v340) + (uint64_t) v391);
              // pto: %81, %82, %80, %79
              ;
              int32_t v395 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v295 * (uint64_t) v29) + (uint64_t) (v394 / v78))];
              // pto: %83
              ;
              int64_t v396 = (int64_t) v395;
              // pto: %84
              ;
              if (v396 >= v77) {
                // pto: %86, %88, %87
                ;
                int64_t v397 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v396 * (uint64_t) v78) + (uint64_t) (v394 % v78));
                // pto: %89
                ;
                int64_t v398 = (int64_t) ((uint64_t) v393 - (uint64_t) v391);
                // pto: %90
                ;
                Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v399 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v398);
                // pto: %90
                ;
                uint64_t v400 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v391 * (uint64_t) v36) + (uint64_t) v39);
                TASSIGN(v399, v400);
                // pto: %91
                ;
                int64_t v401 = v397 < v77 ? v77 : v397;
                // pto: %92
                ;
                const int64_t v402 = 0;
                // pto: %92
                ;
                __gm__ bfloat16_t* v403 = PTOAS__GLOBAL_TENSOR_DATA(v160);
                // pto: %92
                ;
                const int64_t v404 = 1;
                // pto: %92
                ;
                const int64_t v405 = 1;
                // pto: %92
                ;
                const int64_t v406 = 1;
                // pto: %92
                ;
                int64_t v407 = v398 * v70;
                // pto: %92
                ;
                int64_t v408 = v406 * v407;
                // pto: %92
                ;
                pto::Shape<1, 1, 1, -1, 512> v409 = pto::Shape<1, 1, 1, -1, 512>(v404, v405, v406, v398, v70);
                // pto: %92
                ;
                pto::Stride<-1, -1, -1, -1, -1> v410 = pto::Stride<-1, -1, -1, -1, -1>(v405 * v408, v408, v407, v70, v69);
                // pto: %92
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v411 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v403 + (v402 + v401 * v70 + v77 * v69), v409, v410);
                TLOAD(v399, v411);
              };
            };
            // pto: %95
            ;
            int64_t v412 = v392 < v77 ? v77 : v392;
            // pto: %96, %97
            ;
            int64_t v413 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v85 - (uint64_t) v347) - (uint64_t) v340);
            // pto: %98
            ;
            int64_t v414 = v413 < v350 ? v413 : v350;
            // pto: %99
            ;
            if (v412 < v414) {
              // pto: %100, %101
              ;
              int64_t v415 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v346 + (uint64_t) v340) + (uint64_t) v412);
              // pto: %104, %105, %103, %102
              ;
              int32_t v416 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v295 * (uint64_t) v29) + (uint64_t) (v415 / v78))];
              // pto: %106
              ;
              int64_t v417 = (int64_t) v416;
              // pto: %107
              ;
              if (v417 >= v77) {
                // pto: %109, %111, %110
                ;
                int64_t v418 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v417 * (uint64_t) v78) + (uint64_t) (v415 % v78));
                // pto: %112
                ;
                int64_t v419 = (int64_t) ((uint64_t) v414 - (uint64_t) v412);
                // pto: %113
                ;
                Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v420 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v419);
                // pto: %113
                ;
                uint64_t v421 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v412 * (uint64_t) v36) + (uint64_t) v39);
                TASSIGN(v420, v421);
                // pto: %114
                ;
                int64_t v422 = v418 < v77 ? v77 : v418;
                // pto: %115
                ;
                const int64_t v423 = 0;
                // pto: %115
                ;
                __gm__ bfloat16_t* v424 = PTOAS__GLOBAL_TENSOR_DATA(v160);
                // pto: %115
                ;
                const int64_t v425 = 1;
                // pto: %115
                ;
                const int64_t v426 = 1;
                // pto: %115
                ;
                const int64_t v427 = 1;
                // pto: %115
                ;
                int64_t v428 = v419 * v70;
                // pto: %115
                ;
                int64_t v429 = v427 * v428;
                // pto: %115
                ;
                pto::Shape<1, 1, 1, -1, 512> v430 = pto::Shape<1, 1, 1, -1, 512>(v425, v426, v427, v419, v70);
                // pto: %115
                ;
                pto::Stride<-1, -1, -1, -1, -1> v431 = pto::Stride<-1, -1, -1, -1, -1>(v426 * v429, v429, v428, v70, v69);
                // pto: %115
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v432 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v424 + (v423 + v422 * v70 + v77 * v69), v430, v431);
                TLOAD(v420, v432);
              };
            };
            // pto: %118
            ;
            int64_t v433 = v413 < v77 ? v77 : v413;
            // pto: %119, %120
            ;
            int64_t v434 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v88 - (uint64_t) v347) - (uint64_t) v340);
            // pto: %121
            ;
            int64_t v435 = v434 < v350 ? v434 : v350;
            // pto: %122
            ;
            if (v433 < v435) {
              // pto: %123, %124
              ;
              int64_t v436 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v346 + (uint64_t) v340) + (uint64_t) v433);
              // pto: %127, %128, %126, %125
              ;
              int32_t v437 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v295 * (uint64_t) v29) + (uint64_t) (v436 / v78))];
              // pto: %129
              ;
              int64_t v438 = (int64_t) v437;
              // pto: %130
              ;
              if (v438 >= v77) {
                // pto: %132, %134, %133
                ;
                int64_t v439 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v438 * (uint64_t) v78) + (uint64_t) (v436 % v78));
                // pto: %135
                ;
                int64_t v440 = (int64_t) ((uint64_t) v435 - (uint64_t) v433);
                // pto: %136
                ;
                Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v441 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v440);
                // pto: %136
                ;
                uint64_t v442 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v433 * (uint64_t) v36) + (uint64_t) v39);
                TASSIGN(v441, v442);
                // pto: %137
                ;
                int64_t v443 = v439 < v77 ? v77 : v439;
                // pto: %138
                ;
                const int64_t v444 = 0;
                // pto: %138
                ;
                __gm__ bfloat16_t* v445 = PTOAS__GLOBAL_TENSOR_DATA(v160);
                // pto: %138
                ;
                const int64_t v446 = 1;
                // pto: %138
                ;
                const int64_t v447 = 1;
                // pto: %138
                ;
                const int64_t v448 = 1;
                // pto: %138
                ;
                int64_t v449 = v440 * v70;
                // pto: %138
                ;
                int64_t v450 = v448 * v449;
                // pto: %138
                ;
                pto::Shape<1, 1, 1, -1, 512> v451 = pto::Shape<1, 1, 1, -1, 512>(v446, v447, v448, v440, v70);
                // pto: %138
                ;
                pto::Stride<-1, -1, -1, -1, -1> v452 = pto::Stride<-1, -1, -1, -1, -1>(v447 * v450, v450, v449, v70, v69);
                // pto: %138
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v453 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v445 + (v444 + v443 * v70 + v77 * v69), v451, v452);
                TLOAD(v441, v453);
              };
            };
          } else {
            pipe_barrier(PIPE_V);
            TEXPANDS(v341, v86);
            set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
            wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
            for (int64_t v454 = v77; v454 < v74; v454 += v69) {
              // pto: %139, %140, %141, %142
              ;
              int64_t v455 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v337 - (uint64_t) v69) * (uint64_t) v70) + (uint64_t) v340) + (uint64_t) v454);
              // pto: %143
              ;
              if (v455 < v70) {
                // pto: %144, %145, %qk_ridx_inline118__tile
                ;
                int32_t v456 = (v15)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v292 * (uint64_t) v70) + (uint64_t) v455)];
                // pto: %146
                ;
                int64_t v457 = (int64_t) v456;
                // pto: %147
                ;
                if (v457 >= v77) {
                  // pto: %151, %152, %150, %148
                  ;
                  int32_t v458 = (v16)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v295 * (uint64_t) v31) + (uint64_t) (v457 / v78))];
                  // pto: %153
                  ;
                  int64_t v459 = (int64_t) v458;
                  // pto: %154
                  ;
                  if (v459 >= v77) {
                    // pto: %155, %158, %157
                    ;
                    int64_t v460 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v459 * (uint64_t) v78) + (uint64_t) (v457 % v78));
                    // pto: %159
                    ;
                    Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v461;
                    // pto: %159
                    ;
                    uint64_t v462 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v454 * (uint64_t) v36) + (uint64_t) v39);
                    TASSIGN(v461, v462);
                    // pto: %160
                    ;
                    int64_t v463 = v460 < v77 ? v77 : v460;
                    // pto: %cmp_kv_flat_inline125__ssa_v0_pview
                    ;
                    __gm__ bfloat16_t* v464 = PTOAS__GLOBAL_TENSOR_DATA(v169);
                    // pto: %cmp_kv_flat_inline125__ssa_v0_pview
                    ;
                    const int64_t v465 = 0;
                    // pto: %cmp_kv_flat_inline125__ssa_v0_pview
                    ;
                    const int64_t v466 = 512;
                    // pto: %cmp_kv_flat_inline125__ssa_v0_pview
                    ;
                    pto::Shape<1, 1, 1, 1, 512> v467 = pto::Shape<1, 1, 1, 1, 512>();
                    // pto: %cmp_kv_flat_inline125__ssa_v0_pview
                    ;
                    pto::Stride<512, 512, 512, 512, 1> v468 = pto::Stride<512, 512, 512, 512, 1>();
                    // pto: %cmp_kv_flat_inline125__ssa_v0_pview
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v469 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v464 + (v465 + v463 * v466), v467, v468);
                    TLOAD(v461, v469);
                  };
                };
              };
            };
          };
          set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
          // pto: %1, %161
          ;
          int64_t v470 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v290 * (uint64_t) v70) + (uint64_t) v340);
          // pto: %162
          ;
          int64_t v471 = v470 < v77 ? v77 : v470;
          // pto: %kv_transfer_inline43__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v472 = PTOAS__GLOBAL_TENSOR_DATA(v103);
          // pto: %kv_transfer_inline43__ssa_v0_pview
          ;
          const int64_t v473 = 0;
          // pto: %kv_transfer_inline43__ssa_v0_pview
          ;
          const int64_t v474 = 512;
          // pto: %kv_transfer_inline43__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 64, 512> v475 = pto::Shape<1, 1, 1, 64, 512>();
          // pto: %kv_transfer_inline43__ssa_v0_pview
          ;
          pto::Stride<32768, 32768, 32768, 512, 1> v476 = pto::Stride<32768, 32768, 32768, 512, 1>();
          // pto: %kv_transfer_inline43__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v477 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v472 + (v473 + v471 * v474), v475, v476);
          wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
          TSTORE(v477, v230);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        };
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
        uint16_t v478 = getFFTSMsg(FFTS_MODE_VAL, v77);
        ffts_cross_core_sync(PIPE_MTE3, v478);
        int32_t v479 = (int32_t) v69;
        wait_flag_dev(v479);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
        for (int64_t v480 = v77; v480 < v84; v480 += v69) {
          // pto: %165, %163
          ;
          int64_t v481 = (int64_t) ((uint64_t) v325 + (uint64_t) ((int64_t) (uint64_t) v480 * (uint64_t) v79));
          // pto: %166
          ;
          bool v482 = v337 == v77;
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          if (v482) {
            // pto: %sm_live_scores_inline157__ssa_v0
            ;
            Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v483 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v85);
            // pto: %sm_live_scores_inline157__ssa_v0
            ;
            uint64_t v484 = (uint64_t) v43;
            TASSIGN(v483, v484);
            // pto: %167
            ;
            int64_t v485 = v481 < v77 ? v77 : v481;
            // pto: %score_transfer_inline64__ssa_v0_pview
            ;
            __gm__ float* v486 = PTOAS__GLOBAL_TENSOR_DATA(v111);
            // pto: %score_transfer_inline64__ssa_v0_pview
            ;
            const int64_t v487 = 0;
            // pto: %score_transfer_inline64__ssa_v0_pview
            ;
            const int64_t v488 = 512;
            // pto: %score_transfer_inline64__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 8, 128> v489 = pto::Shape<1, 1, 1, 8, 128>();
            // pto: %score_transfer_inline64__ssa_v0_pview
            ;
            pto::Stride<4096, 4096, 4096, 512, 1> v490 = pto::Stride<4096, 4096, 4096, 512, 1>();
            // pto: %score_transfer_inline64__ssa_v0_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND> v491 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND>(v486 + (v487 + v485 * v488), v489, v490);
            TLOAD(v483, v491);
            set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
            // pto: %t__tmp_v47
            ;
            Tile<TileType::Vec, float, 8, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v492 = Tile<TileType::Vec, float, 8, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v89);
            // pto: %t__tmp_v47
            ;
            uint64_t v493 = (uint64_t) v44;
            TASSIGN(v492, v493);
            pipe_barrier(PIPE_V);
            TEXPANDS(v492, v80);
            // pto: %sm_scores_inline154__ssa_v0
            ;
            Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v494 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
            // pto: %sm_scores_inline154__ssa_v0
            ;
            uint64_t v495 = (uint64_t) v39;
            TASSIGN(v494, v495);
            pipe_barrier(PIPE_V);
            wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
            TCONCAT(v494, v483, v492);
          } else {
            // pto: %sm_scores_inline154__ssa_v1
            ;
            Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v496 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
            // pto: %sm_scores_inline154__ssa_v1
            ;
            uint64_t v497 = (uint64_t) v39;
            TASSIGN(v496, v497);
            // pto: %168
            ;
            int64_t v498 = v481 < v77 ? v77 : v481;
            // pto: %169
            ;
            __gm__ float* v499 = PTOAS__GLOBAL_TENSOR_DATA(v111);
            // pto: %169
            ;
            const int64_t v500 = 0;
            // pto: %169
            ;
            const int64_t v501 = 512;
            // pto: %169
            ;
            pto::Shape<1, 1, 1, 8, 512> v502 = pto::Shape<1, 1, 1, 8, 512>();
            // pto: %169
            ;
            pto::Stride<4096, 4096, 4096, 512, 1> v503 = pto::Stride<4096, 4096, 4096, 512, 1>();
            // pto: %169
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND> v504 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND>(v499 + (v500 + v498 * v501), v502, v503);
            TLOAD(v496, v504);
          };
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          // pto: %sm_bias_inline82__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v505 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v70);
          // pto: %sm_bias_inline82__ssa_v0
          ;
          uint64_t v506 = (uint64_t) v44;
          TASSIGN(v505, v506);
          // pto: %170
          ;
          int64_t v507 = v292 < v77 ? v77 : v292;
          // pto: %171
          ;
          int64_t v508 = (int64_t) ((uint64_t) v337 * (uint64_t) v70);
          // pto: %172
          ;
          int64_t v509 = v508 < v77 ? v77 : v508;
          // pto: %sparse_bias_inline97__rv_v2_pview
          ;
          __gm__ float* v510 = PTOAS__GLOBAL_TENSOR_DATA(v178);
          // pto: %sparse_bias_inline97__rv_v2_pview
          ;
          const int64_t v511 = 0;
          // pto: %sparse_bias_inline97__rv_v2_pview
          ;
          const int64_t v512 = 1024;
          // pto: %sparse_bias_inline97__rv_v2_pview
          ;
          pto::Shape<1, 1, 1, 1, 512> v513 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %sparse_bias_inline97__rv_v2_pview
          ;
          pto::Stride<1024, 1024, 1024, 1024, 1> v514 = pto::Stride<1024, 1024, 1024, 1024, 1>();
          // pto: %sparse_bias_inline97__rv_v2_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v515 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v510 + (v511 + v507 * v512 + v509), v513, v514);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
          TLOAD(v505, v515);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          // pto: %t__tmp_v48
          ;
          Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v516 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
          // pto: %t__tmp_v48
          ;
          uint64_t v517 = (uint64_t) v39;
          TASSIGN(v516, v517);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          TMULS(v516, v258, v90);
          // pto: %sm_masked_inline66__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v518 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
          // pto: %sm_masked_inline66__ssa_v0
          ;
          uint64_t v519 = (uint64_t) v39;
          TASSIGN(v518, v519);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          TCOLEXPANDADD(v518, v516, v505);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
          // pto: %sm_block_max_inline42__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v520 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v69);
          // pto: %sm_block_max_inline42__ssa_v0
          ;
          uint64_t v521 = (uint64_t) v44;
          TASSIGN(v520, v521);
          pipe_barrier(PIPE_V);
          TROWMAX(v520, v518, v299);
          // pto: %sm_old_m_inline40__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v522 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v69);
          // pto: %sm_old_m_inline40__ssa_v0
          ;
          uint64_t v523 = (uint64_t) v45;
          TASSIGN(v522, v523);
          // pto: %173
          ;
          int64_t v524 = v481 < v77 ? v77 : v481;
          // pto: %174
          ;
          __gm__ float* v525 = PTOAS__GLOBAL_TENSOR_DATA(v143);
          // pto: %174
          ;
          const int64_t v526 = 0;
          // pto: %174
          ;
          pto::Shape<1, 1, 1, 8, 1> v527 = pto::Shape<1, 1, 1, 8, 1>();
          // pto: %174
          ;
          pto::Stride<8, 8, 8, 1, 1536> v528 = pto::Stride<8, 8, 8, 1, 1536>();
          // pto: %174
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN> v529 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN>(v525 + (v526 + v524), v527, v528);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
          TLOAD(v522, v529);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
          // pto: %sm_old_l_inline39__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v530 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v69);
          // pto: %sm_old_l_inline39__ssa_v0
          ;
          uint64_t v531 = (uint64_t) v46;
          TASSIGN(v530, v531);
          // pto: %176
          ;
          __gm__ float* v532 = PTOAS__GLOBAL_TENSOR_DATA(v151);
          // pto: %176
          ;
          const int64_t v533 = 0;
          // pto: %176
          ;
          pto::Shape<1, 1, 1, 8, 1> v534 = pto::Shape<1, 1, 1, 8, 1>();
          // pto: %176
          ;
          pto::Stride<8, 8, 8, 1, 1536> v535 = pto::Stride<8, 8, 8, 1, 1536>();
          // pto: %176
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN> v536 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN>(v532 + (v533 + v524), v534, v535);
          TLOAD(v530, v536);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
          // pto: %sm_max_inline164__rm_a0_tmp_v4
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v537 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v79);
          // pto: %sm_max_inline164__rm_a0_tmp_v4
          ;
          uint64_t v538 = (uint64_t) v45;
          TASSIGN(v537, v538);
          // pto: %sm_max_inline164__rm_a1_tmp_v5
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v539 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v79);
          // pto: %sm_max_inline164__rm_a1_tmp_v5
          ;
          uint64_t v540 = (uint64_t) v44;
          TASSIGN(v539, v540);
          // pto: %sm_max_inline164__row_major_tmp_v6
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v541 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v79);
          // pto: %sm_max_inline164__row_major_tmp_v6
          ;
          uint64_t v542 = (uint64_t) v47;
          TASSIGN(v541, v542);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
          pipe_barrier(PIPE_V);
          TMAX(v541, v537, v539);
          // pto: %sm_max_inline164__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v543 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v69);
          // pto: %sm_max_inline164__ssa_v0
          ;
          uint64_t v544 = (uint64_t) v47;
          TASSIGN(v543, v544);
          // pto: %t__rm_a0_tmp_v7
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v545 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v79);
          // pto: %t__rm_a0_tmp_v7
          ;
          uint64_t v546 = (uint64_t) v45;
          TASSIGN(v545, v546);
          // pto: %t__rm_a1_tmp_v8
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v547 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v79);
          // pto: %t__rm_a1_tmp_v8
          ;
          uint64_t v548 = (uint64_t) v47;
          TASSIGN(v547, v548);
          // pto: %t__row_major_tmp_v9
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v549 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v79);
          // pto: %t__row_major_tmp_v9
          ;
          uint64_t v550 = (uint64_t) v44;
          TASSIGN(v549, v550);
          pipe_barrier(PIPE_V);
          TSUB(v549, v545, v547);
          // pto: %t__tmp_v49
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v551 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v69);
          // pto: %t__tmp_v49
          ;
          uint64_t v552 = (uint64_t) v44;
          TASSIGN(v551, v552);
          // pto: %sm_alpha_inline38__rm_a0_tmp_v10
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v553 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v79);
          // pto: %sm_alpha_inline38__rm_a0_tmp_v10
          ;
          uint64_t v554 = (uint64_t) v44;
          TASSIGN(v553, v554);
          // pto: %sm_alpha_inline38__row_major_tmp_v11
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v555 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v79);
          // pto: %sm_alpha_inline38__row_major_tmp_v11
          ;
          uint64_t v556 = (uint64_t) v48;
          TASSIGN(v555, v556);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
          TEXP(v555, v553);
          // pto: %sm_alpha_inline38__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v557 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v69);
          // pto: %sm_alpha_inline38__ssa_v0
          ;
          uint64_t v558 = (uint64_t) v48;
          TASSIGN(v557, v558);
          // pto: %t__tmp_v50
          ;
          Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v559 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
          // pto: %t__tmp_v50
          ;
          uint64_t v560 = (uint64_t) v39;
          TASSIGN(v559, v560);
          TROWEXPANDSUB(v559, v518, v543);
          // pto: %sm_exp_inline120__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v561 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
          // pto: %sm_exp_inline120__ssa_v0
          ;
          uint64_t v562 = (uint64_t) v39;
          TASSIGN(v561, v562);
          pipe_barrier(PIPE_V);
          TEXP(v561, v559);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          // pto: %177
          ;
          int64_t v563 = (v12)[v292];
          // pto: %sm_key_count_inline139__phi_v2
          ;
          int64_t v564;
          if (v482) {
            // pto: %182
            ;
            int64_t v565 = (int64_t) ((uint64_t) v563 + (uint64_t) v69);
            // pto: %183
            ;
            v564 = v565 < v85 ? v565 : v85;
          } else {
            // pto: %184, %185
            ;
            int64_t v566 = (int64_t) ((uint64_t) v563 + (uint64_t) v69) / v84;
            // pto: %186
            ;
            v564 = v566 < v70 ? v566 : v70;
          };
          // pto: %187
          ;
          bool v567 = v564 < v74;
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          if (v567) {
            // pto: %sm_short_inline46__ssa_v0
            ;
            Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v568 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v564);
            // pto: %sm_short_inline46__ssa_v0
            ;
            uint64_t v569 = (uint64_t) v39;
            TASSIGN(v568, v569);
            // pto: %slice_view
            ;
            Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v570 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v564);
            // pto: %slice_view
            ;
            uint64_t v571 = (uint64_t) v39;
            TASSIGN(v570, v571);
            // pto: %t__tmp_v52
            ;
            Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v572 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
            // pto: %t__tmp_v52
            ;
            uint64_t v573 = (uint64_t) v44;
            TASSIGN(v572, v573);
            // pto: %sm_block_sum_inline36__ssa_v0
            ;
            Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v574 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v69);
            // pto: %sm_block_sum_inline36__ssa_v0
            ;
            uint64_t v575 = (uint64_t) v49;
            TASSIGN(v574, v575);
            pipe_barrier(PIPE_V);
            TROWSUM(v574, v570, v572);
          } else {
            // pto: %188
            ;
            bool v576 = v564 < v70;
            if (v576) {
              // pto: %t__tmp_v53
              ;
              Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v577 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
              // pto: %t__tmp_v53
              ;
              uint64_t v578 = (uint64_t) v44;
              TASSIGN(v577, v578);
              TEXPANDS(v577, v80);
              // pto: %t__ci_tmp_v0
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v579 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v91);
              // pto: %t__ci_tmp_v0
              ;
              uint64_t v580 = (uint64_t) v50;
              TASSIGN(v579, v580);
              // pto: %t__tmp_v54
              ;
              Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v581 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v74);
              // pto: %t__tmp_v54
              ;
              uint64_t v582 = (uint64_t) v51;
              TASSIGN(v581, v582);
              // pto: %ci_tmp_view
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v583;
              TRESHAPE(v583, v579);
              // pto: %ci_dst_view
              ;
              Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v584;
              TRESHAPE(v584, v581);
              TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v584, v92, v583);
              // pto: %t__tmp_v55
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v585 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v74);
              // pto: %t__tmp_v55
              ;
              uint64_t v586 = (uint64_t) v50;
              TASSIGN(v585, v586);
              pipe_barrier(PIPE_V);
              RoundMode v587 = RoundMode::CAST_ROUND;
              SaturationMode v588 = SaturationMode::ON;
              TCVT(v585, v581, v587, v588);
              // pto: %sm_columns_inline44__ssa_v0
              ;
              Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v589 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
              // pto: %sm_columns_inline44__ssa_v0
              ;
              uint64_t v590 = (uint64_t) v44;
              TASSIGN(v589, v590);
              pipe_barrier(PIPE_V);
              TCOLEXPANDADD(v589, v577, v585);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
              // pto: %t__tmp_v56
              ;
              Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v591 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
              // pto: %t__tmp_v56
              ;
              uint64_t v592 = (uint64_t) v39;
              TASSIGN(v591, v592);
              // pto: %189
              ;
              Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v593;
              // pto: %189
              ;
              uint64_t v594 = (uint64_t) v39;
              TASSIGN(v593, v594);
              // pto: %softmax_copy64_inline74__ssa_v0_pview
              ;
              __gm__ float* v595 = PTOAS__GLOBAL_TENSOR_DATA(v186);
              // pto: %softmax_copy64_inline74__ssa_v0_pview
              ;
              const int64_t v596 = 0;
              // pto: %softmax_copy64_inline74__ssa_v0_pview
              ;
              const int64_t v597 = 64;
              // pto: %softmax_copy64_inline74__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 8, 64> v598 = pto::Shape<1, 1, 1, 8, 64>();
              // pto: %softmax_copy64_inline74__ssa_v0_pview
              ;
              pto::Stride<512, 512, 512, 64, 1> v599 = pto::Stride<512, 512, 512, 64, 1>();
              // pto: %softmax_copy64_inline74__ssa_v0_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v600 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v595 + (v596 + v524 * v597), v598, v599);
              TSTORE(v600, v593);
              set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
              // pto: %sm_fold64_inline35__ssa_v0
              ;
              Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v601 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
              // pto: %sm_fold64_inline35__ssa_v0
              ;
              uint64_t v602 = (uint64_t) v50;
              TASSIGN(v601, v602);
              wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
              TLOAD(v601, v600);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
              // pto: %193
              ;
              bool v603 = v564 > v74;
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
              if (v603) {
                // pto: %t__tmp_v57
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v604 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %t__tmp_v57
                ;
                uint64_t v605 = (uint64_t) v52;
                TASSIGN(v604, v605);
                // pto: %194
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v606;
                // pto: %194
                ;
                uint64_t v607 = (uint64_t) v52;
                TASSIGN(v606, v607);
                // pto: %sm_added_inline160__ssa_v0
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v608 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %sm_added_inline160__ssa_v0
                ;
                uint64_t v609 = (uint64_t) v53;
                TASSIGN(v608, v609);
                TADD(v608, v601, v606);
                // pto: %195
                ;
                bool v610 = v564 < v85;
                if (v610) {
                  // pto: %196
                  ;
                  uint64_t v611 = (uint64_t) v564;
                  // pto: %196, %197, %198
                  ;
                  float v612 = (float) ((int32_t) (int64_t) (v611 - (uint64_t) v74));
                  // pto: %sm_tail_mask_inline31__ssa_v0
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v613 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
                  // pto: %sm_tail_mask_inline31__ssa_v0
                  ;
                  uint64_t v614 = (uint64_t) v54;
                  TASSIGN(v613, v614);
                  CmpMode v615 = CmpMode::LT;
                  TCMPS(v613, v589, v612, v615);
                  // pto: %t__tmp_v58
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v616 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v71);
                  // pto: %t__tmp_v58
                  ;
                  uint64_t v617 = (uint64_t) v55;
                  TASSIGN(v616, v617);
                  // pto: %sm_fold64_inline35__ssa_v1
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v618 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                  // pto: %sm_fold64_inline35__ssa_v1
                  ;
                  uint64_t v619 = (uint64_t) v56;
                  TASSIGN(v618, v619);
                  pipe_barrier(PIPE_V);
                  TSEL(v618, v613, v608, v601, v616);
                } else {
                  // pto: %sm_fold64_inline35__ssa_v2
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v620 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                  // pto: %sm_fold64_inline35__ssa_v2
                  ;
                  uint64_t v621 = (uint64_t) v53;
                  TASSIGN(v620, v621);
                  // pto: %sm_fold64_inline35__ssa_v2_mv
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v622 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                  // pto: %sm_fold64_inline35__ssa_v2_mv
                  ;
                  uint64_t v623 = (uint64_t) v56;
                  TASSIGN(v622, v623);
                  pipe_barrier(PIPE_V);
                  TMOV(v622, v620);
                };
              } else {
                // pto: %sm_fold64_inline35__ssa_v0_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v624 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %sm_fold64_inline35__ssa_v0_mv
                ;
                uint64_t v625 = (uint64_t) v56;
                TASSIGN(v624, v625);
                TMOV(v624, v601);
              };
              // pto: %199
              ;
              bool v626 = v564 > v85;
              if (v626) {
                // pto: %t__tmp_v59
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v627 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %t__tmp_v59
                ;
                uint64_t v628 = (uint64_t) v57;
                TASSIGN(v627, v628);
                // pto: %200
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v629;
                // pto: %200
                ;
                uint64_t v630 = (uint64_t) v57;
                TASSIGN(v629, v630);
                // pto: %sm_added_inline160__ssa_v1
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v631 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %sm_added_inline160__ssa_v1
                ;
                uint64_t v632 = (uint64_t) v50;
                TASSIGN(v631, v632);
                pipe_barrier(PIPE_V);
                TADD(v631, v264, v629);
                // pto: %201
                ;
                bool v633 = v564 < v91;
                if (v633) {
                  // pto: %202
                  ;
                  uint64_t v634 = (uint64_t) v564;
                  // pto: %202, %203, %204
                  ;
                  float v635 = (float) ((int32_t) (int64_t) (v634 - (uint64_t) v85));
                  // pto: %sm_tail_mask_inline31__ssa_v1
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v636 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
                  // pto: %sm_tail_mask_inline31__ssa_v1
                  ;
                  uint64_t v637 = (uint64_t) v58;
                  TASSIGN(v636, v637);
                  CmpMode v638 = CmpMode::LT;
                  TCMPS(v636, v589, v635, v638);
                  // pto: %t__tmp_v60
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v639 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v71);
                  // pto: %t__tmp_v60
                  ;
                  uint64_t v640 = (uint64_t) v59;
                  TASSIGN(v639, v640);
                  // pto: %sm_fold64_inline35__ssa_v5
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v641 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                  // pto: %sm_fold64_inline35__ssa_v5
                  ;
                  uint64_t v642 = (uint64_t) v54;
                  TASSIGN(v641, v642);
                  pipe_barrier(PIPE_V);
                  TSEL(v641, v636, v631, v264, v639);
                } else {
                  // pto: %sm_fold64_inline35__ssa_v6
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v643 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                  // pto: %sm_fold64_inline35__ssa_v6
                  ;
                  uint64_t v644 = (uint64_t) v50;
                  TASSIGN(v643, v644);
                  // pto: %sm_fold64_inline35__ssa_v6_mv
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v645 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                  // pto: %sm_fold64_inline35__ssa_v6_mv
                  ;
                  uint64_t v646 = (uint64_t) v54;
                  TASSIGN(v645, v646);
                  pipe_barrier(PIPE_V);
                  TMOV(v645, v643);
                };
              } else {
                // pto: %sm_fold64_inline35__phi_v4_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v647 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %sm_fold64_inline35__phi_v4_mv
                ;
                uint64_t v648 = (uint64_t) v54;
                TASSIGN(v647, v648);
                pipe_barrier(PIPE_V);
                TMOV(v647, v264);
              };
              // pto: %205
              ;
              bool v649 = v564 > v91;
              if (v649) {
                // pto: %t__tmp_v61
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v650 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %t__tmp_v61
                ;
                uint64_t v651 = (uint64_t) v60;
                TASSIGN(v650, v651);
                // pto: %206
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v652;
                // pto: %206
                ;
                uint64_t v653 = (uint64_t) v60;
                TASSIGN(v652, v653);
                // pto: %sm_added_inline160__ssa_v2
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v654 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %sm_added_inline160__ssa_v2
                ;
                uint64_t v655 = (uint64_t) v53;
                TASSIGN(v654, v655);
                pipe_barrier(PIPE_V);
                TADD(v654, v268, v652);
                // pto: %207
                ;
                bool v656 = v564 < v82;
                if (v656) {
                  // pto: %208
                  ;
                  uint64_t v657 = (uint64_t) v564;
                  // pto: %208, %209, %210
                  ;
                  float v658 = (float) ((int32_t) (int64_t) (v657 - (uint64_t) v91));
                  // pto: %sm_tail_mask_inline31__ssa_v2
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v659 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
                  // pto: %sm_tail_mask_inline31__ssa_v2
                  ;
                  uint64_t v660 = (uint64_t) v58;
                  TASSIGN(v659, v660);
                  CmpMode v661 = CmpMode::LT;
                  TCMPS(v659, v589, v658, v661);
                  // pto: %t__tmp_v62
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v662 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v71);
                  // pto: %t__tmp_v62
                  ;
                  uint64_t v663 = (uint64_t) v59;
                  TASSIGN(v662, v663);
                  // pto: %sm_fold64_inline35__ssa_v9
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v664 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                  // pto: %sm_fold64_inline35__ssa_v9
                  ;
                  uint64_t v665 = (uint64_t) v56;
                  TASSIGN(v664, v665);
                  pipe_barrier(PIPE_V);
                  TSEL(v664, v659, v654, v268, v662);
                } else {
                  // pto: %sm_fold64_inline35__ssa_v10
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v666 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                  // pto: %sm_fold64_inline35__ssa_v10
                  ;
                  uint64_t v667 = (uint64_t) v53;
                  TASSIGN(v666, v667);
                  // pto: %sm_fold64_inline35__ssa_v10_mv
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v668 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                  // pto: %sm_fold64_inline35__ssa_v10_mv
                  ;
                  uint64_t v669 = (uint64_t) v56;
                  TASSIGN(v668, v669);
                  pipe_barrier(PIPE_V);
                  TMOV(v668, v666);
                };
              } else {
                // pto: %sm_fold64_inline35__phi_v8_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v670 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %sm_fold64_inline35__phi_v8_mv
                ;
                uint64_t v671 = (uint64_t) v56;
                TASSIGN(v670, v671);
                pipe_barrier(PIPE_V);
                TMOV(v670, v268);
              };
              // pto: %211
              ;
              bool v672 = v564 > v82;
              if (v672) {
                // pto: %t__tmp_v63
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v673 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %t__tmp_v63
                ;
                uint64_t v674 = (uint64_t) v61;
                TASSIGN(v673, v674);
                // pto: %212
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v675;
                // pto: %212
                ;
                uint64_t v676 = (uint64_t) v61;
                TASSIGN(v675, v676);
                // pto: %sm_added_inline160__ssa_v3
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v677 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %sm_added_inline160__ssa_v3
                ;
                uint64_t v678 = (uint64_t) v50;
                TASSIGN(v677, v678);
                pipe_barrier(PIPE_V);
                TADD(v677, v272, v675);
                // pto: %213
                ;
                bool v679 = v564 < v93;
                if (v679) {
                  // pto: %214
                  ;
                  uint64_t v680 = (uint64_t) v564;
                  // pto: %214, %215, %216
                  ;
                  float v681 = (float) ((int32_t) (int64_t) (v680 - (uint64_t) v82));
                  // pto: %sm_tail_mask_inline31__ssa_v3
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v682 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
                  // pto: %sm_tail_mask_inline31__ssa_v3
                  ;
                  uint64_t v683 = (uint64_t) v58;
                  TASSIGN(v682, v683);
                  CmpMode v684 = CmpMode::LT;
                  TCMPS(v682, v589, v681, v684);
                  // pto: %t__tmp_v64
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v685 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v71);
                  // pto: %t__tmp_v64
                  ;
                  uint64_t v686 = (uint64_t) v59;
                  TASSIGN(v685, v686);
                  // pto: %sm_fold64_inline35__ssa_v13
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v687 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                  // pto: %sm_fold64_inline35__ssa_v13
                  ;
                  uint64_t v688 = (uint64_t) v54;
                  TASSIGN(v687, v688);
                  pipe_barrier(PIPE_V);
                  TSEL(v687, v682, v677, v272, v685);
                } else {
                  // pto: %sm_fold64_inline35__ssa_v14
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v689 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                  // pto: %sm_fold64_inline35__ssa_v14
                  ;
                  uint64_t v690 = (uint64_t) v50;
                  TASSIGN(v689, v690);
                  // pto: %sm_fold64_inline35__ssa_v14_mv
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v691 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                  // pto: %sm_fold64_inline35__ssa_v14_mv
                  ;
                  uint64_t v692 = (uint64_t) v54;
                  TASSIGN(v691, v692);
                  pipe_barrier(PIPE_V);
                  TMOV(v691, v689);
                };
              } else {
                // pto: %sm_fold64_inline35__phi_v12_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v693 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %sm_fold64_inline35__phi_v12_mv
                ;
                uint64_t v694 = (uint64_t) v54;
                TASSIGN(v693, v694);
                pipe_barrier(PIPE_V);
                TMOV(v693, v272);
              };
              // pto: %217
              ;
              bool v695 = v564 > v93;
              if (v695) {
                // pto: %t__tmp_v65
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v696 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %t__tmp_v65
                ;
                uint64_t v697 = (uint64_t) v62;
                TASSIGN(v696, v697);
                // pto: %218
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v698;
                // pto: %218
                ;
                uint64_t v699 = (uint64_t) v62;
                TASSIGN(v698, v699);
                // pto: %sm_added_inline160__ssa_v4
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v700 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %sm_added_inline160__ssa_v4
                ;
                uint64_t v701 = (uint64_t) v53;
                TASSIGN(v700, v701);
                pipe_barrier(PIPE_V);
                TADD(v700, v276, v698);
                // pto: %219
                ;
                bool v702 = v564 < v89;
                if (v702) {
                  // pto: %220
                  ;
                  uint64_t v703 = (uint64_t) v564;
                  // pto: %220, %221, %222
                  ;
                  float v704 = (float) ((int32_t) (int64_t) (v703 - (uint64_t) v93));
                  // pto: %sm_tail_mask_inline31__ssa_v4
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v705 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
                  // pto: %sm_tail_mask_inline31__ssa_v4
                  ;
                  uint64_t v706 = (uint64_t) v58;
                  TASSIGN(v705, v706);
                  CmpMode v707 = CmpMode::LT;
                  TCMPS(v705, v589, v704, v707);
                  // pto: %t__tmp_v66
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v708 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v71);
                  // pto: %t__tmp_v66
                  ;
                  uint64_t v709 = (uint64_t) v59;
                  TASSIGN(v708, v709);
                  // pto: %sm_fold64_inline35__ssa_v17
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v710 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                  // pto: %sm_fold64_inline35__ssa_v17
                  ;
                  uint64_t v711 = (uint64_t) v56;
                  TASSIGN(v710, v711);
                  pipe_barrier(PIPE_V);
                  TSEL(v710, v705, v700, v276, v708);
                } else {
                  // pto: %sm_fold64_inline35__ssa_v18
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v712 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                  // pto: %sm_fold64_inline35__ssa_v18
                  ;
                  uint64_t v713 = (uint64_t) v53;
                  TASSIGN(v712, v713);
                  // pto: %sm_fold64_inline35__ssa_v18_mv
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v714 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                  // pto: %sm_fold64_inline35__ssa_v18_mv
                  ;
                  uint64_t v715 = (uint64_t) v56;
                  TASSIGN(v714, v715);
                  pipe_barrier(PIPE_V);
                  TMOV(v714, v712);
                };
              } else {
                // pto: %sm_fold64_inline35__phi_v16_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v716 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %sm_fold64_inline35__phi_v16_mv
                ;
                uint64_t v717 = (uint64_t) v56;
                TASSIGN(v716, v717);
                pipe_barrier(PIPE_V);
                TMOV(v716, v276);
              };
              // pto: %223
              ;
              bool v718 = v564 > v89;
              if (v718) {
                // pto: %t__tmp_v67
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v719 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %t__tmp_v67
                ;
                uint64_t v720 = (uint64_t) v63;
                TASSIGN(v719, v720);
                // pto: %224
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v721;
                // pto: %224
                ;
                uint64_t v722 = (uint64_t) v63;
                TASSIGN(v721, v722);
                // pto: %sm_added_inline160__ssa_v5
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v723 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %sm_added_inline160__ssa_v5
                ;
                uint64_t v724 = (uint64_t) v50;
                TASSIGN(v723, v724);
                pipe_barrier(PIPE_V);
                TADD(v723, v280, v721);
                // pto: %225
                ;
                bool v725 = v564 < v94;
                if (v725) {
                  // pto: %226
                  ;
                  uint64_t v726 = (uint64_t) v564;
                  // pto: %226, %227, %228
                  ;
                  float v727 = (float) ((int32_t) (int64_t) (v726 - (uint64_t) v89));
                  // pto: %sm_tail_mask_inline31__ssa_v5
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v728 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
                  // pto: %sm_tail_mask_inline31__ssa_v5
                  ;
                  uint64_t v729 = (uint64_t) v58;
                  TASSIGN(v728, v729);
                  CmpMode v730 = CmpMode::LT;
                  TCMPS(v728, v589, v727, v730);
                  // pto: %t__tmp_v68
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v731 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v71);
                  // pto: %t__tmp_v68
                  ;
                  uint64_t v732 = (uint64_t) v59;
                  TASSIGN(v731, v732);
                  // pto: %sm_fold64_inline35__ssa_v21
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v733 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                  // pto: %sm_fold64_inline35__ssa_v21
                  ;
                  uint64_t v734 = (uint64_t) v54;
                  TASSIGN(v733, v734);
                  pipe_barrier(PIPE_V);
                  TSEL(v733, v728, v723, v280, v731);
                } else {
                  // pto: %sm_fold64_inline35__ssa_v22
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v735 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                  // pto: %sm_fold64_inline35__ssa_v22
                  ;
                  uint64_t v736 = (uint64_t) v50;
                  TASSIGN(v735, v736);
                  // pto: %sm_fold64_inline35__ssa_v22_mv
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v737 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                  // pto: %sm_fold64_inline35__ssa_v22_mv
                  ;
                  uint64_t v738 = (uint64_t) v54;
                  TASSIGN(v737, v738);
                  pipe_barrier(PIPE_V);
                  TMOV(v737, v735);
                };
              } else {
                // pto: %sm_fold64_inline35__phi_v20_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v739 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %sm_fold64_inline35__phi_v20_mv
                ;
                uint64_t v740 = (uint64_t) v54;
                TASSIGN(v739, v740);
                pipe_barrier(PIPE_V);
                TMOV(v739, v280);
              };
              // pto: %229
              ;
              bool v741 = v564 > v94;
              if (v741) {
                // pto: %t__tmp_v69
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v742 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %t__tmp_v69
                ;
                uint64_t v743 = (uint64_t) v64;
                TASSIGN(v742, v743);
                // pto: %230
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v744;
                // pto: %230
                ;
                uint64_t v745 = (uint64_t) v64;
                TASSIGN(v744, v745);
                // pto: %sm_added_inline160__ssa_v6
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v746 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %sm_added_inline160__ssa_v6
                ;
                uint64_t v747 = (uint64_t) v53;
                TASSIGN(v746, v747);
                pipe_barrier(PIPE_V);
                TADD(v746, v284, v744);
                // pto: %231
                ;
                uint64_t v748 = (uint64_t) v564;
                // pto: %231, %232, %233
                ;
                float v749 = (float) ((int32_t) (int64_t) (v748 - (uint64_t) v94));
                // pto: %sm_tail_mask_inline31__ssa_v6
                ;
                Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v750 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
                // pto: %sm_tail_mask_inline31__ssa_v6
                ;
                uint64_t v751 = (uint64_t) v56;
                TASSIGN(v750, v751);
                CmpMode v752 = CmpMode::LT;
                TCMPS(v750, v589, v749, v752);
                // pto: %t__tmp_v70
                ;
                Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v753 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v71);
                // pto: %t__tmp_v70
                ;
                uint64_t v754 = (uint64_t) v65;
                TASSIGN(v753, v754);
                // pto: %sm_fold64_inline35__ssa_v25
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v755 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %sm_fold64_inline35__ssa_v25
                ;
                uint64_t v756 = (uint64_t) v44;
                TASSIGN(v755, v756);
                pipe_barrier(PIPE_V);
                TSEL(v755, v750, v746, v284, v753);
              } else {
                // pto: %sm_fold64_inline35__phi_v24_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v757 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v74);
                // pto: %sm_fold64_inline35__phi_v24_mv
                ;
                uint64_t v758 = (uint64_t) v44;
                TASSIGN(v757, v758);
                pipe_barrier(PIPE_V);
                TMOV(v757, v284);
              };
              // pto: %sm_groups64_inline30__ssa_v0
              ;
              Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v759 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v79);
              // pto: %sm_groups64_inline30__ssa_v0
              ;
              uint64_t v760 = (uint64_t) v44;
              TASSIGN(v759, v760);
              // pto: %t__tmp_v71
              ;
              Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v761 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v79);
              // pto: %t__tmp_v71
              ;
              uint64_t v762 = (uint64_t) v50;
              TASSIGN(v761, v762);
              // pto: %sm_sum8_inline173__ssa_v0
              ;
              Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v763 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v69);
              // pto: %sm_sum8_inline173__ssa_v0
              ;
              uint64_t v764 = (uint64_t) v53;
              TASSIGN(v763, v764);
              pipe_barrier(PIPE_V);
              TROWSUM(v763, v759, v761);
              // pto: %sm_final8_inline29__ssa_v0
              ;
              Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v765 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
              // pto: %sm_final8_inline29__ssa_v0
              ;
              uint64_t v766 = (uint64_t) v53;
              TASSIGN(v765, v766);
              // pto: %t__tmp_v72
              ;
              Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v767 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
              // pto: %t__tmp_v72
              ;
              uint64_t v768 = (uint64_t) v44;
              TASSIGN(v767, v768);
              // pto: %sm_block_sum_inline36__ssa_v1
              ;
              Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v769 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v69);
              // pto: %sm_block_sum_inline36__ssa_v1
              ;
              uint64_t v770 = (uint64_t) v49;
              TASSIGN(v769, v770);
              pipe_barrier(PIPE_V);
              TROWSUM(v769, v765, v767);
            } else {
              // pto: %sm_groups8_inline63__ssa_v0
              ;
              Tile<TileType::Vec, float, 512, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v771 = Tile<TileType::Vec, float, 512, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
              // pto: %sm_groups8_inline63__ssa_v0
              ;
              uint64_t v772 = (uint64_t) v39;
              TASSIGN(v771, v772);
              // pto: %t__tmp_v73
              ;
              Tile<TileType::Vec, float, 512, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v773 = Tile<TileType::Vec, float, 512, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
              // pto: %t__tmp_v73
              ;
              uint64_t v774 = (uint64_t) v44;
              TASSIGN(v773, v774);
              // pto: %sm_sum64_inline79__ssa_v0
              ;
              Tile<TileType::Vec, float, 512, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v775 = Tile<TileType::Vec, float, 512, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v69);
              // pto: %sm_sum64_inline79__ssa_v0
              ;
              uint64_t v776 = (uint64_t) v66;
              TASSIGN(v775, v776);
              pipe_barrier(PIPE_V);
              TROWSUM(v775, v771, v773);
              // pto: %sm_groups64_inline30__ssa_v1
              ;
              Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v777 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v79);
              // pto: %sm_groups64_inline30__ssa_v1
              ;
              uint64_t v778 = (uint64_t) v66;
              TASSIGN(v777, v778);
              // pto: %t__tmp_v74
              ;
              Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v779 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v79);
              // pto: %t__tmp_v74
              ;
              uint64_t v780 = (uint64_t) v44;
              TASSIGN(v779, v780);
              // pto: %sm_sum8_inline173__ssa_v1
              ;
              Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v781 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v74, v69);
              // pto: %sm_sum8_inline173__ssa_v1
              ;
              uint64_t v782 = (uint64_t) v50;
              TASSIGN(v781, v782);
              pipe_barrier(PIPE_V);
              TROWSUM(v781, v777, v779);
              // pto: %sm_final8_inline29__ssa_v1
              ;
              Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v783 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
              // pto: %sm_final8_inline29__ssa_v1
              ;
              uint64_t v784 = (uint64_t) v50;
              TASSIGN(v783, v784);
              // pto: %t__tmp_v75
              ;
              Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v785 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
              // pto: %t__tmp_v75
              ;
              uint64_t v786 = (uint64_t) v44;
              TASSIGN(v785, v786);
              // pto: %sm_block_sum_inline36__ssa_v2
              ;
              Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v787 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v69);
              // pto: %sm_block_sum_inline36__ssa_v2
              ;
              uint64_t v788 = (uint64_t) v67;
              TASSIGN(v787, v788);
              pipe_barrier(PIPE_V);
              TROWSUM(v787, v783, v785);
              // pto: %sm_block_sum_inline36__ssa_v2_mv
              ;
              Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v789 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v69);
              // pto: %sm_block_sum_inline36__ssa_v2_mv
              ;
              uint64_t v790 = (uint64_t) v49;
              TASSIGN(v789, v790);
              pipe_barrier(PIPE_V);
              TMOV(v789, v787);
            };
          };
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
          // pto: %t__rm_a0_tmp_v12
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v791 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v79);
          // pto: %t__rm_a0_tmp_v12
          ;
          uint64_t v792 = (uint64_t) v46;
          TASSIGN(v791, v792);
          // pto: %t__rm_a1_tmp_v13
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v793 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v79);
          // pto: %t__rm_a1_tmp_v13
          ;
          uint64_t v794 = (uint64_t) v48;
          TASSIGN(v793, v794);
          // pto: %t__row_major_tmp_v14
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v795 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v79);
          // pto: %t__row_major_tmp_v14
          ;
          uint64_t v796 = (uint64_t) v44;
          TASSIGN(v795, v796);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
          TMUL(v795, v791, v793);
          // pto: %t__tmp_v76
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v797 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v69);
          // pto: %t__tmp_v76
          ;
          uint64_t v798 = (uint64_t) v44;
          TASSIGN(v797, v798);
          // pto: %sm_sum_inline32__rm_a0_tmp_v15
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v799 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v79);
          // pto: %sm_sum_inline32__rm_a0_tmp_v15
          ;
          uint64_t v800 = (uint64_t) v44;
          TASSIGN(v799, v800);
          // pto: %sm_sum_inline32__rm_a1_tmp_v16
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v801 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v79);
          // pto: %sm_sum_inline32__rm_a1_tmp_v16
          ;
          uint64_t v802 = (uint64_t) v49;
          TASSIGN(v801, v802);
          // pto: %sm_sum_inline32__row_major_tmp_v17
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v803 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v69, v79);
          // pto: %sm_sum_inline32__row_major_tmp_v17
          ;
          uint64_t v804 = (uint64_t) v44;
          TASSIGN(v803, v804);
          pipe_barrier(PIPE_V);
          TADD(v803, v799, v801);
          // pto: %sm_sum_inline32__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v805 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v69);
          // pto: %sm_sum_inline32__ssa_v0
          ;
          uint64_t v806 = (uint64_t) v44;
          TASSIGN(v805, v806);
          // pto: %sm_probability_inline28__ssa_v0
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v807 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
          // pto: %sm_probability_inline28__ssa_v0
          ;
          uint64_t v808 = (uint64_t) v39;
          TASSIGN(v807, v808);
          RoundMode v809 = RoundMode::CAST_ROUND;
          SaturationMode v810 = SaturationMode::ON;
          TCVT(v807, v561, v809, v810);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
          // pto: %probability_transfer_inline132__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v811 = PTOAS__GLOBAL_TENSOR_DATA(v119);
          // pto: %probability_transfer_inline132__ssa_v0_pview
          ;
          const int64_t v812 = 0;
          // pto: %probability_transfer_inline132__ssa_v0_pview
          ;
          const int64_t v813 = 512;
          // pto: %probability_transfer_inline132__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 8, 512> v814 = pto::Shape<1, 1, 1, 8, 512>();
          // pto: %probability_transfer_inline132__ssa_v0_pview
          ;
          pto::Stride<4096, 4096, 4096, 512, 1> v815 = pto::Stride<4096, 4096, 4096, 512, 1>();
          // pto: %probability_transfer_inline132__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND> v816 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND>(v811 + (v812 + v524 * v813), v814, v815);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
          TSTORE(v816, v807);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          TSTORE(v529, v543);
          TSTORE(v536, v805);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
          // pto: %alpha_transfer_inline75__ssa_v0_pview
          ;
          __gm__ float* v817 = PTOAS__GLOBAL_TENSOR_DATA(v194);
          // pto: %alpha_transfer_inline75__ssa_v0_pview
          ;
          const int64_t v818 = 0;
          // pto: %alpha_transfer_inline75__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 8, 1> v819 = pto::Shape<1, 1, 1, 8, 1>();
          // pto: %alpha_transfer_inline75__ssa_v0_pview
          ;
          pto::Stride<8, 8, 8, 1, 1536> v820 = pto::Stride<8, 8, 8, 1, 1536>();
          // pto: %alpha_transfer_inline75__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN> v821 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN>(v817 + (v818 + v524), v819, v820);
          TSTORE(v821, v557);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
        };
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        uint16_t v822 = getFFTSMsg(FFTS_MODE_VAL, v83);
        ffts_cross_core_sync(PIPE_MTE3, v822);
        int32_t v823 = (int32_t) v95;
        wait_flag_dev(v823);
        // pto: %next_m_inline26__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v824 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v69);
        // pto: %next_m_inline26__ssa_v0
        ;
        uint64_t v825 = (uint64_t) v38;
        TASSIGN(v824, v825);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        TLOAD(v824, v331);
        // pto: %next_l_inline25__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v826 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v69);
        // pto: %next_l_inline25__ssa_v0
        ;
        uint64_t v827 = (uint64_t) v40;
        TASSIGN(v826, v827);
        TLOAD(v826, v336);
        // pto: %alpha_inline24__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v828 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v69);
        // pto: %alpha_inline24__ssa_v0
        ;
        uint64_t v829 = (uint64_t) v68;
        TASSIGN(v828, v829);
        // pto: %246
        ;
        __gm__ float* v830 = PTOAS__GLOBAL_TENSOR_DATA(v194);
        // pto: %246
        ;
        const int64_t v831 = 0;
        // pto: %246
        ;
        pto::Shape<1, 1, 1, 32, 1> v832 = pto::Shape<1, 1, 1, 32, 1>();
        // pto: %246
        ;
        pto::Stride<32, 32, 32, 1, 1536> v833 = pto::Stride<32, 32, 32, 1, 1536>();
        // pto: %246
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN> v834 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN>(v830 + (v831 + v326), v832, v833);
        TLOAD(v828, v834);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        // pto: %pv_left_inline116__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v835 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v82);
        // pto: %pv_left_inline116__ssa_v0
        ;
        uint64_t v836 = (uint64_t) v39;
        TASSIGN(v835, v836);
        // pto: %pv_transfer_inline121__ssa_v0_pview
        ;
        __gm__ float* v837 = PTOAS__GLOBAL_TENSOR_DATA(v127);
        // pto: %pv_transfer_inline121__ssa_v0_pview
        ;
        const int64_t v838 = 0;
        // pto: %pv_transfer_inline121__ssa_v0_pview
        ;
        const int64_t v839 = 512;
        // pto: %pv_transfer_inline121__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 32, 256> v840 = pto::Shape<1, 1, 1, 32, 256>();
        // pto: %pv_transfer_inline121__ssa_v0_pview
        ;
        pto::Stride<16384, 16384, 16384, 512, 1> v841 = pto::Stride<16384, 16384, 16384, 512, 1>();
        // pto: %pv_transfer_inline121__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v842 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v837 + (v838 + v326 * v839), v840, v841);
        TLOAD(v835, v842);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %t__tmp_v77
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v843 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v82);
        // pto: %t__tmp_v77
        ;
        uint64_t v844 = (uint64_t) v66;
        TASSIGN(v843, v844);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v843, v321, v828);
        // pto: %next_left_inline23__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v845 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v82);
        // pto: %next_left_inline23__ssa_v0
        ;
        uint64_t v846 = (uint64_t) v41;
        TASSIGN(v845, v846);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        TADD(v845, v843, v835);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
        // pto: %pv_right_inline22__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v847 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v82);
        // pto: %pv_right_inline22__ssa_v0
        ;
        uint64_t v848 = (uint64_t) v39;
        TASSIGN(v847, v848);
        // pto: %249
        ;
        __gm__ float* v849 = PTOAS__GLOBAL_TENSOR_DATA(v127);
        // pto: %249
        ;
        const int64_t v850 = 256;
        // pto: %249
        ;
        const int64_t v851 = 512;
        // pto: %249
        ;
        pto::Shape<1, 1, 1, 32, 256> v852 = pto::Shape<1, 1, 1, 32, 256>();
        // pto: %249
        ;
        pto::Stride<16384, 16384, 16384, 512, 1> v853 = pto::Stride<16384, 16384, 16384, 512, 1>();
        // pto: %249
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v854 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v849 + (v850 + v326 * v851), v852, v853);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
        TLOAD(v847, v854);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %t__tmp_v78
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v855 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v82);
        // pto: %t__tmp_v78
        ;
        uint64_t v856 = (uint64_t) v66;
        TASSIGN(v855, v856);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v855, v323, v828);
        // pto: %next_right_inline41__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v857 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v82);
        // pto: %next_right_inline41__ssa_v0
        ;
        uint64_t v858 = (uint64_t) v42;
        TASSIGN(v857, v858);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        TADD(v857, v855, v847);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
      };
    };
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    // pto: %250, %251
    ;
    int64_t v859 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v292 * (uint64_t) v74) + (uint64_t) v298);
    // pto: %252
    ;
    int64_t v860 = v859 < v77 ? v77 : v859;
    // pto: %attn_mi_inline91__ssa_v0_pview
    ;
    int64_t v861 = (int64_t) v26;
    // pto: %attn_mi_inline91__ssa_v0_pview
    ;
    const int64_t v862 = 0;
    // pto: %attn_mi_inline91__ssa_v0_pview
    ;
    __gm__ float* v863 = PTOAS__GLOBAL_TENSOR_DATA(v203);
    // pto: %attn_mi_inline91__ssa_v0_pview
    ;
    const int64_t v864 = 1;
    // pto: %attn_mi_inline91__ssa_v0_pview
    ;
    const int64_t v865 = 1;
    // pto: %attn_mi_inline91__ssa_v0_pview
    ;
    const int64_t v866 = 1;
    // pto: %attn_mi_inline91__ssa_v0_pview
    ;
    int64_t v867 = v78 * v69;
    // pto: %attn_mi_inline91__ssa_v0_pview
    ;
    int64_t v868 = v866 * v867;
    // pto: %attn_mi_inline91__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 1> v869 = pto::Shape<1, 1, 1, 32, 1>(v864, v865, v866, v78, v69);
    // pto: %attn_mi_inline91__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v870 = pto::Stride<-1, -1, -1, -1, -1>(v865 * v868, v868, v867, v69, v861);
    // pto: %attn_mi_inline91__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v871 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v863 + (v862 + v860 * v69 + v77 * v861), v869, v870);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
    TSTORE(v871, v301);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    // pto: %attn_li_inline106__ssa_v0_pview
    ;
    int64_t v872 = (int64_t) v26;
    // pto: %attn_li_inline106__ssa_v0_pview
    ;
    const int64_t v873 = 0;
    // pto: %attn_li_inline106__ssa_v0_pview
    ;
    __gm__ float* v874 = PTOAS__GLOBAL_TENSOR_DATA(v212);
    // pto: %attn_li_inline106__ssa_v0_pview
    ;
    const int64_t v875 = 1;
    // pto: %attn_li_inline106__ssa_v0_pview
    ;
    const int64_t v876 = 1;
    // pto: %attn_li_inline106__ssa_v0_pview
    ;
    const int64_t v877 = 1;
    // pto: %attn_li_inline106__ssa_v0_pview
    ;
    int64_t v878 = v78 * v69;
    // pto: %attn_li_inline106__ssa_v0_pview
    ;
    int64_t v879 = v877 * v878;
    // pto: %attn_li_inline106__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 1> v880 = pto::Shape<1, 1, 1, 32, 1>(v875, v876, v877, v78, v69);
    // pto: %attn_li_inline106__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v881 = pto::Stride<-1, -1, -1, -1, -1>(v876 * v879, v879, v878, v69, v872);
    // pto: %attn_li_inline106__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v882 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v874 + (v873 + v860 * v69 + v77 * v872), v880, v881);
    TSTORE(v882, v319);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    // pto: %attn_oi_inline71__ssa_v0_pview
    ;
    __gm__ float* v883 = PTOAS__GLOBAL_TENSOR_DATA(v221);
    // pto: %attn_oi_inline71__ssa_v0_pview
    ;
    const int64_t v884 = 0;
    // pto: %attn_oi_inline71__ssa_v0_pview
    ;
    const int64_t v885 = 512;
    // pto: %attn_oi_inline71__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 256> v886 = pto::Shape<1, 1, 1, 32, 256>();
    // pto: %attn_oi_inline71__ssa_v0_pview
    ;
    pto::Stride<16384, 16384, 16384, 512, 1> v887 = pto::Stride<16384, 16384, 16384, 512, 1>();
    // pto: %attn_oi_inline71__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v888 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v883 + (v884 + v860 * v885), v886, v887);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v888, v321);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    // pto: %256
    ;
    __gm__ float* v889 = PTOAS__GLOBAL_TENSOR_DATA(v221);
    // pto: %256
    ;
    const int64_t v890 = 256;
    // pto: %256
    ;
    const int64_t v891 = 512;
    // pto: %256
    ;
    pto::Shape<1, 1, 1, 32, 256> v892 = pto::Shape<1, 1, 1, 32, 256>();
    // pto: %256
    ;
    pto::Stride<16384, 16384, 16384, 512, 1> v893 = pto::Stride<16384, 16384, 16384, 512, 1>();
    // pto: %256
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v894 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v889 + (v890 + v860 * v891), v892, v893);
    pipe_barrier(PIPE_MTE3);
    TSTORE(v894, v323);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}