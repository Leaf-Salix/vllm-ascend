# 完整 CSA 入口实际生成物独立复核

**结论：通过，未见完整入口内联造成的生成代码阻断。** 只读取回指定 build `pypto-build-7_aitfy4` 的 orchestration 目录与 QK/PV AIC、AIV 两个文本文件，没有读取 cache、opp、权重或 tensor。审查者没有提交任务或修改正式源码。

## 与已审 program 候选对照

- AIC 与 AIV 完整 device body，去掉整行注释/空行后各2493行，与 `candidate-swa-cube-generated` **逐字相同**。body SHA：`6d0e2f35337b867c6ae367f1cbe0ae90e70078a4115fd7e12bf248888f80d313`。
- kernel_entry wrapper 只对 SSA/return-phi 的局部名字做一致双射标准化后逐字相同。所有 args 槽、类型、动态 shape 轴、scalar 转换和最终实参顺序保持。
- 因完整核体相同，前次已审 SWA guard、PV 首片初始化/后续累加、显式 +0 tail concat、L1/UB 物理布局、四组 FFTS 事件、compressed K512 运算/归约/CAST_ROUND/online 顺序均没有因完整入口内联变化。

## 完整编排检查

- 实际 root ABI62；checked48 → planner32 → mixed24 的显式依赖链保留。
- 完整 root 的 mixed func_id 为65(AIC)、66(AIV)，与孤立 program 中3/4不同；后续若分析完整root PMU，不能沿用孤立root的func编号。
- mi/li/oi 在 attention scope 中创建；返回描述符保持同一 allocation；merge_norm 在该scope结束前消费它们。
- merge_norm 同时依赖本次 qk_tid 与 rope_tid，输出写 root 持有的 o_packed_heads；后续 heads/O-proj 没有使用被释放的局部 allocation。

## 实际文件身份

| 文件 | SHA256 |
| --- | --- |
| QK/PV AIC | `8d4e5a961928c1c8b4c4b5cd8f35026df907920b9dcfc2098662b556119cc835` |
| QK/PV AIV | `443c51ae3e41c1c4a9efd6ad52a7f72408f32a8b5ba3e302f1601f9e4888e73b` |
| 完整 orchestration | `3b00f200d75ce0f7727a4b8f7fea1b4c48109e3c1e666cc736dc25cece1ccb79` |

可以运行 `python3 check.py` 独立重算核体/wrapper/编排检查。详细JSON见 `results.json`。

这是生成代码身份和生命周期复核；硬件数值、性能及整模型结论仍须由实际相应任务结果支持。
