"""CPU-only comparison of the real full-entry generated sparse mixed kernels."""
import hashlib
import json
from pathlib import Path
import re

HERE=Path(__file__).resolve().parent
PROGRAM=HERE.parent/'candidate-swa-cube-generated'
FULL=HERE/'actual'
MARKER='extern "C" __aicore__ __attribute__((always_inline)) void kernel_entry'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def clean(text):
    return '\n'.join(line.strip() for line in text.splitlines() if line.strip() and not line.lstrip().startswith('//'))
def alpha_wrapper(text):
    names={}
    def rename(match):
        name=match.group()
        if '__ssa_v' not in name and '__rv_v' not in name:return name
        if name not in names:names[name]='LOCAL_'+str(len(names))
        return names[name]
    return re.sub(r'\b[A-Za-z_][A-Za-z_0-9]*\b',rename,text)
result={'static_generated_review_pass':True,'hardware_executed_by_reviewer':False,
        'source_manifest_sha256':'2c1f3bc97187e6c6f2cac4bdee086a631bae2a2b7a1b023bb0e99b28a1bd6b72',
        'remote_actual_build':'full-csa-gate/build/pypto-build-7_aitfy4',
        'download_scope':['orchestration/','kernels/aic/qk_pv_aic.cpp','kernels/aiv/qk_pv_aiv.cpp'],
        'kernels':{}}
for core in ('aic','aiv'):
    rel=f'kernels/{core}/qk_pv_{core}.cpp'
    old_body,old_wrapper=clean((PROGRAM/rel).read_text()).split(MARKER)
    new_body,new_wrapper=clean((FULL/rel).read_text()).split(MARKER)
    assert old_body==new_body,(core,'changed complete device body')
    assert alpha_wrapper(old_wrapper)==alpha_wrapper(new_wrapper),(core,'changed wrapper arguments/types/dynamic-shape semantics')
    result['kernels'][core]={'program_sha256':sha(PROGRAM/rel),'full_sha256':sha(FULL/rel),
        'body_lines':len(new_body.splitlines()),'body_sha256':hashlib.sha256(new_body.encode()).hexdigest(),
        'complete_body_identical':True,'wrapper_alpha_identical':True}
orch=FULL/'orchestration/_full_csa_tnd.cpp'
text=orch.read_text()
for value in ('expected_arg_count = 62','params_t58.launch_spec.set_block_num(48)',
              'params_t59.launch_spec.set_block_num(32)',
              'params_t59_deps[params_t59_deps_count++] = checked_tid_inline5806',
              'MixedKernels mixed_60 = {65, 66, 66}',
              'params_t60.launch_spec.set_block_num(24)',
              'params_t60_deps[params_t60_deps_count++] = qk_plan_tid_inline5802',
              'params_t62_deps[params_t62_deps_count++] = qk_tid_inline5881',
              'params_t62_deps[params_t62_deps_count++] = rope_tid_inline5817',
              'Tensor attn_li_inline1391 = attn_li_inline5834',
              'Tensor attn_oi_inline1383 = attn_oi_inline5870'):
    assert value in text,value
result['orchestration_sha256']=sha(orch)
result['reviewed_scope']='mi/li/oi defined in attention scope and consumed by merge_norm before its exit; root-owned output heads preserved'
result['remaining_gate']='Main-thread NPU precision/performance results; this review only validates generated identity and orchestration'
(HERE/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
