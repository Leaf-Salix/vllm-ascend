# QK/PV 首轮 PMU 独立判断

结论：**先测 SWA 的 Cube 有效长度 128，保留原 K512 softmax、归约树及全部量化/舍入。** 这是当前四个候选中，源码存在确定冗余、测量也能够直接检验其影响的最小因素。尚不能由当前 PMU 断言它会明显降低整层延迟。

## 已知事实

独立读取三份原始 CSV，以实际 `kernel_config.py` 映射：func3 为 `qk_pv_aic`、func4 为 `qk_pv_aiv`。两份事件 2 均有 24 条 AIC 与 48 条 AIV；程序单卡 B4、24 个真实 token，每 core 一个 query。完整通过的一次程序有 47 项检查；第一份所在任务随后未完成，但其第一次已落盘 CSV 可用于计数重复性，不能称该任务整体通过。

下表是每条 task/core 记录的均值范围，单位为 PMU cycles，**不是各阶段的互斥耗时**。

| core | total | Cube / Vector busy | Scalar busy | MTE1 busy | MTE2 busy | MTE3 busy |
|---|---:|---:|---:|---:|---:|---:|
| AIC，两次事件2 | 132,823～138,208 | Cube 18,519～18,520 | 21,945～23,242 | 21,694～21,695 | 24,627～25,653 | 0 |
| AIV，两次事件2 | 137,404～142,233 | Vector 34,689～34,694 | 43,691～46,535 | 0 | 20,654～22,520 | 16,403～16,458 |

Cube/Vector busy 重复性远好于 task 总 cycles；本例中分别约占 total 的 13%～14%、24%～25%。这说明整 task 不是持续满载的单一 Cube/Vector 算术流；**不能因此认定剩余都是等待，或认定 Cube 优化不会影响关键路径**。Scalar、DMA、跨核信号和流水之间可能并行，也可能互相阻塞。

事件 6：AIC 的三个冲突计数均为 0；AIV 的 bankgroup stall 约 2,108、bank stall 约 3,265、Vector resource conflict 为 0。两种 bank 计数不能直接相加；它们没有证明 UB bank conflict 是主要损失。事件 6 与事件 2 来自不同运行，不能以两次 total 相减分解时间。

原始 CSV 的 SHA、逐函数统计保存在 `PMU_INDEPENDENT_AGGREGATE.json`。

## 四个候选的证据排序

| 因素 | 当前证据 | 首次 A/B 应保留什么 | 当前判断 |
|---|---|---|---|
| SWA128 vs padded512 Cube extent | SWA 实际最多128 Key；源码仍对第0块执行4个K128 QK及4个K128 PV，后三段为 padding。直接存在空算和 L1/GM 搬运 | 其他 compressed 块、512列 softmax、Native 实际长度归约、BF16概率和FP32更新边界不动 | **优先**。期望首先减少 Cube/MTE1 指令量；收益必须由无DFX配对延迟证明 |
| PV N128 | 现有 PV 为64×512输出；当前 Cube busy 只占整task一部分，尚无N维切分效率或L0C stall指标 | 同一输出列的K128累加顺序与边界不变 | 可作为第二个可控因素，但N切分也会增加循环/装载，不由当前数据推出收益 |
| UB stats/mi-li驻留 | 源码每个8head组有GM统计读写，确有可检查的指令；事件6 bank冲突较小，没有相关字节数或独立成本 | 初始sink、每512候选的max/sum/alpha顺序、跨AIV独立head行不动 | 先量化GM事务/循环和实际依赖，再判断；目前不能称主要瓶颈 |
| K512预取 | AIC/AIV有四组显式跨核握手；PMU没有各次sync_wait或MTE等待跨度 | 原顺序/round不变，还需证明buffer生命周期及事件不会覆盖尚在消费的数据 | **证据不足，暂不优先复杂流水**。busy低不能证明带宽瓶颈，也不能证明预取能够遮蔽等待 |

SWA 的缩短应特别检查：原 score 的 padding 列是否仍显式初始化，不能让旧/未初始化 NaN 经 `score*scale+NEG_INF` 进入 softmax；保留尾列的有限零值更容易与原路径建立合同。PV 去掉零 contribution 后仍需检查 ±0 及真实同输入逐 bit，不能仅用代数上的“加零”宣称位等价。

## 还缺少的关键量

1. **同一 bank 的 Nal sparse PMU**：需相同输入、block/key数量与 core 映射；比较 busy、指令路径及 total。即使 Nal 精度仅记录，不能混用另一种输入当性能归因。
2. **每次同步等待的内核跨度**：当前公开 DSL 没有 span/cycle API，PMU 只包整 task。不能把 `total − busy` 当作 sync_wait；若不扩 SDK，先通过单因素保持数学的 A/B 缩小归因范围。
3. **实际搬运量/缓存命中**：事件2 MTE busy 不提供带宽或 L2 miss；若后续仍怀疑搬运，需要事件4/8或 CANN对应指标，且各自独立任务采集。
4. **生产 FULL graph 配对延迟**：program-mode 总执行含另一套调度/搬运，不作为正式延迟。先测 isolated candidate 的位等价和counter变化，再以原 graph无DFX交错配对，至少覆盖短/混合及大T，收益稳定后才扩大整模型。

本分析没有改算子、提交 NPU 或将 PMU counter 解释成可相加的计算/搬运/等待分解。
