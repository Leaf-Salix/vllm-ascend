#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
here=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "$here/pin-v6.sh"
source "$here/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
unset SIMPLER_PMU_EVENT_TYPE
label="${1:?new label}";event="${2:?event}";shift 2
[[ "$label" =~ ^[A-Za-z0-9_.-]+$ ]]
mkdir -p "$here/program-results"
mkdir "$here/program-results/$label"
python "$here/preflight.py" > "$here/program-results/$label/preflight.log" 2>&1
# program keeps all tensors and artifacts on 227; only metrics may be pulled.
timeout --signal=TERM --kill-after=15s 750s python "$here/run_program.py" \
 --bank /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/qkpv-measurement-20261019-codex/capture-b4/csa-results/native-sparse-b40/data/native-sparse-bank.pt \
 --bank-sha ee36fbef78c0ad255408fe7796e212eabb1b45ccc29070214ade2110c1b27b8a \
 --event "$event" --out "$here/program-results/$label/data" "$@" > "$here/program-results/$label/run.log" 2>&1
