# SWA formatted-v2 phase 封包工具独立审查

日期：2026-10-19。当前工具 SHA：`5e1fa075be3d3291b183a73a9598fc745887b02c5bb74b85a89ccf226bde3234`。

**静态审查通过。** 未执行封包、修改正式repo或提交NPU；两档新实际审计尚不由本review宣告完成。

- 原V6 phase整包固定为 `bfec22356b0bc83fd2f7c2f6b20a43bdad35550f5bba5371222649d00bcf29ab`，已对正式 current evidence manifest 与本地原包 SHA 交叉核真。因此旧 policy、七fixture、审计器和历史调查材料均有原字节来源约束。
- 读取时拒绝非普通文件、软链、绝对/穿越路径、重复member、非UTF8/含NUL数据；不提取到任意路径，不包含模型tensor/binary。
- 两份新audit必须 `pass=true`、source等于显式 expected-source、identity=`SWA_Cube128_V2`。128K额外要求完整policy相同、fa3政策SHA和原审计器SHA一致。工具直接保留输入审计原字节，没有生成或修改其数值结论。
- 旧两份audit原字节移到 `historical-v6-*`，对应正式文件名由新实际audit占用。新增provenance明确旧七fixture是历史审计器自测，不是新候选NPU结果，其余observer材料仍为历史解释。
- 输出拒绝覆盖，用内存payload生成新tar，再逐member回读字节核验。旧包不会改动。
- `pack.py` 与 `build_manifest_phase_matched.py` 均与V6已审版本逐字节相同。新phase包接入后仍需新mixed/8K/128K raw、source639b、两份独立审计及 `--accept` 完整门禁；pack输出的pass仅是封包完整性。

执行时应传最终 formatted-v2 的 `639b1280dc682dad23195509ddd51970d0d16da55fa11efa302e9edc97da7e03`，不能沿用未format v1的2c1f身份。当前工具以CLI expected强制绑定，后续builder/CPU证据还会再比较实际raw/source。因此仅变更identity标签不能把旧V6结果变成新候选验收。
