# Sparse ACL graph A/B 独立审查

结论：**当前 helper 静态审查通过，未发现提交小任务前的阻断。** 审查没有提交或运行设备，没有修改正式源码。实际硬件结果仍由主线程取得。

## 两臂绑定

- baseline root 直接 import 正式 precision `decode_sparse_attn_csa.sparse_attn_csa`；candidate root import 私有 `candidate_sparse.sparse_attn_csa`。去掉这一条 provider import 后，两 root 完整 AST 相同。
- 候选 sparse SHA `8f3ddd066cbf4f7111b554baaa0f3720f940c5db96bb32235cecdfad201ea20c` 与前次独立源码/生成审查一致。正式基线 sparse SHA 被脚本显式限制为 `f5558603e25711de2a0ae9422dc62de977c36159c668f13d4451b176b9ca17c6`。
- 不同 torch namespace 注册两个不同 JIT root。已只读核对227固定SDK `registration.py`：每个注册实现的 execute 闭包持有传入 kernel；同 namespace 试图绑定不同 kernel 会抛错，没有按通用 root 名称偷偷覆盖另一个 namespace 的路由。
- shell 本次 preflight 核验 helper manifest 和正式 snapshot；结果另外记录四个实际 import 文件路径/SHA。审查时全部新 helper 文件都与 manifest 匹配，详见 `results.json`。

## 精度与保护门禁

- 固定 Native bank SHA、baseline raw stats SHA，gold 内 bank_sha 必须匹配。实际 bank 的 ori/cmp 原形状已从捕获报告核对为 `[37,32,1,512]` 与 `[265,32,1,512]`，与两个 root 的输入页布局匹配。
- 每臂独立 owner 和四个 Out；前后各64元素 guard，所有 Out 先 NaN poison，再实际 NPUGraph replay，并逐项对固定 `mi/li/oi/heads` gold。
- 初审发现的 live-input 门禁缺失已补齐：Q+B、Qzero 不仅两臂互比，还要求输出至少一项相对 A 真正变化；Q+B 实际 device Q 会读回对预期输入，zero 实际 Q 也断言为零。
- A 恢复后两臂分别对固定 stats 和 Native pre-inverse heads；所有 live 比较均要求四个 Out 有限且 guards 完整。
- 计时期间每五轮比较两臂及 guard；计时最后两臂分别再次对固定 gold，避免共同漂移逃过互比。所有 device In 在最后读回逐字对 Host bank，因此不再只有 program runner 的 Host-only readonly 检查。
- 任一首差 assert 即停止，不能继续得出性能通过结论。

## 计时口径

20轮、每轮每臂100次 replay，同卡顺序交错，奇数轮反转；NPU Event 取整段 elapsed/100。脚本未启 PMU/DFX/depgen，graph 预热和所有 CPU拷贝/精度比较位于计时段之外；最终同时保存原始20对样本。

计时覆盖的是 **完整 isolated sparse diagnostic root**，包含 checked/planner、mixed QK/PV、独立 RoPE任务与 publish/归一化/统计量导出。它既不是纯 QK/PV Cube 延迟，也不是完整 CSA 或整模型延迟。真实 bank 是 eager Native sparse 观察，而 graph 执行为本次真实 ACL graph，两者范围必须在结果中明确。

正式源仍是1d6基线；本审查不等于候选已通过其他history、不等长请求或真实整模型。后续扩大仍须首差停下、每任务不超过15分钟。
