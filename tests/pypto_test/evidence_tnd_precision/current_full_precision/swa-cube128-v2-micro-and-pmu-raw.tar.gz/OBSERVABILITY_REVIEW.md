# QK/PV 核内可观测性只读审查

## 结论

保留 `1d6dbd027` 基准。本次只读核当前227固定PyPTO/Simpler、torch_npu 2.10.0.post2及私有CANN9.2工具，未安装、编译、修改源码或提交NPU。

1. **现有PyPTO DSL没有查到可在QK/PV体内使用的cycle/timestamp/计时span操作。** Simpler内部有时间戳，但这不是DSL公开接口。
2. **当前FULL graph所用PyPTO kernel模式不能开启Simpler内部PMU。** 这不是缺少一个Python参数：C++的KernelStaticConfig显式拒绝`enable_pmu!=0`。不能私改CallConfig绕过。
3. **torch_npu profiler公开API与现存msprof支持流水/内存指标。** `_ExperimentalConfig`确实支持PipeUtilization、MemoryL0、MemoryUB、ResourceConflictRatio；必须Level1或Level2，Level0会将metrics改成None。
4. **这些指标不能直接给出“计算x µs＋搬运y µs＋同步等待z µs”的互斥分解。** 活跃流水可以重叠，MemoryL0/UB主要是存储访问/带宽，ResourceConflict只覆盖特定冲突，不是全部同步等待。
5. **现有混合核还存在外层launch归因问题。** 一次PTO root调用launch外层AICore executor，内部再`execute_task`执行多个PTO func。CANN通常按外层launch记账，不能先假定它会自动把PMU分别贴给`qk_pv_aic/qk_pv_aiv`。是否能对本机该路径细分，需要小pilot验证实际输出。

在“不改SDK/codegen/C++helper”的约束下，可靠目标是先取得：**同一数值实现的task生命周期＋按AIC/AIV区分的流水活跃/内存访问/有限冲突证据**。完整的核内逐段时间戳及全部跨核等待暂时没有已核实接口。

## 能力与边界

| 路径 | 本次核实的能力 | 不能直接说明的内容 |
| --- | --- | --- |
| `pypto.torch.begin_dfx/end_dfx`、level4 | 每task执行起止、调度/编排阶段；已用actual artifact映射 | task内部QK/PV、MTE、event wait各占多少 |
| DSL `Span`、`static_print` | 源位置元数据、编译期打印 | 运行时计时；这里的Span不是profiling span |
| `CompileProfiler`、`simpler.trace` | 编译/Host侧计时 | AI Core核内cycle |
| `pypto.torch.init/KernelConfig` | swimlane/dep-gen | 无PMU参数；native验证也禁止PMU |
| program-mode `RunConfig(enable_pmu=N)` | 既有per-task PMU及`pmu.csv`，按task_id/func_id/core_type记录 | 当前FULL graph的kernel-mode可直接启用；两种模式同进程互斥 |
| torch_npu `_ExperimentalConfig` | Pipe/Arithmetic/Memory/L0/UB/Conflict/L2等组 | 不保证当前外层executor下面每个PTO inner func都有独立行 |
| `msprof` / `msprof op` | 本机已有工具，help列出Pipe/MemoryL0/MemoryUB/Conflict等 | 有help选项不等于本机custom mixed路径已有完整核内TimelineDetail/Source映射 |

### 精确源码证据

- PyPTO `torch/execution.py:17–25`、`runtime/kernel/abi.py:21–31,69–85`：kernel初始化只有swimlane、dep-gen；配置冻结。
- Simpler `src/common/platform/include/host/kernel_static_config.h:32–42`：kernel模式只允许两种diagnostics；PMU/dump_args/scope_stats返回unsupported。
- Simpler `aicore_executor.cpp:179–195`：task起止和program PMU包住整个`execute_task`，不是核内自定义片段。
- Simpler `kernel_launch_owner.cpp:122–142`及`kernel_launch_sequence.h:33–54`：一次root调用launch外层AICore/AICPU，再由executor分派inner task。**持久的是参数/stream等资源，不能误说整个kernel从init一直常驻不退出。**
- torch_npu `experimental_config.py:25–28,42–51,67–83,144–148`：组已导出；Level0/Level_none会清掉aic_metrics。
- CANN wheel `ai_core_metrics_manager.py:43–55`：Pipe、MemoryL0、MemoryUB、ResourceConflict的真实输出列。

源文件路径/解析后的路径/SHA在`source-identities.json`；关键摘录保存于本目录的`*.txt`，不依赖网上版本。

## 各指标究竟能回答什么

### PipeUtilization

本机CANN schema包含`aic_mac_ratio`、`aiv_vec_ratio`、AIC/AIV scalar及MTE1/2/3 ratio字段；具体实际导出列需以pilot结果为准。Simpler program PMU事件2的原始表是：

- vec/cube/scalar busy cycles；
- MTE1/MTE2/MTE3 busy cycles；
- icache miss/request。

可以判断所采scope里哪些流水活跃、是否有搬运或计算持续占用。不能把这些busy相加当wall time，也不能以`1-sum(busy)`推导等待。

### MemoryL0 / MemoryUB

前者给L0A/B/C访问带宽；后者给MTE、Vector、Scalar的UB读写带宽。它们是数据路径利用情况，不是“等待L0”或“等待搬运”的直接耗时。需要结合PipeUtilization、总cycle、输入字节/运算量和冲突组解释。

### ResourceConflictRatio

当前A2/A3表提供bankgroup/bank stall、vector resource conflict。它不覆盖全部`sync_wait`、FFTS握手、生产者等待、调度等待。CANN wheel里虽另有新芯片的`PipeStallCycle`常量，但当前torch_npu AiCMetrics和本机CLI help未开放这个组，不能当作本机已支持。

### 单位与多核

PMU total cycle与DFX系统计数时钟不是同一个计时单位。先按每task的`counter/pmu_total_cycles`计算比率，保留AIC/AIV及core_id；不要把24个AIC、48个AIV的cycle求和当单次wall time。若换算等效活跃时间，必须注明近似和时钟/计数窗口前提，不是可加的真实分解。

## 推荐测量顺序

### 第一门：低成本验证CANN实际可见范围

独立报告目录、单卡B4/history8191，沿用当前baseline、warmup后只采少量FULL graph replay。用公开API：

```python
from torch_npu.profiler import (
    profile, ProfilerActivity, ProfilerLevel, AiCMetrics, _ExperimentalConfig,
)
config = _ExperimentalConfig(
    profiler_level=ProfilerLevel.Level1,
    aic_metrics=AiCMetrics.PipeUtilization,
    data_simplification=False,
)
# 前置：原数值、graph和guard门禁通过，图已warmup；这里不做正式延迟统计。
with profile(activities=[ProfilerActivity.CPU, ProfilerActivity.NPU],
             experimental_config=config, on_trace_ready=existing_trace_handler):
    graph.replay()
    torch.npu.synchronize()
```

这只是调用方式草稿，`existing_trace_handler`应沿用已验证的runner导出路径。每个事件组独立短任务，不把多个互斥metrics塞进一个配置；内部750秒/外部780秒。首先核对实际输出是否存在有效AI Core PMU、AIC/AIV区分以及内层QK/PV归因，不能只检查profile目录创建成功。

若只有外层executor行，则明确记录为“完整root指标”，**不得贴成QK/PV指标**。随后选下列路径之一，而不是做不可解释的ablation。

### 第二门A：QK/PV-only DSL测量wrapper＋外部CANN profiler

只在reports构造私有wrapper，调用原QK/PV mixed body，使用原代码生成的真实计划、Q/KV、bias/valid mask、FFTS/workspace。保持所有运算、K512/归约、舍入和event顺序；输出mi/li/oi逐bit对齐baseline；检查实际生成的AIC/AIV核体等价。

这样外层launch主要只有QK/PV，CANN指标可以归到“QK/PV wrapper＋runtime分派开销”，但仍不能称完全没有框架成分，也不能据它直接代表整模型profile。混合核必须两侧成对运行，不能只profile默认kernel replay中的单独AIC或AIV一侧。

### 第二门B：复用已有program-mode per-task PMU

若A路径缺少必要字段，现有program-mode PMU更适合精确绑定func_id/task_id。固定runtime已有PMU ST：`runtime/tests/st/a2a3/tensormap_and_ringbuffer/dfx/pmu/test_pmu.py`；CSV前缀为`thread_id,core_id,task_id,func_id,core_type,pmu_total_cycles`。

用独立进程/私有program-mode wrapper，不先调用`pypto.torch.init`再混用program；不改SDK。先验证与baseline相同输入、相同核体、相同结果，再采事件2（Pipe）、6（Conflict），有需要才增加5（L0）、7（UB）及4（Memory）。显式清除或固定`SIMPLER_PMU_EVENT_TYPE`，因为它能覆盖请求的事件组。

这是诊断执行模式，不是当前生产FULL graph的直接PMU结果。必须同时保留生产模式DFX和无插桩计时，不能混算。该QK/PV wrapper的实际硬件采集还未执行，本报告没有把可行路径冒充验证成功。

### 后续单因素与精度

取得可归因的counter之后再决定计算布局、搬运或同步优化；每次只改一个因素，保留1d6dbd027和原数值边界。正式收益用无DFX/无PMU同卡交错测量，稳定后再跑用户指定的整模型测试。每项NPU任务均小于15分钟，首差停下来定位。

## 不可采用的“分解”

- 删掉matmul的快版与原版差值，不等于真实计算时间：它会改变MTE重叠、寄存器/L0C压力和握手等待。
- 删掉wait或绕过producer，不仅无法保留同步语义，通常还会产生竞态；差值不能当等待时间。
- memory-only、compute-only、no-sort等probe可验证因果敏感性，但它们的差值不能相加成原核wall time。
- Pipe busy、Memory带宽、bank冲突是互相关联且可重叠的证据，不是三段互斥秒表。

在现有约束下，尚不能保证直接得到所有核内同步片段的精确cycle。若最终需要完整逐段时间戳，应另外确认平台支持的instruction/TimelineDetail或新增可验证的DSL计时op；后者超出本次“不改SDK/codegen/C++”范围，不能暗中实施。
