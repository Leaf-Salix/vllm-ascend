# SWA 候选复用 V6 证据封包协议审查

日期：2026-10-19。结论：**方案可复用，不需弱化 current evidence CPU 门禁；新 raw 与审计齐全前不得 accepted。** 本轮只读，未修改正式 repo 或提交任务。

## 可以原样复用的部分

`pack.py` 已参数化 job、result-root、source manifest、prefix 和 repeats，可将新 mixed、8K、128K 放入独立 `swa-cube128-v1` 包。它核对 raw/config 的实际新 source hash，混合场景绑定43个实际源及 helper；整模型绑定实际 configuration、16rank原始请求/性能记录、Native历史性能与token/event黄金及helper。不接受换个包名就把旧V6结果视为新源。

正式 CPU 测试还会复算包内容 SHA、source manifest、43运行源集合与当前 repo 字节、helper manifest，重放所有 warm+三轮 token/events/零抢占/21CSA+20HCA/62ABI及Native历史同输入CPU观测门禁。新 Sparse 生效时，manifest 中的43源必须只有该文件变成新SHA；不可跳过当前源校验。

## 必须选择 phase 版本 builder

应使用 `build_manifest_phase_matched.py`，传入新 source、identity、prefix、repeats=3、新的两档实际独立审计和新 phase archive。普通 `build_manifest.py` 不生成 reference_phase_policy，CPU 测试将把128K所有轮对Native第一轮比较；它不符合已验收的固定 first/repeated 配对协议。

`--accept` 必须等到新 mixed+两档whole raw完整、两份新独立审计通过。builder核新源一致、三轮完整、tested_sources相同与重算性能，phase builder另外核policy/auditor/七fixture。新参数不涉及修改数值或metadata验收条件。

## Phase archive 的复用范围

- policy应原字节保留 `fa3be8eebcde5fada53af07219431a1b1ea7949c89864348f154701bced86335`，固定1→1、2/3→2，仅排除call、禁止input_ids归一化。
- 未改的审计器和七fixture可原字节保留；它们证明此审计器/配对政策对已定义正负例的行为，不是新候选NPU结果。归档应保留这一历史自测范围。
- `phase-audit.json` 必须换为新候选实际128K审计，source hash绑定新manifest；建议直接与传给builder的 `--audit-128k` 字节相同并保存SHA，避免两个同源不同run的审计混用。
- 原始失败、独立review、source observer解释仍是历史政策依据，保留其原SHA。旧 `independent8k.json` 若沿用，应明确历史V6证据，不能作为当前8K结果；当前8K实际验收来自新raw和显式新审计。
- 旧 `pack_phase_evidence.py` 将路径和文件名硬编码到V6，不能直接执行后当作新包。应在独立副本改目标/新审计来源，以新archive名/hash生成，并保留既有V6原包不动。

## 不得扩大声明

新source/math/helper hash本轮来自主线程的静态准备receipt，本审查没有再次抓取远端快照；应在实际封包前按最终值逐文件验证。当前mixed任务仍在进行，本review不是设备验收。正式current CPU测试只有在新source与新证据一起接入后才应通过，不能因正式repo暂未换Sparse而放宽源比较。

该协议验证已记录NPU结果与当前源码身份，不证明整模型所有内部FP32/BF16张量均逐bit，也不将CPU observer等同实际GPU输入hook。
