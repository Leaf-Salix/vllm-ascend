"""只封包本轮显式选择的文本测量证据；不接收模型、张量或缓存。"""
from pathlib import Path
import hashlib
import io
import json
import tarfile

root = Path(__file__).resolve().parent
selected = set()
allowed = {'.json', '.jsonl', '.py', '.sh', '.md', '.txt', '.csv', '.cpp', '.h', '.patch', '.log'}
def include(path):
    if path.is_file() and path.suffix in allowed and '__pycache__' not in path.parts:
        assert not path.is_symlink()
        assert not any(p in {'opp_env', 'cache', 'build', 'ascend-cache', 'vllm-cache'} for p in path.relative_to(root).parts)
        selected.add(path)
for path in root.iterdir():
    include(path)
helpers = ('pmu-pilot', 'capture-b4', 'sparse-program', 'sparse-program-b40',
           'candidate-swa-cube', 'sparse-graph-ab', 'sparse-graph-ab-b40',
           'nal-sparse-program', 'whole-tools-v2', 'full-csa-gate', 'full-csa-gate-v2')
for name in helpers:
    for path in (root/name).iterdir():
        include(path)
for name in ('candidate-swa-cube-generated', 'sparse-program-generated-second',
             'nal-sparse-generated', 'independent-source-review', 'review-capture-b4', 'review-candidate-swa-cube', 'review-sparse-graph-ab',
             'review-nal-sparse-program', 'review-full-csa-gate', 'review-full-generated',
             'review-whole-tools-v2', 'review-whole-prepare', 'review-evidence-reuse',
             'review-swa-phase-pack'):
    for path in (root/name).rglob('*'):
        include(path)
for path in (root/'pmu-pilot/bsh-source').rglob('*.py'):
    include(path)
results = ('sparse-program-results-pass', 'sparse-program-results-first',
           'sparse-program-conflict-results', 'nal-sparse-results', 'candidate-swa-cube-results',
           'sparse-graph-results-r1', 'sparse-graph-results-r2',
           'sparse-graph-b40-results-r1', 'sparse-graph-b40-results-r2')
for name in results:
    for path in (root/name/'data').iterdir():
        include(path)
    for name_log in ('run.log', 'preflight.log'):
        path = root/name/name_log
        if path.exists():
            include(path)
for path in (root/'pmu-pilot-results/data/pmu/native').rglob('kernel_details.csv'):
    include(path)
for name in ('full-csa-mixed21-results/data', 'full-csa-t1-results', 'full-csa-t240-results', 'full-csa-v2-mixed21-results'):
    include(root/name/'result.json')
required = ('capture-b4-results/data/result.json', 'capture-b40-results/result.json',
            'stats-gold-b4-results/result.json', 'stats-gold-b40-results/result.json',
            'pmu-pilot-results/data/result.json', 'nal-sparse-generated/kernel_config.py',
            'nal-sparse-generated/compiled_meta.json',
            'sparse-program-results-first/run.log', 'sparse-program-results-first/data/pmu-2.csv',
            'full-csa-v2-mixed21-results/result.json')
for name in required:
    path = root/name
    assert path.is_file(), name
    include(path)
archive = root/'swa-cube128-v2-micro-and-pmu-raw.tar.gz'
assert not archive.exists()
records = {}
contents = {}
for path in sorted(selected):
    data = path.read_bytes()
    data.decode('utf-8')
    assert b'\x00' not in data
    name = path.relative_to(root).as_posix()
    assert '..' not in Path(name).parts and not name.startswith('/')
    contents[name] = data
    records[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
contents['ARCHIVE_MANIFEST.json'] = (json.dumps({
    'scope': 'PMU diagnostics and isolated sparse + complete CSA gates; whole-model evidence separate',
    'no_models_tensors_binaries': True, 'files': records,
    'baseline_commit': '1d6dbd02700cf8686fd1e82a87558c188fcbdf5d',
    'final_sparse_sha256': '248d8b11bb0a045f7863c0b264d962845dcabafa51cbf1e5fafee413fa8dc6d5',
    'v1_hardware_records_not_relabelled_v2': True,
}, indent=2) + '\n').encode()
with tarfile.open(archive, 'x:gz') as tar:
    for name,data in sorted(contents.items()):
        t = tarfile.TarInfo(name)
        t.size = len(data)
        t.mode = 0o644
        tar.addfile(t, io.BytesIO(data))
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(contents)
    for name,data in contents.items():
        assert tar.extractfile(name).read() == data
print(json.dumps({'path': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'bytes': archive.stat().st_size, 'files': len(contents)}))
