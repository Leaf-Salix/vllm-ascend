# 固定 Nal Sparse program 助手独立审查

日期：2026-10-19。只读审查四个新助手，未提交 NPU 或改正式实现。

## 结论

**源码层面通过，可继续实际生成物门禁。** 三个 Python 文件可解析；helper manifest 64 项一致，Nal a919 的 38 项源码 pin 一致。根 AST 为 11 个输入加 1 个 Out，共12参数。真实编译 ABI 和完成依赖仍待实际生成物确认。

### 输入与输出

- 直接 import 已固定 a919 的原 `sparse_attn_csa`，没有复制、重写 Sparse 数学。真实 TND 正式源码没有变化。
- 原 Native bank 的 Q、ori/cmp cache/table、TopK、位置、lengths 和 sink 按原参数顺序传入。均匀 S6 由 bank lengths assert；当前 bank SHA 固定。建议再显式要求 `tokens == 6*len(lengths)` 且 `tokens<=384`，避免将来更换 bank 时只验证长度列表而遗漏 Q 行数。
- `packed` 发布地址为 `group*384+token`、每行4096元素=8heads×512。现有 `[8,384,8,512]`→取有效 token→置换→`[tokens,64,512]` 解包正确。
- 只检查有效 packed 行 finite 与重复字节一致，符合本助手口径。Native 数值误差单独记录，不作为 TND 精度黄金，也不因此阻断 Nal 性能参考。
- cos=1/sin=0 不消除原 Nal inverse RoPE 的计算、取数和发布任务；signed-zero 等细节也不保证与省略 inverse RoPE 逐 bit 相同。scope 已明确，不应删去这一限定。

### 依赖、身份与执行

- `sparse_attn_csa` 返回的 ready 是 qk task；Out 直接作为根输出，没有另一个根内消费者在缺依赖下读取 packed。未显式返回 TaskId 本身不构成缺失 consumer 依赖。实际生成物仍应确认该任务不会在根返回前逃逸，以及根 ABI 确实为12。
- 编译助手保留实际 `param_names`，运行助手核验 frozen-artifact 全部文件 hash。应在归档时同时保存原-source pin、编译输出路径和 frozen-artifact manifest，避免仅凭目录名声称 artifact 来自本次 root。
- run-nal.sh 先做预检，固定 bank SHA，750秒 timeout，设备由 TASK_DEVICE 映射。运行程序调用0、0、event：每进程只有一次 PMU 初始化，避免已发现的重复共享内存注册问题。
- 程序检查 fresh pmu.csv、至少一行非零周期；没有错误地宣称每行都一定是 qk_pv。后续按实际 kernel_config 做归属，不按文件顺序猜核名。
- readonly_scope 明确只有 host 参数字节。这不能证明 NPU 内部的输入 cache 没被写，但也没有夸大为设备只读门禁。

## 性能结论的边界

两程序 scope 有差异：Nal 原 helper 包含 inverse RoPE/packed publish；TND 诊断根另含 m/l/o 和 heads 的发布。因此**不能用两 program 的总耗时直接声称纯 QK/PV 差距**。可比较已核对应 qk_pv AIC/AIV 的 PMU 行，同时记录 Nal 融合了末尾输出步骤这一事实；活动周期包含等待，计数也不能自动等同纯计算周期。

本轮未做设备采集，未判断任何计数已能定位瓶颈。
