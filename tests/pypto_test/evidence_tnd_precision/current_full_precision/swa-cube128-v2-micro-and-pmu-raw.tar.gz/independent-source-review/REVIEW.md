# QK/PV 三种实现的静态对照与测量建议

日期：2026-10-19。独立只读审查；未修改正式源码、SDK 或环境，未编译、提交 NPU 任务。

## 1. 本轮结论

当前精度基准为 `1d6dbd02700cf8686fd1e82a87558c188fcbdf5d`。本地已有的三份实现足以解释结构差异，**不足以仅凭源码确定主要时间消耗来自计算、搬运还是等待**。

最值得拆测的四项是：

1. TND 的 SWA 有效窗口最多 128 行，Cube 仍执行一个完整 512 行块；Native 使用实际有效长度。
2. TND PV 的实际生成布局是 `M64/N512/K32`，Native 和 Nal 采用 `N128/K128`，具有不同的累加器占用和 FIX 重叠方式。
3. TND 的中间 max/sum/alpha 由同一 AIV 写回 GM 后再读取；Native 在 UB 保存对应状态。
4. TND 当前按一个 K512 块完成 gather→QK→softmax→PV→merge，再处理下一个块；Native 和 Nal 有跨阶段软件流水。

这些均为**待测因子**。Nal 的软件流水同时伴随 K128 独立 softmax、不同概率舍入及归并方式，不能整段移入精度版。

## 2. 源码身份及来源限制

工作区绝对根：`/Users/jiayetcs/Desktop/Project/PyPTO`。下列路径均相对此根，逐文件 SHA 见同目录 `source-identities.json`。

| 身份 | 本地来源 |
| --- | --- |
| TND 精度版 | `vllm-ascend-nalinaly-tnd-20261008-codex/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision/decode_sparse_attn_csa.py` |
| TND 实际 AIC 生成物 | `reports/dsv4-tnd-precision-overnight-20261019/formal-v6-generated-review/full/kernels/aic/qk_pv_aic.cpp` |
| Nal 性能版 | `reports/dsv4-tnd-precision-overnight-20261019/threeway-formal-v6/bsh-source/vllm_ascend/ops/pypto/deepseek_v4_flash_csa/decode_sparse_attn_csa.py`，固定 `a919f11942d93627441c8fa694e310dcbd1c671b` |
| Native 调用 | 当前 checkout 的 `vllm_ascend/attention/dsa_v1.py` 与 `device/device_op.py` |
| Native 对应算子源码 | 当前 checkout 的 `csrc/attention/sparse_attn_sharedkv/op_kernel/arch32/` 与其 `op_host/` |

`DeviceOperator.get_dsa_sparse_attn_op()` 返回 `_C_ascend.npu_sparse_attn_sharedkv`。压缩率 4 路径实际传入 `layout_q="TND"`、`layout_kv="PA_ND"`、Native query 边界、seq lengths、TopK、两类 block table、sink 和 SAS metadata。

因此，本轮分析使用当前 checkout 的 `sparse_attn_sharedkv` 源码。旧参考目录的 `sparse_flash_attention.cpp` 是另一个算子，不能因名称相近就认定为当前运行实现。

**限制：已确认 API 与算子类别对应；尚未证明当前本地 C++ 每个字节就是 227 已装 Native 静态算子包的构建输入。** 现有二进制身份门禁仍需保留。不能把这一源码对照写成已验证线上所有分支的指令级实现。

## 3. 对比总表

本表按 `H=64、D=512、SWA<=128、压缩 TopK<=512` 的当前配置讨论。

| 部分 | TND 精度版 | Nal 性能 BSH 版 | Native 对应 Arch32 源码 |
| --- | --- | --- | --- |
| 请求布局 | 真正 TND；token→request 使用 Native 请求边界派生映射 | 均匀每请求 S6，按 B×6 处理 | TND 请求边界和实际长度 |
| 数值 softmax 分块 | SWA 一块、压缩一块；存储宽度均 512；按实际 K 选择归约树 | SWA 128，加四个压缩 128 块 | S2 基块 512；SWA/尾块使用实际 K |
| QK 物理分块 | 候选 N128；D512 实际拆四个 K128 | 候选 N128；D512 的 Cube 计算 | N128、K-L1=256、K-L0=128 |
| PV DSL 形状 | P64×128 @ KV128×512；一个 C64×512 保留整个 K512 累加 | 每块 P64×128；输出拆四个 N128 | 输出 N128；沿实际候选 K，每 K-L0=128 保留累加 |
| PV 实际生成 | L0A64×32、L0B32×512、L0C64×512 | 源码显式 Left/Right N128；两累加器交替提交 FIX | N128/K128；L0A/B、L0C 双缓冲 |
| KV→L1 | 先 AIV paged gather 到 GM；AIC 再读；末两个 K128 在 L1 保留至 PV | AIV gather 到 GM；三槽 KV 在 QK 和延后 PV 之间保留 | raw SWA 直接 GM→L1 分页拷贝；compressed 由 AIV 合并到 GM 后入 L1 |
| Q 复用 | 一个 query 内跨两数值块保留 | 同 query 多 K128 块复用 | 每 M/query 组跨 candidate N 块复用 |
| 跨阶段流水 | 当前 K512 完成后进入下一块 | QK(k)、softmax(k−1)、PV(k−2)、merge(k−3) | Vec0/MM1 当前块；Vec1/MM2 上一块；Vec2 上两块，preload=2 |
| softmax head 切片 | 每 AIV 32 heads，按 8 heads×512 处理 | 每 AIV 一次 32 heads×128 | 根据实际 M/K 分片调用 SoftmaxFlashV2 |
| 概率 BF16 | `round`，对齐 CAST_ROUND | `rint`，与 Native 数值边界不同 | CAST_ROUND |
| online 归并 | K512 的旧 max/sum/o 与本块更新，先确定新 max 再 exp/BF16/PV | K128 先独立 local max/exp/BF16/PV，再 alpha/beta 归并 | 以当前实际 S2 块执行 online softmax 与旧输出更新 |
| 中间 m/l/alpha | 同一 AIV 经 GM 写入再读回 | local block stats 在 GM 三槽传递、running 状态在 AIV | UB 中 max/sum/exp 轮转；输出另有 GM 缓冲 |
| 最终输出 | FP32 o/l→BF16 rint→widen→inverse RoPE→BF16 rint；独立 merge/publish 任务 | 最后一块在 AIV 内完成归一化/inverse RoPE/publish | 算子归一化后 BF16 CAST_RINT；inverse RoPE 在模型后续路径 |

TND 文件中仍有 `S=6` 相关容量/小 tile 常量，不等于每个请求必须 padding 到 6。实际 query 行数、请求边界和 token_request 才决定有效数据；不可仅据常量认定仍为 BSH。

## 4. TND 的搬运、同步与数值顺序

### AIC

`decode_sparse_attn_csa.py:355` 起，每个 AIC lane 处理 `qk_t=core, core+24,...`。

- Q64×512 保留在 L1。
- 每个有效 K512 块等待 `KV_READY`，逐四个 K128 片读 KV→L1，QK 结果写 GM score。
- KV carrier 为 384×512 BF16：slot0 为前两片共用 scratch，slot1/2 保留后两片。
- 完成 score FIX 后发 `SCORE_READY`，等待 `PROB_READY`。
- PV 概率从 GM 入 L1；前两片 KV 再载入 slot0，后两片复用 slot1/2。
- 四片按原顺序累加到同一 FP32 C64×512；FIX 到 GM 后发 `PV_READY`。

实际生成物中，KV/Q/P L1 区间分别为 `[0,393216)`、`[393216,458752)`、`[458752,475136)` 字节，总计 **464 KiB**。剩余容量不能直接容纳另一整份 512 行 KV；跨块预取需要重新证明槽位寿命和 fence，不能直接加一个双缓冲常量。

生成物 `qk_pv_aic.cpp:447` 的 PV accumulator 是 64×512 FP32，满 **128 KiB L0C**。`542`、`554` 附近实际 Left/Right 为 64×32、32×512；每逻辑 K128 分成四个 K32 累加。物理分块应据生成物判断，不能把 DSL 中的 K128 输入形状直接当硬件 K128 MMA。

### AIV

每个 AIC 对应两个 AIV。每个 AIV 管 32 heads、每 K128 中的 64 行 KV。

1. 在 paged cache 中解析行、gather 到 UB，写 GM `kv_transfer`；raw SWA 的无效行明确置零。
2. MTE3 发布 KV_READY，MTE2 等 SCORE_READY。
3. 按 8 heads×512 读 score、mask 和旧 m/l，计算 online 新 max、alpha、exp、实际 K 的归约树和新 sum。
4. 概率 CAST_ROUND 到 BF16，再写 GM；m/l/alpha 同样写 GM。
5. MTE3 发 PROB_READY，MTE2 等 PV_READY；读 PV 与 m/l/alpha，计算旧 o×alpha+新 PV。
6. 完成全部块后将最终 FP32 m/l/o 写 GM，供独立归一化/inverse RoPE/publish 使用。

事件编号仅在本核作用域内理解：KV0、SCORE1、PROB2、PV3。改变流水必须核查双方 set/wait 次数、有效块跳过、首尾 drain、跨 query 槽回收与 MTE/FIX 完成语义。

## 5. Native 可借鉴的物理编排

当前 `sparse_attn_sharedkv_scfa_kernel.h:790` 的 PreloadPipeline 保留三个 RunInfo：当前、上一轮、上两轮。压缩路径先 Vec0 合并 KV；MM1 得 score；上一轮 Vec1 做 online softmax、MM2 做 PV；上两轮 Vec2 更新输出。**它用 K512 的数值块做流水，并不要求把 softmax 改成五个 K128 独立块。**

`scfa_block_cube.h:59` 附近明确 N128、K-L0=128、K-L1=256：

- Q/P L1 四个 64 KiB 槽，KV 三个 64 KiB 槽，总计 448 KiB。
- L0A/B 各两槽，L0C 两个 64 KiB 槽；用于搬运、MMA、FIX 重叠。
- raw SWA 的分页地址可由 Cube 直接 DataCopyPA 读取，不经 AIV→GM 的合并中转。
- 压缩 TopK 通过 AIV 处理索引和合并，有 UB ping-pong 及跨核事件。
- PV 输出沿 N128 分割；同一 N 输出沿原候选 K 顺序累加。

`scfa_block_vector.h:421` 的 SoftmaxFlashV2 输入 actualColumnCount 与旧 max/sum；482 附近概率 CAST_ROUND；854 附近 BF16 最终结果 CAST_RINT。仅从这一 header 不能穷尽 AscendC 内置 SoftmaxFlashV2 的全部归约微指令；不能据源码注释就替代既有 bit 对拍。

## 6. Nal 速度机制中，哪些不能直接照搬

Nal K128 三槽流水、QK 提前两拍、PV 输出 N128 和 FIX 双累加器是明确的物理实现差异。源码还把一次完整 token 的五个块铺平成 tick 流，跨 query 不完全排空。

但其数值路径同时不同：每个 K128 自己取 max、exp、BF16 rint、PV，之后用 alpha/beta 合并。TND/Native 需要在原 K512 边界决定 max/概率及 PV 累加，且概率使用 round。**不能只将 Nal 的 ATTN_K_TILE 改回 512，就推断其 pipeline 与精度版等价。**

Nal 一次 32 heads×128 的 softmax score 大小，与当前 8 heads×512 同为 16 KiB FP32。若直接把 TND head tile 从 8 改 32，score、exp、mask 等载体各自可能变 64 KiB，还要同时保留 64 KiB running output，必须实际审查 UB 生命周期。不能按“减少四个循环”认定合法或更快。

## 7. 单因素候选及门禁

这里的顺序是最小改动的验证建议，最终优先级由内部测量决定。

| 待测因素 | 首版只改变什么 | 保留什么 | 关键风险与门禁 |
| --- | --- | --- | --- |
| SWA Cube 实际 K128 extent | 仅 SWA QK/PV 计算有效片数；仍保留完整 score/prob 存储与同一数值块 | AIV gather/store、PV0 reload、K512 softmax 与原 round 不变 | 未写 score 尾部必须显式初始化或在 AIV 构建已定义零尾，禁止 stale/NaN 经 mask 泄漏；PV 省略零片对 signed-zero/FP32 累加的影响必须 Native bit 验证 |
| PV N128/K128 物理布局 | 同一 K512 内四个输出 N128 tile，保留各输出 K 遍历顺序 | online max/exp/概率 round、所有 cache/GM 输入不变 | 改变实际 K32→K128 硬件分组；数学同序仍非 bit 证明；L0C 双缓冲/FIX fence 与实际生成物门禁 |
| m/l/alpha 留 UB | 在同一 AIV 内保留 32×1 FP32 状态，移除中间 GM 往返 | 每个 8-head 原算式、原迭代顺序、最终 stats 发布不变 | loop-carried/assemble 物理 alias、signed-zero 与 tail；先查实际 UB 和 store/load 是否承担必要同步 |
| K512 软件预取 | 原 online 数值块上流水化 gather/QK/softmax/PV | 原 K512/max/归约/CAST_ROUND/PV 顺序、Native请求边界不变 | 当前464 KiB L1已紧；GM环形槽、合法有效块、两AIV握手、query切换/排空复杂，需单独设计而非复制 Nal tick |
| raw SWA 直接 Cube paged load | 消除 raw 的 AIV→GM→L1 中转 | 索引结果、无效行值、概率及数学边界不变 | DSL 现有 API 是否真正支持所需分页/跨页加载；可能引入更多标量控制或编译分块，先测搬运，不先重写 |

前两项的 static FLOPs 估算也不能替代实测：一条 query 在完整 SWA128+TopK512 时，当前 padded 两个 K512 的 QK+PV 约 134.22 MFLOP；只处理有效 128+512 行约 83.89 MFLOP。它只说明执行工作量存在减少空间，不等于总耗时可缩短 37.5%，更不证明 Cube 已经是瓶颈。

PV N128 路线也不自动减少 MMA 指令数量：当前一 K512 为 4 个逻辑 K128×各 4 个 K32；N128 路线为 4 个输出 N128×各 4 个 K128，按这个理想拆分都为 16 次 MMA。差异在 tile 形状、L0C 占用、数据移动和可重叠性，需要实际测量。

## 8. 内部测量应回答的问题

1. **先固定边界**：Native sparse op 返回归一化 BF16 attention，后续模型才 inverse RoPE；PTO helper 包含 inverse RoPE/publish。三方要么统一包含这些后处理，要么均在 inverse RoPE 之前取观测值，不能 attention-only 对完整 helper。
2. **先固定输入**：三方同 Q、真实 paged cache、TopK、位置和请求边界；BSH 仅均匀 S6 场景。短 query/混合 1～6 行只比较 Native/TND，不把额外 padding 算成等价性能测试。
3. **先无 profiler 测完整 root**：同卡 FULL graph，SK0/NZ2/确定性，交错重复，确认实际 PTO 路由、无 Native fallback、source identity 和 output bit 门禁。
4. **计算段**：可用冻结的连续 Q/KV/P 另根保持实际 MMA 次序测量，但只代表该计算根；必须检查物理 tile 一致，不能把少一次 gather 的新布局当原核纯计算。
5. **搬运段**：保留真实 page table、TopK 分布、无效槽及传输量。理想连续 memcpy 只给上限，不等于原 paged gather 的开销。
6. **同步段**：需可用的核内 marker/PMU/官方 profiler 证据；DFX task begin/end 只给活动跨度。纯 no-op event 环不等于真实负载下的等待；完整延迟减计算根延迟也不能精确得到“搬运+等待”，因为有重叠和不同调度。
7. **仪器开销**：核内 marker、PMU 采集另跑，不能把采样任务的耗时当正式无采样 replay 延迟；依赖图采集与 timing 分开。
8. **保留真实 TND**：Native query bounds 和 token_request 继续决定映射；按请求复用不意味着多个 query 的 TopK 相同，更不能恢复 t//6 的 request 推导。

已有 V6 DFX 的 QK/PV 活动跨度约 686.52～699.74 µs，包含两类核的计算、搬运和等待。它是 candidate-only 证据，**不是 Native/Nal 对应模块差值，也不能与其他 phase envelope 相加**。在新的内部测量结果到来之前，不认定上表任何项为主瓶颈。

## 9. 验证建议

- 本轮只读完成：实际调用边界、三份代码、TND实际生成 tile/L1 区间、数值差异、单因素风险已核。
- 下一步建议：先核可用测量工具的实际 API/二进制，再做保持数值不变的最小测量 root；每任务不超过 780 秒。
- 每个候选：先无设备 GCC/CCEC 与实际生成物审查；再 Native/旧 PTO/候选同输入首差停止。包括 SWA 尾部、短 K、负槽、±0、小值、poison、只读输入和 A/B/A 恢复。
- 有稳定单层收益后再做完整 CSA，并保留 T1、非等长 mixed、T144/T240 和真实模型 token 门禁。无稳定收益不合入。
