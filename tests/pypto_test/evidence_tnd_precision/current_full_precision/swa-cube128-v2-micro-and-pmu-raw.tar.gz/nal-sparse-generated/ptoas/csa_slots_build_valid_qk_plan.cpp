#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void csa_slots_build_valid_qk_plan(__gm__ int32_t* v1, __gm__ float* v2, __gm__ int32_t* v3, __gm__ int64_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ int32_t* v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int64_t v12, int32_t v13, int32_t v14) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v15 = 4;
  const int32_t v16 = 1;
  // pto: %c33280_i64
  const int64_t v17 = 33280;
  // pto: %c0_i64
  const int64_t v18 = 0;
  // pto: %c16384_i64
  const int64_t v19 = 16384;
  // pto: %c32768_i64
  const int64_t v20 = 32768;
  // pto: %c512_index
  const int64_t v21 = 512;
  // pto: %c1_index
  const int64_t v22 = 1;
  // pto: %c640_index
  const int64_t v23 = 640;
  // pto: %c16_index
  const int64_t v24 = 16;
  // pto: %c8_index
  const int64_t v25 = 8;
  // pto: %c128_index
  const int64_t v26 = 128;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %cst_11
  const float v28 = 1.0f;
  // pto: %cst_12
  const float v29 = 0.25f;
  // pto: %cst_13
  const float v30 = 0.0f;
  // pto: %cst_14
  const float v31 = 1.00000002E+20f;
  // pto: %c5_index
  const int64_t v32 = 5;
  // pto: %c192_index
  const int64_t v33 = 192;
  const int32_t v34 = 0;
  // pto: %c6_index
  const int64_t v35 = 6;
  // pto: %c32_index
  const int64_t v36 = 32;
  // pto: %cmp_sparse_indices_inline150__ssa_v0_view
  const int64_t v37 = 1;
  // pto: %cmp_sparse_indices_inline150__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %cmp_sparse_indices_inline150__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %cmp_sparse_indices_inline150__ssa_v0_view
  int64_t v40 = (int64_t) v9;
  // pto: %cmp_sparse_indices_inline150__ssa_v0_view
  int64_t v41 = v40 * v21;
  // pto: %cmp_sparse_indices_inline150__ssa_v0_view
  int64_t v42 = v39 * v41;
  // pto: %cmp_sparse_indices_inline150__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v43 = pto::Shape<1, 1, 1, -1, -1>(v37, v38, v39, v40, v21);
  // pto: %cmp_sparse_indices_inline150__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v44 = pto::Stride<-1, -1, -1, -1, -1>(v38 * v42, v42, v41, v21, v22);
  // pto: %cmp_sparse_indices_inline150__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v45 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v43, v44);
  // pto: %sparse_bias_inline152__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %sparse_bias_inline152__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %sparse_bias_inline152__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %sparse_bias_inline152__ssa_v0_view
  int64_t v49 = (int64_t) v9;
  // pto: %sparse_bias_inline152__ssa_v0_view
  int64_t v50 = v49 * v23;
  // pto: %sparse_bias_inline152__ssa_v0_view
  int64_t v51 = v48 * v50;
  // pto: %sparse_bias_inline152__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v52 = pto::Shape<1, 1, 1, -1, -1>(v46, v47, v48, v49, v23);
  // pto: %sparse_bias_inline152__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v53 = pto::Stride<-1, -1, -1, -1, -1>(v47 * v51, v51, v50, v23, v22);
  // pto: %sparse_bias_inline152__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v54 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v52, v53);
  // pto: %topk__ssa_v0_view
  const int64_t v55 = 1;
  // pto: %topk__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %topk__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %topk__ssa_v0_view
  int64_t v58 = (int64_t) v10;
  // pto: %topk__ssa_v0_view
  int64_t v59 = v58 * v21;
  // pto: %topk__ssa_v0_view
  int64_t v60 = v57 * v59;
  // pto: %topk__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v61 = pto::Shape<1, 1, 1, -1, -1>(v55, v56, v57, v58, v21);
  // pto: %topk__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v62 = pto::Stride<-1, -1, -1, -1, -1>(v56 * v60, v60, v59, v21, v22);
  // pto: %topk__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v63 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v61, v62);
  // pto: %positions__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %positions__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %positions__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %positions__ssa_v0_view
  int64_t v67 = (int64_t) v10;
  // pto: %positions__ssa_v0_view
  int64_t v68 = v67 * v22;
  // pto: %positions__ssa_v0_view
  int64_t v69 = v66 * v68;
  // pto: %positions__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v70 = pto::Shape<1, 1, 1, -1, -1>(v64, v65, v66, v67, v22);
  // pto: %positions__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v71 = pto::Stride<-1, -1, -1, -1, -1>(v65 * v69, v69, v68, v22, (int64_t) v10);
  // pto: %positions__ssa_v0_view
  GlobalTensor<int64_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v72 = GlobalTensor<int64_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v4, v70, v71);
  // pto: %v_valid_inline69__phi_v5
  Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v73 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
  // pto: %v_valid_inline69__phi_v5
  uint64_t v74 = (uint64_t) v18;
  TASSIGN(v73, v74);
  // pto: %v_valid_inline69__phi_v4
  Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v75 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
  // pto: %v_valid_inline69__phi_v4
  uint64_t v76 = (uint64_t) v18;
  TASSIGN(v75, v76);
  // pto: %plan_worker_inline142__ssa_v0, %36
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  for (int64_t v77 = (int64_t) ((uint64_t) ((int64_t) v13) * (uint64_t) v25); v77 < v9; v77 += v26) {
    // pto: %37
    ;
    int64_t v78 = (int64_t) ((uint64_t) v9 - (uint64_t) v77);
    // pto: %38
    ;
    int64_t v79 = v78 < v25 ? v78 : v25;
    // pto: %t__tile
    ;
    Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v80 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v21);
    // pto: %t__tile
    ;
    uint64_t v81 = (uint64_t) v17;
    TASSIGN(v80, v81);
    // pto: %39
    ;
    int64_t v82 = v77 < v27 ? v27 : v77;
    // pto: %topk__ssa_v0_pview
    ;
    const int64_t v83 = 0;
    // pto: %topk__ssa_v0_pview
    ;
    __gm__ int32_t* v84 = PTOAS__GLOBAL_TENSOR_DATA(v63);
    // pto: %topk__ssa_v0_pview
    ;
    const int64_t v85 = 1;
    // pto: %topk__ssa_v0_pview
    ;
    const int64_t v86 = 1;
    // pto: %topk__ssa_v0_pview
    ;
    const int64_t v87 = 1;
    // pto: %topk__ssa_v0_pview
    ;
    int64_t v88 = v79 * v21;
    // pto: %topk__ssa_v0_pview
    ;
    int64_t v89 = v87 * v88;
    // pto: %topk__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v90 = pto::Shape<1, 1, 1, -1, 512>(v85, v86, v87, v79, v21);
    // pto: %topk__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v91 = pto::Stride<-1, -1, -1, -1, -1>(v86 * v89, v89, v88, v21, v22);
    // pto: %topk__ssa_v0_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v92 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v84 + (v83 + v82 * v21 + v27 * v22), v90, v91);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v80, v92);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %c_raw_tile_inline104__tile
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v21);
    // pto: %c_raw_tile_inline104__tile
    ;
    uint64_t v94 = (uint64_t) v17;
    TASSIGN(v93, v94);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v95 = RoundMode::CAST_ROUND;
    SaturationMode v96 = SaturationMode::ON;
    TCVT(v93, v80, v95, v96);
    // pto: %0
    ;
    Tile<TileType::Vec, int64_t, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Vec, int64_t, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v22);
    // pto: %0
    ;
    uint64_t v98 = (uint64_t) v18;
    TASSIGN(v97, v98);
    // pto: %positions__ssa_v0_pview
    ;
    int64_t v99 = (int64_t) v10;
    // pto: %positions__ssa_v0_pview
    ;
    const int64_t v100 = 0;
    // pto: %positions__ssa_v0_pview
    ;
    __gm__ int64_t* v101 = PTOAS__GLOBAL_TENSOR_DATA(v72);
    // pto: %positions__ssa_v0_pview
    ;
    const int64_t v102 = 1;
    // pto: %positions__ssa_v0_pview
    ;
    const int64_t v103 = 1;
    // pto: %positions__ssa_v0_pview
    ;
    const int64_t v104 = 1;
    // pto: %positions__ssa_v0_pview
    ;
    int64_t v105 = v79 * v22;
    // pto: %positions__ssa_v0_pview
    ;
    int64_t v106 = v104 * v105;
    // pto: %positions__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 1> v107 = pto::Shape<1, 1, 1, -1, 1>(v102, v103, v104, v79, v22);
    // pto: %positions__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v108 = pto::Stride<-1, -1, -1, -1, -1>(v103 * v106, v106, v105, v22, v99);
    // pto: %positions__ssa_v0_pview
    ;
    GlobalTensor<int64_t, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v109 = GlobalTensor<int64_t, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v101 + (v100 + v82 * v22 + v27 * v99), v107, v108);
    TLOAD(v97, v109);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %c_pos_inline73__rm_a0_tmp_v0
    ;
    Tile<TileType::Vec, int64_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Vec, int64_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v79);
    // pto: %c_pos_inline73__rm_a0_tmp_v0
    ;
    uint64_t v111 = (uint64_t) v18;
    TASSIGN(v110, v111);
    // pto: %c_pos_inline73__row_major_tmp_v1
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v112 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v79);
    // pto: %c_pos_inline73__row_major_tmp_v1
    ;
    uint64_t v113 = (uint64_t) v18;
    TASSIGN(v112, v113);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    RoundMode v114 = RoundMode::CAST_ROUND;
    SaturationMode v115 = SaturationMode::ON;
    TCVT(v112, v110, v114, v115);
    // pto: %c_pos_inline73__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v116 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v22);
    // pto: %c_pos_inline73__tile
    ;
    uint64_t v117 = (uint64_t) v18;
    TASSIGN(v116, v117);
    // pto: %t__rm_a0_tmp_v2
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v79);
    // pto: %t__rm_a0_tmp_v2
    ;
    uint64_t v119 = (uint64_t) v18;
    TASSIGN(v118, v119);
    // pto: %t__row_major_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v120 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v79);
    // pto: %t__row_major_tmp_v3
    ;
    uint64_t v121 = (uint64_t) v18;
    TASSIGN(v120, v121);
    pipe_barrier(PIPE_V);
    TADDS(v120, v118, v28);
    // pto: %1
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v122 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v22);
    // pto: %1
    ;
    uint64_t v123 = (uint64_t) v18;
    TASSIGN(v122, v123);
    // pto: %t__rm_a0_tmp_v4
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v79);
    // pto: %t__rm_a0_tmp_v4
    ;
    uint64_t v125 = (uint64_t) v18;
    TASSIGN(v124, v125);
    // pto: %t__row_major_tmp_v5
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v126 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v79);
    // pto: %t__row_major_tmp_v5
    ;
    uint64_t v127 = (uint64_t) v18;
    TASSIGN(v126, v127);
    pipe_barrier(PIPE_V);
    TMULS(v126, v124, v29);
    // pto: %2
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v128 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v22);
    // pto: %2
    ;
    uint64_t v129 = (uint64_t) v18;
    TASSIGN(v128, v129);
    // pto: %t__rm_a0_tmp_v6
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v79);
    // pto: %t__rm_a0_tmp_v6
    ;
    uint64_t v131 = (uint64_t) v18;
    TASSIGN(v130, v131);
    // pto: %t__row_major_tmp_v7
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v79);
    // pto: %t__row_major_tmp_v7
    ;
    uint64_t v133 = (uint64_t) v18;
    TASSIGN(v132, v133);
    pipe_barrier(PIPE_V);
    RoundMode v134 = RoundMode::CAST_TRUNC;
    SaturationMode v135 = SaturationMode::ON;
    TCVT(v132, v130, v134, v135);
    // pto: %3
    ;
    Tile<TileType::Vec, int32_t, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Vec, int32_t, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v22);
    // pto: %3
    ;
    uint64_t v137 = (uint64_t) v18;
    TASSIGN(v136, v137);
    // pto: %c_pos_q_inline157__rm_a0_tmp_v8
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v79);
    // pto: %c_pos_q_inline157__rm_a0_tmp_v8
    ;
    uint64_t v139 = (uint64_t) v18;
    TASSIGN(v138, v139);
    // pto: %c_pos_q_inline157__row_major_tmp_v9
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v140 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v79);
    // pto: %c_pos_q_inline157__row_major_tmp_v9
    ;
    uint64_t v141 = (uint64_t) v19;
    TASSIGN(v140, v141);
    pipe_barrier(PIPE_V);
    RoundMode v142 = RoundMode::CAST_ROUND;
    SaturationMode v143 = SaturationMode::ON;
    TCVT(v140, v138, v142, v143);
    // pto: %c_pos_q_inline157__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v144 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v22);
    // pto: %c_pos_q_inline157__tile
    ;
    uint64_t v145 = (uint64_t) v19;
    TASSIGN(v144, v145);
    // pto: %4
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v146 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v21);
    // pto: %4
    ;
    uint64_t v147 = (uint64_t) v18;
    TASSIGN(v146, v147);
    pipe_barrier(PIPE_V);
    TEXPANDS(v146, v28);
    // pto: %c_upper_b_inline108__tile
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v148 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v21);
    // pto: %c_upper_b_inline108__tile
    ;
    uint64_t v149 = (uint64_t) v18;
    TASSIGN(v148, v149);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v148, v146, v144);
    // pto: %5
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v150 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v21);
    // pto: %5
    ;
    uint64_t v151 = (uint64_t) v19;
    TASSIGN(v150, v151);
    pipe_barrier(PIPE_V);
    TADDS(v150, v93, v28);
    // pto: %6
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v152 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v21);
    // pto: %6
    ;
    uint64_t v153 = (uint64_t) v19;
    TASSIGN(v152, v153);
    pipe_barrier(PIPE_V);
    TMAXS(v152, v150, v30);
    // pto: %c_ge_tile_inline139__tile
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v154 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v21);
    // pto: %c_ge_tile_inline139__tile
    ;
    uint64_t v155 = (uint64_t) v19;
    TASSIGN(v154, v155);
    pipe_barrier(PIPE_V);
    TMINS(v154, v152, v28);
    // pto: %7
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v156 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v21);
    // pto: %7
    ;
    uint64_t v157 = (uint64_t) v18;
    TASSIGN(v156, v157);
    TSUB(v156, v148, v93);
    // pto: %8
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v158 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v21);
    // pto: %8
    ;
    uint64_t v159 = (uint64_t) v18;
    TASSIGN(v158, v159);
    pipe_barrier(PIPE_V);
    TMAXS(v158, v156, v30);
    // pto: %c_lt_tile_inline114__tile
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v160 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v21);
    // pto: %c_lt_tile_inline114__tile
    ;
    uint64_t v161 = (uint64_t) v18;
    TASSIGN(v160, v161);
    pipe_barrier(PIPE_V);
    TMINS(v160, v158, v28);
    // pto: %c_mask_tile_inline118__tile
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v162 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v21);
    // pto: %c_mask_tile_inline118__tile
    ;
    uint64_t v163 = (uint64_t) v18;
    TASSIGN(v162, v163);
    pipe_barrier(PIPE_V);
    TMUL(v162, v154, v160);
    // pto: %9
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v164 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v21);
    // pto: %9
    ;
    uint64_t v165 = (uint64_t) v17;
    TASSIGN(v164, v165);
    TADDS(v164, v93, v28);
    // pto: %10
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v166 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v21);
    // pto: %10
    ;
    uint64_t v167 = (uint64_t) v17;
    TASSIGN(v166, v167);
    pipe_barrier(PIPE_V);
    TMUL(v166, v162, v164);
    // pto: %c_out_tile_inline116__tile
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v168 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v21);
    // pto: %c_out_tile_inline116__tile
    ;
    uint64_t v169 = (uint64_t) v17;
    TASSIGN(v168, v169);
    pipe_barrier(PIPE_V);
    TSUBS(v168, v166, v28);
    // pto: %11
    ;
    Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v170 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v21);
    // pto: %11
    ;
    uint64_t v171 = (uint64_t) v19;
    TASSIGN(v170, v171);
    pipe_barrier(PIPE_V);
    RoundMode v172 = RoundMode::CAST_ROUND;
    SaturationMode v173 = SaturationMode::ON;
    TCVT(v170, v168, v172, v173);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    v170.SetValidShape(v79, v21);
    // pto: %cmp_sparse_indices_inline150__iter_v1_pview
    ;
    const int64_t v174 = 0;
    // pto: %cmp_sparse_indices_inline150__iter_v1_pview
    ;
    __gm__ int32_t* v175 = PTOAS__GLOBAL_TENSOR_DATA(v45);
    // pto: %cmp_sparse_indices_inline150__iter_v1_pview
    ;
    const int64_t v176 = 1;
    // pto: %cmp_sparse_indices_inline150__iter_v1_pview
    ;
    const int64_t v177 = 1;
    // pto: %cmp_sparse_indices_inline150__iter_v1_pview
    ;
    const int64_t v178 = 1;
    // pto: %cmp_sparse_indices_inline150__iter_v1_pview
    ;
    int64_t v179 = v79 * v21;
    // pto: %cmp_sparse_indices_inline150__iter_v1_pview
    ;
    int64_t v180 = v178 * v179;
    // pto: %cmp_sparse_indices_inline150__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v181 = pto::Shape<1, 1, 1, -1, 512>(v176, v177, v178, v79, v21);
    // pto: %cmp_sparse_indices_inline150__iter_v1_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v182 = pto::Stride<-1, -1, -1, -1, -1>(v177 * v180, v180, v179, v21, v22);
    // pto: %cmp_sparse_indices_inline150__iter_v1_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v183 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v175 + (v174 + v82 * v21 + v27 * v22), v181, v182);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v183, v170);
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    // pto: %13
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v21);
    // pto: %13
    ;
    uint64_t v185 = (uint64_t) v17;
    TASSIGN(v184, v185);
    pipe_barrier(PIPE_V);
    TMINS(v184, v168, v30);
    // pto: %14
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v186 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v21);
    // pto: %14
    ;
    uint64_t v187 = (uint64_t) v17;
    TASSIGN(v186, v187);
    pipe_barrier(PIPE_V);
    TMULS(v186, v184, v31);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    v186.SetValidShape(v79, v21);
    // pto: %sparse_bias_inline152__iter_v1_pview
    ;
    const int64_t v188 = 0;
    // pto: %sparse_bias_inline152__iter_v1_pview
    ;
    __gm__ float* v189 = PTOAS__GLOBAL_TENSOR_DATA(v54);
    // pto: %sparse_bias_inline152__iter_v1_pview
    ;
    const int64_t v190 = 1;
    // pto: %sparse_bias_inline152__iter_v1_pview
    ;
    const int64_t v191 = 1;
    // pto: %sparse_bias_inline152__iter_v1_pview
    ;
    const int64_t v192 = 1;
    // pto: %sparse_bias_inline152__iter_v1_pview
    ;
    int64_t v193 = v79 * v23;
    // pto: %sparse_bias_inline152__iter_v1_pview
    ;
    int64_t v194 = v192 * v193;
    // pto: %sparse_bias_inline152__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v195 = pto::Shape<1, 1, 1, -1, 512>(v190, v191, v192, v79, v21);
    // pto: %sparse_bias_inline152__iter_v1_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v196 = pto::Stride<-1, -1, -1, -1, -1>(v191 * v194, v194, v193, v23, v22);
    // pto: %sparse_bias_inline152__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v197 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v189 + (v188 + v82 * v23 + v26 * v22), v195, v196);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    TSTORE(v197, v186);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    for (int64_t v198 = v22; v198 < v32; v198 += v22) {
      // pto: %16
      ;
      Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v26);
      // pto: %16
      ;
      uint64_t v200 = (uint64_t) v18;
      TASSIGN(v199, v200);
      // pto: %slice_view
      ;
      Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79);
      // pto: %43, %44, %slice_view
      ;
      uint64_t v202 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v198 - (uint64_t) v22) * (uint64_t) v26) * (uint64_t) v15);
      TASSIGN(v201, v202);
      // pto: %tmp_tile
      ;
      Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v203 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v26);
      // pto: %tmp_tile
      ;
      uint64_t v204 = (uint64_t) v17;
      TASSIGN(v203, v204);
      // pto: %c_blk_valid_inline200__tile
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v22);
      // pto: %c_blk_valid_inline200__tile
      ;
      uint64_t v206 = (uint64_t) v19;
      TASSIGN(v205, v206);
      wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      TROWMAX(v205, v201, v203);
      set_flag(PIPE_V, PIPE_S, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
      for (int64_t v207 = v27; v207 < v79; v207 += v22) {
        // pto: %45
        ;
        float v208 = v205.GetValue(v207);
        // pto: %46
        ;
        int32_t v209 = (int32_t) v208;
        // pto: %47, %48, %49
        ;
        int64_t v210 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v77 + (uint64_t) v207) * (uint64_t) v24) + (uint64_t) v198);
        (v5)[v210] = v209;
      };
      set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    };
    // pto: %t__ci_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v33);
    // pto: %t__ci_tmp_v0
    ;
    uint64_t v212 = (uint64_t) v17;
    TASSIGN(v211, v212);
    // pto: %17
    ;
    Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
    // pto: %17
    ;
    uint64_t v214 = (uint64_t) v18;
    TASSIGN(v213, v214);
    // pto: %ci_tmp_view
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215;
    TRESHAPE(v215, v211);
    // pto: %ci_dst_view
    ;
    Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v216;
    TRESHAPE(v216, v213);
    pipe_barrier(PIPE_V);
    TCI<Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v216, v34, v215);
    // pto: %v_columns_inline140__tile
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
    // pto: %v_columns_inline140__tile
    ;
    uint64_t v218 = (uint64_t) v18;
    TASSIGN(v217, v218);
    pipe_barrier(PIPE_V);
    RoundMode v219 = RoundMode::CAST_ROUND;
    SaturationMode v220 = SaturationMode::ON;
    TCVT(v217, v213, v219, v220);
    // pto: %v_len_col_inline156__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v221 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v22);
    // pto: %v_len_col_inline156__tile
    ;
    uint64_t v222 = (uint64_t) v19;
    TASSIGN(v221, v222);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    for (int64_t v223 = v27; v223 < v25; v223 += v22) {
      // pto: %50
      ;
      int64_t v224 = (int64_t) ((uint64_t) v79 - (uint64_t) v22);
      // pto: %51
      ;
      int64_t v225 = v223 < v224 ? v223 : v224;
      // pto: %52
      ;
      int64_t v226 = (int64_t) ((uint64_t) v77 + (uint64_t) v225);
      // pto: %54
      ;
      int64_t v227 = (v4)[v226];
      // pto: %58
      ;
      int64_t v228 = (int64_t) ((uint64_t) v227 + (uint64_t) v22);
      // pto: %59
      ;
      int64_t v229 = v228 < v26 ? v228 : v26;
      // pto: %53, %60
      ;
      int32_t v230 = (v6)[v226 / v35];
      // pto: %61, %62, %v_len_value_inline89__phi_v2
      ;
      int64_t v231 = (int64_t) v230 <= v27 ? v27 : v229;
      // pto: %64, %65
      ;
      float v232 = (float) ((int32_t) v231);
      v221.SetValue(v223, v232);
    };
    set_flag(PIPE_S, PIPE_V, EVENT_ID1);
    // pto: %18
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v26);
    // pto: %18
    ;
    uint64_t v234 = (uint64_t) v17;
    TASSIGN(v233, v234);
    TEXPANDS(v233, v28);
    // pto: %v_col_tile_inline83__tile
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v26);
    // pto: %v_col_tile_inline83__tile
    ;
    uint64_t v236 = (uint64_t) v17;
    TASSIGN(v235, v236);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v235, v233, v217);
    // pto: %19
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v237 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v26);
    // pto: %19
    ;
    uint64_t v238 = (uint64_t) v17;
    TASSIGN(v237, v238);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
    TROWEXPANDSUB(v237, v235, v221);
    // pto: %20
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v239 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v26);
    // pto: %20
    ;
    uint64_t v240 = (uint64_t) v17;
    TASSIGN(v239, v240);
    pipe_barrier(PIPE_V);
    TNEG(v239, v237);
    // pto: %21
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v241 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v26);
    // pto: %21
    ;
    uint64_t v242 = (uint64_t) v17;
    TASSIGN(v241, v242);
    pipe_barrier(PIPE_V);
    TMAXS(v241, v239, v30);
    // pto: %v_valid_tile_inline82__tile
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v26);
    // pto: %v_valid_tile_inline82__tile
    ;
    uint64_t v244 = (uint64_t) v17;
    TASSIGN(v243, v244);
    pipe_barrier(PIPE_V);
    TMINS(v243, v241, v28);
    // pto: %22
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v245 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v26);
    // pto: %22
    ;
    uint64_t v246 = (uint64_t) v17;
    TASSIGN(v245, v246);
    pipe_barrier(PIPE_V);
    TSUBS(v245, v243, v28);
    // pto: %23
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v247 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v26);
    // pto: %23
    ;
    uint64_t v248 = (uint64_t) v17;
    TASSIGN(v247, v248);
    pipe_barrier(PIPE_V);
    TMULS(v247, v245, v31);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
    v247.SetValidShape(v79, v26);
    // pto: %sparse_bias_inline152__tile_pview
    ;
    const int64_t v249 = 0;
    // pto: %sparse_bias_inline152__tile_pview
    ;
    __gm__ float* v250 = PTOAS__GLOBAL_TENSOR_DATA(v54);
    // pto: %sparse_bias_inline152__tile_pview
    ;
    const int64_t v251 = 1;
    // pto: %sparse_bias_inline152__tile_pview
    ;
    const int64_t v252 = 1;
    // pto: %sparse_bias_inline152__tile_pview
    ;
    const int64_t v253 = 1;
    // pto: %sparse_bias_inline152__tile_pview
    ;
    int64_t v254 = v79 * v23;
    // pto: %sparse_bias_inline152__tile_pview
    ;
    int64_t v255 = v253 * v254;
    // pto: %sparse_bias_inline152__tile_pview
    ;
    pto::Shape<1, 1, 1, -1, 128> v256 = pto::Shape<1, 1, 1, -1, 128>(v251, v252, v253, v79, v26);
    // pto: %sparse_bias_inline152__tile_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v257 = pto::Stride<-1, -1, -1, -1, -1>(v252 * v255, v255, v254, v23, v22);
    // pto: %sparse_bias_inline152__tile_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v258 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v250 + (v249 + v82 * v23 + v27 * v22), v256, v257);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
    TSTORE(v258, v247);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    for (int64_t v259 = v27; v259 < v79; v259 += v22) {
      // pto: %70
      ;
      int64_t v260 = (int64_t) ((uint64_t) v77 + (uint64_t) v259);
      // pto: %71
      ;
      int64_t v261 = v260 / v35;
      // pto: %72
      ;
      int64_t v262 = (v4)[v260];
      // pto: %76
      ;
      int64_t v263 = (int64_t) ((uint64_t) v262 + (uint64_t) v22);
      // pto: %77
      ;
      int64_t v264 = v263 < v26 ? v263 : v26;
      // pto: %78
      ;
      int32_t v265 = (v6)[v261];
      // pto: %79, %80, %v_length_inline78__phi_v2
      ;
      int64_t v266 = (int64_t) v265 <= v27 ? v27 : v264;
      // pto: %82, %83
      ;
      int64_t v267 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v262 - (uint64_t) v266) + (uint64_t) v22);
      // pto: %84
      ;
      int64_t v268 = v267 % v36;
      // pto: %v_block_valid_inline128__rv_v2
      ;
      int32_t v269;
      // pto: %v_has_hole_inline77__rv_v2
      ;
      int32_t v270;
      v269 = v34;
      v270 = v34;
      for (int64_t v271 = v27; v271 < v32; v271 += v22) {
        // pto: %87, %88
        ;
        int64_t v272 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v271 * (uint64_t) v36) - (uint64_t) v268);
        // pto: %89
        ;
        int64_t v273 = v272 < v27 ? v27 : v272;
        // pto: %92
        ;
        int64_t v274 = (int64_t) ((uint64_t) v272 + (uint64_t) v36);
        // pto: %93
        ;
        int64_t v275 = v274 < v266 ? v274 : v266;
        // pto: %94
        ;
        // pto: %v_block_valid_inline128__phi_v5
        ;
        int32_t v276;
        // pto: %v_has_hole_inline77__phi_v5
        ;
        int32_t v277;
        if (v273 < v275) {
          // pto: %97, %98, %95, %96, %v_page_inline71__tile
          ;
          int32_t v278 = (v7)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v261 * (uint64_t) v12) + (uint64_t) ((int64_t) ((uint64_t) v267 + (uint64_t) v273) / v36))];
          // pto: %99, %100
          ;
          bool v279 = (int64_t) v278 >= v27;
          // pto: %v_block_valid_inline128__phi_v4
          ;
          int32_t v280 = v279 ? v16 : v269;
          // pto: %v_has_hole_inline77__phi_v4
          ;
          int32_t v281 = v279 ? v270 : v16;
          v276 = v280;
          v277 = v281;
        } else {
          v276 = v269;
          v277 = v270;
        };
        v269 = v276;
        v270 = v277;
      };
      // pto: %103
      ;
      int64_t v282 = (int64_t) ((uint64_t) v260 * (uint64_t) v24);
      (v5)[v282] = v269;
      // pto: %105
      ;
      int64_t v283 = (int64_t) v270;
      // pto: %106
      ;
      if (v283 == v22) {
        // pto: %t__ci_tmp_v1
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v284 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v33);
        // pto: %t__ci_tmp_v1
        ;
        uint64_t v285 = (uint64_t) v17;
        TASSIGN(v284, v285);
        // pto: %25
        ;
        Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
        // pto: %25
        ;
        uint64_t v287 = (uint64_t) v18;
        TASSIGN(v286, v287);
        // pto: %107
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v288;
        TRESHAPE(v288, v284);
        // pto: %108
        ;
        Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v289;
        TRESHAPE(v289, v286);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        TCI<Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v289, v34, v288);
        // pto: %v_columns_row_inline107__tile
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
        // pto: %v_columns_row_inline107__tile
        ;
        uint64_t v291 = (uint64_t) v17;
        TASSIGN(v290, v291);
        pipe_barrier(PIPE_V);
        RoundMode v292 = RoundMode::CAST_ROUND;
        SaturationMode v293 = SaturationMode::ON;
        TCVT(v290, v286, v292, v293);
        // pto: %v_valid_inline69__tile
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v294 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
        // pto: %v_valid_inline69__tile
        ;
        uint64_t v295 = (uint64_t) v18;
        TASSIGN(v294, v295);
        pipe_barrier(PIPE_V);
        TEXPANDS(v294, v30);
        for (int64_t v296 = v27; v296 < v32; v296 += v22) {
          // pto: %109, %110
          ;
          int64_t v297 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v296 * (uint64_t) v36) - (uint64_t) v268);
          // pto: %111
          ;
          int64_t v298 = v297 < v27 ? v27 : v297;
          // pto: %114
          ;
          int64_t v299 = (int64_t) ((uint64_t) v297 + (uint64_t) v36);
          // pto: %115
          ;
          int64_t v300 = v299 < v266 ? v299 : v266;
          // pto: %116
          ;
          if (v298 < v300) {
            // pto: %119, %120, %117, %118, %v_hole_page_inline61__tile
            ;
            int32_t v301 = (v7)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v261 * (uint64_t) v12) + (uint64_t) ((int64_t) ((uint64_t) v267 + (uint64_t) v298) / v36))];
            // pto: %121, %122
            ;
            if ((int64_t) v301 >= v27) {
              // pto: %123, %124
              ;
              float v302 = (float) ((int32_t) v298);
              // pto: %125, %126
              ;
              float v303 = (float) ((int32_t) v300);
              // pto: %26
              ;
              Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v304 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
              // pto: %26
              ;
              uint64_t v305 = (uint64_t) v19;
              TASSIGN(v304, v305);
              pipe_barrier(PIPE_V);
              TSUBS(v304, v290, v302);
              // pto: %27
              ;
              Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
              // pto: %27
              ;
              uint64_t v307 = (uint64_t) v19;
              TASSIGN(v306, v307);
              pipe_barrier(PIPE_V);
              TADDS(v306, v304, v28);
              // pto: %28
              ;
              Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v308 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
              // pto: %28
              ;
              uint64_t v309 = (uint64_t) v19;
              TASSIGN(v308, v309);
              pipe_barrier(PIPE_V);
              TMAXS(v308, v306, v30);
              // pto: %v_ge_inline94__tile
              ;
              Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v310 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
              // pto: %v_ge_inline94__tile
              ;
              uint64_t v311 = (uint64_t) v19;
              TASSIGN(v310, v311);
              pipe_barrier(PIPE_V);
              TMINS(v310, v308, v28);
              // pto: %29
              ;
              Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
              // pto: %29
              ;
              uint64_t v313 = (uint64_t) v20;
              TASSIGN(v312, v313);
              TNEG(v312, v290);
              // pto: %30
              ;
              Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v314 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
              // pto: %30
              ;
              uint64_t v315 = (uint64_t) v20;
              TASSIGN(v314, v315);
              pipe_barrier(PIPE_V);
              TADDS(v314, v312, v303);
              // pto: %31
              ;
              Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v316 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
              // pto: %31
              ;
              uint64_t v317 = (uint64_t) v20;
              TASSIGN(v316, v317);
              pipe_barrier(PIPE_V);
              TMAXS(v316, v314, v30);
              // pto: %v_lt_inline126__tile
              ;
              Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v318 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
              // pto: %v_lt_inline126__tile
              ;
              uint64_t v319 = (uint64_t) v20;
              TASSIGN(v318, v319);
              pipe_barrier(PIPE_V);
              TMINS(v318, v316, v28);
              // pto: %32
              ;
              Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v320 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
              // pto: %32
              ;
              uint64_t v321 = (uint64_t) v19;
              TASSIGN(v320, v321);
              pipe_barrier(PIPE_V);
              TMUL(v320, v310, v318);
              // pto: %33
              ;
              Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v322 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
              // pto: %33
              ;
              uint64_t v323 = (uint64_t) v18;
              TASSIGN(v322, v323);
              pipe_barrier(PIPE_V);
              TADD(v322, v294, v320);
            };
          };
        };
        // pto: %34
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v324 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
        // pto: %34
        ;
        uint64_t v325 = (uint64_t) v17;
        TASSIGN(v324, v325);
        pipe_barrier(PIPE_V);
        TSUBS(v324, v294, v28);
        // pto: %35
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v326 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v22, v26);
        // pto: %35
        ;
        uint64_t v327 = (uint64_t) v17;
        TASSIGN(v326, v327);
        pipe_barrier(PIPE_V);
        TMULS(v326, v324, v31);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        // pto: %128
        ;
        int64_t v328 = v260 < v27 ? v27 : v260;
        // pto: %sparse_bias_inline152__iter_v7_pview
        ;
        __gm__ float* v329 = PTOAS__GLOBAL_TENSOR_DATA(v54);
        // pto: %sparse_bias_inline152__iter_v7_pview
        ;
        const int64_t v330 = 0;
        // pto: %sparse_bias_inline152__iter_v7_pview
        ;
        const int64_t v331 = 640;
        // pto: %sparse_bias_inline152__iter_v7_pview
        ;
        pto::Shape<1, 1, 1, 1, 128> v332 = pto::Shape<1, 1, 1, 1, 128>();
        // pto: %sparse_bias_inline152__iter_v7_pview
        ;
        pto::Stride<640, 640, 640, 640, 1> v333 = pto::Stride<640, 640, 640, 640, 1>();
        // pto: %sparse_bias_inline152__iter_v7_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<640, 640, 640, 640, 1>, pto::Layout::ND> v334 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<640, 640, 640, 640, 1>, pto::Layout::ND>(v329 + (v330 + v328 * v331), v332, v333);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        TSTORE(v334, v326);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      };
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  #endif // __DAV_VEC__

  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}