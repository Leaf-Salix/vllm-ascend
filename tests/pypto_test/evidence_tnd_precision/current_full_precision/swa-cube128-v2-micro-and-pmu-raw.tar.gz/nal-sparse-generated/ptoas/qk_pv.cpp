#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qk_pv_aic(__gm__ int64_t* v1, __gm__ bfloat16_t* v2, __gm__ int32_t* v3, __gm__ bfloat16_t* v4, __gm__ float* v5, __gm__ bfloat16_t* v6, __gm__ float* v7, __gm__ float* v8, __gm__ int64_t* v9, __gm__ int32_t* v10, __gm__ bfloat16_t* v11, __gm__ int32_t* v12, __gm__ int32_t* v13, __gm__ bfloat16_t* v14, __gm__ float* v15, __gm__ float* v16, __gm__ float* v17, __gm__ float* v18, __gm__ float* v19, __gm__ bfloat16_t* v20, int64_t v21, int64_t v22, int64_t v23, int64_t v24, int64_t v25, int64_t v26, int64_t v27, int64_t v28, int64_t v29, int32_t v30, int32_t v31) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v32 = 32;
  // pto: %c0_i64
  const int64_t v33 = 0;
  // pto: %c65536_i64
  const int64_t v34 = 65536;
  // pto: %c16384_i64
  const int64_t v35 = 16384;
  // pto: %c32768_i64
  const int64_t v36 = 32768;
  // pto: %c458752_i64
  const int64_t v37 = 458752;
  // pto: %c512_index
  const int64_t v38 = 512;
  // pto: %c1_index
  const int64_t v39 = 1;
  // pto: %c16_index
  const int64_t v40 = 16;
  // pto: %c9216_index
  const int64_t v41 = 9216;
  // pto: %c4608_index
  const int64_t v42 = 4608;
  // pto: %c128_index
  const int64_t v43 = 128;
  // pto: %c64_index
  const int64_t v44 = 64;
  // pto: %c384_index
  const int64_t v45 = 384;
  // pto: %c23_index
  const int64_t v46 = 23;
  // pto: %c24_index
  const int64_t v47 = 24;
  // pto: %c5_index
  const int64_t v48 = 5;
  // pto: %c0_index
  const int64_t v49 = 0;
  // pto: %c2_index
  const int64_t v50 = 2;
  // pto: %c3_index
  const int64_t v51 = 3;
  // pto: %c256_index
  const int64_t v52 = 256;
  // pto: %cn128_index
  const int64_t v53 = -128;
  // pto: %q_flat_inline179__ssa_v0_view
  const int64_t v54 = 1;
  // pto: %q_flat_inline179__ssa_v0_view
  const int64_t v55 = 1;
  // pto: %q_flat_inline179__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %q_flat_inline179__ssa_v0_view
  int64_t v57 = (int64_t) v22;
  // pto: %q_flat_inline179__ssa_v0_view
  int64_t v58 = v57 * v38;
  // pto: %q_flat_inline179__ssa_v0_view
  int64_t v59 = v56 * v58;
  // pto: %q_flat_inline179__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v60 = pto::Shape<1, 1, 1, -1, -1>(v54, v55, v56, v57, v38);
  // pto: %q_flat_inline179__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v61 = pto::Stride<-1, -1, -1, -1, -1>(v55 * v59, v59, v58, v38, v39);
  // pto: %q_flat_inline179__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v62 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v60, v61);
  // pto: %kv_transfer_inline112__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %kv_transfer_inline112__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %kv_transfer_inline112__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %kv_transfer_inline112__ssa_v0_view
  int64_t v66 = v41 * v38;
  // pto: %kv_transfer_inline112__ssa_v0_view
  int64_t v67 = v65 * v66;
  // pto: %kv_transfer_inline112__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v68 = pto::Shape<1, 1, 1, -1, -1>(v63, v64, v65, v41, v38);
  // pto: %kv_transfer_inline112__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v69 = pto::Stride<-1, -1, -1, -1, -1>(v64 * v67, v67, v66, v38, v39);
  // pto: %kv_transfer_inline112__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v70 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v68, v69);
  // pto: %score_transfer_inline187__ssa_v0_view
  const int64_t v71 = 1;
  // pto: %score_transfer_inline187__ssa_v0_view
  const int64_t v72 = 1;
  // pto: %score_transfer_inline187__ssa_v0_view
  const int64_t v73 = 1;
  // pto: %score_transfer_inline187__ssa_v0_view
  int64_t v74 = v42 * v43;
  // pto: %score_transfer_inline187__ssa_v0_view
  int64_t v75 = v73 * v74;
  // pto: %score_transfer_inline187__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v76 = pto::Shape<1, 1, 1, -1, -1>(v71, v72, v73, v42, v43);
  // pto: %score_transfer_inline187__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v77 = pto::Stride<-1, -1, -1, -1, -1>(v72 * v75, v75, v74, v43, v39);
  // pto: %score_transfer_inline187__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v78 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v76, v77);
  // pto: %probability_transfer_inline189__ssa_v0_view
  const int64_t v79 = 1;
  // pto: %probability_transfer_inline189__ssa_v0_view
  const int64_t v80 = 1;
  // pto: %probability_transfer_inline189__ssa_v0_view
  const int64_t v81 = 1;
  // pto: %probability_transfer_inline189__ssa_v0_view
  int64_t v82 = v42 * v43;
  // pto: %probability_transfer_inline189__ssa_v0_view
  int64_t v83 = v81 * v82;
  // pto: %probability_transfer_inline189__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v84 = pto::Shape<1, 1, 1, -1, -1>(v79, v80, v81, v42, v43);
  // pto: %probability_transfer_inline189__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v85 = pto::Stride<-1, -1, -1, -1, -1>(v80 * v83, v83, v82, v43, v39);
  // pto: %probability_transfer_inline189__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v86 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v84, v85);
  // pto: %pv_transfer_inline155__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %pv_transfer_inline155__ssa_v0_view
  const int64_t v88 = 1;
  // pto: %pv_transfer_inline155__ssa_v0_view
  const int64_t v89 = 1;
  // pto: %pv_transfer_inline155__ssa_v0_view
  int64_t v90 = v42 * v38;
  // pto: %pv_transfer_inline155__ssa_v0_view
  int64_t v91 = v89 * v90;
  // pto: %pv_transfer_inline155__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v92 = pto::Shape<1, 1, 1, -1, -1>(v87, v88, v89, v42, v38);
  // pto: %pv_transfer_inline155__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v93 = pto::Stride<-1, -1, -1, -1, -1>(v88 * v91, v91, v90, v38, v39);
  // pto: %pv_transfer_inline155__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v94 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v92, v93);
  // pto: %qk_l1_inline79__phi_v5
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v95 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v38);
  // pto: %qk_l1_inline79__phi_v5
  uint64_t v96 = (uint64_t) v34;
  TASSIGN(v95, v96);
  // pto: %qk_q_inline169__phi_v5
  Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v38);
  // pto: %qk_q_inline169__phi_v5
  uint64_t v98 = (uint64_t) v33;
  TASSIGN(v97, v98);
  // pto: %qk_q_inline169__phi_v4
  Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v99 = Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v38);
  // pto: %qk_q_inline169__phi_v4
  uint64_t v100 = (uint64_t) v33;
  TASSIGN(v99, v100);
  // pto: %qk_l1_inline79__phi_v4
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v38);
  // pto: %qk_l1_inline79__phi_v4
  uint64_t v102 = (uint64_t) v34;
  TASSIGN(v101, v102);
  // pto: %qk_core_inline134__ssa_v0
  int64_t v103 = (int64_t) v30;
  uint64_t v104 = reinterpret_cast<uint64_t>(v1);
  set_ffts_base_addr(v104);
  // pto: %3, %4, %5, %6
  int64_t v105 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v21 - (uint64_t) v103) + (uint64_t) v46) / v47) * (uint64_t) v48);
  // pto: %qk_q_inline169__ssa_v0
  Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v38);
  // pto: %qk_q_inline169__ssa_v0
  uint64_t v107 = (uint64_t) v33;
  TASSIGN(v106, v107);
  // pto: %qk_l1_inline79__ssa_v0
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v45, v38);
  // pto: %qk_l1_inline79__ssa_v0
  uint64_t v109 = (uint64_t) v34;
  TASSIGN(v108, v109);
  // pto: %7
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  for (int64_t v110 = v49; v110 < ((int64_t) ((uint64_t) v105 + (uint64_t) v50)); v110 += v39) {
    // pto: %8
    ;
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    if (v110 < v105) {
      // pto: %9
      ;
      int64_t v111 = v110 % v48;
      // pto: %12, %10, %11
      ;
      int64_t v112 = (int64_t) ((uint64_t) v103 + (uint64_t) ((int64_t) (uint64_t) (v110 / v48) * (uint64_t) v47));
      // pto: %13
      ;
      if (v111 == v49) {
        // pto: %gather_row_view
        ;
        Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, 64, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v113;
        // pto: %gather_row_view
        ;
        uint64_t v114 = (uint64_t) v33;
        TASSIGN(v113, v114);
        // pto: %14
        ;
        int64_t v115 = (int64_t) ((uint64_t) v112 * (uint64_t) v44);
        // pto: %15
        ;
        int64_t v116 = v115 < v49 ? v49 : v115;
        // pto: %q_flat_inline179__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v117 = PTOAS__GLOBAL_TENSOR_DATA(v62);
        // pto: %q_flat_inline179__ssa_v0_pview
        ;
        const int64_t v118 = 0;
        // pto: %q_flat_inline179__ssa_v0_pview
        ;
        const int64_t v119 = 512;
        // pto: %q_flat_inline179__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 64, 512> v120 = pto::Shape<1, 1, 1, 64, 512>();
        // pto: %q_flat_inline179__ssa_v0_pview
        ;
        pto::Stride<32768, 32768, 32768, 512, 1> v121 = pto::Stride<32768, 32768, 32768, 512, 1>();
        // pto: %q_flat_inline179__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v122 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v117 + (v118 + v116 * v119), v120, v121);
        TLOAD(v113, v122);
      };
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %flat_offset_mul, %flat_offset, %t__tile
      ;
      int32_t v123 = (v3)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v112 * (uint64_t) v40) + (uint64_t) v111)];
      // pto: %16, %17
      ;
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      if ((int64_t) v123 > v49) {
        // pto: %19
        ;
        int64_t v124 = v110 % v51;
        // pto: %18, %20
        ;
        int64_t v125 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v103 * (uint64_t) v51) + (uint64_t) v124);
        // pto: %21
        ;
        int64_t v126 = (int64_t) ((uint64_t) v125 * (uint64_t) v43);
        // pto: %22
        ;
        int64_t v127 = (int64_t) ((uint64_t) v125 * (uint64_t) v44);
        int32_t v128 = (int32_t) v49;
        wait_flag_dev(v128);
        // pto: %24
        ;
        int64_t v129 = (int64_t) ((uint64_t) v124 * (uint64_t) v43);
        // pto: %25
        ;
        Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, 128, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v130;
        // pto: %25
        ;
        uint64_t v131 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v129 * (uint64_t) v32) + (uint64_t) v34);
        TASSIGN(v130, v131);
        // pto: %26
        ;
        int64_t v132 = v126 < v49 ? v49 : v126;
        // pto: %kv_transfer_inline112__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v133 = PTOAS__GLOBAL_TENSOR_DATA(v70);
        // pto: %kv_transfer_inline112__ssa_v0_pview
        ;
        const int64_t v134 = 0;
        // pto: %kv_transfer_inline112__ssa_v0_pview
        ;
        const int64_t v135 = 512;
        // pto: %kv_transfer_inline112__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 128, 512> v136 = pto::Shape<1, 1, 1, 128, 512>();
        // pto: %kv_transfer_inline112__ssa_v0_pview
        ;
        pto::Stride<65536, 65536, 65536, 512, 1> v137 = pto::Stride<65536, 65536, 65536, 512, 1>();
        // pto: %kv_transfer_inline112__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND> v138 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND>(v133 + (v134 + v132 * v135), v136, v137);
        TLOAD(v130, v138);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %qk_l1_t_inline204__ssa_v0
        ;
        Tile<TileType::Mat, bfloat16_t, 512, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v139 = Tile<TileType::Mat, bfloat16_t, 512, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v38, v45);
        // pto: %qk_l1_t_inline204__ssa_v0
        ;
        uint64_t v140 = (uint64_t) v34;
        TASSIGN(v139, v140);
        // pto: %qk_scores_inline92__ssa_v0_l0_init
        ;
        Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v43);
        // pto: %qk_scores_inline92__ssa_v0_l0_init
        ;
        uint64_t v142 = (uint64_t) v33;
        TASSIGN(v141, v142);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        for (int64_t v143 = v49; v143 < v38; v143 += v52) {
          // pto: %qk_scores_inline92__ssa_v0_l0_a
          ;
          Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v144 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v43);
          // pto: %qk_scores_inline92__ssa_v0_l0_a
          ;
          uint64_t v145 = (uint64_t) v33;
          TASSIGN(v144, v145);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          pipe_barrier(PIPE_MTE1);
          uint16_t v146 = static_cast<uint16_t>(v49);
          uint16_t v147 = static_cast<uint16_t>(v143);
          TEXTRACT(v144, v99, v146, v147);
          // pto: %qk_scores_inline92__ssa_v0_l0_b
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v148 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v43, v43);
          // pto: %qk_scores_inline92__ssa_v0_l0_b
          ;
          uint64_t v149 = (uint64_t) v33;
          TASSIGN(v148, v149);
          uint16_t v150 = static_cast<uint16_t>(v143);
          uint16_t v151 = static_cast<uint16_t>(v129);
          TEXTRACT(v148, v139, v150, v151);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          // pto: %0
          ;
          Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v152 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v43);
          // pto: %0
          ;
          uint64_t v153 = (uint64_t) v35;
          TASSIGN(v152, v153);
          // pto: %27
          ;
          int64_t v154 = (int64_t) ((uint64_t) v143 + (uint64_t) v43);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          uint16_t v155 = static_cast<uint16_t>(v49);
          uint16_t v156 = static_cast<uint16_t>(v154);
          TEXTRACT(v152, v99, v155, v156);
          // pto: %1
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v43, v43);
          // pto: %1
          ;
          uint64_t v158 = (uint64_t) v36;
          TASSIGN(v157, v158);
          uint16_t v159 = static_cast<uint16_t>(v154);
          uint16_t v160 = static_cast<uint16_t>(v129);
          TEXTRACT(v157, v139, v159, v160);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          // pto: %29
          ;
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          if (v143 == v49) {
            pipe_barrier(PIPE_M);
            TMATMUL(v141, v144, v148);
          } else {
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v141, v141, v144, v148);
          };
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          // pto: %30
          ;
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
          if (v143 == v53) {
            pipe_barrier(PIPE_M);
            TMATMUL(v141, v152, v157);
          } else {
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v141, v141, v152, v157);
          };
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        };
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        // pto: %31
        ;
        int64_t v161 = v127 < v49 ? v49 : v127;
        // pto: %score_transfer_inline187__ssa_v0_pview
        ;
        __gm__ float* v162 = PTOAS__GLOBAL_TENSOR_DATA(v78);
        // pto: %score_transfer_inline187__ssa_v0_pview
        ;
        const int64_t v163 = 0;
        // pto: %score_transfer_inline187__ssa_v0_pview
        ;
        const int64_t v164 = 128;
        // pto: %score_transfer_inline187__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 64, 128> v165 = pto::Shape<1, 1, 1, 64, 128>();
        // pto: %score_transfer_inline187__ssa_v0_pview
        ;
        pto::Stride<8192, 8192, 8192, 128, 1> v166 = pto::Stride<8192, 8192, 8192, 128, 1>();
        // pto: %score_transfer_inline187__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND> v167 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND>(v162 + (v163 + v161 * v164), v165, v166);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
        pipe_barrier(PIPE_FIX);
        TSTORE(v167, v141);
        uint16_t v168 = getFFTSMsg(FFTS_MODE_VAL, v39);
        ffts_cross_core_sync(PIPE_FIX, v168);
      };
    };
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
    // pto: %32
    ;
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
    if (v110 >= v50) {
      // pto: %33
      ;
      int64_t v169 = (int64_t) ((uint64_t) v110 - (uint64_t) v50);
      // pto: %37, %35, %36, %39, %40, %34, %38
      ;
      int32_t v170 = (v3)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v103 + (uint64_t) ((int64_t) (uint64_t) (v169 / v48) * (uint64_t) v47)) * (uint64_t) v40) + (uint64_t) (v169 % v48))];
      // pto: %41, %42
      ;
      if ((int64_t) v170 > v49) {
        // pto: %44
        ;
        int64_t v171 = v169 % v51;
        // pto: %43, %45, %46
        ;
        int64_t v172 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v103 * (uint64_t) v51) + (uint64_t) v171) * (uint64_t) v44);
        int32_t v173 = (int32_t) v50;
        wait_flag_dev(v173);
        // pto: %pv_probability_inline158__ssa_v0
        ;
        Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v43);
        // pto: %pv_probability_inline158__ssa_v0
        ;
        uint64_t v175 = (uint64_t) v37;
        TASSIGN(v174, v175);
        // pto: %47
        ;
        int64_t v176 = v172 < v49 ? v49 : v172;
        // pto: %probability_transfer_inline189__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v177 = PTOAS__GLOBAL_TENSOR_DATA(v86);
        // pto: %probability_transfer_inline189__ssa_v0_pview
        ;
        const int64_t v178 = 0;
        // pto: %probability_transfer_inline189__ssa_v0_pview
        ;
        const int64_t v179 = 128;
        // pto: %probability_transfer_inline189__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 64, 128> v180 = pto::Shape<1, 1, 1, 64, 128>();
        // pto: %probability_transfer_inline189__ssa_v0_pview
        ;
        pto::Stride<8192, 8192, 8192, 128, 1> v181 = pto::Stride<8192, 8192, 8192, 128, 1>();
        // pto: %probability_transfer_inline189__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND> v182 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND>(v177 + (v178 + v176 * v179), v180, v181);
        TLOAD(v174, v182);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        // pto: %49
        ;
        int64_t v183 = (int64_t) ((uint64_t) v171 * (uint64_t) v43);
        // pto: %pv_probability_left_inline151__ssa_v0
        ;
        Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v184 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v43);
        // pto: %pv_probability_left_inline151__ssa_v0
        ;
        uint64_t v185 = (uint64_t) v33;
        TASSIGN(v184, v185);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        pipe_barrier(PIPE_MTE1);
        TMOV(v184, v174);
        // pto: %pv_first_right_inline211__ssa_v0
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v186 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v43, v43);
        // pto: %pv_first_right_inline211__ssa_v0
        ;
        uint64_t v187 = (uint64_t) v33;
        TASSIGN(v186, v187);
        uint16_t v188 = static_cast<uint16_t>(v183);
        uint16_t v189 = static_cast<uint16_t>(v49);
        TEXTRACT(v186, v95, v188, v189);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %pv_previous_inline188__ssa_v0
        ;
        Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v190 = Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v43);
        // pto: %pv_previous_inline188__ssa_v0
        ;
        uint64_t v191 = (uint64_t) v33;
        TASSIGN(v190, v191);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        TMATMUL(v190, v184, v186);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        // pto: %pv_next_right_inline113__ssa_v0
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v43, v43);
        // pto: %pv_next_right_inline113__ssa_v0
        ;
        uint64_t v193 = (uint64_t) v33;
        TASSIGN(v192, v193);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        uint16_t v194 = static_cast<uint16_t>(v183);
        uint16_t v195 = static_cast<uint16_t>(v43);
        TEXTRACT(v192, v95, v194, v195);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        // pto: %pv_current_inline195__ssa_v0
        ;
        Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v43);
        // pto: %pv_current_inline195__ssa_v0
        ;
        uint64_t v197 = (uint64_t) v36;
        TASSIGN(v196, v197);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
        TMATMUL(v196, v184, v192);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        // pto: %pv_transfer_inline155__ssa_v0_pview
        ;
        __gm__ float* v198 = PTOAS__GLOBAL_TENSOR_DATA(v94);
        // pto: %pv_transfer_inline155__ssa_v0_pview
        ;
        const int64_t v199 = 0;
        // pto: %pv_transfer_inline155__ssa_v0_pview
        ;
        const int64_t v200 = 512;
        // pto: %pv_transfer_inline155__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 64, 128> v201 = pto::Shape<1, 1, 1, 64, 128>();
        // pto: %pv_transfer_inline155__ssa_v0_pview
        ;
        pto::Stride<32768, 32768, 32768, 512, 1> v202 = pto::Stride<32768, 32768, 32768, 512, 1>();
        // pto: %pv_transfer_inline155__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v203 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v198 + (v199 + v176 * v200), v201, v202);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        pipe_barrier(PIPE_FIX);
        TSTORE(v203, v190);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        // pto: %pv_previous_inline188__ssa_v1
        ;
        Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v204 = Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v43);
        // pto: %pv_previous_inline188__ssa_v1
        ;
        uint64_t v205 = (uint64_t) v36;
        TASSIGN(v204, v205);
        // pto: %pv_next_right_inline113__ssa_v1
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v206 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v43, v43);
        // pto: %pv_next_right_inline113__ssa_v1
        ;
        uint64_t v207 = (uint64_t) v33;
        TASSIGN(v206, v207);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        uint16_t v208 = static_cast<uint16_t>(v183);
        uint16_t v209 = static_cast<uint16_t>(v52);
        TEXTRACT(v206, v95, v208, v209);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        // pto: %pv_current_inline195__ssa_v1
        ;
        Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v43);
        // pto: %pv_current_inline195__ssa_v1
        ;
        uint64_t v211 = (uint64_t) v33;
        TASSIGN(v210, v211);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        TMATMUL(v210, v184, v206);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        // pto: %52
        ;
        __gm__ float* v212 = PTOAS__GLOBAL_TENSOR_DATA(v94);
        // pto: %52
        ;
        const int64_t v213 = 128;
        // pto: %52
        ;
        const int64_t v214 = 512;
        // pto: %52
        ;
        pto::Shape<1, 1, 1, 64, 128> v215 = pto::Shape<1, 1, 1, 64, 128>();
        // pto: %52
        ;
        pto::Stride<32768, 32768, 32768, 512, 1> v216 = pto::Stride<32768, 32768, 32768, 512, 1>();
        // pto: %52
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v217 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v212 + (v213 + v176 * v214), v215, v216);
        pipe_barrier(PIPE_FIX);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        TSTORE(v217, v204);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
        // pto: %pv_previous_inline188__ssa_v2
        ;
        Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v43);
        // pto: %pv_previous_inline188__ssa_v2
        ;
        uint64_t v219 = (uint64_t) v33;
        TASSIGN(v218, v219);
        // pto: %pv_next_right_inline113__ssa_v2
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v43, v43);
        // pto: %pv_next_right_inline113__ssa_v2
        ;
        uint64_t v221 = (uint64_t) v33;
        TASSIGN(v220, v221);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
        uint16_t v222 = static_cast<uint16_t>(v183);
        uint16_t v223 = static_cast<uint16_t>(v45);
        TEXTRACT(v220, v95, v222, v223);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        // pto: %pv_current_inline195__ssa_v2
        ;
        Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v43);
        // pto: %pv_current_inline195__ssa_v2
        ;
        uint64_t v225 = (uint64_t) v36;
        TASSIGN(v224, v225);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
        TMATMUL(v224, v184, v220);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        // pto: %54
        ;
        __gm__ float* v226 = PTOAS__GLOBAL_TENSOR_DATA(v94);
        // pto: %54
        ;
        const int64_t v227 = 256;
        // pto: %54
        ;
        const int64_t v228 = 512;
        // pto: %54
        ;
        pto::Shape<1, 1, 1, 64, 128> v229 = pto::Shape<1, 1, 1, 64, 128>();
        // pto: %54
        ;
        pto::Stride<32768, 32768, 32768, 512, 1> v230 = pto::Stride<32768, 32768, 32768, 512, 1>();
        // pto: %54
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v231 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v226 + (v227 + v176 * v228), v229, v230);
        pipe_barrier(PIPE_FIX);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
        TSTORE(v231, v218);
        // pto: %pv_previous_inline188__ssa_v3
        ;
        Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v43);
        // pto: %pv_previous_inline188__ssa_v3
        ;
        uint64_t v233 = (uint64_t) v36;
        TASSIGN(v232, v233);
        // pto: %56
        ;
        __gm__ float* v234 = PTOAS__GLOBAL_TENSOR_DATA(v94);
        // pto: %56
        ;
        const int64_t v235 = 384;
        // pto: %56
        ;
        const int64_t v236 = 512;
        // pto: %56
        ;
        pto::Shape<1, 1, 1, 64, 128> v237 = pto::Shape<1, 1, 1, 64, 128>();
        // pto: %56
        ;
        pto::Stride<32768, 32768, 32768, 512, 1> v238 = pto::Stride<32768, 32768, 32768, 512, 1>();
        // pto: %56
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v239 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v234 + (v235 + v176 * v236), v237, v238);
        pipe_barrier(PIPE_FIX);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        TSTORE(v239, v232);
        uint16_t v240 = getFFTSMsg(FFTS_MODE_VAL, v51);
        ffts_cross_core_sync(PIPE_FIX, v240);
      };
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  uint64_t v241 = reinterpret_cast<uint64_t>(v1);
  set_ffts_base_addr(v241);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void qk_pv_aiv(__gm__ int64_t* v1, __gm__ bfloat16_t* v2, __gm__ int32_t* v3, __gm__ bfloat16_t* v4, __gm__ float* v5, __gm__ bfloat16_t* v6, __gm__ float* v7, __gm__ float* v8, __gm__ int64_t* v9, __gm__ int32_t* v10, __gm__ bfloat16_t* v11, __gm__ int32_t* v12, __gm__ int32_t* v13, __gm__ bfloat16_t* v14, __gm__ float* v15, __gm__ float* v16, __gm__ float* v17, __gm__ float* v18, __gm__ float* v19, __gm__ bfloat16_t* v20, int64_t v21, int64_t v22, int64_t v23, int64_t v24, int64_t v25, int64_t v26, int64_t v27, int64_t v28, int64_t v29, int32_t v30, int32_t v31, int32_t v32) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v33 = 53504;
  const int64_t v34 = 20736;
  const int64_t v35 = 1024;
  // pto: %c69888_i64
  const int64_t v36 = 69888;
  // pto: %c4352_i64
  const int64_t v37 = 4352;
  // pto: %c37120_i64
  const int64_t v38 = 37120;
  // pto: %c0_i64
  const int64_t v39 = 0;
  // pto: %c4096_i64
  const int64_t v40 = 4096;
  // pto: %c4224_i64
  const int64_t v41 = 4224;
  // pto: %c135680_i64
  const int64_t v42 = 135680;
  // pto: %c168448_i64
  const int64_t v43 = 168448;
  // pto: %c173056_i64
  const int64_t v44 = 173056;
  // pto: %c135424_i64
  const int64_t v45 = 135424;
  // pto: %c135552_i64
  const int64_t v46 = 135552;
  // pto: %c177152_i64
  const int64_t v47 = 177152;
  // pto: %c172544_i64
  const int64_t v48 = 172544;
  // pto: %c172800_i64
  const int64_t v49 = 172800;
  const int64_t v50 = 78080;
  // pto: %c512_index
  const int64_t v51 = 512;
  // pto: %c1_index
  const int64_t v52 = 1;
  // pto: %c16_index
  const int64_t v53 = 16;
  // pto: %c9216_index
  const int64_t v54 = 9216;
  // pto: %c4608_index
  const int64_t v55 = 4608;
  // pto: %c128_index
  const int64_t v56 = 128;
  // pto: %c64_index
  const int64_t v57 = 64;
  // pto: %c640_index
  const int64_t v58 = 640;
  // pto: %c384_index
  const int64_t v59 = 384;
  // pto: %c3072_index
  const int64_t v60 = 3072;
  // pto: %c4096_index
  const int64_t v61 = 4096;
  // pto: %c23_index
  const int64_t v62 = 23;
  // pto: %c24_index
  const int64_t v63 = 24;
  // pto: %c5_index
  const int64_t v64 = 5;
  // pto: %c32_index
  const int64_t v65 = 32;
  // pto: %c192_index
  const int64_t v66 = 192;
  // pto: %c0_i32
  const int32_t v67 = 0;
  // pto: %c2_i32
  const int32_t v68 = 2;
  // pto: %c449_i32
  const int32_t v69 = 449;
  // pto: %c512_i32
  const int32_t v70 = 512;
  // pto: %c1024_index
  const int64_t v71 = 1024;
  // pto: %c0_index
  const int64_t v72 = 0;
  // pto: %cst_37
  const float v73 = 0.0f;
  // pto: %c256_index
  const int64_t v74 = 256;
  const int64_t v75 = 3;
  // pto: %c6_index
  const int64_t v76 = 6;
  // pto: %cst_41
  const bfloat16_t v77 = 0.0f;
  // pto: %c96_index
  const int64_t v78 = 96;
  // pto: %c160_index
  const int64_t v79 = 160;
  // pto: %c144_index
  const int64_t v80 = 144;
  // pto: %cst_45
  const float v81 = 0.0441941731f;
  // pto: %c2_index
  const int64_t v82 = 2;
  // pto: %c4_index
  const int64_t v83 = 4;
  // pto: %c8192_index
  const int64_t v84 = 8192;
  // pto: %c448_index
  const int64_t v85 = 448;
  // pto: %c8_index
  const int64_t v86 = 8;
  // pto: %kv_transfer_inline112__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %kv_transfer_inline112__ssa_v0_view
  const int64_t v88 = 1;
  // pto: %kv_transfer_inline112__ssa_v0_view
  const int64_t v89 = 1;
  // pto: %kv_transfer_inline112__ssa_v0_view
  int64_t v90 = v54 * v51;
  // pto: %kv_transfer_inline112__ssa_v0_view
  int64_t v91 = v89 * v90;
  // pto: %kv_transfer_inline112__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v92 = pto::Shape<1, 1, 1, -1, -1>(v87, v88, v89, v54, v51);
  // pto: %kv_transfer_inline112__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v93 = pto::Stride<-1, -1, -1, -1, -1>(v88 * v91, v91, v90, v51, v52);
  // pto: %kv_transfer_inline112__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v94 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v92, v93);
  // pto: %score_transfer_inline187__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %score_transfer_inline187__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %score_transfer_inline187__ssa_v0_view
  const int64_t v97 = 1;
  // pto: %score_transfer_inline187__ssa_v0_view
  int64_t v98 = v55 * v56;
  // pto: %score_transfer_inline187__ssa_v0_view
  int64_t v99 = v97 * v98;
  // pto: %score_transfer_inline187__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v100 = pto::Shape<1, 1, 1, -1, -1>(v95, v96, v97, v55, v56);
  // pto: %score_transfer_inline187__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v101 = pto::Stride<-1, -1, -1, -1, -1>(v96 * v99, v99, v98, v56, v52);
  // pto: %score_transfer_inline187__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v102 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v100, v101);
  // pto: %probability_transfer_inline189__ssa_v0_view
  const int64_t v103 = 1;
  // pto: %probability_transfer_inline189__ssa_v0_view
  const int64_t v104 = 1;
  // pto: %probability_transfer_inline189__ssa_v0_view
  const int64_t v105 = 1;
  // pto: %probability_transfer_inline189__ssa_v0_view
  int64_t v106 = v55 * v56;
  // pto: %probability_transfer_inline189__ssa_v0_view
  int64_t v107 = v105 * v106;
  // pto: %probability_transfer_inline189__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v108 = pto::Shape<1, 1, 1, -1, -1>(v103, v104, v105, v55, v56);
  // pto: %probability_transfer_inline189__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v109 = pto::Stride<-1, -1, -1, -1, -1>(v104 * v107, v107, v106, v56, v52);
  // pto: %probability_transfer_inline189__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v110 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v108, v109);
  // pto: %pv_transfer_inline155__ssa_v0_view
  const int64_t v111 = 1;
  // pto: %pv_transfer_inline155__ssa_v0_view
  const int64_t v112 = 1;
  // pto: %pv_transfer_inline155__ssa_v0_view
  const int64_t v113 = 1;
  // pto: %pv_transfer_inline155__ssa_v0_view
  int64_t v114 = v55 * v51;
  // pto: %pv_transfer_inline155__ssa_v0_view
  int64_t v115 = v113 * v114;
  // pto: %pv_transfer_inline155__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v116 = pto::Shape<1, 1, 1, -1, -1>(v111, v112, v113, v55, v51);
  // pto: %pv_transfer_inline155__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v117 = pto::Stride<-1, -1, -1, -1, -1>(v112 * v115, v115, v114, v51, v52);
  // pto: %pv_transfer_inline155__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v118 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v116, v117);
  // pto: %attn_sink_col_inline181__ssa_v0_view
  const int64_t v119 = 1;
  // pto: %attn_sink_col_inline181__ssa_v0_view
  const int64_t v120 = 1;
  // pto: %attn_sink_col_inline181__ssa_v0_view
  const int64_t v121 = 1;
  // pto: %attn_sink_col_inline181__ssa_v0_view
  int64_t v122 = v57 * v52;
  // pto: %attn_sink_col_inline181__ssa_v0_view
  int64_t v123 = v121 * v122;
  // pto: %attn_sink_col_inline181__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v124 = pto::Shape<1, 1, 1, -1, -1>(v119, v120, v121, v57, v52);
  // pto: %attn_sink_col_inline181__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v125 = pto::Stride<-1, -1, -1, -1, -1>(v120 * v123, v123, v122, v52, v57);
  // pto: %attn_sink_col_inline181__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v126 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v8, v124, v125);
  // pto: %293
  int64_t v127 = (int64_t) ((uint64_t) v27 * (uint64_t) v65);
  // pto: %ori_kv_flat_inline67__ssa_v1_view
  const int64_t v128 = 1;
  // pto: %ori_kv_flat_inline67__ssa_v1_view
  const int64_t v129 = 1;
  // pto: %ori_kv_flat_inline67__ssa_v1_view
  const int64_t v130 = 1;
  // pto: %ori_kv_flat_inline67__ssa_v1_view
  int64_t v131 = v127 * v51;
  // pto: %ori_kv_flat_inline67__ssa_v1_view
  int64_t v132 = v130 * v131;
  // pto: %ori_kv_flat_inline67__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v133 = pto::Shape<1, 1, 1, -1, -1>(v128, v129, v130, v127, v51);
  // pto: %ori_kv_flat_inline67__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v134 = pto::Stride<-1, -1, -1, -1, -1>(v129 * v132, v132, v131, v51, v52);
  // pto: %ori_kv_flat_inline67__ssa_v1_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v135 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v11, v133, v134);
  // pto: %294
  int64_t v136 = (int64_t) ((uint64_t) v29 * (uint64_t) v65);
  // pto: %cmp_kv_flat_inline127__ssa_v0_view
  const int64_t v137 = 1;
  // pto: %cmp_kv_flat_inline127__ssa_v0_view
  const int64_t v138 = 1;
  // pto: %cmp_kv_flat_inline127__ssa_v0_view
  const int64_t v139 = 1;
  // pto: %cmp_kv_flat_inline127__ssa_v0_view
  int64_t v140 = v136 * v51;
  // pto: %cmp_kv_flat_inline127__ssa_v0_view
  int64_t v141 = v139 * v140;
  // pto: %cmp_kv_flat_inline127__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v142 = pto::Shape<1, 1, 1, -1, -1>(v137, v138, v139, v136, v51);
  // pto: %cmp_kv_flat_inline127__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v143 = pto::Stride<-1, -1, -1, -1, -1>(v138 * v141, v141, v140, v51, v52);
  // pto: %cmp_kv_flat_inline127__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v144 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v142, v143);
  // pto: %sparse_bias_inline152__rv_v2_view
  const int64_t v145 = 1;
  // pto: %sparse_bias_inline152__rv_v2_view
  const int64_t v146 = 1;
  // pto: %sparse_bias_inline152__rv_v2_view
  const int64_t v147 = 1;
  // pto: %sparse_bias_inline152__rv_v2_view
  int64_t v148 = (int64_t) v23;
  // pto: %sparse_bias_inline152__rv_v2_view
  int64_t v149 = v148 * v58;
  // pto: %sparse_bias_inline152__rv_v2_view
  int64_t v150 = v147 * v149;
  // pto: %sparse_bias_inline152__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v151 = pto::Shape<1, 1, 1, -1, -1>(v145, v146, v147, v148, v58);
  // pto: %sparse_bias_inline152__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v152 = pto::Stride<-1, -1, -1, -1, -1>(v146 * v150, v150, v149, v58, v52);
  // pto: %sparse_bias_inline152__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v153 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v151, v152);
  // pto: %mi_transfer_inline190__ssa_v0_view
  const int64_t v154 = 1;
  // pto: %mi_transfer_inline190__ssa_v0_view
  const int64_t v155 = 1;
  // pto: %mi_transfer_inline190__ssa_v0_view
  const int64_t v156 = 1;
  // pto: %mi_transfer_inline190__ssa_v0_view
  int64_t v157 = v55 * v52;
  // pto: %mi_transfer_inline190__ssa_v0_view
  int64_t v158 = v156 * v157;
  // pto: %mi_transfer_inline190__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v159 = pto::Shape<1, 1, 1, -1, -1>(v154, v155, v156, v55, v52);
  // pto: %mi_transfer_inline190__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v160 = pto::Stride<-1, -1, -1, -1, -1>(v155 * v158, v158, v157, v52, v55);
  // pto: %mi_transfer_inline190__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v161 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v16, v159, v160);
  // pto: %li_transfer_inline121__ssa_v0_view
  const int64_t v162 = 1;
  // pto: %li_transfer_inline121__ssa_v0_view
  const int64_t v163 = 1;
  // pto: %li_transfer_inline121__ssa_v0_view
  const int64_t v164 = 1;
  // pto: %li_transfer_inline121__ssa_v0_view
  int64_t v165 = v55 * v52;
  // pto: %li_transfer_inline121__ssa_v0_view
  int64_t v166 = v164 * v165;
  // pto: %li_transfer_inline121__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v167 = pto::Shape<1, 1, 1, -1, -1>(v162, v163, v164, v55, v52);
  // pto: %li_transfer_inline121__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v168 = pto::Stride<-1, -1, -1, -1, -1>(v163 * v166, v166, v165, v52, v55);
  // pto: %li_transfer_inline121__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v169 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v17, v167, v168);
  // pto: %cos__ssa_v0_view
  const int64_t v170 = 1;
  // pto: %cos__ssa_v0_view
  const int64_t v171 = 1;
  // pto: %cos__ssa_v0_view
  const int64_t v172 = 1;
  // pto: %cos__ssa_v0_view
  int64_t v173 = (int64_t) v24;
  // pto: %cos__ssa_v0_view
  int64_t v174 = v173 * v57;
  // pto: %cos__ssa_v0_view
  int64_t v175 = v172 * v174;
  // pto: %cos__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v176 = pto::Shape<1, 1, 1, -1, -1>(v170, v171, v172, v173, v57);
  // pto: %cos__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v177 = pto::Stride<-1, -1, -1, -1, -1>(v171 * v175, v175, v174, v57, v52);
  // pto: %cos__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v178 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v18, v176, v177);
  // pto: %rope_sin_signed_inline153__ssa_v0_view
  const int64_t v179 = 1;
  // pto: %rope_sin_signed_inline153__ssa_v0_view
  const int64_t v180 = 1;
  // pto: %rope_sin_signed_inline153__ssa_v0_view
  const int64_t v181 = 1;
  // pto: %rope_sin_signed_inline153__ssa_v0_view
  int64_t v182 = v59 * v57;
  // pto: %rope_sin_signed_inline153__ssa_v0_view
  int64_t v183 = v181 * v182;
  // pto: %rope_sin_signed_inline153__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v184 = pto::Shape<1, 1, 1, -1, -1>(v179, v180, v181, v59, v57);
  // pto: %rope_sin_signed_inline153__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v185 = pto::Stride<-1, -1, -1, -1, -1>(v180 * v183, v183, v182, v57, v52);
  // pto: %rope_sin_signed_inline153__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v186 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v19, v184, v185);
  // pto: %packed__ssa_v0_view
  const int64_t v187 = 1;
  // pto: %packed__ssa_v0_view
  const int64_t v188 = 1;
  // pto: %packed__ssa_v0_view
  const int64_t v189 = 1;
  // pto: %packed__ssa_v0_view
  int64_t v190 = v60 * v61;
  // pto: %packed__ssa_v0_view
  int64_t v191 = v189 * v190;
  // pto: %packed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v192 = pto::Shape<1, 1, 1, -1, -1>(v187, v188, v189, v60, v61);
  // pto: %packed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v193 = pto::Stride<-1, -1, -1, -1, -1>(v188 * v191, v191, v190, v61, v52);
  // pto: %packed__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v194 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v20, v192, v193);
  // pto: %qk_kv_half_inline47__phi_v21
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v195 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v57, v51);
  // pto: %qk_kv_half_inline47__phi_v21
  uint64_t v196 = (uint64_t) v36;
  TASSIGN(v195, v196);
  // pto: %qk_kv_half_inline47__phi_v3
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v197 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v57, v51);
  // pto: %qk_kv_half_inline47__phi_v3
  uint64_t v198 = (uint64_t) v36;
  TASSIGN(v197, v198);
  // pto: %qk_kv_half_inline47__phi_v2
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v199 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v57, v51);
  // pto: %qk_kv_half_inline47__phi_v2
  uint64_t v200 = (uint64_t) v36;
  TASSIGN(v199, v200);
  // pto: %qk_kv_half_inline47__phi_v6
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v57, v51);
  // pto: %qk_kv_half_inline47__phi_v6
  uint64_t v202 = (uint64_t) v36;
  TASSIGN(v201, v202);
  // pto: %qk_kv_half_inline47__phi_v5
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v203 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v57, v51);
  // pto: %qk_kv_half_inline47__phi_v5
  uint64_t v204 = (uint64_t) v36;
  TASSIGN(v203, v204);
  // pto: %qk_kv_half_inline47__phi_v9
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v57, v51);
  // pto: %qk_kv_half_inline47__phi_v9
  uint64_t v206 = (uint64_t) v36;
  TASSIGN(v205, v206);
  // pto: %qk_kv_half_inline47__phi_v8
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v57, v51);
  // pto: %qk_kv_half_inline47__phi_v8
  uint64_t v208 = (uint64_t) v36;
  TASSIGN(v207, v208);
  // pto: %qk_kv_half_inline47__phi_v12
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v57, v51);
  // pto: %qk_kv_half_inline47__phi_v12
  uint64_t v210 = (uint64_t) v36;
  TASSIGN(v209, v210);
  // pto: %qk_kv_half_inline47__phi_v11
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v57, v51);
  // pto: %qk_kv_half_inline47__phi_v11
  uint64_t v212 = (uint64_t) v36;
  TASSIGN(v211, v212);
  // pto: %qk_kv_half_inline47__phi_v15
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v57, v51);
  // pto: %qk_kv_half_inline47__phi_v15
  uint64_t v214 = (uint64_t) v36;
  TASSIGN(v213, v214);
  // pto: %qk_kv_half_inline47__phi_v14
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v57, v51);
  // pto: %qk_kv_half_inline47__phi_v14
  uint64_t v216 = (uint64_t) v36;
  TASSIGN(v215, v216);
  // pto: %qk_kv_half_inline47__phi_v20
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v217 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v57, v51);
  // pto: %qk_kv_half_inline47__phi_v20
  uint64_t v218 = (uint64_t) v36;
  TASSIGN(v217, v218);
  // pto: %qk_kv_half_inline47__phi_v19
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v219 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v57, v51);
  // pto: %qk_kv_half_inline47__phi_v19
  uint64_t v220 = (uint64_t) v36;
  TASSIGN(v219, v220);
  // pto: %m_after_inline72__rv_v0
  Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v221 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
  // pto: %m_after_inline72__rv_v0
  uint64_t v222 = (uint64_t) v36;
  TASSIGN(v221, v222);
  // pto: %l_after_inline29__rv_v0
  Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v223 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
  // pto: %l_after_inline29__rv_v0
  uint64_t v224 = (uint64_t) v42;
  TASSIGN(v223, v224);
  // pto: %left_after_inline27__rv_v0
  Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v225 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v74);
  // pto: %left_after_inline27__rv_v0
  uint64_t v226 = (uint64_t) v37;
  TASSIGN(v225, v226);
  // pto: %right_after_inline162__rv_v0
  Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v74);
  // pto: %right_after_inline162__rv_v0
  uint64_t v228 = (uint64_t) v38;
  TASSIGN(v227, v228);
  // pto: %m_valid_inline100__rv_v0
  Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v229 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
  // pto: %m_valid_inline100__rv_v0
  uint64_t v230 = (uint64_t) v45;
  TASSIGN(v229, v230);
  // pto: %l_valid_inline26__rv_v0
  Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v231 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
  // pto: %l_valid_inline26__rv_v0
  uint64_t v232 = (uint64_t) v46;
  TASSIGN(v231, v232);
  // pto: %left_valid_inline198__rv_v0
  Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v233 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v74);
  // pto: %left_valid_inline198__rv_v0
  uint64_t v234 = (uint64_t) v37;
  TASSIGN(v233, v234);
  // pto: %right_valid_inline32__rv_v0
  Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v74);
  // pto: %right_valid_inline32__rv_v0
  uint64_t v236 = (uint64_t) v38;
  TASSIGN(v235, v236);
  // pto: %m_published_inline21__rv_v0
  Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v237 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
  // pto: %m_published_inline21__rv_v0
  uint64_t v238 = (uint64_t) v36;
  TASSIGN(v237, v238);
  // pto: %l_published_inline41__rv_v0
  Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v239 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
  // pto: %l_published_inline41__rv_v0
  uint64_t v240 = (uint64_t) v42;
  TASSIGN(v239, v240);
  // pto: %left_published_inline160__rv_v0
  Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v241 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v74);
  // pto: %left_published_inline160__rv_v0
  uint64_t v242 = (uint64_t) v37;
  TASSIGN(v241, v242);
  // pto: %right_published_inline20__rv_v0
  Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v74);
  // pto: %right_published_inline20__rv_v0
  uint64_t v244 = (uint64_t) v38;
  TASSIGN(v243, v244);
  // pto: %qk_core_inline134__ssa_v0
  int64_t v245 = (int64_t) v30;
  uint64_t v246 = reinterpret_cast<uint64_t>(v1);
  set_ffts_base_addr(v246);
  // pto: %3, %4, %5, %6
  int64_t v247 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) ((int64_t) (uint64_t) v21 - (uint64_t) v245) + (uint64_t) v62) / v63) * (uint64_t) v64);
  // pto: %qk_aiv_inline65__ssa_v0
  int64_t v248 = (int64_t) v32;
  uint64_t v249 = reinterpret_cast<uint64_t>(v1);
  set_ffts_base_addr(v249);
  // pto: %7
  int64_t v250 = (int64_t) ((uint64_t) v248 * (uint64_t) v65);
  // pto: %8
  int64_t v251 = (int64_t) ((uint64_t) v248 * (uint64_t) v57);
  // pto: %m_idx_inline214__ci_tmp_v0
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v252 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v66);
  // pto: %m_idx_inline214__ci_tmp_v0
  uint64_t v253 = (uint64_t) v36;
  TASSIGN(v252, v253);
  // pto: %m_idx_inline214__ssa_v0
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v254 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v57);
  // pto: %m_idx_inline214__ssa_v0
  uint64_t v255 = (uint64_t) v37;
  TASSIGN(v254, v255);
  // pto: %ci_tmp_view
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v256;
  TRESHAPE(v256, v252);
  // pto: %ci_dst_view
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v257;
  TRESHAPE(v257, v254);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v257, v67, v256);
  // pto: %m_rem_tmp_inline185__ssa_v0
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v258 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v57);
  // pto: %m_rem_tmp_inline185__ssa_v0
  uint64_t v259 = (uint64_t) v36;
  TASSIGN(v258, v259);
  // pto: %m_lane_inline68__ssa_v0
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v260 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v57);
  // pto: %m_lane_inline68__ssa_v0
  uint64_t v261 = (uint64_t) v38;
  TASSIGN(v260, v261);
  pipe_barrier(PIPE_V);
  TREMS(v260, v254, v68, v258);
  // pto: %t__tmp_v51
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v262 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v57);
  // pto: %t__tmp_v51
  uint64_t v263 = (uint64_t) v36;
  TASSIGN(v262, v263);
  pipe_barrier(PIPE_V);
  TMULS(v262, v260, v68);
  // pto: %t__tmp_v52
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v264 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v57);
  // pto: %t__tmp_v52
  uint64_t v265 = (uint64_t) v36;
  TASSIGN(v264, v265);
  pipe_barrier(PIPE_V);
  TSUB(v264, v254, v262);
  // pto: %m_swap_row_inline180__ssa_v0
  Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v57);
  // pto: %m_swap_row_inline180__ssa_v0
  uint64_t v267 = (uint64_t) v37;
  TASSIGN(v266, v267);
  pipe_barrier(PIPE_V);
  TADDS(v266, v264, v69);
  // pto: %m_swap_base_inline87__ssa_v0
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v268 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v57);
  // pto: %m_swap_base_inline87__ssa_v0
  uint64_t v269 = (uint64_t) v36;
  TASSIGN(v268, v269);
  // pto: %m_swap_source_inline215__ssa_v0
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v57);
  // pto: %m_swap_source_inline215__ssa_v0
  uint64_t v271 = (uint64_t) v36;
  TASSIGN(v270, v271);
  pipe_barrier(PIPE_V);
  TCOLEXPAND(v270, v266);
  // pto: %t__ci_tmp_v1
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v272 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v66);
  // pto: %t__ci_tmp_v1
  uint64_t v273 = (uint64_t) v37;
  TASSIGN(v272, v273);
  // pto: %t__tmp_v53
  Tile<TileType::Vec, int32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v274 = Tile<TileType::Vec, int32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
  // pto: %t__tmp_v53
  uint64_t v275 = (uint64_t) v38;
  TASSIGN(v274, v275);
  // pto: %9
  Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v276;
  TRESHAPE(v276, v272);
  // pto: %10
  Tile<TileType::Vec, int32_t, 1, 16, BLayout::RowMajor, 1, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277;
  TRESHAPE(v277, v274);
  pipe_barrier(PIPE_V);
  TCI<Tile<TileType::Vec, int32_t, 1, 16, BLayout::RowMajor, 1, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v277, v67, v276);
  // pto: %m_row_offsets_inline97__ssa_v0
  Tile<TileType::Vec, int32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v278 = Tile<TileType::Vec, int32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
  // pto: %m_row_offsets_inline97__ssa_v0
  uint64_t v279 = (uint64_t) v37;
  TASSIGN(v278, v279);
  pipe_barrier(PIPE_V);
  TMULS(v278, v274, v70);
  // pto: %t__tmp_v54
  Tile<TileType::Vec, int32_t, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v280 = Tile<TileType::Vec, int32_t, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v52);
  // pto: %t__tmp_v54
  uint64_t v281 = (uint64_t) v37;
  TASSIGN(v280, v281);
  // pto: %t__tmp_v55
  Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v282 = Tile<TileType::Vec, int32_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v57);
  // pto: %t__tmp_v55
  uint64_t v283 = (uint64_t) v39;
  TASSIGN(v282, v283);
  pipe_barrier(PIPE_V);
  TROWEXPANDADD(v282, v270, v280);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %m_swap_idx_inline216__ssa_v0
  Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v284 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v71);
  // pto: %m_swap_idx_inline216__ssa_v0
  uint64_t v285 = (uint64_t) v39;
  TASSIGN(v284, v285);
  // pto: %running_m_inline64__ssa_v0
  Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
  // pto: %running_m_inline64__ssa_v0
  uint64_t v287 = (uint64_t) v40;
  TASSIGN(v286, v287);
  // pto: %11
  int64_t v288 = v250 < v72 ? v72 : v250;
  // pto: %attn_sink_col_inline181__ssa_v0_pview
  __gm__ float* v289 = PTOAS__GLOBAL_TENSOR_DATA(v126);
  // pto: %attn_sink_col_inline181__ssa_v0_pview
  const int64_t v290 = 0;
  // pto: %attn_sink_col_inline181__ssa_v0_pview
  pto::Shape<1, 1, 1, 32, 1> v291 = pto::Shape<1, 1, 1, 32, 1>();
  // pto: %attn_sink_col_inline181__ssa_v0_pview
  pto::Stride<32, 32, 32, 1, 64> v292 = pto::Stride<32, 32, 32, 1, 64>();
  // pto: %attn_sink_col_inline181__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 64>, pto::Layout::DN> v293 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 64>, pto::Layout::DN>(v289 + (v290 + v288), v291, v292);
  TLOAD(v286, v293);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %running_l_inline101__rm_a0_tmp_v0
  Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v294 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
  // pto: %running_l_inline101__rm_a0_tmp_v0
  uint64_t v295 = (uint64_t) v40;
  TASSIGN(v294, v295);
  // pto: %running_l_inline101__row_major_tmp_v1
  Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
  // pto: %running_l_inline101__row_major_tmp_v1
  uint64_t v297 = (uint64_t) v41;
  TASSIGN(v296, v297);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  TMULS(v296, v294, v73);
  // pto: %running_l_inline101__ssa_v0
  Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
  // pto: %running_l_inline101__ssa_v0
  uint64_t v299 = (uint64_t) v41;
  TASSIGN(v298, v299);
  // pto: %running_left_inline149__ssa_v0
  Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v300 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v74);
  // pto: %running_left_inline149__ssa_v0
  uint64_t v301 = (uint64_t) v37;
  TASSIGN(v300, v301);
  pipe_barrier(PIPE_V);
  TEXPANDS(v300, v73);
  // pto: %running_right_inline62__ssa_v0
  Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v302 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v74);
  // pto: %running_right_inline62__ssa_v0
  uint64_t v303 = (uint64_t) v38;
  TASSIGN(v302, v303);
  TEXPANDS(v302, v73);
  // pto: %12
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t v304 = v72; v304 < ((int64_t) ((uint64_t) v247 + (uint64_t) v75)); v304 += v52) {
    // pto: %15, %13, %14
    ;
    int64_t v305 = (int64_t) ((uint64_t) v245 + (uint64_t) ((int64_t) (uint64_t) (v304 / v64) * (uint64_t) v63));
    // pto: %16
    ;
    int64_t v306 = v305 / v76;
    // pto: %17
    ;
    int64_t v307 = v304 % v64;
    // pto: %18
    ;
    bool v308 = v304 < v247;
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    if (v308) {
      // pto: %flat_offset_mul, %flat_offset, %t__tile
      ;
      int32_t v309 = (v3)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v305 * (uint64_t) v53) + (uint64_t) v307)];
      // pto: %19, %20
      ;
      if ((int64_t) v309 > v72) {
        // pto: %0
        ;
        Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v310 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v57, v51);
        // pto: %0
        ;
        uint64_t v311 = (uint64_t) v36;
        TASSIGN(v310, v311);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        TEXPANDS(v310, v77);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        // pto: %25
        ;
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
        if (v307 == v72) {
          // pto: %26
          ;
          int64_t v312 = (v9)[v305];
          // pto: %30
          ;
          int64_t v313 = (int64_t) ((uint64_t) v312 + (uint64_t) v52);
          // pto: %31
          ;
          int64_t v314 = v313 < v56 ? v313 : v56;
          // pto: %32, %33
          ;
          int64_t v315 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v312 - (uint64_t) v314) + (uint64_t) v52);
          // pto: %34
          ;
          int64_t v316 = v315 % v65;
          // pto: %35
          ;
          int64_t v317 = (int64_t) ((uint64_t) v314 - (uint64_t) v251);
          // pto: %36
          ;
          int64_t v318 = v317 < v72 ? v72 : v317;
          // pto: %37
          ;
          int64_t v319 = v318 < v57 ? v318 : v57;
          // pto: %38, %39
          ;
          int64_t v320 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v65 - (uint64_t) v316) - (uint64_t) v251);
          // pto: %40
          ;
          int64_t v321 = v320 < v319 ? v320 : v319;
          // pto: %41
          ;
          if (v321 > v72) {
            // pto: %42
            ;
            int64_t v322 = (int64_t) ((uint64_t) v315 + (uint64_t) v251);
            // pto: %45, %46, %44, %qk_raw_page_inline122__tile
            ;
            int32_t v323 = (v10)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v306 * (uint64_t) v26) + (uint64_t) (v322 / v65))];
            // pto: %47
            ;
            int64_t v324 = (int64_t) v323;
            // pto: %48
            ;
            if (v324 >= v72) {
              // pto: %50, %52, %51
              ;
              int64_t v325 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v324 * (uint64_t) v65) + (uint64_t) (v322 % v65));
              // pto: %gather_row_view
              ;
              Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v326 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v321);
              // pto: %gather_row_view
              ;
              uint64_t v327 = (uint64_t) v36;
              TASSIGN(v326, v327);
              // pto: %54
              ;
              int64_t v328 = v325 < v72 ? v72 : v325;
              // pto: %ori_kv_flat_inline67__ssa_v1_pview
              ;
              const int64_t v329 = 0;
              // pto: %ori_kv_flat_inline67__ssa_v1_pview
              ;
              __gm__ bfloat16_t* v330 = PTOAS__GLOBAL_TENSOR_DATA(v135);
              // pto: %ori_kv_flat_inline67__ssa_v1_pview
              ;
              const int64_t v331 = 1;
              // pto: %ori_kv_flat_inline67__ssa_v1_pview
              ;
              const int64_t v332 = 1;
              // pto: %ori_kv_flat_inline67__ssa_v1_pview
              ;
              const int64_t v333 = 1;
              // pto: %ori_kv_flat_inline67__ssa_v1_pview
              ;
              int64_t v334 = v321 * v51;
              // pto: %ori_kv_flat_inline67__ssa_v1_pview
              ;
              int64_t v335 = v333 * v334;
              // pto: %ori_kv_flat_inline67__ssa_v1_pview
              ;
              pto::Shape<1, 1, 1, -1, 512> v336 = pto::Shape<1, 1, 1, -1, 512>(v331, v332, v333, v321, v51);
              // pto: %ori_kv_flat_inline67__ssa_v1_pview
              ;
              pto::Stride<-1, -1, -1, -1, -1> v337 = pto::Stride<-1, -1, -1, -1, -1>(v332 * v335, v335, v334, v51, v52);
              // pto: %ori_kv_flat_inline67__ssa_v1_pview
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v338 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v330 + (v329 + v328 * v51 + v72 * v52), v336, v337);
              TLOAD(v326, v338);
            };
          };
          // pto: %57
          ;
          int64_t v339 = v320 < v72 ? v72 : v320;
          // pto: %58, %59
          ;
          int64_t v340 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v57 - (uint64_t) v316) - (uint64_t) v251);
          // pto: %60
          ;
          int64_t v341 = v340 < v319 ? v340 : v319;
          // pto: %61
          ;
          if (v339 < v341) {
            // pto: %62, %63
            ;
            int64_t v342 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v315 + (uint64_t) v251) + (uint64_t) v339);
            // pto: %66, %67, %65, %64
            ;
            int32_t v343 = (v10)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v306 * (uint64_t) v26) + (uint64_t) (v342 / v65))];
            // pto: %68
            ;
            int64_t v344 = (int64_t) v343;
            // pto: %69
            ;
            if (v344 >= v72) {
              // pto: %71, %73, %72
              ;
              int64_t v345 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v344 * (uint64_t) v65) + (uint64_t) (v342 % v65));
              // pto: %74
              ;
              int64_t v346 = (int64_t) ((uint64_t) v341 - (uint64_t) v339);
              // pto: %75
              ;
              Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v346);
              // pto: %75
              ;
              uint64_t v348 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v339 * (uint64_t) v35) + (uint64_t) v36);
              TASSIGN(v347, v348);
              // pto: %76
              ;
              int64_t v349 = v345 < v72 ? v72 : v345;
              // pto: %77
              ;
              const int64_t v350 = 0;
              // pto: %77
              ;
              __gm__ bfloat16_t* v351 = PTOAS__GLOBAL_TENSOR_DATA(v135);
              // pto: %77
              ;
              const int64_t v352 = 1;
              // pto: %77
              ;
              const int64_t v353 = 1;
              // pto: %77
              ;
              const int64_t v354 = 1;
              // pto: %77
              ;
              int64_t v355 = v346 * v51;
              // pto: %77
              ;
              int64_t v356 = v354 * v355;
              // pto: %77
              ;
              pto::Shape<1, 1, 1, -1, 512> v357 = pto::Shape<1, 1, 1, -1, 512>(v352, v353, v354, v346, v51);
              // pto: %77
              ;
              pto::Stride<-1, -1, -1, -1, -1> v358 = pto::Stride<-1, -1, -1, -1, -1>(v353 * v356, v356, v355, v51, v52);
              // pto: %77
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v359 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v351 + (v350 + v349 * v51 + v72 * v52), v357, v358);
              TLOAD(v347, v359);
            };
          };
          // pto: %80
          ;
          int64_t v360 = v340 < v72 ? v72 : v340;
          // pto: %81, %82
          ;
          int64_t v361 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v78 - (uint64_t) v316) - (uint64_t) v251);
          // pto: %83
          ;
          int64_t v362 = v361 < v319 ? v361 : v319;
          // pto: %84
          ;
          if (v360 < v362) {
            // pto: %85, %86
            ;
            int64_t v363 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v315 + (uint64_t) v251) + (uint64_t) v360);
            // pto: %89, %90, %88, %87
            ;
            int32_t v364 = (v10)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v306 * (uint64_t) v26) + (uint64_t) (v363 / v65))];
            // pto: %91
            ;
            int64_t v365 = (int64_t) v364;
            // pto: %92
            ;
            if (v365 >= v72) {
              // pto: %94, %96, %95
              ;
              int64_t v366 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v365 * (uint64_t) v65) + (uint64_t) (v363 % v65));
              // pto: %97
              ;
              int64_t v367 = (int64_t) ((uint64_t) v362 - (uint64_t) v360);
              // pto: %98
              ;
              Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v368 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v367);
              // pto: %98
              ;
              uint64_t v369 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v360 * (uint64_t) v35) + (uint64_t) v36);
              TASSIGN(v368, v369);
              // pto: %99
              ;
              int64_t v370 = v366 < v72 ? v72 : v366;
              // pto: %100
              ;
              const int64_t v371 = 0;
              // pto: %100
              ;
              __gm__ bfloat16_t* v372 = PTOAS__GLOBAL_TENSOR_DATA(v135);
              // pto: %100
              ;
              const int64_t v373 = 1;
              // pto: %100
              ;
              const int64_t v374 = 1;
              // pto: %100
              ;
              const int64_t v375 = 1;
              // pto: %100
              ;
              int64_t v376 = v367 * v51;
              // pto: %100
              ;
              int64_t v377 = v375 * v376;
              // pto: %100
              ;
              pto::Shape<1, 1, 1, -1, 512> v378 = pto::Shape<1, 1, 1, -1, 512>(v373, v374, v375, v367, v51);
              // pto: %100
              ;
              pto::Stride<-1, -1, -1, -1, -1> v379 = pto::Stride<-1, -1, -1, -1, -1>(v374 * v377, v377, v376, v51, v52);
              // pto: %100
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v380 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v372 + (v371 + v370 * v51 + v72 * v52), v378, v379);
              TLOAD(v368, v380);
            };
          };
          // pto: %103
          ;
          int64_t v381 = v361 < v72 ? v72 : v361;
          // pto: %104, %105
          ;
          int64_t v382 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v56 - (uint64_t) v316) - (uint64_t) v251);
          // pto: %106
          ;
          int64_t v383 = v382 < v319 ? v382 : v319;
          // pto: %107
          ;
          if (v381 < v383) {
            // pto: %108, %109
            ;
            int64_t v384 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v315 + (uint64_t) v251) + (uint64_t) v381);
            // pto: %112, %113, %111, %110
            ;
            int32_t v385 = (v10)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v306 * (uint64_t) v26) + (uint64_t) (v384 / v65))];
            // pto: %114
            ;
            int64_t v386 = (int64_t) v385;
            // pto: %115
            ;
            if (v386 >= v72) {
              // pto: %117, %119, %118
              ;
              int64_t v387 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v386 * (uint64_t) v65) + (uint64_t) (v384 % v65));
              // pto: %120
              ;
              int64_t v388 = (int64_t) ((uint64_t) v383 - (uint64_t) v381);
              // pto: %121
              ;
              Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v389 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v388);
              // pto: %121
              ;
              uint64_t v390 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v381 * (uint64_t) v35) + (uint64_t) v36);
              TASSIGN(v389, v390);
              // pto: %122
              ;
              int64_t v391 = v387 < v72 ? v72 : v387;
              // pto: %123
              ;
              const int64_t v392 = 0;
              // pto: %123
              ;
              __gm__ bfloat16_t* v393 = PTOAS__GLOBAL_TENSOR_DATA(v135);
              // pto: %123
              ;
              const int64_t v394 = 1;
              // pto: %123
              ;
              const int64_t v395 = 1;
              // pto: %123
              ;
              const int64_t v396 = 1;
              // pto: %123
              ;
              int64_t v397 = v388 * v51;
              // pto: %123
              ;
              int64_t v398 = v396 * v397;
              // pto: %123
              ;
              pto::Shape<1, 1, 1, -1, 512> v399 = pto::Shape<1, 1, 1, -1, 512>(v394, v395, v396, v388, v51);
              // pto: %123
              ;
              pto::Stride<-1, -1, -1, -1, -1> v400 = pto::Stride<-1, -1, -1, -1, -1>(v395 * v398, v398, v397, v51, v52);
              // pto: %123
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v401 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v393 + (v392 + v391 * v51 + v72 * v52), v399, v400);
              TLOAD(v389, v401);
            };
          };
          // pto: %126
          ;
          int64_t v402 = v382 < v72 ? v72 : v382;
          // pto: %127, %128
          ;
          int64_t v403 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v79 - (uint64_t) v316) - (uint64_t) v251);
          // pto: %129
          ;
          int64_t v404 = v403 < v319 ? v403 : v319;
          // pto: %130
          ;
          if (v402 < v404) {
            // pto: %131, %132
            ;
            int64_t v405 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v315 + (uint64_t) v251) + (uint64_t) v402);
            // pto: %135, %136, %134, %133
            ;
            int32_t v406 = (v10)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v306 * (uint64_t) v26) + (uint64_t) (v405 / v65))];
            // pto: %137
            ;
            int64_t v407 = (int64_t) v406;
            // pto: %138
            ;
            if (v407 >= v72) {
              // pto: %140, %142, %141
              ;
              int64_t v408 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v407 * (uint64_t) v65) + (uint64_t) (v405 % v65));
              // pto: %143
              ;
              int64_t v409 = (int64_t) ((uint64_t) v404 - (uint64_t) v402);
              // pto: %144
              ;
              Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v410 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v409);
              // pto: %144
              ;
              uint64_t v411 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v402 * (uint64_t) v35) + (uint64_t) v36);
              TASSIGN(v410, v411);
              // pto: %145
              ;
              int64_t v412 = v408 < v72 ? v72 : v408;
              // pto: %146
              ;
              const int64_t v413 = 0;
              // pto: %146
              ;
              __gm__ bfloat16_t* v414 = PTOAS__GLOBAL_TENSOR_DATA(v135);
              // pto: %146
              ;
              const int64_t v415 = 1;
              // pto: %146
              ;
              const int64_t v416 = 1;
              // pto: %146
              ;
              const int64_t v417 = 1;
              // pto: %146
              ;
              int64_t v418 = v409 * v51;
              // pto: %146
              ;
              int64_t v419 = v417 * v418;
              // pto: %146
              ;
              pto::Shape<1, 1, 1, -1, 512> v420 = pto::Shape<1, 1, 1, -1, 512>(v415, v416, v417, v409, v51);
              // pto: %146
              ;
              pto::Stride<-1, -1, -1, -1, -1> v421 = pto::Stride<-1, -1, -1, -1, -1>(v416 * v419, v419, v418, v51, v52);
              // pto: %146
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v422 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v414 + (v413 + v412 * v51 + v72 * v52), v420, v421);
              TLOAD(v410, v422);
            };
          };
        } else {
          pipe_barrier(PIPE_V);
          TEXPANDS(v310, v77);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
          for (int64_t v423 = v72; v423 < v57; v423 += v52) {
            // pto: %147, %148, %149, %150
            ;
            int64_t v424 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v307 - (uint64_t) v52) * (uint64_t) v56) + (uint64_t) v251) + (uint64_t) v423);
            // pto: %151
            ;
            if (v424 < v51) {
              // pto: %152, %153, %qk_ridx_inline39__tile
              ;
              int32_t v425 = (v12)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v305 * (uint64_t) v51) + (uint64_t) v424)];
              // pto: %154
              ;
              int64_t v426 = (int64_t) v425;
              // pto: %155
              ;
              if (v426 >= v72) {
                // pto: %159, %160, %158, %156
                ;
                int32_t v427 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v306 * (uint64_t) v28) + (uint64_t) (v426 / v65))];
                // pto: %161, %162, %165, %164
                ;
                int64_t v428 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v427) * (uint64_t) v65) + (uint64_t) (v426 % v65));
                // pto: %166
                ;
                Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v429;
                // pto: %166
                ;
                uint64_t v430 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v423 * (uint64_t) v35) + (uint64_t) v36);
                TASSIGN(v429, v430);
                // pto: %167
                ;
                int64_t v431 = v428 < v72 ? v72 : v428;
                // pto: %cmp_kv_flat_inline127__ssa_v0_pview
                ;
                __gm__ bfloat16_t* v432 = PTOAS__GLOBAL_TENSOR_DATA(v144);
                // pto: %cmp_kv_flat_inline127__ssa_v0_pview
                ;
                const int64_t v433 = 0;
                // pto: %cmp_kv_flat_inline127__ssa_v0_pview
                ;
                const int64_t v434 = 512;
                // pto: %cmp_kv_flat_inline127__ssa_v0_pview
                ;
                pto::Shape<1, 1, 1, 1, 512> v435 = pto::Shape<1, 1, 1, 1, 512>();
                // pto: %cmp_kv_flat_inline127__ssa_v0_pview
                ;
                pto::Stride<512, 512, 512, 512, 1> v436 = pto::Stride<512, 512, 512, 512, 1>();
                // pto: %cmp_kv_flat_inline127__ssa_v0_pview
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v437 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v432 + (v433 + v431 * v434), v435, v436);
                TLOAD(v429, v437);
              };
            };
          };
        };
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID4);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID5);
        // pto: %21, %23, %22, %24, %168
        ;
        int64_t v438 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v245 * (uint64_t) v75) + (uint64_t) (v304 % v75)) * (uint64_t) v56) + (uint64_t) v251);
        // pto: %169
        ;
        int64_t v439 = v438 < v72 ? v72 : v438;
        // pto: %kv_transfer_inline112__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v440 = PTOAS__GLOBAL_TENSOR_DATA(v94);
        // pto: %kv_transfer_inline112__ssa_v0_pview
        ;
        const int64_t v441 = 0;
        // pto: %kv_transfer_inline112__ssa_v0_pview
        ;
        const int64_t v442 = 512;
        // pto: %kv_transfer_inline112__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 64, 512> v443 = pto::Shape<1, 1, 1, 64, 512>();
        // pto: %kv_transfer_inline112__ssa_v0_pview
        ;
        pto::Stride<32768, 32768, 32768, 512, 1> v444 = pto::Stride<32768, 32768, 32768, 512, 1>();
        // pto: %kv_transfer_inline112__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v445 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v440 + (v441 + v439 * v442), v443, v444);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID4);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID5);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v445, v195);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
      };
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    // pto: %170
    ;
    if (v21 >= v80) {
      // pto: %171, %172, %173
      ;
      if (v304 > v72 & v304 <= v247) {
        // pto: %175
        ;
        int64_t v446 = (int64_t) ((uint64_t) v304 - (uint64_t) v52);
        // pto: %178, %176, %177, %181, %182, %180, %174
        ;
        int32_t v447 = (v3)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v245 + (uint64_t) ((int64_t) (uint64_t) (v446 / v64) * (uint64_t) v63)) * (uint64_t) v53) + (uint64_t) (v446 % v64))];
        // pto: %183, %184
        ;
        if ((int64_t) v447 > v72) {
          int32_t v448 = (int32_t) v52;
          wait_flag_dev(v448);
        };
      };
      if (v308) {
        // pto: %187, %188, %186
        ;
        int32_t v449 = (v3)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v305 * (uint64_t) v53) + (uint64_t) v307)];
        // pto: %189, %190
        ;
        if ((int64_t) v449 > v72) {
          uint16_t v450 = getFFTSMsg(FFTS_MODE_VAL, v72);
          ffts_cross_core_sync(PIPE_MTE3, v450);
        };
      };
    };
    // pto: %191, %192, %193
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    if (v304 > v72 & v304 <= v247) {
      // pto: %194
      ;
      int64_t v451 = (int64_t) ((uint64_t) v304 - (uint64_t) v52);
      // pto: %195
      ;
      int64_t v452 = v451 % v64;
      // pto: %198, %196, %197
      ;
      int64_t v453 = (int64_t) ((uint64_t) v245 + (uint64_t) ((int64_t) (uint64_t) (v451 / v64) * (uint64_t) v63));
      // pto: %200, %201, %199
      ;
      int32_t v454 = (v3)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v453 * (uint64_t) v53) + (uint64_t) v452)];
      // pto: %202, %203
      ;
      if ((int64_t) v454 > v72) {
        // pto: %208
        ;
        int64_t v455 = (int64_t) ((uint64_t) v452 * (uint64_t) v56);
        // pto: %209
        ;
        if (v21 < v80) {
          int32_t v456 = (int32_t) v52;
          wait_flag_dev(v456);
        };
        // pto: %qk_reduce_tmp_inline34__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v457 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v56);
        // pto: %qk_reduce_tmp_inline34__ssa_v0
        ;
        uint64_t v458 = (uint64_t) v36;
        TASSIGN(v457, v458);
        // pto: %qk_scores_half_inline33__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v459 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v56);
        // pto: %qk_scores_half_inline33__ssa_v0
        ;
        uint64_t v460 = (uint64_t) v42;
        TASSIGN(v459, v460);
        // pto: %204, %206, %205, %207, %210
        ;
        int64_t v461 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v245 * (uint64_t) v75) + (uint64_t) (v451 % v75)) * (uint64_t) v57) + (uint64_t) v250);
        // pto: %211
        ;
        int64_t v462 = v461 < v72 ? v72 : v461;
        // pto: %score_transfer_inline187__ssa_v0_pview
        ;
        __gm__ float* v463 = PTOAS__GLOBAL_TENSOR_DATA(v102);
        // pto: %score_transfer_inline187__ssa_v0_pview
        ;
        const int64_t v464 = 0;
        // pto: %score_transfer_inline187__ssa_v0_pview
        ;
        const int64_t v465 = 128;
        // pto: %score_transfer_inline187__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 32, 128> v466 = pto::Shape<1, 1, 1, 32, 128>();
        // pto: %score_transfer_inline187__ssa_v0_pview
        ;
        pto::Stride<4096, 4096, 4096, 128, 1> v467 = pto::Stride<4096, 4096, 4096, 128, 1>();
        // pto: %score_transfer_inline187__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v468 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v463 + (v464 + v462 * v465), v466, v467);
        TLOAD(v459, v468);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %qk_bias_inline191__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v469 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v56);
        // pto: %qk_bias_inline191__ssa_v0
        ;
        uint64_t v470 = (uint64_t) v43;
        TASSIGN(v469, v470);
        // pto: %212
        ;
        int64_t v471 = v453 < v72 ? v72 : v453;
        // pto: %213
        ;
        int64_t v472 = v455 < v72 ? v72 : v455;
        // pto: %sparse_bias_inline152__rv_v2_pview
        ;
        __gm__ float* v473 = PTOAS__GLOBAL_TENSOR_DATA(v153);
        // pto: %sparse_bias_inline152__rv_v2_pview
        ;
        const int64_t v474 = 0;
        // pto: %sparse_bias_inline152__rv_v2_pview
        ;
        const int64_t v475 = 640;
        // pto: %sparse_bias_inline152__rv_v2_pview
        ;
        pto::Shape<1, 1, 1, 1, 128> v476 = pto::Shape<1, 1, 1, 1, 128>();
        // pto: %sparse_bias_inline152__rv_v2_pview
        ;
        pto::Stride<640, 640, 640, 640, 1> v477 = pto::Stride<640, 640, 640, 640, 1>();
        // pto: %sparse_bias_inline152__rv_v2_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<640, 640, 640, 640, 1>, pto::Layout::ND> v478 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<640, 640, 640, 640, 1>, pto::Layout::ND>(v473 + (v474 + v471 * v475 + v472), v476, v477);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
        TLOAD(v469, v478);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %t__tmp_v62
        ;
        Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v479 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v56);
        // pto: %t__tmp_v62
        ;
        uint64_t v480 = (uint64_t) v42;
        TASSIGN(v479, v480);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        TMULS(v479, v459, v81);
        // pto: %qk_masked_inline213__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v481 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v56);
        // pto: %qk_masked_inline213__ssa_v0
        ;
        uint64_t v482 = (uint64_t) v42;
        TASSIGN(v481, v482);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        TCOLEXPANDADD(v481, v479, v469);
        // pto: %qk_mi_inline209__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v483 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
        // pto: %qk_mi_inline209__ssa_v0
        ;
        uint64_t v484 = (uint64_t) v43;
        TASSIGN(v483, v484);
        pipe_barrier(PIPE_V);
        TROWMAX(v483, v481, v457);
        // pto: %t__tmp_v63
        ;
        Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v485 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v56);
        // pto: %t__tmp_v63
        ;
        uint64_t v486 = (uint64_t) v42;
        TASSIGN(v485, v486);
        pipe_barrier(PIPE_V);
        TROWEXPANDSUB(v485, v481, v483);
        // pto: %qk_exp_inline31__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v487 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v56);
        // pto: %qk_exp_inline31__ssa_v0
        ;
        uint64_t v488 = (uint64_t) v42;
        TASSIGN(v487, v488);
        pipe_barrier(PIPE_V);
        TEXP(v487, v485);
        // pto: %qk_li_inline30__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v489 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
        // pto: %qk_li_inline30__ssa_v0
        ;
        uint64_t v490 = (uint64_t) v44;
        TASSIGN(v489, v490);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
        TROWSUM(v489, v487, v457);
        // pto: %qk_probability_inline146__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v491 = Tile<TileType::Vec, bfloat16_t, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v56);
        // pto: %qk_probability_inline146__ssa_v0
        ;
        uint64_t v492 = (uint64_t) v36;
        TASSIGN(v491, v492);
        pipe_barrier(PIPE_V);
        RoundMode v493 = RoundMode::CAST_RINT;
        SaturationMode v494 = SaturationMode::ON;
        TCVT(v491, v487, v493, v494);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        // pto: %probability_transfer_inline189__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v495 = PTOAS__GLOBAL_TENSOR_DATA(v110);
        // pto: %probability_transfer_inline189__ssa_v0_pview
        ;
        const int64_t v496 = 0;
        // pto: %probability_transfer_inline189__ssa_v0_pview
        ;
        const int64_t v497 = 128;
        // pto: %probability_transfer_inline189__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 32, 128> v498 = pto::Shape<1, 1, 1, 32, 128>();
        // pto: %probability_transfer_inline189__ssa_v0_pview
        ;
        pto::Stride<4096, 4096, 4096, 128, 1> v499 = pto::Stride<4096, 4096, 4096, 128, 1>();
        // pto: %probability_transfer_inline189__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND> v500 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 128>, pto::Stride<4096, 4096, 4096, 128, 1>, pto::Layout::ND>(v495 + (v496 + v462 * v497), v498, v499);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        TSTORE(v500, v491);
        // pto: %mi_transfer_inline190__ssa_v0_pview
        ;
        __gm__ float* v501 = PTOAS__GLOBAL_TENSOR_DATA(v161);
        // pto: %mi_transfer_inline190__ssa_v0_pview
        ;
        const int64_t v502 = 0;
        // pto: %mi_transfer_inline190__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 32, 1> v503 = pto::Shape<1, 1, 1, 32, 1>();
        // pto: %mi_transfer_inline190__ssa_v0_pview
        ;
        pto::Stride<32, 32, 32, 1, 4608> v504 = pto::Stride<32, 32, 32, 1, 4608>();
        // pto: %mi_transfer_inline190__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 4608>, pto::Layout::DN> v505 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 4608>, pto::Layout::DN>(v501 + (v502 + v462), v503, v504);
        TSTORE(v505, v483);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
        // pto: %li_transfer_inline121__ssa_v0_pview
        ;
        __gm__ float* v506 = PTOAS__GLOBAL_TENSOR_DATA(v169);
        // pto: %li_transfer_inline121__ssa_v0_pview
        ;
        const int64_t v507 = 0;
        // pto: %li_transfer_inline121__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 32, 1> v508 = pto::Shape<1, 1, 1, 32, 1>();
        // pto: %li_transfer_inline121__ssa_v0_pview
        ;
        pto::Stride<32, 32, 32, 1, 4608> v509 = pto::Stride<32, 32, 32, 1, 4608>();
        // pto: %li_transfer_inline121__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 4608>, pto::Layout::DN> v510 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 4608>, pto::Layout::DN>(v506 + (v507 + v462), v508, v509);
        TSTORE(v510, v489);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
        uint16_t v511 = getFFTSMsg(FFTS_MODE_VAL, v82);
        ffts_cross_core_sync(PIPE_MTE3, v511);
      };
    };
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    // pto: %220
    ;
    if (v21 < v80 & v308) {
      // pto: %223, %224, %222
      ;
      int32_t v512 = (v3)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v305 * (uint64_t) v53) + (uint64_t) v307)];
      // pto: %225, %226
      ;
      if ((int64_t) v512 > v72) {
        uint16_t v513 = getFFTSMsg(FFTS_MODE_VAL, v72);
        ffts_cross_core_sync(PIPE_MTE3, v513);
      };
    };
    // pto: %227
    ;
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
    pipe_barrier(PIPE_ALL);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    if (v304 >= v75) {
      int64_t v514 = (int64_t) ((uint64_t) v304 - (uint64_t) v75);
      // pto: %230
      ;
      int64_t v515 = v514 % v64;
      // pto: %233, %231, %232
      ;
      int64_t v516 = (int64_t) ((uint64_t) v245 + (uint64_t) ((int64_t) (uint64_t) (v514 / v64) * (uint64_t) v63));
      // pto: %235, %236, %234
      ;
      int32_t v517 = (v3)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v516 * (uint64_t) v53) + (uint64_t) v515)];
      // pto: %237, %238
      ;
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      if ((int64_t) v517 > v72) {
        int32_t v518 = (int32_t) v75;
        wait_flag_dev(v518);
        // pto: %pv_m_inline206__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v519 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
        // pto: %pv_m_inline206__ssa_v0
        ;
        uint64_t v520 = (uint64_t) v36;
        TASSIGN(v519, v520);
        // pto: %239, %241, %240, %242, %243
        ;
        int64_t v521 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v245 * (uint64_t) v75) + (uint64_t) (v514 % v75)) * (uint64_t) v57) + (uint64_t) v250);
        // pto: %244
        ;
        int64_t v522 = v521 < v72 ? v72 : v521;
        // pto: %245
        ;
        __gm__ float* v523 = PTOAS__GLOBAL_TENSOR_DATA(v161);
        // pto: %245
        ;
        const int64_t v524 = 0;
        // pto: %245
        ;
        pto::Shape<1, 1, 1, 32, 1> v525 = pto::Shape<1, 1, 1, 32, 1>();
        // pto: %245
        ;
        pto::Stride<32, 32, 32, 1, 4608> v526 = pto::Stride<32, 32, 32, 1, 4608>();
        // pto: %245
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 4608>, pto::Layout::DN> v527 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 4608>, pto::Layout::DN>(v523 + (v524 + v522), v525, v526);
        TLOAD(v519, v527);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %pv_l_inline196__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v528 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
        // pto: %pv_l_inline196__ssa_v0
        ;
        uint64_t v529 = (uint64_t) v42;
        TASSIGN(v528, v529);
        // pto: %248
        ;
        __gm__ float* v530 = PTOAS__GLOBAL_TENSOR_DATA(v169);
        // pto: %248
        ;
        const int64_t v531 = 0;
        // pto: %248
        ;
        pto::Shape<1, 1, 1, 32, 1> v532 = pto::Shape<1, 1, 1, 32, 1>();
        // pto: %248
        ;
        pto::Stride<32, 32, 32, 1, 4608> v533 = pto::Stride<32, 32, 32, 1, 4608>();
        // pto: %248
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 4608>, pto::Layout::DN> v534 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 4608>, pto::Layout::DN>(v530 + (v531 + v522), v532, v533);
        TLOAD(v528, v534);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        // pto: %next_m_inline25__rm_a0_tmp_v2
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v535 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %next_m_inline25__rm_a0_tmp_v2
        ;
        uint64_t v536 = (uint64_t) v40;
        TASSIGN(v535, v536);
        // pto: %next_m_inline25__rm_a1_tmp_v3
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v537 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %next_m_inline25__rm_a1_tmp_v3
        ;
        uint64_t v538 = (uint64_t) v36;
        TASSIGN(v537, v538);
        // pto: %next_m_inline25__row_major_tmp_v4
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v539 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %next_m_inline25__row_major_tmp_v4
        ;
        uint64_t v540 = (uint64_t) v45;
        TASSIGN(v539, v540);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        TMAX(v539, v535, v537);
        // pto: %next_m_inline25__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v541 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
        // pto: %next_m_inline25__ssa_v0
        ;
        uint64_t v542 = (uint64_t) v45;
        TASSIGN(v541, v542);
        // pto: %t__rm_a0_tmp_v5
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v543 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %t__rm_a0_tmp_v5
        ;
        uint64_t v544 = (uint64_t) v40;
        TASSIGN(v543, v544);
        // pto: %t__rm_a1_tmp_v6
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v545 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %t__rm_a1_tmp_v6
        ;
        uint64_t v546 = (uint64_t) v45;
        TASSIGN(v545, v546);
        // pto: %t__row_major_tmp_v7
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v547 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %t__row_major_tmp_v7
        ;
        uint64_t v548 = (uint64_t) v43;
        TASSIGN(v547, v548);
        pipe_barrier(PIPE_V);
        TSUB(v547, v543, v545);
        // pto: %t__tmp_v66
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v549 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
        // pto: %t__tmp_v66
        ;
        uint64_t v550 = (uint64_t) v43;
        TASSIGN(v549, v550);
        // pto: %alpha_inline42__rm_a0_tmp_v8
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v551 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %alpha_inline42__rm_a0_tmp_v8
        ;
        uint64_t v552 = (uint64_t) v43;
        TASSIGN(v551, v552);
        // pto: %alpha_inline42__row_major_tmp_v9
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v553 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %alpha_inline42__row_major_tmp_v9
        ;
        uint64_t v554 = (uint64_t) v43;
        TASSIGN(v553, v554);
        pipe_barrier(PIPE_V);
        TEXP(v553, v551);
        // pto: %alpha_inline42__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v555 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
        // pto: %alpha_inline42__ssa_v0
        ;
        uint64_t v556 = (uint64_t) v43;
        TASSIGN(v555, v556);
        // pto: %t__rm_a0_tmp_v10
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v557 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %t__rm_a0_tmp_v10
        ;
        uint64_t v558 = (uint64_t) v36;
        TASSIGN(v557, v558);
        // pto: %t__rm_a1_tmp_v11
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v559 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %t__rm_a1_tmp_v11
        ;
        uint64_t v560 = (uint64_t) v45;
        TASSIGN(v559, v560);
        // pto: %t__row_major_tmp_v12
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v561 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %t__row_major_tmp_v12
        ;
        uint64_t v562 = (uint64_t) v36;
        TASSIGN(v561, v562);
        TSUB(v561, v557, v559);
        // pto: %t__tmp_v67
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v563 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
        // pto: %t__tmp_v67
        ;
        uint64_t v564 = (uint64_t) v36;
        TASSIGN(v563, v564);
        // pto: %beta_inline24__rm_a0_tmp_v13
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v565 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %beta_inline24__rm_a0_tmp_v13
        ;
        uint64_t v566 = (uint64_t) v36;
        TASSIGN(v565, v566);
        // pto: %beta_inline24__row_major_tmp_v14
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v567 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %beta_inline24__row_major_tmp_v14
        ;
        uint64_t v568 = (uint64_t) v44;
        TASSIGN(v567, v568);
        pipe_barrier(PIPE_V);
        TEXP(v567, v565);
        // pto: %beta_inline24__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v569 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
        // pto: %beta_inline24__ssa_v0
        ;
        uint64_t v570 = (uint64_t) v44;
        TASSIGN(v569, v570);
        // pto: %t__rm_a0_tmp_v15
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v571 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %t__rm_a0_tmp_v15
        ;
        uint64_t v572 = (uint64_t) v43;
        TASSIGN(v571, v572);
        // pto: %t__rm_a1_tmp_v16
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v573 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %t__rm_a1_tmp_v16
        ;
        uint64_t v574 = (uint64_t) v41;
        TASSIGN(v573, v574);
        // pto: %t__row_major_tmp_v17
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v575 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %t__row_major_tmp_v17
        ;
        uint64_t v576 = (uint64_t) v36;
        TASSIGN(v575, v576);
        pipe_barrier(PIPE_V);
        TMUL(v575, v571, v573);
        // pto: %t__tmp_v68
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v577 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
        // pto: %t__tmp_v68
        ;
        uint64_t v578 = (uint64_t) v36;
        TASSIGN(v577, v578);
        // pto: %t__rm_a0_tmp_v18
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v579 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %t__rm_a0_tmp_v18
        ;
        uint64_t v580 = (uint64_t) v44;
        TASSIGN(v579, v580);
        // pto: %t__rm_a1_tmp_v19
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v581 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %t__rm_a1_tmp_v19
        ;
        uint64_t v582 = (uint64_t) v42;
        TASSIGN(v581, v582);
        // pto: %t__row_major_tmp_v20
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v583 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %t__row_major_tmp_v20
        ;
        uint64_t v584 = (uint64_t) v42;
        TASSIGN(v583, v584);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        TMUL(v583, v579, v581);
        // pto: %t__tmp_v69
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v585 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
        // pto: %t__tmp_v69
        ;
        uint64_t v586 = (uint64_t) v42;
        TASSIGN(v585, v586);
        // pto: %next_l_inline81__rm_a0_tmp_v21
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v587 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %next_l_inline81__rm_a0_tmp_v21
        ;
        uint64_t v588 = (uint64_t) v36;
        TASSIGN(v587, v588);
        // pto: %next_l_inline81__rm_a1_tmp_v22
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v589 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %next_l_inline81__rm_a1_tmp_v22
        ;
        uint64_t v590 = (uint64_t) v42;
        TASSIGN(v589, v590);
        // pto: %next_l_inline81__row_major_tmp_v23
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v591 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %next_l_inline81__row_major_tmp_v23
        ;
        uint64_t v592 = (uint64_t) v46;
        TASSIGN(v591, v592);
        pipe_barrier(PIPE_V);
        TADD(v591, v587, v589);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        // pto: %next_l_inline81__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v593 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
        // pto: %next_l_inline81__ssa_v0
        ;
        uint64_t v594 = (uint64_t) v46;
        TASSIGN(v593, v594);
        // pto: %pv_left_inline164__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v595 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v74);
        // pto: %pv_left_inline164__ssa_v0
        ;
        uint64_t v596 = (uint64_t) v36;
        TASSIGN(v595, v596);
        // pto: %pv_transfer_inline155__ssa_v0_pview
        ;
        __gm__ float* v597 = PTOAS__GLOBAL_TENSOR_DATA(v118);
        // pto: %pv_transfer_inline155__ssa_v0_pview
        ;
        const int64_t v598 = 0;
        // pto: %pv_transfer_inline155__ssa_v0_pview
        ;
        const int64_t v599 = 512;
        // pto: %pv_transfer_inline155__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 32, 256> v600 = pto::Shape<1, 1, 1, 32, 256>();
        // pto: %pv_transfer_inline155__ssa_v0_pview
        ;
        pto::Stride<16384, 16384, 16384, 512, 1> v601 = pto::Stride<16384, 16384, 16384, 512, 1>();
        // pto: %pv_transfer_inline155__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v602 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v597 + (v598 + v522 * v599), v600, v601);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        TLOAD(v595, v602);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
        // pto: %t__tmp_v70
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v603 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v74);
        // pto: %t__tmp_v70
        ;
        uint64_t v604 = (uint64_t) v42;
        TASSIGN(v603, v604);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v603, v300, v555);
        // pto: %t__tmp_v71
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v605 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v74);
        // pto: %t__tmp_v71
        ;
        uint64_t v606 = (uint64_t) v36;
        TASSIGN(v605, v606);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
        TROWEXPANDMUL(v605, v595, v569);
        // pto: %next_left_inline23__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v607 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v74);
        // pto: %next_left_inline23__ssa_v0
        ;
        uint64_t v608 = (uint64_t) v37;
        TASSIGN(v607, v608);
        pipe_barrier(PIPE_V);
        TADD(v607, v603, v605);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        // pto: %pv_right_inline22__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v609 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v74);
        // pto: %pv_right_inline22__ssa_v0
        ;
        uint64_t v610 = (uint64_t) v36;
        TASSIGN(v609, v610);
        // pto: %253
        ;
        __gm__ float* v611 = PTOAS__GLOBAL_TENSOR_DATA(v118);
        // pto: %253
        ;
        const int64_t v612 = 256;
        // pto: %253
        ;
        const int64_t v613 = 512;
        // pto: %253
        ;
        pto::Shape<1, 1, 1, 32, 256> v614 = pto::Shape<1, 1, 1, 32, 256>();
        // pto: %253
        ;
        pto::Stride<16384, 16384, 16384, 512, 1> v615 = pto::Stride<16384, 16384, 16384, 512, 1>();
        // pto: %253
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v616 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v611 + (v612 + v522 * v613), v614, v615);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        TLOAD(v609, v616);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        // pto: %t__tmp_v72
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v617 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v74);
        // pto: %t__tmp_v72
        ;
        uint64_t v618 = (uint64_t) v42;
        TASSIGN(v617, v618);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v617, v302, v555);
        // pto: %t__tmp_v73
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v619 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v74);
        // pto: %t__tmp_v73
        ;
        uint64_t v620 = (uint64_t) v36;
        TASSIGN(v619, v620);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
        TROWEXPANDMUL(v619, v609, v569);
        // pto: %next_right_inline202__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v621 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v74);
        // pto: %next_right_inline202__ssa_v0
        ;
        uint64_t v622 = (uint64_t) v38;
        TASSIGN(v621, v622);
        pipe_barrier(PIPE_V);
        TADD(v621, v617, v619);
      } else {
        // pto: %m_iter_mv
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v623 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
        // pto: %m_iter_mv
        ;
        uint64_t v624 = (uint64_t) v45;
        TASSIGN(v623, v624);
        pipe_barrier(PIPE_V);
        TMOV(v623, v286);
        // pto: %l_iter_mv
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v625 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
        // pto: %l_iter_mv
        ;
        uint64_t v626 = (uint64_t) v46;
        TASSIGN(v625, v626);
        TMOV(v625, v298);
      };
      // pto: %254
      ;
      if (v515 == v83) {
        // pto: %m_gather_tmp_inline52__ssa_v0
        ;
        Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v627 = Tile<TileType::Vec, int32_t, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v71);
        // pto: %m_gather_tmp_inline52__ssa_v0
        ;
        uint64_t v628 = (uint64_t) v43;
        TASSIGN(v627, v628);
        // pto: %t__tmp_v74
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v629 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %t__tmp_v74
        ;
        uint64_t v630 = (uint64_t) v45;
        TASSIGN(v629, v630);
        // pto: %t__tmp_v75
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v631 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__tmp_v75
        ;
        uint64_t v632 = (uint64_t) v42;
        TASSIGN(v631, v632);
        pipe_barrier(PIPE_V);
        uint16_t v633 = static_cast<uint16_t>(v72);
        uint16_t v634 = static_cast<uint16_t>(v72);
        TEXTRACT(v631, v629, v633, v634);
        // pto: %m_mi_inline17__ssa_v0
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v635 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v52);
        // pto: %m_mi_inline17__ssa_v0
        ;
        uint64_t v636 = (uint64_t) v42;
        TASSIGN(v635, v636);
        // pto: %t__tmp_v76
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v637 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %t__tmp_v76
        ;
        uint64_t v638 = (uint64_t) v46;
        TASSIGN(v637, v638);
        // pto: %t__tmp_v77
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v639 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__tmp_v77
        ;
        uint64_t v640 = (uint64_t) v44;
        TASSIGN(v639, v640);
        uint16_t v641 = static_cast<uint16_t>(v72);
        uint16_t v642 = static_cast<uint16_t>(v72);
        TEXTRACT(v639, v637, v641, v642);
        // pto: %m_li_inline16__ssa_v0
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v643 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v52);
        // pto: %m_li_inline16__ssa_v0
        ;
        uint64_t v644 = (uint64_t) v44;
        TASSIGN(v643, v644);
        // pto: %m_left_inline144__ssa_v0
        ;
        Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v645 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v74);
        // pto: %m_left_inline144__ssa_v0
        ;
        uint64_t v646 = (uint64_t) v37;
        TASSIGN(v645, v646);
        // pto: %slice_view
        ;
        Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, 16, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v647;
        // pto: %slice_view
        ;
        uint64_t v648 = (uint64_t) v37;
        TASSIGN(v647, v648);
        // pto: %m_right_inline15__ssa_v0
        ;
        Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v649 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v74);
        // pto: %m_right_inline15__ssa_v0
        ;
        uint64_t v650 = (uint64_t) v38;
        TASSIGN(v649, v650);
        // pto: %256
        ;
        Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, 16, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v651;
        // pto: %256
        ;
        uint64_t v652 = (uint64_t) v38;
        TASSIGN(v651, v652);
        // pto: %m_oi_inline14__ssa_v0
        ;
        Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v653 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v51);
        // pto: %m_oi_inline14__ssa_v0
        ;
        uint64_t v654 = (uint64_t) v36;
        TASSIGN(v653, v654);
        pipe_barrier(PIPE_ALL);
        TCONCAT(v653, v647, v651);
        // pto: %n_sink_bias_inline13__ssa_v0
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v655 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v52);
        // pto: %n_sink_bias_inline13__ssa_v0
        ;
        uint64_t v656 = (uint64_t) v47;
        TASSIGN(v655, v656);
        // pto: %258
        ;
        __gm__ float* v657 = PTOAS__GLOBAL_TENSOR_DATA(v126);
        // pto: %258
        ;
        const int64_t v658 = 0;
        // pto: %258
        ;
        pto::Shape<1, 1, 1, 16, 1> v659 = pto::Shape<1, 1, 1, 16, 1>();
        // pto: %258
        ;
        pto::Stride<16, 16, 16, 1, 64> v660 = pto::Stride<16, 16, 16, 1, 64>();
        // pto: %258
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<16, 16, 16, 1, 64>, pto::Layout::DN> v661 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<16, 16, 16, 1, 64>, pto::Layout::DN>(v657 + (v658 + v288), v659, v660);
        TLOAD(v655, v661);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        // pto: %t__rm_a0_tmp_v24
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v662 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__rm_a0_tmp_v24
        ;
        uint64_t v663 = (uint64_t) v42;
        TASSIGN(v662, v663);
        // pto: %t__rm_a1_tmp_v25
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v664 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__rm_a1_tmp_v25
        ;
        uint64_t v665 = (uint64_t) v42;
        TASSIGN(v664, v665);
        // pto: %t__row_major_tmp_v26
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v666 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__row_major_tmp_v26
        ;
        uint64_t v667 = (uint64_t) v48;
        TASSIGN(v666, v667);
        pipe_barrier(PIPE_V);
        TSUB(v666, v662, v664);
        // pto: %t__tmp_v78
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v668 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v52);
        // pto: %t__tmp_v78
        ;
        uint64_t v669 = (uint64_t) v48;
        TASSIGN(v668, v669);
        // pto: %n_sink_tile_inline11__rm_a0_tmp_v27
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v670 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %n_sink_tile_inline11__rm_a0_tmp_v27
        ;
        uint64_t v671 = (uint64_t) v48;
        TASSIGN(v670, v671);
        // pto: %n_sink_tile_inline11__rm_a1_tmp_v28
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v672 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %n_sink_tile_inline11__rm_a1_tmp_v28
        ;
        uint64_t v673 = (uint64_t) v47;
        TASSIGN(v672, v673);
        // pto: %n_sink_tile_inline11__row_major_tmp_v29
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v674 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %n_sink_tile_inline11__row_major_tmp_v29
        ;
        uint64_t v675 = (uint64_t) v47;
        TASSIGN(v674, v675);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
        TADD(v674, v670, v672);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        // pto: %n_sink_tile_inline11__ssa_v0
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v676 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v52);
        // pto: %n_sink_tile_inline11__ssa_v0
        ;
        uint64_t v677 = (uint64_t) v47;
        TASSIGN(v676, v677);
        // pto: %t__rm_a0_tmp_v30
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v678 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__rm_a0_tmp_v30
        ;
        uint64_t v679 = (uint64_t) v47;
        TASSIGN(v678, v679);
        // pto: %t__rm_a1_tmp_v31
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v680 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__rm_a1_tmp_v31
        ;
        uint64_t v681 = (uint64_t) v42;
        TASSIGN(v680, v681);
        // pto: %t__row_major_tmp_v32
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v682 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__row_major_tmp_v32
        ;
        uint64_t v683 = (uint64_t) v42;
        TASSIGN(v682, v683);
        pipe_barrier(PIPE_V);
        TSUB(v682, v678, v680);
        // pto: %t__tmp_v79
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v684 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v52);
        // pto: %t__tmp_v79
        ;
        uint64_t v685 = (uint64_t) v42;
        TASSIGN(v684, v685);
        // pto: %t__rm_a0_tmp_v33
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v686 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__rm_a0_tmp_v33
        ;
        uint64_t v687 = (uint64_t) v42;
        TASSIGN(v686, v687);
        // pto: %t__row_major_tmp_v34
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v688 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__row_major_tmp_v34
        ;
        uint64_t v689 = (uint64_t) v42;
        TASSIGN(v688, v689);
        pipe_barrier(PIPE_V);
        TEXP(v688, v686);
        // pto: %t__tmp_v80
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v690 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v52);
        // pto: %t__tmp_v80
        ;
        uint64_t v691 = (uint64_t) v42;
        TASSIGN(v690, v691);
        // pto: %n_denom_inline10__rm_a0_tmp_v35
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v692 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %n_denom_inline10__rm_a0_tmp_v35
        ;
        uint64_t v693 = (uint64_t) v44;
        TASSIGN(v692, v693);
        // pto: %n_denom_inline10__rm_a1_tmp_v36
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v694 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %n_denom_inline10__rm_a1_tmp_v36
        ;
        uint64_t v695 = (uint64_t) v42;
        TASSIGN(v694, v695);
        // pto: %n_denom_inline10__row_major_tmp_v37
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v696 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %n_denom_inline10__row_major_tmp_v37
        ;
        uint64_t v697 = (uint64_t) v42;
        TASSIGN(v696, v697);
        pipe_barrier(PIPE_V);
        TADD(v696, v692, v694);
        // pto: %n_denom_inline10__ssa_v0
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v698 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v52);
        // pto: %n_denom_inline10__ssa_v0
        ;
        uint64_t v699 = (uint64_t) v42;
        TASSIGN(v698, v699);
        // pto: %n_full_inline60__ssa_v0
        ;
        Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v700 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v51);
        // pto: %n_full_inline60__ssa_v0
        ;
        uint64_t v701 = (uint64_t) v36;
        TASSIGN(v700, v701);
        pipe_barrier(PIPE_V);
        TROWEXPANDDIV(v700, v653, v698);
        // pto: %n_bf16_inline28__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v702 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v51);
        // pto: %n_bf16_inline28__ssa_v0
        ;
        uint64_t v703 = (uint64_t) v42;
        TASSIGN(v702, v703);
        pipe_barrier(PIPE_V);
        RoundMode v704 = RoundMode::CAST_RINT;
        SaturationMode v705 = SaturationMode::ON;
        TCVT(v702, v700, v704, v705);
        // pto: %m_cos_il_inline8__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v706 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v57);
        // pto: %m_cos_il_inline8__ssa_v0
        ;
        uint64_t v707 = (uint64_t) v48;
        TASSIGN(v706, v707);
        // pto: %259
        ;
        int64_t v708 = v516 < v72 ? v72 : v516;
        // pto: %cos__ssa_v0_pview
        ;
        __gm__ float* v709 = PTOAS__GLOBAL_TENSOR_DATA(v178);
        // pto: %cos__ssa_v0_pview
        ;
        const int64_t v710 = 0;
        // pto: %cos__ssa_v0_pview
        ;
        const int64_t v711 = 64;
        // pto: %cos__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 64> v712 = pto::Shape<1, 1, 1, 1, 64>();
        // pto: %cos__ssa_v0_pview
        ;
        pto::Stride<64, 64, 64, 64, 1> v713 = pto::Stride<64, 64, 64, 64, 1>();
        // pto: %cos__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v714 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v709 + (v710 + v708 * v711), v712, v713);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        TLOAD(v706, v714);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %m_sin_signed_inline12__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v715 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v57);
        // pto: %m_sin_signed_inline12__ssa_v0
        ;
        uint64_t v716 = (uint64_t) v49;
        TASSIGN(v715, v716);
        // pto: %rope_sin_signed_inline153__ssa_v0_pview
        ;
        __gm__ float* v717 = PTOAS__GLOBAL_TENSOR_DATA(v186);
        // pto: %rope_sin_signed_inline153__ssa_v0_pview
        ;
        const int64_t v718 = 0;
        // pto: %rope_sin_signed_inline153__ssa_v0_pview
        ;
        const int64_t v719 = 64;
        // pto: %rope_sin_signed_inline153__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 64> v720 = pto::Shape<1, 1, 1, 1, 64>();
        // pto: %rope_sin_signed_inline153__ssa_v0_pview
        ;
        pto::Stride<64, 64, 64, 64, 1> v721 = pto::Stride<64, 64, 64, 64, 1>();
        // pto: %rope_sin_signed_inline153__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v722 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v717 + (v718 + v708 * v719), v720, v721);
        TLOAD(v715, v722);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %t__tmp_v81
        ;
        Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v723 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v84);
        // pto: %t__tmp_v81
        ;
        uint64_t v724 = (uint64_t) v36;
        TASSIGN(v723, v724);
        // pto: %m_swapped_flat_inline7__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v725 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v71);
        // pto: %m_swapped_flat_inline7__ssa_v0
        ;
        uint64_t v726 = (uint64_t) v44;
        TASSIGN(v725, v726);
        TGATHER(v725, v723, v284, v627);
        // pto: %m_swapped_inline184__ssa_v0
        ;
        Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v727 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v57);
        // pto: %m_swapped_inline184__ssa_v0
        ;
        uint64_t v728 = (uint64_t) v44;
        TASSIGN(v727, v728);
        // pto: %m_rope_inline9__ssa_v0_textract
        ;
        Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v729 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v57);
        // pto: %m_rope_inline9__ssa_v0_textract
        ;
        uint64_t v730 = (uint64_t) v47;
        TASSIGN(v729, v730);
        uint16_t v731 = static_cast<uint16_t>(v72);
        uint16_t v732 = static_cast<uint16_t>(v85);
        TEXTRACT(v729, v700, v731, v732);
        // pto: %t__tmp_v82
        ;
        Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v733 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v57);
        // pto: %t__tmp_v82
        ;
        uint64_t v734 = (uint64_t) v36;
        TASSIGN(v733, v734);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        TCOLEXPANDMUL(v733, v729, v706);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        // pto: %t__tmp_v83
        ;
        Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v735 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v57);
        // pto: %t__tmp_v83
        ;
        uint64_t v736 = (uint64_t) v44;
        TASSIGN(v735, v736);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        TCOLEXPANDMUL(v735, v727, v715);
        // pto: %m_rot_inline58__ssa_v0
        ;
        Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v737 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v57);
        // pto: %m_rot_inline58__ssa_v0
        ;
        uint64_t v738 = (uint64_t) v36;
        TASSIGN(v737, v738);
        pipe_barrier(PIPE_V);
        TADD(v737, v733, v735);
        // pto: %n_rope_bf16_inline6__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v739 = Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v57);
        // pto: %n_rope_bf16_inline6__ssa_v0
        ;
        uint64_t v740 = (uint64_t) v44;
        TASSIGN(v739, v740);
        pipe_barrier(PIPE_V);
        RoundMode v741 = RoundMode::CAST_RINT;
        SaturationMode v742 = SaturationMode::ON;
        TCVT(v739, v737, v741, v742);
        // pto: %t__tmp_v84
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v743 = Tile<TileType::Vec, bfloat16_t, 16, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v85);
        // pto: %t__tmp_v84
        ;
        uint64_t v744 = (uint64_t) v42;
        TASSIGN(v743, v744);
        // pto: %261
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, 16, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v745;
        // pto: %261
        ;
        uint64_t v746 = (uint64_t) v42;
        TASSIGN(v745, v746);
        // pto: %n_full_bf16_inline178__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v747 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v51);
        // pto: %n_full_bf16_inline178__ssa_v0
        ;
        uint64_t v748 = (uint64_t) v36;
        TASSIGN(v747, v748);
        pipe_barrier(PIPE_V);
        TCONCAT(v747, v745, v739);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        // pto: %n_group_bf16_inline177__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 2, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v749 = Tile<TileType::Vec, bfloat16_t, 2, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v82, v61);
        // pto: %n_group_bf16_inline177__ssa_v0
        ;
        uint64_t v750 = (uint64_t) v36;
        TASSIGN(v749, v750);
        // pto: %n_pack_first_inline40__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v751 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v61);
        // pto: %n_pack_first_inline40__ssa_v0
        ;
        uint64_t v752 = (uint64_t) v36;
        TASSIGN(v751, v752);
        // pto: %262
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v753;
        // pto: %262
        ;
        uint64_t v754 = (uint64_t) v36;
        TASSIGN(v753, v754);
        // pto: %n_pack_second_inline132__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v755 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v61);
        // pto: %n_pack_second_inline132__ssa_v0
        ;
        uint64_t v756 = (uint64_t) v50;
        TASSIGN(v755, v756);
        // pto: %263
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v757;
        // pto: %263
        ;
        uint64_t v758 = (uint64_t) v50;
        TASSIGN(v757, v758);
        // pto: %264, %265, %266
        ;
        int64_t v759 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v250 / v86) * (uint64_t) v59) + (uint64_t) v516);
        // pto: %267
        ;
        int64_t v760 = (int64_t) ((uint64_t) v759 + (uint64_t) v59);
        // pto: %268
        ;
        int64_t v761 = v759 < v72 ? v72 : v759;
        // pto: %packed__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v762 = PTOAS__GLOBAL_TENSOR_DATA(v194);
        // pto: %packed__ssa_v0_pview
        ;
        const int64_t v763 = 0;
        // pto: %packed__ssa_v0_pview
        ;
        const int64_t v764 = 4096;
        // pto: %packed__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v765 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %packed__ssa_v0_pview
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v766 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %packed__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v767 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v762 + (v763 + v761 * v764), v765, v766);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
        TSTORE(v767, v753);
        // pto: %269
        ;
        int64_t v768 = v760 < v72 ? v72 : v760;
        // pto: %270
        ;
        __gm__ bfloat16_t* v769 = PTOAS__GLOBAL_TENSOR_DATA(v194);
        // pto: %270
        ;
        const int64_t v770 = 0;
        // pto: %270
        ;
        const int64_t v771 = 4096;
        // pto: %270
        ;
        pto::Shape<1, 1, 1, 1, 4096> v772 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %270
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v773 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %270
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v774 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v769 + (v770 + v768 * v771), v772, v773);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v774, v757);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        // pto: %271
        ;
        int64_t v775 = (int64_t) ((uint64_t) v250 + (uint64_t) v53);
        // pto: %t__tmp_v85
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v776 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %t__tmp_v85
        ;
        uint64_t v777 = (uint64_t) v45;
        TASSIGN(v776, v777);
        // pto: %t__tmp_v86
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v778 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__tmp_v86
        ;
        uint64_t v779 = (uint64_t) v42;
        TASSIGN(v778, v779);
        pipe_barrier(PIPE_V);
        uint16_t v780 = static_cast<uint16_t>(v72);
        uint16_t v781 = static_cast<uint16_t>(v53);
        TEXTRACT(v778, v776, v780, v781);
        // pto: %m_mi_inline17__ssa_v1
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v782 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v52);
        // pto: %m_mi_inline17__ssa_v1
        ;
        uint64_t v783 = (uint64_t) v42;
        TASSIGN(v782, v783);
        // pto: %t__tmp_v87
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v784 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %t__tmp_v87
        ;
        uint64_t v785 = (uint64_t) v46;
        TASSIGN(v784, v785);
        // pto: %t__tmp_v88
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v786 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__tmp_v88
        ;
        uint64_t v787 = (uint64_t) v44;
        TASSIGN(v786, v787);
        uint16_t v788 = static_cast<uint16_t>(v72);
        uint16_t v789 = static_cast<uint16_t>(v53);
        TEXTRACT(v786, v784, v788, v789);
        // pto: %m_li_inline16__ssa_v1
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v790 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v52);
        // pto: %m_li_inline16__ssa_v1
        ;
        uint64_t v791 = (uint64_t) v44;
        TASSIGN(v790, v791);
        // pto: %m_left_inline144__ssa_v1
        ;
        Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v792 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v74);
        // pto: %m_left_inline144__ssa_v1
        ;
        uint64_t v793 = (uint64_t) v37;
        TASSIGN(v792, v793);
        // pto: %272
        ;
        Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, 16, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v794;
        // pto: %272
        ;
        uint64_t v795 = (uint64_t) v34;
        TASSIGN(v794, v795);
        // pto: %m_right_inline15__ssa_v1
        ;
        Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v796 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v74);
        // pto: %m_right_inline15__ssa_v1
        ;
        uint64_t v797 = (uint64_t) v38;
        TASSIGN(v796, v797);
        // pto: %273
        ;
        Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, 16, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v798;
        // pto: %273
        ;
        uint64_t v799 = (uint64_t) v33;
        TASSIGN(v798, v799);
        // pto: %m_oi_inline14__ssa_v1
        ;
        Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v800 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v51);
        // pto: %m_oi_inline14__ssa_v1
        ;
        uint64_t v801 = (uint64_t) v36;
        TASSIGN(v800, v801);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        TCONCAT(v800, v794, v798);
        // pto: %n_sink_bias_inline13__ssa_v1
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v802 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v52);
        // pto: %n_sink_bias_inline13__ssa_v1
        ;
        uint64_t v803 = (uint64_t) v47;
        TASSIGN(v802, v803);
        // pto: %274
        ;
        int64_t v804 = v775 < v72 ? v72 : v775;
        // pto: %275
        ;
        __gm__ float* v805 = PTOAS__GLOBAL_TENSOR_DATA(v126);
        // pto: %275
        ;
        const int64_t v806 = 0;
        // pto: %275
        ;
        pto::Shape<1, 1, 1, 16, 1> v807 = pto::Shape<1, 1, 1, 16, 1>();
        // pto: %275
        ;
        pto::Stride<16, 16, 16, 1, 64> v808 = pto::Stride<16, 16, 16, 1, 64>();
        // pto: %275
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<16, 16, 16, 1, 64>, pto::Layout::DN> v809 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 1>, pto::Stride<16, 16, 16, 1, 64>, pto::Layout::DN>(v805 + (v806 + v804), v807, v808);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        TLOAD(v802, v809);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %t__rm_a0_tmp_v38
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v810 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__rm_a0_tmp_v38
        ;
        uint64_t v811 = (uint64_t) v42;
        TASSIGN(v810, v811);
        // pto: %t__rm_a1_tmp_v39
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v812 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__rm_a1_tmp_v39
        ;
        uint64_t v813 = (uint64_t) v42;
        TASSIGN(v812, v813);
        // pto: %t__row_major_tmp_v40
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v814 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__row_major_tmp_v40
        ;
        uint64_t v815 = (uint64_t) v48;
        TASSIGN(v814, v815);
        pipe_barrier(PIPE_V);
        TSUB(v814, v810, v812);
        // pto: %t__tmp_v89
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v816 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v52);
        // pto: %t__tmp_v89
        ;
        uint64_t v817 = (uint64_t) v48;
        TASSIGN(v816, v817);
        // pto: %n_sink_tile_inline11__rm_a0_tmp_v41
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v818 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %n_sink_tile_inline11__rm_a0_tmp_v41
        ;
        uint64_t v819 = (uint64_t) v48;
        TASSIGN(v818, v819);
        // pto: %n_sink_tile_inline11__rm_a1_tmp_v42
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v820 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %n_sink_tile_inline11__rm_a1_tmp_v42
        ;
        uint64_t v821 = (uint64_t) v47;
        TASSIGN(v820, v821);
        // pto: %n_sink_tile_inline11__row_major_tmp_v43
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v822 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %n_sink_tile_inline11__row_major_tmp_v43
        ;
        uint64_t v823 = (uint64_t) v47;
        TASSIGN(v822, v823);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        TADD(v822, v818, v820);
        // pto: %n_sink_tile_inline11__ssa_v1
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v824 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v52);
        // pto: %n_sink_tile_inline11__ssa_v1
        ;
        uint64_t v825 = (uint64_t) v47;
        TASSIGN(v824, v825);
        // pto: %t__rm_a0_tmp_v44
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v826 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__rm_a0_tmp_v44
        ;
        uint64_t v827 = (uint64_t) v47;
        TASSIGN(v826, v827);
        // pto: %t__rm_a1_tmp_v45
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v828 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__rm_a1_tmp_v45
        ;
        uint64_t v829 = (uint64_t) v42;
        TASSIGN(v828, v829);
        // pto: %t__row_major_tmp_v46
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v830 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__row_major_tmp_v46
        ;
        uint64_t v831 = (uint64_t) v42;
        TASSIGN(v830, v831);
        pipe_barrier(PIPE_V);
        TSUB(v830, v826, v828);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        // pto: %t__tmp_v90
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v832 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v52);
        // pto: %t__tmp_v90
        ;
        uint64_t v833 = (uint64_t) v42;
        TASSIGN(v832, v833);
        // pto: %t__rm_a0_tmp_v47
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v834 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__rm_a0_tmp_v47
        ;
        uint64_t v835 = (uint64_t) v42;
        TASSIGN(v834, v835);
        // pto: %t__row_major_tmp_v48
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v836 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %t__row_major_tmp_v48
        ;
        uint64_t v837 = (uint64_t) v42;
        TASSIGN(v836, v837);
        pipe_barrier(PIPE_V);
        TEXP(v836, v834);
        // pto: %t__tmp_v91
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v838 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v52);
        // pto: %t__tmp_v91
        ;
        uint64_t v839 = (uint64_t) v42;
        TASSIGN(v838, v839);
        // pto: %n_denom_inline10__rm_a0_tmp_v49
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v840 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %n_denom_inline10__rm_a0_tmp_v49
        ;
        uint64_t v841 = (uint64_t) v44;
        TASSIGN(v840, v841);
        // pto: %n_denom_inline10__rm_a1_tmp_v50
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v842 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %n_denom_inline10__rm_a1_tmp_v50
        ;
        uint64_t v843 = (uint64_t) v42;
        TASSIGN(v842, v843);
        // pto: %n_denom_inline10__row_major_tmp_v51
        ;
        Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v844 = Tile<TileType::Vec, float, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v53);
        // pto: %n_denom_inline10__row_major_tmp_v51
        ;
        uint64_t v845 = (uint64_t) v42;
        TASSIGN(v844, v845);
        pipe_barrier(PIPE_V);
        TADD(v844, v840, v842);
        // pto: %n_denom_inline10__ssa_v1
        ;
        Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v846 = Tile<TileType::Vec, float, 16, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v52);
        // pto: %n_denom_inline10__ssa_v1
        ;
        uint64_t v847 = (uint64_t) v42;
        TASSIGN(v846, v847);
        // pto: %n_full_inline60__ssa_v1
        ;
        Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v848 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v51);
        // pto: %n_full_inline60__ssa_v1
        ;
        uint64_t v849 = (uint64_t) v36;
        TASSIGN(v848, v849);
        pipe_barrier(PIPE_V);
        TROWEXPANDDIV(v848, v800, v846);
        // pto: %n_bf16_inline28__ssa_v1
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v850 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v51);
        // pto: %n_bf16_inline28__ssa_v1
        ;
        uint64_t v851 = (uint64_t) v42;
        TASSIGN(v850, v851);
        pipe_barrier(PIPE_V);
        RoundMode v852 = RoundMode::CAST_RINT;
        SaturationMode v853 = SaturationMode::ON;
        TCVT(v850, v848, v852, v853);
        // pto: %m_cos_il_inline8__ssa_v1
        ;
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v854 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v57);
        // pto: %m_cos_il_inline8__ssa_v1
        ;
        uint64_t v855 = (uint64_t) v47;
        TASSIGN(v854, v855);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        TLOAD(v854, v714);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %m_sin_signed_inline12__ssa_v1
        ;
        Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v856 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v57);
        // pto: %m_sin_signed_inline12__ssa_v1
        ;
        uint64_t v857 = (uint64_t) v48;
        TASSIGN(v856, v857);
        TLOAD(v856, v722);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %t__tmp_v92
        ;
        Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v858 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v84);
        // pto: %t__tmp_v92
        ;
        uint64_t v859 = (uint64_t) v36;
        TASSIGN(v858, v859);
        // pto: %m_swapped_flat_inline7__ssa_v1
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v860 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v71);
        // pto: %m_swapped_flat_inline7__ssa_v1
        ;
        uint64_t v861 = (uint64_t) v44;
        TASSIGN(v860, v861);
        TGATHER(v860, v858, v284, v627);
        // pto: %m_swapped_inline184__ssa_v1
        ;
        Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v862 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v57);
        // pto: %m_swapped_inline184__ssa_v1
        ;
        uint64_t v863 = (uint64_t) v44;
        TASSIGN(v862, v863);
        // pto: %m_rope_inline9__ssa_v1_textract
        ;
        Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v864 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v57);
        // pto: %m_rope_inline9__ssa_v1_textract
        ;
        uint64_t v865 = (uint64_t) v43;
        TASSIGN(v864, v865);
        pipe_barrier(PIPE_V);
        uint16_t v866 = static_cast<uint16_t>(v72);
        uint16_t v867 = static_cast<uint16_t>(v85);
        TEXTRACT(v864, v848, v866, v867);
        // pto: %t__tmp_v93
        ;
        Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v868 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v57);
        // pto: %t__tmp_v93
        ;
        uint64_t v869 = (uint64_t) v36;
        TASSIGN(v868, v869);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        TCOLEXPANDMUL(v868, v864, v854);
        // pto: %t__tmp_v94
        ;
        Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v870 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v57);
        // pto: %t__tmp_v94
        ;
        uint64_t v871 = (uint64_t) v43;
        TASSIGN(v870, v871);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        TCOLEXPANDMUL(v870, v862, v856);
        // pto: %m_rot_inline58__ssa_v1
        ;
        Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v872 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v57);
        // pto: %m_rot_inline58__ssa_v1
        ;
        uint64_t v873 = (uint64_t) v36;
        TASSIGN(v872, v873);
        pipe_barrier(PIPE_V);
        TADD(v872, v868, v870);
        // pto: %n_rope_bf16_inline6__ssa_v1
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v874 = Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v57);
        // pto: %n_rope_bf16_inline6__ssa_v1
        ;
        uint64_t v875 = (uint64_t) v43;
        TASSIGN(v874, v875);
        pipe_barrier(PIPE_V);
        RoundMode v876 = RoundMode::CAST_RINT;
        SaturationMode v877 = SaturationMode::ON;
        TCVT(v874, v872, v876, v877);
        // pto: %t__tmp_v95
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v878 = Tile<TileType::Vec, bfloat16_t, 16, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v85);
        // pto: %t__tmp_v95
        ;
        uint64_t v879 = (uint64_t) v42;
        TASSIGN(v878, v879);
        // pto: %280
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, 16, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v880;
        // pto: %280
        ;
        uint64_t v881 = (uint64_t) v42;
        TASSIGN(v880, v881);
        // pto: %n_full_bf16_inline178__ssa_v1
        ;
        Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v882 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v53, v51);
        // pto: %n_full_bf16_inline178__ssa_v1
        ;
        uint64_t v883 = (uint64_t) v36;
        TASSIGN(v882, v883);
        pipe_barrier(PIPE_V);
        TCONCAT(v882, v880, v874);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        // pto: %n_group_bf16_inline177__ssa_v1
        ;
        Tile<TileType::Vec, bfloat16_t, 2, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v884 = Tile<TileType::Vec, bfloat16_t, 2, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v82, v61);
        // pto: %n_group_bf16_inline177__ssa_v1
        ;
        uint64_t v885 = (uint64_t) v36;
        TASSIGN(v884, v885);
        // pto: %n_pack_first_inline40__ssa_v1
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v886 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v61);
        // pto: %n_pack_first_inline40__ssa_v1
        ;
        uint64_t v887 = (uint64_t) v36;
        TASSIGN(v886, v887);
        // pto: %281
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v888;
        // pto: %281
        ;
        uint64_t v889 = (uint64_t) v36;
        TASSIGN(v888, v889);
        // pto: %n_pack_second_inline132__ssa_v1
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v890 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v61);
        // pto: %n_pack_second_inline132__ssa_v1
        ;
        uint64_t v891 = (uint64_t) v50;
        TASSIGN(v890, v891);
        // pto: %282
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v892;
        // pto: %282
        ;
        uint64_t v893 = (uint64_t) v50;
        TASSIGN(v892, v893);
        // pto: %283, %284, %285
        ;
        int64_t v894 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) (v775 / v86) * (uint64_t) v59) + (uint64_t) v516);
        // pto: %286
        ;
        int64_t v895 = (int64_t) ((uint64_t) v894 + (uint64_t) v59);
        // pto: %287
        ;
        int64_t v896 = v894 < v72 ? v72 : v894;
        // pto: %288
        ;
        __gm__ bfloat16_t* v897 = PTOAS__GLOBAL_TENSOR_DATA(v194);
        // pto: %288
        ;
        const int64_t v898 = 0;
        // pto: %288
        ;
        const int64_t v899 = 4096;
        // pto: %288
        ;
        pto::Shape<1, 1, 1, 1, 4096> v900 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %288
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v901 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %288
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v902 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v897 + (v898 + v896 * v899), v900, v901);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
        TSTORE(v902, v888);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
        // pto: %289
        ;
        int64_t v903 = v895 < v72 ? v72 : v895;
        // pto: %290
        ;
        __gm__ bfloat16_t* v904 = PTOAS__GLOBAL_TENSOR_DATA(v194);
        // pto: %290
        ;
        const int64_t v905 = 0;
        // pto: %290
        ;
        const int64_t v906 = 4096;
        // pto: %290
        ;
        pto::Shape<1, 1, 1, 1, 4096> v907 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %290
        ;
        pto::Stride<4096, 4096, 4096, 4096, 1> v908 = pto::Stride<4096, 4096, 4096, 4096, 1>();
        // pto: %290
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v909 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v904 + (v905 + v903 * v906), v907, v908);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v909, v892);
        // pto: %reset_m_inline3__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v910 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
        // pto: %reset_m_inline3__ssa_v0
        ;
        uint64_t v911 = (uint64_t) v36;
        TASSIGN(v910, v911);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
        TLOAD(v910, v293);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %reset_l_inline2__rm_a0_tmp_v52
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v912 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %reset_l_inline2__rm_a0_tmp_v52
        ;
        uint64_t v913 = (uint64_t) v36;
        TASSIGN(v912, v913);
        // pto: %reset_l_inline2__row_major_tmp_v53
        ;
        Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v914 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v52, v65);
        // pto: %reset_l_inline2__row_major_tmp_v53
        ;
        uint64_t v915 = (uint64_t) v42;
        TASSIGN(v914, v915);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        TMULS(v914, v912, v73);
        // pto: %reset_l_inline2__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v916 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
        // pto: %reset_l_inline2__ssa_v0
        ;
        uint64_t v917 = (uint64_t) v42;
        TASSIGN(v916, v917);
        // pto: %reset_left_inline1__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v918 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v74);
        // pto: %reset_left_inline1__ssa_v0
        ;
        uint64_t v919 = (uint64_t) v37;
        TASSIGN(v918, v919);
        TEXPANDS(v918, v73);
        // pto: %reset_right_inline0__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v920 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v74);
        // pto: %reset_right_inline0__ssa_v0
        ;
        uint64_t v921 = (uint64_t) v38;
        TASSIGN(v920, v921);
        TEXPANDS(v920, v73);
      } else {
        // pto: %m_valid_inline100__rv_v0_mv
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v922 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
        // pto: %m_valid_inline100__rv_v0_mv
        ;
        uint64_t v923 = (uint64_t) v36;
        TASSIGN(v922, v923);
        pipe_barrier(PIPE_V);
        TMOV(v922, v229);
        // pto: %l_valid_inline26__rv_v0_mv
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v924 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
        // pto: %l_valid_inline26__rv_v0_mv
        ;
        uint64_t v925 = (uint64_t) v42;
        TASSIGN(v924, v925);
        TMOV(v924, v231);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    } else {
      // pto: %1
      ;
      Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v926 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
      // pto: %1
      ;
      uint64_t v927 = (uint64_t) v36;
      TASSIGN(v926, v927);
      pipe_barrier(PIPE_V);
      TMOV(v926, v286);
      // pto: %2
      ;
      Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v928 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
      // pto: %2
      ;
      uint64_t v929 = (uint64_t) v42;
      TASSIGN(v928, v929);
      TMOV(v928, v298);
    };
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    // pto: %l_after_inline29__rv_v0_mv
    ;
    Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v930 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
    // pto: %l_after_inline29__rv_v0_mv
    ;
    uint64_t v931 = (uint64_t) v41;
    TASSIGN(v930, v931);
    pipe_barrier(PIPE_V);
    TMOV(v930, v223);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    // pto: %m_after_inline72__rv_v0_mv
    ;
    Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v932 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v65, v52);
    // pto: %m_after_inline72__rv_v0_mv
    ;
    uint64_t v933 = (uint64_t) v40;
    TASSIGN(v932, v933);
    pipe_barrier(PIPE_ALL);
    TMOV(v932, v221);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}