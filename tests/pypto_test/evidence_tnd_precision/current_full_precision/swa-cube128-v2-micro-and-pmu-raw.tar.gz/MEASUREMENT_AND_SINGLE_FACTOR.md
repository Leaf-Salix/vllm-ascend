# QK/PV 内部计数与单因素优化（2026-10-19）

## 目标与身份

保留 `1d6dbd02700cf8686fd1e82a87558c188fcbdf5d` 精度基准，仅在独立目录验证。分支 `dev/pypto-dsv4-csa-nalinaly-tnd-20261008-codex`。Nal 性能版固定 `a919f11942d93627441c8fa694e310dcbd1c671b`，不把其数值路径作为精度金值。Native 为本环境实际 `npu_sparse_attn_sharedkv`。

## 测量能回答和不能回答的问题

- 固定同一 Native 捕获的 Q、cache、TopK、Native inverse RoPE 前 BF16 heads，program-mode 读取每个 AIC/AIV 的 Cube、Vector、Scalar、MTE busy cycles。
- kernel-mode FULL graph 当前明确拒绝 PMU；program-mode 计数用于解释工作量，实际收益必须另做关闭 DFX 的同卡交错 FULL graph 测量。
- busy counters 可重叠，不能相加或拿 total 减去各 busy 称作同步等待。当前工具不能直接给出各 set/wait 的等待周期；这里未声称得到这项精确分解。
- Native 用 CANN 采集；Nal root 还包含 inverse RoPE/publish；TND qk_pv 不包含。这些数值不是严格等范围的三方计时排名。
- 同 bank Native heads 是精度金值，baseline PTO 的 raw FP32 mi/li/oi 是改变前后中间状态金值。Nal 的测量完成不代表其逐bit一致。

## 找到的单因素

SWA 最多128个真实 Key，但原精度版在512宽数值块上为QK/PV执行四个128片。候选仅让SWA的Cube计算第一片，其余compressed块的四片顺序不变。保留原K512 softmax/实际K归约树、BF16 CAST_ROUND、online更新顺序、所有跨核事件和KV载入。未写score尾部通过显式正零构造，避免读未初始化GM。

这是一个“SWA Cube有效宽度”候选，同时改变QK和PV的无效计算；不能据总收益分别分摊QK/PV节省时间。省略零项累加不是纯代数的bit证明，因此实际比较raw FP32统计的全部字节。

候选 program-mode 59项通过，包含Native heads、baseline FP32统计、有限值、重复稳定性。详见 `PMU_SWA_CUBE_FOUR_WAY_REVIEW.md` 和原始CSV SHA。

## 无插桩 FULL graph sparse 局部门禁

每任务两臂同卡、20轮×100 replay交错顺序，四个输出prefix/suffix guard；A/B/ABA、Q=0、NaN poison和只读输入检查。每次71项检查均通过。所有80个配对轮次候选均更快。

| 配置 | 独立重复 | 原版µs | 候选µs | 延迟下降 |
| --- | --- | ---: | ---: | ---: |
| 8K/B4/T24 | r1 | 236.487 | 217.648 | 7.97% |
| 8K/B4/T24 | r2 | 227.034 | 219.317 | 3.40% |
| 8K/B40/T240 | r1 | 963.384 | 881.135 | 8.54% |
| 8K/B40/T240 | r2 | 978.618 | 908.281 | 7.19% |

这是完整sparse诊断root（包含planner和统计/heads发布）范围，既不是纯QK时间，也不是完整CSA或整模型收益。跨任务原版漂移，所以不平均成一个固定百分比。

## 正式入口候选绑定

仅更改原3365文件中的sparse一个文件，43运行文件中其余42份保持不变；62 Tensor单入口和真正TND仍保持。新snapshot manifest为 `2c1f3bc97187e6c6f2cac4bdee086a631bae2a2b7a1b023bb0e99b28a1bd6b72`；候选Sparse为 `0b6c0af7100bcb87010a9a7fc19690d48f074648a9b1f6b3d8c124384af14149`。

v1实际完整CSA T21/T1/T240均通过Native逐bit门禁。格式检查发现仅一处concat换行需格式化，因此保留v1，另建最终v2（AST完全相同）。v2 Sparse为 `248d8b11bb0a045f7863c0b264d962845dcabafa51cbf1e5fafee413fa8dc6d5`，snapshot manifest为 `639b1280dc682dad23195509ddd51970d0d16da55fa11efa302e9edc97da7e03`。后续混合21和整模型证据绑定真实v2源；不将v1硬件记录重标为v2。

真实整模型8K、128K仍待本轮实测，不得把局部通过提前称为整模型验收。

## 已遇到的测试助手问题

完整记录见 `TASKS.json`。包括：重复compile导致仅SSA命名/包装identity变化而被冻结artifact门禁拒绝；同进程二次PMU初始化SHM失败（首窗口有效）；task-submit自动追加device参数导致一次parser错误；一次wrapper路径拼接缺段立即127。均没有数值首差，已修正助手且保留失败历史，未弱化精度断言。
