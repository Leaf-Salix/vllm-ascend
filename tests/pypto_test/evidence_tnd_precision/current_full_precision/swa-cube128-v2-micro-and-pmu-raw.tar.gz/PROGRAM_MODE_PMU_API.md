# 固定 227 SDK 的 Program-mode PMU 调用合同

核查日期：2026-10-19。只读核查固定 PyPTO/Simpler Python/C++ 源码；本核查没有运行 NPU、改 SDK 或改正式算子。

## 最小调用

```python
from pathlib import Path
from pypto.runtime import RunConfig

# wrapper 是 @pl.jit 顶层入口；所有 Tensor（包括 Out）具有完整注解。
# 不调用 pypto.torch.init()，不在此进程先执行 kernel-mode root。
work_dir = Path("/absolute/owned/experiment/program-pmu-pipe-v1")
compiled = wrapper.compile(config=RunConfig(
    platform="a2a3",
    save_kernels=True,
    save_kernels_dir=str(work_dir),
))
print("PROGRAM_BUILD", compiled.output_dir, compiled.runtime_name)
print("PROGRAM_RUNTIME_CONFIG", compiled.runtime_config)
assert compiled.runtime_name == "tensormap_and_ringbuffer"

# cpu_args 全部是 caller 供应的 CPU torch Tensor / 普通 scalar。
# 包括每个 Out/InOut；CompiledProgram 不自动分配漏传的输出。
compiled(*cpu_args, config=RunConfig(
    platform="a2a3",       # 必须显式写；RunConfig 默认是 a2a3sim！
    device_id=0,
    aicpu_thread_num=4,
    enable_pmu=2,           # PIPE_UTILIZATION
    enable_chip_swimlane=0,
    enable_dep_gen=False,
    enable_dump_args=0,
    enable_scope_stats=False,
))
pmu_csv = compiled.output_dir / "dfx_outputs" / "pmu.csv"
assert pmu_csv.is_file() and pmu_csv.stat().st_size > 0
```

`wrapper.compile()` 不读取样例 Tensor 的内容；注解完整时也不需要样例。`.compile()` 只生成代码，首次读取 `runtime_name` / `runtime_config` 会懒编译、准备可执行产物，但不执行 NPU。首次 `compiled(...)` 会执行设备程序并把 Out/InOut 写回 caller 的 CPU Tensor；返回值是 `None`。

## Runtime、目录和 core/thread 设置

- **`RunConfig` 没有 `runtime` 或 `aicore_num` 参数。** 默认编译 runtime 已是 TensorMap/ringbuffer。如需显式固定：

  ```python
  from pypto.ir import PassContext
  from pypto.pypto_core.passes import RuntimeKind

  with PassContext([], runtime=RuntimeKind.TENSORMAP_AND_RINGBUFFER):
      compiled = wrapper.compile(config=compile_cfg)
  ```

- `save_kernels_dir` 在 **compile 阶段**映射到 `ir.compile(output_dir=...)`。执行阶段从已编译 artifact 的目录创建 `dfx_outputs`，不能靠 dispatch `RunConfig(save_kernels_dir=...)` 把已编译程序的 PMU 改到另一目录。
- 最小方案用每次实验独立的显式 `save_kernels_dir`，避开 persistent-cache 路径。persistent artifact 的输出使用独立 `ArtifactRuntime.run_directory`，不写 immutable cache 内部。
- Simpler 当前 program run 固定占整卡，orchestration 用 `rt_available_cluster_count()` 读取可用宽度；没有 `RunConfig(aicore_num=24)`。227 已知卡为 24 AIC / 48 AIV，仍应记录实际日志及 PMU `core_type/core_id`，避免只依据请求值声称核心数。
- `aicpu_thread_num=None` 的优先级是 dispatch override → 生成 `kernel_config.py` 中的 `RUNTIME_CONFIG` → Simpler 默认。CallConfig 的默认 `0` 是 auto；a2a3 auto=4，显式正常 run 至少为 2。示例显式固定 4。
- 任务系统只给该进程分配一张卡时，使用其可见映射内 `device_id=0`；不可把服务器物理卡号与可见逻辑编号混用。

## PMU 采集的必要门禁

1. 独立 program 进程。program-mode 与 `pypto.torch.init()` 后的 kernel-mode 执行互斥。
2. 清除 `SIMPLER_PMU_EVENT_TYPE`，或把它明确设为 `2`；该环境变量会覆盖请求事件。
3. `pmu.csv` 名称固定、输出目录是唯一性边界。多次 `compiled(...)` 之后立即复制当前 CSV 为独立编号，避免后一次覆盖前一次；每次恢复可变输入/cache 状态。
4. PMU-only 不打开 swimlane。当前 onboard 的 `enable_chip_swimlane>0` 会先以子进程额外执行 dep-gen，再运行 timing pass；`enable_dep_gen=False` 不会阻止这次自动结构采集。需要 swimlane 时单独执行并按两次运行处理状态。
5. 不设置 `golden_data_dir`、不打开参数全量 dump；本路径不需要保存 Tensor 文件。
6. root 把 sparse helper 返回的 `mi/li/oi` 显式写到 caller Out，防止未消费结果被消除；先与现有 FULL-graph/Native 中对应边界逐 bit 核对。
7. 以该次 actual `kernel_config.py` 的 `func_id` / 源文件映射识别 `qk_pv_aic/aiv`，再检查每条记录的 core 类型、调用次数和非空计数。

## 可测和不可测的含义

program executor 的 `pmu_aicore_begin/end` 包围每个 `execute_task`。CSV 含 encoded `task_id`、`func_id`、`core_type`、`total_cycles` 及事件组计数，因此可把 QK/PV AIC、AIV 的各自整 task 流水活跃度分开；这比外层 ACL root 级 profiler 更精确。

事件 2 的 Cube/Vector/Scalar/MTE busy 是并发流水计数，**不能相加成计算、搬运、等待的 wall-time 分解**。事件 6 可补充特定 bank/Vector 资源冲突；没有在当前 DSL 中找到可直接插入内核 span/cycle 标记的公开接口。program-mode PMU 结果是诊断证据；其调度模式、CPU↔设备搬运和单次初始化不等同于生产 FULL-graph 延迟，正式性能仍应由原无 DFX graph 计时衡量。

## 核查证据

本目录保存了实际固定文件的只读摘录：

- `program-mode-call-source.txt`：`JITFunction.compile`、`CompiledProgram.__call__`、artifact 输出目录合同。
- `program-mode-dispatch-source.txt`：`RunConfig.compile_options` 的 output_dir 映射。
- `program-mode-execution-contract.txt`：`_invoke_compiled`、`_execute_compiled`、Worker 的实际调用链。
- `program-mode-imports-and-core-policy.txt`：PassContext 导入、整卡 core policy、固定 PMU 文件及 event override。
- `program-mode-callconfig-validation.txt`：a2a3 AICPU auto=4、显式至少 2。
- `OBSERVABILITY_REVIEW.md`、`pmu-tests-and-executor.txt`：已固定 DSL/PMU 观测边界及 executor 计数范围。

以上结论是源码/API 核查；还不是该新 wrapper 的硬件采集通过结论。
