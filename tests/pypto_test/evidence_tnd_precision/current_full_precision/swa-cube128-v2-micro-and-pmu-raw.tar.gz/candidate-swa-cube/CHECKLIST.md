# 独立三方runner检查

- [x] 复用旧完整边界与同fixture，Nal38文件pin不变
- [x] 显式候选DIR/ENV/MANIFEST/SHA/ROOTMODULE和62ABI门禁
- [x] Native/TND首差停，Nal精度只记录
- [x] eligible、实际delegate调用、Native fallback计数、FULL/ABA/guard与身份记录
- [x] 本地AST/语法/shell静态检查
- [ ] 上传并在默认V4环境执行只读preflight（不生成全核、不申请NPU）
- [ ] 主线程数值验收选定variant后分别提交B4/B40

每task一个B、750/780秒；无DFX、无scheduler。
