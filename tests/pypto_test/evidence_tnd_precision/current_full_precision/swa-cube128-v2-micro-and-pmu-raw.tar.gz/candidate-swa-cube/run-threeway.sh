#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
source "$(dirname "${BASH_SOURCE[0]}")/env.sh"
label="${1:?new result label required}"
batch="${2:?batch4 or40 required}"
shift 2
[[ "$label" =~ ^[A-Za-z0-9_.-]+$ ]]
[[ "$batch" == 4 || "$batch" == 40 ]]
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
out="$job/csa-results/$label"
mkdir -p "$job/csa-results"
mkdir "$out"
export out
ccache -s > "$out/ccache.log"
export ASCEND_CACHE_PATH="$out/ascend-cache" ASCEND_PROCESS_LOG_PATH="$out/ascend"
export VLLM_CACHE_ROOT="$out/vllm-cache"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH" "$VLLM_CACHE_ROOT"
# One B per task; caller sets task max-time780. Includes preflight/OPP/probe.
timeout --signal=TERM --kill-after=15s 750s bash "$job/worker.sh" "$batch" "$@" > "$out/run.log" 2>&1
