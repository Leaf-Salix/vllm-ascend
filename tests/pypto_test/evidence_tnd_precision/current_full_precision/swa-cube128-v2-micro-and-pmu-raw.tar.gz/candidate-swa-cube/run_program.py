"""独立 program 进程：先 Native bit 门禁，再采每 task PMU。"""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import time
import torch
from pypto.runtime import RunConfig
from pypto.ir import CompiledProgram

parser = argparse.ArgumentParser()
parser.add_argument("--bank", type=Path, required=True)
parser.add_argument("--bank-sha", required=True)
parser.add_argument("--out", type=Path, required=True)
parser.add_argument("--event", type=int, choices=(0, 2, 6), default=2)
parser.add_argument("--save-stats", action="store_true")
parser.add_argument("--gold-stats", type=Path)
parser.add_argument("--gold-sha")
parser.add_argument("--device", type=int, help="task-submit physical device hint; runtime uses visible logical device 0")
args = parser.parse_args()
args.out.mkdir()
assert hashlib.sha256(args.bank.read_bytes()).hexdigest() == args.bank_sha
assert not os.environ.get("SIMPLER_PMU_EVENT_TYPE"), "ambient PMU override"
bank = torch.load(args.bank, map_location="cpu", weights_only=False)
kwargs = bank["kwargs"]
report = {"pass": False, "complete": False, "scope": "isolated sparse program-mode, not production FULL timing",
          "bank_sha": args.bank_sha, "checks": [], "event": args.event, "runs": [],
          "readonly_scope": "Host CPU arguments unchanged; not a device In-tensor copyback guard",
          "stats_gold_scope": "mi/li/oi compare repeated original PTO executions, not inaccessible Native internal statistics"}


def save():
    (args.out / "result.json").write_text(json.dumps(report, indent=2) + "\n")


def check(label, actual, expected):
    assert actual.dtype == expected.dtype and actual.shape == expected.shape, label
    diff = actual.contiguous().view(torch.uint8) != expected.contiguous().view(torch.uint8)
    same = not bool(diff.any())
    report["checks"].append({"label": label, "bit_equal": same, "different_bytes": int(diff.sum())})
    save()
    assert same, "FIRST_BIT_DIFFERENCE " + label


save()
q = bank["q"]
tokens, heads, dim = q.shape
bounds = kwargs["cu_seqlens_q"].reshape(-1).to(torch.int32)
lengths = kwargs["seqused_kv"].reshape(-1).to(torch.int32)
assert bounds[0] == 0 and bounds[-1] == tokens and len(bounds) == len(lengths) + 1
requests = torch.repeat_interleave(torch.arange(len(lengths), dtype=torch.int32), bounds[1:] - bounds[:-1])
assert torch.equal(bounds[1:] - bounds[:-1], torch.tensor(bank["lengths"]))
assert (heads, dim) == (64, 512)
ori, cmp = kwargs["ori_kv"], kwargs["cmp_kv"]
assert all(bank["original_layout"][key]["contiguous"] for key in ("q", "ori_kv", "cmp_kv")), "layout changed"
inputs = [q, ori.reshape(-1, 32, 1, 512), kwargs["ori_block_table"],
          cmp.reshape(-1, 32, 1, 512), kwargs["cmp_block_table"],
          kwargs["cmp_sparse_indices"].reshape(tokens, 512), bank["positions"].reshape(tokens, 1),
          lengths, requests, kwargs["sinks"].reshape(64).to(torch.float32),
          torch.ones(tokens, 64, dtype=torch.float32), torch.zeros(tokens, 64, dtype=torch.float32)]
assert all(value.device.type == "cpu" and value.is_contiguous() for value in inputs)
outputs = [torch.empty(tokens, 64), torch.empty(tokens, 64), torch.empty(tokens, 64, 512),
           torch.empty(tokens, 64, 512, dtype=torch.bfloat16)]
compiled = CompiledProgram.from_dir(Path(__file__).resolve().parent / "frozen-artifact", platform="a2a3")
report["artifact"] = str(compiled.output_dir)
report["source_identity"] = bank["source_identity"]
report["source_identity_scope"] = "bank origin; current source is separately rechecked by preflight.log"
expected_kernels = {"aic": "f3788fed7cd3ef145e96ebd7185f7cb7030ae3f7aec5a9fff21725a97eb66f6d",
                    "aiv": "fd276e9d112cd1bcceb0fb300ad891ab13db86eb8d99dd2d08562bf73c297fbf"}
for core, sha in expected_kernels.items():
    source = Path(compiled.output_dir) / "kernels" / core / f"qk_pv_{core}.cpp"
    assert hashlib.sha256(source.read_bytes()).hexdigest() == sha, "unreviewed generated QK/PV"
gold = None
reference_stats = None
if args.gold_stats:
    assert args.gold_sha and hashlib.sha256(args.gold_stats.read_bytes()).hexdigest() == args.gold_sha
    reference_stats = torch.load(args.gold_stats, map_location="cpu", weights_only=False)
    assert reference_stats["bank_sha"] == args.bank_sha
for index, pmu in enumerate((0, 0, args.event) if args.event else (0, 0)):
    for value in outputs:
        value.fill_(float("nan"))
    before = [value.clone() for value in inputs]
    pmu_source = Path(compiled.output_dir) / "dfx_outputs" / "pmu.csv"
    if pmu and pmu_source.exists():
        shutil.move(pmu_source, args.out / f"pmu-before-{index}.csv")
    started = time.monotonic()
    compiled(*inputs, *outputs, config=RunConfig(platform="a2a3", device_id=0, aicpu_thread_num=4,
        enable_pmu=pmu, enable_chip_swimlane=0, enable_dep_gen=False, enable_dump_args=0))
    report["runs"].append({"index": index, "pmu": pmu, "host_seconds": time.monotonic() - started})
    assert all(bool(torch.isfinite(value).all()) for value in outputs), "nonfinite sparse output/statistics"
    check(f"run{index}.Native.pre_inverse_heads", outputs[-1], bank["native_heads"].reshape(tokens, 64, 512))
    if reference_stats:
        for label, value in zip(("mi", "li", "oi", "heads"), outputs):
            check(f"run{index}.baseline_PTO.{label}", value, reference_stats[label])
    for i, value in enumerate(inputs):
        check(f"run{index}.readonly.{i}", value, before[i])
    if gold is not None:
        for label, actual, expected in zip(("mi", "li", "oi", "heads"), outputs, gold):
            check(f"run{index}.repeat.{label}", actual, expected)
    else:
        gold = [value.clone() for value in outputs]
        if args.save_stats:
            torch.save({"bank_sha": args.bank_sha, **dict(zip(("mi", "li", "oi", "heads"), gold))}, args.out / "stats-gold.pt")
    if pmu:
        assert pmu_source.is_file() and pmu_source.stat().st_size > 100, "missing fresh per-task PMU"
        records = list(csv.DictReader(pmu_source.open()))
        assert records and {"func_id", "core_type", "pmu_total_cycles"}.issubset(records[0]), "invalid PMU schema"
        assert any(int(row["func_id"]) in (3, 4) and int(row["pmu_total_cycles"]) > 0 for row in records), "missing QK/PV counters"
        report["runs"][-1]["PMU_rows"] = len(records)
        shutil.copy2(pmu_source, args.out / f"pmu-{index}.csv")
    save()
report["pass"] = report["complete"] = True
save()
print("SPARSE_PROGRAM_PMU_PASS", flush=True)
