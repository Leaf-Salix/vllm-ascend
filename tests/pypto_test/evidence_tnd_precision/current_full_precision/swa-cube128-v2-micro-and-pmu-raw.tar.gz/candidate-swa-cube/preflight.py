"""只读源/helper/runtime身份和三方配置预检，不生成内核、不申请NPU。"""
import importlib
import json
import os
from pathlib import Path
from tri_identity import identity
record,root=identity()
paths={}
for name in ('torch','torch_npu','vllm','vllm_ascend','pypto','simpler','npugraph_ex'):
    module=importlib.import_module(name);path=Path(module.__file__).resolve()
    paths[name]={'path':str(path),'version':str(getattr(module,'__version__',None))}
    if name=='vllm_ascend':assert path.is_relative_to(Path(os.environ['SOURCE_ROOT']).resolve())
    if name=='pypto':assert path.is_relative_to(Path(os.environ['LOW_ACCEPTANCE_RUNTIME_PACKAGE']).resolve()/'pypto')
    if name=='simpler':assert path.is_relative_to(Path('/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/python/simpler').resolve())
for name in ('PTOAS_ROOT','ASCEND_HOME_PATH','ATB_HOME_PATH','CCACHE_DIR'):
    assert os.environ.get(name),name
from vllm_ascend import envs
assert envs.VLLM_ASCEND_ENABLE_NZ==2 and envs.PTO_CSA_RUNTIME=='tensormap_and_ringbuffer'
assert envs.VLLM_ASCEND_PTO_CSA_ATOMIC_ADD==0
assert os.environ['PYTHONNOUSERSITE']=='1' and os.environ['HCCL_DETERMINISTIC']=='true'
from pypto.jit._toolchain import capture_toolchain
assert capture_toolchain('a2a3','tensormap_and_ringbuffer').usable
record.update(runtime_identities=paths,config={'SK':0,'NZ':2,'runtime':envs.PTO_CSA_RUNTIME,'atomic':0,'HCCL_DETERMINISTIC':True})
print('TRI_PREFLIGHT_PASS',json.dumps(record,sort_keys=True),flush=True)
import hashlib
import sys
import types
here=Path(__file__).resolve().parent
historical=types.ModuleType('historical_pypto');historical.__path__=[str(here/'bsh-source/vllm_ascend/ops/pypto')]
sys.modules['historical_pypto']=historical
adapter=importlib.import_module('historical_pypto.deepseek_v4_flash_csa.native_adapter')
assert Path(adapter.__file__).resolve().is_relative_to(here/'bsh-source')
record['bsh_actual_root_abi']={'count':len(adapter.decode_csa_tp1_layer_test.param_names),'param_names':list(adapter.decode_csa_tp1_layer_test.param_names),'adapter':str(Path(adapter.__file__).resolve())}
meta=Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE'])/'metadata.json'
assert hashlib.sha256(meta.read_bytes()).hexdigest()=='863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
print('TRI_BSH_IDENTITY_PASS',json.dumps(record['bsh_actual_root_abi']),flush=True)
