#!/usr/bin/env bash
# Pin all candidate identity inputs; never accept ambient defaults.
export TRI_VARIANT_DIR=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overnight-20261019/whole-formal-v6/snapshot/source
export TRI_VARIANT_ENV=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overnight-20261019/formal-csa-v6/env.sh
export TRI_EXPECTED_MANIFEST=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overnight-20261019/whole-formal-v6/snapshot/manifest.json
export TRI_EXPECTED_MANIFEST_SHA256=6d9656de4580ba5f768881c417f3093a7744808ac6518c594e9db881971e7ab2
export TRI_ROOT_MODULE=vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.decode_csa
export TRI_ROOT_ATTR=decode_csa_tp1_layer_test
