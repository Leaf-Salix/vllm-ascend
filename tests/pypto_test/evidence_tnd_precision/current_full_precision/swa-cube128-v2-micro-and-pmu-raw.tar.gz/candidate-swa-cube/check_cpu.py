"""独立runner小范围静态门禁：复制与范围、路由、计时、参数化边界。"""
import ast
import hashlib
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
s=(HERE/'probe_threeway.py').read_text();tree=ast.parse(s)
old=(HERE.parent/'threeway/probe_threeway.py').read_text();oldtree=ast.parse(old)
for name in ('NativeHalf','PTOHalf','RequirePTO'):
    fn=lambda t:next(n for n in t.body if isinstance(n,ast.ClassDef) and n.name==name)
    assert ast.dump(fn(tree),include_attributes=False)==ast.dump(fn(oldtree),include_attributes=False),name+' boundary changed'
assert (HERE/'ragged_fixture.py').read_bytes()==(HERE.parent/'threeway/ragged_fixture.py').read_bytes()
assert 'from staged_csa' not in s and 'overnight_tnd_15a9' not in s
assert "super_kernel_optimize':False" in s and "weight_nz_mode':2" in s
assert "lengths = [6]*args.batch" in s and "choices=(4,40)" in s
assert 'for _ in range(args.timing_iters):graph.replay()' in s and 'range(8)' in s
assert 'fallback_calls[arm]+=1' in s and "assert fallback_calls[arm]==0" in s
assert "assert guarded.calls>eager_calls" in s
assert "if arm=='tnd':\n                    raise RuntimeError" in s
assert "report['bsh_precision_not_a_performance_gate']=True" in s
pin=json.loads((HERE/'nalinaly-pin.json').read_text());assert len(pin['files'])==38
for f in pin['files']:assert hashlib.sha256((HERE/'bsh-source'/f['path']).read_bytes()).hexdigest()==f['sha256']
for f in HERE.rglob('*.py'):ast.parse(f.read_text())
print('CPU_PASS: reused HCpre-to-HCpost boundaries, exact fixture, pin38, actual route assertions, SK0/NZ2, oneB, no old root')
