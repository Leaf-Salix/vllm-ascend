"""显式候选、固定Nal源码与独立runner的身份门禁；不猜源目录。"""
import hashlib
import importlib
import json
import os
from pathlib import Path
HERE=Path(__file__).resolve().parent
SHA=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def checked_manifest(root, manifest_path, expected_sha=None):
    root=root.resolve();manifest_path=manifest_path.resolve()
    if expected_sha is not None:
        assert len(expected_sha)==64 and SHA(manifest_path)==expected_sha,'explicit manifest SHA mismatch'
    raw=json.loads(manifest_path.read_text());files=raw.get('files',raw)
    assert isinstance(files,dict) and files
    for name,sha in files.items():
        target=(root/name).resolve()
        assert target.is_relative_to(root),'manifest path escapes explicit source directory'
        assert SHA(target)==sha,(name,'manifest source mismatch')
    return files

def identity(import_root=True):
    helper_files=checked_manifest(HERE,HERE/'manifest.json')
    pin=json.loads((HERE/'nalinaly-pin.json').read_text())
    assert pin['commit']=='a919f11942d93627441c8fa694e310dcbd1c671b'
    assert pin['git_tar_commit']==pin['commit'] and len(pin['files'])==38
    for record in pin['files']:
        assert SHA(HERE/'bsh-source'/record['path'])==record['sha256']
    variant=Path(os.environ['TRI_VARIANT_DIR']).resolve()
    env=Path(os.environ['TRI_VARIANT_ENV']).resolve()
    expected=Path(os.environ['TRI_EXPECTED_MANIFEST']).resolve()
    expected_sha=os.environ['TRI_EXPECTED_MANIFEST_SHA256']
    files=checked_manifest(variant,expected,expected_sha)
    runtime_root=Path(os.environ['SOURCE_ROOT']).resolve()
    runtime_files=checked_manifest(runtime_root,runtime_root.parent/'manifest.json')
    result={'runner_dir':str(HERE),'helper_manifest_sha256':SHA(HERE/'manifest.json'),
            'helper_file_count':len(helper_files),'variant_dir':str(variant),'variant_env':str(env),
            'variant_env_sha256':SHA(env),'expected_manifest':str(expected),'expected_manifest_sha256':expected_sha,
            'variant_file_count':len(files),'runtime_source_root':str(runtime_root),'runtime_source_files':len(runtime_files),
            'root_module':os.environ['TRI_ROOT_MODULE'],'root_attr':os.environ['TRI_ROOT_ATTR'],
            'nal_commit':pin['commit'],'nal_files':len(pin['files'])}
    if import_root:
        module=importlib.import_module(result['root_module'])
        path=Path(module.__file__).resolve()
        assert path.is_relative_to(variant),'root imported outside explicit TRI_VARIANT_DIR'
        key=path.relative_to(variant).as_posix()
        assert key in files and SHA(path)==files[key],'root absent from explicit manifest'
        root=getattr(module,result['root_attr'])
        names=list(root.param_names)
        assert len(names)==62,('TND ABI must remain62',names)
        result.update(root_file=str(path),root_sha256=SHA(path),root_param_names=names,root_abi_count=len(names))
        return result,root
    return result,None
