#!/usr/bin/env bash
set -euo pipefail
here=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "$here/pin-v6.sh"
exec bash "$here/run-threeway.sh" "$@"
