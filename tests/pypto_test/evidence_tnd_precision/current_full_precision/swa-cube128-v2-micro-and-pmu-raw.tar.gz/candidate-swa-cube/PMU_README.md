# QK/PV PMU 输出粒度预实验

保留正式V6 frozen source6d9656与Nal a919原始helper数据/图/精度门禁，在既有无profiler八轮计时后单独收集3次图重放的CANN PipeUtilization。Level2、关闭shape/memory/stack，不与DFX一起开启。Native/TND八边界bit首差即停；Nal数值差异仅记录。三臂profile后检查状态/guard完全不变。

本实验只验证CANN实际输出字段、launch名称和归因粒度。不将executor PMU当成QK/PV内部PMU，也不把流水busy比率当成可加耗时分解。若仅有executor，需后续等价私有QK/PV-only入口。

一个B4任务，wrapper750秒/task780秒；不改变生产源码或SDK，不安装工具。
