"""只生成私有诊断 root，不申请设备。"""
import json
from pathlib import Path
from pypto.runtime import RunConfig
from sparse_root import sparse_probe

here = Path(__file__).resolve().parent
compiled = sparse_probe.compile(config=RunConfig(
    platform="a2a3", save_kernels=True, save_kernels_dir=str(here / "artifact"),
))
record = {"output_dir": str(compiled.output_dir), "hardware_executed": False,
          "params": list(sparse_probe.param_names)}
(here / "compiled.json").write_text(json.dumps(record, indent=2) + "\n")
print("SPARSE_PROGRAM_GENERATED", json.dumps(record), flush=True)
