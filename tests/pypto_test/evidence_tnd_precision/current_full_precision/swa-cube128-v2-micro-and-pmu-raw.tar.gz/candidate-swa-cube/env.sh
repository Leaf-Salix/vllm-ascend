#!/usr/bin/env bash
tri_runner_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
export TRI_VARIANT_DIR="${TRI_VARIANT_DIR:-/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overnight-20261019/csa-combo-v4}"
export TRI_VARIANT_ENV="${TRI_VARIANT_ENV:-$TRI_VARIANT_DIR/env.sh}"
export TRI_EXPECTED_MANIFEST="${TRI_EXPECTED_MANIFEST:-$TRI_VARIANT_DIR/manifest.json}"
export TRI_EXPECTED_MANIFEST_SHA256="${TRI_EXPECTED_MANIFEST_SHA256:-ed6d6ad1b3ab22a73dd19a92d5f40eb210f1e64929321acbef28de2377ea927b}"
export TRI_ROOT_MODULE="${TRI_ROOT_MODULE:-candidate_csa}"
export TRI_ROOT_ATTR="${TRI_ROOT_ATTR:-decode_csa_tp1_layer_test}"
source "$TRI_VARIANT_ENV"
job="$tri_runner_dir"
export job
export PYTHONPATH="$job:$TRI_VARIANT_DIR:$PYTHONPATH"
export PYPTO_PROG_BUILD_DIR="$job/build" PYPTO_CACHE_DIR="$job/cache"
export PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1
export LOCAL_WORLD_SIZE=1 HCCL_DETERMINISTIC=true
export CMAKE_BUILD_PARALLEL_LEVEL=4 MAX_JOBS=4
