# v2 格式化与准备门禁独立审查

**静态审查通过。** 未执行准备器、NPU或重测，没有改正式源码、旧v1快照或基准。

- 已审v1 sparse SHA `0b6c0af7100bcb87010a9a7fc19690d48f074648a9b1f6b3d8c124384af14149`，新formatted sparse SHA `248d8b11bb0a045f7863c0b264d962845dcabafa51cbf1e5fafee413fa8dc6d5`。实际 diff 仅 `pl.concat` 的换行格式，完整 AST（不含行号）相同。
- 使用当前本机 Ruff **0.14.8** 和项目 `pyproject.toml`，对该文件执行 `format --check`、`check` 均通过。该记录明确工具版本，没有冒称执行另一版本。
- `prepare_whole_swa.py` 对旧v1的改动仅为：导入ast、接收formatted路径、限制固定新SHA、要求原候选相对import转换后的AST与formatted完整相同、采用formatted文本、receipt记录AST等价。
- 新SHA和AST断言均在 `prepare(...)` 创建目标之前执行；此前RAW候选SHA、四次graph门禁、原3365文件snapshot/原Sparse SHA、替换后全部source重哈、43 tested_sources、math、helper和原reference manifest重哈等门禁均未删除或放松。
- 准备结果仍明确写 `NPU_executed=False`、`whole-model qualification pending`，不会因为格式等价把v1旧硬件结果改称v2实际运行。

主线程提供的v2 source/math/helper新身份列在 `results.json`，本次没有重新执行准备器来独立重建这些输出hash。后续正式mixed21与整模型任务应在本次实际v2 snapshot上重新绑定；v1的T1/T240保留原身份并标注“AST等价的先行门禁”，不能改标签为v2。
