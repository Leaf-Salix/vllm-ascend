# QK/PV 分解测量与单因素优化清单

开始于2026-10-19，沿用1d6dbd027精度基准。用户授权继续对拍及Native对齐修正，不逐操作确认。每项NPU任务max780秒、独立小任务，5分钟内查看状态；不用自动调度。

## 顺序与门禁

- [x] 保存当前commit/43运行源SHA及不可变V6 snapshot、gold、helpers；不覆盖原基准。
- [x] 只读核对227实际Python/import/CANN/ATB/PTOAS及既有profiling工具，不安装或重编框架。
- [x] 对照当前TND、固定Nal a919及实际Native SparseAttnSharedKV接口/内核来源，分清计算和舍入差异。
- [x] 独立审查可用DFX/核内计时/PMU测量范围。任务跨度不是核内计算时间；不能把ablation差值相加当精确分解。
- [x] 在独立实验目录创建最小测量助手、无设备预检、实际生成物及独立review，然后提交小任务验证测量是否有效且数值不变。
- [x] 使用相同输入、FULL graph、确定性、SK0/NZ2测量QK/PV内部，单独量化profiler扰动；先B4再B40，必要时分PMU组。
- [x] 基于实测选择一个优化因素，保留Native K512、CAST_ROUND、PV累加和online更新顺序，保留真实TND。
- [x] 私有候选通过静态生成/物理内存与事件审查后，Native/PTO首差停止；同卡交错+独立重复验证稳定收益。
- [ ] 无稳定收益则拒绝候选，准确记录原因，不改正式精度版。
- [ ] 有稳定收益才建立最终源身份，验证T1/mixed21/T144/T240和62 tensor单入口。
- [ ] 再复测真实8K/B40 warm192+3x192 token，逐rank token/接受事件/资格/零抢占及CPU阶段匹配；通过后128K/B24。
- [ ] 完整记录测量/候选/失败、可复现命令、原始证据；正式变化做增量CPU、pre-commit、Markdown和独立review后commit/push到Leaf。

## 约束

仅227，所有远端新文件置于自有 `/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/` 独立目录。复用当前CANN9.2/PyPTO/Simpler，不装环境、不改SDK/codegen、不增加手写C++、不使用Native数值回调代替PTO。只搬运源码、指标、profile和JSON，不传模型权重/.pt。Native整模型沿用旧黄金与性能窗，不新增Native2任务。首差先定位，不跑后续大配置。
