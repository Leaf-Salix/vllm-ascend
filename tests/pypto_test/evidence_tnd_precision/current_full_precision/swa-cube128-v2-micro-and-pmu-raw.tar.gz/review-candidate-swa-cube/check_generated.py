"""Independent CPU-only checks of actual generated SWA mixed code."""
import hashlib
import json
from pathlib import Path
import re

R = Path('/Users/jiayetcs/Desktop/Project/PyPTO/reports/dsv4-tnd-qkpv-20261019')
B, C = R / 'sparse-program-generated', R / 'candidate-swa-cube-generated'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def clean(text):
    return '\n'.join(line.strip() for line in text.splitlines() if line.strip() and not line.lstrip().startswith('//'))

def alpha(text):
    names = {}
    def one(match):
        name = match.group()
        if '_inline' not in name:
            return name
        if name not in names:
            names[name] = 'INLINE_LOCAL_' + str(len(names))
        return names[name]
    return re.sub(r'\b[A-Za-z_][A-Za-z_0-9]*\b', one, clean(text))

old_orch = (B / 'orchestration/_sparse_probe.cpp').read_text()
new_orch = (C / 'orchestration/_sparse_probe.cpp').read_text()
assert alpha(old_orch) == alpha(new_orch), 'orchestration changed beyond inline local names'
assert json.loads((B/'compiled_meta.json').read_text())['params'] == json.loads((C/'compiled_meta.json').read_text())['params']
source = (C / 'kernels/aic/qk_pv_aic.cpp').read_text()
aic = source.split('static __aicore__ void qk_pv_aic(')[1].split('static __aicore__ void qk_pv_aiv(')[0]
aiv = source.split('static __aicore__ void qk_pv_aiv(')[1].split('extern "C"')[0]
# Reviewed explicit predicates preserve all compressed parts and SWA part0.
for needle in ('if (v124 > v49 | v127 == v49)', 'if (v124 > v49 | v177)',
               'bool v177 = v176 == v49', 'if (v177 & v202 == v49)',
               'TMATMUL(v174, v203, v207)', 'TMATMUL_ACC(v174, v174, v203, v207)',
               'TSTORE(v226, v174)'):
    assert needle in aic, needle
for needle in ('const int64_t v39 = 82304', 'const int64_t v43 = 110976',
               'const int64_t v44 = 98688', 'const float v80 = 0.0f',
               'TEXPANDS(v492, v80)', 'TCONCAT(v494, v483, v492)',
               'TLOAD(v496, v504)', 'TMULS(v516, v258, v90)',
               'wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5)'):
    assert needle in aiv, needle
# Explicit live/tail/destination UB ranges are disjoint during concat.
ranges = {'live128': [110976,110976+8*128*4],
          'zero384': [98688,98688+8*384*4],
          'scores512': [82304,82304+8*512*4]}
for key, bounds in ranges.items():
    for other, second in ranges.items():
        if key != other:
            assert bounds[1] <= second[0] or second[1] <= bounds[0]
result = {'static_generated_pass': True, 'hardware_executed': False,
          'orchestration_alpha_equal': True, 'root_abi_equal': True,
          'kernels': {core: {'baseline_sha256':sha(B/f'kernels/{core}/qk_pv_{core}.cpp'),
                            'candidate_sha256':sha(C/f'kernels/{core}/qk_pv_{core}.cpp')}
                      for core in ('aic','aiv')},
          'swa_qk_guard': 'block > 0 or qk_part == 0',
          'swa_pv_guard': 'block > 0 or pv_part == 0',
          'pv_init': 'part0 and k0 uses TMATMUL, all later actual subtiles TMATMUL_ACC; shared L0C addr0',
          'concat_disjoint_ub_ranges': ranges,
          'l1_bytes': {'carrier':[0,393216], 'q':[393216,458752], 'pv_probability':[458752,475136]},
          'remaining_gate': 'actual raw mi/li/oi and Native BF16 heads bit comparison; CCEC compile is parent-owned'}
(R/'review-candidate-swa-cube/generated-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
