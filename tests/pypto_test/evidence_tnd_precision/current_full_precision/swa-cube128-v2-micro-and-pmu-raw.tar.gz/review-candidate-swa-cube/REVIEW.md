# SWA Cube K128 私有候选独立审查

基线：正式仓库 `1d6dbd027` 的 precision sparse 文件，SHA `f5558603e25711de2a0ae9422dc62de977c36159c668f13d4451b176b9ca17c6`。
候选：`candidate-swa-cube/candidate_sparse.py`，SHA `8f3ddd066cbf4f7111b554baaa0f3720f940c5db96bb32235cecdfad201ea20c`。
本审查只读；没有改正式源码、SDK 或提交 NPU。

## 当前结论

**源码层面方案合理，未发现明确寻址或同步错误；仍须通过实际生成检查和逐 byte 硬件门禁，不能先宣布逐 bit 等价。** `check_source.py` 已做精确 AST 逆变换：只撤销两处有效 K guard 和一处 score 尾部构造、恢复私有 import 之后，完整候选 AST 与正式基线相同。`source-review.json` 记录完整身份。

### 保留的语义

- `qk_sb==0` 仅消费 SWA 128 行；其余 sparse block 仍执行原四片 K128 QK 与四片 PV。
- QK 侧四次 KV carrier load 仍无条件执行；slot0 对 part0/1 复用，slot1/2 保留 part2/3；完整载体先转置再切片的顺序不变。
- SWA PV part0 会重新装入 slot0 的真实首128行，覆盖 QK part1 留在 slot0 的零片。下一 compressed block 的四次 gather 会重新定义所有后续消费的 slot，不依赖被跳过 PV part1 的旧内容。
- AIV 的四片 KV 生成、零初始化和 GM store 均未变；故 QK 等待的 KV_READY 生产者没有减少写入或改变发信号时机。
- KV_READY、SCORE_READY、PROB_READY、PV_READY 的 set/wait 全部保留在原来的 block 层级。SWA QK 提前完成也要等原 probability 事件；PV part0 后仍发布 PV_READY。
- 未写的 SWA score_transfer 尾部384列不再读取：`live128 + FP32 +0 tail384` 显式构成512列。bias 仍为原来的尾部 `-1e20`。softmax scale/max/exp、实际 K 对应的求和树、BF16 CAST_ROUND、online m/l/oi 更新全部未改。
- 无 T//6 请求重建；动态 TND request、position、seq_lens、page table 与有效性规则均未改。

## 必须用证据排除的风险

1. **省略零乘累加并不自动等价于所有位相同。** SWA 后384行 KV 为显式正零，正常概率尾也为正零。对普通非零 FP32 累加器，加零通常不改变值；但浮点 `-0 + +0` 的符号、下溢/flush 路径和 Cube accumulator 行为不能靠代数推断。候选少执行三次 matmul_acc，必须比较 raw FP32 oi 的所有字节；只比较最终 BF16 heads 会漏掉舍入掩盖的差异。
2. **尾部 score 替代的适用域。** 对有限 Q 与零 KV，masked 后应与固定负 bias 相同；非有限 Q 的 `Inf×0/NaN×0` 不满足此推断。实际 fixture 应确认输入 Q、cache、sink 和全部输出有限；不要把已验收有限输入域扩大成对所有 IEEE 特殊值的保证。
3. **Tile phi / init。** pv_acc 在循环前创建，只有 part0 第一次 matmul_acc 以 init_cond=true 定义内容；源码每个执行 block 的 part0 guard 恒真。实际 generated 必须确认该初始分支没有未定义 tile phi、没有在循环末读到旧 L0C，compressed part1…3 仍累加同一个物理 accumulator。
4. **concat 布局和 UB。** 必须检查实际 generated `sm_live_scores` 的128列、tail384与目标512列的物理偏移。不能仅看 AST 猜测 tile concat 布局；应确认新增中间 tile 不覆盖 qk_reduce_tmp、running state 或同步中的 buffer。寄存器/UB 增长可能抵消 Cube 节省。
5. **测量因素的表述。** 这是一个“让 SWA Cube 只处理实际128行”的完整候选，同时涉及 QK、PV 两阶段和必要的 score 尾构造。它不是单独 QK 或单独 PV 的速度测量，不能由总收益精确分解各阶段贡献。

## 建议门禁顺序

1. 无设备生成：核对原16参ABI、checked48→plan32→mixed24→publish24；逐项比较 set/wait/event/pipe；compressed 路径的 matmul 形状和 init/accumulate 序列；SWA首片载体；concat完整512列；实际 UB/L1/L0C 物理布局及 scope。生成文件需要独立新SHA，不复用 baseline 的“核体逐字一致”结论。
2. 固定同一个 Native capture bank，先取得正式 baseline `mi/li/oi/heads` 四项黄金及其文件SHA、baseline artifact身份。候选每个非PMU/PMU执行均与该固定 gold 比较 raw uint8，并对 Native pre-inverse heads 做独立逐 byte 比较；保留 finite、NaN poison、Host 输入不变与首差停止。
3. 按最早差异分流：mi/li 首差优先查 QK score/尾部/softmax；mi/li 一致但 oi 首差优先查 PV 零项累加和 signed zero；三项一致而 heads 不同查 publish layout/除法/cast。
4. B4/history8191 通过只能作为这个真实 bank 的候选验证。扩大验收需覆盖短 SWA、跨页/缺页、SWA-only/无有效 compressed、正负零/小值及混合请求；每个任务仍≤15分钟，发现首差停止。
5. 精度门禁全部通过后才看 PMU，两侧 func_id/core_type/cycle 分开记录。正式收益最终用无PMU、同卡交错 baseline/candidate 测量；不能把 program Host seconds 或 busy counter 相减当生产 FULL graph 延迟收益。

## 实际 generated 补充审查

`check_generated.py` 已运行通过，详细数据见 `generated-review.json`。

- 完整 orchestration 去注释、只按一致映射标准化 inline 局部名字后，与 baseline 逐字相同；16参 ABI/dtype/dynamic shape 与 baseline 元数据完全相同。因此 scratch 生命周期、输出所有权、planner 和 publish 依赖没有增加变化。
- AIC QK guard 对应 `(block>0 || part==0)`，PV guard 同理；part0/k0 的 `TMATMUL` 明确初始化 L0C，此后的实际子片使用 `TMATMUL_ACC`，最终 store 仍读同一物理地址0。多出的 phi 是相同物理地址的描述符，没有将未初始化寄存器作为数据消费。
- QK L1 carrier `[0,393216)`、Q `[393216,458752)`、PV probability `[458752,475136)` 保持原布置；QK四次 gather 在 guard 外，SWA PV首片重载仍在 guard 内且恒执行。
- AIV live128 `[110976,115072)`、zero384 `[98688,110976)`、拼接输出512 `[82304,98688)` 在 concat 期间互不重叠。tail 由 `TEXPANDS(...,0.0f)` 生成；`TCONCAT` 后 consumer 用同一物理512列 phi。compressed 分支在该相同地址完整 load512列。复用tail的 bias load 前有 `PIPE_V→MTE2` set/wait。
- 跨核事件仍为 AIC 等 KV0/PROB2、发 SCORE1/PV3；AIV 发 KV0/PROB2、等 SCORE1/PV3，均在 part guard 外。底层自动同步增加了条件路径所需的本地 event，但没有绕开原四组跨核握手。
- 候选核SHA：AIC `f3788fed7cd3ef145e96ebd7185f7cb7030ae3f7aec5a9fff21725a97eb66f6d`；AIV `fd276e9d112cd1bcceb0fb300ad891ab13db86eb8d99dd2d08562bf73c297fbf`。运行 helper 应锁定这份实际生成，不能继续 pin baseline 的核SHA。

源码和生成静态检查通过，未发现 generated 阻断。CCEC 编译由主线程负责；本审查没有将候选判为硬件精度通过，±0/下溢等风险仍以固定 baseline mi/li/oi 全字节黄金和 Native heads 对拍为准。
