"""CPU-only independent AST audit of the SWA effective-K experiment."""
import ast
import copy
import hashlib
import json
from pathlib import Path

WORK = Path('/Users/jiayetcs/Desktop/Project/PyPTO')
BASE = WORK / 'vllm-ascend-nalinaly-tnd-20261008-codex/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision/decode_sparse_attn_csa.py'
CAND = WORK / 'reports/dsv4-tnd-qkpv-20261019/candidate-swa-cube/candidate_sparse.py'
OUT = WORK / 'reports/dsv4-tnd-qkpv-20261019/review-candidate-swa-cube'
old = ast.parse(BASE.read_text())
new = ast.parse(CAND.read_text())
checks = {}

def dump(node):
    return ast.dump(node, include_attributes=False)

def expr(text):
    return ast.parse(text, mode='eval').body

class RestoreExperiment(ast.NodeTransformer):
    def visit_ImportFrom(self, node):
        prefix = 'vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.'
        if node.module and node.module.startswith(prefix):
            node.module = node.module.removeprefix(prefix)
            node.level = 1
        return node

    def visit_For(self, node):
        node = self.generic_visit(node)
        if isinstance(node.target, ast.Name) and node.target.id == 'qk_part':
            last = node.body[-1]
            if isinstance(last, ast.If) and dump(last.test) == dump(expr('qk_sb > 0 or qk_part == 0')):
                assert not last.orelse
                node.body = node.body[:-1] + last.body
                checks['qk_guard_restored'] = checks.get('qk_guard_restored', 0) + 1
        if isinstance(node.target, ast.Name) and node.target.id == 'pv_part':
            assert len(node.body) == 1 and isinstance(node.body[0], ast.If)
            branch = node.body[0]
            assert dump(branch.test) == dump(expr('qk_sb > 0 or pv_part == 0')) and not branch.orelse
            node.body = branch.body
            checks['pv_guard_restored'] = checks.get('pv_guard_restored', 0) + 1
        return node

    def visit_If(self, node):
        node = self.generic_visit(node)
        if (len(node.body) == 2 and isinstance(node.body[0], ast.Assign)
                and isinstance(node.body[0].targets[0], ast.Name)
                and node.body[0].targets[0].id == 'sm_live_scores'):
            assert dump(node.test) == dump(expr('qk_sb == 0'))
            assert len(node.orelse) == 1
            expected = ast.parse('''sm_live_scores = pl.load(score_transfer, [sm_row, 0], [SOFTMAX_HEAD_TILE, WIN])
sm_scores = pl.concat(sm_live_scores, pl.tile.full([SOFTMAX_HEAD_TILE, ATTN_K_TILE - WIN], dtype=pl.FP32, value=0.0))''').body
            assert [dump(x) for x in node.body] == [dump(x) for x in expected]
            checks['explicit_zero_tail_verified'] = True
            return node.orelse
        return node

restored = RestoreExperiment().visit(copy.deepcopy(new))
assert checks == {'explicit_zero_tail_verified': True, 'qk_guard_restored': 1, 'pv_guard_restored': 1}, checks
assert dump(old) == dump(restored), 'Changes outside the three reviewed sparse edits/import relocation'
result = {'static_ast_pass': True, 'hardware_executed': False,
          'baseline_sha256': hashlib.sha256(BASE.read_bytes()).hexdigest(),
          'candidate_sha256': hashlib.sha256(CAND.read_bytes()).hexdigest(),
          'canonical_baseline_restored_after_exact_three_edits': True,
          'checked_transformations': checks,
          'untouched': ['all planner/checked-index functions', 'AIV KV gather and four-panel stores',
                        'AIC four-panel QK carrier loads and full-carrier transpose-before-slice',
                        'all four cross-core event set/wait calls', 'softmax scale/bias/max/reduction/casts',
                        'online m/l/oi updates', 'compressed-block branches', 'TND request and dynamic axes']}
(OUT / 'source-review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
