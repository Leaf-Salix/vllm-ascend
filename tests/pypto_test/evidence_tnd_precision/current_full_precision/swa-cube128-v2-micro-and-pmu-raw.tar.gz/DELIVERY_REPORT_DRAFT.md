# TND精度版QK/PV测量与SWA优化（2026-10-19）

## 本轮目标

保持当前Native精度基准，先用相同输入分别观察Native、固定Nal性能BSH版和TND精度版的QK/PV工作量，再做一个可单独回退的优化。只有局部收益稳定且精度不变后，才复测真实整模型8K/B40与128K/B24的192token。

基准为 `1d6dbd027`。当前分支为 `dev/pypto-dsv4-csa-nalinaly-tnd-20261008-codex`。本轮不改PyPTO/Simpler/CANN或Native代码，不增加手写C++。

## 测量结论

现有kernel-mode FULL graph不能直接采集内部PMU，故另建program-mode诊断入口，保持原sparse helper计算，显式发布mi/li/oi和归一化BF16 heads；复用同一Native捕获输入和baseline FP32状态金值。实际收益另用关闭DFX/PMU的FULL graph验证。

Cube、Vector、Scalar及MTE忙碌计数可以重叠，不能相加为互斥耗时。当前接口没有精确逐事件等待周期，因此没有将total减busy后标成等待。Native用CANN采集，Nal核还包括inverse RoPE/发布，TND QK/PV核不包括；三者范围/采集模式不同，不能当统一性能排名。

### 保留的单因素

SWA只有最多128个真实Key，旧精度版却为512列数值块执行四片QK/PV。仅在SWA跳过第2～4片Cube计算，并显式构造score的正零尾。compressed路径不变。原K512 softmax块、实际K归约树、CAST_ROUND、PV累加与online状态更新顺序保持；跨核set/wait全保留。AIC QK侧四片KV载入也先保留，使本轮因素局限于无用Cube计算。

省略零项累加不自动保证所有浮点位相同，故不只验最终BF16：程序模式核对raw FP32 mi/li/oi全部字节，Graph又检查改输入、Q=0、ABA、NaN poison、guard和只读输入。

### 同卡交错局部实测

单位µs/完整sparse诊断root；每臂每任务20轮×100 replay；包括planner和统计/heads发布，不是单独QK/PV时间。

| 配置 | 重复 | 原版 | 优化 | 延迟下降 | 逐bit/其他门禁 |
| --- | --- | ---: | ---: | ---: | --- |
| 8K/B4/T24 | r1 | 236.487 | 217.648 | 7.97% | 71项通过 |
| 8K/B4/T24 | r2 | 227.034 | 219.317 | 3.40% | 71项通过 |
| 8K/B40/T240 | r1 | 963.384 | 881.135 | 8.54% | 71项通过 |
| 8K/B40/T240 | r2 | 978.618 | 908.281 | 7.19% | 71项通过 |

80个配对轮次均为正收益。B4两个任务在物理0卡，B40两个在物理1卡；跨任务基线漂移，不把两次降幅平均成固定收益。

### PMU如何解释收益

同bank的program-mode，单位为每core/task平均千cycles。TND原版→候选：Cube busy18.52→11.58、MTE1 busy21.69→13.56，各下降约37.5%，接近Nal的11.78/13.56；AIC total138.21→117.25、AIV total142.23→121.67。AIV Vector仍为35.32，Nal为21.11；MTE2也尚有差距。busy变化只用于诊断，不能将这些降幅替代生产Graph收益。

### 计算、搬运与等待的位置

下图只表示静态依赖，不按时间比例绘制。跨核事件全部保留。

```mermaid
sequenceDiagram
    participant V as AIV
    participant C as AIC
    V->>V: 分页gather及零尾，写KV中转GM
    V->>C: KV_READY
    C->>C: Q/KV入L1，QK Cube，FIX写score
    C->>V: SCORE_READY
    V->>V: 读score、mask、online softmax、概率舍入
    V->>C: PROB_READY
    C->>C: 概率/KV入L1，PV Cube，FIX写输出
    C->>V: PV_READY
    V->>V: 读PV，按原顺序更新mi/li/oi
```

PTO诊断PMU的每core平均千cycles如下；各pipeline并发，不能相加。

| 指标 | Nal性能BSH | TND原版 | SWA候选 |
| --- | ---: | ---: | ---: |
| AIC total | 78.44 | 138.21 | 117.25 |
| AIC Cube busy | 11.78 | 18.52 | 11.58 |
| AIC MTE1 busy | 13.56 | 21.69 | 13.56 |
| AIC MTE2 busy | 17.34 | 25.65 | 23.27 |
| AIC Scalar busy | 36.37 | 23.24 | 21.27 |
| AIV total | 87.89 | 142.23 | 121.67 |
| AIV Vector busy | 21.11 | 34.69 | 35.32 |
| AIV MTE2 busy | 24.09 | 22.52 | 21.42 |
| AIV MTE3 busy | 10.53 | 16.46 | 17.68 |
| AIV Scalar busy | 45.61 | 46.53 | 41.58 |

Native CANN实测SparseAttnSharedkv三次duration为55.760/55.800/55.040µs；CANN给出的忙碌占比另记：AIC Cube13.63%、MTE1 17.53%、MTE2 53.23%、Scalar57.20%；AIV Vector8.70%、MTE2 37.30%、MTE3 15.37%、Scalar43.10%。其总cycles均摊每core为AIC90.05k/AIV96.28k。没有原始busy cycles时保留百分比，不从舍入百分比或假定频率换算cycles；也不将这些跨采集模式数据作为严格速度比。

Nal测量用同bank，但heads relative L2为0.2544%，不满足本轮逐bit验收；其pass只表示测量程序完成。不能为了达到Nal的busy计数而照搬K128独立softmax/rint及online归并。

## 精度和覆盖

v1完整CSA Native/PTO在T1、混合1～6行T21、B40/T240均逐bit通过；T21实际21行，不按请求补S6。最终v2仅为concat表达式换行，完整AST相同，另用v2真实源重测混合T21通过。所有比较覆盖输出、六类cache/state、TopK，8边界A/B/ABA、防越界、实际PTO dispatch及62Tensor入口；无Native fallback。

本轮单层完整CSA的B40/T240为Native1.373ms、优化PTO2.295ms，仍有明显差距。这一结果不是整模型延迟，也不是与旧PTO同卡交错。

## 整模型结果

待真实8K/B40通过后执行128K/B24。最终文档必须填写实际token/接受事件数、三次测量max-rank延迟和Native历史窗差距，不得用局部收益替代。

## 可复现身份与限制

最终运行Sparse SHA：`248d8b11bb0a045f7863c0b264d962845dcabafa51cbf1e5fafee413fa8dc6d5`。
完整3365文件source manifest：`639b1280dc682dad23195509ddd51970d0d16da55fa11efa302e9edc97da7e03`。
43运行源中仅Sparse变化，其余42份及62Tensor根不变。

真实模型使用原公开40条输入及自行Native生成的固定prefix/cache银行，未证明与Nal原bank逐字节相同。TP1/DP=EP16、NZ2/SK0、deterministic1/HCCL true、EPLB关；接收步长3.8未强制。128K/B24按提交24、实际21并发口径，126有效token进入144图桶。保留真正TND和Native公共metadata/cache/connector；仅CSA替换，HCA和FFN仍Native。

性能与精度仅覆盖记录的有限输入、模型、版本、硬件和图配置；没有声称所有IEEE特殊值或任意模型都逐bit相同。原Native性能为历史窗；只有局部sparse A/B是同卡交错的受控收益证据。每项NPU任务上限780秒，未重跑整模型Native2。
