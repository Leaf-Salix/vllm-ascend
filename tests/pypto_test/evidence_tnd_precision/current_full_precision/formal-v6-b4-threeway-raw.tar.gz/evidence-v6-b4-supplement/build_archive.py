from pathlib import Path
import json,hashlib,tarfile,gzip,io
P=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
allowed={'.json','.py','.md'};names=['README.md','review_threeway_b4.py','THREEWAY_INDEPENDENT_REVIEW.json','threeway-v6-b4-result.json','source43-binding.json','PINNED_V6.json','threeway-helper-manifest.json','BASE_ARCHIVE_REFERENCE.json','build_archive.py'];files={}
for name in names:
 p=P/name;assert p.is_file() and not p.is_symlink() and p.suffix in allowed;data=p.read_bytes();data.decode('utf-8');assert b'\x00' not in data;files[name]={'sha256':sha(p),'bytes':len(data)}
manifest={'scope':'final V6 controlled threeway B4 supplement only, previous archive unchanged','no_models_tensors_binaries':True,'NPU_executed_by_packager':False,'files':files};(P/'ARCHIVE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');archive=P.parent/'evidence-v6-threeway-b4-supplement-20261019.tar.gz';assert not archive.exists()
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for name in sorted(names+['ARCHIVE_MANIFEST.json']):
    data=(P/name).read_bytes();m=tarfile.TarInfo('evidence-v6-b4-supplement/'+name);m.size=len(data);m.mode=0o644;m.uid=m.gid=m.mtime=0;tar.addfile(m,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 for member in tar.getmembers():
  assert member.isfile() and not member.issym() and '..' not in Path(member.name).parts and Path(member.name).suffix in allowed;data=tar.extractfile(member).read();data.decode('utf-8');name=Path(member.name).name
  if name!='ARCHIVE_MANIFEST.json':assert hashlib.sha256(data).hexdigest()==files[name]['sha256']
ready={'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'files':len(names)+1,'whitelist_and_SHA_readback':True,'previous_archive_changed':False};(P/'ARCHIVE_READY.json').write_text(json.dumps(ready,indent=2)+'\n');print(json.dumps(ready,indent=2))
