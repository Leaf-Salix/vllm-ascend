# V6 三方 B4 增补证据

本包增补最终 V6 的 B4/T24、history8191、L4 真实权重、固定合成 hidden 的三方 FULL graph 单层结果。它不是整模型吞吐或 token 报告。

| 实现 | 平均延迟 µs | 相对 Native 精度 |
| --- | ---: | --- |
| Native | 559.544 | 基准 |
| TND V6 | 820.725 | 八个输出/cache/state 边界逐 bit 一致 |
| Nal 性能版 a919f119 | 489.360 | 误差只记录，未作为性能计时门禁 |

固定源 manifest `6d9656de4580ba5f768881c417f3093a7744808ac6518c594e9db881971e7ab2`、TND ABI62/Nal ABI57、同一53helper清单、Nal38源、SK0/NZ2、确定性及0fallback均已独立核验。三臂 actual FULL/raw replay、ABA、poison、写入 guard，以及 8×20 次无DFX计时门禁通过。

TND 仍为 Native 的1.4668倍、Nal的1.6771倍。相对前轮 V4 B4，原始 TND 延迟下降12.52%，但两轮不同任务的 Native/Nal 也下降4.85%/5.30%；不能把原始差值全归因于代码优化。两轮 TND 样本区间没有重叠，旧V4 raw 路径/SHA与漂移均在独立审计中记录。

本包不重复原 `evidence-v6-kernel-threeway-pre-dfx-20261019.tar.gz`：该包SHA为 `37456f91e91c06d5acd856d16f1045d677af75073cce5114f8cf2cd1039624c5`，包含实际43源、Nal38源、完整可复现helpers、四项单因素及实际生成物审查。此处以 `BASE_ARCHIVE_REFERENCE.json` 引用它。

没有模型、tensor、二进制或 DFX 实际结果。三个性能臂的数值差异仅针对本次单层输入，不能推断 Nal 的整模型误差。本包不会覆盖已有archive或runtime。
