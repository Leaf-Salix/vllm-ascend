#!/usr/bin/env bash
set -euo pipefail
source /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overnight-20261019/csa-combo-v4/env.sh
export ASCEND_RT_VISIBLE_DEVICES="" TORCH_DEVICE_BACKEND_AUTOLOAD=0
ccache -s
python "$job/check_cpu.py"
python "$job/preflight.py"
python "$job/compile.py" "$@"
