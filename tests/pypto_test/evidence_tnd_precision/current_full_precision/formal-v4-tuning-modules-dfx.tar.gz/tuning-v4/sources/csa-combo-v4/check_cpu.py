"""Unsubmitted ComboV4: strict dependency/ABI/plan ownership checks, no NPU."""
import ast
import copy
import hashlib
import json
from pathlib import Path

P=Path(__file__).resolve().parent
R=P.parent
parse=lambda p:ast.parse(p.read_text())
dump=lambda tree:ast.dump(tree,include_attributes=False)
find=lambda tree,name:next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
inputs=json.loads((P/'input-sources.json').read_text())
assert hashlib.sha256((P/'baseline_csa.py').read_bytes()).hexdigest()==inputs['baseline_csa_sha256']
assert hashlib.sha256((P/'candidate_norm.py').read_bytes()).hexdigest()==inputs['norm_source_sha256']=='5aa19332056b3bc2b202dd733679d22325ac92b3c176a93f3fed0204b1bf74cc'
base=find(parse(P/'baseline_csa.py'),'_full_csa_tnd');candidate=find(parse(P/'candidate_csa.py'),'_full_csa_tnd')
assert len(candidate.args.args)==len(base.args.args)==62
assert dump(candidate.args)==dump(base.args)
class StripRootPlan(ast.NodeTransformer):
    def visit_Call(self,node):
        node=self.generic_visit(node)
        if isinstance(node.func,ast.Name) and node.func.id=='sparse_attn_csa_tp1':
            assert isinstance(node.args[-1],ast.Constant) and node.args[-1].value==32
            node.args.pop()
        return node
assert dump(base)==dump(StripRootPlan().visit(copy.deepcopy(candidate)))
assert hashlib.sha256((P/'candidate_wkv.py').read_bytes()).hexdigest()==inputs['baseline_wkv_sha256']=='a711a35799f4c331348b1cb9d3d88fec49e67ac85fea0ad8a89e110bda8fb0b8'
# Compare full sparse math against the already tested single-factor constant32 version.
class NormalizeSparse(ast.NodeTransformer):
    def visit_FunctionDef(self,node):
        if node.name in ('sparse_attn_csa','sparse_attn_csa_tp1') and node.args.args[-1].arg=='plan_workers':
            assert not node.args.defaults
            assert ast.unparse(node.args.args[-1].annotation)=='pl.Scalar[pl.INDEX]'
            node.args.args.pop()
        return self.generic_visit(node)
    def visit_Name(self,node):
        if isinstance(node.ctx,ast.Load) and node.id in ('plan_workers','CSA_PLAN_WORKERS'):
            return ast.copy_location(ast.Constant(32),node)
        return node
    def visit_Assign(self,node):
        if any(isinstance(t,ast.Name) and t.id=='CSA_PLAN_WORKERS' for t in node.targets):
            node.value=ast.Constant(16)
        return self.generic_visit(node)
    def visit_Call(self,node):
        # The required scalar is only an internal function edge, not new arithmetic.
        if isinstance(node.func,ast.Name) and node.func.id=='sparse_attn_csa' and isinstance(node.args[-1],ast.Name) and node.args[-1].id=='plan_workers':
            node.args.pop()
        return self.generic_visit(node)
new=parse(P/'candidate_sparse.py');old=parse(R/'csa-plan-workers32/candidate_sparse.py')
assert dump(NormalizeSparse().visit(new))==dump(NormalizeSparse().visit(old)),'Sparse math changed beyond plan argument'
legacy=parse(P/'legacy_root_explicit16.py')
calls=[n for n in ast.walk(legacy) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='sparse_attn_csa_tp1']
assert len(calls)==1 and isinstance(calls[0].args[-1],ast.Constant) and calls[0].args[-1].value==16
# Baseline HC remains ComboV3b; optimized HC combines two disjoint passing regions.
assert (P/'candidate_hc.py').read_bytes()==(R/'csa-combo-v3b/candidate_hc.py').read_bytes()
assert (P/'candidate_panel.py').read_bytes()==(R/'square-group4/candidate_panel.py').read_bytes()
original_group=(R/'square-group4/candidate_hc.py').read_text()
assert hashlib.sha256(original_group.encode()).hexdigest()==inputs['square_group4_hc_source_sha256']
optimized=(P/'optimized_hc.py').read_text()
assert optimized==original_group.replace('PANEL_MIN_TOKENS = 16','PANEL_MIN_TOKENS = 1')
assert hashlib.sha256(optimized.encode()).hexdigest()==inputs['candidate_optimized_hc_sha256']
for tokens in range(1,257):
    threshold_changed=tokens<16
    grouping_changed=tokens>=64
    assert not(threshold_changed and grouping_changed)
# Root imports must stay isolated: baseline never imports optimized HC.
assert 'from optimized_hc import hc_pre_entry' in (P/'candidate_csa.py').read_text()
assert 'from candidate_hc import hc_pre_entry' in (P/'baseline_csa.py').read_text()
assert 'optimized_hc' not in (P/'baseline_csa.py').read_text()

# Same scalar cacheline ownership as the passing plan32 candidate; both task stages keep checked_tid deps.
for tokens in range(1,257):
    for workers in (16,32):
        seen={};cachelines={name:{} for name in ('indices','bias','mask')}
        for worker in range(workers):
            for tile in range(worker*8,tokens,workers*8):
                for row in range(tile,min(tile+8,tokens)):
                    assert row not in seen;seen[row]=worker
                    for name,stride in (('indices',512*4),('bias',1024*4),('mask',16*4)):
                        for line in range(row*stride//64,(row+1)*stride//64):
                            assert line not in cachelines[name] or cachelines[name][line]==worker
                            cachelines[name][line]=worker
        assert set(seen)==set(range(tokens))
result={'pass':True,'NPU_executed':False,'CCEC_executed':False,'root_abi':62,'baseline':'ComboV3b exact helper bytes','candidate_delta':'Norm5aa193, required internal plan_workers=32, isolated group4 HC plus short threshold1','legacy_call_workers':16,'full_call_workers':32,'plan_scalar_required_no_defaults':True,'math_AST_equal_to_plan32_singlefactor_after_argument_substitution':True,'all_T1_256_planner_coverage_and_cacheline_ownership':True,'scope_AST_unchanged':True,'HC_baseline_dependency_isolated':True,'HC_group4_and_short_threshold_regions_disjoint_T1_256':True,'not_a_numeric_equivalence_claim':True}
(P/'cpu-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
