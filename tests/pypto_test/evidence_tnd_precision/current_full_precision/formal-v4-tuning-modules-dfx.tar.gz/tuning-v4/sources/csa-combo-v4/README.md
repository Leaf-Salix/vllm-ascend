# ComboV4未提交候选

## 状态

**输入与helper已冻结；只授权无设备生成、实际orchestration GCC和全核CCEC。V3b NPU仍在运行，通过后才允许提交V4 NPU。**
`NPU_BLOCKED.json`是运行状态门禁，不属于源码身份manifest；只有主线程确认V3b后可解除。

只在reports准备。CPU AST/布局检查已通过；即将执行静态lower/GCC/CCEC，**尚未运行V4 NPU**。
主线程已确认Norm6/144/240、plan32 T21/144/240、HC group4 6/144/240与短CubeT1…15全部Native强门禁通过。
ComboV3b mixed21仍是独立执行任务；本目录没有修改任何其冻结helper。

- baseline_csa逐字节来自ComboV3b candidate，包含其M64N32 WKV及WO-B64。
- candidate增加Norm融合5aa193、planning32，以及独立optimized_hc：冻结group4 HC7b955只将PANEL_MIN_TOKENS从16改为1；baseline继续引用原candidate_hc，避免污染。
- group4仅T>=64改变partial任务编排；短Cube阈值仅T<16改变路径，两者适用区间互斥。该组合尚未做NPU验证，单因素通过不能冒充组合通过。
- 两根均62参数；planning参数是内部required Scalar INDEX，不增加torch/root ABI参数。
- probe使用新的ComboV3/ComboV4身份和namespace，并保存完整manifest，不沿用15a9/split-range标签。

## 正式最小diff（production_diff.patch）

1. 修改原`deepseek_v4_flash_csa_tnd_precision/decode_sparse_attn_csa.py`：
   `sparse_attn_csa`和`_tp1`均添加required `plan_workers: pl.Scalar[pl.INDEX]`。
   tp1原样转传；仅两处SPMD worker数和两处tile步长使用此参数。
   保留16的旧模块常量作为历史校准身份，不用可选参数/default/global monkeypatch。
2. 原precision/decode_csa唯一caller显式传16，不改变它的root ABI、scope或原功能。
3. fullprecision/decode_csa唯一caller显式传32；其root仍62参数。
4. fullprecision/input_norm替换为5aa193融合草稿；T6/T144/T240 Native output+rstd精度门禁已由主线程确认。
5. fullprecision/hc_pre仅分组sq partial任务（T>=64为4个partial一个worker）和短Cube阈值16→1；两者只编排/路径选择，仍必须组合数值验收。

**正式包不新增第二份700行sparse实现。** 本目录candidate_sparse只是生成检查所需的
临时materialization，由原文件应用这个小diff并转为绝对import，不能复制成生产新模块。
legacy_root_explicit16同理，只是原legacy caller的包外编译见证。
目前patch以ComboV3的full根（与ComboV2正式根体相同）为base；
HC分组/短Cube阈值现作为第5个hc_pre.py最小diff写入draft patch；WKV/O-proj等ComboV3前置改动须先独立冻结，不能错当成本patch覆盖范围。

## 已执行CPU检查

`check_cpu.py`实际核对：

- baseline源SHA、Norm5aa193 SHA和62参数签名；
- candidate root只多了内部32参数，scope及其余root体AST不变；
- required参数代入32后，完整sparse数学AST与已测constant32单因素相同；
- legacy caller确实显式16，没有optional/default回退；
- T1..256、16/32 workers逐行完全覆盖且checked indices、bias、mask无跨worker 64B同行写。

这些是生成前结构门禁，不能作为NPU数值等价或性能证明。

## 后续生成/数值门禁

1. 同原私有SDK/冻结资产，先`compile.sh --roots candidate legacy --ccec none`。
   要看到candidate两规划任务block_num32，legacy保持16；required参数不能导致新增root实参。
   legacy root参数数量须等于原precision root，完整candidate root必须62。
2. 复用Norm已验收生成审查方法，检查本次inline进完整根后的fused UB存活区间：
   wide从平方前到apply最后读保持，scalar sqrt循环期间无覆盖；仅一个fused任务，无中间GM sums。
   Norm5aa193模块已有40,992B生成writer上界记录，但不能不看新的完整inline产物就继承该数字。
3. 原Indexer/Attention及各阶段scope边界应保持，planning checked_tid→qk_plan_tid→QK/PV依赖不变。
   与ComboV3b orchestration比较arena分组与alloc_tensors，不能让32worker重引入跨scope TaskId问题。
4. CPU/生成审查后才`--ccec changed`，必要时all；CCEC本身不执行NPU。
5. 分别提交mixed21、短T6、T144、T240 FULL graph三臂同输入对拍，按主线程选择顺序，
   首个Native差异就停。保存8类A/B边界、实际namespace、guard/poison以及计时后状态门禁。
   每task max780，不连成长任务，不创建自动调度。
6. 最终数学/权重service资格均落定后，必须新的8K/128K whole源码快照和Nativegold token/events证据；
   不把ComboV2/V3或模块通过冒称为ComboV4整模型验收。

## 轻量证据

Git保留压缩原始JSON/完整token/events、Native gold、source/helper manifests及执行脚本，
两档按现有数据通常各约1～2MiB；大tensor原始.pt仍留本地/227，归档只列SHA/bytes及见证复核结论。
module raw JSON和最终source身份不可删；SDK、模型、KV bank及大生成二进制不进Git。
最终CPU模板可复用`../final-tests/`，不再建立另一套性能审计框架。
