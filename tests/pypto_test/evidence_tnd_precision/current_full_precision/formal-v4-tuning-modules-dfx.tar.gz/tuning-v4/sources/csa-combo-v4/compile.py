"""Prepare generation/CCEC checks only; never launch an NPU kernel."""
import argparse
import hashlib
import importlib
import json
import shutil
from pathlib import Path

from pypto.runtime import RunConfig
from pypto.runtime.kernel_compiler import KernelCompiler

P=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--roots',nargs='+',choices=('baseline','candidate','legacy'),default=['candidate','legacy'])
parser.add_argument('--ccec',choices=('none','changed','all'),default='none')
a=parser.parse_args()
isa='/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/build/pto-isa'
compiler=KernelCompiler('a2a3')
results=[]
for arm in a.roots:
    name={'baseline':'baseline_csa','candidate':'candidate_csa','legacy':'legacy_root_explicit16'}[arm]
    module=importlib.import_module(name)
    kernel=module.decode_csa_tp1_layer_test
    if arm!='legacy':assert len(kernel.param_names)==62
    else:
        original=importlib.import_module('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.decode_csa')
        assert len(kernel.param_names)==len(original.decode_csa_tp1_layer_test.param_names)
    program=kernel.compile(config=RunConfig(platform='a2a3'))
    output=Path(program.output_dir)
    sources=sorted(f for f in output.glob('kernels/*/*.cpp') if f.parent.name in ('aic','aiv'))
    assert sources,(arm,output)
    orchestration=list((output/'orchestration').glob('*.cpp'));assert orchestration
    assert len(orchestration)==1
    host_build=P/'precompile'/arm/'host';host_build.mkdir(parents=True,exist_ok=True)
    host_binary=compiler.compile_orchestration('tensormap_and_ringbuffer',str(orchestration[0]),build_dir=str(host_build))
    (host_build/'orchestration.so').write_bytes(host_binary)
    print('COMBO_V4_ORCHESTRATION_GCC_PASS',arm,len(host_binary),flush=True)
    generated=P/'generated-review'/arm
    shutil.copytree(output/'kernels',generated/'kernels',dirs_exist_ok=True)
    shutil.copytree(output/'orchestration',generated/'orchestration',dirs_exist_ok=True)
    text='\n'.join(f.read_text() for f in orchestration)
    workers=32 if arm=='candidate' else 16
    for task in ('csa_checked_indices','csa_slots_build_valid_qk_plan'):
        marker='// Spmd '+task
        i=text.index(marker);segment=text[i:text.index('\n\n',i)]
        assert f'.launch_spec.set_block_num({workers})' in segment,(arm,task,segment)
    changed=[f for f in sources if f.stem in ('csa_checked_indices','csa_slots_build_valid_qk_plan','input_rms_fused')]
    if arm=='candidate':
        assert any(f.stem=='input_rms_fused' for f in sources)
        assert not any(f.stem in ('input_rms_sum_dsl','input_rms_inverse','input_rms_apply') for f in sources)
    compiled=[]
    for source in sources if a.ccec=='all' else changed if a.ccec=='changed' else []:
        build=P/'precompile'/arm/source.parent.name;build.mkdir(parents=True,exist_ok=True)
        binary=KernelCompiler('a2a3').compile_incore(str(source),core_type=source.parent.name,pto_isa_root=isa,runtime_name='tensormap_and_ringbuffer',build_dir=str(build))
        (build/(source.stem+'.elf')).write_bytes(binary)
        compiled.append({'name':source.name,'bytes':len(binary)})
        print('COMBO_V4_CCEC',arm,source.name,len(binary),flush=True)
    results.append({'arm':arm,'output_dir':str(output),'orchestration_binary_bytes':len(host_binary),'root_arguments':len(kernel.param_names),'planning_workers':workers,'ccec':a.ccec,'compiled':compiled,
                    'sources':{str(f.relative_to(output)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [*sources,*orchestration]}})
(P/'compile-results.json').write_text(json.dumps({'NPU_executed':False,'results':results},indent=2)+'\n')
print('COMBO_V4_GENERATED_ONLY',flush=True)
