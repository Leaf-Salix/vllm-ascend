# 可参数化独立三方完整CSA复测runner

复用旧threeway/probe_threeway.py及同一fixture，原helpers、V4与正式source不改。固定Nal性能源码a919f119（38文件原SHA/Pax commit已核），测试完整HC-pre→inputnorm→CSA attention→Oproj→HC-post。真实L4权重、相同seed1024合成hidden/history8191/cache；uniform B4/T24或B40/T240。它是受控单层半边性能，不是整模型token吞吐。

## 显式候选身份

| 参数 | 默认值/作用 |
|---|---|
| TRI_VARIANT_DIR | 独立csa-combo-v4目录；所有候选根必须位于此目录内 |
| TRI_VARIANT_ENV | 上述目录/env.sh；显式source并记录SHA |
| TRI_EXPECTED_MANIFEST | 上述目录/manifest.json，支持平坦map或files map |
| TRI_EXPECTED_MANIFEST_SHA256 | 默认冻结V4的ed6d6ad1…；每次换快照必须显式传入新SHA，不能现读现信 |
| TRI_ROOT_MODULE | candidate_csa；支持后续正式快照中的完整包module名 |
| TRI_ROOT_ATTR | decode_csa_tp1_layer_test；实际param_names必须62 |

不猜source路径：先source显式ENV，再将runner和显式VARIANT_DIR加入PYTHONPATH。若改为正式snapshot包root，则VARIANT_DIR须设为该snapshot源码根，ROOT_MODULE填完整包名，ENV与manifest/SHA都同时显式指定。tri_identity.py验证候选manifest内所有文件、根文件确实被manifest覆盖、固定运行时SOURCE_ROOT完整manifest、Nal38文件及runner helper清单。默认V4只是预检对象，必须主线程完成其数值验收后才能提交。

## 执行

每task只一个B，脚本750秒统一timeout+15秒kill，task上限780秒：

```bash
bash run-threeway.sh LABEL 4 --timing-iters 10
bash run-threeway.sh OTHER_LABEL 40 --timing-iters 20
```

调度可以尾附--device N；TASK_DEVICE负责物理设备映射。只8轮×10或20次同卡交错正反序raw FULL graph replay，不开DFX/depgen。不预编译全部根。

预检可独立执行：`source env.sh; python preflight.py`，不申请NPU。默认manifest hash若变化将失败，需主线程核验新身份后显式更新参数，不能静默接受。

## 共同口径与精度门禁

三方均SK0（super_kernel_optimize=False）、NZ2、静态13包、确定性Torch+NPU level1+HCCLtrue、atomic0和tensormap_and_ringbuffer。不得与Nal公开SK1报告混用。NativeHalf/PTOHalf类与旧harness逐AST相同，原生copy/HC区域不变。

Native/TND输出、TopK和五类cache等八边界逐bit首差即停（包含±0字节差）；Nal对Native的精度错误只记录，不阻断其计时。所有arm仍要求实际AclGraph/fullgraph、无host-updated节点、compiled/raw自身状态一致、live-input ABA及写入guard；这些用于保证测到真实、可复现的kernel，而非fallback或未写回图。PTO两臂必须eligible=true，RequirePTO拒绝fallback，额外拦截Native fallback并计数为0；记录实际delegate eager/capture调用数、runtime/root module/ABI、SDK身份和源manifest。BSH ABI由SDK实际param_names记录，不猜57源码形参中constexpr是否作为runtime参数。

完整精度门禁后才计时；每轮restore与CPU校验都在timing外，计时后继续对自身状态和guard。Nal图本身若越界/不执行/无法恢复，仍不能作为有效性能基准。

本地check_cpu.py核验原边界类和fixture未变、pin38、SK0/NZ2、路由计数断言及单B参数化；不冒充设备验收。本助手仅准备上传/预检，不提交任务。
