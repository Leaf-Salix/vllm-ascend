"""Independent CPU-only review of V4 real generated kernels and root lifetime."""
import hashlib
import json
import re
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def body(path,name):
 s=path.read_text();s=s[s.index('static __aicore__ void '+name+'('):s.index('// --- Kernel entry point ---')]
 return re.sub(r'\s+','',re.sub(r'//[^\n]*','',s))
checks=[]
references={
 'input_rms_fused':ROOT/'math/input-norm-fused-probe/generated-review/kernels/aiv/input_rms_fused.cpp',
 'csa_checked_indices':ROOT/'csa-plan-workers32/generated-review/kernels/aiv/csa_checked_indices.cpp',
 'csa_slots_build_valid_qk_plan':ROOT/'csa-plan-workers32/generated-review/kernels/aiv/csa_slots_build_valid_qk_plan.cpp',
 'hc_pre_square_partial':ROOT/'square-group4/generated-review/hc/kernels/aic/hc_pre_square_partial.cpp',
}
for name,old in references.items():
 core='aic' if name=='hc_pre_square_partial' else 'aiv'
 new=HERE/f'kernels/{core}/{name}.cpp'
 assert body(old,name)==body(new,name),name+' core instruction drift'
 checks.append({'name':name,'core_identity':True,'source_sha256':sha(new),'normalized_core_sha256':hashlib.sha256(body(new,name).encode()).hexdigest()})
orch=next((HERE/'orchestration').glob('*.cpp')).read_text()
assert 'projected_kv__rv' not in orch
for n,slot in [('mixed',0),('normed',3),('rstd',4),('projected_kv',5),('heads',9)]:
 assert f'const Tensor& {n} = alloc_0.get_ref({slot});' in orch
assert 'params_t12.add_output(rstd);' in orch and 'params_t12.add_output(normed);' in orch
assert 'params_t15.add_output(projected_kv);' in orch and 'params_t26.add_input(projected_kv);' in orch
for n in ('csa_checked_indices','csa_slots_build_valid_qk_plan'):
 i=orch.index('// Spmd '+n);segment=orch[i:orch.index('\n\n',i)]
 assert '.launch_spec.set_block_num(32)' in segment
assert 'params_t60_deps[params_t60_deps_count++] = checked_tid_inline17304;' in orch
assert 'qk_plan_tid_inline17424' in orch
# Both generated planners use token8 blocks at start worker*8, stride32*8=256.
# Per-row storage: cmp indices512I32=2048B, valid mask16I32=64B,
# sparse bias1024F32=4096B. Thus no pair of workers touches a shared64B row.
for t in range(1,257):
 owners={}
 for worker in range(32):
  for begin in range(worker*8,t,256):
   for row in range(begin,min(begin+8,t)):
    assert row not in owners;owners[row]=worker
 assert set(owners)==set(range(t))
 for stride in (2048,64,4096):
  assert stride%64==0
result={'pass':True,'scope':'independent source/generated review, no NPU execution','V4_manifest_sha256':sha(ROOT/'csa-combo-v4/manifest.json'),'checks':checks,'norm_wide_range':[8224,24608],'norm_max_UB_writer_end':40992,'norm_scalar_writes':'UB only, original8lane rstd Vector store','planner_workers':32,'planner_token_stride':256,'T1to256_exclusive_rows':True,'scope_Out_root_ownership':True,'checked_plan_qk_dependency_preserved':True}
(HERE/'review-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
