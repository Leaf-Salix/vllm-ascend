import json
from pathlib import Path
from pypto.runtime import RunConfig
from pypto.runtime.kernel_compiler import KernelCompiler
from candidate_csa import decode_csa_tp1_layer_test
p=decode_csa_tp1_layer_test.compile(config=RunConfig(platform="a2a3"))
isa="/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/build/pto-isa"
for f in Path(p.output_dir).glob("kernels/*/*.cpp"):
 if f.parent.name not in ("aic","aiv"):continue
 (Path(__file__).parent/"precompile"/f.parent.name).mkdir(parents=True,exist_ok=True)
 b=KernelCompiler("a2a3").compile_incore(str(f),core_type=f.parent.name,pto_isa_root=isa,runtime_name="tensormap_and_ringbuffer",build_dir=str(Path(__file__).parent/"precompile"/f.parent.name))
 print("WIDE_HEADS_CCEC",f.name,len(b),flush=True)
