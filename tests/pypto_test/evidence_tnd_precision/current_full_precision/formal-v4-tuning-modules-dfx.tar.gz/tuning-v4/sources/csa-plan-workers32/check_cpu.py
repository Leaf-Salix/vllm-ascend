"""默认参数候选AST单因素、T1..256覆盖及Scalar cacheline排他写。"""
import ast
import hashlib
import json
from pathlib import Path
P=Path(__file__).resolve().parent
BASE=P/'baseline_sparse.py'
base=ast.parse(BASE.read_text());candidate=ast.parse((P/'candidate_sparse.py').read_text())
class Normalize(ast.NodeTransformer):
 def visit_ImportFrom(self,n):
  prefix='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.'
  if n.module and n.module.startswith(prefix):n.module=n.module.removeprefix(prefix);n.level=1
  return n
 def visit_Assign(self,n):
  if any(isinstance(t,ast.Name) and t.id=='CSA_PLAN_WORKERS' for t in n.targets):n.value=ast.Constant(value=16)
  return self.generic_visit(n)
assert ast.dump(Normalize().visit(candidate),include_attributes=False)==ast.dump(base,include_attributes=False),'Non-planning sparse AST changed'
assert (P/'baseline_csa.py').read_bytes()==(P.parent/'csa-combo-v2/candidate_csa.py').read_bytes()
class NormalizeRoot(ast.NodeTransformer):
 def visit_ImportFrom(self,n):return None if n.module=='candidate_sparse' else n
 def visit_Call(self,n):
  if isinstance(n.func,ast.Name) and n.func.id=='sparse_attn_csa_tp1':n.keywords=[k for k in n.keywords if k.arg!='plan_workers']
  return self.generic_visit(n)
assert ast.dump(NormalizeRoot().visit(ast.parse((P/'candidate_csa.py').read_text())),include_attributes=False)==ast.dump(ast.parse((P/'baseline_csa.py').read_text()),include_attributes=False),'Root other changes'
# Actual static config T=64*6 gives min(T,8)=8; row strides as source config.
constants={'BIAS_T_TILE':8,'CMP_TOPK':512,'VALID_BLOCK_MASK_COLS':16,'PADDED_TOPK':1024}
summary=[]
for tokens in range(1,257):
 for workers in (16,32):
  ownership={};line_owners={name:{} for name in ('cmp_sparse_indices','valid_block_mask','sparse_bias')}
  max_blocks=0
  for worker in range(workers):
   blocks=list(range(worker*8,tokens,workers*8));max_blocks=max(max_blocks,len(blocks))
   for start in blocks:
    for row in range(start,min(start+8,tokens)):
     assert row not in ownership;ownership[row]=worker
     # At least64B aligned tensor bases; per-row strides multiple64.
     for name,stride in [('cmp_sparse_indices',512*4),('valid_block_mask',16*4),('sparse_bias',1024*4)]:
      for line in range(row*stride//64,(row+1)*stride//64):
       assert line not in line_owners[name] or line_owners[name][line]==worker
       line_owners[name][line]=worker
  assert set(ownership)==set(range(tokens)),(tokens,workers)
  if tokens in (1,6,8,16,21,128,129,240,256):summary.append({'T':tokens,'workers':workers,'max_token_tiles_per_worker':max_blocks,'active_workers':len(set(ownership.values()))})
r={'pass':True,'sparse_numeric_AST_unchanged_after_private_constant_normalization':True,'root_numeric_AST_unchanged':True,'baseline_byte_equal_combo_v2':True,'all_T1_to256_coverage_and_64B_row_write_exclusion':True,'checked_tid_dependency_source_unchanged':True,'constants':constants,'cases':summary,'sha256':{n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in ('baseline_csa.py','candidate_csa.py','candidate_sparse.py')}}
(P/'cpu-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
