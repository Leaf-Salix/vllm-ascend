# CSA planning workers16→32：单因素概念AB

基线：`csa-combo-v2/candidate_csa.py`逐字节复制为baseline_csa。HC、O-proj、其余融合算法、模型输入与FULL graph harness均沿用该组合。

候选：复制baseprecision的Sparse文件到`candidate_sparse.py`，仅把两类relative imports改绝对baseprecision、私有常量`CSA_PLAN_WORKERS`16改32。候选root只override私有`sparse_attn_csa_tp1`；没有改正式源码、SDK或旧版本路径。

这是概念AB，**不是**建议直接将整份复制文件合入正式项目。默认参数最小探针发现当前inline parser不补省略参数（详见CALLSITES.md），因此按预先约定回退为私有常量候选。`optional_sparse_draft.py`只作研究草稿，不参与候选依赖。

## CPU门禁

`check_cpu.py`完成：

- 将私有常量归一化回16、还原imports后，Sparse全AST与正式base完全一致；slot检查、pair swap、数值计算和checked_tid依赖未变。
- 除私有Sparse override外，candidate root全AST与baseline一致。
- 真实T1～256、workers16/32的所有token tile/row恰好覆盖一次，无遗漏或重复。
- `cmp_sparse_indices`每row512×4=2048B，`valid_block_mask`每row16×4=64B，`sparse_bias`每row1024×4=4096B。以runtime对齐Tensor base为前提，各row的64B cacheline归属唯一worker，两阶段之间仍有完整checked_tid任务依赖；Scalar写回和Vector读没有跨worker cacheline共享。
- T240有30个8行tile：16workers最多各2块，32workers各1块、2个idle；T≤128的有效worker数不变，需实测额外idle/launch开销，不能先认定低T也有收益。

## 编译与运行

`compile.py --ccec planning`先lower完整candidate root，检查两个SPMD确实launch32，再只CCEC两个planner kernel。`--ccec all`可编译全部kernel；`--ccec none`只lower。不执行NPU。

NPU由主线程安排；本代理没有提交任何任务。复用`run-csa.sh <label> <lengths> [layer] [history]`的Native/baseline/candidate FULL graph门禁及计时。先混合T21确认精度，再T240测改善；外部task-submit必须max-time780。发现首差停止。

候选SHA：

- baseline_csa：`a8f08af4506d67a75d2b59574c270f7470a89a7eb9103d86663875ffa0e129c8`
- candidate_csa：`09b277c7bfa2516dea2fc058bc9a84f821c5902eeeffbac257aa796cde70a662`
- candidate_sparse：`a5e50fb4fc9ade75e25bde3b0927daf60ce46889a5b97879b5502c504f7e499f`

## 已完成的编译与实际代码检查

无设备预检3362个冻结source、20个helper通过。完整candidate root lower成功；两个planner实际launch均为32、token tile步长均为256。CCEC：

- `csa_checked_indices.cpp`：47,784字节。
- `csa_slots_build_valid_qk_plan.cpp`：274,904字节。

实际C++的cmp row stride为512 INT32、mask为16 INT32、bias为1024 FP32；task exit的entire-cache DCCI和DSB保留。Orchestration保留checked→plan→qk显式TaskId链。编译器的ScalarWriteLineShared保守警告保留，没有将无法自动证明的动态row索引警告压掉；CPU row/cacheline排他证明与实际stride相符。

`compile-results.json`、`generated-results.json`记录无NPU状态和核验；`generated-review/`保留实际两个planner及orchestration源码。CCEC通过不代表数值/性能验收，等待主线程安排。
