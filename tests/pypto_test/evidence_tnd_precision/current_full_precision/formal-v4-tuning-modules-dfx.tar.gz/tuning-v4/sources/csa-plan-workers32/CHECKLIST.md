# planning32隔离候选检查（2026-10-19 04:08）

- [x] 邻近comboV2/base Sparse源码、现有SDK默认参数语义已读
- [x] 最小默认Scalar无设备探针：省略参数被inline parser拒绝；原失败证据保留
- [x] 按预案只激活私有常量32概念AB，不改SDK/正式源码
- [x] `python check_cpu.py`：数学AST单因素、baseline字节、T1～256、64B写排他
- [x] 正式required参数的只读callsite统计
- [x] 私有源/SDK/helper预检：3362 source、20 helper通过
- [x] `python compile.py --ccec planning`：完整lower，两个planner CCEC通过
- [x] 实际C++：32 launch/256步长、row stride、DCCI/DSB及checked→plan→qk链核验
- [ ] 主线程安排混合TND FULL graph对Native/baseline精度门禁
- [ ] 主线程安排T240计时，确认Scalar瓶颈与总延迟收益
- [ ] 只有稳定收益后，考虑正式required参数最小改动

本代理没有提交NPU任务。当前构建是concept AB，不是已验收优化。
