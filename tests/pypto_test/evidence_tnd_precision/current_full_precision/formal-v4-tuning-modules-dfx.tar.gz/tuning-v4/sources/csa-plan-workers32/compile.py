"""无设备lower完整根；按需CCEC两planning核或全部，不执行NPU。"""
import argparse
import json
from pathlib import Path
from pypto.runtime import RunConfig
from pypto.runtime.kernel_compiler import KernelCompiler
from candidate_csa import decode_csa_tp1_layer_test
P=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--ccec',choices=('none','planning','all'),default='planning');a=p.parse_args()
program=decode_csa_tp1_layer_test.compile(config=RunConfig(platform='a2a3'))
print('PLAN32_GENERATED',program.output_dir,flush=True)
sources=[f for f in Path(program.output_dir).glob('kernels/*/*.cpp') if f.parent.name in ('aic','aiv')]
plans=[f for f in sources if f.stem in ('csa_checked_indices','csa_slots_build_valid_qk_plan')]
assert len(plans)==2
orchestration=list((Path(program.output_dir)/'orchestration').glob('*.cpp'));assert orchestration
text='\n'.join(f.read_text() for f in orchestration)
for name in ('csa_checked_indices','csa_slots_build_valid_qk_plan'):
 i=text.index('// Spmd '+name);segment=text[i:text.index('\n\n',i)]
 assert '.launch_spec.set_block_num(32)' in segment,(name,segment)
for f in plans:
 t=f.read_text();assert '256' in t,(f,'expected32x8 step')
ISA='/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/build/pto-isa'
compiled=[]
for f in sources if a.ccec=='all' else plans if a.ccec=='planning' else []:
 d=P/'precompile'/f.parent.name;d.mkdir(parents=True,exist_ok=True)
 binary=KernelCompiler('a2a3').compile_incore(str(f),core_type=f.parent.name,pto_isa_root=ISA,runtime_name='tensormap_and_ringbuffer',build_dir=str(d))
 (d/(f.stem+'.elf')).write_bytes(binary);compiled.append({'name':f.name,'bytes':len(binary)});print('PLAN32_CCEC_PASS',f.name,len(binary),flush=True)
(P/'compile-results.json').write_text(json.dumps({'NPU_executed':False,'ccec':a.ccec,'output_dir':str(program.output_dir),'planning_launch32_verified':True,'compiled':compiled},indent=2)+'\n')
