# required plan_workers的后续兼容范围（只读统计）

若workers32概念AB确有收益，当前仓库正式实现不必复制/工厂化整份Sparse代码。可给两层函数增加末尾**必填**`plan_workers: pl.Scalar[pl.INDEX]`，明确更新3个实际调用：

| 文件/函数 | 后续动作 |
| --- | --- |
| `deepseek_v4_flash_csa_tnd_precision/decode_sparse_attn_csa.py::sparse_attn_csa_tp1`内部调用`sparse_attn_csa`（当前line640） | 转发`plan_workers` |
| `deepseek_v4_flash_csa_tnd_precision/decode_csa.py`调用`sparse_attn_csa_tp1`（当前line454） | 显式传16，保留旧精度路径 |
| `deepseek_v4_flash_csa_tnd_full_precision/decode_csa.py`调用同一re-export函数（当前line370） | 显式传32，只有完整精度路径选新策略 |

对应两处函数定义在同一个baseprecision Sparse文件。它的两处SPMD和两处步长用同一参数，保留checked_tid依赖。正式顶层CSA根的62 tensor ABI不变；新增参数只存在内部inline依赖，不需要把worker参数暴露到service tensor ABI。

同仓另有`deepseek_v4_flash_csa`性能版及`deepseek_v4_flash_dspark`各自独立的Sparse实现和调用，导入的是自身`.decode_sparse_attn_csa`，不调用baseprecision这两层函数，因此无需修改。测试中的动态getattr诊断入口也指向性能版，不是baseprecision。baseprecision UT读取helper/softmax循环AST，没有直接调用这两层函数。

兼容注意：历史reports里有许多冻结root，它们可能从新baseprecision re-export取函数却沿用旧调用参数数目。新required参数会使这种跨版本混用arity失败；复现历史实验应使用其已固定SOURCE_ROOT/SDK和源码manifest，而不是让旧root连接新base。这里的概念AB使用独立私有复制，旧正式路径完全未动。

默认参数方案在当前SDK无法保持遗漏参数调用兼容：`default_probe.py`两层inline的omitted根在真实lower时报`Function plan_outer expects2 arguments, got1`。这不是Python函数签名问题，当前JIT入口虽然apply_defaults，但inline parser不补齐省略实参。证据保存在远端`default-compile-v2.log`。没有修改SDK；`optional_sparse_draft.py`仅保留草稿，不被候选root导入。

正式required参数修改仍待性能收益后决定。本次只做私有常量32概念AB。
