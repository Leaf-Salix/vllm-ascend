from pathlib import Path
from pypto.runtime import RunConfig
from pypto.runtime.kernel_compiler import KernelCompiler
from candidate_hc import hc_pre_test
p=hc_pre_test.compile(config=RunConfig(platform="a2a3"))
isa="/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/build/pto-isa"
for f in Path(p.output_dir).glob("kernels/*/*.cpp"):
 if f.parent.name not in ("aic","aiv"):continue
 b=Path(__file__).parent/"precompile"/f.parent.name;b.mkdir(parents=True,exist_ok=True)
 blob=KernelCompiler("a2a3").compile_incore(str(f),core_type=f.parent.name,pto_isa_root=isa,runtime_name="tensormap_and_ringbuffer",build_dir=str(b))
 print("HC_SHORT_CCEC_PASS",f.name,len(blob),flush=True)
