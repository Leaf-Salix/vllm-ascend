"""HC-pre面板复用：真实权重、Native逐bit门禁、同卡交错raw graph计时。"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import statistics
import time

import torch
import torch_npu
import pypto.torch
from safetensors import safe_open
from vllm_ascend.utils import enable_custom_op
import baseline_hc
import candidate_hc
from qualification_cpu import qualify_weight, qualify_flat

parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--tokens', type=int, nargs='+', required=True)
parser.add_argument('--device',type=int)  # scheduler compatibility; TASK_DEVICE controls visibility
a = parser.parse_args()
a.out.mkdir()
report = {'complete': False, 'pass': False, 'scope': 'HC-pre only; true model L4 weights, synthetic hidden; not full CSA or whole model',
          'task_device': os.environ['TASK_DEVICE'], 'checks': [], 'timings': [], 'source_sha': {}}
for m in (baseline_hc, candidate_hc):
    report['source_sha'][m.__name__] = hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()

def save():
    (a.out/'result.json').write_text(json.dumps(report, indent=2)+'\n')

def cpu(t):
    torch.npu.synchronize()
    return t.detach().cpu().clone()

def exact(x, y):
    return x.shape == y.shape and x.dtype == y.dtype and torch.equal(x.contiguous().view(torch.uint8), y.contiguous().view(torch.uint8))

def check(label, actual, gold):
    assert all(bool(torch.isfinite(v).all()) and bool(torch.isfinite(gold[k]).all()) for k,v in actual.items()), label+' nonfinite'
    bad = {k: not exact(v, gold[k]) for k, v in actual.items()}
    report['checks'].append({'label': label, 'bit_equal': {k: not v for k,v in bad.items()}})
    save()
    if any(bad.values()):
        torch.save({'actual': actual, 'gold': gold, 'hidden': cpu(hidden)}, a.out/'first-difference.pt')
        raise RuntimeError('FIRST_BIT_DIFFERENCE '+label)

def snapshot(out):
    return {k: cpu(v) for k,v in out.items()}

torch.npu.set_device(0)
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
assert enable_custom_op()
model = Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config = json.loads((model/'config.json').read_text())
index = json.loads((model/'quant_model_weights.safetensors.index.json').read_text())['weight_map']
weights = []
for name in ('hc_attn_fn', 'hc_attn_scale', 'hc_attn_base'):
    key = 'layers.4.'+name
    with safe_open(model/index[key], framework='pt', device='cpu') as f:
        w = f.get_tensor(key)
    assert w.dtype == torch.float32
    report.setdefault('weight_sha', {})[key] = hashlib.sha256(w.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()
    qualify_weight(w.numpy()) if name == 'hc_attn_fn' else None
    weights.append(w.to('npu'))
weight_gold = [cpu(w) for w in weights]
pypto.torch.init(device=0, platform='a2a3', runtime='tensormap_and_ringbuffer')
ops = {}
for name, module in [('baseline', baseline_hc), ('candidate', candidate_hc)]:
    ops[name] = (pypto.torch.register(module.hcpre_linear_test, f'precision_perf_hc_20261018::{name}_linear'),
                 pypto.torch.register(module.hc_pre_test, f'precision_perf_hc_20261018::{name}_full'))
try:
  with torch.inference_mode():
    for n in a.tokens:
        cpu_hidden = torch.randn((n,4,4096), generator=torch.Generator().manual_seed(17+n), dtype=torch.bfloat16)
        qualify_flat(cpu_hidden.float().reshape(n,16384).numpy())
        hidden = cpu_hidden.to('npu')
        original = hidden.clone()
        flat = hidden.float().reshape(n,16384)
        pad = (n+15)//16*16
        out, owners, graph = {}, {}, {}
        for name in ops:
            owners[name] = {'mixed': torch.full((n+2,4096), .0625, dtype=torch.bfloat16, device='npu'),
                            'post': torch.full((n+2,4), .0625, dtype=torch.float32, device='npu'),
                            'comb': torch.full((n+2,16), .0625, dtype=torch.float32, device='npu'),
                            'partials': torch.full((22*pad+2,32), .0625, dtype=torch.float32, device='npu')}
            out[name] = {k:v[1:-1] for k,v in owners[name].items()}
        def run(name, stage):
            if stage == 'linear':
                ops[name][0](flat, weights[0], out[name]['partials'])
            else:
                ops[name][1](hidden, *weights, out[name]['mixed'], out[name]['post'], out[name]['comb'])
        def native():
            native_values = torch.ops._C_ascend.npu_hc_pre_v2(hidden, *weights, 4, config['hc_sinkhorn_iters'], config['rms_norm_eps'], config['hc_eps'])
            return dict(zip(('mixed','post','comb'), (native_values[0],native_values[1],native_values[2].reshape(n,16))))
        for name in ops:
            for stage in ('linear', 'full'):
                run(name, stage)
                g = torch.npu.NPUGraph()
                with torch.npu.graph(g):
                    run(name, stage)
                graph[name,stage] = g
        native()  # prepare any lazy Native state before capture
        g = torch.npu.NPUGraph()
        with torch.npu.graph(g):
            native_out = native()
        graph['native','full'] = g
        # Gate before timing. NaN poisoning must be replaced by replay, with A/B/A/zero input changes.
        for phase in ('A','B','A_restored','zero'):
            hidden.copy_(original)
            if phase == 'B': hidden.add_(.125)
            if phase == 'zero': hidden.zero_()
            flat.copy_(hidden.float().reshape(n,16384))
            expected_hidden, expected_flat = cpu(hidden), cpu(flat)
            gold = snapshot(native())
            for name in ops:
                for v in out[name].values(): v.fill_(float('nan'))
                graph[name,'linear'].replay()
                graph[name,'full'].replay()
                actual = snapshot(out[name])
                check(f'T{n}/{phase}/{name}/Native', {k:actual[k] for k in gold}, gold)
                if name == 'baseline': baseline_partial = actual['partials']
                else: check(f'T{n}/{phase}/candidate/partials', {'partials': actual['partials']}, {'partials': baseline_partial})
                for k,v in owners[name].items():
                    assert bool((cpu(v[[0,-1]]) == .0625).all()), (name,k,'guard')
            graph['native','full'].replay()
            check(f'T{n}/{phase}/native/graph', snapshot(native_out), gold)
            assert exact(cpu(hidden),expected_hidden) and exact(cpu(flat),expected_flat), 'input changed'
            assert all(exact(cpu(w),v) for w,v in zip(weights,weight_gold)), 'weight changed'
        hidden.copy_(original)
        flat.copy_(hidden.float().reshape(n,16384))
        samples = {f'{name}/{stage}':[] for name,stage in graph}
        keys = list(graph)
        for key in keys:
            for _ in range(3): graph[key].replay()
        torch.npu.synchronize()
        # Alternating forward/reverse order reduces timing-order bias; compilation and CPU copies excluded.
        for round_id in range(8):
            for key in keys if round_id%2 == 0 else list(reversed(keys)):
                start, end = torch.npu.Event(enable_timing=True), torch.npu.Event(enable_timing=True)
                start.record()
                for _ in range(10): graph[key].replay()
                end.record(); end.synchronize()
                samples['/'.join(key)].append(start.elapsed_time(end)*1000/10)
        report['timings'].append({'tokens':n,'unit':'us/raw graph replay','samples':samples,
            'summary':{k:{'min':min(v),'mean':statistics.mean(v),'max':max(v)} for k,v in samples.items()}})
        # Final graph state still agrees after timing.
        gold = snapshot(native())
        for name in ops:
            graph[name,'full'].replay()
            check(f'T{n}/post_timing/{name}/Native', {k:cpu(out[name][k]) for k in gold},gold)
        save()
    report['pass'] = report['complete'] = True
    save()
except Exception as exc:
    report['error'] = repr(exc)
    save()
    raise
