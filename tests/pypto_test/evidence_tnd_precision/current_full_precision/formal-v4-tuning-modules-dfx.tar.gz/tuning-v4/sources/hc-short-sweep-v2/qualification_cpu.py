"""Fail-closed CPU setup gate; no model/Native arithmetic and no device calls."""
import numpy as np
LOW=79<<23
HIGH=167<<23

def rounded_weight(weight):
    b=np.asarray(weight,dtype=np.float32).view(np.uint32)
    return ((b+np.uint32(2048))&np.uint32(0xfffff000)).view(np.float32)

def bad(values,bf16=False):
    b=np.asarray(values,dtype=np.float32).view(np.uint32)&np.uint32(0x7fffffff)
    result=(b!=0)&((b<LOW)|(b>HIGH))
    if bf16:result|=(b&65535)!=0
    return result

def qualify_weight(weight):
    weight=np.asarray(weight)
    assert weight.dtype==np.float32 and weight.ndim==2 and weight.shape[0]==24
    converted=rounded_weight(weight)
    assert np.isfinite(weight).all(),'Cube qualification rejects raw NaN/Inf weights'
    assert not bad(converted).any(),'Cube qualification rejects rounded-weight range'
    hi=(converted.view(np.uint32)&np.uint32(0xffff0000)).view(np.float32)
    lo=np.subtract(converted,hi,dtype=np.float32)
    assert not ((hi.view(np.uint32)|lo.view(np.uint32))&np.uint32(0xffff)).any()
    assert np.array_equal(hi.astype(np.float64)+lo.astype(np.float64),converted.astype(np.float64))
    return True

def qualify_flat(flat):
    flat=np.asarray(flat)
    assert flat.dtype==np.float32 and flat.ndim==2
    assert not bad(flat,bf16=True).any(),'Cube qualification rejects non-BF16, nonfinite or out-of-range flat'
    return True

def certificates(flat,weight):
    tokens,hc=flat.shape;pad=(tokens+15)//16*16
    w=np.zeros((hc,32),dtype=np.float32);w[:,:24]=rounded_weight(weight).T
    wb=bad(w)
    wb[:,:24]|=~np.isfinite(weight.T)
    wf=wb.reshape(hc//256,256,32).any(axis=(1,2)).astype(np.int32)
    f=np.zeros((pad,hc),dtype=np.float32);f[:tokens]=flat
    xf=bad(f,bf16=True).reshape(pad//16,16,hc//256,256).any(axis=(1,3)).reshape(-1).astype(np.int32)
    return [np.repeat(v[:,None],16,axis=1) for v in (wf,xf)]
