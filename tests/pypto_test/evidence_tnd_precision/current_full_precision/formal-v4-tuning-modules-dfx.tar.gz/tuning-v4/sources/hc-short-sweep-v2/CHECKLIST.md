# 短T新Cube逐shape门禁

已测T6 Native全HC逐bit，1988.65→160.79us；本轮同一候选逐次T1…15，首差即停止。每任务780s，probe750s，未改SDK/正式源码。
