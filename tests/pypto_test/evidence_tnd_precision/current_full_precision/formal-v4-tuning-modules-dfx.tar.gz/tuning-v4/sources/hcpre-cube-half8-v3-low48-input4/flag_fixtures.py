"""Sparse real-shape certificate fixtures and integer partials oracle."""
import numpy as np
TOKENS=21
PAD=32
HC=16384
LOW=79<<23
HIGH=167<<23


def rational_round(bits):
 total=0
 for bit in bits:
  bit=int(bit);s=-1 if bit>>31 else 1;e=(bit>>23)&255;m=bit&0x7fffff
  assert e!=255
  total+=s*((m|(1<<23))<<(e-1) if e else m)
 s=0x80000000 if total<0 else 0;total=abs(total)
 if total<(1<<23):return s|total
 shift=max(0,total.bit_length()-24);m=total>>shift
 if shift:
  r=total-(m<<shift);h=1<<(shift-1);m+=int(r>h or (r==h and m&1))
 if m==(1<<24):m>>=1;shift+=1
 return s|((shift+1)<<23)|(m&0x7fffff)


def cases():
 return [
  ('normal',None,None,None),('zero',None,None,None),('negative_zero',None,None,None),
  ('input_lower_neighbour','input',LOW-1,(7,321)),('input_lower_boundary','input',LOW,(7,321)),
  ('input_upper_boundary','input',HIGH,(7,321)),('input_upper_neighbour','input',HIGH+1,(7,321)),
  ('input_inside_nonBF16_onebit','input',(127<<23)+1,(16,800)),
  ('weight_lower_HF32outside','weight',LOW-4096,(0,1024)),('weight_lower_boundary','weight',LOW,(0,1024)),
  ('weight_upper_boundary','weight',HIGH,(0,1024)),('weight_upper_HF32outside','weight',HIGH+4096,(0,1024)),
  ('weight_raw_rounds_to_lower','weight',LOW-1,(0,1024)),('weight_raw_rounds_to_upper','weight',HIGH+1,(0,1024)),
  ('tail_input_below','input',LOW-65536,(20,16383)),('tail_input_above','input',HIGH+65536,(20,16383)),
  ('tail_input_nonBF16','input',(127<<23)+1,(20,16383)),('tail_weight_below','weight',LOW-4096,(0,16383)),
  ('tail_weight_above','weight',HIGH+4096,(0,16383)),
 ]


def make(case,phase):
 tag,kind,bit,where=case
 flat=np.full((TOKENS,HC),np.float32(.25));weight=np.full((24,HC),np.float32(.125))
 if tag=='zero':flat.fill(0);weight.fill(0)
 if tag=='negative_zero':flat.fill(np.float32(-0.0));weight.fill(np.float32(-0.0))
 if kind:
  arr=flat if kind=='input' else weight
  arr[where]=np.array([bit],dtype=np.uint32).view(np.float32)[0]
 if phase=='B':flat=np.multiply(flat,np.float32(2),dtype=np.float32)
 if phase=='zero':flat.fill(0);weight.fill(0)
 return flat,weight


def rounded_weight(weight):
 bits=weight.view(np.uint32)
 return ((bits+np.uint32(2048))&np.uint32(0xfffff000)).view(np.float32)


def bad(v,bf16=False):
 bits=v.view(np.uint32)&np.uint32(0x7fffffff)
 result=(bits!=0)&((bits<LOW)|(bits>HIGH))
 if bf16:result|=(bits&65535)!=0
 return result


def certificates(flat,weight):
 w=np.zeros((HC,32),dtype=np.float32);w[:,:24]=rounded_weight(weight).T
 wf=bad(w).reshape(64,256,32).any(axis=(1,2)).astype(np.int32)
 f=np.zeros((PAD,HC),dtype=np.float32);f[:TOKENS]=flat
 xf=bad(f,bf16=True).reshape(PAD//16,16,64,256).any(axis=(1,3)).reshape(-1).astype(np.int32)
 unit=np.full(22*(PAD//8),-1,dtype=np.int32)
 for split in range(22):
  start=split*3;count=min(3,64-start)
  for row in range(0,PAD,8):
   if row<TOKENS:unit[split*(PAD//8)+row//8]=int(wf[start:start+count].any() or xf[(row//16)*64+start:(row//16)*64+start+count].any())
 return [np.repeat(v[:,None],16,axis=1) for v in (wf,xf,unit)]


def partials_oracle(case,phase):
 tag,kind,bit,where=case
 flat,weight=make(case,phase)
 output=np.zeros((22*PAD,32),dtype=np.float32)
 if tag in ('zero','negative_zero') or phase=='zero':return output
 pbase=np.float32(.03125)*(np.float32(2) if phase=='B' else np.float32(1))
 for split in range(22):output[split*PAD:split*PAD+TOKENS,:24]=np.float32(min(768,HC-split*768))*pbase
 if kind:
  row,k=where
  w=rounded_weight(weight)
  override=np.float32(flat[row,k]*w[0,k]) if kind=='input' else np.float32(flat[0,k]*w[row,k])
  split=k//768;kb=(k%768)//8;count=min(768,HC-split*768)//8
  current=np.float32(kb*8)*pbase
  terms=np.array([current]+[pbase]*7+[override],dtype=np.float32)
  current=np.array([rational_round(terms.view(np.uint32))],dtype=np.uint32).view(np.float32)[0]
  for step in range(kb+1,count):
   terms=np.array([current]+[pbase]*8,dtype=np.float32)
   current=np.array([rational_round(terms.view(np.uint32))],dtype=np.uint32).view(np.float32)[0]
  if kind=='input':output[split*PAD+row,:24]=current
  else:output[split*PAD:split*PAD+TOKENS,row]=current
 return output


if __name__=='__main__':
 for case in cases():
  for phase in ['A','B','A_restored','zero']:
   f,w=make(case,phase);wf,xf,u=certificates(f,w);out=partials_oracle(case,phase)
   assert np.isfinite(out).all()
   assert np.all((wf==0)|(wf==1)) and np.all((xf==0)|(xf==1))
   assert np.all(u[:,0].reshape(22,4)[:,3]==-1)
 print('FLAG_FIXTURES_CPU_PASS',len(cases()),'cases x4 phases; integer sparse partials oracle; all flag vectors full16')
