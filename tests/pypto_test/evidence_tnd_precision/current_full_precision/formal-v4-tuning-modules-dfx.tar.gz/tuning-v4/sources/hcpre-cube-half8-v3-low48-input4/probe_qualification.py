"""AIV-only qualificationOut graph gate: rejects NaN/Inf and non-BF16 flat."""
import argparse,hashlib,json,os
from pathlib import Path
import numpy as np
import torch,torch_npu,pypto.torch
import producer_probe
import qualification_fixtures as F
from qualification_cpu import certificates
p=argparse.ArgumentParser();p.add_argument('--out',required=True,type=Path);a=p.parse_args();a.out.mkdir()
report={'complete':False,'pass':False,'scope':'qualification only; Cube never runs; synthetic fixtures','checks':[],'source_sha':{}}
for name in ['producer_probe.py','qualification_cpu.py','qualification_fixtures.py','probe_qualification.py']:
    report['source_sha'][name]=hashlib.sha256((Path(__file__).parent/name).read_bytes()).hexdigest()
def save():(a.out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
def exact(x,y):return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
torch.npu.set_device(0);torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
op=pypto.torch.register(producer_probe.qualification,'overnight_cube_half8::qualification')
with torch.inference_mode():
    fo=torch.full((F.TOKENS+2,F.HC),.0625,dtype=torch.float32,device='npu');flat=fo[1:-1]
    wo=torch.full((26,F.HC),.0625,dtype=torch.float32,device='npu');weight=wo[1:-1]
    owners=[torch.full((n+2,16),-99,dtype=torch.int32,device='npu') for n in [64,(F.PAD//16)*64]]
    out=[v[1:-1] for v in owners]
    x,w=F.make(F.cases()[0],'A');flat.copy_(torch.from_numpy(x).to('npu'));weight.copy_(torch.from_numpy(w).to('npu'))
    op(flat,weight,*out);g=torch.npu.NPUGraph()
    with torch.npu.graph(g):op(flat,weight,*out)
    for case in F.cases():
      for phase in ['A','B','A_restored','zero']:
        x,w=F.make(case,phase);gold=[torch.from_numpy(v) for v in certificates(x,w)]
        flat.copy_(torch.from_numpy(x).to('npu'));weight.copy_(torch.from_numpy(w).to('npu'))
        for z in out:z.fill_(-99)
        g.replay();torch.npu.synchronize();observed=[v.cpu().clone() for v in out]
        c={'case':case[0],'phase':phase,'flags_full_equal':all(exact(v,e) for v,e in zip(observed,gold)),'inputs_unchanged':exact(flat.cpu(),torch.from_numpy(x)) and exact(weight.cpu(),torch.from_numpy(w)),'input_guards':bool((fo[[0,-1]].cpu()==.0625).all()) and bool((wo[[0,-1]].cpu()==.0625).all()),'output_guards':all(bool((v[[0,-1]].cpu()==-99).all()) for v in owners),'weight_bad_blocks':int((observed[0][:,0]!=0).sum()),'input_bad_blocks':int((observed[1][:,0]!=0).sum())}
        report['checks'].append(c);save()
        if not all(c[k] for k in ['flags_full_equal','inputs_unchanged','input_guards','output_guards']):
            torch.save({'case':case,'phase':phase,'actual_flags':observed,'expected_flags':gold},a.out/'first-difference.pt')
            raise RuntimeError('FIRST_QUALIFICATION_DIFFERENCE '+json.dumps(c))
report['complete']=report['pass']=True;save();print('CUBE_QUALIFICATION_PASS',len(report['checks']),flush=True)
