"""Synthetic-only qualification fixtures; no model weights or device calls."""
import numpy as np
from flag_fixtures import TOKENS,PAD,HC,cases as basic_cases,make as basic_make

def cases():
    result=basic_cases()
    for kind in ['input','weight']:
        for bits in [0x7f800000,0xff800000,0x7fc00000,0xffc00000,0x7f800001,0x7fffffff,0xffffffff]:
            result.append((kind+'_nonfinite_'+hex(bits),kind,bits,((20,16383) if kind=='input' else (23,16383))))
    for kind in ['input','weight']:
        for e in [-48,-47,-44,-42,-41,-40]:
            result.append((kind+'_new_domain_'+str(e),kind,(127+e)<<23,((20,16383) if kind=='input' else (23,16383))))
    return result

def make(case,phase):
    if '_nonfinite_' in case[0]:
        flat,weight=basic_make(('normal',None,None,None),'A')
        (_,kind,bits,where)=case
        (flat if kind=='input' else weight)[where]=np.array(bits,dtype=np.uint32).view(np.float32)
        if phase=='zero':flat.fill(0);weight.fill(0)
        elif phase=='B':flat[:,0]*=np.float32(2)
        return flat,weight
    return basic_make(case,phase)
