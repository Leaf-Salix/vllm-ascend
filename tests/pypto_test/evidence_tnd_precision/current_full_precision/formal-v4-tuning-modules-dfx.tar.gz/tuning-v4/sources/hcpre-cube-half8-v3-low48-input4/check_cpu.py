"""CPU packing/qualification proof; does not assume Cube K16 order correctness."""
import ast,json,hashlib
from pathlib import Path
import numpy as np
from qualification_cpu import qualify_flat,qualify_weight,rounded_weight,certificates
from qualification_fixtures import cases,make
HERE=Path(__file__).resolve().parent
rng=np.random.default_rng(2026101908)
def bits(shape,keep):
    b=(rng.integers(79,167,shape,dtype=np.uint32)<<23)|(rng.integers(0,2,shape,dtype=np.uint32)<<31)|rng.integers(0,1<<23,shape,dtype=np.uint32)
    b&=np.uint32(0xffffffff^((1<<(24-keep))-1));return b.view(np.float32)
weight=bits((24,16384),24);flat=bits((21,16384),8)
assert qualify_weight(weight) and qualify_flat(flat)
w=rounded_weight(weight).T
hi=(w.view(np.uint32)&np.uint32(0xffff0000)).view(np.float32);lo=np.subtract(w,hi,dtype=np.float32)
assert np.array_equal(hi.astype(np.float64)+lo.astype(np.float64),w.astype(np.float64))
assert not ((hi.view(np.uint32)|lo.view(np.uint32))&65535).any()
packed_w=np.zeros((32768,32),dtype=np.float32)
packed_w.reshape(2048,16,32)[:,:8,:24]=hi.reshape(2048,8,24)
packed_w.reshape(2048,16,32)[:,8:,:24]=lo.reshape(2048,8,24)
padded=np.zeros((32,16384),dtype=np.float32);padded[:21]=flat
packed_x=np.empty((32,32768),dtype=np.float32)
packed_x.reshape(32,2048,16)[:,:,:8]=padded.reshape(32,2048,8)
packed_x.reshape(32,2048,16)[:,:,8:]=padded.reshape(32,2048,8)
# Independently execute the actual v2 row-insert/transpose producer layout.
transpose_packed=np.empty_like(packed_x)
for t0 in range(0,32,16):
 for k0 in range(0,16384,256):
    tv=padded[t0:t0+16,k0:k0+256].T.copy()
    pt=np.zeros((512,16),dtype=np.float32)
    for chunk in range(32):
        input8=tv[chunk*8:chunk*8+8,:]
        pt[chunk*16:chunk*16+8,:]=input8
        pt[chunk*16+8:chunk*16+16,:]=input8
    transpose_packed[t0:t0+16,k0*2:(k0+256)*2]=pt.T
assert np.array_equal(transpose_packed.view(np.uint32),packed_x.view(np.uint32))
assert not (packed_w.view(np.uint32)&65535).any() and not (packed_x.view(np.uint32)&65535).any()
assert not packed_x[21:].any() and not packed_w[:,24:].any()
# Exhaustively verify all K positions and split boundaries in the packed maps.
for k in range(16384):
    p=(k//8)*16+k%8
    assert np.array_equal(packed_w[p,:24],hi[k]) and np.array_equal(packed_w[p+8,:24],lo[k])
    assert np.array_equal(packed_x[:,p],padded[:,k]) and np.array_equal(packed_x[:,p+8],padded[:,k])
covered=[]
for split in range(22):
    count=min(768,16384-split*768)//8
    for kb in range(count):
        p=split*1536+kb*16
        assert p>=0 and p+15<32768
        covered.extend(range(split*768+kb*8,split*768+kb*8+8))
assert covered==list(range(16384))
# Pairwise exact products for random token/channel/K8 witnesses.
idx=rng.integers(0,2048,20000);rr=rng.integers(0,21,20000);cc=rng.integers(0,24,20000)
x=padded[rr[:,None],idx[:,None]*8+np.arange(8)]
ww=w[idx[:,None]*8+np.arange(8),cc[:,None]]
px=packed_x[rr[:,None],idx[:,None]*16+np.arange(16)]
pw=packed_w[idx[:,None]*16+np.arange(16),cc[:,None]]
product=np.multiply(x,ww,dtype=np.float32)
pair=np.add(np.multiply(px[:,:8],pw[:,:8],dtype=np.float32),np.multiply(px[:,8:],pw[:,8:],dtype=np.float32),dtype=np.float32)
assert np.array_equal(product,pair) and np.array_equal(product.astype(np.float64),x.astype(np.float64)*ww.astype(np.float64))
# Producer diagnostic contains exactly the same two producer bodies, no Cube.
a=next(n for n in ast.parse((HERE/'candidate_panel.py').read_text()).body if isinstance(n,ast.FunctionDef))
b=next(n for n in ast.parse((HERE/'producer_probe.py').read_text()).body if isinstance(n,ast.FunctionDef))
loops=lambda f:[n for n in f.body if isinstance(n,ast.For)]
assert len(loops(a))==3 and len(loops(b))==2
assert [ast.dump(n,include_attributes=False) for n in loops(a)[:2]]==[ast.dump(n,include_attributes=False) for n in loops(b)]
previous=next(n for n in ast.parse((HERE.parent/'hcpre-cube-half8-v3/candidate_panel.py').read_text()).body if isinstance(n,ast.FunctionDef))
def norm48(n):
    class T(ast.NodeTransformer):
        def visit_Constant(self,v):
            if v.value==662700032:v.value=729808896
            return v
    import copy
    return T().visit(copy.deepcopy(n))
assert ast.dump(norm48(loops(a)[0]),include_attributes=False)==ast.dump(loops(previous)[0],include_attributes=False)
assert (HERE/'producer_probe.py').read_text().replace('662700032','729808896')==(HERE.parent/'hcpre-cube-half8-v3/producer_probe.py').read_text()
# The new outer K128 slicing visits precisely eight contiguous old K16 groups.
old_steps=[];new_groups=[]
for split in range(22):
    old_count=min(768,16384-split*768)//8
    new_count=min(768,16384-split*768)//64
    assert new_count==(12 if split<21 else 4) and old_count==new_count*8
    for kb in range(old_count):old_steps.append((split,split*1536+kb*16))
    for kb in range(new_count):
        start=split*1536+kb*128
        assert start%128==0 and start+127<32768
        for inner in range(8):new_groups.append((split,start+inner*16))
assert old_steps==new_groups and len(old_steps)==2048

qchecks=0;rejects=0
for case in cases():
 for phase in ['A','B','A_restored','zero']:
    f,ww=make(case,phase);flags=certificates(f,ww);passed=True
    try:qualify_flat(f);qualify_weight(ww)
    except AssertionError:passed=False
    assert passed==all(not v.any() for v in flags),(case[0],phase)
    qchecks+=1;rejects+=int(not passed)
result={'pass':True,'scope':'CPU pack/index/qualification only; not Cube numerical proof','packing':'K16 first8 hi +last8 lo; duplicated input','weight_split':'truncate BF16 hi with low16 mask, exact low4 residual','all_original_K_positions_checked':16384,'padded_token_rows_zero':11,'padded_weight_columns_zero':8,'exact_pair_product_witnesses':160000,'qualification_cases_phases':qchecks,'rejected_cases_phases':rejects,'diagnostic_producers_identical_AST':True,'v2_transpose_row_assembly_matches_original_packing_bitwise':True,'weight_producer_AST_unchanged_except_low_threshold':True,'qualification_probe_unchanged_except_low_threshold':True,'lower_exp':-48,'upper_exp':40,'minimum_exact_product_lattice_exp':-114,'K128_exactly_preserves_2048_K16_group_order':True,'new_step_counts':[12,4],'generic_HALF_NPU_still_required':False}
(HERE/'cpu-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
