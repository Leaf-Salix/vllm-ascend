#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
source /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overnight-20261019/hcpre-cube-half8-v3-low48-input4/env.sh
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
out="$job/results/${1:?}"
mkdir -p "$job/results"
mkdir "$out"
ccache -s > "$out/ccache.log"
export ASCEND_CACHE_PATH="$out/ascend-cache" ASCEND_PROCESS_LOG_PATH="$out/ascend"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
python "$job/preflight.py" > "$out/preflight.log" 2>&1
python "$job/probe_qualification.py" --out "$out/qualification" > "$out/qualification.log" 2>&1
python "$job/probe_hc.py" --out "$out/data" --tokens ${2:?} > "$out/run.log" 2>&1
