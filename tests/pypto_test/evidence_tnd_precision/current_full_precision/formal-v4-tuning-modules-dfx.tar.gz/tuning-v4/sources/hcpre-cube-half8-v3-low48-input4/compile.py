"""No-device Cube/AIV codegen and CCEC; does not execute kernels."""
import json
from pathlib import Path
from pypto.runtime import RunConfig
from pypto.runtime.kernel_compiler import KernelCompiler
from producer_probe import qualification
from candidate_panel import hcpre_linear_test
from candidate_hc import hc_pre_test
HERE=Path(__file__).resolve().parent
ISA='/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/build/pto-isa'
results=[]
for name,root in [('qualification',qualification),('linear',hcpre_linear_test),('hcpre',hc_pre_test)]:
    p=root.compile(config=RunConfig(platform='a2a3'))
    print('CUBE_HALF_GENERATED',name,p.output_dir,flush=True)
    sources=[x for x in Path(p.output_dir).glob('kernels/*/*.cpp') if x.parent.name in ['aic','aiv']]
    assert sources
    for source in sources:
        build=HERE/('compile-'+name)/source.parent.name;build.mkdir(parents=True,exist_ok=True)
        binary=KernelCompiler('a2a3').compile_incore(str(source),core_type=source.parent.name,pto_isa_root=ISA,runtime_name='tensormap_and_ringbuffer',build_dir=str(build))
        (build/(source.stem+'.elf')).write_bytes(binary)
        print('CUBE_HALF_CCEC_PASS',name,source.name,len(binary),flush=True)
    results.append({'name':name,'output_dir':str(p.output_dir),'kernels':len(sources)})
(HERE/'compile-results.json').write_text(json.dumps({'hardware_executed':False,'roots':results},indent=2)+'\n')
