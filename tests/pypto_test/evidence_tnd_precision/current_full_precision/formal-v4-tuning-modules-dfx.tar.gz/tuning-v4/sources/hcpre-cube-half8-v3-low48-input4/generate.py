"""Freeze only lower-domain qualification threshold; arithmetic stays V3."""
from pathlib import Path
import ast,hashlib,json
HERE=Path(__file__).resolve().parent
BASE=HERE.parent/'hcpre-cube-half8-v3'
for name in ['candidate_panel.py','producer_probe.py']:
    original=(BASE/name).read_text();changed=original.replace('729808896','662700032')
    assert changed!=original
    assert changed.replace('662700032','729808896')==original
    ast.parse(changed);(HERE/name).write_text(changed)
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(HERE.iterdir()) if p.is_file() and p.suffix in ['.py','.sh']}
(HERE/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
