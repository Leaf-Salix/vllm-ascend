"""Isolated split-domain guarded-Sum2 HC-pre candidate; not an accepted production variant.

The scalar path stays in hc_pre.py for short T. Only independent token rows
share weight loads here; K partitioning and each element's FP32 operation order
are identical. The expansion is explicit because existing DSL has no HF32 MAD.
"""
import pypto.language as pl
INPUT_FLAG_ROWS_DYN = pl.dynamic('INPUT_FLAG_ROWS_DYN')
T_DYN = pl.dynamic('T_DYN')
LINEAR_ROWS_DYN = pl.dynamic('LINEAR_ROWS_DYN')
HC_DIM = 16384
MIX_HC = 24
MIX_PAD = 32
LINEAR_OK = 22
LINEAR_K_PER_SPLIT = 768

def _qualification(flat: pl.Tensor[[T_DYN, HC_DIM], pl.FP32], weight: pl.Tensor[[MIX_HC, HC_DIM], pl.FP32], weight_range_flags: pl.Out[pl.Tensor[[HC_DIM // 256, 16], pl.INT32]], input_range_flags: pl.Out[pl.Tensor[[INPUT_FLAG_ROWS_DYN, 16], pl.INT32]]):
    flat.bind_dynamic(0, T_DYN)
    tokens = pl.tensor.dim(flat, 0)
    padded_tokens = (tokens + 15) // 16 * 16
    packed_weight = pl.create_tensor([HC_DIM * 2, MIX_PAD], dtype=pl.BF16)
    for block in pl.spmd(HC_DIM // 256, name_hint='hcpre_hf32_weight', allow_early_resolve=True):
        raw: pl.Tile[[32, 256], pl.FP32] = pl.load(weight, [0, block * 256], [32, 256], valid_shape=[MIX_HC, 256])
        transposed = pl.tile.transpose(raw, axis1=0, axis2=1)
        for pad_column in pl.range(MIX_HC, MIX_PAD):
            for pad_k in pl.range(256):
                pl.write(transposed, [pad_k, pad_column], 0.0)
        transposed = pl.set_validshape(transposed, 256, 32)
        bits = pl.tile.reinterpret_view(transposed, pl.INT32)
        converted = pl.tile.reinterpret_view(pl.tile.and_(pl.tile.add(bits, 2048), pl.tile.full([256, 32], dtype=pl.INT32, value=-4096)), pl.FP32)
        flag_weight = pl.set_validshape(converted, 256, 32)
        wflag_bits = pl.tile.and_(pl.tile.reinterpret_view(flag_weight, pl.INT32), pl.tile.full([256, 32], dtype=pl.INT32, value=2147483647))
        wflag_tmp = pl.create_tile([256, 16], dtype=pl.UINT32)
        wflag_nz = pl.tile.sel(pl.tile.cmp(wflag_bits, pl.tile.full([256, 32], dtype=pl.INT32, value=0), cmp_type=0), pl.tile.full([256, 32], dtype=pl.INT32, value=662700032), wflag_bits, wflag_tmp)
        wflag_low = pl.tile.and_(pl.tile.shrs(pl.tile.sub(wflag_nz, pl.tile.full([256, 32], dtype=pl.INT32, value=662700032)), 31), pl.tile.full([256, 32], dtype=pl.INT32, value=1))
        wflag_high = pl.tile.and_(pl.tile.shrs(pl.tile.sub(pl.tile.full([256, 32], dtype=pl.INT32, value=1400897536), wflag_bits), 31), pl.tile.full([256, 32], dtype=pl.INT32, value=1))
        wflag_bad = pl.tile.cast(pl.tile.add(wflag_low, wflag_high), pl.FP32)
        raw_exponent = pl.tile.and_(bits, pl.tile.full([256, 32], dtype=pl.INT32, value=2139095040))
        raw_nonfinite = pl.tile.sel(pl.tile.cmp(raw_exponent, pl.tile.full([256, 32], dtype=pl.INT32, value=2139095040), cmp_type=0), pl.tile.full([256, 32], dtype=pl.FP32, value=1.0), pl.tile.full([256, 32], dtype=pl.FP32, value=0.0), wflag_tmp)
        wflag_bad = pl.tile.maximum(wflag_bad, raw_nonfinite)
        wflag_columns = pl.tile.col_max(wflag_bad)
        wflag_rep = pl.col_expand(pl.create_tile([8, 32], dtype=pl.FP32), wflag_columns)
        wflag_maximum = pl.tile.row_max(wflag_rep, pl.create_tile([8, 32], dtype=pl.FP32))
        wflag_scalar = pl.cast(pl.tile.read(wflag_maximum, [0, 0]), pl.INT32)
        if wflag_scalar == 0:
            wflag_row = pl.tile.full([1, 16], dtype=pl.INT32, value=0)
        else:
            wflag_row = pl.tile.full([1, 16], dtype=pl.INT32, value=1)
        pl.store(wflag_row, [block, 0], weight_range_flags)
        hi_bits = pl.tile.and_(pl.tile.reinterpret_view(converted, pl.INT32), pl.tile.full([256, 32], dtype=pl.INT32, value=-65536))
        hi_fp32 = pl.tile.reinterpret_view(hi_bits, pl.FP32)
        lo_fp32 = pl.tile.sub(converted, hi_fp32)
        hi_bf16 = pl.tile.cast(hi_fp32, pl.BF16)
        lo_bf16 = pl.tile.cast(lo_fp32, pl.BF16)
        packed_block = pl.tile.full([512, 32], dtype=pl.BF16, value=0.0)
        for chunk in pl.range(32):
            high8 = pl.tile.slice(hi_bf16, [8, 32], [chunk * 8, 0])
            low8 = pl.tile.slice(lo_bf16, [8, 32], [chunk * 8, 0])
            packed_block = pl.tile.assemble(packed_block, high8, [chunk * 16, 0])
            packed_block = pl.tile.assemble(packed_block, low8, [chunk * 16 + 8, 0])
        pl.store(packed_block, [block * 512, 0], packed_weight)
    packed_flat = pl.create_tensor([padded_tokens, HC_DIM * 2], dtype=pl.BF16)
    for transpose_unit in pl.spmd(padded_tokens // 16 * (HC_DIM // 256), name_hint='hcpre_input_panel', allow_early_resolve=True):
        t0 = transpose_unit // (HC_DIM // 256) * 16
        k0 = transpose_unit % (HC_DIM // 256) * 256
        values = pl.load(flat, [t0, k0], [16, 256], valid_shape=[pl.min(16, tokens - t0), 256])
        for invalid_row in pl.range(pl.min(16, tokens - t0), 16):
            for invalid_col in pl.range(256):
                pl.write(values, [invalid_row, invalid_col], 0.0)
        values = pl.set_validshape(values, 16, 256)
        flag_input = pl.set_validshape(values, 16, 256)
        xflag_bits = pl.tile.and_(pl.tile.reinterpret_view(flag_input, pl.INT32), pl.tile.full([16, 256], dtype=pl.INT32, value=2147483647))
        xflag_tmp = pl.create_tile([16, 16], dtype=pl.UINT32)
        xflag_nz = pl.tile.sel(pl.tile.cmp(xflag_bits, pl.tile.full([16, 256], dtype=pl.INT32, value=0), cmp_type=0), pl.tile.full([16, 256], dtype=pl.INT32, value=662700032), xflag_bits, xflag_tmp)
        xflag_low = pl.tile.and_(pl.tile.shrs(pl.tile.sub(xflag_nz, pl.tile.full([16, 256], dtype=pl.INT32, value=662700032)), 31), pl.tile.full([16, 256], dtype=pl.INT32, value=1))
        xflag_high = pl.tile.and_(pl.tile.shrs(pl.tile.sub(pl.tile.full([16, 256], dtype=pl.INT32, value=1400897536), xflag_bits), 31), pl.tile.full([16, 256], dtype=pl.INT32, value=1))
        xflag_bad = pl.tile.cast(pl.tile.add(xflag_low, xflag_high), pl.FP32)
        xflag_tail = pl.tile.and_(xflag_bits, pl.tile.full([16, 256], dtype=pl.INT32, value=65535))
        xflag_format = pl.tile.sel(pl.tile.cmp(xflag_tail, pl.tile.full([16, 256], dtype=pl.INT32, value=0), cmp_type=0), pl.tile.full([16, 256], dtype=pl.FP32, value=0.0), pl.tile.full([16, 256], dtype=pl.FP32, value=1.0), xflag_tmp)
        xflag_bad = pl.tile.maximum(xflag_bad, xflag_format)
        xflag_columns = pl.tile.col_max(xflag_bad)
        xflag_rep = pl.col_expand(pl.create_tile([8, 256], dtype=pl.FP32), xflag_columns)
        xflag_maximum = pl.tile.row_max(xflag_rep, pl.create_tile([8, 256], dtype=pl.FP32))
        xflag_scalar = pl.cast(pl.tile.read(xflag_maximum, [0, 0]), pl.INT32)
        if xflag_scalar == 0:
            xflag_row = pl.tile.full([1, 16], dtype=pl.INT32, value=0)
        else:
            xflag_row = pl.tile.full([1, 16], dtype=pl.INT32, value=1)
        pl.store(xflag_row, [transpose_unit, 0], input_range_flags)
        transposed_values = pl.tile.transpose(values, axis1=0, axis2=1)
        packed_transposed = pl.tile.full([512, 16], dtype=pl.FP32, value=0.0)
        for chunk in pl.range(32):
            input8 = pl.tile.slice(transposed_values, [8, 16], [chunk * 8, 0])
            packed_transposed = pl.tile.assemble(packed_transposed, input8, [chunk * 16, 0])
            packed_transposed = pl.tile.assemble(packed_transposed, input8, [chunk * 16 + 8, 0])
        packed_values = pl.tile.transpose(packed_transposed, axis1=0, axis2=1)
        pl.store(pl.tile.cast(packed_values, pl.BF16), [t0, k0 * 2], packed_flat)
    return (weight_range_flags, input_range_flags)
qualification = pl.jit(_qualification)
