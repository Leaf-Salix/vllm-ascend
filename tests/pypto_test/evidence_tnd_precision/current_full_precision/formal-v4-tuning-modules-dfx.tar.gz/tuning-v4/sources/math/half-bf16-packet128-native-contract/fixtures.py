"""纯CPU通用FP32整数oracle；不加载模型或NPU。"""
import numpy as np

F = np.float32


def rational_round(bits):
    total = 0
    for bit in bits:
        sign = -1 if int(bit) >> 31 else 1
        exponent = int(bit) >> 23 & 255
        sig = int(bit) & 8388607
        total += sign * ((sig | 1 << 23) << exponent - 1 if exponent else sig)
    sign = 2147483648 if total < 0 else 0
    total = abs(total)
    if total < 1 << 23:
        return sign | total
    shift = max(0, total.bit_length() - 24)
    rounded = total >> shift
    if shift:
        rem = total - (total >> shift << shift)
        half = 1 << shift - 1
        rounded += int(rem > half or (rem == half and rounded & 1))
    if rounded == 1 << 24:
        rounded >>= 1
        shift += 1
    return sign | shift + 1 << 23 | rounded & 8388607


def split_trunc(values):
    """Acc:8+8+8同号位片；weight:8+4位片。每片都精确BF16。"""
    hi = (values.view(np.uint32) & np.uint32(0xffff0000)).view(F)
    rest = np.subtract(values, hi, dtype=F)
    mid = (rest.view(np.uint32) & np.uint32(0xffff0000)).view(F)
    lo = np.subtract(rest, mid, dtype=F)
    for part in (hi, mid, lo):
        assert not (part.view(np.uint32) & np.uint32(0xffff)).any()
    assert np.array_equal(hi.astype(np.float64) + mid.astype(np.float64) + lo.astype(np.float64), values.astype(np.float64))
    return hi, mid, lo


def fixture(steps=1, phase='A'):
    assert steps in (1, 8)
    rng = np.random.default_rng(202610190081)
    tags = ['zero', 'negative_zero_inputs', 'ones', 'independent_HL_counterexample',
            'H_with_acc_counterexample', 'exact_cancel', 'positive_halfway', 'negative_halfway',
            'span32', 'cancel_large_span', 'random_narrow', 'random_span32', 'random_full_acc',
            'positive_only', 'negative_only', 'alternating_sign'] + ['random_'+str(i) for i in range(16)]
    groups = len(tags)
    def random_values(shape, width, keep_bits):
        exp = rng.integers(127-width,128+width,shape,dtype=np.uint32)
        bits = ((rng.integers(0,2,shape,dtype=np.uint32)<<31) | (exp<<23)
                | rng.integers(0,1<<23,shape,dtype=np.uint32))
        return (bits & np.uint32(0xffffffff ^ ((1 << (24-keep_bits))-1))).view(F)
    x = random_values((groups,steps,16,8),8,8)
    w = random_values((groups,steps,8,32),8,12)
    acc = random_values((groups,16,32),16,24)
    x[:2] = F(0); w[:2] = F(0); acc[:2] = F(0)
    x[1].fill(F(-0.0)); w[1].fill(F(1))
    x[2].fill(F(1)); w[2].fill(F(1)); acc[2].fill(F(1))
    x[3:10] = 0; w[3:10] = 1; acc[3:10] = 0
    x[3,0,:,0] = 1; x[3,0,:,1] = F(2**-24); acc[3] = F(2**-23)
    x[4,0,:,0] = 1; x[4,0,:,1] = F(2**-13); x[4,0,:,2] = F(-2**-13)
    w[4,0,1] = F(1+2**-11); acc[4] = F(2**-24)
    x[5,0] = np.array([1,-1,2**32,-2**32,2**-32,-2**-32,1,-1],dtype=F)
    x[6,0,:,0] = 1; x[6,0,:,1] = F(2**-24)
    x[7,0] = -x[6,0]
    x[8,0] = np.array([2.**e for e in (0,-32,16,-16,8,-8,31,-1)],dtype=F)
    x[9,0] = np.array([2**32,-2**32,1,2**-24,2**-32,-2**-32,0,0],dtype=F)
    x[10] = random_values((steps,16,8),2,8); w[10] = random_values((steps,8,32),2,12)
    x[11] = random_values((steps,16,8),16,8); w[11] = random_values((steps,8,32),16,12)
    x[13] = np.abs(x[13]); w[13] = np.abs(w[13]); acc[13] = np.abs(acc[13])
    x[14] = -np.abs(x[14]); w[14] = np.abs(w[14]); acc[14] = -np.abs(acc[14])
    x[15,:,:,::2] = np.abs(x[15,:,:,::2]); x[15,:,:,1::2] = -np.abs(x[15,:,:,1::2])
    if phase == 'B':
        # Change data without changing addresses/shapes; weights remain exact HF32.
        x = np.roll(x,1,axis=2).copy(); w = -w; acc = -acc
    elif phase == 'zero':
        x.fill(0); w.fill(0); acc.fill(0)
    else:
        assert phase == 'A'
    # Initial mathematical zero is +0. Signed-zero operands are still tested.
    acc[acc == 0] = F(0)
    ah, am, al = split_trunc(acc)
    wh, wl, unused = split_trunc(w)
    assert not unused.any(), 'HF32 12 significand bits split into 8+4'
    packed_x = np.repeat(x,2,axis=-1)
    packed_w = np.empty((groups,steps,16,32),dtype=F)
    packed_w[:,:,0::2] = wh; packed_w[:,:,1::2] = wl
    packed_product = np.multiply(packed_x[:,:,:,:,None],packed_w[:,:,None,:,:],dtype=F)
    original_product = np.multiply(x[:,:,:,:,None],w[:,:,None,:,:],dtype=F)
    assert np.array_equal(original_product.astype(np.float64), x[:,:,:,:,None].astype(np.float64)*w[:,:,None,:,:].astype(np.float64))
    assert np.array_equal(packed_product[:,:,:,0::2].astype(np.float64)+packed_product[:,:,:,1::2].astype(np.float64),original_product.astype(np.float64))
    expected = np.empty((groups,steps,16,32),dtype=F)
    current = acc.copy()
    for step in range(steps):
        products = original_product[:,step]
        for group in range(groups):
            for row in range(16):
                for col in range(32):
                    bits = np.concatenate((current[group,row,col:col+1],products[group,row,:,col])).view(np.uint32)
                    expected[group,step,row,col] = np.array(rational_round(bits),dtype=np.uint32).view(F)
        current = expected[:,step].copy()
    return {'tags': tags, 'identity': np.eye(16,dtype=F), 'acc': acc.reshape(-1,32),
            'acc_hi': ah.reshape(-1,32), 'acc_mid': am.reshape(-1,32), 'acc_lo': al.reshape(-1,32),
            'packed_x': packed_x.reshape(-1,16), 'packed_w': packed_w.reshape(-1,32),
            'expected': expected.reshape(-1,32), 'steps': steps, 'phase': phase}
