# low48 新增域的 Native 硬件合同验收

沿用 `low48-first-difference` 已通过的 Native workspace 观察器；不编译C++，不改SDK或生产代码。

## 分组与口径

两个独立短任务：group32～39、group40～47，各128个病例。每组覆盖8步，每步T16、24列窗口0～23与8～31，合并覆盖全部16×32元素。各任务最多780秒、内部750秒。

每一步：用原BF16逐K16根的前一步实际FP32累加值作旧acc；通过三个BF16 identity block建立同一Native旧acc，并在开启新八积之前独立核验prefix逐bit相同。然后执行相同八个原始BF16×HF32乘积，检查Native rawAB与BF16 Cube逐bit一致；首差即停止。每例保留Native重复、观察器可见三输出fidelity、workspace header/输入marker/guard门禁。

整数九项RNE只是独立数学诊断，保留差异，不重新作为Native金值。窗口重叠元素在原始比较计数中重复；每任务唯一元素32,768，比较元素49,152。

## CPU预检

两任务各128病例，任意acc的三个BF16分片精确重构、输入片段和列窗口全部通过。

- group32～39：整数诊断差异6,144（含重叠），来自已知group36。
- group40～47：整数诊断差异30（含重叠）。这里用实际旧acc重新计算单步整数结果，数量与原整条整数轨迹差异不同，因而不能直接比较其总数。

复现入口：`bash "$JOB/run.sh" <新label> 32 39`；第二任务用 `40 47`。

当前证据覆盖原逐K16 BF16根的phaseA；不会自动宣称K128或phaseB/graph验收通过。

## NPU结果

| 任务 | 分组 | 状态 | Native/BF16逐bit差异 |
| --- | --- | --- | ---: |
| `task_20261019_032825_348135622422` | 32～39 | exit0，约1分钟 | 0/32,768 |
| `task_20261019_032959_357888415313` | 40～47 | exit0，约1分钟 | 0/32,768 |

256病例全部完成。每个病例的旧acc prefix、Native重复、观察器fidelity、workspace guards通过。两个列窗口的重叠16列逐bit相同。额外CPU检查每一步的Native结果确实等于下一步送入Native的旧acc，完成phaseA整条8步轨迹的归纳验证。

去重后 Native 与单步整数RNE有4,114个差异：group36为4,096，group42为8，group43为10，其余为0。这些差异在Native与BF16中相同。原始generic的4,134是与独立整数整条轨迹对比，包含前步误差传播，两者口径不同，均保留。

`summary.json` 是去重结果。`native-bank-A.pt` 保存形状 `[16group,8step,16row,32col]` 的Native实际轨迹、最后一步、整数单步诊断、BF16轨迹、旧acc。银行SHA：`b3b87f7c6f1a80b10be8cdafd56112d7c99740c10c099a32c9b04421612bfea1`。`summarize.py` 可由两个任务的已保存合成张量重新核验窗口/归纳关系并生成银行。

本次没有修改数学金值或弱化原整数门禁，而是明确区分数学参考与实际Native硬件合同。它验证的是新增low48域的phaseA逐K16 BF16合同，**不是**任意IEEE输入证明，也**没有**自动覆盖K128合并、phaseB或graph。这些仍需使用实际Native银行做独立门禁。
