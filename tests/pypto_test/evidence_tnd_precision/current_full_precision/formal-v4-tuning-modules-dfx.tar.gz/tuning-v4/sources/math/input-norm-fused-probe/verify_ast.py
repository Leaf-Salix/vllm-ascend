"""CPU-only AST arithmetic identity check, without importing NPU packages."""
import ast
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
base=ast.parse((root/'baseline_norm.py').read_text())
cand=ast.parse((root/'candidate_norm.py').read_text())
dump=lambda n:ast.dump(n,include_attributes=False)
fn=lambda tree,name:next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
square=fn(base,'_square_sum').body[-2]
norm=fn(base,'_input_norm_test')
fused=fn(cand,'_input_norm_test').body[-2]
assert isinstance(fused,ast.For)
base_sum=square.body[:-1]
assert [dump(n) for n in fused.body[:len(base_sum)]]==[dump(n) for n in base_sum]
base_inverse=norm.body[-3].body
# Only inverse's GM scalar read is replaced by same FP32 row_sum tile's lane0.
for i,n in enumerate(base_inverse[2:],2):
 assert dump(n)==dump(fused.body[len(base_sum)+i]),i
assert dump(fused.body[len(base_sum)])==dump(ast.parse('total_scalar = pl.read(total, [0, 0])').body[0])
expected=ast.parse('total_vector = pl.mul(pl.full([1, 8], dtype=pl.FP32, value=1.0), total_scalar)').body[0]
assert dump(fused.body[len(base_sum)+1])==dump(expected)
base_apply=norm.body[-2].body
new_apply=fused.body[len(base_sum)+len(base_inverse):]
assert dump(new_apply[0])==dump(ast.parse('apply_value = wide').body[0])
assert dump(new_apply[1])==dump(ast.parse('w_raw = pl.load(weight_view, [0, 0], [1, 4096], target_memory=pl.MemorySpace.Vec)').body[0])
assert dump(new_apply[2])==dump(ast.parse('w = pl.cast(w_raw, pl.FP32)').body[0])
assert dump(new_apply[3])==dump(ast.parse('inv = pl.read(inverse, [0, 0])').body[0])
assert [dump(n) for n in new_apply[4:6]]==[dump(n) for n in base_apply[3:5]]
assert dump(new_apply[6])==dump(ast.parse('pl.store(pl.cast(result, pl.BF16, mode="rint"), [row, 0], output)').body[0])
for constant in ('FRACTION_UNIT','SQRT_COMPARE_SHIFT','SQRT_CORRECTION_STEPS','FP32_INFINITY_BITS'):
 get=lambda tree:next(n for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id==constant)
 assert dump(get(base))==dump(get(cand)),constant
assert dump(norm.args)==dump(fn(cand,'_input_norm_test').args)
assert [dump(n) for n in norm.body[:4]]==[dump(n) for n in fn(cand,'_input_norm_test').body[:4]]
assert dump(fn(cand,'_input_norm_test').body[4])==dump(ast.parse('weight_view = pl.reshape(weight, [1, 4096])').body[0])
print(json.dumps({'pass':True,'sum_arithmetic_statements':len(base_sum),'inverse_unchanged_statements':len(base_inverse)-2,'apply_unchanged_multiply_statements':2,'arithmetic_changes':False,'edge_changes':['remove sums GM write/read','reuse retained FP32 wide input','read inverse FP32 tile lane0 instead of same rstd GM lane0','orchestration-only weight Tensor reshape plus explicit BF16 Tile load, same FP32 cast and values','explicit pl.store of same BF16 RNE cast to same row instead of Tensor subscript write'],'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ('baseline_norm.py','candidate_norm.py')}},indent=2))
