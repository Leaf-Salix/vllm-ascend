# low48 K128：独立 Native 合同闭环

不改原32组整数金值。新增16个极端组使用独立Native HF32观察器的实际银行；原整数轨迹仍保留作诊断。不是用当前seq结果直接充当Native。

银行来自六个独立任务：A组032825/032959、B组033724/033825、zero组033940/034023。每个phase覆盖16组×8步×16行×32列=65,536去重元素；全部Native rawAB与逐K16 BF16相同，768病例prefix/repeat/fidelity/guard、重叠与跨步归纳检查通过。源证据在相邻 `low48-native-contract`、`low48-native-contract-bz`。

- B实际变换：新增16组x沿row roll1，w取负，acc取负但不roll。因此B银行独立采样/Native验证，未从A推断。
- 银行包含每phase完整七项实际输入SHA、Native轨迹/末步、两个原始任务结果SHA、complete标记和固定观察器SHA。
- helper manifest固定银行文件SHA。probe要求七个输入键完整、逐phaseSHA匹配、Native FP32且finite、完整group顺序、provenance complete。
- `check_bank_cpu.py` 实际AST抽取并执行probe的加载函数；确认原32组expected逐bit未改、新16轨迹和末步确为Native银行。

最终任务保留原generic eager A、graph A/B/A-restored/zero、输出NaN poison、外侧guards、输入不改。seq全部8步对gold，K128末步对gold，另保留K128对seq交叉检查。首差停止。任务max780秒，内部750秒。

目前银行冻结SHA：`b529583b21efa08dba414f0f3fad53a92858d40f3c5aed118c7f9c80c5ef74d8`。CPU银行门禁通过：A、B各保留4,134个整数整轨迹诊断差异；zero为0。

复现：`bash "$JOB/run.sh" <新label> 8`。本文件中的gold为原32整数+新16真实Native合同；不宣称数学无限精度累加或任意IEEE域，也不是整模型验收。
