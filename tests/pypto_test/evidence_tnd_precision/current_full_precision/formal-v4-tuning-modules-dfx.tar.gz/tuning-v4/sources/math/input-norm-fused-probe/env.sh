#!/usr/bin/env bash
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/tnd-precision-delivery-20261018/env.sh"
job="$base/precision-overnight-20261019/input-norm-fused-probe"
export PYTHONPATH="$job:$PYTHONPATH"
export PYPTO_PROG_BUILD_DIR="$job/build" PYPTO_CACHE_DIR="$job/cache"
