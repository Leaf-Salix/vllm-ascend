"""Agent-only bounded audit of frozen Norm v5 generated UB live ranges."""
import hashlib
import json
import re
from pathlib import Path

job=Path(__file__).resolve().parent
path=job/'generated-review/kernels/aiv/input_rms_fused.cpp'
source=path.read_text();lines=source.splitlines()
constants={}
for line in lines:
 m=re.search(r'const int64_t (v\d+) = (\d+);',line)
 if m:constants[m[1]]=int(m[2])
 m=re.search(r'uint64_t (v\d+) = \(uint64_t\) (v\d+);',line)
 if m and m[2] in constants:constants[m[1]]=constants[m[2]]
tiles={}
for line in lines:
 m=re.match(r'\s*Tile<TileType::Vec, ([^,]+), (\d+), (\d+), BLayout::(\w+), (-?\d+), (-?\d+),.*> (v\d+)(?: = |;)',line)
 if not m:continue
 dtype,rows,cols,layout,vr,vc,var=m.groups();rows=int(rows);cols=int(cols)
 # Valid dimensions limit element access for slices. Physical scratch/full tiles
 # are conservatively padded to 32-byte rows/columns by the ISA Vec layout.
 actual_rows=rows if int(vr)<0 else int(vr);actual_cols=cols if int(vc)<0 else int(vc)
 width={'float':4,'int32_t':4,'bfloat16_t':2}[dtype]
 extent=actual_rows*((actual_cols*width+31)//32*32) if layout=='RowMajor' else actual_cols*((actual_rows*width+31)//32*32)
 tiles[var]={'dtype':dtype,'rows':rows,'cols':cols,'layout':layout,'bytes':extent}
for line in lines:
 m=re.search(r'TASSIGN\((v\d+), (v\d+)\);',line)
 if m:tiles[m[1]]['offset']=constants[m[2]]
start=next(i for i,l in enumerate(lines) if 'TCVT(v84, v75,' in l)
end=next(i for i,l in enumerate(lines) if 'TMULS(v228, v215,' in l)
assert tiles['v84']['offset']==8224 and tiles['v84']['bytes']==16384
assert tiles['v215']['offset']==8224
wide=(8224,24608);writes=[];overlap=[]
for i,line in enumerate(lines):
 m=re.match(r'\s*(T[A-Z0-9_]+)\((v\d+),',line)
 vars=[]
 if m and m[1] not in {'TASSIGN','TSTORE'}:vars.append((m[2],m[1]))
 if m and m[1]=='TROWSUM':vars.append((re.search(r', (v\d+)\);',line)[1],'TROWSUM_SCRATCH'))
 m2=re.match(r'\s*(v\d+)\.SetValue\(',line)
 if m2:vars.append((m2[1],'SetValue'))
 for var,op in vars:
  tile=tiles[var];lo=tile['offset'];hi=lo+tile['bytes'];writes.append({'line':i+1,'op':op,'tile':var,'range':[lo,hi]})
  if start<i<end and lo<wide[1] and hi>wide[0]:overlap.append(writes[-1])
assert not overlap,overlap
assert max(w['range'][1] for w in writes)==40992
assert tiles['v207']['offset']==0 and tiles['v207']['bytes']==32
assert 'TSTORE(v214, v207);' in source
assert 'TLOAD(v217, v222);' in source and tiles['v217']['offset']+tiles['v217']['bytes']==wide[0]
assert 'wait_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);\n  TLOAD(v217, v222);' in source
assert 'wait_flag(PIPE_V, PIPE_S, EVENT_ID4);' in source
assert 'RoundMode v234 = RoundMode::CAST_RINT;' in source
orch=next((job/'generated-review/orchestration').glob('*.cpp')).read_text()
assert orch.count('rt_submit_aiv_task(')==1 and 'set_block_num(T)' in orch
assert 'create_tensor' not in orch and 'ext_weight.reshape(weight_view_shapes, 2)' in orch
out={'pass':True,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'wide_lifetime_lines':[start+1,end+1],'wide_range':wide,'overlapping_writes_before_last_read':overlap,'ub_writer_end_bytes':40992,'writer_operations':writes,'rstd_range':[0,32],'single_spmd_kernel':True,'hardware_pass':False}
(job/'generated-review.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='writer_operations'},indent=2))
