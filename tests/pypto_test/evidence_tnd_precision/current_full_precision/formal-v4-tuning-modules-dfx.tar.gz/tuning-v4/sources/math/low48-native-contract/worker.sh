#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
python "$job/preflight.py"
python "$job/native_reference.py" --evidence "$base/precision-overnight-20261019/half-bf16-packet128-low48/results/v1/data/first-difference.pt" --reader "$HCPRE_READER" --out "$out/data" --first "${1:?}" --last "${2:?}"
