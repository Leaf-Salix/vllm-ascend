#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
: "${job:?source env.sh first}"
: "${out:?run.sh output required}"
python "$job/preflight.py" > "$out/preflight.log" 2>&1
python "$job/probe.py" --out "$out/data" --steps "${1:?}"
