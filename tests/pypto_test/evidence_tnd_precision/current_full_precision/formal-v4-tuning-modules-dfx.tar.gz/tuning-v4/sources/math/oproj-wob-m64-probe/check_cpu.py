"""实际WO-B候选AST：全T覆盖、K512顺序、尾部容量和INT32安全界。"""
import ast
import hashlib
import json
from pathlib import Path

import numpy as np

HERE=Path(__file__).resolve().parent
base_text=(HERE/'baseline_o_proj.py').read_text();text=(HERE/'candidate_o_proj.py').read_text()
start='    integer_accum =';tail='    for block in pl.spmd(row_tiles * 8, name_hint="oproj_b_dequant"):'
assert text[:text.index(start)]==base_text[:base_text.index(start)],'WO-A/quant changed'
assert text[text.index(tail):]==base_text[base_text.index(tail):],'dequant changed'

def body(text):
    fn=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef))
    first=next(i for i,n in enumerate(fn.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='integer_accum' for t in n.targets))
    last=next(i for i,n in enumerate(fn.body) if isinstance(n,ast.For) and isinstance(n.iter,ast.Call) and any(k.arg=='name_hint' and isinstance(k.value,ast.Constant) and k.value.value=='oproj_b_dequant' for k in n.iter.keywords))
    return fn.body[first:last]
old=body(base_text);new=body(text)
assert isinstance(new[1],ast.If)
assert ast.dump(ast.Module(body=old[1:],type_ignores=[]))==ast.dump(ast.Module(body=new[1].body,type_ignores=[])), 'short T arithmetic changed'

class GM:
    def __init__(self,shape):self.shape=shape;self.values={}
    def __setitem__(self,key,value):
        row,col=key;Trace.assemble(self,value,[row.start,col.start])
class Weight:
    def __getitem__(self,key):return key
class Trace:
    INT32='INT32';rows=0;wide=0;narrow=0
    min=staticmethod(min);max=staticmethod(max);range=staticmethod(range)
    @staticmethod
    def spmd(n,**kwargs):return range(n)
    @staticmethod
    def create_tensor(shape,dtype):
        assert dtype=='INT32'
        if shape[1]==4096:return GM(shape)
        assert shape==[16,128];Trace.narrow+=1
        return {'shape':shape,'sequence':[]}
    @staticmethod
    def slice(t,shape,offset,valid_shape):
        assert shape in ([16,512],[64,512])
        assert 0<valid_shape[0]<=shape[0] and valid_shape[1]==512
        assert 0<=offset[0] and offset[0]+valid_shape[0]<=Trace.rows
        assert offset[1]%512==0 and 0<=offset[1]<=7680
        return shape,offset,valid_shape
    @staticmethod
    def matmul(x,w,out_dtype):
        assert out_dtype=='INT32';Trace.wide+=1
        acc={'shape':[64,128],'sequence':[]}
        return Trace.matmul_acc(acc,x,w,True)
    @staticmethod
    def matmul_acc(acc,x,w,init_cond):
        shape,offset,valid=x
        assert acc['shape']==[shape[0],128]
        assert bool(init_cond)==(len(acc['sequence'])==0)
        assert w[0]==slice(offset[1],offset[1]+512) and w[1].stop-w[1].start==128
        if not acc['sequence']:acc['column']=w[1].start
        else:assert acc['column']==w[1].start
        acc['sequence'].append(offset[1]//512);acc['valid']=valid[0]
        return acc
    @staticmethod
    def assemble(gm,acc,offset):
        row,col=offset
        assert row+acc['shape'][0]<=gm.shape[0] and col==acc['column'] and col+128<=4096
        assert acc['sequence']==list(range(16))
        for real in range(row,row+acc['valid']):
            key=real,col//128;assert key not in gm.values
            gm.values[key]=acc['sequence'].copy()
        return gm

ns={'pl':Trace,'quantized':object(),'wo_b':Weight()}
for name,nodes in [('baseline',old),('candidate',new)]:
    fn=ast.FunctionDef(name=name,args=ast.arguments(posonlyargs=[],args=[ast.arg(arg='rows')],kwonlyargs=[],kw_defaults=[],defaults=[]),
        body=ast.parse('row_tiles=(rows+15)//16').body+nodes+[ast.Return(value=ast.Name(id='integer_accum',ctx=ast.Load()))],decorator_list=[])
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),'actual_WOB_AST','exec'),ns)
contexts=0
for rows in range(1,257):
    Trace.rows=rows;Trace.wide=Trace.narrow=0
    old_values=ns['baseline'](rows).values
    Trace.wide=Trace.narrow=0
    new_values=ns['candidate'](rows).values
    assert old_values==new_values and len(new_values)==rows*32
    if rows<=16:assert Trace.wide==0 and Trace.narrow==32
    else:assert Trace.wide==((rows+63)//64)*32 and Trace.narrow==0
    contexts+=len(new_values)
    assert ((rows+63)//64)*64<=rows+63
# Any exact partial dot, regardless of summation tree, is at most2^27 in magnitude.
assert 8192*128*128==2**27 and 2**27<2**31
rng=np.random.default_rng(202610190421)
integer_cases=0
for case in range(10):
    x=rng.integers(-128,128,(8,8192),dtype=np.int16).astype(np.int64)
    w=rng.integers(-128,128,(8192,8),dtype=np.int16).astype(np.int64)
    if case==0:x.fill(-128);w.fill(-128)
    elif case==1:x.fill(-128);w.fill(127)
    elif case==2:
        x.fill(-128);w[0::2].fill(-128);w[1::2].fill(127)
    accum=np.zeros((8,8),dtype=np.int64)
    for step in range(16):
        accum+=x[:,step*512:(step+1)*512]@w[step*512:(step+1)*512]
        assert np.abs(accum).max()<=((step+1)*512)*128*128
        assert np.array_equal(accum,accum.astype(np.int32).astype(np.int64))
    assert np.array_equal(accum,x@w);integer_cases+=64
result={'pass':True,'actual_WOB_AST_executed':True,'all_T1_to256':True,'real_row_column_contexts':contexts,
        'WOA_and_quant_prefix_byte_exact':True,'dequant_suffix_byte_exact':True,'short_T_WOB_loop_AST_unchanged':True,
        'unique_seed_16_K512_order_and_all_valid_outputs_once':True,'M64_physical_tail_rows_plus63_safe':True,
        'INT32_absolute_dot_bound':2**27,'INT32_exact_witness_outputs':integer_cases,
        'no_Native_INT32_hook_claimed':True,'hardware_executed':False,
        'candidate_sha256':hashlib.sha256(text.encode()).hexdigest()}
(HERE/'cpu-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
