"""No-device generation/CCEC only; record actual UB allocations for review."""
import hashlib
import json
from pathlib import Path

from pypto.runtime import RunConfig
from pypto.runtime.kernel_compiler import KernelCompiler
import baseline_norm
import candidate_norm

job=Path(__file__).resolve().parent
isa='/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/build/pto-isa'
results=[]
for name,module in [('baseline',baseline_norm),('candidate',candidate_norm)]:
    program=module.input_norm_test.compile(config=RunConfig(platform='a2a3'))
    files=sorted(p for p in Path(program.output_dir).rglob('*.cpp') if p.parent.name=='aiv')
    assert files,(name,program.output_dir)
    output=job/('precompile-'+name);output.mkdir(exist_ok=True)
    inventory=[]
    for path in files:
        source=path.read_text()
        binary=KernelCompiler('a2a3').compile_incore(str(path),core_type='aiv',pto_isa_root=isa,runtime_name='tensormap_and_ringbuffer',build_dir=str(output))
        (output/(path.stem+'.elf')).write_bytes(binary)
        inventory.append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'binary_bytes':len(binary),
                          'ub_lines':[line for line in source.splitlines() if any(marker in line for marker in ('TASSIGN','__ubuf__','ub_offset','UB_OFFSET'))]})
        print('NORM_CCEC_PASS',name,path.name,len(binary),flush=True)
    results.append({'name':name,'output_dir':str(program.output_dir),'kernels':inventory})
(job/'compile-result.json').write_text(json.dumps(results,indent=2)+'\n')
print('COMPILE_ONLY_NO_NPU: inspect candidate UB live ranges and 1-row fused task before hardware',flush=True)
