# 输入Norm单任务融合候选（2026-10-19）

- [x] 阅读冻结input_norm.py及已验收Native npu_rms_norm验证助手。
- [x] 只在reports创建baseline/candidate，保持原归约树、标量sqrt纠正/除法和BF16边界。
- [x] CPU AST核对数值子树、动态维及输出布局，估算UB并冻结SHA。
- [x] 准备无设备CCEC编译、生成代码UB/别名检查；由主线程决定执行。
- [x] 准备T6/144/240各独立任务计划，禁止本助手提交或占设备。
- [x] baseline/candidate/实际Native RMSNorm：A/B/A/zero/tiny/异方差，首差停止。
- [x] 真实L4权重，输出与rstd逐bit、8lane一致、poison恢复、guard及input/weight不变。
- [ ] 通过完整模块门禁后才讨论完整CSA/整模型，不修改生产或SDK。

- v5：将 weight 的纯 Tensor reshape 提到 SPMD 外，避免现有 Tensor→Tile pass 将 load 的首参数变成 Tile；仍读取相同 BF16 权重、相同 FP32 cast 与乘法顺序。v4 失败只涉及 IR 类型，不曾运行 NPU。
