# Input RMSNorm单任务融合草稿

## 状态和改动

只在reports准备候选，**未编译运行NPU、未修改生产或SDK**。
基准`baseline_norm.py`为当前完整精度版`input_norm.py`原字节。
Native参考是实际`torch_npu.npu_rms_norm(x, weight, 1e-6)`，
与`AscendRMSNorm.forward_oot`无residual、无bias路径一致，并实际返回rstd；
不是CPU拟合公式或另一个PTO实现。

候选将每行三个SPMD阶段合成一个任务：

1. 保留BF16→FP32 widening、逐项平方、半区间2048→1024→512→256→128→64折叠，
   仍将末64项复制到8×64，再使用同一个row_sum。
2. 删除8lane sums的中间GM写/读，直接读同一FP32结果的lane0。
   variance、epsilon、VSQRT候选、INT64中点比较纠正两次、标量除法原样保留。
3. 原FP32 wide保留到apply；仍先乘FP32 inverse，再乘FP32权重，最后一次BF16 RNE。
   从inverse的FP32 lane0读取缩放，与原rstd GM roundtrip值边界相同；
   rstd[T,8]仍写全部8个一致的lane。

CPU `verify_ast.py`已实际检查归约、纠正子树和最终乘法/舍入AST；
只改变三条数据边：删除sums GM；复用wide；读取inverse tile而非rstd GM。
它不等于NPU数值或性能验收。

## UB和别名风险

必须保留wide（16KiB）穿过全部scalar sqrt纠正循环，并在apply最后读取。
其后续显式SSA use使合法liveness分析不能把wide复用给square、折叠或scalar临时量；
但是否生成正确仍须检查代码。不得为降低峰值改归约树或使用向量rsqrt。

不计layout别名复用的粗略静态tile上限约120KiB：
wide16、square16、折叠约16、repeated/scratch4、原BF16输入8、
weight16、scaled16、result16、BF16输出8KiB及少量标量载体。
这是保守算术估计，不是编译器已确认UB峰值；slice可能零拷贝，反之自动拆分也可能增加临时量。
CCEC通过后仍需逐一核对：

- 只有每行一个fused任务，未引入隐式阶段GM或重复执行；
- wide所在物理UB区间在平方至apply之间没有写入复用；
- square/fold in-place可以发生，但不能覆盖仍活跃的wide；
- scalar循环期间big tile的寄存器/UB存活受编译器保护；
- 最终rstd写回不与外部output/input/weight别名。

`compile.py`会保存生成代码路径、SHA、CCEC二进制字节数及TASSIGN/UB线索。
若发现宽tile被复用或峰值超限，先停下；必要时显式tile copy，不能改数值顺序。

## 后续任务计划（由主线程安排，本目录不自动提交）

先无设备执行`bash compile.sh`，检查上述生成代码及CCEC。
然后T6、T144、T240各单独一个task-submit任务，max780秒，逐项通过再下一项。
不占用当前整模型或128K任务资源。

`run.sh <新标签> 6`（另两项为144、240）仅执行已分配任务，不会自行调用task-submit。
每项使用真实L4 HC-pre输出和原Norm权重，测试A/B/A、zero、极小±2^-70、
按行异方差输入（幅度2^-12至2^20）；baseline若先与Native不一致，也要停止定位。

每个phase三臂同输入，输出BF16和rstd对实际Native逐bit比较；
baseline/candidate的rstd8lane还要求完全相同。检查NaN poison恢复、输入/权重不变、
输出与rstd前后guard，以及timing后再次核验。保存每phase原始CPU见证。
精度全过后，8轮×100次raw graph交错正反计时；该数字仅为模块筛选，
不是npugraph_ex静态FULL服务或完整CSA/整模型收益。

冻结文件SHA见`manifest.json`；移至227新目录需同步修改env/compile/run中的job路径，
重新生成助手manifest并做预检，保留候选数学SHA。

## v3现有DSL类型修复

v2(数学文件SHA6ea58...)在无设备lower时发现`col_expand_mul(Tile,Tensor)`不被允许：保留的wide是Tile，原w表达式仍是Tensor。v3仅在weight reshape之后显式`pl.load`为1×4096 BF16 Tile，再执行原FP32 cast。两个乘法与BF16 RNE顺序不变；这是同值权重的数据读取/调度变化，不是更换RMSNorm公式。旧候选保存在failed/，verify_ast明确检查新增load以及不变的cast/最终算术，未改SDK。

## v4末尾Tile写回修复

v3显式load后继续lower，发现原Tensor形式的output[...]赋值不能接BF16 Tile。v4仅将同一个`cast(result,BF16,mode="rint")`用`pl.store(...,[row,0],output)`写回，舍入表达式和目标row保持不变。verify_ast分别锁定末两次乘法及同cast/地址的store；旧v3存于failed/。这仍是API层级/调度修复，没有改变算术或SDK。

- v5：将 weight 的纯 Tensor reshape 提到 SPMD 外，避免现有 Tensor→Tile pass 将 load 的首参数变成 Tile；仍读取相同 BF16 权重、相同 FP32 cast 与乘法顺序。v4 失败只涉及 IR 类型，不曾运行 NPU。
