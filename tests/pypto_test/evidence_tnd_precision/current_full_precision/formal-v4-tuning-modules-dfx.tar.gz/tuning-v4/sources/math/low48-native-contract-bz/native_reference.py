"""同一旧acc及八积：复用已编译Native HC-pre workspace观察器，不编译C++。

全部输入来自合成first-difference.pt。Native raw AB是参照，不预设整数金值
等于Native内部累加。覆盖新增16组的全部8步、T16和两个24列窗口，不将整数结果当Native金值。
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys
import numpy as np
import torch

HERE=Path(__file__).resolve().parent
F=np.float32

def cpu_cases(path, first=32, last=39):
    p=torch.load(path,map_location='cpu',weights_only=False)
    fx=p['fixture']; groups=len(p['tags'])
    x=fx['packed_x'].numpy().reshape(groups,8,16,16)[...,:8]
    wp=fx['packed_w'].numpy().reshape(groups,8,16,32)
    w=np.add(wp[:,:,:8],wp[:,:,8:],dtype=F)
    actual=p['actual'].numpy().reshape(groups,8,16,32)
    acc=np.add(np.add(fx['acc_hi'].numpy(),fx['acc_mid'].numpy(),dtype=F),fx['acc_lo'].numpy(),dtype=F).reshape(groups,16,32)
    sys.path.insert(0,str(HERE.parent/'half-bf16-packet128-low48'))
    from fixtures import rational_round,split_trunc
    cases=[]
    for group,step,start in [(g,s,c) for g in range(first,last+1) for s in range(8) for c in (0,8)]:
        columns=list(range(start,start+24))
        old=(actual[group,step-1] if step else acc[group])[:16,columns].copy()
        current=x[group,step,:16].copy(); weight=w[group,step,:,columns].T.copy()
        assert weight.shape==(8,24)
        hi,mid,lo=split_trunc(old)
        assert np.array_equal((hi.astype(np.float64)+mid.astype(np.float64)+lo.astype(np.float64)),old.astype(np.float64))
        flat=np.zeros((16,16384),dtype=F); fullweight=np.zeros((24,16384),dtype=F)
        # Three identity*BF16-piece blocks establish arbitrary16x24 oldacc.
        for block,piece in enumerate([hi,mid,lo]):
            flat[:,block*16:block*16+16]=np.eye(16,dtype=F)
            fullweight[:,block*16:block*16+16]=piece.T
        flat[:,48:56]=current; fullweight[:,48:56]=weight.T
        # Give each other split a positive norm workspace diagonal; weights0
        # means these sentinels contribute exactly0 to every rawAB partial.
        for split in range(22):flat[:,split*768+64]=1
        products=np.multiply(current[:,:,None],weight[None,:,:],dtype=F)
        gold=np.empty_like(old)
        for r in range(16):
            for c in range(24):
                terms=np.concatenate((old[r,c:c+1],products[r,:,c]))
                gold[r,c]=np.array(rational_round(terms.view(np.uint32)),dtype=np.uint32).view(F)
        cases.append({'group':group,'step':step,'tag':p['tags'][group],'flat':flat,'weight':fullweight,'old':old,'gold':gold,'bf16':actual[group,step,:16,columns].T.copy(),'columns':columns,'column_start':start})
        assert cases[-1]['bf16'].shape==(16,24)
    return cases

def metrics(a,b):
    a=np.ascontiguousarray(a);b=np.ascontiguousarray(b)
    mask=a.view(np.uint32)!=b.view(np.uint32)
    return {'different':int(mask.sum()),'bit_equal':not bool(mask.any()),'first':np.argwhere(mask)[:4].tolist(),'first_value':float(a.flat[0]),'first_bits':hex(int(a.view(np.uint32).flat[0]))}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--evidence',type=Path,default=HERE/'first-difference.pt');parser.add_argument('--out',type=Path,required=True);parser.add_argument('--reader',type=Path,required=True);parser.add_argument('--cpu-only',action='store_true');parser.add_argument('--first',type=int,required=True);parser.add_argument('--last',type=int,required=True);a=parser.parse_args();assert (a.first,a.last) in ((32,39),(40,47))
    cases=cpu_cases(a.evidence,a.first,a.last)
    if a.cpu_only:
        assert len(cases)==128
        print(json.dumps({'cases':len(cases),'unique_elements':8*8*16*32,'comparison_elements':len(cases)*16*24,'first':a.first,'last':a.last,'integer_different_with_window_overlap':sum(metrics(c['bf16'],c['gold'])['different'] for c in cases)},indent=2));return
    import torch_npu
    from vllm_ascend.utils import enable_custom_op
    assert os.environ.get('TASK_DEVICE'),'task-submit required'
    assert enable_custom_op();torch.npu.set_device(0);torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1)
    torch.ops.load_library(os.environ['HCPRE_BRIDGE'])
    spec=importlib.util.spec_from_file_location('frozen_reader',a.reader);reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
    a.out.mkdir(parents=True,exist_ok=False)
    report={'complete':False,'scope':'synthetic only; frozen installed Native observer; no model weights/new C++/SDK','cases':[],'first':a.first,'last':a.last,'unique_elements':8*8*16*32,'comparison_elements':len(cases)*16*24}
    def save():(a.out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
    save();device='npu'
    with torch.inference_mode():
        for c in cases:
            hidden=torch.from_numpy(c['flat'].copy()).reshape(16,4,4096).to(torch.bfloat16).to(device)
            fn=torch.from_numpy(c['weight'].copy()).to(device);scale=torch.ones(3,device=device,dtype=torch.float32);base=torch.zeros(24,device=device,dtype=torch.float32)
            assert torch.equal(hidden.cpu().float().reshape(16,16384),torch.from_numpy(c['flat']))
            args=(hidden,fn,scale,base,4,20,1e-6,1e-6)
            def reference():
                raw=torch.ops.dsv4_hcpre_observe17.forward(*args)
                torch.npu.synchronize()
                observed=reader.read_workspace(raw[3],hidden)
                assert (observed['header']['multCoreSplitKSize'],observed['header']['cubeBlockDimK'])==(768,22)
                return raw,observed['ab'][0].numpy().copy()
            # Verify arbitrary oldacc prefix before any new products.
            saved=fn[:,48:56].clone();fn[:,48:56].zero_();_,prefix=reference();fn[:,48:56].copy_(saved)
            assert metrics(prefix,c['old'])['bit_equal'], 'Native prefix initialization differs'
            raw,native=reference();raw2,repeated=reference()
            assert metrics(native,repeated)['bit_equal'],'Native observer repeat differs'
            direct=torch.ops._C_ascend.npu_hc_pre_v2(*args);torch.npu.synchronize()
            fidelity=[torch.equal(v.cpu().contiguous().view(torch.uint8),u.cpu().contiguous().view(torch.uint8)) for v,u in zip(raw[:3],direct)]
            assert all(fidelity),'observer changes Native visible outputs'
            record={'group':c['group'],'step':c['step'],'tag':c['tag'],'native_vs_integer':metrics(native,c['gold']),'native_vs_bf16':metrics(native,c['bf16']),'bf16_vs_integer':metrics(c['bf16'],c['gold']),'prefix_bit_equal':True,'native_repeat_bit_equal':True,'observer_fidelity':fidelity,'columns':c['columns'],'column_start':c['column_start']}
            report['cases'].append(record);torch.save({'native':torch.from_numpy(native),'integer':torch.from_numpy(c['gold']),'bf16':torch.from_numpy(c['bf16']),'oldacc':torch.from_numpy(c['old'])},a.out/f"group{c['group']}-step{c['step']}-col{c['column_start']}.pt");save()
            print('CASE',c['group'],c['step'],c['column_start'],record['native_vs_bf16']['different'],flush=True)
            assert record['native_vs_bf16']['bit_equal'],'FIRST_NATIVE_BF16_DIFFERENCE'
    report['complete']=True;report['pass']=all(r['native_vs_bf16']['bit_equal'] for r in report['cases']);save()

if __name__=='__main__':main()
