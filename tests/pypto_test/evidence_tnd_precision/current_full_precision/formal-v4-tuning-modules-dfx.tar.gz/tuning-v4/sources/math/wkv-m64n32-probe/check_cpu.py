"""执行实际候选AST，检查校准order、唯一初始化、K256和store/tail。"""
import ast
import hashlib
import json
from pathlib import Path
import runpy

import numpy as np

HERE = Path(__file__).resolve().parent
PACKAGE = HERE.parents[3] / 'vllm-ascend-nalinaly-tnd-20261008-codex/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision'
base = ast.parse((HERE/'baseline_wkv.py').read_text())
candidate = ast.parse((HERE/'candidate_wkv.py').read_text())
old = next(n for n in base.body if isinstance(n,ast.FunctionDef))
small = next(n for n in candidate.body if isinstance(n,ast.FunctionDef) and n.name=='_wkv16_body')
assert ast.dump(ast.Module(body=old.body,type_ignores=[])) == ast.dump(ast.Module(body=small.body,type_ignores=[]))

class Tensor:
    def __init__(self,shape):self.shape=shape;self.values={}
    def bind_dynamic(self,*args):pass
    def __setitem__(self,key,value):
        row,col=key;Trace.assemble(self,value,[row.start,col.start])
class Weight:
    def __getitem__(self,key):return key
class Trace:
    FP32='FP32';BF16='BF16';rows=0;wide=0;narrow=0;n32=0;n16=0
    range=staticmethod(range);min=staticmethod(min);max=staticmethod(max)
    @staticmethod
    def spmd(n,**kwargs):return range(n)
    @staticmethod
    def read(t,index):return int(t[tuple(index)])
    class tensor:
        @staticmethod
        def dim(t,axis):return t.shape[axis]
    @staticmethod
    def create_tensor(shape,dtype):
        assert dtype=='FP32'
        if shape[-1]==512:return Tensor(shape)
        assert shape==[16,16];Trace.narrow+=1
        return {'shape':shape,'sequence':[],'valid':16}
    @staticmethod
    def slice(t,shape,offset,valid_shape):
        assert shape[0] in (16,64) and shape[1]==256
        assert 0<valid_shape[0]<=shape[0] and valid_shape[1]==256
        assert 0<=offset[0] and offset[0]+valid_shape[0]<=Trace.rows
        assert 0<=offset[1] and offset[1]+256<=4096
        return shape,offset,valid_shape
    @staticmethod
    def matmul(a,b,b_trans,out_dtype):
        assert out_dtype=='FP32' and b_trans
        Trace.wide+=1
        columns=b[0].stop-b[0].start
        assert columns in (16,32)
        if columns==32:Trace.n32+=1
        else:Trace.n16+=1
        acc={'shape':[64,columns],'sequence':[],'valid':a[2][0]}
        return Trace.matmul_acc(acc,a,b,True,True)
    @staticmethod
    def matmul_acc(acc,a,b,b_trans,init_cond):
        shape,offset,valid=a
        assert b_trans and acc['shape'][0]==shape[0]
        assert bool(init_cond)==(len(acc['sequence'])==0)
        assert b[0].stop-b[0].start==acc['shape'][1] and b[1]==slice(offset[1],offset[1]+256)
        if not acc['sequence']:acc['weight_group']=b[0].start//16
        else:assert acc['weight_group']==b[0].start//16
        acc['sequence'].append(offset[1]//256);acc['valid']=valid[0]
        return acc
    @staticmethod
    def assemble(t,acc,offset):
        row,col=offset;size=acc['shape'][0]
        assert row+size<=t.shape[0] and col+acc['shape'][1]<=512
        assert acc['weight_group']==col//16
        assert len(acc['sequence'])==16
        for ri in range(row,row+acc['valid']):
            for group in range(col//16,(col+acc['shape'][1])//16):
                key=(ri,group);assert key not in t.values
                t.values[key]=acc['sequence'].copy()
        return t
    @staticmethod
    def load(t,offset,shape,valid_shape):
        assert shape==[16,512] and 0<valid_shape[0]<=16 and valid_shape[1]==512
        assert offset[0]+valid_shape[0]<=Trace.rows
        return t,offset,shape,valid_shape
    @staticmethod
    def cast(v,dtype,mode):assert dtype=='BF16' and mode=='rint';return v
    @staticmethod
    def store(v,offset,out):
        gm,src,shape,valid=v;assert offset==src
        for row in range(offset[0],offset[0]+valid[0]):
            for group in range(32):
                assert (row,group) not in out.values
                out.values[row,group]=gm.values[row,group]

def executable(tree):
    functions=[]
    for node in tree.body:
        if not isinstance(node,ast.FunctionDef):continue
        node.returns=None;node.decorator_list=[]
        for arg in node.args.args:arg.annotation=None
        functions.append(node)
    return compile(ast.fix_missing_locations(ast.Module(body=functions,type_ignores=[])),'actual_WKV_AST','exec')
ns={'pl':Trace,'T':None};exec(executable(candidate),ns)
ns['wkv16_entry']=ns['_wkv16_body'];ns['wkv64_entry']=ns['_wkv64_body']
base_ns={'pl':Trace,'T':None};exec(executable(base),base_ns)
data=runpy.run_path(str(PACKAGE/'wkv_order_data.py'))
contexts=0;cases=0

def verify(rows,order):
    global contexts,cases
    Trace.rows=rows;Trace.wide=Trace.narrow=Trace.n32=Trace.n16=0
    output=Tensor([rows,512]);ns['_wkv_test'](Tensor([rows,4096]),Weight(),order,output)
    assert len(output.values)==rows*32
    for (row,group),sequence in output.values.items():
        assert sequence==[max(int(k),0) for k in order[group]]
    if rows<=16:assert Trace.wide==0 and Trace.narrow==32
    else:
        panels=(rows+63)//64
        equal_pairs=sum(np.array_equal(order[2*p],order[2*p+1]) for p in range(16))
        assert Trace.narrow==0 and Trace.n32==panels*equal_pairs
        assert Trace.n16==panels*2*(16-equal_pairs)
        assert Trace.wide==Trace.n32+Trace.n16
    contexts+=len(output.values);cases+=1

for rows in range(1,257):
    mode=data['WKV_TOKEN_MODES'][rows-1]
    if rows==6:mode=1 # qualified static profile override
    order=np.array([data['WKV_K_ORDERS'][k] for k in data['WKV_COLUMN_ORDERS'][mode]],dtype=np.int32)
    assert all(sorted(row.tolist())==list(range(16)) for row in order)
    verify(rows,order)
# Every calibration mode at both sides of dispatch and all important tail edges.
for mapping in data['WKV_COLUMN_ORDERS']:
    order=np.array([data['WKV_K_ORDERS'][k] for k in mapping],dtype=np.int32)
    for rows in (1,6,16,17,63,64,65,127,128,129,144,240,255,256):verify(rows,order)
rng=np.random.default_rng(202610190364)
for rows in (6,17,64,65,144,240,256):
    order=np.stack([rng.permutation(16) for _ in range(32)]).astype(np.int32);verify(rows,order)
    negative=np.full((32,16),-1,dtype=np.int32);verify(rows,negative)
# Each pair and each one of the16 raw guard positions alone differs.
for pair in range(16):
    for step in range(16):
        order=np.tile(np.arange(16,dtype=np.int32),(32,1))
        order[pair*2+1,step]=(order[pair*2+1,step]+1)%16
        verify(64,order)
        assert Trace.n32==15 and Trace.n16==2
# Raw-unequal negative inputs clamp identically but must still take fallback.
order=np.full((32,16),-1,dtype=np.int32);order[1::2]=-2
verify(65,order);assert Trace.n32==0 and Trace.n16==64
result={'pass':True,'actual_candidate_AST_executed':True,'original_small_helper_body_AST_unchanged':True,
        'formal_T1_to_256_with_profile_T6_override':True,'all_9_calibrated_column_mappings':True,
        'cases':cases,'token_group_contexts':contexts,'unique_seed_and_16_K256_steps':True,
        'T_le_16_only_original_M16':True,'T_gt_16_M64N32_only_if_all_16_raw_orders_equal_else_M64N16':True,'every_pair_every_guard_step_individually_checked':True,'raw_unequal_negative_conservatively_falls_back':True,'internal_affine_rows_plus63_capacity_safe':True,'real_rows_once_and_physical_store_bounds':True,
        'random_group_permutations_and_negative_clamp':True,'hardware_executed':False,
        'candidate_sha256':hashlib.sha256((HERE/'candidate_wkv.py').read_bytes()).hexdigest()}
(HERE/'cpu-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
