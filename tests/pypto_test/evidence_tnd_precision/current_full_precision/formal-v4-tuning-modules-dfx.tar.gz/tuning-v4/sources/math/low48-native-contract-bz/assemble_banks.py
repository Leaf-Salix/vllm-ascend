"""仅由独立Native观察器原始张量合并A/B/zero银行，绑定原始输入。"""
import hashlib
import json
from pathlib import Path
import torch
P=Path(__file__).resolve().parent;R=P.parent
OBS='c2915e7e30f2686061dd082dd93d06fa240eff6007014cdee0c43a419472a7db'
summary={};bundle={'provenance':{'observer_sha256':OBS,'complete':True,'phases_complete':['A','B','zero'],'hardware_tasks':['task_20261019_032825_348135622422','task_20261019_032959_357888415313','task_20261019_033724_394318118372','task_20261019_033825_400174923503','task_20261019_033940_405985811750','task_20261019_034023_409483130020'],'scope':'new16 groups32..47, all8steps16x32; frozen Native rawAB with percase prefix/repeat/fidelity/guards; no self-sequential gold'},'phases':{}}
for phase in ('A','B','zero'):
 data=R/'low48-first-difference/first-difference.pt' if phase=='A' else R/f'low48-seq-capture/results/v1/data/capture-{phase}.pt'
 src=torch.load(data,map_location='cpu',weights_only=False)
 bank=torch.empty((16,8,16,32),dtype=torch.float32);old=torch.empty_like(bank);bf=torch.empty_like(bank)
 records=[]
 for lo,hi in ((32,39),(40,47)):
  if phase=='A':d=R/f'low48-native-contract/results/group{lo}-{hi}-v1/data'
  else:d=P/f'results/{phase}-{lo}-{hi}-v1/data'
  r=json.loads((d/'result.json').read_text());assert r['complete'] and r['pass'] and len(r['cases'])==128
  assert all(c['prefix_bit_equal'] and c['native_repeat_bit_equal'] and all(c['observer_fidelity']) and c['native_vs_bf16']['bit_equal'] for c in r['cases'])
  for g in range(lo,hi+1):
   for step in range(8):
    a=torch.load(d/f'group{g}-step{step}-col0.pt',map_location='cpu',weights_only=True)
    b=torch.load(d/f'group{g}-step{step}-col8.pt',map_location='cpu',weights_only=True)
    for name,target in (('native',bank),('bf16',bf),('oldacc',old)):
     assert torch.equal(a[name][:,8:].view(torch.int32),b[name][:,:16].view(torch.int32)),(phase,g,step,name,'overlap')
     target[g-32,step]=torch.cat((a[name][:,:8],b[name]),dim=1)
  records.append({'label':d.parent.name,'result_sha256':hashlib.sha256((d/'result.json').read_bytes()).hexdigest()})
 assert torch.equal(bank.view(torch.int32),bf.view(torch.int32))
 assert torch.equal(bank[:,:-1].view(torch.int32),old[:,1:].view(torch.int32)),(phase,'step induction')
 input_sha={n:hashlib.sha256(t.contiguous().numpy().tobytes()).hexdigest() for n,t in src['fixture'].items()}
 bundle['phases'][phase]={'complete':True,'groups':list(range(32,48)),'native_trajectory':bank,'native_final':bank[:,-1].clone(),'input_sha256':input_sha,'native_batches':records}
 summary[phase]={'unique_elements':bank.numel(),'native_bf16_different':0,'overlap_exact':True,'oldacc_induction_exact':True,'native_batches':records}
output=R/'half-bf16-packet128-native-contract/native-banks.pt';torch.save(bundle,output)
summary['bundle_sha256']=hashlib.sha256(output.read_bytes()).hexdigest()
(P/'banks-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
