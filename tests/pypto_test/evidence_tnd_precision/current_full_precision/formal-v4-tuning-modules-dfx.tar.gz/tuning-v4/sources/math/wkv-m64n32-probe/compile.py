"""无设备先检查独立wide root，再dispatch及基准，执行真实CCEC。"""
import argparse
import json
from pathlib import Path

from pypto.runtime import RunConfig
from pypto.runtime.kernel_compiler import KernelCompiler
from baseline_wkv import wkv_test as baseline
from candidate_wkv import wkv64_test, wkv_test

HERE = Path(__file__).resolve().parent
ISA = '/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/build/pto-isa'
parser = argparse.ArgumentParser()
parser.add_argument('--roots', nargs='+', choices=('wide', 'dispatch', 'baseline'), default=['wide', 'dispatch', 'baseline'])
args = parser.parse_args()
roots = {'wide': wkv64_test, 'dispatch': wkv_test, 'baseline': baseline}
results = []
for name in args.roots:
    program = roots[name].compile(config=RunConfig(platform='a2a3'))
    print('WKV_M64_GENERATED', name, program.output_dir, flush=True)
    sources = [q for q in Path(program.output_dir).glob('kernels/*/*.cpp') if q.parent.name in ('aic', 'aiv')]
    assert sources, (name, program.output_dir)
    kernels = []
    for source in sources:
        core = source.parent.name
        build = HERE / ('precompile-' + name) / core
        build.mkdir(parents=True, exist_ok=True)
        binary = KernelCompiler('a2a3').compile_incore(str(source), core_type=core, pto_isa_root=ISA,
            runtime_name='tensormap_and_ringbuffer', build_dir=str(build))
        (build / (source.stem + '.elf')).write_bytes(binary)
        print('WKV_M64_CCEC_PASS', name, core, source.name, len(binary), flush=True)
        kernels.append({'core': core, 'source': str(source), 'bytes': len(binary)})
    results.append({'root': name, 'output_dir': str(program.output_dir), 'kernels': kernels})
(HERE / ('compile-' + '-'.join(args.roots) + '.json')).write_text(json.dumps({'hardware_executed': False, 'results': results}, indent=2) + '\n')
