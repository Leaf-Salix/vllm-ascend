#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
: "${job:?source env.sh first}"
: "${out:?run.sh output required}"
python "$job/preflight.py" > "$out/preflight.log" 2>&1
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out/opp_env")
python "$job/probe.py" --out "$out/data" --tokens "${1:?}" "${@:2}"
