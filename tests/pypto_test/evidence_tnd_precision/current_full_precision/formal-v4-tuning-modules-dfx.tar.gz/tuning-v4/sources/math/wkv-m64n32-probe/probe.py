"""真实L4 normed和WKV权重：Native F.linear、原M16、M64首差即停。"""
import argparse
import contextlib
import hashlib
import json
import os
from pathlib import Path
import statistics
import time

import torch
import torch_npu
import pypto.torch
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from vllm_ascend.utils import enable_custom_op
from dsv4_csa_single_layer import make_layer
from dsv4_csa_native_case import native_session

import baseline_wkv
import candidate_wkv

BASE = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
META_SHA = '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
FIXTURE_SHA = '5b873509016a7419abf5639a808da58950eb2d3d3bd332c00ed8625e00174481'
parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--tokens', type=int, choices=(6, 144, 240), required=True)
parser.add_argument('--device', type=int)
parser.add_argument('--timing-rounds', type=int, default=0)
parser.add_argument('--timing-iters', type=int, default=10)
args = parser.parse_args()
assert 0 <= args.timing_rounds <= 20 and 1 <= args.timing_iters <= 100
args.out.mkdir()
started = time.monotonic()
report = {'pass': False, 'complete': False, 'layer': 4, 'tokens': args.tokens,
          'scope': 'same real L4 weights and saved normed; Native F.linear vs qualified M64 vs guarded M64N32 WKV, not full CSA or whole-model acceptance',
          'task_device': os.environ['TASK_DEVICE'], 'comparisons': [], 'timings': [], 'completed_phases': []}
x = None


def save():
    (args.out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')


def host(value):
    torch.npu.synchronize()
    if value.device.type != 'cpu' and torch_npu.get_npu_format(value) not in (0, 2):
        value = torch_npu.npu_format_cast(value, 2)
    return value.detach().cpu().contiguous()


def tensor_sha(value):
    return hashlib.sha256(host(value).view(torch.uint8).numpy().tobytes()).hexdigest()


def check(label, actual, expected):
    actual, expected = host(actual), host(expected)
    assert actual.shape == expected.shape and actual.dtype == expected.dtype, label
    if expected.is_floating_point():
        assert bool(torch.isfinite(expected).all()), label + ' reference nonfinite'
    bits_type = {1: torch.int8, 2: torch.int16, 4: torch.int32}[actual.element_size()]
    diff = actual.view(bits_type) != expected.view(bits_type)
    result = {'label': label, 'bit_equal': not bool(diff.any()), 'different_elements': int(diff.sum()),
              'max_abs': float((actual.float() - expected.float()).abs().max()),
              'first_coordinates': diff.nonzero()[:8].tolist()}
    if actual.is_floating_point() and not bool(torch.isfinite(actual).all()):
        result['nonfinite_actual_elements'] = int((~torch.isfinite(actual)).sum())
        result['max_abs'] = 'nonfinite'
    report['comparisons'].append(result)
    save()
    if not result['bit_equal']:
        result['first_values'] = [{'index': index, 'actual': str(actual[tuple(index)].item()),
                                   'expected': expected[tuple(index)].item()} for index in result['first_coordinates']]
        save()
        torch.save({'stage': label, 'input': host(x) if x is not None else None,
                    'actual': actual, 'expected': expected}, args.out / 'first-difference.pt')
        raise RuntimeError('FIRST_BIT_DIFFERENCE ' + label)


def check_time():
    assert time.monotonic() - started < 690, 'Split remaining cases into another <=15 minute task'


torch.npu.set_device(0)
torch.npu.config.allow_internal_format = True
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
current_platform.pre_register_and_update()
assert enable_custom_op()
checkpoint = Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config = EngineArgs(model=str(checkpoint), tokenizer_mode='deepseek_v4', trust_remote_code=True,
    tensor_parallel_size=1, dtype='bfloat16', quantization='ascend', hf_overrides={'sliding_window':128},
    max_model_len=16384, max_num_seqs=40, max_num_batched_tokens=256, enable_prefix_caching=False,
    enforce_eager=False, block_size=32,
    speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},
    additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,
        'fuse_norm_quant':True,'align_decode_capture_sizes':False},'enable_cpu_binding':False,
        'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()

save()
stack = contextlib.ExitStack()
try:
    stack.enter_context(native_session(config, 0))
    with torch.inference_mode():
        pypto.torch.init(device=0, platform='a2a3', runtime='tensormap_and_ringbuffer')
        layer, details = make_layer(config, checkpoint, torch.device('npu:0'), 4)
        report['weight_details'] = details
        impl = layer.self_attn.dsa_attn.dsa_attn.impl
        fixture_dir = Path('/data/pyptouser/yejia/lc128/retest192-native2-b24000/full-probe')
        fixture_path = fixture_dir / 'step074.pt'
        assert hashlib.sha256(fixture_path.read_bytes()).hexdigest() == FIXTURE_SHA
        fixture = torch.load(fixture_path, map_location='cpu', weights_only=True)[4]
        stage_record = json.loads((fixture_dir / 'stages.jsonl').read_text().splitlines()[74])['layers']['4']
        assert tensor_sha(fixture['normed']) == stage_record['normed']['sha256']
        real_input = fixture['normed'].reshape(6, 4096)
        assert real_input.dtype == torch.bfloat16 and bool(torch.isfinite(real_input).all())
        report['fixture'] = {'path': str(fixture_path), 'sha256': FIXTURE_SHA, 'layer': 4,
                             'saved_normed_sha256': stage_record['normed']['sha256'],
                             'scope': 'existing real-model Native normed input; no new Native2 run'}
        torch.npu.set_compile_mode(jit_compile=False)
        from npugraph_ex._acl_concrete_graph import static_kernel
        static_kernel.compile_static_kernel(lambda: None)
        assert len(static_kernel._installed_run_pkgs) == 13
        meta = Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE']) / 'metadata.json'
        assert hashlib.sha256(meta.read_bytes()).hexdigest() == META_SHA
        report['static'] = {'installed_packages': 13, 'metadata_sha256': META_SHA}
        native_weight = impl.wkv.weight.detach()
        assert native_weight.dtype == torch.bfloat16 and list(native_weight.shape) == [512, 4096]
        assert impl.wkv.bias is None
        weight = torch_npu.npu_format_cast(native_weight, 2).contiguous()
        check('weight_layout_values_only', weight, native_weight)
        weight_hashes = [tensor_sha(native_weight), tensor_sha(weight)]
        report['weight_hashes'] = weight_hashes
        report['weight_format'] = int(torch_npu.get_npu_format(native_weight))
        from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv_profile import WKVProfile
        from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv_order_data import (
            WKV_TOKEN_MODES, WKV_COLUMN_ORDERS, WKV_K_ORDERS, NATIVE_ORDER_MAP_SHA256,
        )
        profile = WKVProfile()
        assert profile.select(6, WKV_TOKEN_MODES, capturing=False, static_requested=True) == WKV_TOKEN_MODES[5]
        profile.qualify_static(metadata_sha256=META_SHA, reselected=True)
        mode = profile.select(args.tokens, WKV_TOKEN_MODES, capturing=True, static_requested=True)
        assert mode == (1 if args.tokens == 6 else WKV_TOKEN_MODES[args.tokens - 1])
        order_cpu = torch.tensor([WKV_K_ORDERS[k] for k in WKV_COLUMN_ORDERS[mode]], dtype=torch.int32)
        assert list(order_cpu.shape) == [32, 16]
        assert all(sorted(row.tolist()) == list(range(16)) for row in order_cpu)
        order = order_cpu.to('npu')
        report['same_raw_order_pairs'] = sum(torch.equal(order_cpu[i], order_cpu[i + 1]) for i in range(0, 32, 2))
        report['order'] = {'mode': mode, 'static_T6_override': args.tokens == 6,
                           'native_order_map_sha256': NATIVE_ORDER_MAP_SHA256,
                           'table_sha256': tensor_sha(order_cpu), 'groups': order_cpu.tolist()}
        ops = {name: pypto.torch.register(module.wkv_test, 'precision_wkv_m64n32_20261019::' + name)
               for name, module in (('baseline', baseline_wkv), ('candidate', candidate_wkv))}
        report['source_hashes'] = {name: hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()
                                  for name, module in (('baseline', baseline_wkv), ('candidate', candidate_wkv))}

        def alloc(rows, columns):
            owner = torch.full((rows + 16, columns), 0.0625, dtype=torch.bfloat16, device='npu')
            return owner, owner[8:-8]

        def guards(label, owner):
            edges = torch.cat((host(owner[:8]), host(owner[-8:])))
            check(label + '_guard', edges, torch.full_like(edges, 0.0625))

        rows = args.tokens
        initial = real_input.repeat(((rows + 5) // 6, 1))[:rows].clone()
        input_owner, x = alloc(rows, 4096)
        x.copy_(initial.to('npu'))
        owners, outputs, graphs = {}, {}, {}
        for name in ops:
            owners[name], outputs[name] = alloc(rows, 512)

        def native():
            return torch.nn.functional.linear(x, native_weight)

        def call(name):
            ops[name](x, weight, order, outputs[name])

        def qualify_input(label, value):
            x.copy_(value.to('npu'))
            gold = host(native())
            check(label + '_Native_repeat', native(), gold)
            return gold

        gold_a = qualify_input('A', initial)
        for name in ops:
            outputs[name].fill_(float('nan'))
            call(name)
            check('eager_A_' + name, outputs[name], gold_a)
            guards('eager_A_' + name, owners[name])
            graph = torch.npu.NPUGraph()
            with torch.npu.graph(graph):
                call(name)
            graphs[name] = graph
        native_graph = torch.npu.NPUGraph()
        with torch.npu.graph(native_graph):
            native_graph_output = native()
        graphs['native'] = native_graph

        phases = (('A', initial), ('B', torch.roll(initial, 1, 1)), ('A_restored', initial),
                  ('zero', torch.zeros_like(initial)), ('tiny', initial * 2**-40), ('small', initial * 2**-20))
        for phase, value in phases:
            check_time()
            gold = qualify_input(phase, value)
            if phase == 'B':
                assert not torch.equal(gold, gold_a), 'Native B must change the output'
            native_graph_output.fill_(float('nan'))
            native_graph.replay()
            check(phase + '_Native_graph', native_graph_output, gold)
            for name in ops:
                outputs[name].fill_(float('nan'))
                call(name)
                check(phase + '_eager_' + name, outputs[name], gold)
                outputs[name].fill_(float('nan'))
                graphs[name].replay()
                check(phase + '_graph_' + name, outputs[name], gold)
                guards(phase + '_' + name, owners[name])
            check(phase + '_candidate_vs_baseline', outputs['candidate'], outputs['baseline'])
            check(phase + '_input_unchanged', x, value)
            check(phase + '_order_unchanged', order, order_cpu)
            guards(phase + '_input', input_owner)
            assert weight_hashes == [tensor_sha(native_weight), tensor_sha(weight)]
            report['completed_phases'].append(phase)
            save()

        # Non-Native order is tested only against the qualified M64 PTO root.
        forced_order = order_cpu.clone()
        forced_order[1::2] = order_cpu[0::2]
        forced_order[1::2, 0], forced_order[1::2, 1] = order_cpu[0::2, 1], order_cpu[0::2, 0]
        assert all(not torch.equal(forced_order[i], forced_order[i + 1]) for i in range(0, 32, 2))
        report['forced_unequal_pair_count'] = 16
        assert not torch.equal(forced_order, order_cpu)
        order.copy_(forced_order.to('npu'))
        for phase, value in phases[:3]:
            check_time()
            x.copy_(value.to('npu'))
            outputs['baseline'].fill_(float('nan'))
            call('baseline')
            gold = host(outputs['baseline'])
            outputs['baseline'].fill_(float('nan'))
            graphs['baseline'].replay()
            check('forced_' + phase + '_baseline_graph', outputs['baseline'], gold)
            outputs['candidate'].fill_(float('nan'))
            call('candidate')
            check('forced_' + phase + '_candidate_eager', outputs['candidate'], gold)
            outputs['candidate'].fill_(float('nan'))
            graphs['candidate'].replay()
            check('forced_' + phase + '_candidate_graph', outputs['candidate'], gold)
            check('forced_' + phase + '_input', x, value)
            check('forced_' + phase + '_order', order, forced_order)
            guards('forced_' + phase + '_input', input_owner)
            for name in ops:
                guards('forced_' + phase + '_' + name, owners[name])
        order.copy_(order_cpu.to('npu'))
        x.copy_(initial.to('npu'))
        native_graph.replay()
        check('restore_Native_graph', native_graph_output, gold_a)
        for name in ops:
            outputs[name].fill_(float('nan'))
            graphs[name].replay()
            check('restore_' + name, outputs[name], gold_a)
        if args.timing_rounds:
            timing = {name: [] for name in graphs}
            for repeat in range(args.timing_rounds):
                check_time()
                names = list(graphs) if repeat % 2 == 0 else list(reversed(graphs))
                for name in names:
                    begin, end = torch.npu.Event(enable_timing=True), torch.npu.Event(enable_timing=True)
                    begin.record()
                    for _ in range(args.timing_iters):
                        graphs[name].replay()
                    end.record(); end.synchronize()
                    timing[name].append(begin.elapsed_time(end) * 1000 / args.timing_iters)
            report['timings'] = {'unit': 'us/raw graph, no DFX, Native F.linear graph has no extra output copy',
                'samples': timing, 'summary': {k: {'min': min(v), 'mean': statistics.mean(v), 'max': max(v)} for k, v in timing.items()}}
            for name in ops:
                graphs[name].replay()
                check('post_timing_' + name, outputs[name], gold_a)
                guards('post_timing_' + name, owners[name])
            native_graph.replay()
            check('post_timing_Native', native_graph_output, gold_a)
        check('final_input', x, initial)
        check('final_order', order, order_cpu)
        guards('final_input', input_owner)
        assert weight_hashes == [tensor_sha(native_weight), tensor_sha(weight)]
        report['pass'] = report['complete'] = True
        save()
except Exception as exc:
    report['error'] = repr(exc)
    save()
    raise
finally:
    stack.close()
