"""BF16交错K16是否复现HF32 exact8；仅generic硬件契约探针。"""
import pypto.language as pl

ROWS = pl.dynamic('BF16_EXACT8_ROWS')
PACKED_ROWS = pl.dynamic('BF16_EXACT8_PACKED_ROWS')


def _prefix(
    identity: pl.Tensor[[16, 16], pl.BF16],
    acc_hi: pl.Tensor[[ROWS, 32], pl.BF16],
    acc_mid: pl.Tensor[[ROWS, 32], pl.BF16],
    acc_lo: pl.Tensor[[ROWS, 32], pl.BF16],
    output: pl.Out[pl.Tensor[[ROWS, 32], pl.FP32]],
):
    rows = pl.tensor.dim(acc_hi, 0)
    for group in pl.spmd(rows // 16, name_hint='bf16_prefix'):
        row = group * 16
        eye = pl.slice(identity, [16, 16], [0, 0])
        hi = pl.slice(acc_hi, [16, 32], [row, 0])
        mid = pl.slice(acc_mid, [16, 32], [row, 0])
        lo = pl.slice(acc_lo, [16, 32], [row, 0])
        acc = pl.matmul(eye, hi, out_dtype=pl.FP32)
        acc = pl.matmul_acc(acc, eye, mid)
        acc = pl.matmul_acc(acc, eye, lo)
        output = pl.assemble(output, acc, [row, 0])
    return output


def _interleaved(
    identity: pl.Tensor[[16, 16], pl.BF16],
    acc_hi: pl.Tensor[[ROWS, 32], pl.BF16],
    acc_mid: pl.Tensor[[ROWS, 32], pl.BF16],
    acc_lo: pl.Tensor[[ROWS, 32], pl.BF16],
    packed_x: pl.Tensor[[PACKED_ROWS, 16], pl.BF16],
    packed_w: pl.Tensor[[PACKED_ROWS, 32], pl.BF16],
    prefix_output: pl.Out[pl.Tensor[[ROWS, 32], pl.FP32]],
    trajectory: pl.Out[pl.Tensor[[PACKED_ROWS, 32], pl.FP32]],
):
    rows = pl.tensor.dim(acc_hi, 0)
    packed_rows = pl.tensor.dim(packed_x, 0)
    steps = packed_rows // rows
    for group in pl.spmd(rows // 16, name_hint='bf16_interleaved_dot8'):
        row = group * 16
        eye = pl.slice(identity, [16, 16], [0, 0])
        hi = pl.slice(acc_hi, [16, 32], [row, 0])
        mid = pl.slice(acc_mid, [16, 32], [row, 0])
        lo = pl.slice(acc_lo, [16, 32], [row, 0])
        acc = pl.matmul(eye, hi, out_dtype=pl.FP32)
        acc = pl.matmul_acc(acc, eye, mid)
        acc = pl.matmul_acc(acc, eye, lo)
        prefix_output = pl.assemble(prefix_output, acc, [row, 0])
        for step in pl.range(steps):
            packed_row = (group * steps + step) * 16
            x = pl.slice(packed_x, [16, 16], [packed_row, 0])
            w = pl.slice(packed_w, [16, 32], [packed_row, 0])
            acc = pl.matmul_acc(acc, x, w, init_cond=False)
            trajectory = pl.assemble(trajectory, acc, [packed_row, 0])
    return prefix_output, trajectory


prefix = pl.jit(_prefix)
interleaved = pl.jit(_interleaved)
