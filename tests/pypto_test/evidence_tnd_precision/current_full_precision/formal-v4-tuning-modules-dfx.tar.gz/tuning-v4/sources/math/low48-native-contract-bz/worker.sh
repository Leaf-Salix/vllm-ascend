#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
python "$job/preflight.py"
python "$job/native_reference.py" --evidence "$base/precision-overnight-20261019/low48-seq-capture/results/v1/data/capture-${3:?}.pt" --reader "$HCPRE_READER" --out "$out/data" --first "${1:?}" --last "${2:?}"
