# WKV M64N32相邻列组合并候选

## 基准与范围

基准为已通过真实L4 T6/T144/T240 Native逐bit强门禁的M64，SHA `2822ae86cab33504546b3f962084eab122b8c227fe9c42dd46357a5c5c80f6a0`；候选SHA `4fe20a68a9f695777f5e15bf90388049c76416046e72679353dadfbf3dc41b80`。仅为独立实验，不加入当前CSA组合，不改正式源码或SDK。

T≤16保留原M16 helper，body AST不变。T>16每个M64 panel按16对相邻N16列组分工。对每pair的全部16个原始INT32 order做Scalar相等检查；完全相同才做M64N32点积，否则逐组执行两个原M64N16点积。对raw不同、clamp后相同的负K值也保守回退；不使用INT32向量LT/GT。

每个分支均由一个无条件首K256 matmul建立自己的accumulator，后15次matmul_acc(initfalse)严格按原group次序，分支内直接assemble到GM accum，没有在分支外合并不同seed的L0C tile。最终仍沿原M16×512规则RNE成BF16。

## Affine容量变更

内部FP32 accum同时供N32和N16回退，改为`[rows+63,512]`，避免内联整根后ceil64不可逆shape recovery；`ceil(rows/64)*64≤rows+63`。这只增加容量，不改变列stride、实际store或公开真实T。最多额外63×512×4=126KiB GM，属于该helper原生命周期，UB/L0C不因此增加。T240额外47行=94KiB。

M64N32单步BF16 A64×256=32KiB、B32×256=16KiB，FP32 C64×32=8KiB；比N16多B及C，实际双缓冲、CompactNormal和L0C别名必须CCEC确认。不同N可能影响硬件内部累加行为，因此数学等价不代替逐bit门禁。

## 本地实际AST检查

运行`python check_cpu.py`：653例、2064896个token×group上下文通过，覆盖：

- T1…256、正式WKVProfile T6静态覆盖、全部9种校准映射；
- 每个pair的每一个raw guard位置单独不同，确认不会漏检；
- 所有有效行唯一写入，权重列与输出列对应，真实K256次序、唯一seed和尾行/物理store；
- 任意独立group排列、raw相等负数走N32、raw不等但clamp相同负数仍走两次N16；
- T≤16只原M16，其余fast/回退数与每pair raw相等情况完全一致。

CPU执行实际候选函数，不只另写索引模型；没有执行矩阵数值硬件。

## 无设备编译与强对拍

`source env.sh; python preflight.py`校验固定环境/正式源码/本目录helper SHA。先`python compile.py --roots wide`，再`--roots dispatch baseline`；保存生成路径，真实CCEC检查两seed分支没有L0C phi冲突。

继承M64强harness：真实L4归档normed输入及真实BF16 WKV权重，Native F.linear/旧M64/新N32，同一WKVProfile选定order；eager/raw graph逐bit、Native repeat/graph、A/B/A/zero/tiny/small、NaN毒化、首尾8行guard及input/order/weight不变。T144与T240正式order的16个pair全部相等，实际覆盖N32；T6走原M16。

额外强制把每个odd group设为相邻even group次序并交换前两步，保证16个pair全部不等；同修改order的旧M64 eager为金值，验两graph和candidate eager，恢复同地址原order后再对Native。该部分不把修改order当成Native输出。

按6→144→240各自单卡任务，首差即停，每任务外部780秒、wrapper750秒；精度全过才交错计时。T144/240输入为归档真实六行重复扩展的模块测试，不是整模型轨迹。没有上传、CCEC或NPU，不能声明硬件精度或性能通过。
