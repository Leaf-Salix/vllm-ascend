# WKV M64N32 2026-10-19

- [x] 实际AST653例/2064896上下文，全T、9校准映射、每pair每guard位置、negative/不等回退与尾行。
- [x] 原M16 body不变；两矩阵分支各自seed和store，无跨branch L0C tile合并。
- [x] Affine rows+63容量证明，列stride/公开T不改。
- [x] 真实L4强harness及16个相邻pair强制不等回退、Native恢复；环境与SHA预检。
- [ ] 独立wide根及dispatch真实CCEC/资源复核。
- [ ] T6→144→240 Native逐bit强门禁及关闭DFX性能。
- [ ] 未加入CSA组合；后续整根及真实8K/128K回归由主线程决定。
