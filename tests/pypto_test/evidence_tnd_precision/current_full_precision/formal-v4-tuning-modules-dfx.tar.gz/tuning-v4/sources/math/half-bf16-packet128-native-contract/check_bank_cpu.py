"""实际执行probe的qualified_fixture函数（AST抽取，避免本机NPU导入）。"""
import ast
import hashlib
from pathlib import Path
import numpy as np
import torch
from packet_fixtures import fixture
P=Path(__file__).resolve().parent
bank=torch.load(P/'native-banks.pt',map_location='cpu',weights_only=True)
assert bank['provenance']['complete'] and set(bank['provenance']['phases_complete'])=={'A','B','zero'}
tree=ast.parse((P/'probe.py').read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='qualified_fixture')
ns={'fixture':fixture,'bank_data':bank,'hashlib':hashlib,'np':np,'torch':torch,'report':{},'names':('identity','acc_hi','acc_mid','acc_lo','packed_x','packed_w','packet_x')}
exec(compile(ast.Module(body=[fn],type_ignores=[]),'probe-qualified-fixture','exec'),ns)
for phase in ('A','B','zero'):
 original=fixture(phase);qualified=ns['qualified_fixture'](phase)
 assert np.array_equal(original['expected'].reshape(48,8,16,32)[:32].view(np.uint32),qualified['expected'].reshape(48,8,16,32)[:32].view(np.uint32))
 assert np.array_equal(bank['phases'][phase]['native_trajectory'].numpy().view(np.uint32),qualified['expected'].reshape(48,8,16,32)[32:].view(np.uint32))
 assert np.array_equal(bank['phases'][phase]['native_final'].numpy().view(np.uint32),qualified['expected_final'].reshape(48,16,32)[32:].view(np.uint32))
 print('CPU_NATIVE_BANK_PASS',phase,ns['report']['native_integer_trace_diagnostics'][phase],flush=True)
print('CPU_BANK_SHA',hashlib.sha256((P/'native-banks.pt').read_bytes()).hexdigest())
