"""Retain original32 cases, append extreme low48 domain cases, use HALF packing."""
import numpy as np
from original_packet_fixtures import fixture as old_fixture
from fixtures import rational_round,split_trunc
F=np.float32

def fixture(phase='A'):
    old=old_fixture(phase);oldg=len(old['tags'])
    ox=old['packed_x'].reshape(oldg,8,16,16)[...,0::2].copy()
    ow=old['packed_w'].reshape(oldg,8,16,32)
    ow=np.add(ow[:,:,0::2],ow[:,:,1::2],dtype=F)
    x=np.zeros((16,8,16,8),dtype=F);w=np.zeros((16,8,8,32),dtype=F);acc=np.zeros((16,16,32),dtype=F)
    lo=F(2.0**-48);up=F(2.0**40);xa=F(1+2.0**-7)*lo;wb=F(1+2.0**-11)*lo;q=F(2.0**-114)
    tags=['minimum_product','maximum_product','recover_q114','recover_negative_q114','max_cancel_recover_q114',
          'initial_acc_q114','initial_acc_full24_Eminus91','initial_acc_large_full24','layer14_like_Em42',
          'signed_zero','random_full_domain_0','random_full_domain_1','alternating_extreme_products',
          'small_acc_negative_full24','cross_step_q114_halfulp','cross_step_negative_q114_halfulp']
    x[0].fill(lo);w[0].fill(lo);x[1].fill(up);w[1].fill(up)
    def recovery(group,negative=False,offset=0):
        s=F(-1 if negative else 1)
        x[group,:,:,offset:offset+4]=s*np.array([xa,-lo,-xa,lo],dtype=F)
        w[group,:,offset:offset+4,:]=np.array([wb,wb,lo,lo],dtype=F)[None,:,None]
    recovery(2);recovery(3,True);recovery(4,offset=2)
    x[4,:,:,0]=up;w[4,:,0]=up;x[4,:,:,1]=-up;w[4,:,1]=up
    x[5].fill(lo);w[5].fill(lo);acc[5].fill(q)
    rng=np.random.default_rng(2026101948)
    low_acc_bits=np.uint32((127-91)<<23)|rng.integers(0,1<<23,(16,32),dtype=np.uint32)
    acc[6]=low_acc_bits.view(F);x[6].fill(lo);w[6].fill(lo)
    large_acc_bits=np.uint32((127+89)<<23)|rng.integers(0,1<<22,(16,32),dtype=np.uint32)
    acc[7]=large_acc_bits.view(F);x[7].fill(-up);w[7].fill(up)
    x[8].fill(lo);w[8].fill(F(2.0**-42));x[9].fill(F(-0.0));w[9].fill(lo)
    for g in [10,11]:
        xb=(rng.integers(79,167,(8,16,8),dtype=np.uint32)<<23)|(rng.integers(0,2,(8,16,8),dtype=np.uint32)<<31)|(rng.integers(0,128,(8,16,8),dtype=np.uint32)<<16)
        wbits=(rng.integers(79,167,(8,8,32),dtype=np.uint32)<<23)|(rng.integers(0,2,(8,8,32),dtype=np.uint32)<<31)|(rng.integers(0,2048,(8,8,32),dtype=np.uint32)<<12)
        x[g]=xb.view(F);w[g]=wbits.view(F)
    x[12]=np.array([up,lo,-up,xa,up,-lo,-up,-xa],dtype=F)
    w[12]=np.array([up,lo,up,wb,up,lo,up,wb],dtype=F)[None,:,None]
    acc[13]=-low_acc_bits.view(F);x[13].fill(lo);w[13].fill(-lo)
    recovery(14);recovery(15,True);acc[14].fill(F(2.0**-90));acc[15].fill(F(-2.0**-90))
    # Only two RN steps contribute half-ULPs; a single global RN would move oneULP.
    x[14:16,2:]=0;w[14:16,2:]=0
    if phase=='B':x=np.roll(x,1,axis=2).copy();w=-w;acc=-acc
    elif phase=='zero':x.fill(0);w.fill(0);acc.fill(0)
    else:assert phase=='A'
    acc[acc==0]=F(0)
    x=np.concatenate((ox,x));w=np.concatenate((ow,w));acc=np.concatenate((old['acc'].reshape(oldg,16,32),acc));tags=old['tags']+tags
    groups=len(tags);ah,am,al=split_trunc(acc);wh,wl,unused=split_trunc(w)
    assert not unused.any()
    # Explicitly require normal-or-zero BF16 pieces and FP32 subproducts.
    for part in [x,wh,wl,ah,am,al]:
        assert not (part.view(np.uint32)&65535).any()
        assert ((part==0)|(np.abs(part)>=F(2.0**-126))).all()
    px=np.concatenate((x,x),axis=-1);pw=np.concatenate((wh,wl),axis=2)
    product=np.multiply(x[:,:,:,:,None],w[:,:,None,:,:],dtype=F)
    sub=np.multiply(px[:,:,:,:,None],pw[:,:,None,:,:],dtype=F)
    assert np.array_equal(product.astype(np.float64),x[:,:,:,:,None].astype(np.float64)*w[:,:,None,:,:].astype(np.float64))
    assert np.array_equal(sub[:,:,:,:8].astype(np.float64)+sub[:,:,:,8:].astype(np.float64),product.astype(np.float64))
    assert ((sub==0)|(np.abs(sub)>=F(2.0**-126))).all()
    expected=np.empty((groups,8,16,32),dtype=F);current=acc.copy()
    for step in range(8):
        for group in range(groups):
            for row in range(16):
                for col in range(32):
                    terms=np.concatenate((current[group,row,col:col+1],product[group,step,row,:,col]))
                    expected[group,step,row,col]=np.array(rational_round(terms.view(np.uint32)),dtype=np.uint32).view(F)
        current=expected[:,step].copy()
        assert ((current==0)|(np.abs(current)>=F(2.0**-114))).all()
    assert np.array_equal(expected[:oldg].view(np.uint32),old['expected'].reshape(oldg,8,16,32).view(np.uint32))
    return {'tags':tags,'identity':np.eye(16,dtype=F),'acc':acc.reshape(-1,32),'acc_hi':ah.reshape(-1,32),'acc_mid':am.reshape(-1,32),'acc_lo':al.reshape(-1,32),
            'packed_x':px.reshape(-1,16),'packed_w':pw.reshape(-1,32),'packet_x':px.transpose(0,2,1,3).reshape(groups*16,128).copy(),
            'packet_w':pw.reshape(-1,32),'expected':expected.reshape(-1,32),'expected_final':expected[:,-1].reshape(-1,32),'steps':8,'phase':phase}
