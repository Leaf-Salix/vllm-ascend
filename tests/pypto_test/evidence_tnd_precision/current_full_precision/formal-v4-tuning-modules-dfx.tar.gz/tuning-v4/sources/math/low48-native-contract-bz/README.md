# B/zero 独立 Native 银行

沿用phaseA的固定Native观察器和同输入旧acc+8product方法。各phase分32～39/40～47两批，每批128病例，max780秒；4批全部exit0。每phase65,536去重元素，Native rawAB与冻结BF16逐K16相同；prefix/repeat/fidelity/guards、窗口重叠与跨步归纳全部通过。

B并非简单将A输出取负/roll：实际fixture对x按row roll1、w取负、acc取负但不roll。先用独立 `low48-seq-capture` 任务采样冻结seq的B/zero轨迹，原32仍对整数严格门禁；新16当时只存为待验证轨迹。随后每一步在Native中建立同一旧acc，并独立读取Native rawAB，逐bit验证轨迹。因此最终银行是Native观测值，不是把seq直接当金值。

`assemble_banks.py`要求六批(A/B/zero)原始结果都complete/pass、每批128病例，逐项验证prefix/repeat/fidelity及Native对BF16结果、两个列窗口重叠、跨步归纳，再绑定各phase原始七个输入SHA。输出相邻 `half-bf16-packet128-native-contract/native-banks.pt`。

最终K128/seq复测已经通过；参见相邻 `half-bf16-packet128-native-contract/RESULTS.md`。原始任务结果、合成张量、日志均保留。
