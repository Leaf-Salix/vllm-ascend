#!/usr/bin/env bash
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/tnd-precision-delivery-20261018/env.sh"
job=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
export job base
export PYTHONPATH="$job:$PYTHONPATH"
export PYPTO_PROG_BUILD_DIR="$job/build" PYPTO_CACHE_DIR="$job/cache"
export PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1
export LOCAL_WORLD_SIZE=1 HCCL_DETERMINISTIC=true
native_dir="$base/full-pto-precision-20261016/hcpre-native-v3"
export HCPRE_BRIDGE="$native_dir/bridge-build/dsv4_hcpre_observe17_bridge.so"
export HCPRE_READER="$base/full-pto-precision-20261016/hcpre-external-partials-v1/read_hcpre_workspace.py"
vendor="$native_dir/install/packages/vendors/yejia_hcpre_observe16_transformer"
test -f "$vendor/op_api/lib/libcust_opapi.so"
test -f "$vendor/op_impl/ai_core/tbe/kernel/config/ascend910_93/hc_pre_full_diag.json"
test -f "$vendor/op_impl/ai_core/tbe/kernel/config/ascend910_93/binary_info_config.json"
export ASCEND_CUSTOM_OPP_PATH="$vendor:${ASCEND_CUSTOM_OPP_PATH:-}"
