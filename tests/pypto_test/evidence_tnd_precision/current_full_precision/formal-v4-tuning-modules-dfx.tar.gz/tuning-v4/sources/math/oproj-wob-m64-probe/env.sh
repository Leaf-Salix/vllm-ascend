#!/usr/bin/env bash
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/tnd-precision-delivery-20261018/env.sh"
job=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
export job
export PYTHONPATH="$job:$PYTHONPATH"
export PYPTO_PROG_BUILD_DIR="$job/build" PYPTO_CACHE_DIR="$job/cache"
export PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1
export LOCAL_WORLD_SIZE=1 HCCL_DETERMINISTIC=true
