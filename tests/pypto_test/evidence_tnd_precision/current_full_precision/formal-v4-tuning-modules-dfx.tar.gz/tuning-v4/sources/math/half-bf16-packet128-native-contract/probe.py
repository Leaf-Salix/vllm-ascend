"""原32整数金值、新16独立Native硬件bank：逐K16与K128及ABA门禁。"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import time
import numpy as np
import torch
import torch_npu
import pypto.torch
import baseline_dot8
import packet128
from packet_fixtures import fixture

p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--steps',type=int,choices=(8,),required=True);p.add_argument('--device',type=int);a=p.parse_args();a.out.mkdir()
started=time.monotonic()
report={'pass':False,'complete':False,'scope':'low48 HALF generic old32 integer / new16 independently collected Native contract; sequential8 K16 / packet K128, not model acceptance',
        'steps':8,'checks':[],'task_device':os.environ['TASK_DEVICE']}
HERE=Path(__file__).resolve().parent
bank_file=HERE/'native-banks.pt'
bank_data=torch.load(bank_file,map_location='cpu',weights_only=True)
report['native_bank_sha256']=hashlib.sha256(bank_file.read_bytes()).hexdigest()
report['native_bank_provenance']=bank_data['provenance']
assert bank_data['provenance']['complete'] and set(bank_data['provenance']['phases_complete'])=={'A','B','zero'}
def qualified_fixture(phase):
    current=fixture(phase)
    bank=bank_data['phases'][phase]
    assert bank['complete'] and bank['groups']==list(range(32,48))
    assert set(bank['input_sha256'])==set(names)
    assert bank['native_trajectory'].dtype==torch.float32 and torch.isfinite(bank['native_trajectory']).all()
    for name,expected_sha in bank['input_sha256'].items():
        assert hashlib.sha256(current[name].tobytes()).hexdigest()==expected_sha,(phase,name,'Native bank input differs')
    original=current['expected'].reshape(48,8,16,32).copy()
    native=bank['native_trajectory'].numpy()
    assert native.shape==(16,8,16,32)
    report.setdefault('native_integer_trace_diagnostics',{})[phase]=int((original[32:].view(np.uint32)!=native.view(np.uint32)).sum())
    original[32:]=native
    current['expected']=original.reshape(-1,32)
    current['expected_final']=original[:,-1].reshape(-1,32).copy()
    return current
names=('identity','acc_hi','acc_mid','acc_lo','packed_x','packed_w','packet_x')
def save():(a.out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
def host(value):
    torch.npu.synchronize();return value.detach().cpu().contiguous()
def check(label,actual,expected,current):
    actual,expected=host(actual),expected.cpu().contiguous()
    assert actual.shape==expected.shape and actual.dtype==expected.dtype
    kind=torch.int32 if actual.element_size()==4 else torch.int16
    diff=actual.view(kind)!=expected.view(kind)
    item={'label':label,'bit_equal':not bool(diff.any()),'different_elements':int(diff.sum()),'first_coordinates':diff.nonzero()[:8].tolist()}
    if bool(diff.any()) and actual.dtype==torch.float32 and not 'guard' in label:
        if 'trajectory' in label:
            s,g,r,c=diff.reshape(len(current['tags']),8,16,32).permute(1,0,2,3).nonzero()[0].tolist()
        else:
            row,c=diff.nonzero()[0].tolist();g,r=row//16,row%16;s=7 if 'final' in label else -1
        item.update(first_step=s,first_group=g,case_tag=current['tags'][g],first_row=r,first_col=c)
    report['checks'].append(item);save()
    if not item['bit_equal']:
        torch.save({'label':label,'actual':actual,'expected':expected,'tags':current['tags'],
                    'fixture':{n:torch.from_numpy(current[n].copy()) for n in names}},a.out/'first-difference.pt')
        raise RuntimeError('FIRST_BIT_DIFFERENCE '+json.dumps(item))

torch.npu.set_device(0);torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1);torch.set_num_threads(4)
pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer');save()
try:
 with torch.inference_mode():
    initial=qualified_fixture('A');report['tags']=initial['tags']
    report['source_sha']={m.__name__:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for m in (baseline_dot8,packet128)}
    inputs={n:torch.from_numpy(initial[n].copy()).to(dtype=torch.bfloat16,device='npu') for n in names}
    for n in names:assert np.array_equal(host(inputs[n]).float().numpy(),initial[n]),n
    seq=pypto.torch.register(baseline_dot8.interleaved,'interleave_packet128_20261019::sequential8')
    packet=pypto.torch.register(packet128.packet128,'interleave_packet128_20261019::packet128')
    def alloc(rows):
        owner=torch.full((rows+16,32),.0625,dtype=torch.float32,device='npu');return owner,owner[8:-8]
    seqp_owner,seqp=alloc(len(initial['acc']));seqt_owner,seqt=alloc(len(initial['expected']))
    packp_owner,packp=alloc(len(initial['acc']));packf_owner,packf=alloc(len(initial['acc']))
    def seq_call():seq(*(inputs[n] for n in names[:6]),seqp,seqt)
    def packet_call():packet(*(inputs[n] for n in names[:4]),inputs['packet_x'],inputs['packed_w'],packp,packf)
    def check_seq(label,d):
        check(label+'_seq_prefix',seqp,torch.from_numpy(d['acc'].copy()),d)
        check(label+'_seq_trajectory',seqt,torch.from_numpy(d['expected'].copy()),d)
    def check_packet(label,d):
        check(label+'_packet_prefix',packp,torch.from_numpy(d['acc'].copy()),d)
        check(label+'_packet_final_vs_qualified_gold',packf,torch.from_numpy(d['expected_final'].copy()),d)
        old_final=host(seqt).reshape(len(d['tags']),8,16,32)[:,-1].contiguous().reshape(-1,32)
        check(label+'_packet_final_vs_sequential_NPU',packf,old_final,d)
    seq_call();check_seq('eager_A',initial)
    packet_call();check_packet('eager_A',initial)
    seq_graph,packet_graph=torch.npu.NPUGraph(),torch.npu.NPUGraph()
    with torch.npu.graph(seq_graph):seq_call()
    with torch.npu.graph(packet_graph):packet_call()
    for phase in ('A','B','A_restored','zero'):
        assert time.monotonic()-started<690,'Split remaining phases into another short task'
        d=qualified_fixture('A' if phase=='A_restored' else phase)
        for n in names:inputs[n].copy_(torch.from_numpy(d[n].copy()).to(dtype=torch.bfloat16,device='npu'))
        for value in (seqp,seqt,packp,packf):value.fill_(float('nan'))
        seq_graph.replay();check_seq(phase,d)
        packet_graph.replay();check_packet(phase,d)
        for i,owner in enumerate((seqp_owner,seqt_owner,packp_owner,packf_owner)):
            edges=torch.cat((host(owner[:8]),host(owner[-8:])))
            check(phase+'_guard_'+str(i),edges,torch.full_like(edges,.0625),d)
        for n in names:check(phase+'_input_'+n,inputs[n],torch.from_numpy(d[n].copy()).to(torch.bfloat16),d)
    report.update(complete=True,**{'pass':True,'wall_seconds':time.monotonic()-started});save()
    print('INTERLEAVE_PACKET128_PASS',json.dumps(report),flush=True)
except Exception as error:
 report['error']=repr(error);report['wall_seconds']=time.monotonic()-started;save();raise
