# O-proj WO-B M64单因素候选

## 固定基准与源码范围

基准为`csa-combo-v2/candidate_o_proj.py`，SHA `76092347e468e782d6ad52ed5ee241f1ec43508625b61e71563f52a67050a8a9`。候选SHA `81a08a22f056433718152c238e83f0ead622fd88b6b2d381f0a2058ad208762c`，不加入当前CSA组合，不修改正式源码或SDK。

WO-A、整行量化的完整前缀及WO-B dequant的完整后缀逐字节保留；WO-A原M128 pipeline2及短T M16策略完全不改。只改WO-B：

- T≤16保留原M16×N128、16次K512循环，body AST不变。
- T>16改为M64×N128；首K512通过单一无条件`pl.matmul(...out_dtype=INT32)`建立acc，step1…15按原K512次序`matmul_acc(initfalse)`。
- 两分支的矩阵变量各自局部，直接写共同GM integer_accum，不在分支外合并L0C tile。
- 没有加入WO-B pipeline，也没有M128 WO-B变化。

## 精确整数界

所有量化输入、权重都是合法INT8，绝对值≤128。8192项点积任意精确部分和的绝对值≤`8192×128×128=2^27<2^31`，故任意合法相加顺序都不会发生INT32溢出。单积与每次K512累加均是精确整数，保持原K次序更保守。最终INT32→FP32、通道/行scale和BF16舍入语句完全不改。

这是整数表示与计算界的证明；**没有声称已观测Native内部INT32输出或hook到Native整数阶段**。第一阶段仍以相同oa/QI/rowscale与最终BF16的Native逐bit为验收。

## 尾行容量与资源

integer_accum由`[rows+15,4096]`改为`[rows+63,4096]`。对任意正T，ceil(T/64)×64≤T+63，M64的完整物理store合法；原dequant继续按M16和真实valid rows消费。列stride与公开真实T不变。相比affine基准固定多48行INT32，即768KiB GM，仍在原O-proj子scope生命周期内；不新增UB或改变公开ABI。

M64N128/K512 INT8的A为32KiB、B为64KiB、INT32 C为32KiB。若实际codegen分K256，则A/B双缓冲约32/64KiB；如果未分块或额外缓冲导致资源不足，必须由CCEC拒绝，不修改SDK绕过。首matmul用于派生合法CompactNormal，仍需静态验证其INT32支持及分支L0C身份。

## 本地实际AST与整数验证

```bash
.venv311/bin/python reports/dsv4-tnd-precision-overnight-20261019/math/oproj-wob-m64-probe/check_cpu.py
```

T1…256实际执行候选及基准WO-B AST，共1052672个真实row×N128上下文；检查每有效位置唯一写入、权重输出列对应、16个K512完整有序、唯一初始化、短T仅M16/长T仅M64、完整物理store界及前后活数学逐字节不变。额外640个整数输出见证包含全−128最大正积、最坏负积、交错抵消与随机INT8；所有K512前缀均在INT32界内，最终与INT64完整点积相同。没有运行硬件。

## 无设备编译与真实L4强门禁

`source env.sh; python preflight.py`验证固定环境、正式完整source manifest、helper SHA与两臂来源。`python compile.py`执行两个完整O-proj root的生成及实际CCEC，保存路径和每个AIC/AIV结果。先确认INT32 seed、物理尾部和资源，再进行NPU。

强harness复用本轮真实L4权重与归档heads，Native/ComboV2基准/本候选四阶段oa BF16、量化INT8、行scale FP32、最终BF16逐bit。包含Native归档与hook保真、eager/raw graph、A/B/A/zero/tiny/small、输出毒化、首尾8行guard、输入/权重/order不变及WO-A非均匀起点恢复测试。没有额外导出INT32诊断。

每个任务一个T，按6→144→240，首差即停；精度门禁全过才做无DFX同卡交错raw graph计时。外部上限780秒，wrapper750秒。T144/240是归档真实六行重复扩展的模块输入，不冒充整模型轨迹。

```bash
bash "$JOB/run.sh" <新label> 6 --timing-rounds 5 --timing-iters 10
```

当前仅本地CPU、Python/shell语法与源码复核。没有上传、CCEC或NPU；没有改正式源码/SDK，不宣称性能收益。
