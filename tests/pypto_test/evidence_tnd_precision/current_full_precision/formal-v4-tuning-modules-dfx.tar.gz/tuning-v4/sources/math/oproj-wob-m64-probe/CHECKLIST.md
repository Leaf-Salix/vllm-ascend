# WO-B M64候选 2026-10-19

- [x] 基准76092347；WO-A/quant前缀、dequant后缀逐字节不变。
- [x] 短T原M16 body不变，长T单seed+15 K512原序；无WO-B pipeline。
- [x] 实际AST全T1…256、1052672上下文，列组/覆盖/尾行/store/init/K512次序。
- [x] INT32无溢出解析界2^27，以及640个INT64精确输出见证。
- [x] 继承真实L4 Native四阶段强harness；不声称Native INT32 hook。
- [ ] 实际CCEC/CompactNormal/内存资源及别名审查。
- [ ] 独立T6→144→240强门禁，首差停止；通过后不插桩计时。
- [ ] 后续完整CSA/真实模型回归由主线程决定。
