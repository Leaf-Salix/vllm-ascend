#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
source "$(dirname "${BASH_SOURCE[0]}")/env.sh"
label=${1:?new-label}
steps=${2:?must-be-8}
[[ "$label" =~ ^[A-Za-z0-9_.-]+$ ]]
[[ "$steps" == 8 ]]
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
out="$job/results/$label"
mkdir -p "$job/results"
mkdir "$out"
export out
ccache -s > "$out/ccache.log"
export ASCEND_CACHE_PATH="$out/ascend-cache" ASCEND_PROCESS_LOG_PATH="$out/ascend"
export VLLM_CACHE_ROOT="$out/vllm-cache"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH" "$VLLM_CACHE_ROOT"
# 外部task-submit仍应设--max-time 780；本wrapper把整个有效运行限制在750秒。
timeout --signal=TERM --kill-after=10s 750s bash "$job/worker.sh" "$steps" "${@:3}" > "$out/run.log" 2>&1
