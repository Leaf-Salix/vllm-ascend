#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit only; no automatic submission}"
source /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overnight-20261019/input-norm-fused-probe/env.sh
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
label=${1:?new output label};tokens=${2:?one of 6/144/240}
out="$job/results/$label"
mkdir -p "$job/results"
mkdir "$out"
export ASCEND_CACHE_PATH="$out/ascend-cache" ASCEND_PROCESS_LOG_PATH="$out/ascend"
mkdir "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
ccache -s > "$out/ccache.log"
python "$job/preflight.py" > "$out/preflight.log" 2>&1
python "$job/probe_norm.py" --out "$out/data" --tokens "$tokens" > "$out/run.log" 2>&1
