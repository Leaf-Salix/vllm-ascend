"""Generate baseline/candidate and compile Cube/Vector kernels without NPU."""
import json
from pathlib import Path

from pypto.runtime import RunConfig
from pypto.runtime.kernel_compiler import KernelCompiler

from baseline_o_proj import o_proj_test as baseline
from candidate_o_proj import o_proj_test as candidate

HERE = Path(__file__).resolve().parent
ISA = "/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/build/pto-isa"
results = []
for name, root in (("baseline", baseline), ("packets", candidate)):
    program = root.compile(config=RunConfig(platform="a2a3"))
    print("OPROJ_PACKET_GENERATED", name, program.output_dir, flush=True)
    sources = [q for q in Path(program.output_dir).glob("kernels/*/*.cpp") if q.parent.name in ("aiv", "aic")]
    assert sources, (name, program.output_dir)
    kernels = []
    for source in sources:
        core = source.parent.name
        build = HERE / ("precompile-" + name) / core
        build.mkdir(parents=True, exist_ok=True)
        binary = KernelCompiler("a2a3").compile_incore(
            str(source), core_type=core, pto_isa_root=ISA,
            runtime_name="tensormap_and_ringbuffer", build_dir=str(build),
        )
        (build / (source.stem + ".elf")).write_bytes(binary)
        print("OPROJ_PACKET_CCEC_PASS", name, core, source.name, len(binary), flush=True)
        kernels.append({"core": core, "source": str(source), "bytes": len(binary)})
    results.append({"arm": name, "output_dir": str(program.output_dir), "kernels": kernels})
(HERE / "compile-results.json").write_text(json.dumps({"hardware_executed": False, "results": results}, indent=2) + "\n")
