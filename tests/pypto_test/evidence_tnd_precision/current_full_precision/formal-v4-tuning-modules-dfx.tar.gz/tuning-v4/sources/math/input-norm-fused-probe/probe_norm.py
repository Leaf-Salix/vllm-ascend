"""Real L4 Native HC-pre input / RMSNorm, strict three-arm raw graph probe."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import statistics

import torch
import torch_npu
import pypto.torch
from safetensors import safe_open
from vllm_ascend.utils import enable_custom_op

import baseline_norm
import candidate_norm

p=argparse.ArgumentParser()
p.add_argument('--out',type=Path,required=True)
p.add_argument('--tokens',type=int,choices=(6,144,240),required=True)
a=p.parse_args();a.out.mkdir(parents=True)
n=a.tokens
report={'pass':False,'complete':False,'tokens':n,'task_device':os.environ['TASK_DEVICE'],
        'scope':'Input RMSNorm module, real L4 HC/norm weights, synthetic hidden and stress inputs; raw graph, not whole-model/static FULL service timing',
        'checks':[],'sources':{m.__name__:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for m in (baseline_norm,candidate_norm)}}
def save():(a.out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
def cpu(x):
    torch.npu.synchronize()
    return x.detach().cpu().clone()
def exact(x,y):return x.dtype==y.dtype and x.shape==y.shape and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def snapshot(out):return {k:cpu(v) for k,v in out.items()}
def gate(label,actual,gold):
    for k,value in actual.items():
        assert bool(torch.isfinite(value).all()) and bool(torch.isfinite(gold[k]).all()),(label,k,'nonfinite')
    result={k:exact(v,gold[k]) for k,v in actual.items()}
    report['checks'].append({'label':label,'bit_equal':result});save()
    if not all(result.values()):
        torch.save({'actual':actual,'gold':gold,'input':cpu(x),'weight':cpu(weight)},a.out/'first-difference.pt')
        raise RuntimeError('FIRST_BIT_DIFFERENCE '+label)
def observed(name):
    v=snapshot(outputs[name])
    if name!='native':
        assert exact(v['rstd'],v['rstd'][:,:1].expand(-1,8).contiguous()),(name,'rstd 8lane')
        v['rstd']=v['rstd'][:,:1].contiguous()
    else:v['rstd']=v['rstd'].reshape(n,1)
    return v

def main():
    global x,weight,outputs
    torch.npu.set_device(0);torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True);torch_npu.npu.set_deterministic_level(1)
    assert enable_custom_op()
    model=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
    cfg=json.loads((model/'config.json').read_text());assert cfg['rms_norm_eps']==1e-6
    ix=json.loads((model/'quant_model_weights.safetensors.index.json').read_text())['weight_map']
    values={}
    for name in ('hc_attn_fn','hc_attn_scale','hc_attn_base','attn_norm.weight'):
        key='layers.4.'+name
        with safe_open(model/ix[key],framework='pt',device='cpu') as f:w=f.get_tensor(key)
        report.setdefault('weights',{})[key]={'sha256':hashlib.sha256(w.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest(),'stored_dtype':str(w.dtype)}
        values[name]=w.to('npu',dtype=torch.bfloat16 if name=='attn_norm.weight' else w.dtype)
    weight=values['attn_norm.weight'];weight_before={k:cpu(v) for k,v in values.items()}
    hidden=torch.randn((n,4,4096),generator=torch.Generator().manual_seed(20261019+n),dtype=torch.bfloat16).to('npu')
    def mixed(h):return torch.ops._C_ascend.npu_hc_pre_v2(h,values['hc_attn_fn'],values['hc_attn_scale'],values['hc_attn_base'],4,cfg['hc_sinkhorn_iters'],cfg['rms_norm_eps'],cfg['hc_eps'])[0]
    input_a=cpu(mixed(hidden));input_b=cpu(mixed(hidden+.125))
    assert not exact(input_a,input_b),'A/B inputs equal'
    x_owner=torch.full((n+2,4096),.0625,dtype=torch.bfloat16,device='npu');x=x_owner[1:-1];x.copy_(input_a)
    pypto.torch.init(device=0,platform='a2a3',runtime='tensormap_and_ringbuffer')
    ops={name:pypto.torch.register(m.input_norm_test,'norm_fused_20261019::'+name) for name,m in [('baseline',baseline_norm),('candidate',candidate_norm)]}
    owners={name:{'output':torch.full((n+2,4096),.0625,dtype=torch.bfloat16,device='npu'),
                  'rstd':torch.full((n+2,8),.0625,dtype=torch.float32,device='npu')} for name in ops}
    outputs={name:{k:v[1:-1] for k,v in o.items()} for name,o in owners.items()}
    def native():
        y,rstd=torch_npu.npu_rms_norm(x,weight,1e-6)
        return {'output':y,'rstd':rstd}
    graphs={}
    for name,op in ops.items():
        op(x,weight,outputs[name]['output'],outputs[name]['rstd'])
        graph=torch.npu.NPUGraph()
        with torch.npu.graph(graph):op(x,weight,outputs[name]['output'],outputs[name]['rstd'])
        graphs[name]=graph
    native()
    graph=torch.npu.NPUGraph()
    with torch.npu.graph(graph):outputs['native']=native()
    graphs['native']=graph
    tiny=torch.full((n,4096),2.0**-70,dtype=torch.bfloat16);tiny[:,1::2].neg_()
    noise=torch.randn((n,4096),generator=torch.Generator().manual_seed(88),dtype=torch.float32)
    scale=torch.tensor([2.0**(-12+4*(i%9)) for i in range(n)],dtype=torch.float32).reshape(n,1)
    hetero=(noise*scale).to(torch.bfloat16)
    phases=[('A',input_a),('B',input_b),('A_restored',input_a),('zero',torch.zeros_like(input_a)),('tiny',tiny),('heterovariance',hetero)]
    for phase,value in phases:
        x.copy_(value);before=cpu(x)
        gold=snapshot(native());gold['rstd']=gold['rstd'].reshape(n,1)
        if phase=='A':a_native_output=gold['output'].clone()
        if phase=='B':assert not exact(gold['output'],a_native_output),'Native B output unchanged'
        if phase=='A_restored':assert exact(gold['output'],a_native_output),'Native restored A changed'
        repeated=snapshot(native());repeated['rstd']=repeated['rstd'].reshape(n,1)
        gate(phase+'/native_repeat',repeated,gold)
        for name,g in graphs.items():
            for v in outputs[name].values():v.fill_(float('nan'))
            g.replay();gate(phase+'/'+name,observed(name),gold)
            assert exact(cpu(x),before),'input mutated'
            assert bool((cpu(x_owner[[0,-1]])==.0625).all()),'input guard'
            assert all(exact(cpu(v),weight_before[k]) for k,v in values.items()),'weight mutation'
            if name!='native':
                for k,v in owners[name].items():assert bool((cpu(v[[0,-1]])==.0625).all()),(name,k,'guard')
        torch.save({'input':before,'weight':weight_before['attn_norm.weight'],'native':gold,'baseline':observed('baseline'),'candidate':observed('candidate')},a.out/(phase+'-witness.pt'))
    # Timing follows all precision gates, excludes compilation, poison and CPU copies.
    x.copy_(input_a)
    for g in graphs.values():
        for _ in range(3):g.replay()
    torch.npu.synchronize();samples={k:[] for k in graphs}
    keys=list(graphs)
    for round_id in range(8):
        for name in keys if round_id%2==0 else reversed(keys):
            start,end=torch.npu.Event(enable_timing=True),torch.npu.Event(enable_timing=True)
            start.record()
            for _ in range(100):graphs[name].replay()
            end.record();end.synchronize();samples[name].append(start.elapsed_time(end)*1000/100)
    gold=snapshot(native());gold['rstd']=gold['rstd'].reshape(n,1)
    for name,g in graphs.items():
        g.replay();gate('post_timing/'+name,observed(name),gold)
        assert exact(cpu(x),input_a),'post-timing input mutation'
        assert bool((cpu(x_owner[[0,-1]])==.0625).all()),'post-timing input guard'
        assert all(exact(cpu(v),weight_before[k]) for k,v in values.items()),'post-timing weight mutation'
        if name!='native':
            for k,v in owners[name].items():assert bool((cpu(v[[0,-1]])==.0625).all()),(name,k,'post-timing guard')
    report['timing']={'unit':'us/raw module graph replay','rounds':8,'replays_per_round':100,'samples':samples,
                      'summary':{k:{'min':min(v),'mean':statistics.mean(v),'max':max(v)} for k,v in samples.items()}}
    report['pass']=report['complete']=True;save()

save()
try:
    with torch.inference_mode():main()
except Exception as e:
    report['error']=repr(e);save();raise
