#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
source "$(dirname "${BASH_SOURCE[0]}")/env.sh"
label=${1:?new-label}
first=${2:?first-group}
last=${3:?last-group}
[[ "$first:$last" == 32:39 || "$first:$last" == 40:47 ]]
[[ "$label" =~ ^[A-Za-z0-9_.-]+$ ]]
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
out="$job/results/$label"
mkdir -p "$job/results"
mkdir "$out"
export out
export ASCEND_CACHE_PATH="$out/ascend-cache" ASCEND_PROCESS_LOG_PATH="$out/ascend" VLLM_CACHE_ROOT="$out/vllm-cache"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH" "$VLLM_CACHE_ROOT"
timeout --signal=TERM --kill-after=10s 750s bash "$job/worker.sh" "$first" "$last" > "$out/run.log" 2>&1
