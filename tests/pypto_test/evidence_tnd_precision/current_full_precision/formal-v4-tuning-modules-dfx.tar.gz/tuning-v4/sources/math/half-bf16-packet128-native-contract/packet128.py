"""八组交错K16合成单K128，验证硬件内部RN边界。"""
import pypto.language as pl

ROWS = pl.dynamic('BF16_PACKET128_ROWS')
WEIGHT_ROWS = pl.dynamic('BF16_PACKET128_WEIGHT_ROWS')


def _packet128(
    identity: pl.Tensor[[16, 16], pl.BF16],
    acc_hi: pl.Tensor[[ROWS, 32], pl.BF16],
    acc_mid: pl.Tensor[[ROWS, 32], pl.BF16],
    acc_lo: pl.Tensor[[ROWS, 32], pl.BF16],
    packet_x: pl.Tensor[[ROWS, 128], pl.BF16],
    packet_w: pl.Tensor[[WEIGHT_ROWS, 32], pl.BF16],
    prefix_output: pl.Out[pl.Tensor[[ROWS, 32], pl.FP32]],
    output: pl.Out[pl.Tensor[[ROWS, 32], pl.FP32]],
):
    rows = pl.tensor.dim(acc_hi, 0)
    for group in pl.spmd(rows // 16, name_hint='bf16_interleaved_packet128'):
        row = group * 16
        eye = pl.slice(identity, [16, 16], [0, 0])
        hi = pl.slice(acc_hi, [16, 32], [row, 0])
        mid = pl.slice(acc_mid, [16, 32], [row, 0])
        lo = pl.slice(acc_lo, [16, 32], [row, 0])
        acc = pl.matmul(eye, hi, out_dtype=pl.FP32)
        acc = pl.matmul_acc(acc, eye, mid)
        acc = pl.matmul_acc(acc, eye, lo)
        prefix_output = pl.assemble(prefix_output, acc, [row, 0])
        x = pl.slice(packet_x, [16, 128], [row, 0])
        w = pl.slice(packet_w, [128, 32], [group * 128, 0])
        acc = pl.matmul_acc(acc, x, w, init_cond=False)
        output = pl.assemble(output, acc, [row, 0])
    return prefix_output, output


packet128 = pl.jit(_packet128)
