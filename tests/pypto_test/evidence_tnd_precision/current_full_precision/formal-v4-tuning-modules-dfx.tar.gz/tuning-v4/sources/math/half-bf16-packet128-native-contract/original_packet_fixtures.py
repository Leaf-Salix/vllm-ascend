"""原S8夹具+明确区分每K16 RN和整K128只RN一次的跨步见证。"""
import numpy as np
from fixtures import fixture as original_fixture, rational_round


def fixture(phase='A'):
    data = original_fixture(8,phase)
    groups = len(data['tags'])
    x = data['packed_x'].reshape(groups,8,16,16)
    w = data['packed_w'].reshape(groups,8,16,32)
    expected = data['expected'].reshape(groups,8,16,32)
    # Add dedicated cross-step RN witnesses while retaining the first16 cases.
    for group,tag in ((17,'cross_step_positive_halfulps'),(18,'cross_step_negative_halfulps'),(19,'cross_step_large_cancel')):
        data['tags'][group] = tag
        x[group].fill(0); w[group].fill(0)
        for key in ('acc','acc_hi','acc_mid','acc_lo'):
            data[key].reshape(groups,16,32)[group].fill(0)
        sign = -1 if group == 18 else 1
        if phase == 'B':sign *= -1
        if phase != 'zero':
            w[group,:,0::2,:] = sign
            if group in (17,18):
                x[group,0,:,0:2] = 1
                x[group,0,:,2:4] = np.float32(2**-24)
                x[group,1,:,0:2] = np.float32(2**-24)
            else:
                x[group,0,:,0:2] = np.float32(2**24)
                x[group,1,:,0:2] = 1
                x[group,2,:,0:2] = np.float32(-2**24)
        current = np.zeros((16,32),dtype=np.float32)
        for step in range(8):
            raw_w = np.add(w[group,step,0::2],w[group,step,1::2],dtype=np.float32)
            raw_x = x[group,step,:,0::2]
            product = np.multiply(raw_x[:,:,None],raw_w[None,:,:],dtype=np.float32)
            for row in range(16):
                for col in range(32):
                    values = np.concatenate((current[row,col:col+1],product[row,:,col]))
                    current[row,col] = np.array(rational_round(values.view(np.uint32)),dtype=np.uint32).view(np.float32)
            expected[group,step] = current
    data['packet_x'] = x.transpose(0,2,1,3).reshape(groups*16,128).copy()
    data['packet_w'] = data['packed_w']
    data['expected_final'] = expected[:,-1].reshape(groups*16,32).copy()
    return data
