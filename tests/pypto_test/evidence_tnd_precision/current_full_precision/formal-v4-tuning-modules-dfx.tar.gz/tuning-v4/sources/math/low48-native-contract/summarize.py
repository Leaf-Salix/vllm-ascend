"""合并两个列窗口，逐bit核验重叠后生成去重Native参照银行。"""
import hashlib
import json
from pathlib import Path
import torch
P=Path(__file__).resolve().parent
bank=torch.empty((16,8,16,32),dtype=torch.float32)
ints=torch.empty_like(bank);bf16=torch.empty_like(bank);old=torch.empty_like(bank)
results=[]
for label in ('group32-39-v1','group40-47-v1'):
 d=P/'results'/label/'data';r=json.loads((d/'result.json').read_text())
 assert r['complete'] and r['pass'] and len(r['cases'])==128
 for g in range(r['first'],r['last']+1):
  for step in range(8):
   a=torch.load(d/f'group{g}-step{step}-col0.pt',map_location='cpu',weights_only=True)
   b=torch.load(d/f'group{g}-step{step}-col8.pt',map_location='cpu',weights_only=True)
   for name,dest in [('native',bank),('integer',ints),('bf16',bf16),('oldacc',old)]:
    assert torch.equal(a[name][:,8:].view(torch.int32),b[name][:,:16].view(torch.int32)),(g,step,name,'overlap')
    dest[g-32,step]=torch.cat([a[name][:,:8],b[name]],dim=1)
 results.append({'label':label,'cases':len(r['cases']),'unique_elements':r['unique_elements'],'native_bf16_different':sum(c['native_vs_bf16']['different'] for c in r['cases']),'prefix_pass':all(c['prefix_bit_equal'] for c in r['cases']),'repeat_pass':all(c['native_repeat_bit_equal'] for c in r['cases']),'fidelity_pass':all(all(c['observer_fidelity']) for c in r['cases'])})
assert torch.equal(bank.view(torch.int32),bf16.view(torch.int32))
assert torch.equal(bank[:,:-1].view(torch.int32),old[:,1:].view(torch.int32)), 'Native-step induction'
summary={'complete':True,'unique_elements':bank.numel(),'native_bf16_different':int((bank.view(torch.int32)!=bf16.view(torch.int32)).sum()),'native_integer_step_different':int((bank.view(torch.int32)!=ints.view(torch.int32)).sum()),'native_integer_by_group':{str(g+32):int((bank[g].view(torch.int32)!=ints[g].view(torch.int32)).sum()) for g in range(16)},'overlap_exact':True,'oldacc_induction_exact':True,'scope':'phaseA groups32..47 all8steps16x32; sequential BF16 K16 contract only, not K128 acceptance','batches':results}
torch.save({'native_trajectory':bank,'native_final':bank[:,-1].clone(),'integer_single_step':ints,'bf16_trajectory':bf16,'oldacc':old,'groups':list(range(32,48)),'phase':'A','observer_sha256':'c2915e7e30f2686061dd082dd93d06fa240eff6007014cdee0c43a419472a7db'},P/'native-bank-A.pt')
summary['native_bank_sha256']=hashlib.sha256((P/'native-bank-A.pt').read_bytes()).hexdigest()
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
