"""只读检查正式源、私有SDK、固定环境、候选/基准和所有helper身份。"""
import ast
import hashlib
import importlib
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
root = Path(os.environ['SOURCE_ROOT']).resolve()
source_manifest = json.loads((root.parent / 'manifest.json').read_text())
for name, sha in source_manifest['files'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == sha, name
helper_manifest = json.loads((HERE / 'sha256sums.json').read_text())['files']
for name, sha in helper_manifest.items():
    assert hashlib.sha256((HERE / name).read_bytes()).hexdigest() == sha, name
for name in ('torch', 'torch_npu', 'vllm', 'vllm_ascend', 'pypto', 'simpler', 'npugraph_ex'):
    module = importlib.import_module(name)
    path = Path(module.__file__).resolve()
    print('MODULE', name, getattr(module, '__version__', None), str(path), flush=True)
    if name == 'vllm_ascend':
        assert path.is_relative_to(root)
    if name == 'pypto':
        assert path.is_relative_to(Path(os.environ['LOW_ACCEPTANCE_RUNTIME_PACKAGE']).resolve() / 'pypto')
    if name == 'simpler':
        assert path.is_relative_to(Path('/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/python/simpler').resolve())
for name in ('PTOAS_ROOT', 'ASCEND_HOME_PATH', 'ATB_HOME_PATH', 'CCACHE_DIR'):
    assert os.environ.get(name), name
    print('ENV', name, os.environ[name], flush=True)
assert os.environ['PYTHONNOUSERSITE'] == '1' and os.environ['HCCL_DETERMINISTIC'] == 'true'
from pypto.jit._toolchain import capture_toolchain
assert capture_toolchain('a2a3', 'tensormap_and_ringbuffer').usable
meta = Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE']) / 'metadata.json'
assert hashlib.sha256(meta.read_bytes()).hexdigest() == '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'

import baseline_dot8
import packet128
assert Path(baseline_dot8.__file__).resolve().parent == HERE
assert Path(packet128.__file__).resolve().parent == HERE
assert (HERE/'native-banks.pt').is_file()
print('PREFLIGHT_PASS', 'source_files', len(source_manifest['files']), 'helpers', len(helper_manifest), flush=True)
