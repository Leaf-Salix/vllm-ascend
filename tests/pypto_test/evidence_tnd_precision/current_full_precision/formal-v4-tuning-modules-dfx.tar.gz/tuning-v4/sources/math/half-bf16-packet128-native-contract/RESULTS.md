# low48 HF32 / BF16 / K128 硬件合同结果

## 最终结论

在当前合成覆盖中，BF16 hi/lo替代与K128合并均对齐Native HF32。原32组继续通过原整数金值；新增16个宽指数极端组对齐独立Native硬件银行。Eager及graph A/B/A-restored/zero共69项检查全部逐bit一致。

这解决了此前low48 generic的首差归属：部分宽指数输入下Native本身不等于无限精度九项和的FP32 RNE。BF16并未在这些已知首差处偏离Native。原失败与整数结果保留，不能把表示域不FTZ的证明称为硬件无限精度累加证明。

## 分步证据

| 阶段 | 配置 | 结果 |
| --- | --- | --- |
| 首差定位 | 原逐K16、phaseA | 4,134项不同于整数轨迹；尚未执行K128即停止 |
| 最小三方诊断 | 控制组及三个已知首差 | Native与BF16相同，Native也丢弃q114及产生随机1ULP差异 |
| 独立Native银行 | A/B/zero，各16组×8步×16行×32列 | 共196,608去重元素，Native与BF16逐K16差异0 |
| 最终generic | 原32整数、新16独立Native；逐K16与K128 | 69项全部通过，eager与graph ABA/zero稳定 |

银行每phase的256个T16/24列窗口病例，都保留：

- 独立建立相同FP32旧acc的prefix逐bit核验；
- Native重复一致、观察器可见三输出与安装版Native一致；
- workspace header、输入marker与外侧guard；
- 两列窗口重叠逐bit核验、跨步旧acc归纳关系。

B银行按真实B变换重新获取；没有简单从A取负或滚动推断。最终probe核验每phase全部7个输入SHA、Native bank FP32/finite、group顺序、complete和固定manifest SHA。金值不是直接从被测seq取出。

## 任务与复现

| 任务 | 用途 | 结果 |
| --- | --- | --- |
| `task_20261019_032350_326973230699` | 最小Native首差参照 | exit0 |
| `task_20261019_032825_348135622422` / `032959_357888415313` | A银行两批 | exit0 |
| `task_20261019_033541_384936723313` | B/zero冻结seq采样，原32门禁 | exit0 |
| `task_20261019_033724_394318118372` / `033825_400174923503` | B银行两批 | exit0 |
| `task_20261019_033940_405985811750` / `034023_409483130020` | zero银行两批 | exit0 |
| `task_20261019_034423_72958579` | 最终K128/逐K16 Native合同 | exit0；数值段43.17秒 |

全部是1卡小任务，max-time780、内部750秒；没有长任务。原始JSON、合成张量与日志在相邻报告目录保留。所有数学DSL根、SDK、生产源码未因这次诊断修改；只新增隔离Python观测/验收脚本和银行。

复现入口：

```bash
bash "$JOB/run.sh" <新label> 8
```

其中JOB是本目录上传的独立实验目录。它自动核验固定源/SDK/helper/bank身份，执行原32整数+新16Native金值的完整门禁。银行由相邻 `low48-native-contract-bz/assemble_banks.py` 从六批独立Native原始张量重建，`check_bank_cpu.py`实际执行probe的银行加载函数。

银行SHA256：`b529583b21efa08dba414f0f3fad53a92858d40f3c5aed118c7f9c80c5ef74d8`。

## 保留的诊断与限制

A和B各有4,134项不同于原整数整轨迹，zero为0；这些数学差异已在最终结果JSON中保留。它们不构成对Native不一致，因为Native银行与被测两种Cube实现逐bit相同。

当前覆盖是48组指定合成输入、8步，以及资格范围内的边界/宽指数/跨步舍入反例；不等于任意IEEE输入证明。也不代替真实HC全部层、完整CSA、8K/128K整模型token及性能验收。这些仍由主线程独立进行。
