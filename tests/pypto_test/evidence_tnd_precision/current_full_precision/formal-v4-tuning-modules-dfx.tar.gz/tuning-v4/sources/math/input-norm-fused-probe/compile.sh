#!/usr/bin/env bash
set -euo pipefail
source /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overnight-20261019/input-norm-fused-probe/env.sh
export ASCEND_RT_VISIBLE_DEVICES="" TORCH_DEVICE_BACKEND_AUTOLOAD=0
ccache -s
python "$job/verify_ast.py"
python "$job/compile.py"
