"""No-device compile of original/group4 HC roots and same-body square probes."""
import hashlib
import json
from pathlib import Path
from pypto.runtime import RunConfig
from pypto.runtime.kernel_compiler import KernelCompiler
import baseline_hc
import candidate_hc
import baseline_square
import candidate_square
HERE=Path(__file__).resolve().parent
ISA='/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/build/pto-isa'
results=[]
for name,root in [('baseline_square',baseline_square.square_partial_test),('candidate_square',candidate_square.square_partial_test),('baseline_hc',baseline_hc.hc_pre_test),('candidate_hc',candidate_hc.hc_pre_test)]:
    p=root.compile(config=RunConfig(platform='a2a3'))
    print('SQUARE_GENERATED',name,p.output_dir,flush=True)
    sources=sorted(x for x in Path(p.output_dir).glob('kernels/*/*.cpp') if x.parent.name in ['aic','aiv'])
    assert sources
    inventory=[]
    for source in sources:
        build=HERE/('compile-'+name)/source.parent.name;build.mkdir(parents=True,exist_ok=True)
        binary=KernelCompiler('a2a3').compile_incore(str(source),core_type=source.parent.name,pto_isa_root=ISA,runtime_name='tensormap_and_ringbuffer',build_dir=str(build))
        (build/(source.stem+'.elf')).write_bytes(binary)
        inventory.append({'path':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'binary_bytes':len(binary)})
        print('SQUARE_CCEC_PASS',name,source.name,len(binary),flush=True)
    results.append({'name':name,'output_dir':str(p.output_dir),'kernels':inventory})
(HERE/'compile-results.json').write_text(json.dumps({'hardware_executed':False,'roots':results},indent=2)+'\n')
