"""CPU-only AST and exhaustive T1..256 scheduling equivalence gate."""
import ast
import copy
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
dump=lambda n:ast.dump(n,include_attributes=False)
base=ast.parse((HERE/'baseline_hc.py').read_text())
candidate=ast.parse((HERE/'candidate_hc.py').read_text())
fn=lambda tree:next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='hc_pre_gates')
b,c=fn(base),fn(candidate)
bi=next(i for i,n in enumerate(b.body) if isinstance(n,ast.Assign) and n.targets[0].id=='sq_units')
ci=next(i for i,n in enumerate(c.body) if isinstance(n,ast.Assign) and n.targets[0].id=='sq_group')
b_square=b.body[bi:bi+2];c_square=c.body[ci:ci+5]
assert ci==bi
# Everything outside the scheduling rewrite must remain identical, including
# original RMS part0..21 aggregation, vector root and all HC gates/mix stages.
normalized=copy.deepcopy(candidate)
norm_fn=fn(normalized);norm_fn.body[ci:ci+5]=copy.deepcopy(b_square)
assert dump(base)==dump(normalized),'non-square or RMS math changed'
b_loop=b_square[-1];c_loop=c_square[-1]
assert isinstance(b_loop,ast.For) and isinstance(c_loop,ast.For)
inner=c_loop.body[-1];assert isinstance(inner,ast.For)
# Before matmul only sq_part binding changes; same count/acc init/K32/pipeline,
# same product order, and same partial output row/store in each part.
assert [dump(n) for n in b_loop.body[3:]]==[dump(n) for n in inner.body[1:]]
assert dump(b_loop.body[2])==dump(c_loop.body[2]) # sq_rows
for label,expected in [('baseline',b_square),('candidate',c_square)]:
 probe=ast.parse((HERE/(label+'_square.py')).read_text())
 f=next(n for n in probe.body if isinstance(n,ast.FunctionDef))
 assert [dump(n) for n in f.body[5:-1]]==[dump(n) for n in expected],label+' observation body drift'
# Exact source identity of selected current HC panel and baseline, not old15.
combo=HERE.parent/'csa-combo-v2'
assert sha(HERE/'baseline_hc.py')==sha(combo/'candidate_hc.py')
assert sha(HERE/'candidate_panel.py')==sha(combo/'candidate_panel.py')
records=[]
for t in range(1,257):
 pad=(t+15)//16*16;group=4 if t>=64 else 1;ng=(22+group-1)//group
 expected=[(t0,p) for t0 in range(0,pad,16) for p in range(22)]
 actual=[];owners={};matmul_steps=0
 for worker in range((pad//16)*ng):
  t0=worker//ng*16;begin=worker%ng*group
  parts=[]
  for i in range(min(group,22-begin)):
   p=begin+i;parts.append(p);actual.append((t0,p))
   ks=[p*768+kb*32 for kb in range(min(768,16384-p*768)//32)]
   assert ks==list(range(p*768,min(p*768+768,16384),32))
   assert (len(ks)==8 if p==21 else len(ks)==24)
   matmul_steps+=len(ks)
   lo=(p*pad+t0)*16*4;hi=lo+16*16*4
   assert lo%64==0 and hi%64==0
   for line in range(lo//64,hi//64):
    assert line not in owners,(t,worker,p,'shared or duplicate output cacheline')
    owners[line]=worker
  assert parts==list(range(begin,min(begin+group,22)))
 assert actual==expected and len(set(actual))==len(expected)
 assert len(owners)*64==22*pad*16*4
 assert matmul_steps==(pad//16)*(21*24+8)
 records.append({'tokens':t,'group':group,'baseline_tasks':(pad//16)*22,'candidate_tasks':(pad//16)*ng,'last_group_parts':min(group,22-(ng-1)*group)})
out={'pass':True,'scope':'CPU scheduling/AST only; no numerical hardware claim','unchanged':{'K':32,'M':16,'N':16,'pipeline_stage':2,'parts':22,'last_part_k_count':8,'per_part_fp32_store':True,'rms_aggregation_full_ast':True},'tokens1to256':records,'sha256':{n:sha(HERE/n) for n in ('baseline_hc.py','candidate_hc.py','candidate_panel.py','baseline_square.py','candidate_square.py')}}
(HERE/'cpu-results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({**{k:v for k,v in out.items() if k!='tokens1to256'},'selected':[r for r in records if r['tokens'] in (1,6,16,40,63,64,144,240,256)]},indent=2))
