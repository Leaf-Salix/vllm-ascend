# Square partial group4 验证清单

- [x] 基准取当前 ComboV2 HC 与 panel 原字节，非旧 scalar15 实现。
- [x] 仅 T>=64 时每个任务连续处理4个 part；小 T 仍每任务1个 part。
- [x] CPU AST：每part M/N16、K32、stage2、24/尾8次累加、FP32 store 不变。
- [x] CPU AST：原22part RMS聚合、其余HC和混合计算全部不变。
- [x] T1..256 全部映射，每个(token16,part)恰好一次；尾group2part，无共享输出cacheline。
- [x] 同body独立FP32 Gram输出探针；真实rows×rows比较，不读取未定义padding作金值。
- [x] 无设备完整lower/CCEC：原/新 square 和 HC 两类根。
- [x] 实际C++：每part初始化与store；新part重置L0C前原FIX写回完成；尾part索引合法。
- [ ] 主线程后续提交小NPU任务：先T240，再T144/40/6及64/65边界，首差即停。
- [ ] Native mixed/post/comb、baseline有效Gram、ABA/zero/poison/guard逐bit，计时后复验。

本目录仅准备和编译，不自动提交NPU任务。每个硬件任务max780秒，脚本内部750秒；不超过15分钟。
