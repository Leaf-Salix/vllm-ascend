"""Bounded checks of actual group4 square C++ and HC orchestration."""
import hashlib
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
records=[]
for name in ('square','hc'):
 path=HERE/'generated-review'/name/'kernels/aic/hc_pre_square_partial.cpp'
 s=path.read_text()
 assert s.count('TMATMUL(v55,')==3 and s.count('TMATMUL_ACC(v55, v55,')==3
 assert 'if (v59 == v17)' in s # zero-index first K32 branch resets L0C
 assert 'const int64_t v17 = 0;' in s
 assert 'const int64_t v20 = 32;' in s
 assert 'const int64_t v19 = 768;' in s
 assert s.count('TSTORE(v130, v41);')==1
 assert 'uint64_t v42 = (uint64_t) v12;' in s and 'const int64_t v12 = 0;' in s
 assert 'uint64_t v56 = (uint64_t) v12;' in s # same L0C alias, correct store
 assert 'for (int64_t v49 = v17; v49 < (v4 < v48 ? v4 : v48);' in s
 assert 'int64_t v48 = (int64_t) ((uint64_t) v18 - (uint64_t) v45);' in s
 assert 'wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);\n    for (int64_t v59' in s
 assert 'TSTORE(v130, v41);\n    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);' in s
 assert 'wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);\n    pipe_barrier(PIPE_FIX);\n    TSTORE' in s
 assert 'int64_t v123 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v50 * (uint64_t) ' + ('v6' if name=='square' else 'v7') + ') + (uint64_t) v44);' in s
 records.append({'root':name,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'l0c_range':[0,1024],'each_part_resets_k32_acc':True,'part_store_FIX_to_next_M_barrier':True,'tail_min_group_22minus_base':True})
orch=next((HERE/'generated-review/hc/orchestration').glob('*.cpp')).read_text()
assert 'params_t1.add_output(sq_partials_inline2275);' in orch
assert 'params_t2.add_input(sq_partials_inline2275);' in orch
assert 'params_t1.launch_spec.set_block_num(sq_units_inline2246);' in orch
assert 'int64_t sq_groups_inline2359 = ((sq_group_inline2280 + 21) / sq_group_inline2280);' in orch
result={'pass':True,'hardware_executed':False,'records':records,'HC_square_output_to_RMS_input_dependency':True}
(HERE/'generated-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
