"""Read-only environment/helper identity checks, no device arithmetic."""
import hashlib
import importlib
import json
import os
from pathlib import Path

job=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name,digest in json.loads((job/'manifest.json').read_text())['files'].items():
    assert sha(job/name)==digest,name
source=Path(os.environ['SOURCE_ROOT'])
assert sha(job/'baseline_hc.py')=='9b85c789b23aa4c4340a867587f5dfa18f3f5cca30fbda62d25fffabd5fc51b1'
assert sha(job/'candidate_panel.py')=='927ad345681b52d7741c9dbe2df4377e87545ad6b4d9f940a17f70c7a7dac0d0'
for name in ('torch','torch_npu','pypto','simpler','vllm_ascend'):
    module=importlib.import_module(name)
    print('MODULE',name,getattr(module,'__version__',None),module.__file__,flush=True)
    if name=='vllm_ascend':assert Path(module.__file__).resolve().is_relative_to(source.resolve())
    if name=='pypto':assert Path(module.__file__).resolve().is_relative_to(Path(os.environ['LOW_ACCEPTANCE_RUNTIME_PACKAGE']).resolve()/'pypto')
for name in ('PTOAS_ROOT','ASCEND_HOME_PATH','ATB_HOME_PATH','CCACHE_DIR'):
    assert os.environ.get(name),name
assert os.environ['HCCL_DETERMINISTIC']=='true'
from pypto.jit._toolchain import capture_toolchain
assert capture_toolchain('a2a3','tensormap_and_ringbuffer').usable
from baseline_hc import hc_pre_test as baseline
from candidate_hc import hc_pre_test as candidate
assert tuple(baseline.param_names)==tuple(candidate.param_names)==('x','hc_fn','hc_scale','hc_base','x_mixed','post','comb')
print('PREFLIGHT_PASS',flush=True)
