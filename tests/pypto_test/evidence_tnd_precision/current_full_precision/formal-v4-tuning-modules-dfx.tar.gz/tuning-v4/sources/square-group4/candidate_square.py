# SPDX-License-Identifier: Apache-2.0
"""Standalone FP32 Gram partial observation; same source body as HC gate."""
import pypto.language as pl
T=pl.dynamic("SQUARE_T")
P=pl.dynamic("SQUARE_PARTIAL_ROWS")
HC_DIM=16384
LINEAR_OK=22

def _square_partial_test(
    x: pl.Tensor[[T, 4, 4096], pl.FP32],
    sq_partials: pl.Out[pl.Tensor[[P, 16], pl.FP32]],
):
    x.bind_dynamic(0, T)
    sq_partials.bind_dynamic(0, P)
    t_dim=pl.tensor.dim(x, 0)
    t_linear=((t_dim+15)//16)*16
    x_flat=pl.reshape(x, [t_dim, HC_DIM])
    sq_group = 1
    if t_dim >= 64:
        sq_group = 4
    sq_groups = (LINEAR_OK + sq_group - 1) // sq_group
    sq_units = (t_linear // 16) * sq_groups
    for sq_unit in pl.spmd(sq_units, name_hint="hc_pre_square_partial", allow_early_resolve=True):
        sq_t0 = (sq_unit // sq_groups) * 16
        sq_part_base = (sq_unit % sq_groups) * sq_group
        sq_rows = pl.min(16, t_dim - sq_t0)
        for sq_group_item in pl.range(pl.min(sq_group, LINEAR_OK - sq_part_base)):
            sq_part = sq_part_base + sq_group_item
            sq_count = pl.min(768, HC_DIM - sq_part * 768) // 32
            native_sq_acc = pl.create_tensor([16, 16], dtype=pl.FP32)
            for sq_kb in pl.pipeline(0, sq_count, stage=2):
                sq_k = sq_part * 768 + sq_kb * 32
                sq_lhs = pl.slice(x_flat, [16, 32], [sq_t0, sq_k], valid_shape=[sq_rows, 32])
                native_sq_acc = pl.matmul_acc(native_sq_acc, sq_lhs, sq_lhs, b_trans=True, init_cond=(sq_kb == 0))
            sq_out_row = sq_part * t_linear + sq_t0
            sq_partials[sq_out_row : sq_out_row + 16, 0:16] = native_sq_acc
    return sq_partials

square_partial_test=pl.jit(_square_partial_test)
