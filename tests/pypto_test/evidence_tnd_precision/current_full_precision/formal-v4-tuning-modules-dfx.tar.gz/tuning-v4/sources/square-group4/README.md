# HC-pre FP32 Gram 分片任务成组候选

## 目标与范围

仅改变 `hc_pre_square_partial` 任务粒度，基准逐字节取已验收 ComboV2 HC，panel也是同一已验收Cube实现。生产源码、SDK和数学公式不变。

T<64保持每任务1个part；T>=64每任务连续处理4个part，最后一个任务仅处理part20、21。

| T | 原任务数 | 新任务数 |
|---:|---:|---:|
| 40 | 66 | 66 |
| 64 | 88 | 24 |
| 144 | 198 | 54 |
| 240 | 330 | 90 |

每part仍为16×16 Gram；K32、stage2、首次`init_cond(kb==0)`、21个768和末256分片、FP32 partial存储、后续22part顺序聚合全部保留。绝不把多个part合成更长K归约。

## 静态证明与实际门禁

`check_cpu.py`用全文件AST归一化证明只有上述调度段不同，并对T1..256穷举真实任务、输出和K32范围。每个 `(token16,part)` 一次，part不跨界，每个1024字节矩阵由唯一worker写入，64字节cacheline无共享。

`baseline_square.py`、`candidate_square.py`是从对应正式候选段抽出的同body诊断根，AST检查它们没有另写一套算法。独立探针输出原FP32 Gram，比较每16×16块中真实行×真实列，padding部分无定义、不能充当金值。完整HC仍对实际Native `npu_hc_pre_v2` 比较 mixed/post/comb。

必须检查生成代码中：

1. 每part首条TMATMUL重新初始化L0C，不继承前一个part结果；
2. 每part写回完成后，下一part才复用同L0C/FIX资源；
3. 分片基址为part×768，最后256仍8步，22part RMS归约原样；
4. group4引入的scalar循环和尾group2没有产生错误输出别名。

CPU、四根无设备CCEC及实际生成C++审查均已通过；独立agent复核未见阻断。原/新完整HC各12个核均通过；新square独立根115568B、完整HC中的square核116184B。

实际新square核L0C仅0..1024；每part首kb重新TMATMUL，后kb TMATMUL_ACC。每part末尾M→FIX wait与TSTORE，随后set FIX→M，下一part入口wait FIX→M，避免覆盖仍在写回的同一L0C。输出地址仍part×t_linear+t0，后续RMS任务显式消费该Tensor，依赖未丢。`generated-review.json`与`review_generated.py`保存两根实际物理门禁。

这些结果尚不代表NPU逐bit或性能通过；由主线程再安排硬件门禁。

## 复现

在独立远端同名目录 source `env.sh`，无设备运行 `bash compile.sh`。实际NPU由主线程通过task-submit分配1卡后调用：

```bash
bash run-hc.sh t240-v1 240
```

脚本本身不提交任务。内部750秒超时，每任务外部max780秒。先模块门禁，不直接推进整模型。A/B/A/zero、poison恢复、输入权重不变、输出guard、Native三输出以及有效Gram逐bit后才统计交错raw graph延迟，并在计时后复验。此处数据不能解释为整模型性能。
