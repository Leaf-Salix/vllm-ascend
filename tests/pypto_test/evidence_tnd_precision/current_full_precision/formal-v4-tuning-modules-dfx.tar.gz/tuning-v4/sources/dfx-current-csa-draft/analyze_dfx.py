"""Analyze only with a reviewed token-map bound to actual live artifact SHA."""
import argparse
import ast
from collections import defaultdict
import hashlib
import json
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--token-map',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
artifact=a.run/'current-artifact';meta=json.loads((artifact/'artifact.json').read_text());mapping=json.loads(a.token_map.read_text())
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
assert mapping['complete'] is True and mapping['derivation']=='reviewed actual current alloc/submit order with executed branches'
for key,name in [('config_sha256','kernel_config.py'),('orchestration_sha256','orchestration.cpp')]:
 assert mapping[key]==meta[key]==sha(artifact/name),key+' cannot reuse a token map from a different build'
config=ast.parse((artifact/'kernel_config.py').read_text())
node=next(n for n in config.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='KERNELS' for t in n.targets))
kernels={k['func_id']:k for k in ast.literal_eval(node.value)}
windows=[]
for path in sorted((a.run/'dfx').rglob('chip_swimlane_records.json')):
 d=json.loads(path.read_text());assert d['chip_swimlane_level']==4 and d['metadata']['dropped_run_boundaries']==0
 freq=d['metadata']['clock_freq_hz']/1e6;rows=d['aicore_tasks'];zero=min(r[3] for r in rows)
 groups=defaultdict(list);counts=defaultdict(lambda:defaultdict(int))
 for row in rows:
  token=row[1];key=f'{token>>32}:{token&0xffffffff}';entry=mapping['entries'][key]
  core=d['metadata']['core_types'][row[0]]
  func=[f for f in entry['func_ids'] if kernels[f]['core_type']==core]
  assert len(func)==1,(key,core,entry)
  groups[func[0]].append(row);counts[key][core]+=1
 for key,actual in counts.items():assert dict(actual)==mapping['entries'][key]['expected_executions'],(key,actual,mapping['entries'][key])
 assert set(counts)==set(mapping['entries']),'map includes unexecuted branch or misses actual tasks'
 stats=[]
 for f,rr in groups.items():
  stats.append({'func_id':f,'name':kernels[f]['name'],'core_type':kernels[f]['core_type'],'executions':len(rr),
   'start_us':(min(r[3] for r in rr)-zero)/freq,'end_us':(max(r[4] for r in rr)-zero)/freq,
   'instrumented_span_us':(max(r[4] for r in rr)-min(r[3] for r in rr))/freq,
   'mean_task_execution_us':sum(r[4]-r[3] for r in rr)/freq/len(rr)})
 windows.append({'path':str(path),'sha256':sha(path),'all_actual_tokens_mapped':True,'functions':sorted(stats,key=lambda r:r['instrumented_span_us'],reverse=True)})
assert len(windows)==3,'qualified run must contain exactly three windows'
result={'scope':'DFX instrumented observation; not formal latency, pure compute, or DMA attribution','token_map_sha256':sha(a.token_map),'artifact':meta,'windows':windows}
a.out.write_text(json.dumps(result,indent=2)+'\n');print('THREE_WINDOWS_MAPPED actual artifact SHA/count/core checks passed')
