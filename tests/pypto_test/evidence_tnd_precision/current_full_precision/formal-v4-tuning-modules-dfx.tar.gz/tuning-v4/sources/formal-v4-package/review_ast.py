"""Identity checks against actual V4 source, independently of formatting/import text."""
import ast
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
from prepare import FULL, PREC, HERE, REPO, SOURCES, transform

# prepare.py is guarded separately after initial preparation; import must not rebuild.
def dump(node):
    return ast.dump(node,include_attributes=False)

def imports(tree, package):
    result=[]
    for n in tree.body:
        if isinstance(n,ast.ImportFrom):
            module=importlib.util.resolve_name('.'*n.level+(n.module or ''),package) if n.level else n.module
            result.extend((module,a.name,a.asname) for a in n.names)
        elif isinstance(n,ast.Import):
            result.extend(('',a.name,a.asname) for a in n.names)
    return sorted(result)

records={}
for rel,source in SOURCES.items():
    target=HERE/'patch'/rel
    raw=ast.parse(source.read_text());formal=ast.parse(target.read_text())
    expected=ast.parse(transform(rel,source.read_text()))
    package=rel.rsplit('/',1)[0].replace('/','.')
    assert imports(expected,package)==imports(formal,package),(rel,'import binding change')
    keep=lambda t:[n for n in t.body if not isinstance(n,(ast.Import,ast.ImportFrom))]
    assert list(map(dump,keep(expected)))==list(map(dump,keep(formal))),(rel,'canonical module body mismatch')
    old_functions={n.name:n for n in raw.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    new_functions={n.name:n for n in formal.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    removed=set(old_functions)-set(new_functions)
    expected_removed={'_wkv16_body','_wkv64_body'} if rel==FULL+'/wkv.py' else set()
    assert removed==expected_removed,(rel,removed)
    runtime=[]
    for name,node in new_functions.items():
        assert dump(node)==dump(old_functions[name]),(rel,name,'actual V4 function/class differs')
        runtime.append({'name':name,'canonical_AST_sha256':hashlib.sha256(dump(node).encode()).hexdigest()})
    records[rel]={'pass':True,'new_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'reference_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'import_bindings_resolved':True,'all_retained_functions_classes_exact_actual_reference_AST':True,'removed_unreferenced_probe_functions':sorted(removed),'functions':runtime}

# Service differs from the frozen production source solely by the prior reviewed load gate.
rel=FULL+'/service.py';old=ast.parse((REPO/rel).read_text());new=ast.parse((HERE/'patch'/rel).read_text())
find=lambda t:next(n for n in t.body if isinstance(n,ast.ClassDef) and n.name=='CSAServiceRuntime')
old_cls=find(old);new_cls=find(new)
assert [n.name for n in old_cls.body if isinstance(n,ast.FunctionDef)]==[n.name for n in new_cls.body if isinstance(n,ast.FunctionDef)]
old_ctor=next(n for n in old_cls.body if isinstance(n,ast.FunctionDef) and n.name=='__init__')
new_ctor=next(n for n in new_cls.body if isinstance(n,ast.FunctionDef) and n.name=='__init__')
assert ast.unparse(new_ctor.body[0].test)=='torch.npu.is_current_stream_capturing()'
assert 'qualify_hc_pre_weight' in ast.unparse(new_ctor)
stripped=[n for n in new_ctor.body if not (isinstance(n,ast.If) and ast.unparse(n.test)=='torch.npu.is_current_stream_capturing()') and not (isinstance(n,ast.Assign) and any(ast.unparse(a)=='self.hc_weight_qualification' for a in n.targets))]
assert list(map(dump,stripped))==list(map(dump,old_ctor.body))
for node in new_cls.body:
    if isinstance(node,ast.FunctionDef) and node.name!='__init__':
        match=next(n for n in old_cls.body if isinstance(n,ast.FunctionDef) and n.name==node.name)
        assert dump(node)==dump(match),(node.name,'service hot path changed')

root=ast.parse((HERE/'patch'/FULL/'decode_csa.py').read_text())
root_fn=next(n for n in root.body if isinstance(n,ast.FunctionDef) and n.name=='_full_csa_tnd');assert len(root_fn.args.args)==62
for rel in SOURCES:
    for node in ast.walk(ast.parse((HERE/'patch'/rel).read_text())):
        if isinstance(node,(ast.Import,ast.ImportFrom)):
            module=getattr(node,'module','') or ''
            assert not any(x in module for x in ('candidate','baseline','wide_heads','optimized_hc')),(rel,module)

math={rel:r['new_sha256'] for rel,r in records.items()}
(HERE/'candidate-math.json').write_text(json.dumps(math,indent=2)+'\n')
(HERE/'canonical-identity.json').write_text(json.dumps({'pass':True,'NPU_executed':False,'formal_source_NPU_acceptance_pending':True,'root_ABI':62,'service_delta':'only pre-capture load gate and weight qualification assignment; all hot-path methods AST unchanged','records':records},indent=2)+'\n')
patch=''
summary=[]
for rel in SOURCES:
    target=HERE/'patch'/rel;old=(REPO/rel).read_text() if (REPO/rel).exists() else ''
    new=target.read_text()
    patch+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
    lines=list(difflib.ndiff(old.splitlines(),new.splitlines()))
    summary.append({'path':rel,'added':sum(x.startswith('+ ') for x in lines),'removed':sum(x.startswith('- ') for x in lines),'new':not (REPO/rel).exists()})
(HERE/'formal-source.patch').write_text(patch)
(HERE/'diff-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('CANONICAL_ACTUAL_V4_AST_PASS',len(records),'files root62; load-only service gate')
