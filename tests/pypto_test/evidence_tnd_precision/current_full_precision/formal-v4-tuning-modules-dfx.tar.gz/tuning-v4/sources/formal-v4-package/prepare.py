"""Materialize relative-import V4 sources in reports only; no production edits."""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPORT = HERE.parent
REPO = REPORT.parent.parent / 'vllm-ascend-nalinaly-tnd-20261008-codex'
V4 = REPORT / 'csa-combo-v4'
FULL = 'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision'
PREC = 'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision'
PABS = 'vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.'
FABS = 'vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.'
# Start from the accepted ComboV2 private formal patch, then apply V4 exact bodies.
SOURCES = {
    FULL+'/decode_csa.py': V4/'candidate_csa.py',
    FULL+'/hc_pre.py': V4/'optimized_hc.py',
    FULL+'/hc_pre_panel.py': V4/'candidate_panel.py',
    FULL+'/heads.py': V4/'wide_heads.py',
    FULL+'/o_proj.py': V4/'candidate_o_proj.py',
    FULL+'/wkv.py': V4/'candidate_wkv.py',
    FULL+'/input_norm.py': V4/'candidate_norm.py',
    FULL+'/service.py': REPORT/'weight-contract-package/service.py',
    FULL+'/hc_pre_contract.py': REPORT/'weight-contract-package/hc_pre_contract.py',
    PREC+'/decode_csa.py': V4/'legacy_root_explicit16.py',
    PREC+'/decode_sparse_attn_csa.py': V4/'candidate_sparse.py',
}

def transform(rel, text):
    if rel.startswith(FULL+'/'):
        text = text.replace('from '+PABS, 'from ..deepseek_v4_flash_csa_tnd_precision.')
        text = text.replace('from '+FABS, 'from .')
        for old,new in {
            'optimized_hc':'.hc_pre', 'wide_heads':'.heads',
            'candidate_norm':'.input_norm', 'candidate_o_proj':'.o_proj',
            'candidate_wkv':'.wkv', 'candidate_panel':'.hc_pre_panel',
            'candidate_sparse':'..deepseek_v4_flash_csa_tnd_precision.decode_sparse_attn_csa',
        }.items():
            text=text.replace('from '+old+' import ', 'from '+new+' import ')
    else:
        text=text.replace('from '+PABS, 'from .')
        text=text.replace('from candidate_sparse import ', 'from .decode_sparse_attn_csa import ')
    if rel==FULL+'/hc_pre.py':
        tail='\nfrom .hc_pre_panel import _hcpre_linear_panel\nhcpre_linear_test = pl.jit(_hcpre_linear_panel)\n'
        assert text.endswith(tail)
        text=text[:-len(tail)]+'\n'
        text=text.replace('# measured break-even; keep short-query scalar path', '# All qualified nonempty queries use the Cube panel path.')
    if rel==FULL+'/wkv.py':
        # These probe-era old helpers have no references from the actual dispatch.
        prefix=text[:text.index('def _wkv16_body(')]
        body=text[text.index('def _wkv_test('):]
        text=prefix+body
    return text

if __name__ == '__main__':
    patch=HERE/'patch'
    for name in ('decode_csa.py','hc_pre.py','hc_pre_panel.py','heads.py','o_proj.py'):
        source=REPORT/'whole-cube-oproj-v2/patch'/name
        target=patch/FULL/name;target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(source.read_bytes())
    records={}
    for rel,source in SOURCES.items():
        target=patch/rel;target.parent.mkdir(parents=True,exist_ok=True)
        target.write_text(transform(rel,source.read_text()))
        records[rel]={'input':str(source.relative_to(REPORT)), 'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
    (HERE/'input-sources.json').write_text(json.dumps({'base_checkout_commit':'15a9c1a3ec97da9dd91340e675429b7a55589821','V4_manifest_sha256':hashlib.sha256((V4/'manifest.json').read_bytes()).hexdigest(),'sources':records},indent=2)+'\n')
    print('PREPARED_REPORT_ONLY',len(records))
