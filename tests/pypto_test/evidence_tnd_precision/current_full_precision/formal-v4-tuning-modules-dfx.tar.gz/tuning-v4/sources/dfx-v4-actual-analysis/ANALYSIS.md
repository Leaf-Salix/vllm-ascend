# V4 T240 当前三窗 DFX 分析

## 身份与映射验收

当前任务 `task_20261019_051751_57250520650` 已完成。真实L4权重、合成hidden/history8191、40个S6请求、240条真实token行，完整HC-pre至HC-post、FULL graph。Native与候选先通过原字节/ABA/poison/guard门禁，再采三窗level4、depgen=false。没有运行正式延迟计时。

- 当前实际配置78个kernel，执行67组token；没有套用之前80核静态编译的编号。
- config SHA：`98c57f6122febf42bc107e8dbb29d380aba9e6c34e080d4233b0d41e82fdeab3`。
- orchestration SHA：`432d893a2edf4f51d2bd4eb7279ed963c64efcf8db5f6e0a411bf19ac57e87f8`。
- `reviewed-token-map.json`按当前实际alloc/submit/dummy/分支/循环顺序建立ring-local映射；`analyze_dfx.py`三窗的全部token、核类型、执行次数校验均通过。
- `analysis.json`顶层`review_status=PASS`。其中artifact内的`mapping_status=UNMAPPED...`是原始捕获时状态，原样保留；不代表后续审查失败。原始data未改动。
- 独立review已核对短request分支、merge scope和O-proj八次循环：40request组、120pair组，waves分别2/5，48≤50选择func53+54/55；single-leaf发布61；O-proj A八次对应ring1:61..68。

## 当前热点

单位μs。跨度指该阶段本窗首任务开始至末任务结束，含排队、跨核等待与搬运；不是纯计算或正式延迟。不同阶段可以重叠，不能直接相加。

| 阶段 | 窗1 | 窗2 | 窗3 | 解释 |
|---|---:|---:|---:|---|
| 完整HC-pre |457.9|454.6|458.7|group4 Square与input4 packing已生效|
| InputNorm |73.9|74.3|74.3|融合核240个任务|
| checked_indices |162.2|161.1|159.8|32worker；单任务执行均约146.0|
| slots_plan |18.6|19.1|19.2|32worker，严格依赖checked完成|
| sparse QK/PV |715.7|721.4|721.3|24AIC+48AIV，AIV单任务均706.0|
| O-proj完整 |478.1|473.5|470.7|含A、BF16、量化、B64和反量化|
| HC-post |39.7|39.7|39.8|60个任务|
| 全部AI核任务包络 |2689.8|2655.2|2664.6|仅DFX包络，不作正式性能结果|

细分：Indexer score/TopK只有61.7/69.1/62.2μs；O-proj A八次提交合计跨度252.2/249.0/249.4μs；HC linear Cube152.1/162.0/152.3μs；HC input pack115.0/107.5/116.9μs；Square86.5/72.8/78.3μs。WKV、Qproj和Indexer projection跨阶段有明显排队/交错，不能用它们的首末跨度直接声称算术慢。

## 下一步可行方向

最大稳定单核组为QK/PV，约720μs。当前K512概率舍入、FP32 PV累加及online更新是Native精度合同；Nal性能版的K128块、局部softmax后归并和rint边界不同，不能照搬以换速度。当前可保序测试的是末两个K128 KV面板留在L1，省PV末两次重搬，数学、K128累计顺序、K512 softmax与四类跨核event保持原样。理论L1为Q64KiB+KV384KiB+概率16KiB=464KiB，须经实际CCEC/物理别名及硬件逐bit验证，尚无性能结论。

另一个独立候选为小T保留16planner、大T32，已做CPU与无设备编译；本T240仍32，不应改变本档数值或预期任务粒度。

## 复现分析

```bash
.venv311/bin/python reports/dsv4-tnd-precision-overnight-20261019/dfx-current-csa-draft/analyze_dfx.py --run reports/dsv4-tnd-precision-overnight-20261019/dfx-v4-actual-analysis/data --token-map reports/dsv4-tnd-precision-overnight-20261019/dfx-v4-actual-analysis/reviewed-token-map.json --out /tmp/v4-dfx-reanalysis.json
.venv311/bin/python reports/dsv4-tnd-precision-overnight-20261019/dfx-v4-actual-analysis/summarize.py
```
