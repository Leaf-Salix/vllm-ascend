import json,pathlib,collections,statistics
B=pathlib.Path(__file__).resolve().parent;d=json.loads((B/'analysis.json').read_text());mapping=json.loads((B/'reviewed-token-map.json').read_text())
def union(xs):
 out=[]
 for a,b in sorted(xs):
  if out and a<=out[-1][1]:out[-1][1]=max(out[-1][1],b)
  else:out.append([a,b])
 return out
phaseids={'HC_pre':set(range(0,12)), 'input_norm':{12}, 'WKV':{14,15}, 'indexer_weight':{16,17},'Q_KV_compression':set(range(20,41)), 'Indexer':set(range(41,63)), 'checked_indices':{64},'slot_plan':{65}, 'QK_PV':{66,67},'heads_finalize':{68,69,70},'Oproj':{71,72,73,75,76},'HCpost':{77}}
wins=[]
for w in d['windows']:
 raw=json.loads(pathlib.Path(w['path']).read_text());freq=raw['metadata']['clock_freq_hz']/1e6;zero=min(r[3] for r in raw['aicore_tasks']);groups=collections.defaultdict(list)
 for r in raw['aicore_tasks']:
  key=f'{r[1]>>32}:{r[1]&0xffffffff}';core=raw['metadata']['core_types'][r[0]]; fs=mapping['entries'][key]['func_ids'];cfg=next(f['func_id'] for f in w['functions'] if f['func_id'] in fs and f['core_type']==core)
  groups[cfg].append(((r[3]-zero)/freq,(r[4]-zero)/freq))
 phases={}
 for name,ids in phaseids.items():
  xs=[x for f in ids for x in groups[f]];u=union(xs);phases[name]={'start_us':min(x[0] for x in xs),'end_us':max(x[1] for x in xs),'span_us':max(x[1] for x in xs)-min(x[0] for x in xs),'busy_union_us':sum(b-a for a,b in u)}
 wins.append({'path':w['path'],'phases':phases})
res={'scope':'DFX instrumented spans and execution unions; not formal latency or compute/DMA attribution','windows':wins};(B/'phase-summary.json').write_text(json.dumps(res,indent=2)+'\n')
for name in phaseids:
 vals=[w['phases'][name] for w in wins]
 print(name,'start',*[round(v['start_us'],1) for v in vals], 'end',*[round(v['end_us'],1) for v in vals],'span',*[round(v['span_us'],1) for v in vals],'busy',*[round(v['busy_union_us'],1) for v in vals])
