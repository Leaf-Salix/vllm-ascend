#!/usr/bin/env bash
set -euo pipefail
profile=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "$profile/parameters.env"
runner=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overnight-20261019/threeway-parameterized
source "$runner/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="" TORCH_DEVICE_BACKEND_AUTOLOAD=0
python "$runner/preflight.py"
