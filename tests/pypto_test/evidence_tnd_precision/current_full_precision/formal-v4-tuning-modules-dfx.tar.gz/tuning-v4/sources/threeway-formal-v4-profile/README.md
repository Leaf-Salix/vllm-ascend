# 正式V4 snapshot三方复测参数

仅独立profile，不改三方runner、V4或正式repo，不提交NPU。

- 候选source：`whole-formal-v4/snapshot/source`
- manifest：snapshot/manifest.json，SHA `6107e6ed747925793dcfe0e5188dee8486c3a8b91d0c1b7e073b62d38215bc28`
- 正式root模块：`vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.decode_csa`
- root导出：`decode_csa_tp1_layer_test`；源码SHA `906329dbe19cb8097c3e988ef3f035a9e37f6c64ed06b7744107e8ec498cc3a0`，必须实际62参数。

`parameters.env`显式设置所有TRI参数。`variant-env.sh`保持已验收delivery的私有PyPTO/Simpler、CANN9.2、13包静态和确定性设置，只将SOURCE_ROOT与PYTHONPATH切到正式snapshot；不source whole-formal-v4/env.sh，以免自动载入其中whole-model sitecustomize的PERF_* observer与21层qualification hooks。单层三方自身在相同13包校验/reselect之后调用runtime.qualify_static_wkv。

预检（无设备）：`bash preflight.sh`。

通过并由主线程决定提交时，在同一shell先source参数，再调用原可参数化runner：

```bash
source parameters.env
bash ../threeway-parameterized/run-threeway.sh LABEL 4 --timing-iters 10
```

B40单独另一任务。脚本750秒，task780秒，无DFX，不预编全核。改变snapshot或后续V5时必须新建显式profile、更新源manifest SHA，不从路径猜测候选。
