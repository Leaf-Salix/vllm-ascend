#!/usr/bin/env bash
# Preserve the same private SDK/static packages, without whole-model observer hooks.
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/tnd-precision-delivery-20261018/env.sh"
export SOURCE_ROOT="$base/precision-overnight-20261019/whole-formal-v4/snapshot/source"
export PYTHONPATH="$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
export PYTHONNOUSERSITE=1 HCCL_DETERMINISTIC=true LOCAL_WORLD_SIZE=1
export OMP_NUM_THREADS=4 OMP_PROC_BIND=false
unset PERF_CASE PERF_BACKEND PERF_OUTPUT PERF_CAPTURE_BUCKET
unset ADMISSION_TRACE_DIR FULL_PROBE_DIR FULL_PROBE_MODE LOW_ACCEPTANCE_FIRST_STEP_DIR OFFLINE_PTO_SWIMLANE_DIR
