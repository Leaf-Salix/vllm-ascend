"""用归档位模式银行执行原qualified_fixture AST，无设备、无pickle。"""
import ast
import hashlib
from pathlib import Path
import sys
import numpy as np
import torch
from load_bank_json import load_bank
HERE=Path(__file__).resolve().parent
fixture_dir=HERE.parent/'sources/math/half-bf16-packet128-native-contract'
sys.path.insert(0,str(fixture_dir))
from packet_fixtures import fixture
bank=load_bank()
assert bank['provenance']['complete'] and set(bank['provenance']['phases_complete'])=={'A','B','zero'}
source=ast.parse((fixture_dir/'probe.py').read_text())
fn=next(n for n in source.body if isinstance(n,ast.FunctionDef) and n.name=='qualified_fixture')
ns={'fixture':fixture,'bank_data':bank,'hashlib':hashlib,'np':np,'torch':torch,'report':{},'names':('identity','acc_hi','acc_mid','acc_lo','packed_x','packed_w','packet_x')}
exec(compile(ast.Module(body=[fn],type_ignores=[]),'archived-original-qualified-fixture','exec'),ns)
for phase in ('A','B','zero'):
    original=fixture(phase);qualified=ns['qualified_fixture'](phase)
    assert np.array_equal(original['expected'].reshape(48,8,16,32)[:32].view(np.uint32),qualified['expected'].reshape(48,8,16,32)[:32].view(np.uint32))
    assert np.array_equal(bank['phases'][phase]['native_trajectory'].numpy().view(np.uint32),qualified['expected'].reshape(48,8,16,32)[32:].view(np.uint32))
    assert np.array_equal(bank['phases'][phase]['native_final'].numpy().view(np.uint32),qualified['expected_final'].reshape(48,16,32)[32:].view(np.uint32))
    print('ARCHIVED_NATIVE_BANK_CPU_PASS',phase,ns['report']['native_integer_trace_diagnostics'][phase])
