"""读取合成Native银行的FP32位模式；不读取pickle或模型权重。"""
import hashlib
import json
from pathlib import Path
import numpy as np
import torch

def load_bank(path=None):
    path=Path(path or Path(__file__).with_name('native-bank-bits.json'))
    doc=json.loads(path.read_text())
    assert doc['schema']=='synthetic-native-hf32-bank-v1'
    assert doc['original_artifact_sha256']=='b529583b21efa08dba414f0f3fad53a92858d40f3c5aed118c7f9c80c5ef74d8'
    def decode(v):
        if isinstance(v,dict) and '__synthetic_tensor__' in v:
            t=v['__synthetic_tensor__'];assert t['encoding']=='IEEE754-binary32-little-endian-uint32'
            a=np.asarray(t['uint32_bits'],dtype='<u4').reshape(t['shape'])
            assert hashlib.sha256(a.tobytes()).hexdigest()==t['raw_sha256']
            out=torch.from_numpy(a.view('<f4').copy());assert bool(torch.isfinite(out).all());return out
        if isinstance(v,dict):return {k:decode(x) for k,x in v.items()}
        if isinstance(v,list):return [decode(x) for x in v]
        return v
    return decode(doc['bank'])
