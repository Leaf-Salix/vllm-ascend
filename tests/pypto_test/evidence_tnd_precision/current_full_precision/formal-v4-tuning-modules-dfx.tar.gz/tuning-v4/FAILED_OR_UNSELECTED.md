# 失败或未保留项摘要

这些不属于V4最终数学，原完整证据仍在本次overnight相邻目录。

- 宽指数low48最初相对无限整数金值失败；后续独立Native银行证明已知首差处Native同样不等于无限精度和。最终按Native硬件合同验收，未隐去原差异。
- INT32有序比较的早期range guard硬件误分支；改用安全有界相减符号位，并单独重测阈值与相邻bit。此类门禁不能仅靠CPU证明。
- chunk累加备份/zero的SSA物理别名造成错误；失败源保留，不能把同buffer的名字当备份。
- Sigma/W17、output-major布局、提前BF16/gather布局、部分大panel没有稳定完整HC收益，没有因单个局部计时好看就纳入V4。
- WO-A M256 T240约2.8%收益，未纳入V4。
- 全形状seedK256在T240有收益，但T144退化，未纳入V4；分档hybrid后续另测，不混入此V4归档。
- KV复用v1虽CCEC通过，实际slice→transpose丢动态偏移，被静态审查阻止NPU；v2另测，不属于V4。
- HClinear M64后续候选standalone编译通过而完整HC ConvertToSSA失败，数值checks为空，属于编排作用域问题；不纳入V4，不标成精度失败。其修复与V4安全归档并行进行。
