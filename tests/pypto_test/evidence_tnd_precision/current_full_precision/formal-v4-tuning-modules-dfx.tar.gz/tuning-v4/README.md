# V4 调优证据安全归档

本目录保存明确选择的源文件、CPU/CCEC审查、原始结果JSON及合成Native银行。文件SHA见 `SHA256SUMS.json`；复制来源见 `origin-index.json`。原始结果未改写，21个远端结果按 `remote-result-files.txt` 明确名单收回。

## 证据分层

| 证据 | 目录/索引 | 支持范围与限制 |
| --- | --- | --- |
| HF32 Native合同 | `sources/math/half-bf16-packet128-native-contract/RESULTS.md`；相邻两个Native银行采集目录；`synthetic-gold/` | 原32组合成整数金值保留；新增16组使用独立Native HF32银行。A/B/zero共196608个去重Native结果，最终K16与K128、eager/graph共69项逐bit门禁通过。限指定48组、8步和当前A3环境，不能声称任意IEEE输入的无限精确和。 |
| HC输入group4 | `sources/hcpre-cube-half8-v3-low48-input4/`；对应raw result | 真实L4权重、合成hidden；原数学不变，只分组4个工作项。包含全模型权重资格的范围/SHA摘要，不含实际权重。 |
| HC平方和group4 | `sources/square-group4/`；T6/144/240 raw | Native完整HC三输出、旧PTO有效Gram及linear partials逐bit。有效Gram对旧实现，不能当作新采集Native内部Gram。 |
| HC短query | `sources/hc-short-sweep-v2/`；T1…15 raw | 每档完整HC输出与Native逐bit；保留原S6无关的真实T行语义。 |
| WKV M64N32 | `sources/math/wkv-m64n32-probe/`；T6/144/240 raw | Native原K256顺序和BF16发布；强制相邻order不等时对同输入旧PTO回退。后来V4内联/作用域整理由formal canonical关系另行证明。 |
| WO-B M64 | `sources/math/oproj-wob-m64-probe/`；T6/144/240 raw | Native oa/qi/scale/output四阶段逐bit；INT32点积无溢出界及原K512顺序。包含已验收WO-A上游实现，不把其收益重复算成WO-B收益。 |
| InputNorm融合 | `sources/math/input-norm-fused-probe/`；T6/144/240 raw | 原sum树、sqrt/倒数及BF16边界；Native output/rstd逐bit。 |
| heads宽copy | `sources/csa-wide-heads/`；mixed21/T240 raw | 完整单层CSA的输出、TopK、六cache、FULL replay对拍；只改位拷贝粒度。 |
| Planner32 | `sources/csa-plan-workers32/`；T21/144/240 raw | 保留每query验证/地址数学，改变工作分配；原始小T结果也保留，不外推所有形状收益。 |
| 私有V4合并与CCEC | `sources/csa-combo-v4/`、`sources/review-combo-v4-generated/` | 合并源身份、CPU/完整CCEC及生命周期审查；这些private helper结果不冒充formal源执行。 |
| private→formal转换 | `sources/formal-v4-package/{prepare.py,review_ast.py,CONVERSION_RULES.json,canonical-identity.json}` | 相对import、格式和alias整理，移除不可达测试入口；保留函数体与绑定关系。11个prepared文件与所有实际private输入已归档。此canonical报告自身的NPU pending字段是生成当时状态，原样保留，后来的formal运行另看raw。 |
| 正式V4三方 | `FORMAL_THREEWAY_SUMMARY.json` 与 `raw-results/threeway-parameterized/` | 实际formal snapshot根906329…、manifest6107…；真实L4权重/合成hidden/history8191，均匀B4/T24与B40/T240，完整HC-pre→HC-post、SK0/NZ2/确定性、8×10同卡交错FULL graph、无回退。TND对Native先逐bit门禁，Nal已知误差仅记录。不是192-token整模型或公开SK1口径。 |
| 当前DFX | `sources/dfx-v4-actual-analysis/` | 实际78核、67个token映射、三窗摘要及对应actual orchestration/config。DFX跨度包含排队/搬运等待，不能当正式延迟或纯计算时间。未复制原始大泳道窗口；完整窗口仍在原报告路径。 |

## 正式源与性能口径

三方formal raw明确记录了实际源SHA与manifest，`FORMAL_THREEWAY_SUMMARY.json`提取了原始min/mean/max，不替换原始样本。B4均值Native/TND/Nal约588.073/938.189/516.747µs，B40约1375.258/2669.736/1290.203µs；这些是单层完整CSA，不能直接与真实整模型forward均值相比较。

最终43个runtime文件的真实8K/128K/token结果，以及主线程另行接入的三个raw包，负责证明最终formal执行。这些4.27MB raw包未在本目录重复打包。private单因素→canonical AST→formal raw是三种不同证据，不能互换标签。

## 合成银行的安全导出与复核

`synthetic-gold/native-bank-bits.json`把原合成银行6个FP32 tensor保存为IEEE754 uint32位模式，保留shape、每tensor原始字节SHA、7个输入SHA和Native来源。共221184个tensor元素（包含重复的final行）；不含模型权重或pickle。原PyTorch容器SHA b529…只用于来源绑定；JSON文件有自己的SHA，不能把两者称为同一文件。

```bash
PYTHONDONTWRITEBYTECODE=1 python synthetic-gold/verify_bank_cpu.py
python verify_archive.py
```

前者使用归档的原 `qualified_fixture` AST核验全部phase输入SHA、原32组整数金值不变和新增16组Native位模式；CPU依赖NumPy/Torch，不执行NPU。原NPU helper仍保留其原 `.pt` 文件SHA检查，需要原实验环境中的银行文件；本归档没有偷偷更改原门禁。当前纯JSON加载器用于无pickle的值级复核。

## 复现前提与保留记录

源/helper保持原实验环境依赖：模型、SDK、CANN/ATB、静态13包、已有Native观察器和明确的227目录。归档不包含这些依赖的二进制；执行原设备runner前应按其preflight逐项核验。完整模型配置与最终43文件复现请使用主线程最终报告和对应raw包。

未纳入V4的候选摘要见 `FAILED_OR_UNSELECTED.md`。本目录本身没有提交任务，也没有修改正式checkout或Git。
