"""验证安全归档的完整性与来源范围；纯stdlib，不执行设备。"""
import hashlib
import json
from pathlib import Path

D=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
allowed={'.py','.md','.json','.sh','.log','.patch','.txt','.env','.cpp'}
manifest=json.loads((D/'SHA256SUMS.json').read_text())
actual={str(p.relative_to(D)):p for p in D.rglob('*') if p.is_file() and p.name!='SHA256SUMS.json'}
assert set(actual)==set(manifest['files']),('inventory changed',set(actual)^set(manifest['files']))
for rel,p in actual.items():
    assert not p.is_symlink() and p.suffix in allowed,rel
    assert not any(x in p.relative_to(D).parts for x in ('cache','build','__pycache__','precompile-baseline','precompile-candidate')),rel
    p.read_text(encoding='utf-8')
    assert sha(p)==manifest['files'][rel]['sha256'],rel
raws=sorted((D/'raw-results').rglob('result.json'))
assert len(raws)==21
source_checks=[]
for p in raws:
    d=json.loads(p.read_text());assert d['pass'] and d['complete'],p
    exp=p.relative_to(D/'raw-results').parts[0]
    name='math/'+exp if exp in ('wkv-m64n32-probe','oproj-wob-m64-probe','input-norm-fused-probe') else exp
    folder=D/'sources'/name
    for key in ('helper_sha','source_sha','sources'):
        for module,digest in d.get(key,{}).items():
            f=folder/(module if module.endswith('.py') else module+'.py')
            if f.exists():assert sha(f)==digest,(p,module);source_checks.append(str(f.relative_to(D)))
    for arm,digest in d.get('source_hashes',{}).items():
        tail='wkv' if exp=='wkv-m64n32-probe' else 'o_proj'
        f=folder/(arm+'_'+tail+'.py');assert sha(f)==digest,(p,arm);source_checks.append(str(f.relative_to(D)))
    if exp=='threeway-parameterized':
        v=d['variant_identity'];assert v['root_sha256']=='906329dbe19cb8097c3e988ef3f035a9e37f6c64ed06b7744107e8ec498cc3a0'
        assert v['expected_manifest_sha256']=='6107e6ed747925793dcfe0e5188dee8486c3a8b91d0c1b7e073b62d38215bc28'
        assert d['SK']==0 and d['NZ']==2 and not d['DFX'] and not d['depgen']
        assert all(x==0 for x in d['fallback_calls'].values())
        assert d['root_abi']['tnd']['count']==62 and d['root_abi']['bsh']['count']==57
        assert all(c['bit_equal'] for c in d['comparisons']['tnd'].values())
        assert sha(D/'sources/threeway-formal-v4-profile/variant-env.sh')==v['variant_env_sha256']
        assert d['graphs']['tnd']['actual_acl_graph'] and d['graphs']['tnd']['fullgraph']
        assert all(d['routes'][arm]['capture_PTO_calls']>0 and d['routes'][arm]['Native_fallback_calls']==0 for arm in ('tnd','bsh'))
contract=json.loads((D/'sources/math/half-bf16-packet128-native-contract/results/v1/data/result.json').read_text())
assert contract['pass'] and contract['complete'] and len(contract['checks'])==69
assert all(v['bit_equal'] for v in contract['checks'])
assert contract['native_bank_sha256']=='b529583b21efa08dba414f0f3fad53a92858d40f3c5aed118c7f9c80c5ef74d8'
canonical=json.loads((D/'sources/formal-v4-package/canonical-identity.json').read_text())
assert canonical['pass'] and canonical['NPU_executed'] is False
for rel,record in canonical['records'].items():
    assert sha(D/'sources/formal-v4-package/patch'/rel)==record['new_sha256']
    assert record['all_retained_functions_classes_exact_actual_reference_AST']
print(json.dumps({'pass':True,'files':len(actual),'bytes':sum(p.stat().st_size for p in actual.values()),'raw_results':len(raws),'source_identity_comparisons':len(source_checks),'HF32_hardware_checks':69,'synthetic_JSON_bank_present':(D/'synthetic-gold/native-bank-bits.json').exists(),'no_pt_or_model_weights_or_binaries':True,'formal_3way_TND62_BSH57_SK0_NZ2':True,'private_results_not_relabeled_formal':True},ensure_ascii=False,indent=2))
