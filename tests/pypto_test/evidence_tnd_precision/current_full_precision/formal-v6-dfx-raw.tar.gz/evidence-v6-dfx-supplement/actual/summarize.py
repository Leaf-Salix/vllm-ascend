"""Summarize only after strict current-artifact three-window mapping passes."""
from pathlib import Path
import json,hashlib,statistics
P=Path(__file__).resolve().parent;d=json.loads((P/'analysis.json').read_text());assert len(d['windows'])==3 and all(w['all_actual_tokens_mapped'] for w in d['windows'])
HC={'hc_pre_widen','hc_pre_square_partial','hc_pre_native_rms','hcpre_hf32_weight','hcpre_input_panel','hcpre_bf16_half_exact8_m64','hcpre_bf16_half_exact8','hc_pre_linear_reduce','split_pre_post','comb_sinkhorn','mix_x'}
def category(name):
 if name in HC:return 'HC-pre'
 if name=='input_rms_fused':return 'InputNorm'
 if name.startswith('wkv'):return 'WKV'
 if name=='csa_checked_indices':return 'Checked indices'
 if name=='csa_slots_build_valid_qk_plan':return 'Slots plan'
 if name in ('qk_pv_aic','qk_pv_aiv'):return 'Sparse QK/PV'
 if name=='rope_cs':return 'RoPE cos/sin prepare (early)'
 if name in ('merge_norm','native_heads'):return 'Attention merge/heads finish'
 if name.startswith('oproj'):return 'O-proj'
 if name=='hc_post':return 'HC-post'
 if name.startswith('indexer_score_topk') or name.startswith('indexer_head_coefficients') or name.startswith('indexer_topk'):return 'Indexer score/TopK'
 return 'Other QKV/compressor/indexer preparation'
phases={};functions={};envelopes=[]
for w in d['windows']:
 grouped={}
 for f in w['functions']:
  functions.setdefault(f['name'],[]).append({'span_us':f['instrumented_span_us'],'mean_task_execution_us':f['mean_task_execution_us'],'executions':f['executions']})
  grouped.setdefault(category(f['name']),[]).append(f)
 envelopes.append(max(f['end_us'] for f in w['functions'])-min(f['start_us'] for f in w['functions']))
 for c,fs in grouped.items():phases.setdefault(c,[]).append({'span_us':max(f['end_us'] for f in fs)-min(f['start_us'] for f in fs),'start_us':min(f['start_us'] for f in fs),'end_us':max(f['end_us'] for f in fs),'functions':[f['name'] for f in fs]})
summary={'review_status':'PASS','scope':'current candidate-only instrumented timeline; phase envelopes may overlap and are not additive/formal latency/pure math/DMA attribution; no Native or Nal per-module DFX here','actual_artifact':d['artifact'],'three_windows_strict_token_core_count_PASS':True,'whole_instrumented_envelopes_us':envelopes,'phase_spans_us':{k:{'min':min(x['span_us'] for x in v),'mean':statistics.mean(x['span_us'] for x in v),'max':max(x['span_us'] for x in v),'windows':v} for k,v in phases.items()},'functions':functions,'raw_analysis_sha256':hashlib.sha256((P/'analysis.json').read_bytes()).hexdigest()}
(P/'phase-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for k,v in sorted(summary['phase_spans_us'].items(),key=lambda x:x[1]['mean'],reverse=True):print(k,round(v['min'],3),round(v['mean'],3),round(v['max'],3))
