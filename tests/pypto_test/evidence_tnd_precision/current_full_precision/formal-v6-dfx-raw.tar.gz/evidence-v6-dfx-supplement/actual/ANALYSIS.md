# V6 B40 最终三窗 DFX：实际映射通过

## 验证范围

任务 `task_20261019_071231_13930312492`，L4 真实权重、固定合成 hidden/history8191、B40/T240/S6，完整 HC-pre→HC-post，单卡 FULL graph。先 Native/TND A、B 两组输入的八个外部输出/cache/state 边界逐 bit 对拍；全部通过，FULL/raw、ABA、poison、写入 guard 和 root62 门禁通过。随后只采 TND 三窗，level4、dep-gen=false。

该采集只有候选的模块泳道；没有 Native/Nal 的模块泳道。它不能证明与 Nal 的某个模块相比差多少，也不能替代无插桩三方延迟或真实整模型吞吐。

## 实际 artifact 与映射

- Source manifest：`6d9656de4580ba5f768881c417f3093a7744808ac6518c594e9db881971e7ab2`。
- 实际 config：`e412c88c14cb87c45d6bae50f5d37a205f64d57921197e27270f8b1ac089e947`。
- 实际 orchestration：`3c595e656dc37ed385b616f6aa4c50e6541ee472d8d2438e0efb91a228751d5e`。
- 实际 orchestration 与预编文件 SHA 不同，首次严格绑定拒绝。独立审查确认执行体仅607个局部变量双射改名，新增的 ABI 静态断言与描述符函数位于执行体之外，没有改变计算、字面量、依赖或 alloc/submit 顺序。
- 对实际源码重新独立扫描，102个 alloc/dummy/submit 事件、67个内核 token 的 scope、func_id、source line、grid 全部匹配。修复了准备阶段 HC-post grid30→60 的计数错误后才接受。
- 实际结果绑定后，三窗每个实际 token、core type、执行数量全部 strict PASS。旧 V4 token 编号没有复用。

原始 artifact 中 `mapping_status=UNMAPPED...` 是捕获时的历史字段，保持原文；`reviewed-token-map.json` 与 `phase-summary.json` 的 reviewed PASS 是后续验收状态。

## 实测跨度

单位 µs，为每组相关任务从最早启动到最晚结束的活动包络，表中给出三窗 min～max。包络可以包含排队/等待、重叠和空隙，不能相加，也不能解释成纯计算或纯搬运时间。

| 部分 | 三窗活动跨度 |
| --- | ---: |
| Q/KV、compressor、Indexer 前置准备合成包络 | 830.10～859.02 |
| Sparse QK/PV 融合 task | 686.52～699.74 |
| O-proj | 357.08～362.30 |
| HC-pre | 344.24～369.00 |
| WKV 投影及舍入 | 111.38～213.36 |
| Indexer coefficient/score/TopK publish | 136.28～154.28 |
| Checked indices | 107.48～109.36 |
| Attention merge/heads 收尾 | 74.08～75.60 |
| InputNorm | 55.36～61.98 |
| HC-post | 35.96～40.06 |
| Slots plan | 17.70～18.30 |

Q/KV 等合成包络覆盖多个准备模块，不能当成一个待优化算子。QK/PV 是当前最长的单个融合 task：48个 AIV 的平均 task 生命周期为682.90～688.49 µs，24个 AIC 为681.05～686.75 µs；二者有同步/等待，不能把这些时间都归为数学运算。

HC-pre 内部，widen 为109.26～135.30 µs，input-pack 为119.18～156.08 µs；HC linear M64 只有28.64～32.22 µs。O-proj 的 A 阶段为146.40～149.86 µs，B64 为109.30～113.40 µs。

整体三窗插桩包络为2356.40、2368.14、2324.98 µs。正式无DFX三方 B40 的 TND 均值2391.330 µs、Native1393.111 µs、Nal1272.611 µs另见三方报告；不得把插桩包络混作正式延迟。

## 后续方向与限制

1. 优先评估 QK/PV 的搬运和核内流水，保留 Native 的 K512 softmax、归约/online 更新与所有 BF16/量化舍入边界。当前证据足以确定其 task 生命周期大，尚未把内部计算和等待分离，不能直接改变求和树。
2. HC-pre 若继续优化，应先看 widen/input-pack/静态布局准备及任务粒度，继续优化约31 µs的 linear 已不是首要空间。任何静态缓存或 hoist 都需资格/失效和相同位结果门禁，现有跨度不能证明总延迟收益。
3. O-proj 的 A/B Cube 仍各占约148/111 µs；进一步尝试必须保留动态量化的原始舍入边界。
4. 该 profile 是8K、单个L4、uniform S6 的候选观察，不能外推整模型128K或不等长请求的性能。新的优化仍须单因素、无DFX同卡对照和整模型精度验收。

本次只做观察、解析和文本证据归档，没有更改 runtime、SDK、生产源码或提交新的 NPU 任务。
