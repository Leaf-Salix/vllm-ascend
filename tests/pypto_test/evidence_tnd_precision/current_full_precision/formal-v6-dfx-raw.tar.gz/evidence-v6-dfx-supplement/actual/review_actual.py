"""Review the captured orchestration body; do not edit raw artifact bytes."""
from pathlib import Path
import re,json,hashlib
P=Path(__file__).resolve().parent;R=P.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=R/'formal-v6-generated-review/full/orchestration/_full_csa_tnd.cpp';b=P/'data/current-artifact/orchestration.cpp';raw=b.read_text();marker='#include <type_traits>';assert raw.count(marker)==1;body,footer=raw.split(marker,1)
# This recognized runtime attachment is outside the complete orchestration body.
assert re.fullmatch(r'\s*static_assert\(std::is_same_v<decltype\(&aicpu_orchestration_entry\), void \(\*\)\(const ChipTaskArgs&\)>\);\s*extern "C" __attribute__\(\(visibility\("default"\)\)\)\s*const char\* pypto_kernel_abi_descriptor\(\) \{ return "pypto-kernel-abi-v1:[0-9a-f]{64}"; \}\s*',footer),footer

def canonical(s):
 ids={}
 def rename(m):
  name=m.group()
  if '_inline' in name or re.match(r't__tmp_v\d+',name):
   if name not in ids:ids[name]='GENERATED_'+str(len(ids))
   return ids[name]
  return name
 s=re.sub(r'//[^\n]*','',s);s=re.sub(r'\b[A-Za-z_]\w*\b',rename,s)
 return re.sub(r'\s+','',s),ids
x,ax=canonical(a.read_text());y,by=canonical(body);assert x==y and len(ax)==len(by)==607
mapping=dict(zip(ax,by));assert len(set(mapping.values()))==len(mapping)
# Numeric literals/operators, every argument/alias/control-flow statement and
# all submit/alloc order are identical. Scope/line count before each submit is
# unchanged; footer adds no scheduling operation.
for op in ('alloc_tensors','rt_submit_aic_task','rt_submit_aiv_task','rt_submit_task','rt_submit_dummy_task','SIMPLER_SCOPE'):
 assert a.read_text().count(op+'(')==body.count(op+'('),op
review={'pass':True,'actual_source_orchestration_sha256':sha(b),'precompiled_source_orchestration_sha256':sha(a),'config_sha256':sha(P/'data/current-artifact/kernel_config.py'),'generated_identifiers_bijective_count':607,'orchestration_body_exact_after_bijective_generated_local_rename':True,'runtime_ABI_descriptor_outside_body_only':True,'runtime_ABI_attachment':marker+footer,'reference_to_actual_generated_names':mapping,'raw_artifact_bytes_modified':False}
(P/'ORCHESTRATION_ALPHA_REVIEW.json').write_text(json.dumps(review,indent=2)+'\n')
ref=R/'dfx-formal-v6-map/reference-token-map.json';m=json.loads(ref.read_text());assert m['complete'] is False;m['precompiled_reference_map_sha256']=sha(ref);m['orchestration_sha256']=sha(b);m['config_sha256']=review['config_sha256'];m['actual_alpha_proof_sha256']=sha(P/'ORCHESTRATION_ALPHA_REVIEW.json');m['scope']='captured actual V6 orchestration reviewed; await independent exact-map review plus strict DFX counts';(P/'actual-token-map-candidate.json').write_text(json.dumps(m,indent=2)+'\n')
print('ACTUAL_CAPTURE_BODY_REVIEW_PASS; independent review and strict counts still required')
print('ACTUAL_MAP_SHA',sha(P/'actual-token-map-candidate.json'))
