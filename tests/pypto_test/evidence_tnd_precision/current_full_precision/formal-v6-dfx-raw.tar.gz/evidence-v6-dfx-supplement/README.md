# V6 最终 B40 三窗 DFX 增补包

本包保存最终实际三窗原始 JSON、live artifact 的 orchestration/config、绑定后的 accepted token-map、strict 解析结果和两次独立审查。Native/TND A、B 两组输入的八个外部边界全部逐 bit 一致，FULL/raw、ABA、poison、guard 与 root62 均通过。

每窗67个内核 token / 2815条硬件任务，token/core type/grid 数量全部 strict PASS；独立 reviewer 又直接从三份原始 trace 复算，计数、span、mean-task-duration 一致。只读实际 config/orchestration，未套旧V4编号。捕获时原始 UNMAPPED 字样和 complete=false 的候选 map 保留为过程记录；最终以 `actual/reviewed-token-map.json` 的 complete=true、`actual/phase-summary.json` 的 reviewed PASS 和独立最终分析审查为准。

实际 config SHA 为 `e412c88c14cb87c45d6bae50f5d37a205f64d57921197e27270f8b1ac089e947`，orchestration SHA为 `3c595e656dc37ed385b616f6aa4c50e6541ee472d8d2438e0efb91a228751d5e`。与预编文件差异是607局部变量双射改名和执行体外的ABI导出附加，独立检查确认所有运算/字面量/事件/依赖不变。

## 当前实测活动跨度

单位µs，三窗min～max，均为插桩包络：

| 模块 | 范围 |
| --- | ---: |
| Sparse QK/PV | 686.52～699.74 |
| O-proj | 357.08～362.30 |
| HC-pre | 344.24～369.00 |
| Checked indices | 107.48～109.36 |
| InputNorm | 55.36～61.98 |
| HC-post | 35.96～40.06 |

HC内部widen109.26～135.30、input-pack119.18～156.08，而linear M64仅28.64～32.22。O-proj A146.40～149.86、B64 109.30～113.40。完整解释和限制见 `actual/ANALYSIS.md`。

这是8K、L4真实权重、固定合成hidden、B40/T240/S6的candidate-only观察。包络可能含排队/同步/空隙、相互重叠，不能相加、不能当正式延迟或纯计算/纯搬运耗时；这里没有Nal/Native模块泳道，不能称Nal分模块差值。QK/PV是最大的单个融合task生命周期，后续优先尝试不改Native K512/舍入树的搬运/核内流水，但仍需单因素、无DFX计时和数值门禁。

## 解析复现

只用标准Python，解压后在本包目录执行：

```bash
python tools/analyze_dfx.py --run actual/data --token-map actual/reviewed-token-map.json --out /tmp/v6-dfx-recheck.json
```

成功应打印 `THREE_WINDOWS_MAPPED actual artifact SHA/count/core checks passed`。实际任务采集命令由原基础包的 `dfx-formal-v6-b40/run-pinned-v6.sh` 提供；本包没有再次提交任务，也没有更改runtime或生产源码。

本包不重复旧基础包或B4增补包，名称和SHA在 `BASE_ARCHIVE_REFERENCE.json`。只包含UTF-8 JSON/Python/Markdown/实际生成C++文本；没有权重、.pt、ELF/SO、cache、模型或设备二进制。归档逐文件SHA并tar回读校验。
