"""DFX final text-only supplement; previous archives remain immutable."""
from pathlib import Path
import hashlib,json,shutil,tarfile,gzip,io
P=Path(__file__).resolve().parent;R=P.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();allowed={'.json','.py','.md','.txt','.cpp'}
refs=[]
for name,expected in [('evidence-v6-kernel-threeway-pre-dfx-20261019.tar.gz','37456f91e91c06d5acd856d16f1045d677af75073cce5114f8cf2cd1039624c5'),('evidence-v6-threeway-b4-supplement-20261019.tar.gz','cee990ee89d31c79ac8cca6c006dcc84d00a4659e27911f583aa109e8c8dafc9')]:
 src=R/name;assert sha(src)==expected;refs.append({'name':name,'sha256':expected,'bytes':src.stat().st_size,'repackaged':False})
(P/'BASE_ARCHIVE_REFERENCE.json').write_text(json.dumps({'source_manifest_sha256':'6d9656de4580ba5f768881c417f3093a7744808ac6518c594e9db881971e7ab2','archives':refs},indent=2)+'\n')
payload=P/'payload';assert not payload.exists();payload.mkdir();files={}
def add(src,name):
 assert src.is_file() and not src.is_symlink() and src.suffix.lower() in allowed and '..' not in Path(name).parts
 data=src.read_bytes();data.decode('utf-8');assert b'\x00' not in data
 dst=payload/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data);files[str(name)]={'sha256':sha(dst),'bytes':len(data)}
for folder,prefix in [('dfx-formal-v6-actual','actual'),('review-dfx-formal-v6-actual','independent-review'),('dfx-formal-v6-map','map-preparation')]:
 for src in sorted((R/folder).rglob('*')):
  if src.is_file() and src.suffix.lower() in allowed and '__pycache__' not in src.parts:add(src,Path(prefix)/src.relative_to(R/folder))
for name in ('analyze_dfx.py','capture_artifact.py','inventory_mapping.py'):add(R/'dfx-formal-v6-b40'/name,Path('tools')/name)
for name in ('README.md','BASE_ARCHIVE_REFERENCE.json','build_archive.py'):add(P/name,Path(name))
add(R/'formal-v6-bindings/binding.json',Path('source43-binding.json'))
result=json.loads((payload/'actual/data/result.json').read_text());analysis=json.loads((payload/'actual/analysis.json').read_text());m=json.loads((payload/'actual/reviewed-token-map.json').read_text());review=json.loads((payload/'independent-review/DFX_ANALYSIS_REVIEW.json').read_text())
assert result['complete'] and result['pass'] and m['complete'] and review['pass'];assert len(analysis['windows'])==len(review['windows'])==3 and all(w['all_actual_tokens_mapped'] for w in analysis['windows']);assert len(m['entries'])==67
assert all(w['tokens']==67 and w['task_count']==2815 and w['all_token_core_counts_exact'] for w in review['windows'])
manifest={'scope':'final candidate-only V6 B40 actual three-window DFX supplement; not formal latency/Nal module comparison','no_models_tensors_binaries_caches':True,'previous_archives_repackaged_or_changed':False,'root_ABI':62,'actual_config_sha256':m['config_sha256'],'actual_orchestration_sha256':m['orchestration_sha256'],'actual_three_windows_tokens_per_window':67,'actual_tasks_per_window':2815,'raw_Native_TND_A_B_bit_gates_pass':True,'strict_and_independent_analysis_pass':True,'files':files,'file_count':len(files),'payload_bytes':sum(x['bytes'] for x in files.values())};(payload/'ARCHIVE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=R/'evidence-v6-dfx-final-20261019.tar.gz';assert not archive.exists()
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for src in sorted(payload.rglob('*')):
    if not src.is_file():continue
    data=src.read_bytes();info=tarfile.TarInfo('evidence-v6-dfx-supplement/'+src.relative_to(payload).as_posix());info.size=len(data);info.mode=0o644;info.uid=info.gid=info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers()
 for m in members:
  assert m.isfile() and not m.issym() and '..' not in Path(m.name).parts and Path(m.name).suffix in allowed;rel=Path(m.name).relative_to('evidence-v6-dfx-supplement').as_posix();data=tar.extractfile(m).read();data.decode('utf-8')
  if rel!='ARCHIVE_MANIFEST.json':assert hashlib.sha256(data).hexdigest()==files[rel]['sha256']
ready={'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'payload_files':len(files)+1,'payload_bytes':manifest['payload_bytes'],'whitelist_and_SHA_readback_PASS':True,'prior_archives_unchanged':True};(P/'ARCHIVE_READY.json').write_text(json.dumps(ready,indent=2)+'\n');print(json.dumps(ready,indent=2))
