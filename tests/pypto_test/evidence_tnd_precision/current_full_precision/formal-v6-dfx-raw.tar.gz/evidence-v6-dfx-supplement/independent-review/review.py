"""独立词法双射及actual调度trace复核；不读取作者alpha映射生成结论。"""
import hashlib,json,re
from pathlib import Path
H=Path(__file__).resolve().parent;R=H.parent
old=R/'formal-v6-generated-review/full/orchestration/_full_csa_tnd.cpp'
actual=R/'dfx-formal-v6-actual/data/current-artifact';new=actual/'orchestration.cpp'
reference=R/'dfx-formal-v6-actual/actual-token-map-candidate.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
oldtext=old.read_text();newtext=new.read_text();body,sep,footer=newtext.partition('#include <type_traits>');assert sep
expectedfooter=r'\s*static_assert\(std::is_same_v<decltype\(&aicpu_orchestration_entry\), void \(\*\)\(const ChipTaskArgs&\)>\);\s*extern "C" __attribute__\(\(visibility\("default"\)\)\)\s*const char\* pypto_kernel_abi_descriptor\(\) \{ return "pypto-kernel-abi-v1:319e3efb5cb4fc5fa6d00c36e7f311eb109fa085210854cc1235b74bbe2b1e5e"; \}\s*'
assert re.fullmatch(expectedfooter,footer)
# Token alignment preserves every non-generated identifier, operator, literal
# and string; only the generated local-name family may form a bijection.
lex=re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[A-Za-z_]\w*|\d+(?:\.\d*)?|[^\s]')
def tokens(s):return lex.findall(re.sub(r'/\*.*?\*/|//[^\n]*','',s,flags=re.S))
a,b=tokens(oldtext),tokens(body);assert len(a)==len(b)
islocal=lambda s:bool(re.fullmatch(r'[A-Za-z_]\w*',s) and ('_inline' in s or re.match(r't__tmp_v\d+',s)))
forward,reverse={},{}
for x,y in zip(a,b,strict=True):
 if islocal(x):
  assert islocal(y)
  if x in forward:assert forward[x]==y
  if y in reverse:assert reverse[y]==x
  forward[x]=y;reverse[y]=x
 else:assert x==y,(x,y)
assert len(forward)==len(reverse)==607
# Names being changed must be declared in this orchestration; no external
# symbol, type, API selector or function name can silently be renamed.
for name in forward:
 assert re.search(r'(?:int64_t|int32_t|uint32_t|Tensor|TensorCreateInfo|TaskId)\s*(?:&\s*)?'+re.escape(name)+r'(?:\b|\[)',oldtext),name
for name in reverse:
 assert re.search(r'(?:int64_t|int32_t|uint32_t|Tensor|TensorCreateInfo|TaskId)\s*(?:&\s*)?'+re.escape(name)+r'(?:\b|\[)',body),name
m=json.loads(reference.read_text());prior=json.loads((R/'dfx-formal-v6-map/reference-token-map.json').read_text())
assert not m['complete'];assert sha(reference)=='907a7eec72a4edd5fa4c0fa4e93bc096a935da989c46096405eeb76b2f5a32b2'
assert m['precompiled_reference_map_sha256']==sha(R/'dfx-formal-v6-map/reference-token-map.json')
assert m['orchestration_sha256']==sha(new) and m['config_sha256']==sha(actual/'kernel_config.py')
assert m['entries']==prior['entries'] and m['trace']==prior['trace'] and m['case']==prior['case']
assert sha(actual/'kernel_config.py')==sha(R/'formal-v6-generated-review/full/kernel_config.py')
# Independently reuse the reviewer-owned lexical scope/event scanner on the
# captured body, not author prepare_map/review_actual. Its source path is replaced
# only in this in-memory execution; neither raw artifacts nor files are changed.
owned=(R/'review-dfx-formal-v6-map/review.py').read_text();start=owned.index('# Scan lexical braces;');end=owned.index("assert entries==m['entries']")
namespace={'source':body,'m':m,'re':re,'Counter':__import__('collections').Counter,
 'exclude_tasks':{6,12,46,47,48,49,52,53,54,56,65,68},'exclude_allocs':{21,22,24,25},
 'expected_grids':json.loads((R/'review-dfx-formal-v6-map/results.json').read_text())['selected_source_grid_table']}
namespace['expected_grids']={int(k):v for k,v in namespace['expected_grids'].items()}
import ast
config=ast.parse((actual/'kernel_config.py').read_text());ks=next(ast.literal_eval(n.value) for n in config.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='KERNELS' for t in n.targets));namespace['byid']={k['func_id']:k for k in ks}
exec(compile(owned[start:end],'reviewer_lexical_actual_scope_trace','exec'),namespace)
assert namespace['entries']==m['entries']
key=lambda e:tuple(map(int,e['token'].split(':')))
assert sorted(namespace['trace'],key=key)==sorted(m['trace'],key=key)
r={'pass':True,'reference_map_sha256':sha(reference),'actual_config_sha256':sha(actual/'kernel_config.py'),'actual_orchestration_sha256':sha(new),'precompiled_orchestration_sha256':sha(old),'generated_local_bijection_count':607,'all_nonlocal_tokens_and_control_flow_literals_exact':True,'all_renamed_identifiers_declared_locally':True,'ABI_footer_signature_and_descriptor_checked':True,'actual_events_independently_reconstructed':102,'actual_kernel_tokens':67,'actual_source_lines_scope_tokens_funcids_counts_exact':True,'complete_in_candidate_map_still_false':True,'raw_artifact_modified':False,'NPU_or_compile_executed':False,'qualification_limit':'Independent actual-source review only; bind successful current result and run strict three-window type/count analyzer before treating mapping as accepted live DFX.'}
(H/'results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
