"""Independent raw swimlane task decoding and key envelopes; no formal timing."""
import ast,collections,hashlib,json,math,statistics
from pathlib import Path
H=Path(__file__).resolve().parent;R=H.parent;P=R/'dfx-formal-v6-actual';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((P/'reviewed-token-map.json').read_text());a=json.loads((P/'analysis.json').read_text());s=json.loads((P/'phase-summary.json').read_text())
assert m['complete'] and m['review_status']=='PASS' and s['review_status']=='PASS'
assert a['token_map_sha256']==sha(P/'reviewed-token-map.json')
assert s['raw_analysis_sha256']==sha(P/'analysis.json')
assert m['independent_review_sha256']==sha(H/'results.json')
assert m['actual_result_sha256']==sha(P/'data/result.json')
cfg=P/'data/current-artifact/kernel_config.py';t=ast.parse(cfg.read_text());ks=next(ast.literal_eval(n.value) for n in t.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='KERNELS' for x in n.targets));byid={k['func_id']:k for k in ks}
assert sha(cfg)==m['config_sha256'] and sha(P/'data/current-artifact/orchestration.cpp')==m['orchestration_sha256']
assert len(a['windows'])==3
HC={'hc_pre_widen','hc_pre_square_partial','hc_pre_native_rms','hcpre_hf32_weight','hcpre_input_panel','hcpre_bf16_half_exact8_m64','hcpre_bf16_half_exact8','hc_pre_linear_reduce','split_pre_post','comb_sinkhorn','mix_x'}
phases={'Sparse QK/PV':{'qk_pv_aic','qk_pv_aiv'},'HC-pre':HC,'O-proj':{k['name'] for k in ks if k['name'].startswith('oproj')}}
small=['hcpre_bf16_half_exact8_m64','hc_pre_widen','hcpre_input_panel']
spans={x:[] for x in [*phases,*small]};windows=[]
for w in a['windows']:
 rawpath=Path(w['path']);raw=json.loads(rawpath.read_text());assert sha(rawpath)==w['sha256']
 freq=raw['metadata']['clock_freq_hz'];types=raw['metadata']['core_types'];counts={};functions={}
 for core,token,taskid,start,end,*rest in raw['aicore_tasks']:
  key=f'{token>>32}:{token&0xffffffff}';assert key in m['entries'],key
  kind=types[core];entry=m['entries'][key]
  counts.setdefault(key,collections.Counter())[kind]+=1
  ids=[f for f in entry['func_ids'] if byid[f]['core_type']==kind];assert len(ids)==1
  name=byid[ids[0]]['name'];functions.setdefault(name,[]).append((start,end))
 assert len(counts)==67 and counts.keys()==m['entries'].keys()
 for key,values in counts.items():assert dict(values)==m['entries'][key]['expected_executions'],(key,values)
 def envelope(names):
  ts=[v for n in names for v in functions.get(n,[])];assert ts
  return (max(v[1] for v in ts)-min(v[0] for v in ts))*1e6/freq
 expected={f['name']:f for f in w['functions']};assert functions.keys()==expected.keys()
 for name,ts in functions.items():
  assert len(ts)==expected[name]['executions']
  assert math.isclose(envelope({name}),expected[name]['instrumented_span_us'],abs_tol=1e-9)
  assert math.isclose(statistics.mean((e-b)*1e6/freq for b,e in ts),expected[name]['mean_task_execution_us'],abs_tol=1e-9)
 for label,names in phases.items():
  value=envelope(names);spans[label].append(value)
  assert math.isclose(value,s['phase_spans_us'][label]['windows'][len(windows)]['span_us'],abs_tol=1e-9)
 for name in small:spans[name].append(envelope({name}))
 windows.append({'raw':str(rawpath),'raw_sha256':sha(rawpath),'tokens':len(counts),'task_count':sum(sum(c.values()) for c in counts.values()),'all_token_core_counts_exact':True})
out={'pass':True,'raw_three_window_count_and_span_independent_review':True,'windows':windows,'key_envelope_ranges_us':{k:{'min':min(v),'max':max(v),'windows':v} for k,v in spans.items()},'limitations':['Candidate-only instrumented phase envelopes, potentially overlapping and not additive.','Not formal replay latency or pure compute/DMA wait attribution.','No Native/Nal module DFX baseline here; cannot call these Native/Nal per-module gap.','Original capture artifact mapping_status UNMAPPED is retained historical raw metadata; reviewed map+strict actual verification supplies current PASS.'],'hashes':{'reviewed_map':sha(P/'reviewed-token-map.json'),'analysis':sha(P/'analysis.json'),'phase_summary':sha(P/'phase-summary.json')},'NPU_compile_or_raw_mutation_performed':False}
(H/'DFX_ANALYSIS_REVIEW.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
