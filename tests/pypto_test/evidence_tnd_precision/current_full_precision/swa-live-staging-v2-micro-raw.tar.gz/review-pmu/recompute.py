"""Independent CPU recomputation of three pilot PMU captures, no device calls."""
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import statistics

R = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
aggregate = json.loads((R / "PMU_AGGREGATE.json").read_text())
columns = ["pmu_total_cycles", "vec_busy_cycles", "cube_busy_cycles", "scalar_busy_cycles", "mte1_busy_cycles", "mte2_busy_cycles", "mte3_busy_cycles"]
expected = set()
for i in range(3):
    expected.add(f"run{i}.Native.pre_inverse_heads")
    expected.update(f"run{i}.baseline_PTO.{s}" for s in ("mi", "li", "oi", "heads"))
    expected.update(f"run{i}.readonly.{j}" for j in range(12))
    if i:
        expected.update(f"run{i}.repeat.{s}" for s in ("mi", "li", "oi", "heads"))
assert len(expected) == 59
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
result = {"pass": True, "scope": "Independent CPU audit of existing raw PMU; no new hardware", "runs": {}}
for name in ("pmu-baseline", "pmu-read-only", "pmu-live-staging"):
    data = R / "pmu/results" / name / "data"
    report = json.loads((data / "result.json").read_text())
    assert report["pass"] is True and report["complete"] is True
    assert len(report["checks"]) == 59 and {x["label"] for x in report["checks"]} == expected
    assert all(x["bit_equal"] is True and x["different_bytes"] == 0 for x in report["checks"])
    assert report["event"] == 2 and [x["pmu"] for x in report["runs"]] == [0, 0, 2]
    rows = list(csv.DictReader((data / "pmu-2.csv").open()))
    counts = Counter((x["func_id"], x["core_type"], x["event_type"]) for x in rows)
    assert counts[("3", "0", "2")] == 24 and counts[("4", "1", "2")] == 48
    groups = {}
    for fid, size in (("3", 24), ("4", 48)):
        selected = [x for x in rows if x["func_id"] == fid]
        assert len(selected) == size and len({x["core_id"] for x in selected}) == size
        assert all(int(x["pmu_total_cycles"]) > 0 for x in selected)
        mean = {k: statistics.mean(int(x[k]) for x in selected) for k in columns}
        assert mean == aggregate[name]["cores"][fid]
        groups[fid] = {"count": size, "mean": mean, "min": {k: min(int(x[k]) for x in selected) for k in columns}, "max": {k: max(int(x[k]) for x in selected) for k in columns}}
    assert report["task_device"] == aggregate[name]["task_device"]
    assert sha(data / "pmu-2.csv") == aggregate[name]["pmu_sha"]
    assert report["helper_manifest_sha256"] == aggregate[name]["helper_sha"]
    result["runs"][name] = {"task_device": report["task_device"], "result_sha": sha(data / "result.json"), "pmu_sha": sha(data / "pmu-2.csv"), "helper_sha": report["helper_manifest_sha256"], "checks": 59, "groups": groups}

base = result["runs"]["pmu-baseline"]
read = result["runs"]["pmu-read-only"]
assert base["task_device"] == read["task_device"] == "9"
result["same_card9_read_only_delta_percent"] = {fid: {k: (read["groups"][fid]["mean"][k] / base["groups"][fid]["mean"][k] - 1) * 100 for k in columns if base["groups"][fid]["mean"][k]} for fid in ("3", "4")}
result["restrictions"] = ["One PMU window per variant, not repeated evidence", "live_staging on card8; never attribute cross-card differences to a stage", "Busy counters overlap and must not be added as stage latency", "Numerical evidence limited to captured B4 fixture; host-only read-only checks"]
(OUT / "results.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"pass": True, "checks_per_arm": 59, "AIC_AIV_counts": [24, 48], "card9_read_only_delta_percent": result["same_card9_read_only_delta_percent"]}, indent=2))
