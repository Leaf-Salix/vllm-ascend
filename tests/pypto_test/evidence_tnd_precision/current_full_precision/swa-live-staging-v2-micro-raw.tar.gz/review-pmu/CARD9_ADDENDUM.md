# 同卡9补测及结论边界

`recompute_card9.py` 已实际执行 PASS；本次读取现有文本结果，没有提交任务。新 live_staging 的59项完整数值门禁通过，181行PMU、24唯一AIC及48唯一AIV正计数均核实；bank、helper及编译receipt与此前卡8的live任务完全相同。原卡8记录保留，不再用其作同卡阶段归因。

| 每核平均 cycles | baseline 卡9 | read_only 卡9 | live_staging 卡9 |
| --- | ---: | ---: | ---: |
| AIC total | 120100.833 | 129344.208 | 127422.792 |
| AIC Cube busy | 11580.833 | 11570.000 | 11579.167 |
| AIC MTE1 busy | 13570.625 | 13551.125 | 13567.375 |
| AIC MTE2 busy | 23752.875 | 19610.833 | 25559.583 |
| AIV total | 123763.667 | 134147.125 | 131607.896 |
| AIV Vector busy | 35283.104 | 35323.583 | 34499.813 |
| AIV Scalar busy | 47009.917 | 48410.313 | 43667.063 |
| AIV MTE2 busy | 22193.813 | 23062.875 | 23301.313 |
| AIV MTE3 busy | 16970.688 | 17953.313 | 14481.229 |

## 已观察到的计数

完整候选的 AIC MTE2 busy 比 baseline **增加7.61%**，比read_only增加30.33%；AIV MTE2 busy比baseline增加4.99%。所以“完整候选降低了 MTE2 busy”不成立，不能沿用AIC-only的-17.44%表述。

同一候选窗口里，AIV Vector busy比baseline减少2.22%，Scalar busy减少7.11%，MTE3 busy减少14.67%。AIC Cube/MTE1接近不变。以上是实测计数，不能当作阶段耗时，也没有证据把差异精确拆成固定加载、等待、softmax各占多少；不以total减busy求wait，不把多个busy求和。

尤其read_only与live_staging的AIC生成函数去注释后逐字相同，load地址、执行分支及固定fixture也相同，而MTE2 busy相差30.33%。这说明**该busy不是执行字节数或固定指令条数的替代量**；配套AIV生产时机、共享内存系统、cache/争用以及任务窗口状态都可能影响占用持续时间，目前未测出唯一原因。不能从这个差异反推候选偷偷多读了30%数据。

## 能确定删掉的工作

静态源与真实生成物共同证明：对有live SWA block的每个query，QK原四片K128只保留part0。

- AIC少3×128×512×2 = **384 KiB逻辑GM→L1 gather数据量**。
- AIV少相同 **384 KiB逻辑GM写入数据量**，以及对应无消费者片的页解析、全tile零填充和store。两个half各64行，合计128行；part0完整+0仍保留。
- 本B4/T24且所有SWA有效时，两方向各少9 MiB逻辑传输；该数字是DSL/生成加载范围推导，不是PMU测出的HBM流量，cache可能使实际HBM不同。
- Compressed staging、PV part0重载、固定carrier容量和四项跨核同步不变。

这次不是softmax算法优化。score仍按live128+显式+0 tail384组成K512；softmax掩码、row max、FP32 exp、Native求和树、BF16 CAST_ROUND、online更新和最终归一化全部保留。Vector busy的少量下降可与删除KV零填充/搬运相关，但不能将其归为softmax或归约数学工作减少。

## 与无PMU graph的关系

四次同卡9无PMU graph已独立复算：B4收益1.381%/3.236%，B40收益3.378%/1.703%，76/80正，四个事前配对区间下界均为正。它们支持当前隔离sparse root的微小稳定收益；PMU单窗口total没有下降与此不是同一测量配置，不应选择性忽略任一结果，也不能把PMU总周期直接转换成无PMU graph微秒。

因此目前可成立的结论是：**数值保持、无消费者KV staging确实减少、隔离sparse graph重复测得小幅收益；MTE2 busy下降和整模型收益尚未成立。**

## 新whole身份

`candidate-metadata.json` 明确新source `808dceaf50c53f40a495329c3f1711503e5bf9c84e258e84e1b9a5806f95a5b3`、Sparse `782355875150e92f27ab40c00dbcc4c420fe12a8ab955c4430f07d3de36a7a56`、helper `80046a0f3a9e47b8c2af60e5cc1abf480b2c94a0d908ad5568036a3af278fa58`。43源表与原基准只差Sparse；ABI62、3365文件、基准7078均保留，NPU_executed为false且whole资格pending。这是准备身份，不把微测结果充当正式入口或整模型通过。

完整CSA与8K/128K模型资格须按新正式字节重新验证；本附录不提前标记通过。
