"""Audit existing same-card live-staging PMU without device calls."""
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import statistics

R = Path(__file__).resolve().parents[1]
O = Path(__file__).resolve().parent
p = R / "pmu-card9/data/result.json"
d = json.loads(p.read_text())
old = json.loads((R / "pmu/results/pmu-live-staging/data/result.json").read_text())
assert d["pass"] is True and d["complete"] is True and d["variant"] == "live_staging"
assert d["task_device"] == "9" and d["helper_manifest_sha256"] == old["helper_manifest_sha256"]
assert len(d["checks"]) == 59 and d["checks"] == old["checks"]
assert all(x["bit_equal"] is True and x["different_bytes"] == 0 for x in d["checks"])
assert d["event"] == 2 and [x["pmu"] for x in d["runs"]] == [0, 0, 2]
assert d["bank_sha"] == old["bank_sha"] and d["artifact_manifest"] == old["artifact_manifest"]
rows = list(csv.DictReader((p.parent / "pmu-2.csv").open()))
assert len(rows) == 181
groups = {}
columns = ["pmu_total_cycles", "vec_busy_cycles", "cube_busy_cycles", "scalar_busy_cycles", "mte1_busy_cycles", "mte2_busy_cycles", "mte3_busy_cycles"]
for fid, kind, n in (("3", "0", 24), ("4", "1", 48)):
    s = [x for x in rows if x["func_id"] == fid]
    assert len(s) == n and len({x["core_id"] for x in s}) == n
    assert all(x["core_type"] == kind and x["event_type"] == "2" and int(x["pmu_total_cycles"]) > 0 for x in s)
    groups[fid] = {k: statistics.mean(int(x[k]) for x in s) for k in columns}
previous = json.loads((O / "results.json").read_text())
delta = {}
for name in ("pmu-baseline", "pmu-read-only"):
    reference = previous["runs"][name]
    assert reference["task_device"] == "9"
    delta[name] = {fid: {k: (groups[fid][k] / reference["groups"][fid]["mean"][k] - 1) * 100 for k in columns if reference["groups"][fid]["mean"][k]} for fid in ("3", "4")}
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
out = {"pass": True, "hardware_executed_by_this_audit": False, "card": "9", "checks": 59, "groups": groups, "live_delta_percent": delta, "result_sha": sha(p), "pmu_sha": sha(p.parent / "pmu-2.csv"), "helper_sha": d["helper_manifest_sha256"], "exact_same_artifact_receipt_as_card8_live": True, "interpretation": "MTE2 busy did not decrease for the complete live candidate. Busy cycles are not byte traffic, overlap and are not phase latency."}
(O / "card9-results.json").write_text(json.dumps(out, indent=2) + "\n")
print(json.dumps(out, indent=2))
