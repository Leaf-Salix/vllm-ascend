# SWA live staging：首轮 PMU 独立复算

## 数据审核

`recompute.py` 只读取已有文本结果及 CSV，实际 CPU 执行通过，未提交任务。三份结果全部 complete/pass，每份严格核对原 59 个唯一检查名称、`different_bytes=0`、两次无 PMU 后一次 event2；均通过 Native BF16 heads、基准 PTO FP32 mi/li/oi、重复运行以及 host 输入不变门禁。

每份 PMU 均有 24 个唯一 AIC（func3/core_type0）和 48 个唯一 AIV（func4/core_type1）的正周期记录，总 CSV 181 行。重新按 func 聚合所有七项计数，和 `PMU_AGGREGATE.json` 完全相同。CSV、结果、助手 SHA 均保存在本目录 `results.json`。

这证明当前 B4 固定 bank 的数值门禁通过，不证明整模型或其他请求形状。mi/li/oi 黄金来自原 PTO；Native 的内部统计量没有直接导出，Native heads 是另一条独立对照。readonly 门禁仅针对 host CPU 参数。

## 原始计数

单位为每核平均 cycles，**不能把各 busy 相加当作阶段耗时**；计数可以重叠，而且没有直接观测 transfer wait。

| 指标 | baseline，卡9 | read_only，卡9 | live_staging，卡8 |
| --- | ---: | ---: | ---: |
| AIC total | 120100.833 | 129344.208 | 124801.125 |
| AIC Cube busy | 11580.833 | 11570.000 | 11575.000 |
| AIC Scalar busy | 23262.292 | 26888.333 | 23361.250 |
| AIC MTE1 busy | 13570.625 | 13551.125 | 13559.250 |
| AIC MTE2 busy | 23752.875 | 19610.833 | 24479.250 |
| AIV total | 123763.667 | 134147.125 | 129628.979 |
| AIV Vector busy | 35283.104 | 35323.583 | 34516.979 |
| AIV Scalar busy | 47009.917 | 48410.313 | 40954.000 |
| AIV MTE2 busy | 22193.813 | 23062.875 | 22735.583 |
| AIV MTE3 busy | 16970.688 | 17953.313 | 13568.521 |

## 能得出的结论

同卡9 baseline→read_only：

- AIC MTE2 busy 减少 **17.44%**，符合只删去无消费者 SWA QK 搬运这一方向。
- Cube busy -0.09%、MTE1 busy -0.14%、AIV Vector busy +0.11%，接近不变，与数学及 AIV 核体未修改的生成物证据相符。
- **AIC total 增加7.70%，AIV total增加8.39%**。当前单次窗口没有显示执行总周期收益，不能把减少搬运等同为缩短关键路径。
- AIC Scalar busy +15.59% 仅是观测事实。没有重复窗口、时间线或稳定同序对照，不能指定为源码 scalar 条件增加的因果，也不能用 `total-sum(busy)` 虚构等待时间。

live_staging 在卡8，另外两项在卡9。因此 live 的计数只作为原始观测记录，不把相减结果归因于 AIV staging，也不能由此认定 AIC-only 与 AIV-only 的独立收益。需要父线程计划的同卡复核；最好继续以交错、多轮、无 PMU graph 测量决定实际性能。

## graph 观察边界

父线程已报告首轮 B4 graph 219.472→216.441 µs，20 对中16对改善。本目录审计时未读取该轮原始 graph 文件，所以这里只注明为父线程报告，不冒称已经独立复算。

现 `graph_ab.py` 对象是 **isolated sparse diagnostic roots 的实际 NPUGraph replay**，包含 sparse plan/publish，不是整层 CSA，也不是 vLLM FULL 整模型路径。上述约1.38%的首次均值变化和16/20正样本不足以单独宣布稳定收益或正式合入；应保留全部样本，不剔除反向样本，再结合 B40 同核跨 token 的数值门禁和独立重复轮。

## 最终环境与先前静态报告的更正

先前 `review-generated/REVIEW.md` 记录的是当时试用的严格白名单方案，**不是最终三个已运行任务的环境**。最终三项结果使用共同 helper manifest `74c0d8215eec473fe86f25f03a73de764844b5368e4b6c2d0b09f2c3479a8001`，preflight 明确记录复用原 `root-fix-20261016/sitecustomize.py`、核对 PyPTO/Simpler/vLLM/Ascend 实际路径，并拒绝 whole-model helper 前置与 active ADMISSION/FULL_PROBE 标志。三个 preflight 均 PASS。

复用已验收 runtime/package selection 和 shutdown 兼容 hook 合理，不能仅因为模块名叫 sitecustomize 就推断模型观测已启动。现 preflight 将其路径及观察开关显式约束，比未经核验地混入其他 whole helper 更清楚。当前日志可以证明相同运行环境门禁通过；未在本次审计中重新下载逐 SHA 审查所有旧 hook 源码，因此不把这条环境结论夸大为新实现独立证明。

## 结论

三项 B4 数值验证通过，PMU 聚合可信。AIC-only 的确减少了 MTE2 busy，但首轮没有总周期改善；paired staging 的阶段收益需要同卡复核。目前继续测试合理，尚不宜宣称稳定优化或合入。
