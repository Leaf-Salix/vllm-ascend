# SWA live staging：独立生成物及助手审查

审查对象：7078bc644 基准上的报告目录私有 `read_only`、`live_staging`；正式源码未在本次审查中修改。审查仅 CPU/文本，没有执行 NPU。

后续说明：本文环境段记录的是提交前试用方案；最终运行复用原 runtime/package selection hook，具体实际环境与三项 PMU 独立复算见 `../review-pmu/REVIEW.md`。生成物数学审查结论不变。

## 结论

**生成物没有发现阻断 B4 单因素 PMU 小任务的问题。** 可在最终远端环境预检通过后，分别用三个独立 program 进程测试 baseline、read_only、live_staging。此结论只批准进入数值/测量门禁，不代表候选数值或性能已验收。

`check.py` 实际执行 PASS，结果和源/生成物 SHA 见 `results.json`。本次读取的助手 manifest SHA 为 `bd2b4e58010b78b45c4df0a34e5908fe68c9e5c1cf9790efb1395b35adacd172`，所列 15 文件逐 SHA 相同。后续助手发生变动应重新预检，不能沿用这里的旧 SHA。

## 单因素与数学边界

- 逆向移动 `read_only` 的 QK gather 到原位置后，整个模块 AST 与 baseline 完全相同。
- 仅解开 `live_staging` 新增的 AIV part guard 后，整个模块 AST 与 read_only 完全相同。
- 三套 diagnostic root 在恢复 provider import 名称后，整个 AST 相同；没有候选实际引用 baseline 的路由。
- cast（包含参数）、exp、matmul/acc、row max/sum、row expand mul/sub、sync set/wait 的实际 Call AST 多重集相同。代码结构逆变换检查同时约束改动范围，不能单独用调用数量宣称数值等价。
- 生成的 **baseline→read_only AIV 完整函数去注释后逐字相同**；**read_only→live_staging AIC 完整函数去注释后逐字相同**。后一组 AIV 差异仅外包既定 guard；前一组 AIC 包含 gather 移动带来的 SSA 重编号和局部同步随迁。
- 16 Tensor ABI、kernel config、32-worker planner 和 diagnostic publish 均相同。所下载、且编译 receipt 列出的文件逐 SHA 核对；未下载的其他生成文件由远端 runner 启动时核对，不冒称已在本机全部核对。

## AIC L1 与局部事件

物理 qk_l1 仍为 384×512 BF16，三个 128 行槽；没有缩小 carrier 或改变 Q/P/accumulator 大小。QK part 的地址仍 `max(part-1,0)*128`：part0/1 使用槽0，part2/3 使用槽1/2。

read_only 实际生成在 `sb>0 or part==0` 内完成原 128×512 TLOAD、原转置/分片和 MMA。MTE1→MTE2 EVENT_ID2 的 wait 与下一次 set 都位于同一 guard 内，初始 seed 和最终 drain 保留：SWA part0 必定执行，part1…3 不消耗事件；下一个 compressed/live part 或 query 消费的仍是一次合法归还。MTE2→MTE1 EVENT_ID1 的 set/wait 也随同一 gather 移入 guard，不会等待未发生的被跳过 load。

PV 原 `part<2` 重载条件未变，尤其 SWA PV part0 继续重载，不依赖以前 part3 对 L1 的副作用。Compressed QK 每片先写后读，PV part0/1 重载，part2/3 消费本 compressed block 已写的槽1/2。无效 block 整段跳过，其后不读取该 block 缓冲。跨 token 的整数槽标签证明另见 `../review-design/lifetime-check.json`；它不替代真实执行的同步验证。

## AIV +0 和 cross-core 事件

live_staging 实际生成仅将 per-part 的初始化、页解析/gather 和 store 包在 `sb>0 or part==0` 中。保留下来的 part0 仍是完整 64×512 BF16 `TEXPANDS(...,+0)`，短窗口/空洞行没有省略初始化。两个 AIV half 合成实际 128 行 SWA 数据。

SWA score 的 live128 + 明确 FP32 +0 tail384 的 TCONCAT 仍在原位置，随后 K512 softmax、mask、归约、CAST_ROUND、online update 都保留；绝不把未写 tail 从 GM/L1 当作 score 输入。

四项跨核同步仍在有效 block 层，未放入 part guard：AIV KV_READY0、AIC SCORE_READY1、AIV PROB_READY2、AIC PV_READY3；各自 set/wait 未增删。AIV 的 per-part MTE3→V EVENT_ID3 保持 seed、guard 内 wait/set 配对和最终 drain，跳过 part 不消耗事件。

## 助手与测量范围

已识别并让主线程移除 inherited root-fix/whole-model `sitecustomize`：现 `PYTHONPATH` 明确列出 helper、固定 source/tests、PyPTO runtime、CANN/TBE、reference site-packages、Simpler 和 vLLM；不把整个旧 PYTHONPATH 拼接回来。preflight 拒绝 sitecustomize、核实际 import 路径及必要环境。此变更不改变已经 CCEC 编译的核体，不要求重做编译；最终运行仍必须保存实际 preflight。

shell 固定 Native bank 与 FP32 stats 黄金 SHA，每个独立进程先两次无 PMU，第三次 event2。每次输出先 NaN poison，检查 finite、Native BF16 heads、原 PTO 四输出逐 byte、12 host 输入不变；后两次再比较四输出 repeat，合计原 59 门禁完整保留。发现第一个差异即保存并 assert 停止。PMU 文件必须是本窗口新生成，旧文件先移走；不混用 torch init 和 program runtime。

边界须保留：

1. `readonly` 是 CPU host 参数不变，没有设备 In tensor copyback 保障，报告已明确。Native 内部 mi/li/oi 不可直接观察，FP32 stats 的黄金是旧 PTO，而 Native heads 是独立数值门禁。
2. runner PMU 最小检查只要求 func3/4 至少一类正周期；分析结果时还应检查 AIC3 与 AIV4 两类均有有效样本，不能只凭该最小断言声称拿到双侧计数。
3. B4/T24 每个 AIC 只有一个 token，无法验证同 core 跨 token 的复用；如 B4 通过，后续至少 B40/T240 再做真实 FP32/heads/guard 验证才可推广。
4. 当前 preflight 锁 Sparse SHA 与 helper manifest，没有重新遍历整个3365文件 source snapshot。配置/layout 的 import 来自固定 snapshot，尚未发生变更；如果将来复制或改 snapshot，必须另行绑定这些依赖，不能复用当前结论。

本轮没有修改正式源码、SDK、运行助手，也未提交设备任务。
