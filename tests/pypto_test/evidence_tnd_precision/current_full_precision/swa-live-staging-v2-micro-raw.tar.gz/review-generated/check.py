"""Independent CPU-only source/generated identity checks; never runs hardware."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

R = Path(__file__).resolve().parents[1]
H = R / "helpers"
G = R / "generated"
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
dump = lambda n: ast.dump(n, include_attributes=False)
trees = {v: ast.parse((H / f"{v}_sparse.py").read_text()) for v in ("baseline", "read_only", "live_staging")}

# Reverse only the documented changes, then compare the entire module AST.
read = ast.parse((H / "read_only_sparse.py").read_text())
loop = next(n for n in ast.walk(read) if isinstance(n, ast.For) and ast.unparse(n.target) == "qk_part" and any(isinstance(x, ast.Assign) and ast.unparse(x.targets[0]) == "qk_slot_row" for x in n.body))
guard = next(n for n in loop.body if isinstance(n, ast.If))
gather = guard.body.pop(0)
assert isinstance(gather, ast.Assign) and ast.unparse(gather.targets[0]) == "qk_l1"
loop.body.insert(loop.body.index(guard), gather)
assert dump(read) == dump(trees["baseline"])
live = ast.parse((H / "live_staging_sparse.py").read_text())
loops = [n for n in ast.walk(live) if isinstance(n, ast.For) and ast.unparse(n.target) == "qk_part"]
stage = next(n for n in loops if len(n.body) == 1 and isinstance(n.body[0], ast.If))
assert ast.unparse(stage.body[0].test) == "qk_sb > 0 or qk_part == 0"
stage.body = stage.body[0].body
assert dump(live) == dump(trees["read_only"])

def fn(path, name):
    text = path.read_text()
    start = text.index(f"static __aicore__ void {name}(")
    pos = text.index("{", start)
    depth = 1
    end = pos + 1
    while depth:
        depth += (text[end] == "{") - (text[end] == "}")
        end += 1
    return "\n".join(x.strip() for x in text[start:end].splitlines() if x.strip() and not x.lstrip().startswith("//"))

paths = {v: {side: G / f"{v}-artifact/kernels/{side}/qk_pv_{side}.cpp" for side in ("aic", "aiv")} for v in trees}
assert fn(paths["baseline"]["aiv"], "qk_pv_aiv") == fn(paths["read_only"]["aiv"], "qk_pv_aiv")
assert fn(paths["read_only"]["aic"], "qk_pv_aic") == fn(paths["live_staging"]["aic"], "qk_pv_aic")
for v in trees:
    config = G / f"{v}-artifact/kernel_config.py"
    assert config.read_bytes() == (G / "baseline-artifact/kernel_config.py").read_bytes()
    receipt = json.loads((G / f"{v}-compiled.json").read_text())
    for name, digest in receipt["files"].items():
        p = G / f"{v}-artifact" / name
        if p.exists():
            assert sha(p) == digest, (v, name)

# The mathematical AST calls remain exact, including cast modes and reduction args.
math = {"cast", "exp", "matmul", "matmul_acc", "row_expand_mul", "row_expand_sub", "row_max", "row_sum", "sync_set", "sync_wait"}
def calls(t):
    return Counter(dump(n) for n in ast.walk(t) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in math)
assert calls(trees["baseline"]) == calls(trees["read_only"]) == calls(trees["live_staging"])
root = (H / "baseline_root.py").read_text()
for v in ("read_only", "live_staging"):
    assert ast.dump(ast.parse((H / f"{v}_root.py").read_text().replace(f"from {v}_sparse import", "from baseline_sparse import"))) == ast.dump(ast.parse(root))

result = {
    "pass": True,
    "hardware_executed": False,
    "scope": "Static generated/source review, not numerical or PMU acceptance",
    "reversible_whole_module_ast_changes": True,
    "baseline_to_read_only_AIV_exact_without_comments": True,
    "read_only_to_live_staging_AIC_exact_without_comments": True,
    "math_call_AST_multisets_exact": sorted(math),
    "kernel_config_16_tensor_ABI_exact": True,
    "source_sha256": {v: sha(H / f"{v}_sparse.py") for v in trees},
    "generated_sha256": {v: {s: sha(p) for s, p in d.items()} for v, d in paths.items()},
    "receipts_sha256": {v: sha(G / f"{v}-compiled.json") for v in trees},
    "receipt_scope": "Every locally downloaded listed file checked; absent remote-only files rechecked by run_program",
}
(OUT / "results.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
