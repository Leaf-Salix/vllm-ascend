"""Independent CPU-only paired timing and complete graph evidence audit."""
import hashlib
import json
import math
from pathlib import Path
import statistics

R = Path(__file__).resolve().parents[1]
O = Path(__file__).resolve().parent
gate = json.loads((R / "graph/micro-gates.json").read_text())
t19 = 2.093024054408263  # two-sided Student t(19) 95%
expected = {"Q_B_actual_input"}
fields = ("mi", "li", "oi", "heads")
for arm in ("baseline", "candidate"):
    for point in ("raw_replay", "A_restored", "final_gold"):
        expected.update(f"{arm}.{point}.{x}" for x in fields)
    expected.add(f"{arm}.Native_heads")
for point in ("A", "B_Q_changed", "Q_zero", "A_restored", "timing_round4", "timing_round9", "timing_round14", "timing_round19"):
    expected.update(f"{point}.{x}" for x in fields)
expected.update(f"device_readonly.{i}" for i in range(12))
assert len(expected) == 71
results = []
for raw in gate["graph_runs"]:
    p = R / "graph/results" / raw["label"] / "data/result.json"
    d = json.loads(p.read_text())
    assert hashlib.sha256(p.read_bytes()).hexdigest() == raw["result_sha256"]
    assert d["pass"] is True and d["complete"] is True
    assert len(d["checks"]) == 71 and {x["label"] for x in d["checks"]} == expected
    assert all(x["bit_equal"] is True for x in d["checks"])
    assert d["task_device"] == "9" and d["timing_rounds"] == 20 and d["replays_per_round"] == 100
    assert all(d[k] is False for k in ("DFX", "PMU", "depgen"))
    assert d["source_modules"]["live_staging_sparse"]["sha256"] == "36a3b7ebb2ab42ed4dd8c081f66b2ea60a07d40c55ba021da8552f4de5f2ab12"
    assert d["source_modules"]["baseline_sparse"]["sha256"] == "a4c1c5c6e80e20e8cac2e321e4a55b3a09eebd9113f47a46f557d5a799567608"
    samples = {arm: d["timing_us"][arm]["samples"] for arm in ("baseline", "candidate")}
    assert all(len(s) == 20 and all(math.isfinite(v) and v > 0 for v in s) for s in samples.values())
    for arm, s in samples.items():
        for k, v in (("mean", statistics.mean(s)), ("min", min(s)), ("max", max(s)), ("median", statistics.median(s))):
            assert d["timing_us"][arm][k] == v
    paired = [a - b for a, b in zip(samples["baseline"], samples["candidate"])]
    pct = [(a - b) / a * 100 for a, b in zip(samples["baseline"], samples["candidate"])]
    assert all(math.isclose(a, b, abs_tol=1e-12) for a, b in zip(pct, d["paired_speedup_percent"]))
    mean = statistics.mean(paired)
    half = t19 * statistics.stdev(paired) / math.sqrt(20)
    gain = (statistics.mean(samples["baseline"]) - statistics.mean(samples["candidate"])) / statistics.mean(samples["baseline"]) * 100
    # Gate document uses rounded t=2.093; also retain the exact quantile interval.
    assert math.isclose(mean - 2.093 * statistics.stdev(paired) / math.sqrt(20), raw["paired_ci_lower_us"], abs_tol=1e-10)
    assert math.isclose(gain, raw["gain_percent"], abs_tol=1e-10)
    assert sum(x > 0 for x in paired) == raw["positive_pairs"]
    assert mean - half > 0
    results.append({"label": raw["label"], "device": "9", "baseline_us": statistics.mean(samples["baseline"]), "candidate_us": statistics.mean(samples["candidate"]), "gain_percent": gain, "paired_mean_delta_us": mean, "paired_ci95_us": [mean - half, mean + half], "positive_pairs": sum(x > 0 for x in paired), "negative_pairs": sum(x < 0 for x in paired), "checks": 71, "all_samples_retained": True, "bank_sha": d["bank_sha"], "stats_sha": d["stats_sha"], "helper_sha": d["helper_manifest_sha"], "result_sha": raw["result_sha256"]})
result = {"pass": True, "hardware_executed_by_this_audit": False, "scope": gate["scope"], "positive_pairs": sum(r["positive_pairs"] for r in results), "all_pairs": 80, "runs": results, "ci_limit": "Nominal paired t interval on 20 serial rounds, not proof of independence, universal workload gains or end-to-end gains"}
(O / "graph-results.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
