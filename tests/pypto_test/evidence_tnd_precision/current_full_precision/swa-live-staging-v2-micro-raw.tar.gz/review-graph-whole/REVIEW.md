# 四次 sparse graph 稳定性及 whole 准备工具独立审查

## 结论

四次同卡独立任务的现有结果支持通过事前 micro 门槛，**可以进入正式字节的完整 CSA 门禁及整模型验证**。尚不能据此声称整层或整模型有相同比例收益。`prepare_whole_live.py` 没有发现阻断正确性或身份绑定的问题。

本次只读取已有结果和工具；没有修改正式源码、运行助手或 SDK，没有执行准备工具复制正式快照，也未提交 NPU。

## 独立复算结果

`recompute_graph.py` 实际 CPU 执行 PASS。四份原始结果的 SHA 与 `graph/micro-gates.json` 一致；每份 complete/pass，严格检查71个唯一检查名称及结果，20对×100 replay的全部样本保留，物理卡均为9，无 PMU/DFX/depgen。包含 A/B/zero/恢复、实际设备输入 copyback、四输出黄金及 Native heads；B40补充了同 core 跨 token 的真实执行覆盖。

| 原始任务标签 | baseline µs | candidate µs | 延迟降低 | 更快配对 | 配对差值均值95%区间 µs |
| --- | ---: | ---: | ---: | ---: | --- |
| graph-b4-r1 | 219.472 | 216.441 | 1.381% | 16/20 | [1.620224, 4.441601] |
| graph-b4-r2 | 228.245 | 220.859 | 3.236% | 20/20 | [5.604858, 9.167227] |
| graph-b40-r1 | 867.470 | 838.166 | 3.378% | 20/20 | [24.410509, 34.198783] |
| graph-b40-r2 | 883.235 | 868.197 | 1.703% | 20/20 | [12.665472, 17.411119] |

合计76/80正，全部反向配对仍在样本里。这里的正值表示 baseline-candidate 的延迟差，不把所有80项混成独立任务样本。原门槛采用四舍五入临界值 t19=2.093，表中独立计算使用2.0930240544；变化仅末位，四个区间下界仍为正。

配对 t 区间是20个顺序采样的名义区间，不能据此证明采样独立、忽略热状态或外推其他形状；但“每个B4/B40至少两次独立任务、每次均值正、至少75%配对正、区间下界正”的事前门槛全部达到。两次任务收益幅度仍有漂移，应原样记录1.38%～3.38%的观测范围。

此处实测对象是带 planner/publish 的 **isolated sparse actual ACL graph root**，不是完整 CSA/HC-pre→HC-post，也不是 vLLM FULL 整模型。PMU跨卡限制与总周期未改善的首轮现象仍保留在 `../review-pmu/REVIEW.md`，新的 graph 结果不把那些观察删除或改标。

## 准备工具的源身份

已实际读取并核对：

- 原基准 source manifest固定 `639b1280dc682dad23195509ddd51970d0d16da55fa11efa302e9edc97da7e03`，Sparse固定248d8b11…，helper固定7669087a…；底层 `prepare(...,profile="swa128")` 在创建目录前核验全部3365源文件与全部受SHA约束的助手。
- 私有源固定 `36a3b7ebb2ab42ed4dd8c081f66b2ea60a07d40c55ba021da8552f4de5f2ab12`，与本次实际graph provider字节相同；正式格式源固定 `782355875150e92f27ab40c00dbcc4c420fe12a8ab955c4430f07d3de36a7a56`。
- 仅将两处绝对config import及一处layout import恢复为正式相对import后，私有源与正式格式源整个AST相同；Ruff格式没有引入数学或控制流变化。
- 本目录底层prepare工具与正式repo当前工具逐字相同，没有偷偷引入不同复制规则；它拒绝已有目录、重叠路径、symlink、危险label和已有输出，不复制模型权重或cache，不执行设备任务。

候选只覆写新目录 snapshot/source 和 patch 中的Sparse，更新其manifest及candidate-math，逐3365文件重新核验。其余 source entries 不改，43运行源重新哈希，root ABI仍62。实际执行源由新 SOURCE_ROOT 指定，源预检检查全部manifest字节并注册正式62参数入口；不存在私有provider误用baseline的路径。

## 旧身份与新助手

工具将继承的 `FINAL_SOURCE_BOUND.json`、`PACKAGE_READY.json`、`reproduction.json` 另存 `baseline-swa128-*`；新bound明确写 `NPU_executed:false`、`static source binding only`及`whole-model qualification pending`，不把已有SWA128结果当作live-staging已验收。旧selection/canonical/conversion身份仍保留为baseline字段及原归档，新的delta记录真正单文件diff、格式AST桥和micro门禁SHA。

最后重算helper manifest中每个已有条目及新增baseline副本、delta、micro gates和两个repro工具，旧reference-helper manifest继续保留原SHA。source manifest、candidate-math及43源身份重新绑定新Sparse，旧source639和原reference目录不被覆写。它没有重装或切换运行环境。

准备阶段对micro gates采取固定四组门槛检查，并保存其SHA；不在工具内部重新分析原始graph。这一层是可接受的准备前提：本次独立脚本已对真实四份raw完成严格复算。后续若换gates文件，必须再次审计其原始结果，不能把“JSON pass=true”单独当作数值证明。

## 后续门禁

先对正式782字节做完整入口的混合长度/短query/大T门禁，随后按8K通过再128K进行真实模型token/events/入场轨迹及性能验证。任何首差先停，不因micro精度通过而跳过完整入口或模型级门禁；所有任务仍保持既有780秒上限。
