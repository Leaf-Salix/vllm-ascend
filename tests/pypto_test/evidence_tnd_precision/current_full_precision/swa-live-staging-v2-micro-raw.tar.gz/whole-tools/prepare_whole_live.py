"""从固定SWA128安全复制；只替换已审查的SWA live KV staging单因素，不执行 NPU。"""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import shutil
from prepare_tnd_precision_performance_repro import prepare

SPARSE = "vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision/decode_sparse_attn_csa.py"
BASE_SPARSE = "248d8b11bb0a045f7863c0b264d962845dcabafa51cbf1e5fafee413fa8dc6d5"
RAW_SPARSE = "36a3b7ebb2ab42ed4dd8c081f66b2ea60a07d40c55ba021da8552f4de5f2ab12"
BASE_SOURCE = "639b1280dc682dad23195509ddd51970d0d16da55fa11efa302e9edc97da7e03"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n")


parser = argparse.ArgumentParser()
parser.add_argument("--reference-job", type=Path, required=True)
parser.add_argument("--destination", type=Path, required=True)
parser.add_argument("--candidate", type=Path, required=True)
parser.add_argument("--formatted-candidate", type=Path, required=True)
parser.add_argument("--micro-gates", type=Path, required=True)
parser.add_argument("--label", required=True)
args = parser.parse_args()
assert sha(args.candidate) == RAW_SPARSE and not args.candidate.is_symlink()
gates = json.loads(args.micro_gates.read_text())
assert gates["pass"] and gates["candidate_raw_sparse_sha"] == RAW_SPARSE
assert len(gates["graph_runs"]) == 4 and all(r["pass"] and r["paired_ci_lower_us"] > 0 and r["positive_pairs"] >= 15 for r in gates["graph_runs"])
assert sorted(r["batch"] for r in gates["graph_runs"]) == [4, 4, 40, 40]
assert len({r["label"] for r in gates["graph_runs"]}) == 4
assert len({r["result_sha256"] for r in gates["graph_runs"]}) == 4
assert all(r["checks"] == 71 and r["paired_count"] == 20 for r in gates["graph_runs"])
text = args.candidate.read_text()
old = "from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.config import ("
assert text.count(old) == 2
text = text.replace(old, "from .config import (")
old = "from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.layout import COMPRESSED_TABLE_COLUMNS_DYN, ORIGINAL_TABLE_COLUMNS_DYN"
assert text.count(old) == 1
text = text.replace(old, "from .layout import COMPRESSED_TABLE_COLUMNS_DYN, ORIGINAL_TABLE_COLUMNS_DYN")
assert sha(args.formatted_candidate) == "782355875150e92f27ab40c00dbcc4c420fe12a8ab955c4430f07d3de36a7a56"
formatted = args.formatted_candidate.read_text()
assert ast.dump(ast.parse(text), include_attributes=False) == ast.dump(ast.parse(formatted), include_attributes=False)
text = formatted
prepare(args.reference_job, args.destination, args.label, profile="swa128")
job = args.destination
source = job / "snapshot/source"
manifest_path = job / "snapshot/manifest.json"
assert sha(manifest_path) == BASE_SOURCE
manifest = json.loads(manifest_path.read_text())
assert len(manifest["files"]) == 3365 and manifest["files"][SPARSE] == BASE_SPARSE
(source / SPARSE).write_text(text)
new_sparse = sha(source / SPARSE)
manifest["files"][SPARSE] = new_sparse
write(manifest_path, manifest)
new_source = sha(manifest_path)
for name, digest in manifest["files"].items():
    assert sha(source / name) == digest, name
math_path = job / "candidate-math.json"
math = json.loads(math_path.read_text())
assert math[SPARSE] == BASE_SPARSE
math[SPARSE] = new_sparse
write(math_path, math)
(job / "patch" / SPARSE).write_text(text)
for name in ("FINAL_SOURCE_BOUND.json", "PACKAGE_READY.json", "reproduction.json"):
    shutil.copyfile(job / name, job / ("baseline-swa128-" + name))
bound = json.loads((job / "FINAL_SOURCE_BOUND.json").read_text())
assert len(bound["tested_sources"]) == 43 and bound["tested_sources"][SPARSE] == BASE_SPARSE
bound["tested_sources"][SPARSE] = new_sparse
for name, digest in bound["tested_sources"].items():
    assert sha(source / name) == digest
write(job / "FINAL_SOURCE_BOUND.json", {
    "pass": True, "scope": "static source binding only; whole-model qualification pending",
    "NPU_executed": False, "baseline_commit": "7078bc644d618663c21f558e86432a8cac1bf5dc",
    "source_manifest_sha256": new_source, "source_root": str(source),
    "tested_sources": bound["tested_sources"], "root_ABI": 62, "repeats_default": 3,
    "changed_source_files": [SPARSE], "micro_gates_sha256": sha(args.micro_gates),
})
package = json.loads((job / "PACKAGE_READY.json").read_text())
package["NPU_executed"] = False
package["scope"] = "prepared single-factor source; whole-model tests pending"
package["candidate_math_sha256"] = sha(math_path)
for name in ("selection_sha256", "canonical_identity_sha256", "conversion_rules_sha256"):
    if name in package:
        package["baseline_" + name] = package.pop(name)
package["baseline_selected_options"] = list(package["selected_options"])
package["selected_options"].append("swa_live_staging")
write(job / "LIVE_STAGING_DELTA.json", {
    "baseline_source_manifest_sha256": BASE_SOURCE, "source_manifest_sha256": new_source,
    "changed_source_files": [SPARSE], "baseline_sparse_sha256": BASE_SPARSE,
    "raw_candidate_sparse_sha256": RAW_SPARSE, "candidate_sparse_sha256": new_sparse,
    "formatter_ast_identical": True,
    "micro_gates_sha256": sha(args.micro_gates), "whole_model_qualification": "pending",
})
package["delta_receipt_sha256"] = sha(job / "LIVE_STAGING_DELTA.json")
write(job / "PACKAGE_READY.json", package)
reproduction = json.loads((job / "reproduction.json").read_text())
reproduction.update(identity="LiveStaging_based_on_SWA_Cube128", source_manifest_sha256=new_source,
                    baseline_source_manifest_sha256=BASE_SOURCE, changed_source_files=[SPARSE],
                    candidate_sparse_sha256=new_sparse, raw_candidate_sparse_sha256=RAW_SPARSE,
                    NPU_executed=False)
write(job / "reproduction.json", reproduction)
shutil.copyfile(args.micro_gates, job / "live-staging-gates.json")
tools = job / "repro-tools"
tools.mkdir(exist_ok=True)
for name in ("prepare_whole_live.py", "prepare_tnd_precision_performance_repro.py"):
    shutil.copyfile(Path(__file__).parent / name, tools / name)
helper = json.loads((job / "helper-manifest.json").read_text())
extra = ["baseline-swa128-FINAL_SOURCE_BOUND.json", "baseline-swa128-PACKAGE_READY.json", "baseline-swa128-reproduction.json",
         "live-staging-gates.json", "LIVE_STAGING_DELTA.json", "repro-tools/prepare_whole_live.py", "repro-tools/prepare_tnd_precision_performance_repro.py"]
helper["files"].update({name: sha(job / name) for name in extra})
helper["files"] = {name: sha(job / name) for name in helper["files"]}
write(job / "helper-manifest.json", helper)
assert sha(args.reference_job / "snapshot/manifest.json") == BASE_SOURCE
print("LIVE_STAGING_WHOLE_PREPARED_NO_NPU", json.dumps({"source_sha": new_source, "sparse_sha": new_sparse,
    "math_sha": sha(math_path), "helper_sha": sha(job / "helper-manifest.json"),
    "source_root": str(source), "source_files": 3365, "runtime_files": 43}), flush=True)
