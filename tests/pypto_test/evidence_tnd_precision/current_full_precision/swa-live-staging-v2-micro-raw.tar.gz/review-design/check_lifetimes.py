"""CPU-only tagged-buffer proof for the proposed live-SWA staging factors.

No floating-point math, SDK import, kernel generation, or NPU execution.
"""
import ast
import hashlib
import itertools
import json
from pathlib import Path

W=Path('/Users/jiayetcs/Desktop/Project/PyPTO')
SOURCE=W/'vllm-ascend-nalinaly-tnd-20261008-codex/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision/decode_sparse_attn_csa.py'
HERE=Path(__file__).resolve().parent
tree=ast.parse(SOURCE.read_text())
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='sparse_attn_csa')
qloop=next(n for n in ast.walk(fn) if isinstance(n,ast.For) and ast.unparse(n.target)=='qk_part')
ploop=next(n for n in ast.walk(fn) if isinstance(n,ast.For) and ast.unparse(n.target)=='pv_part')
qguard=next(n for n in qloop.body if isinstance(n,ast.If))
pguard=next(n for n in ploop.body if isinstance(n,ast.If))
reload=next(n for n in pguard.body if isinstance(n,ast.If))
byname={}
for n in ast.walk(fn):
    if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):byname.setdefault(n.targets[0].id,n.value)
constants={'ATTN_CUBE_KV_TILE':128,'ATTN_K_TILE':512,'pl':type('PL',(),{'max':staticmethod(max)})}
def evaluate(node,**values):return eval(compile(ast.Expression(node),'actual_source_expression','eval'),{**constants,**values})
patterns=list(itertools.product((False,True),repeat=2))
counts={}
for variant in ('7078','aic_only','paired'):
    queries=blocks=reads=writes=0
    def trace(sequence):
        global queries,blocks,reads,writes
        l1=[('uninitialized',)]*3
        gm=[('stale',)]*4
        for token,valid in enumerate(sequence):
            queries+=1
            for sb,live in enumerate(valid):
                if not live:continue
                blocks+=1
                # AIV owns the complete block in its fixed core*512 region.
                for part in range(4):
                    if variant!='paired' or sb>0 or part==0:
                        gm[part]=(token,sb,part);writes+=1
                # AIC qk gather/read: existing QK arithmetic guard reused.
                for part in range(4):
                    selected=evaluate(qguard.test,qk_sb=sb,qk_part=part)
                    if variant=='7078' or selected:
                        row=evaluate(byname['qk_slot_row'],qk_part=part)
                        assert row%128==0 and 0<=row<=256
                        assert gm[part]==(token,sb,part)
                        l1[row//128]=gm[part];reads+=1
                    if selected:
                        assert l1[evaluate(byname['qk_slot_row'],qk_part=part)//128]==(token,sb,part)
                # Existing PV reload and MMA guard are unchanged by both factors.
                for part in range(4):
                    if not evaluate(pguard.test,qk_sb=sb,pv_part=part):continue
                    row=evaluate(byname['pv_slot_row'],pv_part=part)
                    if evaluate(reload.test,pv_part=part):
                        assert gm[part]==(token,sb,part)
                        l1[row//128]=gm[part];reads+=1
                    assert l1[row//128]==(token,sb,part)
    for first,second in itertools.product(patterns,repeat=2):trace([first,second])
    # Includes ten consecutive queries per core, as in T240/24-core dispatch.
    for core in range(24):trace([patterns[(core+i)%4] for i in range(10)])
    counts[variant]={'queries':queries,'valid_blocks':blocks,'AIC_KV_panels_read':reads,'AIV_panels_written':writes}
result={'pass':True,'scope':'tagged lifetime and logical transaction counts only, not floating-point or backend/event proof','source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'patterns':'all16 ordered two-token validity transitions +24cores x10queries with rotating invalid/valid blocks','counts':counts,'per_full_query_bytes':{'7078_AIC_KV_reads':1408*512*2,'aic_only_AIC_KV_reads':1024*512*2,'paired_AIC_KV_reads':1024*512*2,'7078_AIV_KV_writes':1024*512*2,'paired_AIV_KV_writes':640*512*2},'unchanged_capacity':'GM core stride512, L1 carrier384x512 BF16, Q64x512 BF16, P64x128 BF16; total L1 475136 bytes'}
(HERE/'lifetime-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
