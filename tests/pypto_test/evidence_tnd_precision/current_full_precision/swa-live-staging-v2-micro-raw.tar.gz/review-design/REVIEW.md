# 7078精度基准剩余Vector/MTE2：独立设计审查

## 结论和优先级

当前正式提交 `7078bc644d618663c21f558e86432a8cac1bf5dc`，Sparse SHA `248d8b11bb0a045f7863c0b264d962845dcabafa51cbf1e5fafee413fa8dc6d5`。本次只读代码与已有证据，未修改正式代码、SDK或提交设备任务。

**优先按主线程计划，先独立去掉SWA没有消费者的AIC KV读取，再去掉配套AIV零尾生产。** 这比先改softmax分块/归约更容易保住当前数值顺序。当前SWA Cube已经只处理part0，但搬运仍按四片K128执行；多余数据有明确use-def证据，收益仍须实测。

先区分三个实现，避免把效果混在一起：

1. 基准7078：SWA QK读四片，PV仅part0，但AIV仍生成四片。
2. AIC-only：仅将SWA QK的part1～3 `gather_row`跳过；AIV不变。
3. paired：在AIC-only基础上，只对SWA part0执行AIV tile零初始化/页表gather/GM store。其他block四片全部保留。

不同时改softmax头数、mask、K512、CAST_ROUND、online更新、L1/GM形状或事件。否则局部PMU变化不能归因到搬运清理。

## Native和Nal对照

| 实现 | SWA KV进入路径 | 有效长度 | QK/PV之间的KV处理 |
| --- | --- | --- | --- |
| Native Arch32对应源码 | raw cache按页直接GM→L1；不先由AIV写一整块raw零尾 | MM1的nL1Loops来自actualSingleProcessSInnerSize；MM2 kL1Loops也来自实际K | MM1/MM2按各自实际行数分块；不能据此臆测所有实际cache命中或线上指令 |
| Nal a919性能BSH | AIV只stage一个固定128行块到GM，AIC载入一个L1轮转槽 | ATTN_K_TILE=128，AIV每lane64行 | PV复用同一个三槽L1，代码不再重新GM→L1搬运该KV块 |
| 当前7078 | SWA有效128，却AIV stage512，AIC QK载入512，PV重载128 | 数值softmax存储仍512，实际K归约保持Native顺序 | QK part1覆盖slot0为零，part2/3填slot1/2；这些SWA载入现已没有消费者 |

Nal的K128独立softmax/rint和alpha/beta归并已有数值差异，不能整段移到本精度版。本轮只借用“没有消费者的数据不搬”的设计。Native源码与当前API对应，但本地C++字节并未证明就是227静态二进制的精确构建输入；生产二进制身份/Native黄金门禁仍须保留。

主要代码位置：

- 当前Sparse：`decode_sparse_attn_csa.py:362–414`（AIC），`:433–478`（AIV KV），`:482–610`（不应变化的softmax/online）。
- Native：`sparse_attn_sharedkv_swa_block_cube.h:334–408`（实际N循环/PA拷贝）、`:654–742`（实际K循环）。
- Nal：`decode_sparse_attn_csa.py:379–455`（128行三槽L1）、`:487–530`（AIV每lane64行staging）。

## 槽位生命周期

保持原carrier为384×512 BF16，slot0/1/2各128行；固定每core的GM区间仍以512行为stride。

| 阶段 | slot0 | slot1 | slot2 | 真实消费者 |
| --- | --- | --- | --- | --- |
| SWA QK part0 | 写本token的live128 | 允许旧值 | 允许旧值 | QK仅读slot0 |
| SWA QK parts1～3 | 候选不再写 | 不再写 | 不再写 | 无QK消费者 |
| SWA PV part0 | 原样重载live128 | 不读 | 不读 | PV只读slot0前128行 |
| compressed QK part0 | 新写part0并消费 | 旧值无关 | 旧值无关 | 只读新slot0 |
| compressed QK part1 | 新写part1并消费 | 旧值无关 | 旧值无关 | 只读新slot0 |
| compressed QK part2/3 | 保留part1 | 新写part2 | 新写part3 | 对应QK读新slot1/2 |
| compressed PV | part0/1原样分别重载 | 复用本block part2 | 复用本block part3 | 四片仍原顺序累加 |

跨token时，SWA会先新写slot0；compressed的每个QK片也先写后读。SWA无效而compressed有效、compressed无效而下一个token有SWA、两block均无效等状态，都不会新增旧slot1/2消费者。

`check_lifetimes.py`从实际生产AST读取guard、slot表达式与PV重载条件，做了16种两token有效性转移，再做24核各10query的轮转状态模拟，标签buffer证明通过（`lifetime-check.json`）。这是地址/use-def检查，**不证明浮点、后端物理布局或硬件同步**。

### 不存在的隐式消费者，仍需生成物复核

- SWA QK完整carrier转置后，只slice第0个128列，TEXTRACT仅消费slot0；不能因为source tile物理容量384就认定自动消费384行。
- SWA PV只执行part0的K32子片，索引0/32/64/96，访问slot0前128行。概率L1为独立 `[458752,475136)`，不能与carrier `[0,393216)`混用。
- AIV softmax尾部384 score由7078的显式+0构造；不读取没有写入的score_transfer尾，更不从KV尾重建。
- 同core GM固定区域不会被另一个core消费；后续compressed生产仍在KV_READY前完整定义512行。

## 逻辑事务计数

按每个query的SWA与compressed都有效、H64/D512、BF16、WIN128/TopK512计数；单位为**逻辑GM事务字节**，不是L2 miss或真实HBM字节，也不是时间预测。

| 项目 | 7078 | AIC-only | paired |
| --- | ---: | ---: | ---: |
| SWA AIC QK KV读 | 512KiB | 128KiB | 128KiB |
| SWA AIC PV KV重载 | 128KiB | 128KiB | 128KiB |
| compressed AIC QK+PV KV读 | 768KiB | 768KiB | 768KiB |
| AIC合计KV读 | 1408KiB | 1024KiB | 1024KiB |
| SWA AIV GM写 | 512KiB | 512KiB | 128KiB |
| compressed AIV GM写 | 512KiB | 512KiB | 512KiB |
| AIV合计KV写 | 1024KiB | 1024KiB | 640KiB |

AIC-only省384KiB/query的MTE2读取，约为该项KV读取的27.27%；paired再省384KiB/query的AIV零填充和GM写，相当于KV staging写的37.5%。T24分别9MiB/方向，T240分别90MiB/方向。GM allocation仍12MiB、L1仍475136B，不靠改变容量取得收益。Scalar页表/循环空分支也可能减少，所以不能把paired的Vector变化全部归结为单个Duplicate指令。

## 同步风险和生成门禁

1. 四组跨核事件必须保留在valid block层级，不能移入part条件：AIV发KV_READY0/PROB_READY2，AIC发SCORE_READY1/PV_READY3，每个有效block仍各一次。KV_READY继续用MTE3，确保live写完成；不能改成Vector事件。
2. AIC-only把gather移入guard后，编译器会重做本地MTE1/MTE2/M/FIX事件。须检查所有执行路径的wait对应seed或此前set；特别SWA跳过三轮后紧接compressed及下一token的loop-carried事件。源码没变FFTS不等于后端本地fence自动正确。
3. AIV paired必须把**整个**无效part的create/fill/gather/store放在guard内，不能只跳store却仍读未定义phi。短window/缺页时part0的完整零初始化必须保留。
4. L1/UB地址和数据live range必须实际复核。新增phi/分支不能让编译器给保留的live128错误alias或改变probability/score/online工作区。不得借机缩短carrier、减GM stride或改softmax。
5. AIC-only的实际AIV计算体应与7078相同；paired的实际AIC体应与AIC-only相同。其余变化应仅对应各自guard和必要本地fence，所有MMA/有效K顺序、exp/cast/归约代码保持。

## 测量顺序

- 两候选各自新源码、新generated SHA和新label，不覆盖7078或彼此。先无设备CCEC/actual orchestration与独立生成审查。
- 固定真实L4 Native bank和7078 baseline mi/li/oi金标：首次无PMU执行先全FP32 raw byte、Native pre-inverse BF16 heads精确、finite、poison、输入保护，首差就停止。
- B4/T24只保证每core一个query。通过后B40/T240至少覆盖每core十个query，另做T1/混合请求、SWA-only/失效block等逻辑边界；不能用B4单独验收跨token生命周期。
- program-mode单次event2 PMU窗口，明确AIC/AIV各func/core身份，比较Cube/Vector/MTE2/MTE3/Scalar/total原始counter；必要时另任务event6。不混用kernel-mode init，不在同进程重复开不可靠窗口。
- 7078→AIC-only看MTE2清理，AIC-only→paired看零尾生产/写回清理。主要判断量不是busy之和或`total−busy`；指标重叠且可能受cache/调度影响。
- 候选精度通过后用关闭DFX/PMU的实际graph同卡交错A/B，保留20×100原始pair并重复任务。稳定后才做完整CSA及真实模型；每任务≤780秒、首差停，不预设一定加速。

## 后续备选，当前不混入

- **第三个独立因素：SWA PV part0免重载。** 只有AIC-only成立后，QK后slot0仍是live128，概率L1独立，理论上可以复用并再省128KiB/query；必须独立生成/数值/同步验证，不能现在混入前两步。
- **softmax_copy64紧凑UB提取。** 原64≤actualK<512路径把exp首64列写GM再读，每query一个SWA块共32KiB双向逻辑搬运。可尝试现有DSL `tile.extract`做8×512→8×64紧凑副本，后续逐chunk加法/sel/8×8归约完全保持。Nal已有Vec TEXTRACT，但其已跑实例为单行；多行提取支持和layout须另做CCEC/数值门禁。
- **m/l/alpha留UB。** Native保留UB状态，当前同AIV却写GM再读，可用row-major1×32的extract/assemble保存。只搬bits不重算exp；但loop phi、ColMajor reshape和跨PV等待liveness比本轮复杂，收益字节量也小，不优先。
- 不直接复制Nal的独立K128 softmax/rint/alpha-beta归并，不换rsqrt/归约树，不把`m*0+1`改成常量，也不将整片head tile改大来同时引入UB/归约布局变量。
