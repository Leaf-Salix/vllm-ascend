import argparse,hashlib,importlib,json
from pathlib import Path
from pypto.runtime import RunConfig
p=argparse.ArgumentParser();p.add_argument("variant");a=p.parse_args()
here=Path(__file__).resolve().parent
root=importlib.import_module(a.variant+"_root").sparse_probe
compiled=root.compile(config=RunConfig(platform="a2a3",save_kernels=True,save_kernels_dir=str(here/(a.variant+"-artifact"))))
print("runtime",compiled.runtime_name,flush=True)
receipt={"variant":a.variant,"output_dir":str(compiled.output_dir),"hardware_executed":False,"files":{str(p.relative_to(compiled.output_dir)):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(compiled.output_dir).rglob("*") if p.is_file() and p.suffix in (".cpp",".py",".json")}}
(here/(a.variant+"-compiled.json")).write_text(json.dumps(receipt,indent=2)+"\n")
print("COMPILE_AND_CCEC_OK",a.variant,flush=True)
