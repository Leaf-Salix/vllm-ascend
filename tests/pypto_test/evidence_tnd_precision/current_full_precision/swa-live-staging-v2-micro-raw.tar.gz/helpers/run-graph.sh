#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
here=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "$here/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
unset SIMPLER_PMU_EVENT_TYPE
case_name="${1:?b4 or b40}"; label="${2:?label}";shift 2
[[ "$label" =~ ^[A-Za-z0-9_.-]+$ ]]
OLD=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/qkpv-measurement-20261019-codex
if [[ "$case_name" == b4 ]]; then
 bank="$OLD/capture-b4/csa-results/native-sparse-bank/data/native-sparse-bank.pt"
 bank_sha=66158da293867dc48626083df47404b919ee859fb9719c8d55c0f88f4809668e
 stats="$OLD/sparse-program/program-results/b4-stats-gold-device/data/stats-gold.pt"
 stats_sha=eb43040864b3b1209d1533f8ce0f2de68b6cee6be322905f45fba6b44e82feb2
elif [[ "$case_name" == b40 ]]; then
 bank="$OLD/capture-b4/csa-results/native-sparse-b40/data/native-sparse-bank.pt"
 bank_sha=ee36fbef78c0ad255408fe7796e212eabb1b45ccc29070214ade2110c1b27b8a
 stats="$OLD/sparse-program-b40/program-results/b40-stats-gold/data/stats-gold.pt"
 stats_sha=85b7fc7845dfe2b56e088db861c1277a26d0da16b233db25c73670c5a065bf1f
else exit 2; fi
mkdir -p "$here/results"
mkdir "$here/results/$label"
ccache -s > "$here/results/$label/ccache.log"
python "$here/preflight.py" > "$here/results/$label/preflight.log" 2>&1
timeout --signal=TERM --kill-after=15s 750s python "$here/graph_ab.py" \
 --bank "$bank" --bank-sha "$bank_sha" --stats "$stats" --stats-sha "$stats_sha" \
 --out "$here/results/$label/data" "$@" > "$here/results/$label/run.log" 2>&1
