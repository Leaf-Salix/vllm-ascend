"""同卡、同 bank、无 PMU/DFX 的原 sparse 与单因素候选 ACL graph 对拍。"""
import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import statistics
import torch
import torch_npu
import pypto.torch
from baseline_root import sparse_probe as baseline
from candidate_root import sparse_probe as candidate

parser = argparse.ArgumentParser()
parser.add_argument("--out", type=Path, required=True)
parser.add_argument("--bank", type=Path, required=True)
parser.add_argument("--bank-sha", required=True)
parser.add_argument("--stats", type=Path, required=True)
parser.add_argument("--stats-sha", required=True)
parser.add_argument("--device", type=int)
args = parser.parse_args()
args.out.mkdir()
assert hashlib.sha256(args.bank.read_bytes()).hexdigest() == args.bank_sha
assert hashlib.sha256(args.stats.read_bytes()).hexdigest() == args.stats_sha
bank = torch.load(args.bank, map_location="cpu", weights_only=False)
gold = torch.load(args.stats, map_location="cpu", weights_only=False)
assert gold["bank_sha"] == args.bank_sha
kwargs = bank["kwargs"]
tokens = bank["q"].shape[0]
bounds = kwargs["cu_seqlens_q"].reshape(-1)
requests = torch.repeat_interleave(torch.arange(len(bounds) - 1, dtype=torch.int32), bounds[1:] - bounds[:-1])
host_inputs = [bank["q"], kwargs["ori_kv"], kwargs["ori_block_table"], kwargs["cmp_kv"],
               kwargs["cmp_block_table"], kwargs["cmp_sparse_indices"].reshape(tokens, 512),
               bank["positions"].reshape(tokens, 1), kwargs["seqused_kv"].reshape(-1), requests,
               kwargs["sinks"].reshape(64), torch.ones(tokens, 64), torch.zeros(tokens, 64)]
report = {"pass": False, "complete": False, "bank_sha": args.bank_sha,
          "stats_sha": args.stats_sha, "task_device": os.environ["TASK_DEVICE"],
          "scope": "same-card original/candidate sparse diagnostic roots, real L4 Native Q/cache/TopK bank, actual ACL graph; not whole CSA or whole model",
          "checks": [], "timing_rounds": 20, "replays_per_round": 100,
          "DFX": False, "PMU": False, "depgen": False}
report["helper_manifest_sha"] = hashlib.sha256((Path(__file__).resolve().parent / "manifest.json").read_bytes()).hexdigest()
report["source_modules"] = {}
for name in ("baseline_root", "candidate_root", "live_staging_sparse", "baseline_sparse", "vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.decode_sparse_attn_csa"):
    module = importlib.import_module(name)
    path = Path(module.__file__).resolve()
    report["source_modules"][name] = {"file": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
assert report["source_modules"]["live_staging_sparse"]["sha256"] == "36a3b7ebb2ab42ed4dd8c081f66b2ea60a07d40c55ba021da8552f4de5f2ab12"
assert report["source_modules"]["vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.decode_sparse_attn_csa"]["sha256"] == "248d8b11bb0a045f7863c0b264d962845dcabafa51cbf1e5fafee413fa8dc6d5"


def save():
    (args.out / "result.json").write_text(json.dumps(report, indent=2) + "\n")


def exact(a, b):
    return a.shape == b.shape and a.dtype == b.dtype and torch.equal(a.contiguous().view(torch.uint8), b.contiguous().view(torch.uint8))


def check(label, actual, expected):
    same = exact(actual, expected)
    report["checks"].append({"label": label, "bit_equal": same})
    save()
    assert same, "FIRST_BIT_DIFFERENCE " + label


torch.npu.set_device(0)
torch.npu.config.allow_internal_format = True
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
pypto.torch.init(device=0, platform="a2a3", runtime="tensormap_and_ringbuffer")
inputs = [v.to("npu:0") for v in host_inputs]
shapes = ((tokens, 64), (tokens, 64), (tokens, 64, 512), (tokens, 64, 512))
labels = ("mi", "li", "oi", "heads")
rows = {}
save()
with torch.inference_mode():
    for name, root in (("baseline", baseline), ("candidate", candidate)):
        op = pypto.torch.register(root, "qkpv_live_staging_" + name + "::run")
        owners, outputs = [], []
        for shape, dtype in zip(shapes, (torch.float32, torch.float32, torch.float32, torch.bfloat16)):
            count = 1
            for d in shape:
                count *= d
            owner = torch.full((count + 128,), -123.0, dtype=dtype, device="npu:0")
            owners.append(owner)
            outputs.append(owner[64:-64].reshape(shape))
        for _ in range(3):
            op(*inputs, *outputs)
        torch.npu.synchronize()
        graph = torch.npu.NPUGraph()
        with torch.npu.graph(graph):
            op(*inputs, *outputs)
        torch.npu.synchronize()
        for value in outputs:
            value.fill_(float("nan"))
        graph.replay()
        torch.npu.synchronize()
        for label, value in zip(labels, outputs):
            check(name + ".raw_replay." + label, value.cpu(), gold[label])
        rows[name] = (graph, outputs, owners, op)

    def compare_live(label):
        for field, base, cand in zip(labels, rows["baseline"][1], rows["candidate"][1]):
            assert bool(torch.isfinite(base).all()) and bool(torch.isfinite(cand).all()), (label, field, "nonfinite")
            check(label + "." + field, cand.cpu(), base.cpu())
        for name, (_, _, owners, _) in rows.items():
            for index, owner in enumerate(owners):
                assert bool((owner[:64] == -123.0).all()) and bool((owner[-64:] == -123.0).all()), (name, index, "guard")

    compare_live("A")
    initial_outputs = [value.cpu() for value in rows["baseline"][1]]
    inputs[0].add_(0.125)
    changed_q = (host_inputs[0].to("npu:0") + 0.125).cpu()
    check("Q_B_actual_input", inputs[0].cpu(), changed_q)
    for graph, _, _, _ in rows.values():
        graph.replay()
    torch.npu.synchronize()
    compare_live("B_Q_changed")
    for name in rows:
        assert any(not exact(value.cpu(), old) for value, old in zip(rows[name][1], initial_outputs)), (name, "stale B")
    inputs[0].zero_()
    for graph, _, _, _ in rows.values():
        graph.replay()
    torch.npu.synchronize()
    compare_live("Q_zero")
    assert bool((inputs[0] == 0).all())
    for name in rows:
        assert any(not exact(value.cpu(), old) for value, old in zip(rows[name][1], initial_outputs)), (name, "stale zero")
    inputs[0].copy_(host_inputs[0])
    for graph, _, _, _ in rows.values():
        graph.replay()
    torch.npu.synchronize()
    compare_live("A_restored")
    for name, (_, outputs, _, _) in rows.items():
        for label, value in zip(labels, outputs):
            check(name + ".A_restored." + label, value.cpu(), gold[label])
        check(name + ".Native_heads", outputs[-1].cpu(), bank["native_heads"].reshape(tokens, 64, 512))
    samples = {name: [] for name in rows}
    for iteration in range(20):
        for name in (("baseline", "candidate") if iteration % 2 == 0 else ("candidate", "baseline")):
            graph, outputs, owners, _ = rows[name]
            begin, end = torch.npu.Event(enable_timing=True), torch.npu.Event(enable_timing=True)
            begin.record()
            for _ in range(100):
                graph.replay()
            end.record()
            torch.npu.synchronize()
            samples[name].append(begin.elapsed_time(end) * 1000 / 100)
        if iteration % 5 == 4:
            compare_live("timing_round" + str(iteration))
    for index, (value, expected) in enumerate(zip(inputs, host_inputs)):
        check("device_readonly." + str(index), value.cpu(), expected)
    for name, (_, outputs, _, _) in rows.items():
        for label, value in zip(labels, outputs):
            check(name + ".final_gold." + label, value.cpu(), gold[label])
    report["timing_us"] = {name: {"min": min(v), "median": statistics.median(v), "mean": statistics.mean(v), "max": max(v), "samples": v} for name, v in samples.items()}
    report["paired_speedup_percent"] = [100 * (a - b) / a for a, b in zip(samples["baseline"], samples["candidate"])]
    report["pass"] = report["complete"] = True
    save()
print("SPARSE_GRAPH_AB_PASS", json.dumps(report["timing_us"]), flush=True)
