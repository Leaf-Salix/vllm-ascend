"""只导出生产 sparse 的统计量；不复制或改写 QK/PV 核体。"""
import pypto.language as pl
from baseline_sparse import (
    sparse_attn_csa, T_DYN, B_DYN, ORI_BLOCK_NUM_DYN, CMP_BLOCK_NUM_DYN,
    H, HEAD_DIM, ROPE_DIM, IDX_TOPK, BLOCK_SIZE,
)
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.layout import (
    ORIGINAL_TABLE_COLUMNS_DYN, COMPRESSED_TABLE_COLUMNS_DYN,
)


def _sparse_probe(
    q: pl.Tensor[[T_DYN, H, HEAD_DIM], pl.BF16],
    ori_kv: pl.Tensor[[ORI_BLOCK_NUM_DYN, BLOCK_SIZE, 1, HEAD_DIM], pl.BF16],
    ori_table: pl.Tensor[[B_DYN, ORIGINAL_TABLE_COLUMNS_DYN], pl.INT32],
    cmp_kv: pl.Tensor[[CMP_BLOCK_NUM_DYN, BLOCK_SIZE, 1, HEAD_DIM], pl.BF16],
    cmp_table: pl.Tensor[[B_DYN, COMPRESSED_TABLE_COLUMNS_DYN], pl.INT32],
    topk: pl.Tensor[[T_DYN, IDX_TOPK], pl.INT32],
    positions: pl.Tensor[[T_DYN, 1], pl.INT64],
    lengths: pl.Tensor[[B_DYN], pl.INT32],
    requests: pl.Tensor[[T_DYN], pl.INT32],
    sink: pl.Tensor[[H], pl.FP32],
    cos: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32],
    sin: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32],
    mi_out: pl.Out[pl.Tensor[[T_DYN, H], pl.FP32]],
    li_out: pl.Out[pl.Tensor[[T_DYN, H], pl.FP32]],
    oi_out: pl.Out[pl.Tensor[[T_DYN, H, HEAD_DIM], pl.FP32]],
    heads: pl.Out[pl.Tensor[[T_DYN, H, HEAD_DIM], pl.BF16]],
):
    q.bind_dynamic(0, T_DYN)
    ori_kv.bind_dynamic(0, ORI_BLOCK_NUM_DYN)
    ori_table.bind_dynamic(0, B_DYN)
    ori_table.bind_dynamic(1, ORIGINAL_TABLE_COLUMNS_DYN)
    cmp_kv.bind_dynamic(0, CMP_BLOCK_NUM_DYN)
    cmp_table.bind_dynamic(0, B_DYN)
    cmp_table.bind_dynamic(1, COMPRESSED_TABLE_COLUMNS_DYN)
    topk.bind_dynamic(0, T_DYN)
    positions.bind_dynamic(0, T_DYN)
    lengths.bind_dynamic(0, B_DYN)
    requests.bind_dynamic(0, T_DYN)
    cos.bind_dynamic(0, T_DYN)
    sin.bind_dynamic(0, T_DYN)
    mi_out.bind_dynamic(0, T_DYN)
    li_out.bind_dynamic(0, T_DYN)
    oi_out.bind_dynamic(0, T_DYN)
    heads.bind_dynamic(0, T_DYN)
    rows = pl.tensor.dim(q, 0)
    mi, li, oi, rope_cos, rope_sin, qk_tid, rope_tid = sparse_attn_csa(
        q, ori_kv, ori_table, cmp_kv, cmp_table, topk, positions, lengths,
        requests, sink, cos, sin, 32,
    )
    mi_rows = pl.reshape(mi, [rows, H])
    li_rows = pl.reshape(li, [rows, H])
    oi_flat = pl.reshape(oi_out, [rows * H, HEAD_DIM])
    heads_flat = pl.reshape(heads, [rows * H, HEAD_DIM])
    with pl.spmd(24, name_hint="diagnostic_publish", deps=[qk_tid]):
        lane = pl.tile.get_block_idx()
        for token in pl.range(lane, rows, 24):
            pl.store(pl.load(mi_rows, [token, 0], [1, H]), [token, 0], mi_out)
            pl.store(pl.load(li_rows, [token, 0], [1, H]), [token, 0], li_out)
        for panel in pl.range(lane, rows * (H // 16), 24):
            row = panel * 16
            value = pl.load(oi, [row, 0], [16, HEAD_DIM])
            denominator = pl.load(li, [row, 0], [16, 1])
            pl.store(value, [row, 0], oi_flat)
            normalized = pl.cast(pl.row_expand_div(value, denominator), pl.BF16, mode="rint")
            pl.store(normalized, [row, 0], heads_flat)
    return mi_out, li_out, oi_out, heads


sparse_probe = pl.jit(_sparse_probe)
