import hashlib,importlib,json,os,sys
from pathlib import Path
here=Path(__file__).resolve().parent
assert not any("whole-swa-cube-v2" in s and not s.endswith(("snapshot/source","snapshot/source/tests/pypto_test")) for s in sys.path), sys.path
custom = sys.modules.get("sitecustomize")
assert custom is not None and Path(custom.__file__).resolve() == Path("/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/root-fix-20261016/sitecustomize.py")
assert all(not os.environ.get(n) for n in ("ADMISSION_TRACE_DIR","FULL_PROBE_DIR","FULL_PROBE_MODE","LOW_ACCEPTANCE_FIRST_STEP_DIR")), "unexpected active whole-model observer"
print("REUSED_RUNTIME_SELECTION_HOOK", custom.__file__)
manifest=json.loads((here/"manifest.json").read_text())
for n,d in manifest.items(): assert hashlib.sha256((here/n).read_bytes()).hexdigest()==d,n
source=Path(os.environ["SOURCE_ROOT"])
s=source/"vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision/decode_sparse_attn_csa.py"
assert hashlib.sha256(s.read_bytes()).hexdigest()=="248d8b11bb0a045f7863c0b264d962845dcabafa51cbf1e5fafee413fa8dc6d5"
for name in ["pypto","simpler","torch","torch_npu","vllm","vllm_ascend"]:
 m=importlib.import_module(name); print(name,getattr(m,"__version__",None),m.__file__)
 if name=="pypto":assert Path(m.__file__).resolve().is_relative_to(Path(os.environ["LOW_ACCEPTANCE_RUNTIME_PACKAGE"])/"pypto")
 if name=="simpler":assert Path(m.__file__).resolve().is_relative_to(Path("/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/python/simpler"))
 if name=="vllm_ascend":assert Path(m.__file__).resolve().is_relative_to(source)
for n in ["PTOAS_ROOT","ASCEND_HOME_PATH","CCACHE_DIR","ATB_HOME_PATH"]:assert os.environ.get(n),n
assert os.environ["PYTHONNOUSERSITE"]=="1"
print("VECTOR_MTE2_NO_DEVICE_PREFLIGHT_OK")
