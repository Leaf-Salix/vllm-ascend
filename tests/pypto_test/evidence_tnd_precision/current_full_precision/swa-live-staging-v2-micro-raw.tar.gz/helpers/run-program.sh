#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
here=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "$here/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
unset SIMPLER_PMU_EVENT_TYPE
variant="${1:?variant}"; label="${2:?label}"; event="${3:?event}";shift 3
[[ "$label" =~ ^[A-Za-z0-9_.-]+$ ]]
mkdir -p "$here/results"
mkdir "$here/results/$label"
python "$here/preflight.py" > "$here/results/$label/preflight.log" 2>&1
timeout --signal=TERM --kill-after=15s 750s python "$here/run_program.py" \
 --variant "$variant" --bank /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/qkpv-measurement-20261019-codex/capture-b4/csa-results/native-sparse-bank/data/native-sparse-bank.pt \
 --bank-sha 66158da293867dc48626083df47404b919ee859fb9719c8d55c0f88f4809668e \
 --gold-stats /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/qkpv-measurement-20261019-codex/sparse-program/program-results/b4-stats-gold-device/data/stats-gold.pt \
 --gold-sha eb43040864b3b1209d1533f8ce0f2de68b6cee6be322905f45fba6b44e82feb2 \
 --event "$event" --out "$here/results/$label/data" "$@" > "$here/results/$label/run.log" 2>&1
