#!/usr/bin/env bash
here=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/tnd-precision-delivery-20261018/env.sh
export SOURCE_ROOT=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/qkpv-measurement-20261019-codex/whole-swa-cube-v2/snapshot/source
export job="$here"
export PYTHONPATH="$here:$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
export PYPTO_PROG_BUILD_DIR="$here/build" PYPTO_CACHE_DIR="$here/cache"
export PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1
export HCCL_DETERMINISTIC=true CMAKE_BUILD_PARALLEL_LEVEL=4 MAX_JOBS=4
