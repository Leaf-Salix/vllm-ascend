# 剩余Vector和MTE2：测量与候选边界

基准7078bc644，固定Nal性能版a919f119与Native arch32源码。只做诊断，不先改正式精度版。

## 源码拆分

- AIV Vector：KV staging每64行先填零；softmax的scale、bias、max、exp和Native实际K归约；概率CAST_ROUND；PV后按Native顺序做online状态更新；辅助索引/rope另task，不混算入qk_pv。
- AIV MTE2：原始paged KV及逐行compressed gather；score、bias、旧mi/li、alpha、PV输出、softmax_copy64回读。不能用逻辑字节数推断延迟，尤其compressed小DMA和Scalar寻址。
- AIC MTE2：Q进入L1、QK的KV面板进入L1、PV probability与需要重载的KV。7078已跳过SWA无效Cube片，但QK仍读取所有4片。
- Native按actualSingleProcessSInnerSize计算nL1Loops，Nal用K128块；两者不存在当前SWA补384行给无消费者读入的相同行为。Nal的softmax/CAST与online顺序不同，不能作为精度金值。

## 单因素分解

基准SWA128仍产生512行KV staging，每行512个BF16。每token跨两AIV：

| 工作 | 基准 | AIC读清理 | 完整live-staging |
| --- | ---: | ---: | ---: |
| AIV KV零初始化元素 | 262144 | 262144 | 65536 |
| AIV KV GM写字节 | 524288 | 524288 | 131072 |
| AIC QK KV GM读字节 | 524288 | 131072 | 131072 |

此表仅SWA，不含原始cache有效行gather、PV part0 reload和compressed。AIC读清理版只把qk_l1 gather放进已有Cube有效片guard；完整候选再跳过AIV未消费的tail fill/store。QK/PV实际算术、SWA概率零尾、K512 softmax/实际K归约、四event、compressed所有4片以及TND请求映射均保持。当前WIN固定128、Cube128；不泛化任意WIN。

先用相同bank、PMU2分别执行基准/读清理/完整候选，逐bit比较Native BF16 heads和原PTO raw FP32 mi/li/oi。对比AIC MTE2和AIV Vector/MTE3的变化判断代价。单独运行每个PMU进程，不叠加依赖图/泳道。计数允许重叠，差值不是互斥阶段耗时，不把total-busy称为同步等待。

源、助手、实际生成物要分别锁SHA，保留实际kernel_config的func_id映射。之后无DFX FULL graph交错，A/B/ABA、Q0、NaN poison、guard和只读输入门禁不减少；各B4/B40重复。只有收益稳定才进完整CSA和8K/128K整模型。

## 环境门禁记录

测量前发现whole-v2 env会前置整模型helper目录，改复用已验收的单层delivery env并显式选择v2源码。试过完全删掉sitecustomize/用PYTHONPATH白名单，但该环境依赖既有runtime_select/package_select和Torch-NPU shutdown兼容选择；白名单预检缺Torch，故未提交设备任务，放弃这一环境变更。最终保持已验收的runtime选择hook，明确拒绝whole-v2 helper路径、ADMISSION/FULL_PROBE启用，并严格核对PyPTO/Simpler/Ascend实际来源。SDK/venv均未修改。

两次rsync连接被服务器关闭，重试后成功。一次通过PTY传长文本触发终端行长限制，已中断该SSH会话并恢复正常rsync，无设备运行。原始任务/精度结果不受影响。

## 本轮局部收益验收口径

B4首轮pilot为219.472→216.441µs，16/20配对更快，不能沿用上轮“80对全正”的事实。后续B4/B40分别至少2次独立任务、每次20对×100replay，所有样本保留。验收要求每次配对差值均值为正，至少75%配对为正，双侧95% Student-t均值区间下界>0（n=20，t=2.093）；任一配置重复不满足则不认定稳定，不据此提交整模型。此为新候选的小幅收益判据，未改变精度门禁，不将上轮验收重新标记成本轮。
