"""只归档本轮显式指定的终态任务，不包含模型/缓存大张量。"""
import argparse,hashlib,io,json,subprocess,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--case',choices=('8k','128k'),required=True);p.add_argument('--tasks',nargs=2,required=True);p.add_argument('--suffix',required=True);a=p.parse_args()
assert a.suffix in ('20261018','20261018-v2')
J=Path(__file__).resolve().parent.parent
B=J.parent
R=Path('/data/pyptouser/yejia/lc128')
files={}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for arm in ('native','pto'):
 root=R/f'perf-single-dsl-{a.case}-{arm}-{a.suffix}'
 assert not list(root.glob('**/*STOP.json'))
 for f in root.iterdir():
  if f.is_file() and f.suffix in ('.json','.log','.jsonl'):files[f'results/{root.name}/{f.name}']=f
for f in J.rglob('*'):
 if f.is_file() and f.suffix in ('.py','.sh','.json','.md','.log') and '__pycache__' not in f.parts:
  files[f'helpers/{f.relative_to(J)}']=f
identity=('root-fix-20261016/manifest.json','root-fix-20261016/env.sh','full-dsl-single-entry-20261018/single-v1/manifest.json','low-acceptance-20261010/runtime-package/manifest.json','low-acceptance-20261010/official-static-cache/metadata.json','low-acceptance-20261010/sitecustomize.py','low-acceptance-20261010/official-static-cache.py','full-pto-8k-b40-20261018/helper-v2/verify_assets.py','full-pto-128k-b24-20261018/helper-v1/check_inputs.py')
for rel in identity:files['identity/'+rel]=B/rel
package=B/'full-dsl-single-entry-20261018/single-v1/source/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision'
for f in package.glob('*.py'):files['source/'+f.name]=f
assert sum(n.startswith('source/') for n in files)==15
for arm in ('native','pto'):
 config=json.loads((R/f'perf-single-dsl-{a.case}-{arm}-{a.suffix}/configuration.json').read_text())
 for rank in range(16):
  root=Path(config['gold'])
  for name in (f'rank{rank}.mixed.json',f'request_stats_rank{rank}.jsonl'):
   files['native-gold/'+a.case+'/'+name]=root/name
status={};times={}
for task in a.tasks:
 assert task.startswith('task_20261018_')
 state=subprocess.run(['task-submit','--status',task],check=True,text=True,capture_output=True).stdout
 assert state.strip().startswith('completed'),state
 status[task]=state
 log=subprocess.run(['task-submit','--log',task],check=True,text=True,capture_output=True).stdout
 raw=J/(task+'.task.log');raw.write_text(log);files['task-logs/'+raw.name]=raw
 candidates=[Path('/data/server-toolkits/pto-task/state/done')/(task+x) for x in ('','.env')]
 rows=[f for f in candidates if f.is_file()];assert len(rows)==1
 allowed=('SUBMIT_TIME','START_TIME','FINISH_TIME','EXIT_CODE','MAX_TIME','USER','DEVICE_NUM')
 fields=dict(line.split('=',1) for line in rows[0].read_text().splitlines() if line.partition('=')[0] in allowed)
 assert fields['EXIT_CODE']=='0'
 from datetime import datetime
 fields['execution_seconds']=(datetime.fromisoformat(fields['FINISH_TIME'])-datetime.fromisoformat(fields['START_TIME'])).total_seconds()
 fields['queue_seconds']=(datetime.fromisoformat(fields['START_TIME'])-datetime.fromisoformat(fields['SUBMIT_TIME'])).total_seconds()
 assert 0<fields['execution_seconds']<900
 fields['planned_max_time_seconds']=780
 fields['max_time_source']='submitted --max-time 780 command; done metadata may omit MAX_TIME'
 if 'MAX_TIME' in fields:
  assert int(fields['MAX_TIME'])==780
  fields['queue_record_max_time_seconds']=int(fields['MAX_TIME'])
 times[task]=fields
manifest={name:{'sha256':sha(f),'bytes':f.stat().st_size} for name,f in files.items()}
archive=J/('pair-'+a.case+'-evidence-v2.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for name,f in sorted(files.items()):tar.add(f,arcname=name,recursive=False)
 for name,data in (('evidence-manifest.json',manifest),('task-statuses.json',status),('task-times.json',times)):
  raw=(json.dumps(data,indent=2)+'\n').encode();item=tarfile.TarInfo(name);item.size=len(raw);tar.addfile(item,io.BytesIO(raw))
print(json.dumps({'archive':str(archive),'sha256':sha(archive),'files':len(files),'bytes':archive.stat().st_size,'tasks':times},indent=2))
