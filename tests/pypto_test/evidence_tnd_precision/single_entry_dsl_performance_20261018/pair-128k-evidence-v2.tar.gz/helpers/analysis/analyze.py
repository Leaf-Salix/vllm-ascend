"""CPU-only audit of real mixed-model timings; missing/unequal work is rejected."""
import argparse,hashlib,json,math,statistics
from pathlib import Path


def distribution(values):
    if not values or not all(math.isfinite(v) and v>0 for v in values):raise ValueError('Invalid timing samples')
    ordered=sorted(values)
    return {'count':len(values),'mean':statistics.mean(values),'min':min(values),'max':max(values),'p50':statistics.median(values),'p95':ordered[math.ceil(.95*len(values))-1]}


def normalized(rows):return [{k:v for k,v in row.items() if k not in ('call','input_ids_cpu')} for row in rows]


def audit(root):
    config=json.loads((root/'configuration.json').read_text());reports=[]
    if config['case']!='128k' or config['repeats']!=2:raise ValueError('Wrong two-round 128K configuration')
    if list(root.glob('**/*STOP.json')):raise ValueError('First difference marker present')
    if config['variant']!='tnd_full_precision' or config['production_git_commit']!='a20bcdb76b2c4daaed2cff3159dc4dada28056d9' or config['source_manifest_sha256']!='7b0650b926a557241b622eba4f032731e7b21d75d807c3b6baccfe689b29c960':raise ValueError('Wrong complete PTO source identity')
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    if sha(config['snapshot_manifest'])!=config['source_manifest_sha256']:raise ValueError('Changed source manifest')
    for name,digest in json.loads(Path(config['snapshot_manifest']).read_text())['files'].items():
        if sha(Path(config['snapshot'])/name)!=digest:raise ValueError('Source changed '+name)
    job=Path(__file__).resolve().parent.parent
    if sha(job/'helper-manifest.json')!=config['helper_manifest_sha256']:raise ValueError('Helper manifest changed')
    for name,digest in json.loads((job/'helper-manifest.json').read_text())['files'].items():
        if sha(job/name)!=digest:raise ValueError('Helper changed '+name)
    expected_requests=config['active_requests_for_timing'];expected_tokens=expected_requests*6;bucket=config['capture_sizes'][-1]
    for rank in range(16):
        d=json.loads((root/f'rank{rank}.real_perf.json').read_text())
        if len(d['rounds'])!=2 or d['variant']!='tnd_full_precision' or d['backend']!=config['backend']:raise ValueError('Incomplete/wrong arm')
        runtime=d['worker_runtime_config']
        if not runtime or any(v['deterministic_level']!=1 or not v['torch_deterministic'] or v['hccl_deterministic']!='true' or v['dynamic_eplb'] or v['cann_event_work_mode']!=1 for v in runtime):raise ValueError('Runtime drift')
        if d['warmup']['decode_tokens']!=192 or config['warmup_tokens']!=192:raise ValueError('Warmup missing')
        for worker in d['implementations']:
            csa=[v for v in worker if v['kind']=='csa'];hca=[v for v in worker if v['kind']=='hca']
            expected='pto' if d['backend']=='pto' else 'native'
            if len(csa)!=21 or len(hca)!=20 or any(v['implementation']!=expected for v in csa) or any(v['implementation']!='native' for v in hca):raise ValueError('Layer selection wrong')
            if expected=='pto' and any(not v['runtime_class'].endswith('.deepseek_v4_flash_csa_tnd_full_precision.service') for v in csa):raise ValueError('Wrong CSA variant')
        gold_root=Path(config['gold'])
        gold_data=json.loads((gold_root/f'rank{rank}.mixed.json').read_text())
        gold_tokens={v['key']:v['output_token_ids'] for v in gold_data['requests']}
        gold_events={v['key']:v['events'] for v in [json.loads(line) for line in (gold_root/f'request_stats_rank{rank}.jsonl').read_text().splitlines()]}
        warm=d['warmup']['requests']
        if len(warm)!=d['batch'] or {v['key'] for v in warm}!=set(gold_tokens) or any(len(v['output_token_ids'])!=192 or v['preemptions']!=0 or v['output_token_ids']!=gold_tokens[v['key']] or v['events']!=gold_events[v['key']] for v in warm):raise ValueError('Complete warmup tokens/events differ from Native gold')
        reference=None
        for index,row in enumerate(d['rounds'],1):
            if row['iteration']!=index or len(row['timing'])!=1 or len(row['requests'])!=d['batch']:raise ValueError('Incomplete round')
            requests=row['requests'];same=[(r['key'],r['output_token_ids'],r['events']) for r in requests]
            if len({v['key'] for v in requests})!=d['batch']:raise ValueError('Duplicate request key')
            if reference is not None and same!=reference:raise ValueError('Within-process repeat token/events differ')
            reference=same
            if any(len(r['output_token_ids'])!=192 or r['preemptions']!=0 for r in requests):raise ValueError('Token count/preemption')
            if any(r['output_token_ids']!=gold_tokens[r['key']] or r['events']!=gold_events[r['key']] for r in requests):raise ValueError('Complete tokens/events differ from frozen precision Native gold')
            proposed=sum(p for r in requests for p,a in r['events']);accepted=sum(a for r in requests for p,a in r['events']);drafts=sum(len(r['events']) for r in requests)
            actual=row['spec_decode']
            if [drafts,proposed,accepted]!=[actual['counters'][k] for k in ('num_drafts','num_draft_tokens','num_accepted_tokens')]:raise ValueError('Counter/event mismatch')
            timing=row['timing'][0];meta=timing['metadata']
            q=timing['identity']['static_full_qualification']
            if q['backend']!=d['backend'] or not q['ready'] or q['actual_reselections']!=1 or q['validated_reuses']<=0 or q['metadata_sha256']!=config['static_metadata_sha256']:raise ValueError('Static selection identity/qualification missing')
            if d['backend']=='pto':
                if q['root_namespace']!='dsv4_csa_tnd_full_precision::attention' or q['root_abi_tensors']!=62 or not config.get('single_pto_entry') or config.get('handwritten_cpp') is not False:raise ValueError('Wrong pure DSL single root identity')
                if q['restored_modules']!=['hc_pre','input_norm','wkv','indexer_weights','o_proj','hc_post'] or set(q['single_root_counts'])!={f'model.layers.{i}.self_attn.attn' for i in range(2,43,2)}:raise ValueError('Incomplete PTO replacement')
                if any(any(c.get(str(n),{}).get('warmup',0)<=0 or c.get(str(n),{}).get('capture',0)<=0 for n in (6,bucket)) for c in q['single_root_counts'].values()):raise ValueError('PTO single root bucket capture missing')
            elif q['restored_modules'] or q['single_root_counts']:raise ValueError('Native arm unexpectedly has PTO runtime')
            if d['backend']=='pto':
                selection=timing['identity']['capture_time_selection'];expected_layers={f'model.layers.{i}.self_attn.attn' for i in range(2,43,2)}
                if set(selection)!=expected_layers or any(any(v.get(f'pto_tokens{n}',0)<1 for n in (6,bucket,expected_requests)) for v in selection.values()):raise ValueError('PTO graph selection incomplete')
                if not timing['identity']['pypto_file'].endswith('/low-acceptance-20261010/runtime-package/pypto/__init__.py'):raise ValueError('Wrong private SDK identity')
            if not timing['sufficient'] or timing['measured_steps']!=20 or len(meta)!=20 or len(timing['cycle']['samples_us'])!=19:raise ValueError('Insufficient timing window')
            for m in meta:
                if m['graph_mode']!='FULL' or m['padded_tokens']!=bucket or m['actual_tokens']!=expected_tokens or m['requests']!=expected_requests or m['dp_tokens']!=[bucket]*16:raise ValueError('Wrong graph/workload')
            if len(timing['forward']['samples_us'])!=20:raise ValueError('Wrong event count')
            counts=timing['cycle']['actual_output_tokens']
            if len(counts)!=19:raise ValueError('Wrong cycle output count length')
            for i,(left,right) in enumerate(zip(meta,meta[1:])):
                if left['keys']!=right['keys']:raise ValueError('Cycle keys changed')
                advances=[right['positions_cpu'][q]-left['positions_cpu'][p] for p,q in zip(left['query_bounds'][:-1],right['query_bounds'][:-1],strict=True)]
                if not all(type(v)is int and 1<=v<=6 for v in advances) or type(counts[i])is not int or sum(advances)!=counts[i]:raise ValueError('Cycle output count not backed by position advance')
            before=row['identity_before'][0]['cache_stats'];after=timing['identity']['cache_stats']
            for field in ('generation_builds','binary_builds','bypasses','invalid_entries','storage_errors','forced_rebuilds'):
                if after[field]!=before[field] or (field not in ('generation_builds','binary_builds') and after[field]!=0):raise ValueError('Measured cache changes/errors')
            if index>1 and normalized(meta)!=normalized(d['rounds'][0]['timing'][0]['metadata']):raise ValueError('Repeat measured CPU workloads differ')
        log=(root/f'rank{rank}.log').read_text(errors='replace')
        if 'OFFICIAL_STATIC_RESELECT success=1' not in log or 'OFFICIAL_STATIC_CACHE packages=13 metadata_sha=863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602' not in log or 'reselect_static_kernel failed' in log or 'execute op_compiler' in log:raise ValueError('Official static package reuse missing')
        reports.append(d)
    forward=[];cycles=[];throughput=[];batch=[];repeat_means=[]
    for repeat in range(2):
        reference_meta=normalized(reports[0]['rounds'][repeat]['timing'][0]['metadata'])
        reference_requests=reports[0]['rounds'][repeat]['requests']
        if any(normalized(r['rounds'][repeat]['timing'][0]['metadata'])!=reference_meta or r['rounds'][repeat]['requests']!=reference_requests for r in reports):raise ValueError('DP replicas workloads/tokens/events differ')
        fs=[r['rounds'][repeat]['timing'][0]['forward']['samples_us'] for r in reports]
        cs=[r['rounds'][repeat]['timing'][0]['cycle']['samples_us'] for r in reports]
        fmax=[max(row[i] for row in fs) for i in range(20)]
        cmax=[max(row[i] for row in cs) for i in range(19)]
        total_outputs=sum(sum(r['rounds'][repeat]['timing'][0]['cycle']['actual_output_tokens']) for r in reports)
        forward.extend(fmax);cycles.extend(cmax);throughput.append(total_outputs/(sum(cmax)*1e-6));batch.append(max(r['rounds'][repeat]['elapsed_batch_including_cache_io_seconds'] for r in reports))
        repeat_means.append({'round':repeat+1,'max_rank_forward_mean_us':statistics.mean(fmax),'max_rank_cycle_mean_us':statistics.mean(cmax),'approx_aggregate_output_tokens_per_second':throughput[-1],'batch_including_io_seconds':batch[-1]})
    return config,reports,{'forward_max_rank_us':distribution(forward),'cycle_max_rank_us':distribution(cycles),'approx_aggregate_output_tokens_per_second':distribution(throughput),'batch_including_io_seconds':distribution(batch),'rounds':repeat_means,'scope':'Max of each aligned step duration across rank clocks, not a globally synchronized service throughput measurement; CPU metadata overhead present in cycle; batch wall includes bank restore/enqueue/barrier.'}


def main():
    p=argparse.ArgumentParser();p.add_argument('native',type=Path);p.add_argument('--pto',type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args()
    nc,nr,ns=audit(a.native);report={'native':ns,'pass':True,'case':nc['case'],'workload_match_scope':'CPU request scheduling geometry/positions/query bounds/DP/graph plus complete Native-gold outputs/events. Raw input_ids_cpu preserved but excluded: async GPU sample/draft scatter and GPU-only placeholder cleanup make CPU staging IDs non-authoritative; no new per-step GPU-ID copy.'}
    if a.pto:
        pc,pr,ps=audit(a.pto)
        for key in ('case','batch','blocks','active_requests_for_timing','capture_sizes','utilization','bank','decode_tokens','warmup_tokens','repeats','warmup_steps','steps','variant','source_manifest_sha256','runtime_manifest_sha256','bank_plan_sha256','helpers_sha256','static_metadata_sha256','helper_manifest_sha256','gold'):
            if nc[key]!=pc[key]:raise ValueError('Arm configuration differs: '+key)
        for rank in range(16):
            if nr[rank]['worker_runtime_config']!=pr[rank]['worker_runtime_config']:raise ValueError('Actual worker runtime differs')
            for repeat in range(2):
                n=nr[rank]['rounds'][repeat];q=pr[rank]['rounds'][repeat]
                if n['requests']!=q['requests'] or normalized(n['timing'][0]['metadata'])!=normalized(q['timing'][0]['metadata']):raise ValueError(f'Native/PTO work differs rank{rank} repeat{repeat}')
        report.update(pto=ps,all16_actual_tokens_events_equal=True,measured_cpu_workloads_equal=True)
        report['forward_latency_reduction_percent']=(1-ps['forward_max_rank_us']['mean']/ns['forward_max_rank_us']['mean'])*100
        report['cycle_latency_reduction_percent']=(1-ps['cycle_max_rank_us']['mean']/ns['cycle_max_rank_us']['mean'])*100
    with a.output.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
    print(json.dumps(report))
if __name__=='__main__':main()
