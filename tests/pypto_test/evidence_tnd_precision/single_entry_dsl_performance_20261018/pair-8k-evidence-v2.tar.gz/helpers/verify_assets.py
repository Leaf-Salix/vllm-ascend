"""只读核查当前完整精度源码、两种已验收Native黄金结果及助手身份。"""
import hashlib,json,os,runpy
from pathlib import Path
B=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
J=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
S=B/'full-dsl-single-entry-20261018/single-v1'
assert sha(S/'manifest.json')=='7b0650b926a557241b622eba4f032731e7b21d75d807c3b6baccfe689b29c960'
p=json.loads((J/'production-package.json').read_text())
assert p['git_commit']=='a20bcdb76b2c4daaed2cff3159dc4dada28056d9' and len(p['files'])==15
for name,digest in p['files'].items():assert sha(S/'source'/name)==digest,name
for name,digest in json.loads((J/'helper-manifest.json').read_text())['files'].items():assert sha(J/name)==digest,name
case=os.environ['PERF_CASE']
# Original asset checkers bind their historical math snapshot as well as Native gold.
# Verify those originals under their expected source, then restore the new source.
source_root=os.environ['SOURCE_ROOT']
os.environ['SOURCE_ROOT']=str(B/'full-pto-8k-b40-20261018/step12/source')
try:
 if case=='8k':runpy.run_path(str(B/'full-pto-8k-b40-20261018/helper-v2/verify_assets.py'),run_name='__main__')
 elif case=='128k':runpy.run_path(str(B/'full-pto-128k-b24-20261018/helper-v1/check_inputs.py'),run_name='__main__')
 else:raise ValueError('Wrong performance case')
finally:
 os.environ['SOURCE_ROOT']=source_root
assert not list((S/'source/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision').glob('*.cpp'))
print('PERFORMANCE_ASSETS_VERIFIED single-root pure-DSL Native-gold '+case)
