#!/usr/bin/env bash
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/root-fix-20261016/env.sh"
export PYTHONPATH="$base/single-dsl-real-model-perf-20261018:$PYTHONPATH"
unset ADMISSION_TRACE_DIR FULL_PROBE_DIR FULL_PROBE_MODE LOW_ACCEPTANCE_FIRST_STEP_DIR OFFLINE_PTO_SWIMLANE_DIR

export SOURCE_ROOT="$base/full-dsl-single-entry-20261018/single-v1/source"
export PYTHONPATH="$base/single-dsl-real-model-perf-20261018:$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
export PTO_CSA_VARIANT=tnd_full_precision
export OMP_NUM_THREADS=10 OMP_PROC_BIND=false
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache CMAKE_BUILD_PARALLEL_LEVEL=4
unset LOCAL_WORLD_SIZE
