"""Small immutable performance evidence archive, no model/tensor/cache payloads."""
import argparse,hashlib,io,json,subprocess,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--labels',nargs='+',required=True);p.add_argument('--tasks',nargs='+',required=True);p.add_argument('--name',required=True);a=p.parse_args()
job=Path(__file__).resolve().parent.parent
files={}
for label in a.labels:
 if label not in ('perf-single-dsl-8k-native-20261018','perf-single-dsl-8k-pto-20261018','perf-single-dsl-128k-native-20261018','perf-single-dsl-128k-pto-20261018'):raise ValueError('Explicit own results only')
 root=Path('/data/pyptouser/yejia/lc128')/label
 for f in root.iterdir():
  if f.is_file() and f.suffix in ('.json','.log','.jsonl'):files[f'results/{label}/{f.name}']=f
for f in job.rglob('*'):
 if f.is_file() and f.suffix in ('.py','.sh','.json','.md') and '__pycache__' not in f.parts:files[f'helpers/{f.relative_to(job)}']=f
base=job.parent
for rel in ('root-fix-20261016/manifest.json','root-fix-20261016/env.sh','full-dsl-single-entry-20261018/single-v1/manifest.json','low-acceptance-20261010/runtime-package/manifest.json','low-acceptance-20261010/official-static-cache/metadata.json','low-acceptance-20261010/sitecustomize.py','low-acceptance-20261010/official-static-cache.py','full-pto-8k-b40-20261018/helper-v2/verify_assets.py','full-pto-128k-b24-20261018/helper-v1/check_inputs.py'):
 files['identity/'+rel]=base/rel
package=base/'full-dsl-single-entry-20261018/single-v1/source/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision'
for f in package.glob('*.py'):files['source/'+f.name]=f
for case,label in (('8k','full-pto8k-native-20261016'),('128k','retest192-native1-b24000')):
 if any(case+'-' in value for value in a.labels):
  root=Path('/data/pyptouser/yejia/lc128')/label
  for rank in range(16):
   for name in (f'rank{rank}.mixed.json',f'request_stats_rank{rank}.jsonl'):
    files['native-gold/'+case+'/'+name]=root/name
status={}
for task in a.tasks:
 result=subprocess.run(['task-submit','--status',task],check=True,text=True,capture_output=True)
 if not result.stdout.strip().startswith('completed'):raise ValueError('Do not archive unfinished task as final')
 status[task]=result.stdout
 log=subprocess.run(['task-submit','--log',task],check=True,text=True,capture_output=True)
 log_path=job/(task+'.task.log');log_path.write_text(log.stdout)
 files['task-logs/'+log_path.name]=log_path
manifest={name:hashlib.sha256(f.read_bytes()).hexdigest() for name,f in files.items()}
archive=job/(a.name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for name,f in sorted(files.items()):tar.add(f,arcname=name,recursive=False)
 for name,data in (('evidence-manifest.json',manifest),('task-statuses.json',status)):
  raw=(json.dumps(data,indent=2)+'\n').encode();item=tarfile.TarInfo(name);item.size=len(raw);tar.addfile(item,io.BytesIO(raw))
print(json.dumps({'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files),'bytes':archive.stat().st_size}))
