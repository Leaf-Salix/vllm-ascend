"""Compile the matched single-entry frozen-task control without hardware."""
import hashlib
import json
import os
from pathlib import Path

from pypto.runtime import RunConfig
import vllm_ascend.ops.pypto as namespace

experiment = Path(os.environ['SPMD_EXPERIMENT'])
namespace.__path__.insert(0, str(experiment / 'src/vllm_ascend/ops/pypto'))
from norm_wkv_orchestrated_control import norm_wkv_orchestrated_control
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program

assert os.environ['ASCEND_RT_VISIBLE_DEVICES'] == ''
compiled = norm_wkv_orchestrated_control.compile(config=RunConfig(
    platform='a2a3', dump_passes=True, save_kernels=True,
    save_kernels_dir=str(experiment / 'norm-wkv-control-artifact')))
program = norm_wkv_orchestrated_control.specialize()
abi = kernel_abi_for_program(program, platform='a2a3', runtime='tensormap_and_ringbuffer')
_compile_impl(program, output_dir=str(experiment / 'norm-wkv-control-kernel-artifact'),
              platform='a2a3', dump_passes=True, _kernel_abi=abi)
control = Path(os.environ['SOURCE_ROOT']) / 'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision'
record = {'hardware_executed':False, 'compiled':True, 'kernel_mode_abi_pass':True,
          'output_dir':str(compiled.output_dir),
          'source_sha256':hashlib.sha256((experiment/'norm_wkv_orchestrated_control.py').read_bytes()).hexdigest(),
          'control_sources': {n:hashlib.sha256((control/n).read_bytes()).hexdigest()
                              for n in ('input_norm.py','wkv.py','wkv_order_data.py')}}
(experiment/'compile-control.json').write_text(json.dumps(record,indent=2)+'\n')
print('PRECISION_MATCHED_CONTROL_COMPILED', json.dumps(record), flush=True)
