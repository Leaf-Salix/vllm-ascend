"""同一PTO顶层入口，内部保留冻结版Norm/WKV原分任务编排。"""
import pypto.language as pl
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.norm_wkv_stages import T
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.input_norm import input_norm_entry
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv import wkv_entry


@pl.jit
def norm_wkv_orchestrated_control(
    x: pl.Tensor[[T,4096],pl.BF16],
    gamma: pl.Tensor[[4096],pl.BF16],
    weight: pl.Tensor[[512,4096],pl.BF16],
    order: pl.Tensor[[32,16],pl.INT32],
    normalized: pl.InOut[pl.Tensor[[T,4096],pl.BF16]],
    rstd: pl.Out[pl.Tensor[[T,8],pl.FP32]],
    output: pl.Out[pl.Tensor[[T,512],pl.BF16]],
):
    x.bind_dynamic(0,T)
    normalized.bind_dynamic(0,T)
    rstd.bind_dynamic(0,T)
    output.bind_dynamic(0,T)
    normalized,rstd=input_norm_entry(x,gamma,normalized,rstd)
    output=wkv_entry(normalized,weight,order,output)
    return normalized,rstd,output
