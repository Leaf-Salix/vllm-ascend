"""报告内HC前缀提取的逐body静态复核，不运行浮点或设备。"""
import ast
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
OLD=HERE.parents[1]/'vllm-ascend-nalinaly-tnd-20261008-codex/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision/hc_pre.py'
old=ast.parse(OLD.read_text());new=ast.parse((HERE/'prefix_stages_draft.py').read_text())
functions=lambda t:{f.name:f for f in t.body if isinstance(f,ast.FunctionDef)}
a,b=functions(old),functions(new)
receipt=json.loads((HERE/'PREFIX_EXTRACTION.json').read_text())
for key,record in receipt['loops'].items():
    name,target=key.split('/')
    if name == 'hc_pre_post':
        outer=next(n for n in ast.walk(a[record['source_function']]) if isinstance(n,ast.For) and ast.unparse(n.target)=='ob_worker')
        before=next(n for n in ast.walk(outer) if isinstance(n,ast.For) and ast.unparse(n.target)=='ob')
        after=next(n for n in ast.walk(b[name]) if isinstance(n,ast.For))
        assert ast.dump(ast.Module(body=before.body,type_ignores=[]))==ast.dump(ast.Module(body=after.body,type_ignores=[]))
        assert ast.unparse(after.iter)=='pl.range(worker, token_tiles, 48)'
        continue
    loop=next(n for n in ast.walk(b[name]) if isinstance(n,ast.For) and ast.unparse(n.target)==target)
    body=ast.dump(ast.Module(body=loop.body,type_ignores=[]))
    assert hashlib.sha256(body.encode()).hexdigest()==record['original_body_ast_sha256'],key
    assert ast.unparse(loop.iter.func)=='pl.range' and ast.unparse(loop.iter.args[0])=='worker'
    assert ast.literal_eval(loop.iter.args[2])==record['worker_count']
old_branch=next(n for n in a['hc_pre_gates_from_rms'].body if isinstance(n,ast.If) and ast.unparse(n.test)=='t_dim >= 64' and isinstance(n.body[0],ast.For))
new_branch=next(n for n in b['hc_linear'].body if isinstance(n,ast.If))
for x,y in zip((old_branch.body[0],old_branch.orelse[0]),(new_branch.body[0],new_branch.orelse[0])):
    assert ast.unparse(y.iter.args[0])=='worker' and ast.literal_eval(y.iter.args[2])==24
    y.iter=x.iter
assert ast.dump(old_branch)==ast.dump(new_branch)
for tokens in range(1,257):
    p16=(tokens+15)//16*16;q8=(tokens+7)//8
    group=4 if tokens>=64 else 1
    counts={ 'widen':tokens, 'square':p16//16*((22+group-1)//group), 'rms':q8,
             'weight':16384//256, 'input':p16//16*64//(4 if tokens>=64 else 1),
             'linear':22*((p16+63)//64) if tokens>=64 else 22*p16//16,
             'linear_reduce':p16//16, 'pre':min(q8,16), 'comb':q8, 'mixed':q8 }
    for name,units in counts.items():
        workers=24 if name in ('square','linear') else 48
        owners=[i for w in range(workers) for i in range(w,units,workers)]
        assert sorted(owners)==list(range(units)),(tokens,name)
    assert q8*8<=p16
    assert sorted(i for owner in range(min(q8,16)) for i in range(owner,q8,min(q8,16))) == sorted(i for owner in range(48) for i in range(owner,q8,48))
    if tokens>=64:
        for split in range(22):
            for row in range(0,p16,64):
                valid=min(64,p16-row)
                assert split*p16+row+valid<=(split+1)*p16
r=functions(ast.parse((HERE/'prefix_root_draft.py').read_text()))
for role in ('prefix_cube','prefix_vector'):
    direct=[n for n in r[role].body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and ast.unparse(n.value.func)=='handoff']
    assert len(direct)==10
    assert not any(isinstance(n,(ast.If,ast.For)) for n in r[role].body)
result={'pass':True,'scope':'source AST/math+ownership+barrier sequence only; no device proof',
        'stage_count':len(b),'loop_bodies_preserved':len(receipt['loops']), 'T1_to256':True,
        'each_role_unconditional_barriers':10}
(HERE/'PREFIX_STATIC_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
