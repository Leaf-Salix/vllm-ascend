#!/usr/bin/env bash
set -euo pipefail
job=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-spmd-20261019/whole-spmd-prepack-v3
export PERF_CASE=${1:?} PERF_BACKEND=native PERF_REPEATS="${PERF_REPEATS:-3}"
case "$PERF_CASE" in
 8k) export LOW_ACCEPTANCE_GPU_BLOCKS=22000 PERF_CAPTURE_BUCKET=240;;
 128k) export LOW_ACCEPTANCE_GPU_BLOCKS=24000 PERF_CAPTURE_BUCKET=144;;
 *) exit 2;;
esac
export LOW_ACCEPTANCE_OFFICIAL_CACHE=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/low-acceptance-20261010/official-static-cache
source "$job/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="" TORCH_DEVICE_BACKEND_AUTOLOAD=0 PERF_OUTPUT="$job/preflight-unused"
ccache -s
python "$job/source_preflight.py"
python "$job/check_bank_$PERF_CASE.py"
python "$job/verify_assets.py"
python - <<'PY'
from offline_pd.worker import OfflineNPUWorker
from offline_pd.observer import OfflineCSAObserver
import low_acceptance_20261001.mixed as m
assert OfflineNPUWorker.load_model.__module__=='sitecustomize'
assert OfflineCSAObserver.offline_begin_real_perf.__module__=='perf_probe'
assert m.run_batches.__module__=='mixed_perf'
print('PERFORMANCE_BOOTSTRAP_NO_DEVICE_OK')
PY
