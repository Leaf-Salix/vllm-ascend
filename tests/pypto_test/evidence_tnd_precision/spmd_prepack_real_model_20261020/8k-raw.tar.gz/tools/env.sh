#!/usr/bin/env bash
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/root-fix-20261016/env.sh"
export PYTHONPATH=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-spmd-20261019/whole-spmd-prepack-v3:"$PYTHONPATH"
unset ADMISSION_TRACE_DIR FULL_PROBE_DIR FULL_PROBE_MODE LOW_ACCEPTANCE_FIRST_STEP_DIR OFFLINE_PTO_SWIMLANE_DIR

export SOURCE_ROOT=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-spmd-20261019/whole-spmd-prepack-v3/snapshot/source
export PYTHONPATH=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-spmd-20261019/whole-spmd-prepack-v3:"$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
export PTO_CSA_VARIANT=pkg:deepseek_v4_flash_csa_tnd_precision_spmd_prepack
export OMP_NUM_THREADS=10 OMP_PROC_BIND=false
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache CMAKE_BUILD_PARALLEL_LEVEL=4
unset LOCAL_WORLD_SIZE
