#!/usr/bin/env bash
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/root-fix-20261016/env.sh"
export PYTHONPATH="$base/real-model-perf-20261016:$PYTHONPATH"
unset ADMISSION_TRACE_DIR FULL_PROBE_DIR FULL_PROBE_MODE LOW_ACCEPTANCE_FIRST_STEP_DIR OFFLINE_PTO_SWIMLANE_DIR
