# 2026-10-16 真实整模型性能：Native vs TND精度CSA

- 用户授权真实模型性能测试；复用当前cbc810c8数学源码与CANN9.2/既有SDK，性能版不改。
- 8K/B40及128K/B24，192真实token，TP1 DP=EP16，分别同22000/24000 blocks；三轮正式采样前独立96token预热。
- 关闭full-probe、admission D2H trace、逐层hook、原值落盘、profiler、DFX。
- 用已预热NPU事件测target model_forward，丢8步取20连续步；forward起点间隔19个包含logits/draft/调度；按真实sampled输出计数估算吞吐。
- 仅保存CPU已有metadata以确认两臂/重复的请求、位置、图档和步序；GPU输入不做新增D2H，范围不扩大为新逐bit精度测试。
- 128K按126token/21请求、padded144测，8K按240/40、padded240；全rank样本充足且连续；全token/事件对已验证黄金，零抢占，实际变体21CSA/20NativeHCA。
- bank恢复/排队/加载/初编译不入forward和稳态周期；generate_aligned_batch总耗时另列含bank/入场IO，不与纯decode混称。
- 每任务max780，Native/CSA分开，完成校验才下项；不超过15min，约5min监控直到结束，无schedule。
- 所有结果写项目MD/JSON/复现脚本，独立review、precommit、commit/push。
