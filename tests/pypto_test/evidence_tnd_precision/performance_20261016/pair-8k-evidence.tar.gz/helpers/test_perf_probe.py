import unittest
from types import SimpleNamespace
from perf_probe import cycle_stats

class Event:
    def __init__(self,value): self.value=value
    def elapsed_time(self,other): return other.value-self.value

class TimingGateTest(unittest.TestCase):
    def entries(self):return [{'call':i,'begin':Event(float(i)),'sample_output':SimpleNamespace(sampled_token_ids=[[1,2],[3]])} for i in range(3)]
    def metadata(self):return [{'keys':['a','b'],'query_bounds':[0,2,3],'positions_cpu':[2*i,2*i+1,i]} for i in range(3)]
    def test_actual_output_throughput(self):
        d=cycle_stats(self.entries(),2,self.metadata())
        self.assertEqual(d['samples_us'],[1000,1000]);self.assertEqual(d['actual_output_tokens'],[3,3]);self.assertEqual(d['actual_output_tokens_per_second'],3000)
    def test_missing_sample_output_rejected(self):
        d=self.entries();del d[0]['sample_output']
        with self.assertRaises(ValueError):cycle_stats(d,2,self.metadata())
    def test_discontinuous_steps_rejected(self):
        d=self.entries();d[1]['call']=7
        with self.assertRaises(ValueError):cycle_stats(d,2,self.metadata())
    def test_invalid_timestamp_rejected(self):
        d=self.entries();d[1]['begin']=Event(-1)
        with self.assertRaises(ValueError):cycle_stats(d,2,self.metadata())
if __name__=='__main__':unittest.main()
