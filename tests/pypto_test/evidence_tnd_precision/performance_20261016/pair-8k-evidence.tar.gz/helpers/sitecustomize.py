"""Reuse the existing private runtime selection and add trace-only hooks."""
import importlib.util
import os
import sys
from importlib.machinery import PathFinder

old = '/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/low-acceptance-20261010/sitecustomize.py'
spec = importlib.util.spec_from_file_location('original_private_sitecustomize', old)
existing = importlib.util.module_from_spec(spec)
spec.loader.exec_module(existing)


class WorkerLoader:
    def __init__(self, original):
        self.original = original

    def create_module(self, spec):
        return self.original.create_module(spec)

    def exec_module(self, module):
        self.original.exec_module(module)
        original = module.OfflineNPUWorker.initialize_from_config

        def initialize(worker, config, *args, **kwargs):
            import json
            from pathlib import Path
            import torch
            from perf_probe import allocation_plan
            plan = allocation_plan(config)
            free, total = torch.npu.mem_get_info()
            rank = worker.vllm_config.parallel_config.data_parallel_rank
            report = dict(plan, free_bytes_before_allocation=free, total_bytes=total)
            directory = Path(os.environ['PERF_OUTPUT'])
            directory.mkdir(parents=True, exist_ok=True)
            (directory / f'rank{rank}.capacity.json').write_text(json.dumps(report, indent=2)+'\n')
            if plan['num_blocks'] != int(os.environ['LOW_ACCEPTANCE_GPU_BLOCKS']):
                raise RuntimeError('Actual KV blocks do not match diagnostic request')
            planned = plan['aligned_allocation_upper_bytes']
            if planned > 21 * 1024**3 or planned + 2 * 1024**3 > free:
                raise RuntimeError(f'Unsafe KV allocation plan: blocks={plan["num_blocks"]} upper={planned} free={free} limit={21 * 1024**3} reserve={2 * 1024**3}')
            print(f'ADMISSION_KV_CAPACITY blocks={plan["num_blocks"]} aligned_upper_bytes={planned} free_bytes={free}', flush=True)
            return original(worker, config, *args, **kwargs)

        module.OfflineNPUWorker.initialize_from_config = initialize


class Loader:
    def __init__(self, original, fullname): self.original, self.fullname = original, fullname
    def create_module(self, spec): return self.original.create_module(spec)
    def exec_module(self, module):
        self.original.exec_module(module)
        if self.fullname == 'offline_pd.observer':
            from perf_probe import install
            install(module)
        else:
            from mixed_perf import run_batches
            module.run_batches = run_batches

class Finder:
    @staticmethod
    def find_spec(fullname, path=None, target=None):
        if fullname not in ('offline_pd.worker','offline_pd.observer','low_acceptance_20261001.mixed'): return None
        spec = PathFinder.find_spec(fullname, path)
        if spec:
            spec.loader = WorkerLoader(spec.loader) if fullname == 'offline_pd.worker' else Loader(spec.loader, fullname)
        return spec

sys.meta_path.insert(0, Finder)
