"""CPU定位线索，不把CPU重建分数当作Native实测金值。"""
import argparse
import hashlib
import json
from pathlib import Path

import torch

parser = argparse.ArgumentParser()
parser.add_argument('witness', type=Path)
parser.add_argument('--out', type=Path, required=True)
a = parser.parse_args()
v = torch.load(a.witness, weights_only=False, map_location='cpu')
kw = v['qli_inputs']['native_FULL']
row = 2
indices = v['states']['candidate']['idx_topk'].reshape(6, 512)[row].long()
scores = v['scores']['candidate']['FULL_scores'].reshape(6, 512)[row].double()
logical = torch.arange(2048)
physical = kw['block_table'][0, logical // 32].long()
key_scale = kw['key_dequant_scale'][physical, logical % 32, 0].double()
keys = kw['key'][physical, logical % 32, 0].int()
dot = kw['query'][row].int() @ keys.T
activation = (dot.float() / 1024).clamp_min(0).half().double().T
matrix = activation * key_scale[:, None]
coefficient = (kw['weights'][row] * kw['query_dequant_scale'][row]).double()
fit = torch.linalg.lstsq(matrix[indices], scores).solution
residual = matrix[indices] @ fit - scores
native_indices = v['states']['native']['idx_topk'].reshape(6, 512)[row]
changes = (fit - coefficient).abs() > 1e-10
r = {
    'scope': 'CPU reconstruction/least-squares diagnosis; NOT Native measured scores or precision acceptance',
    'witness_sha256': hashlib.sha256(a.witness.read_bytes()).hexdigest(),
    'row': row,
    'position': int(v['inputs']['positions'][row]),
    'fit_relative_residual': float(residual.norm() / scores.norm()),
    'approximate_native_order_differences': int((matrix @ coefficient).argsort(descending=True)[:512].ne(native_indices).sum()),
    'significant_coefficient_candidates': [
        {'head': int(h), 'native_input_coefficient': float(coefficient[h]), 'fit': float(fit[h]),
         'fit_rounded_fp16': float(fit[h].half()), 'native_weight': float(kw['weights'][row, h]),
         'native_query_scale': float(kw['query_dequant_scale'][row, h])}
        for h in changes.nonzero().flatten()
    ],
}
a.out.write_text(json.dumps(r, indent=2) + '\n')
print(json.dumps(r, indent=2))
