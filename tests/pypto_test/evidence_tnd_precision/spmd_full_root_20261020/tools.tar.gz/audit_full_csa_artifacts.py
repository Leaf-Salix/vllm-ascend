"""Bind the separate kernel-mode artifacts to their successful compile receipt."""
import hashlib,json,os
from pathlib import Path
p=Path(os.environ['SPMD_EXPERIMENT'])
receipt_path=p/'compile-full-csa-packaged.json'
r=json.loads(receipt_path.read_text())
package=p/'src/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision_spmd'
assert {q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in package.glob('*.py')}==r['sources']
assert r['compiled'] and r['kernel_mode_abi_pass'] and r['torch_dispatcher_registration_pass']
d=Path(r['kernel_artifact_dir'])
audit={'scope':'kernel-mode output; receipt.generated is the separate program-mode output',
 'receipt_sha256':hashlib.sha256(receipt_path.read_bytes()).hexdigest(),
 'sources':r['sources'],'kernel_artifact_dir':str(d),
 'generated':{str(q.relative_to(d)):hashlib.sha256(q.read_bytes()).hexdigest() for q in d.rglob('*') if q.is_file() and q.suffix in ('.cpp','.py','.json')},
 'audit_helper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(p/'compile-full-csa-packaged-kernel-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print('KERNEL_ARTIFACT_AUDIT',len(audit['generated']))
