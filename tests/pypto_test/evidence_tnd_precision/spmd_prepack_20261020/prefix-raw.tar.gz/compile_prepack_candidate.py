"""No-device compilation; this diagnostic does not change installed packages."""
import hashlib
import json
import os
import sys
from pathlib import Path
import pypto
import simpler
import vllm_ascend.ops.pypto as namespace
from pypto.runtime import RunConfig
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program

experiment=Path(os.environ['SPMD_EXPERIMENT'])
namespace.__path__.insert(0,str(experiment/'src/vllm_ascend/ops/pypto'))
sys.path.insert(0,str(experiment))
from prepack_candidate import prepacked_precision_hc_prefix_indexer,prepack_fixed_hc_weight
assert os.environ['ASCEND_RT_VISIBLE_DEVICES']==''
assert 'low-acceptance-20261010/runtime-package/pypto' in pypto.__file__
assert 'pypto-reference/runtime/python/simpler' in simpler.__file__
record={'scope':'prepack standalone one-factor prefix draft; no device executed','hardware_executed':False,'candidate_sha256':hashlib.sha256((experiment/'prepack_candidate.py').read_bytes()).hexdigest(),'programs':{}}
for name,entry in [('prefix',prepacked_precision_hc_prefix_indexer),('prepare',prepack_fixed_hc_weight)]:
    compiled=entry.compile(config=RunConfig(platform='a2a3',dump_passes=True,save_kernels=True,save_kernels_dir=str(experiment/f'prepack-{name}-artifact')))
    program=entry.specialize()
    abi=kernel_abi_for_program(program,platform='a2a3',runtime='tensormap_and_ringbuffer')
    artifact=experiment/f'prepack-{name}-kernel-artifact'
    _compile_impl(program,output_dir=str(artifact),platform='a2a3',dump_passes=True,_kernel_abi=abi)
    record['programs'][name]={'compiled':True,'kernel_mode_abi_pass':True,'output_dir':str(compiled.output_dir),'kernel_artifact_dir':str(artifact),'generated':{str(p.relative_to(artifact)):hashlib.sha256(p.read_bytes()).hexdigest() for p in artifact.rglob('*') if p.is_file() and p.suffix in ('.py','.cpp','.json')}}
(experiment/'compile-prepack-candidate.json').write_text(json.dumps(record,indent=2)+'\n')
print('PREPACK_DRAFT_COMPILED',flush=True)
