"""Complete the formal preparer gate without rebuilding the unchanged full root."""
from pathlib import Path
import hashlib,json,os
import pypto
import pypto.torch
from pypto.runtime import RunConfig
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program
import vllm_ascend.ops.pypto as namespace
exp=Path(os.environ['SPMD_EXPERIMENT'])
namespace.__path__.insert(0,str(exp/'src/vllm_ascend/ops/pypto'))
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_prepack.prefix import prepack_fixed_hc_weight
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_prepack.native_adapter import CSAOperators
assert os.environ['ASCEND_RT_VISIBLE_DEVICES']==''
p=exp/'compile-full-csa-prepack.json';record=json.loads(p.read_text())
package=exp/'src/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision_spmd_prepack'
assert record['sources']=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in package.glob('*.py')}
compiled=prepack_fixed_hc_weight.compile(config=RunConfig(platform='a2a3',dump_passes=True,save_kernels=True,save_kernels_dir=str(exp/'full-prepack-prepare-artifact')))
program=prepack_fixed_hc_weight.specialize()
abi=kernel_abi_for_program(program,platform='a2a3',runtime='tensormap_and_ringbuffer')
artifact=exp/'full-prepack-prepare-kernel-artifact'
_compile_impl(program,output_dir=str(artifact),platform='a2a3',dump_passes=True,_kernel_abi=abi)
operators=CSAOperators.register()
assert len(operators.attention._schema.arguments)==64
assert operators.attention._schema.arguments[1].name=='hc_packed_weight'
assert len(operators.workspace.prepare_hc_weight._schema.arguments)==2
record.update(formal_prepare_program_compiled=True,formal_prepare_kernel_mode_abi_pass=True,formal_operators_registered=True,
 formal_prepare_schema=str(operators.workspace.prepare_hc_weight._schema),formal_attention_schema=str(operators.attention._schema),
 formal_prepare_artifact_dir=str(artifact),formal_prepare_generated={str(p.relative_to(artifact)):hashlib.sha256(p.read_bytes()).hexdigest() for p in artifact.rglob('*') if p.is_file() and p.suffix in ('.py','.cpp','.json')})
p.write_text(json.dumps(record,indent=2)+'\n')
print('FORMAL_PREPACK_PREPARE_AND_OPERATORS_GATE_OK',flush=True)
