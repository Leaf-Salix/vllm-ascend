#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void kv_rms_norm_rope(__gm__ float* v1, __gm__ bfloat16_t* v2, __gm__ bfloat16_t* v3, __gm__ float* v4, __gm__ float* v5, __gm__ int32_t* v6, int64_t v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int32_t v12, int32_t v13) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v14 = 256;
  // pto: %c32768_i64
  const int64_t v15 = 32768;
  // pto: %c16384_i64
  const int64_t v16 = 16384;
  // pto: %c57344_i64
  const int64_t v17 = 57344;
  // pto: %c40960_i64
  const int64_t v18 = 40960;
  // pto: %c49152_i64
  const int64_t v19 = 49152;
  // pto: %c0_i64
  const int64_t v20 = 0;
  // pto: %c8192_i64
  const int64_t v21 = 8192;
  // pto: %c512_index
  const int64_t v22 = 512;
  // pto: %c1_index
  const int64_t v23 = 1;
  // pto: %c64_index
  const int64_t v24 = 64;
  // pto: %c32_index
  const int64_t v25 = 32;
  // pto: %cst_11
  const float v26 = 0.0f;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %c128_index
  const int64_t v28 = 128;
  // pto: %cst_14
  const float v29 = 0.001953125f;
  // pto: %cst_15
  const float v30 = 9.99999997E-7f;
  // pto: %cst_16
  const float v31 = 1.0f;
  // pto: %c384_index
  const int64_t v32 = 384;
  // pto: %c448_index
  const int64_t v33 = 448;
  // pto: %c192_index
  const int64_t v34 = 192;
  // pto: %c0_i32
  const int32_t v35 = 0;
  // pto: %cst_21
  const float v36 = 0.5f;
  // pto: %cst_22
  const float v37 = 2.0f;
  // pto: %cst_23
  const float v38 = 64.0f;
  // pto: %kv_fp32_inline3481__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %kv_fp32_inline3481__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %kv_fp32_inline3481__ssa_v0_view
  const int64_t v41 = 1;
  // pto: %kv_fp32_inline3481__ssa_v0_view
  int64_t v42 = (int64_t) v9;
  // pto: %kv_fp32_inline3481__ssa_v0_view
  int64_t v43 = v42 * v22;
  // pto: %kv_fp32_inline3481__ssa_v0_view
  int64_t v44 = v41 * v43;
  // pto: %kv_fp32_inline3481__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v45 = pto::Shape<1, 1, 1, -1, -1>(v39, v40, v41, v42, v22);
  // pto: %kv_fp32_inline3481__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v40 * v44, v44, v43, v22, v23);
  // pto: %kv_fp32_inline3481__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v47 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v45, v46);
  // pto: %kv_view_inline3486__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %kv_view_inline3486__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %kv_view_inline3486__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %kv_view_inline3486__ssa_v0_view
  int64_t v51 = (int64_t) v10;
  // pto: %kv_view_inline3486__ssa_v0_view
  int64_t v52 = v51 * v22;
  // pto: %kv_view_inline3486__ssa_v0_view
  int64_t v53 = v50 * v52;
  // pto: %kv_view_inline3486__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v54 = pto::Shape<1, 1, 1, -1, -1>(v48, v49, v50, v51, v22);
  // pto: %kv_view_inline3486__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v55 = pto::Stride<-1, -1, -1, -1, -1>(v49 * v53, v53, v52, v22, v23);
  // pto: %kv_view_inline3486__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v56 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v54, v55);
  // pto: %gamma_ckv__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %gamma_ckv__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %gamma_ckv__ssa_v0_view
  const int64_t v59 = 1;
  // pto: %gamma_ckv__ssa_v0_view
  const int64_t v60 = 1;
  // pto: %gamma_ckv__ssa_v0_view
  int64_t v61 = v22 * v23;
  // pto: %gamma_ckv__ssa_v0_view
  int64_t v62 = v60 * v61;
  // pto: %gamma_ckv__ssa_v0_view
  int64_t v63 = v59 * v62;
  // pto: %gamma_ckv__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v64 = pto::Shape<1, 1, 1, 1, -1>(v57, v58, v59, v60, v22);
  // pto: %gamma_ckv__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v65 = pto::Stride<-1, -1, -1, -1, -1>(v58 * v63, v63, v62, v61, v23);
  // pto: %gamma_ckv__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v66 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v64, v65);
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v69 = 1;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v70 = (int64_t) v11;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v71 = v70 * v24;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v72 = v69 * v71;
  // pto: %freqs_cos__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v73 = pto::Shape<1, 1, 1, -1, -1>(v67, v68, v69, v70, v24);
  // pto: %freqs_cos__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v74 = pto::Stride<-1, -1, -1, -1, -1>(v68 * v72, v72, v71, v24, v23);
  // pto: %freqs_cos__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v75 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v73, v74);
  // pto: %island_signed__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %island_signed__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %island_signed__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %island_signed__ssa_v0_view
  int64_t v79 = (int64_t) v11;
  // pto: %island_signed__ssa_v0_view
  int64_t v80 = v79 * v24;
  // pto: %island_signed__ssa_v0_view
  int64_t v81 = v78 * v80;
  // pto: %island_signed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v82 = pto::Shape<1, 1, 1, -1, -1>(v76, v77, v78, v79, v24);
  // pto: %island_signed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v83 = pto::Stride<-1, -1, -1, -1, -1>(v77 * v81, v81, v80, v24, v23);
  // pto: %island_signed__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v84 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v82, v83);
  // pto: %island_swap__ssa_v0_view
  const int64_t v85 = 1;
  // pto: %island_swap__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %island_swap__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %island_swap__ssa_v0_view
  int64_t v88 = (int64_t) v11;
  // pto: %island_swap__ssa_v0_view
  int64_t v89 = v88 * v24;
  // pto: %island_swap__ssa_v0_view
  int64_t v90 = v87 * v89;
  // pto: %island_swap__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v91 = pto::Shape<1, 1, 1, -1, -1>(v85, v86, v87, v88, v24);
  // pto: %island_swap__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v92 = pto::Stride<-1, -1, -1, -1, -1>(v86 * v90, v90, v89, v24, v23);
  // pto: %island_swap__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v93 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v91, v92);
  // pto: %tg_idx_inline3488__ssa_v0, %63
  int64_t v94 = (int64_t) ((uint64_t) ((int64_t) v12) * (uint64_t) v25);
  // pto: %64
  int64_t v95 = (int64_t) ((uint64_t) v7 - (uint64_t) v94);
  // pto: %65
  int64_t v96 = v95 < v25 ? v95 : v25;
  // pto: %66
  int64_t v97 = (int64_t) ((uint64_t) v8 + (uint64_t) v94);
  // pto: %67
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  if (v96 == v25) {
    // pto: %kv_sq_lanes_inline3492__tile
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_sq_lanes_inline3492__tile
    ;
    uint64_t v99 = (uint64_t) v15;
    TASSIGN(v98, v99);
    TEXPANDS(v98, v26);
    for (int64_t v100 = v27; v100 < v22; v100 += v28) {
      // pto: %kv_chunk_inline3494__tile
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %kv_chunk_inline3494__tile
      ;
      uint64_t v102 = (uint64_t) v16;
      TASSIGN(v101, v102);
      // pto: %68
      ;
      int64_t v103 = v94 < v27 ? v27 : v94;
      // pto: %69
      ;
      int64_t v104 = v100 < v27 ? v27 : v100;
      // pto: %kv_fp32_inline3481__ssa_v0_pview
      ;
      __gm__ float* v105 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %kv_fp32_inline3481__ssa_v0_pview
      ;
      const int64_t v106 = 0;
      // pto: %kv_fp32_inline3481__ssa_v0_pview
      ;
      const int64_t v107 = 512;
      // pto: %kv_fp32_inline3481__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 32, 64> v108 = pto::Shape<1, 1, 1, 32, 64>();
      // pto: %kv_fp32_inline3481__ssa_v0_pview
      ;
      pto::Stride<16384, 16384, 16384, 512, 1> v109 = pto::Stride<16384, 16384, 16384, 512, 1>();
      // pto: %kv_fp32_inline3481__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v110 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v105 + (v106 + v103 * v107 + v104), v108, v109);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      TLOAD(v101, v110);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v111 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %0
      ;
      uint64_t v112 = (uint64_t) v17;
      TASSIGN(v111, v112);
      // pto: %71
      ;
      int64_t v113 = (int64_t) ((uint64_t) v100 + (uint64_t) v24);
      // pto: %72
      ;
      int64_t v114 = v113 < v27 ? v27 : v113;
      // pto: %73
      ;
      __gm__ float* v115 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %73
      ;
      const int64_t v116 = 0;
      // pto: %73
      ;
      const int64_t v117 = 512;
      // pto: %73
      ;
      pto::Shape<1, 1, 1, 32, 64> v118 = pto::Shape<1, 1, 1, 32, 64>();
      // pto: %73
      ;
      pto::Stride<16384, 16384, 16384, 512, 1> v119 = pto::Stride<16384, 16384, 16384, 512, 1>();
      // pto: %73
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v120 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v115 + (v116 + v103 * v117 + v114), v118, v119);
      TLOAD(v111, v120);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %t__tile
      ;
      Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %t__tile
      ;
      uint64_t v122 = (uint64_t) v18;
      TASSIGN(v121, v122);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      RoundMode v123 = RoundMode::CAST_RINT;
      SaturationMode v124 = SaturationMode::ON;
      TCVT(v121, v101, v123, v124);
      // pto: %kv_chunk_v1_inline3495__tile
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %kv_chunk_v1_inline3495__tile
      ;
      uint64_t v126 = (uint64_t) v16;
      TASSIGN(v125, v126);
      pipe_barrier(PIPE_V);
      RoundMode v127 = RoundMode::CAST_ROUND;
      SaturationMode v128 = SaturationMode::ON;
      TCVT(v125, v121, v127, v128);
      // pto: %kv_sq_inline3496__tile
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %kv_sq_inline3496__tile
      ;
      uint64_t v130 = (uint64_t) v16;
      TASSIGN(v129, v130);
      pipe_barrier(PIPE_V);
      TMUL(v129, v125, v125);
      // pto: %1
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %1
      ;
      uint64_t v132 = (uint64_t) v16;
      TASSIGN(v131, v132);
      pipe_barrier(PIPE_V);
      TADD(v131, v98, v129);
      // pto: %2
      ;
      Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v133 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %2
      ;
      uint64_t v134 = (uint64_t) v19;
      TASSIGN(v133, v134);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      RoundMode v135 = RoundMode::CAST_RINT;
      SaturationMode v136 = SaturationMode::ON;
      TCVT(v133, v111, v135, v136);
      // pto: %3
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %3
      ;
      uint64_t v138 = (uint64_t) v17;
      TASSIGN(v137, v138);
      pipe_barrier(PIPE_V);
      RoundMode v139 = RoundMode::CAST_ROUND;
      SaturationMode v140 = SaturationMode::ON;
      TCVT(v137, v133, v139, v140);
      // pto: %4
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %4
      ;
      uint64_t v142 = (uint64_t) v17;
      TASSIGN(v141, v142);
      pipe_barrier(PIPE_V);
      TMUL(v141, v137, v137);
      // pto: %5
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v143 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %5
      ;
      uint64_t v144 = (uint64_t) v15;
      TASSIGN(v143, v144);
      pipe_barrier(PIPE_V);
      TADD(v143, v131, v141);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    };
    // pto: %tmp_tile
    ;
    Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Vec, float, 32, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v28);
    // pto: %tmp_tile
    ;
    uint64_t v146 = (uint64_t) v16;
    TASSIGN(v145, v146);
    // pto: %6
    ;
    Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v23);
    // pto: %6
    ;
    uint64_t v148 = (uint64_t) v17;
    TASSIGN(v147, v148);
    pipe_barrier(PIPE_V);
    TROWSUM(v147, v98, v145);
    // pto: %kv_sq_sum_inline3497__tile
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v149 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v25);
    // pto: %kv_sq_sum_inline3497__tile
    ;
    uint64_t v150 = (uint64_t) v17;
    TASSIGN(v149, v150);
    // pto: %7
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v151 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v25);
    // pto: %7
    ;
    uint64_t v152 = (uint64_t) v16;
    TASSIGN(v151, v152);
    pipe_barrier(PIPE_V);
    TMULS(v151, v149, v29);
    // pto: %8
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v25);
    // pto: %8
    ;
    uint64_t v154 = (uint64_t) v16;
    TASSIGN(v153, v154);
    pipe_barrier(PIPE_V);
    TADDS(v153, v151, v30);
    // pto: %kv_rms_inline3498__tile
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v25);
    // pto: %kv_rms_inline3498__tile
    ;
    uint64_t v156 = (uint64_t) v16;
    TASSIGN(v155, v156);
    pipe_barrier(PIPE_V);
    TSQRT(v155, v153);
    // pto: %9
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v25);
    // pto: %9
    ;
    uint64_t v158 = (uint64_t) v15;
    TASSIGN(v157, v158);
    TEXPANDS(v157, v31);
    // pto: %kv_inv_rms_inline3499__tile
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v159 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v25);
    // pto: %kv_inv_rms_inline3499__tile
    ;
    uint64_t v160 = (uint64_t) v19;
    TASSIGN(v159, v160);
    pipe_barrier(PIPE_V);
    TDIV(v159, v157, v155);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    // pto: %kv_inv_rms_t_inline3500__tile
    ;
    Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v23);
    // pto: %kv_inv_rms_t_inline3500__tile
    ;
    uint64_t v162 = (uint64_t) v19;
    TASSIGN(v161, v162);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    for (int64_t v163 = v27; v163 < v32; v163 += v28) {
      // pto: %10
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v164 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %10
      ;
      uint64_t v165 = (uint64_t) v16;
      TASSIGN(v164, v165);
      // pto: %74
      ;
      int64_t v166 = v94 < v27 ? v27 : v94;
      // pto: %75
      ;
      int64_t v167 = v163 < v27 ? v27 : v163;
      // pto: %76
      ;
      __gm__ float* v168 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %76
      ;
      const int64_t v169 = 0;
      // pto: %76
      ;
      const int64_t v170 = 512;
      // pto: %76
      ;
      pto::Shape<1, 1, 1, 32, 64> v171 = pto::Shape<1, 1, 1, 32, 64>();
      // pto: %76
      ;
      pto::Stride<16384, 16384, 16384, 512, 1> v172 = pto::Stride<16384, 16384, 16384, 512, 1>();
      // pto: %76
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v173 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v168 + (v169 + v166 * v170 + v167), v171, v172);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      TLOAD(v164, v173);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %11
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v174 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
      // pto: %11
      ;
      uint64_t v175 = (uint64_t) v20;
      TASSIGN(v174, v175);
      // pto: %gamma_ckv__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v176 = PTOAS__GLOBAL_TENSOR_DATA(v66);
      // pto: %gamma_ckv__ssa_v0_pview
      ;
      const int64_t v177 = 0;
      // pto: %gamma_ckv__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 64> v178 = pto::Shape<1, 1, 1, 1, 64>();
      // pto: %gamma_ckv__ssa_v0_pview
      ;
      pto::Stride<64, 64, 64, 64, 1> v179 = pto::Stride<64, 64, 64, 64, 1>();
      // pto: %gamma_ckv__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v180 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v176 + (v177 + v167), v178, v179);
      TLOAD(v174, v180);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %12
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %12
      ;
      uint64_t v182 = (uint64_t) v15;
      TASSIGN(v181, v182);
      // pto: %79
      ;
      int64_t v183 = (int64_t) ((uint64_t) v163 + (uint64_t) v24);
      // pto: %80
      ;
      int64_t v184 = v183 < v27 ? v27 : v183;
      // pto: %81
      ;
      __gm__ float* v185 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %81
      ;
      const int64_t v186 = 0;
      // pto: %81
      ;
      const int64_t v187 = 512;
      // pto: %81
      ;
      pto::Shape<1, 1, 1, 32, 64> v188 = pto::Shape<1, 1, 1, 32, 64>();
      // pto: %81
      ;
      pto::Stride<16384, 16384, 16384, 512, 1> v189 = pto::Stride<16384, 16384, 16384, 512, 1>();
      // pto: %81
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v190 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v185 + (v186 + v166 * v187 + v184), v188, v189);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
      TLOAD(v181, v190);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      // pto: %13
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v191 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
      // pto: %13
      ;
      uint64_t v192 = (uint64_t) v21;
      TASSIGN(v191, v192);
      // pto: %84
      ;
      __gm__ bfloat16_t* v193 = PTOAS__GLOBAL_TENSOR_DATA(v66);
      // pto: %84
      ;
      const int64_t v194 = 0;
      // pto: %84
      ;
      pto::Shape<1, 1, 1, 1, 64> v195 = pto::Shape<1, 1, 1, 1, 64>();
      // pto: %84
      ;
      pto::Stride<64, 64, 64, 64, 1> v196 = pto::Stride<64, 64, 64, 64, 1>();
      // pto: %84
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v197 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v193 + (v194 + v184), v195, v196);
      TLOAD(v191, v197);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      // pto: %14
      ;
      Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v198 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %14
      ;
      uint64_t v199 = (uint64_t) v17;
      TASSIGN(v198, v199);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      RoundMode v200 = RoundMode::CAST_RINT;
      SaturationMode v201 = SaturationMode::ON;
      TCVT(v198, v164, v200, v201);
      // pto: %kv_chunk_v2_inline3502__tile
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v202 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %kv_chunk_v2_inline3502__tile
      ;
      uint64_t v203 = (uint64_t) v16;
      TASSIGN(v202, v203);
      pipe_barrier(PIPE_V);
      RoundMode v204 = RoundMode::CAST_ROUND;
      SaturationMode v205 = SaturationMode::ON;
      TCVT(v202, v198, v204, v205);
      // pto: %gamma_kv_cast_inline3503__tile
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v206 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
      // pto: %gamma_kv_cast_inline3503__tile
      ;
      uint64_t v207 = (uint64_t) v17;
      TASSIGN(v206, v207);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      RoundMode v208 = RoundMode::CAST_ROUND;
      SaturationMode v209 = SaturationMode::ON;
      TCVT(v206, v174, v208, v209);
      // pto: %gamma_kv_chunk_inline3504__tile
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
      // pto: %gamma_kv_chunk_inline3504__tile
      ;
      uint64_t v211 = (uint64_t) v17;
      TASSIGN(v210, v211);
      // pto: %15
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v212 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %15
      ;
      uint64_t v213 = (uint64_t) v16;
      TASSIGN(v212, v213);
      TROWEXPANDMUL(v212, v202, v161);
      // pto: %kv_normed_inline3505__tile
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %kv_normed_inline3505__tile
      ;
      uint64_t v215 = (uint64_t) v16;
      TASSIGN(v214, v215);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v214, v212, v210);
      // pto: %kv_normed_bf16_inline3506__tile
      ;
      Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %kv_normed_bf16_inline3506__tile
      ;
      uint64_t v217 = (uint64_t) v16;
      TASSIGN(v216, v217);
      pipe_barrier(PIPE_V);
      RoundMode v218 = RoundMode::CAST_RINT;
      SaturationMode v219 = SaturationMode::ON;
      TCVT(v216, v214, v218, v219);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %85
      ;
      int64_t v220 = v97 < v27 ? v27 : v97;
      // pto: %kv_view_inline3486__iter_v1_pview
      ;
      __gm__ bfloat16_t* v221 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %kv_view_inline3486__iter_v1_pview
      ;
      const int64_t v222 = 0;
      // pto: %kv_view_inline3486__iter_v1_pview
      ;
      const int64_t v223 = 512;
      // pto: %kv_view_inline3486__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, 32, 64> v224 = pto::Shape<1, 1, 1, 32, 64>();
      // pto: %kv_view_inline3486__iter_v1_pview
      ;
      pto::Stride<16384, 16384, 16384, 512, 1> v225 = pto::Stride<16384, 16384, 16384, 512, 1>();
      // pto: %kv_view_inline3486__iter_v1_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v226 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v221 + (v222 + v220 * v223 + v167), v224, v225);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v226, v216);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      // pto: %16
      ;
      Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %16
      ;
      uint64_t v228 = (uint64_t) v18;
      TASSIGN(v227, v228);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      RoundMode v229 = RoundMode::CAST_RINT;
      SaturationMode v230 = SaturationMode::ON;
      TCVT(v227, v181, v229, v230);
      // pto: %17
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v231 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %17
      ;
      uint64_t v232 = (uint64_t) v15;
      TASSIGN(v231, v232);
      pipe_barrier(PIPE_V);
      RoundMode v233 = RoundMode::CAST_ROUND;
      SaturationMode v234 = SaturationMode::ON;
      TCVT(v231, v227, v233, v234);
      // pto: %18
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
      // pto: %18
      ;
      uint64_t v236 = (uint64_t) v18;
      TASSIGN(v235, v236);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      RoundMode v237 = RoundMode::CAST_ROUND;
      SaturationMode v238 = SaturationMode::ON;
      TCVT(v235, v191, v237, v238);
      // pto: %19
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v239 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
      // pto: %19
      ;
      uint64_t v240 = (uint64_t) v18;
      TASSIGN(v239, v240);
      // pto: %20
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v241 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %20
      ;
      uint64_t v242 = (uint64_t) v15;
      TASSIGN(v241, v242);
      TROWEXPANDMUL(v241, v231, v161);
      // pto: %21
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %21
      ;
      uint64_t v244 = (uint64_t) v15;
      TASSIGN(v243, v244);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v243, v241, v239);
      // pto: %22
      ;
      Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v245 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %22
      ;
      uint64_t v246 = (uint64_t) v15;
      TASSIGN(v245, v246);
      pipe_barrier(PIPE_V);
      RoundMode v247 = RoundMode::CAST_RINT;
      SaturationMode v248 = SaturationMode::ON;
      TCVT(v245, v243, v247, v248);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      // pto: %kv_view_inline3486__tile_pview
      ;
      __gm__ bfloat16_t* v249 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %kv_view_inline3486__tile_pview
      ;
      const int64_t v250 = 0;
      // pto: %kv_view_inline3486__tile_pview
      ;
      const int64_t v251 = 512;
      // pto: %kv_view_inline3486__tile_pview
      ;
      pto::Shape<1, 1, 1, 32, 64> v252 = pto::Shape<1, 1, 1, 32, 64>();
      // pto: %kv_view_inline3486__tile_pview
      ;
      pto::Stride<16384, 16384, 16384, 512, 1> v253 = pto::Stride<16384, 16384, 16384, 512, 1>();
      // pto: %kv_view_inline3486__tile_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v254 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v249 + (v250 + v220 * v251 + v184), v252, v253);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v254, v245);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    };
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    // pto: %23
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %23
    ;
    uint64_t v256 = (uint64_t) v16;
    TASSIGN(v255, v256);
    // pto: %91
    ;
    int64_t v257 = v94 < v27 ? v27 : v94;
    // pto: %92
    ;
    __gm__ float* v258 = PTOAS__GLOBAL_TENSOR_DATA(v47);
    // pto: %92
    ;
    const int64_t v259 = 384;
    // pto: %92
    ;
    const int64_t v260 = 512;
    // pto: %92
    ;
    pto::Shape<1, 1, 1, 32, 64> v261 = pto::Shape<1, 1, 1, 32, 64>();
    // pto: %92
    ;
    pto::Stride<16384, 16384, 16384, 512, 1> v262 = pto::Stride<16384, 16384, 16384, 512, 1>();
    // pto: %92
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v263 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v258 + (v259 + v257 * v260), v261, v262);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    TLOAD(v255, v263);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    // pto: %24
    ;
    Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v264 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %24
    ;
    uint64_t v265 = (uint64_t) v15;
    TASSIGN(v264, v265);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    RoundMode v266 = RoundMode::CAST_RINT;
    SaturationMode v267 = SaturationMode::ON;
    TCVT(v264, v255, v266, v267);
    // pto: %25
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v268 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %25
    ;
    uint64_t v269 = (uint64_t) v16;
    TASSIGN(v268, v269);
    pipe_barrier(PIPE_V);
    RoundMode v270 = RoundMode::CAST_ROUND;
    SaturationMode v271 = SaturationMode::ON;
    TCVT(v268, v264, v270, v271);
    // pto: %26
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v272 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
    // pto: %26
    ;
    uint64_t v273 = (uint64_t) v17;
    TASSIGN(v272, v273);
    // pto: %93
    ;
    __gm__ bfloat16_t* v274 = PTOAS__GLOBAL_TENSOR_DATA(v66);
    // pto: %93
    ;
    unsigned v275 = 384;
    // pto: %93
    ;
    pto::Shape<1, 1, 1, 1, 64> v276 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %93
    ;
    pto::Stride<64, 64, 64, 64, 1> v277 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %93
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v278 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v274 + v275, v276, v277);
    TLOAD(v272, v278);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    // pto: %27
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
    // pto: %27
    ;
    uint64_t v280 = (uint64_t) v15;
    TASSIGN(v279, v280);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    pipe_barrier(PIPE_V);
    RoundMode v281 = RoundMode::CAST_ROUND;
    SaturationMode v282 = SaturationMode::ON;
    TCVT(v279, v272, v281, v282);
    // pto: %28
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v283 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
    // pto: %28
    ;
    uint64_t v284 = (uint64_t) v15;
    TASSIGN(v283, v284);
    // pto: %29
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %29
    ;
    uint64_t v286 = (uint64_t) v16;
    TASSIGN(v285, v286);
    TROWEXPANDMUL(v285, v268, v161);
    // pto: %30
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %30
    ;
    uint64_t v288 = (uint64_t) v16;
    TASSIGN(v287, v288);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v287, v285, v283);
    // pto: %31
    ;
    Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %31
    ;
    uint64_t v290 = (uint64_t) v16;
    TASSIGN(v289, v290);
    pipe_barrier(PIPE_V);
    RoundMode v291 = RoundMode::CAST_RINT;
    SaturationMode v292 = SaturationMode::ON;
    TCVT(v289, v287, v291, v292);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
    // pto: %95
    ;
    int64_t v293 = v97 < v27 ? v27 : v97;
    // pto: %kv_view_inline3486__rv_v2_main_pview
    ;
    __gm__ bfloat16_t* v294 = PTOAS__GLOBAL_TENSOR_DATA(v56);
    // pto: %kv_view_inline3486__rv_v2_main_pview
    ;
    const int64_t v295 = 384;
    // pto: %kv_view_inline3486__rv_v2_main_pview
    ;
    const int64_t v296 = 512;
    // pto: %kv_view_inline3486__rv_v2_main_pview
    ;
    pto::Shape<1, 1, 1, 32, 64> v297 = pto::Shape<1, 1, 1, 32, 64>();
    // pto: %kv_view_inline3486__rv_v2_main_pview
    ;
    pto::Stride<16384, 16384, 16384, 512, 1> v298 = pto::Stride<16384, 16384, 16384, 512, 1>();
    // pto: %kv_view_inline3486__rv_v2_main_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v299 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v294 + (v295 + v293 * v296), v297, v298);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
    TSTORE(v299, v289);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    // pto: %32
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v300 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
    // pto: %32
    ;
    uint64_t v301 = (uint64_t) v16;
    TASSIGN(v300, v301);
    // pto: %96
    ;
    __gm__ bfloat16_t* v302 = PTOAS__GLOBAL_TENSOR_DATA(v66);
    // pto: %96
    ;
    unsigned v303 = 448;
    // pto: %96
    ;
    pto::Shape<1, 1, 1, 1, 64> v304 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %96
    ;
    pto::Stride<64, 64, 64, 64, 1> v305 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %96
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v306 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v302 + v303, v304, v305);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    TLOAD(v300, v306);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %gamma_rope_cast_inline3507__tile
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
    // pto: %gamma_rope_cast_inline3507__tile
    ;
    uint64_t v308 = (uint64_t) v17;
    TASSIGN(v307, v308);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v309 = RoundMode::CAST_ROUND;
    SaturationMode v310 = SaturationMode::ON;
    TCVT(v307, v300, v309, v310);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    // pto: %gamma_rope_inline3508__tile
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
    // pto: %gamma_rope_inline3508__tile
    ;
    uint64_t v312 = (uint64_t) v17;
    TASSIGN(v311, v312);
    // pto: %kv_rope_chunk_inline3509__tile
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_rope_chunk_inline3509__tile
    ;
    uint64_t v314 = (uint64_t) v16;
    TASSIGN(v313, v314);
    // pto: %98
    ;
    __gm__ float* v315 = PTOAS__GLOBAL_TENSOR_DATA(v47);
    // pto: %98
    ;
    const int64_t v316 = 448;
    // pto: %98
    ;
    const int64_t v317 = 512;
    // pto: %98
    ;
    pto::Shape<1, 1, 1, 32, 64> v318 = pto::Shape<1, 1, 1, 32, 64>();
    // pto: %98
    ;
    pto::Stride<16384, 16384, 16384, 512, 1> v319 = pto::Stride<16384, 16384, 16384, 512, 1>();
    // pto: %98
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v320 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v315 + (v316 + v257 * v317), v318, v319);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    TLOAD(v313, v320);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %33
    ;
    Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %33
    ;
    uint64_t v322 = (uint64_t) v15;
    TASSIGN(v321, v322);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v323 = RoundMode::CAST_RINT;
    SaturationMode v324 = SaturationMode::ON;
    TCVT(v321, v313, v323, v324);
    // pto: %kv_rope_chunk_v1_inline3510__tile
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v325 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_rope_chunk_v1_inline3510__tile
    ;
    uint64_t v326 = (uint64_t) v16;
    TASSIGN(v325, v326);
    pipe_barrier(PIPE_V);
    RoundMode v327 = RoundMode::CAST_ROUND;
    SaturationMode v328 = SaturationMode::ON;
    TCVT(v325, v321, v327, v328);
    // pto: %34
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v329 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %34
    ;
    uint64_t v330 = (uint64_t) v16;
    TASSIGN(v329, v330);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v329, v325, v161);
    // pto: %kv_rope_norm_chunk_inline3511__tile
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v331 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_rope_norm_chunk_inline3511__tile
    ;
    uint64_t v332 = (uint64_t) v16;
    TASSIGN(v331, v332);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v331, v329, v311);
    // pto: %35
    ;
    Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v333 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %35
    ;
    uint64_t v334 = (uint64_t) v15;
    TASSIGN(v333, v334);
    pipe_barrier(PIPE_V);
    RoundMode v335 = RoundMode::CAST_RINT;
    SaturationMode v336 = SaturationMode::ON;
    TCVT(v333, v331, v335, v336);
    // pto: %kv_rope_norm_chunk_v1_inline3512__tile
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v337 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_rope_norm_chunk_v1_inline3512__tile
    ;
    uint64_t v338 = (uint64_t) v16;
    TASSIGN(v337, v338);
    pipe_barrier(PIPE_V);
    RoundMode v339 = RoundMode::CAST_ROUND;
    SaturationMode v340 = SaturationMode::ON;
    TCVT(v337, v333, v339, v340);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    // pto: %kv_cos_il_full_inline3513__tile
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v341 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_cos_il_full_inline3513__tile
    ;
    uint64_t v342 = (uint64_t) v15;
    TASSIGN(v341, v342);
    // pto: %freqs_cos__ssa_v0_pview
    ;
    __gm__ float* v343 = PTOAS__GLOBAL_TENSOR_DATA(v75);
    // pto: %freqs_cos__ssa_v0_pview
    ;
    const int64_t v344 = 0;
    // pto: %freqs_cos__ssa_v0_pview
    ;
    const int64_t v345 = 64;
    // pto: %freqs_cos__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 64> v346 = pto::Shape<1, 1, 1, 32, 64>();
    // pto: %freqs_cos__ssa_v0_pview
    ;
    pto::Stride<2048, 2048, 2048, 64, 1> v347 = pto::Stride<2048, 2048, 2048, 64, 1>();
    // pto: %freqs_cos__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<2048, 2048, 2048, 64, 1>, pto::Layout::ND> v348 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<2048, 2048, 2048, 64, 1>, pto::Layout::ND>(v343 + (v344 + v293 * v345), v346, v347);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    TLOAD(v341, v348);
    // pto: %kv_sin_signed_full_inline3514__tile
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v349 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_sin_signed_full_inline3514__tile
    ;
    uint64_t v350 = (uint64_t) v17;
    TASSIGN(v349, v350);
    // pto: %island_signed__ssa_v0_pview
    ;
    __gm__ float* v351 = PTOAS__GLOBAL_TENSOR_DATA(v84);
    // pto: %island_signed__ssa_v0_pview
    ;
    const int64_t v352 = 0;
    // pto: %island_signed__ssa_v0_pview
    ;
    const int64_t v353 = 64;
    // pto: %island_signed__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 64> v354 = pto::Shape<1, 1, 1, 32, 64>();
    // pto: %island_signed__ssa_v0_pview
    ;
    pto::Stride<2048, 2048, 2048, 64, 1> v355 = pto::Stride<2048, 2048, 2048, 64, 1>();
    // pto: %island_signed__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<2048, 2048, 2048, 64, 1>, pto::Layout::ND> v356 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<2048, 2048, 2048, 64, 1>, pto::Layout::ND>(v351 + (v352 + v293 * v353), v354, v355);
    TLOAD(v349, v356);
    // pto: %kv_swap_idx_full_inline3515__tile
    ;
    Tile<TileType::Vec, int32_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v357 = Tile<TileType::Vec, int32_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_swap_idx_full_inline3515__tile
    ;
    uint64_t v358 = (uint64_t) v18;
    TASSIGN(v357, v358);
    // pto: %island_swap__ssa_v0_pview
    ;
    __gm__ int32_t* v359 = PTOAS__GLOBAL_TENSOR_DATA(v93);
    // pto: %island_swap__ssa_v0_pview
    ;
    const int64_t v360 = 0;
    // pto: %island_swap__ssa_v0_pview
    ;
    const int64_t v361 = 64;
    // pto: %island_swap__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 64> v362 = pto::Shape<1, 1, 1, 32, 64>();
    // pto: %island_swap__ssa_v0_pview
    ;
    pto::Stride<2048, 2048, 2048, 64, 1> v363 = pto::Stride<2048, 2048, 2048, 64, 1>();
    // pto: %island_swap__ssa_v0_pview
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<2048, 2048, 2048, 64, 1>, pto::Layout::ND> v364 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<2048, 2048, 2048, 64, 1>, pto::Layout::ND>(v359 + (v360 + v293 * v361), v362, v363);
    TLOAD(v357, v364);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %gather_acc_init
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v365 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %gather_acc_init
    ;
    uint64_t v366 = (uint64_t) v19;
    TASSIGN(v365, v366);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    for (int64_t v367 = v27; v367 < v25; v367 += v23) {
      // pto: %gather_inp_row
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v368 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
      // pto: %gather_inp_row
      ;
      uint64_t v369 = (uint64_t) v16;
      TASSIGN(v368, v369);
      // pto: %slice_view
      ;
      int64_t v370 = (int64_t) ((uint64_t) v367 * (uint64_t) v14);
      // pto: %slice_view
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v371;
      // pto: %slice_view
      ;
      uint64_t v372 = (uint64_t) ((int64_t) (uint64_t) v370 + (uint64_t) v16);
      TASSIGN(v371, v372);
      // pto: %gather_idx_row
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v373 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
      // pto: %gather_idx_row
      ;
      uint64_t v374 = (uint64_t) v18;
      TASSIGN(v373, v374);
      // pto: %102
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v375;
      // pto: %102
      ;
      uint64_t v376 = (uint64_t) ((int64_t) (uint64_t) v370 + (uint64_t) v18);
      TASSIGN(v375, v376);
      // pto: %gather_row_tmp
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v377 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
      // pto: %gather_row_tmp
      ;
      uint64_t v378 = (uint64_t) v20;
      TASSIGN(v377, v378);
      // pto: %gather_row
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v379 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
      // pto: %gather_row
      ;
      uint64_t v380 = (uint64_t) v21;
      TASSIGN(v379, v380);
      pipe_barrier(PIPE_V);
      TGATHER(v379, v371, v375, v377);
      // pto: %assemble_view
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v381;
      // pto: %assemble_view
      ;
      uint64_t v382 = (uint64_t) ((int64_t) (uint64_t) v370 + (uint64_t) v19);
      TASSIGN(v381, v382);
      pipe_barrier(PIPE_V);
      TMOV(v381, v379);
    };
    // pto: %kv_swapped_full_inline3516__tile
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v383 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_swapped_full_inline3516__tile
    ;
    uint64_t v384 = (uint64_t) v19;
    TASSIGN(v383, v384);
    // pto: %36
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v385 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %36
    ;
    uint64_t v386 = (uint64_t) v16;
    TASSIGN(v385, v386);
    TMUL(v385, v337, v341);
    // pto: %37
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v387 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %37
    ;
    uint64_t v388 = (uint64_t) v15;
    TASSIGN(v387, v388);
    pipe_barrier(PIPE_V);
    TMUL(v387, v383, v349);
    // pto: %kv_rope_rot_full_inline3517__tile
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v389 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_rope_rot_full_inline3517__tile
    ;
    uint64_t v390 = (uint64_t) v16;
    TASSIGN(v389, v390);
    pipe_barrier(PIPE_V);
    TADD(v389, v385, v387);
    // pto: %kv_rope_i16_full_inline3518__tile
    ;
    Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v391 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_rope_i16_full_inline3518__tile
    ;
    uint64_t v392 = (uint64_t) v16;
    TASSIGN(v391, v392);
    pipe_barrier(PIPE_V);
    RoundMode v393 = RoundMode::CAST_RINT;
    SaturationMode v394 = SaturationMode::ON;
    TCVT(v391, v389, v393, v394);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    // pto: %kv_view_inline3486__rv_v2_pview
    ;
    __gm__ bfloat16_t* v395 = PTOAS__GLOBAL_TENSOR_DATA(v56);
    // pto: %kv_view_inline3486__rv_v2_pview
    ;
    const int64_t v396 = 448;
    // pto: %kv_view_inline3486__rv_v2_pview
    ;
    const int64_t v397 = 512;
    // pto: %kv_view_inline3486__rv_v2_pview
    ;
    pto::Shape<1, 1, 1, 32, 64> v398 = pto::Shape<1, 1, 1, 32, 64>();
    // pto: %kv_view_inline3486__rv_v2_pview
    ;
    pto::Stride<16384, 16384, 16384, 512, 1> v399 = pto::Stride<16384, 16384, 16384, 512, 1>();
    // pto: %kv_view_inline3486__rv_v2_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v400 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 64>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v395 + (v396 + v293 * v397), v398, v399);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    TSTORE(v400, v391);
  } else {
    // pto: %kv_reduce_tmp_inline3519__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v401 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_reduce_tmp_inline3519__ssa_v0
    ;
    uint64_t v402 = (uint64_t) v16;
    TASSIGN(v401, v402);
    // pto: %kv_sq_lanes_tail_inline3520__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v403 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_sq_lanes_tail_inline3520__ssa_v0
    ;
    uint64_t v404 = (uint64_t) v15;
    TASSIGN(v403, v404);
    TEXPANDS(v403, v26);
    for (int64_t v405 = v27; v405 < v22; v405 += v28) {
      // pto: %kv_chunk_tail_inline3522__ssa_v0
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v406 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %kv_chunk_tail_inline3522__ssa_v0
      ;
      uint64_t v407 = (uint64_t) v17;
      TASSIGN(v406, v407);
      // pto: %105
      ;
      int64_t v408 = v94 < v27 ? v27 : v94;
      // pto: %106
      ;
      int64_t v409 = v405 < v27 ? v27 : v405;
      // pto: %107
      ;
      const int64_t v410 = 0;
      // pto: %107
      ;
      __gm__ float* v411 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %107
      ;
      const int64_t v412 = 1;
      // pto: %107
      ;
      const int64_t v413 = 1;
      // pto: %107
      ;
      const int64_t v414 = 1;
      // pto: %107
      ;
      int64_t v415 = v96 * v22;
      // pto: %107
      ;
      int64_t v416 = v414 * v415;
      // pto: %107
      ;
      pto::Shape<1, 1, 1, -1, 64> v417 = pto::Shape<1, 1, 1, -1, 64>(v412, v413, v414, v96, v24);
      // pto: %107
      ;
      pto::Stride<-1, -1, -1, -1, -1> v418 = pto::Stride<-1, -1, -1, -1, -1>(v413 * v416, v416, v415, v22, v23);
      // pto: %107
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v419 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v411 + (v410 + v408 * v22 + v409 * v23), v417, v418);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      TLOAD(v406, v419);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %38
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v420 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %38
      ;
      uint64_t v421 = (uint64_t) v18;
      TASSIGN(v420, v421);
      // pto: %109
      ;
      int64_t v422 = (int64_t) ((uint64_t) v405 + (uint64_t) v24);
      // pto: %110
      ;
      int64_t v423 = v422 < v27 ? v27 : v422;
      // pto: %111
      ;
      const int64_t v424 = 0;
      // pto: %111
      ;
      __gm__ float* v425 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %111
      ;
      const int64_t v426 = 1;
      // pto: %111
      ;
      const int64_t v427 = 1;
      // pto: %111
      ;
      const int64_t v428 = 1;
      // pto: %111
      ;
      int64_t v429 = v96 * v22;
      // pto: %111
      ;
      int64_t v430 = v428 * v429;
      // pto: %111
      ;
      pto::Shape<1, 1, 1, -1, 64> v431 = pto::Shape<1, 1, 1, -1, 64>(v426, v427, v428, v96, v24);
      // pto: %111
      ;
      pto::Stride<-1, -1, -1, -1, -1> v432 = pto::Stride<-1, -1, -1, -1, -1>(v427 * v430, v430, v429, v22, v23);
      // pto: %111
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v433 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v425 + (v424 + v408 * v22 + v423 * v23), v431, v432);
      TLOAD(v420, v433);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %t__tmp_v70
      ;
      Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v434 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %t__tmp_v70
      ;
      uint64_t v435 = (uint64_t) v19;
      TASSIGN(v434, v435);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      RoundMode v436 = RoundMode::CAST_RINT;
      SaturationMode v437 = SaturationMode::ON;
      TCVT(v434, v406, v436, v437);
      // pto: %kv_chunk_tail_v1_inline3523__ssa_v0
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v438 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %kv_chunk_tail_v1_inline3523__ssa_v0
      ;
      uint64_t v439 = (uint64_t) v17;
      TASSIGN(v438, v439);
      pipe_barrier(PIPE_V);
      RoundMode v440 = RoundMode::CAST_ROUND;
      SaturationMode v441 = SaturationMode::ON;
      TCVT(v438, v434, v440, v441);
      // pto: %kv_sq_tail_inline3524__ssa_v0
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v442 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %kv_sq_tail_inline3524__ssa_v0
      ;
      uint64_t v443 = (uint64_t) v17;
      TASSIGN(v442, v443);
      pipe_barrier(PIPE_V);
      TMUL(v442, v438, v438);
      // pto: %kv_sq_lanes_tail_inline3520__ssa_v3
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v444 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %kv_sq_lanes_tail_inline3520__ssa_v3
      ;
      uint64_t v445 = (uint64_t) v17;
      TASSIGN(v444, v445);
      pipe_barrier(PIPE_V);
      TADD(v444, v403, v442);
      // pto: %39
      ;
      Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v446 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %39
      ;
      uint64_t v447 = (uint64_t) v20;
      TASSIGN(v446, v447);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      RoundMode v448 = RoundMode::CAST_RINT;
      SaturationMode v449 = SaturationMode::ON;
      TCVT(v446, v420, v448, v449);
      // pto: %40
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v450 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %40
      ;
      uint64_t v451 = (uint64_t) v18;
      TASSIGN(v450, v451);
      pipe_barrier(PIPE_V);
      RoundMode v452 = RoundMode::CAST_ROUND;
      SaturationMode v453 = SaturationMode::ON;
      TCVT(v450, v446, v452, v453);
      // pto: %41
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v454 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %41
      ;
      uint64_t v455 = (uint64_t) v18;
      TASSIGN(v454, v455);
      pipe_barrier(PIPE_V);
      TMUL(v454, v450, v450);
      // pto: %42
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v456 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
      // pto: %42
      ;
      uint64_t v457 = (uint64_t) v15;
      TASSIGN(v456, v457);
      pipe_barrier(PIPE_V);
      TADD(v456, v444, v454);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    };
    // pto: %t__tmp_v71
    ;
    Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v458 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v23);
    // pto: %t__tmp_v71
    ;
    uint64_t v459 = (uint64_t) v17;
    TASSIGN(v458, v459);
    pipe_barrier(PIPE_V);
    TROWSUM(v458, v403, v401);
    // pto: %kv_sq_sum_tail_inline3525__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v460 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v25);
    // pto: %kv_sq_sum_tail_inline3525__ssa_v0
    ;
    uint64_t v461 = (uint64_t) v17;
    TASSIGN(v460, v461);
    // pto: %t__tmp_v72
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v462 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v25);
    // pto: %t__tmp_v72
    ;
    uint64_t v463 = (uint64_t) v16;
    TASSIGN(v462, v463);
    pipe_barrier(PIPE_V);
    TMULS(v462, v460, v29);
    // pto: %t__tmp_v73
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v464 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v25);
    // pto: %t__tmp_v73
    ;
    uint64_t v465 = (uint64_t) v16;
    TASSIGN(v464, v465);
    pipe_barrier(PIPE_V);
    TADDS(v464, v462, v30);
    // pto: %kv_rms_tail_inline3526__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v466 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v25);
    // pto: %kv_rms_tail_inline3526__ssa_v0
    ;
    uint64_t v467 = (uint64_t) v16;
    TASSIGN(v466, v467);
    pipe_barrier(PIPE_V);
    TSQRT(v466, v464);
    // pto: %t__tmp_v74
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v468 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v25);
    // pto: %t__tmp_v74
    ;
    uint64_t v469 = (uint64_t) v15;
    TASSIGN(v468, v469);
    TEXPANDS(v468, v31);
    // pto: %kv_inv_rms_tail_inline3527__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v470 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v25);
    // pto: %kv_inv_rms_tail_inline3527__ssa_v0
    ;
    uint64_t v471 = (uint64_t) v19;
    TASSIGN(v470, v471);
    pipe_barrier(PIPE_V);
    TDIV(v470, v468, v466);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    // pto: %kv_inv_rms_t_tail_inline3528__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v23);
    // pto: %kv_inv_rms_t_tail_inline3528__ssa_v0
    ;
    uint64_t v473 = (uint64_t) v19;
    TASSIGN(v472, v473);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    for (int64_t v474 = v27; v474 < v32; v474 += v28) {
      // pto: %kv_chunk_tail_inline3522__ssa_v1
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v475 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %kv_chunk_tail_inline3522__ssa_v1
      ;
      uint64_t v476 = (uint64_t) v16;
      TASSIGN(v475, v476);
      // pto: %112
      ;
      int64_t v477 = v94 < v27 ? v27 : v94;
      // pto: %113
      ;
      int64_t v478 = v474 < v27 ? v27 : v474;
      // pto: %114
      ;
      const int64_t v479 = 0;
      // pto: %114
      ;
      __gm__ float* v480 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %114
      ;
      const int64_t v481 = 1;
      // pto: %114
      ;
      const int64_t v482 = 1;
      // pto: %114
      ;
      const int64_t v483 = 1;
      // pto: %114
      ;
      int64_t v484 = v96 * v22;
      // pto: %114
      ;
      int64_t v485 = v483 * v484;
      // pto: %114
      ;
      pto::Shape<1, 1, 1, -1, 64> v486 = pto::Shape<1, 1, 1, -1, 64>(v481, v482, v483, v96, v24);
      // pto: %114
      ;
      pto::Stride<-1, -1, -1, -1, -1> v487 = pto::Stride<-1, -1, -1, -1, -1>(v482 * v485, v485, v484, v22, v23);
      // pto: %114
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v488 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v480 + (v479 + v477 * v22 + v478 * v23), v486, v487);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      TLOAD(v475, v488);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %gamma_kv_input_tail_inline3531__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v489 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
      // pto: %gamma_kv_input_tail_inline3531__ssa_v0
      ;
      uint64_t v490 = (uint64_t) v20;
      TASSIGN(v489, v490);
      // pto: %116
      ;
      __gm__ bfloat16_t* v491 = PTOAS__GLOBAL_TENSOR_DATA(v66);
      // pto: %116
      ;
      const int64_t v492 = 0;
      // pto: %116
      ;
      pto::Shape<1, 1, 1, 1, 64> v493 = pto::Shape<1, 1, 1, 1, 64>();
      // pto: %116
      ;
      pto::Stride<64, 64, 64, 64, 1> v494 = pto::Stride<64, 64, 64, 64, 1>();
      // pto: %116
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v495 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v491 + (v492 + v478), v493, v494);
      TLOAD(v489, v495);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %43
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v496 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %43
      ;
      uint64_t v497 = (uint64_t) v15;
      TASSIGN(v496, v497);
      // pto: %118
      ;
      int64_t v498 = (int64_t) ((uint64_t) v474 + (uint64_t) v24);
      // pto: %119
      ;
      int64_t v499 = v498 < v27 ? v27 : v498;
      // pto: %120
      ;
      const int64_t v500 = 0;
      // pto: %120
      ;
      __gm__ float* v501 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %120
      ;
      const int64_t v502 = 1;
      // pto: %120
      ;
      const int64_t v503 = 1;
      // pto: %120
      ;
      const int64_t v504 = 1;
      // pto: %120
      ;
      int64_t v505 = v96 * v22;
      // pto: %120
      ;
      int64_t v506 = v504 * v505;
      // pto: %120
      ;
      pto::Shape<1, 1, 1, -1, 64> v507 = pto::Shape<1, 1, 1, -1, 64>(v502, v503, v504, v96, v24);
      // pto: %120
      ;
      pto::Stride<-1, -1, -1, -1, -1> v508 = pto::Stride<-1, -1, -1, -1, -1>(v503 * v506, v506, v505, v22, v23);
      // pto: %120
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v509 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v501 + (v500 + v477 * v22 + v499 * v23), v507, v508);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      TLOAD(v496, v509);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %44
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v510 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
      // pto: %44
      ;
      uint64_t v511 = (uint64_t) v21;
      TASSIGN(v510, v511);
      // pto: %123
      ;
      __gm__ bfloat16_t* v512 = PTOAS__GLOBAL_TENSOR_DATA(v66);
      // pto: %123
      ;
      const int64_t v513 = 0;
      // pto: %123
      ;
      pto::Shape<1, 1, 1, 1, 64> v514 = pto::Shape<1, 1, 1, 1, 64>();
      // pto: %123
      ;
      pto::Stride<64, 64, 64, 64, 1> v515 = pto::Stride<64, 64, 64, 64, 1>();
      // pto: %123
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v516 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v512 + (v513 + v499), v514, v515);
      TLOAD(v510, v516);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %t__tmp_v75
      ;
      Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v517 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %t__tmp_v75
      ;
      uint64_t v518 = (uint64_t) v17;
      TASSIGN(v517, v518);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      RoundMode v519 = RoundMode::CAST_RINT;
      SaturationMode v520 = SaturationMode::ON;
      TCVT(v517, v475, v519, v520);
      // pto: %kv_chunk_tail_v2_inline3530__ssa_v0
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v521 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %kv_chunk_tail_v2_inline3530__ssa_v0
      ;
      uint64_t v522 = (uint64_t) v16;
      TASSIGN(v521, v522);
      pipe_barrier(PIPE_V);
      RoundMode v523 = RoundMode::CAST_ROUND;
      SaturationMode v524 = SaturationMode::ON;
      TCVT(v521, v517, v523, v524);
      // pto: %gamma_kv_cast_tail_inline3532__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v525 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
      // pto: %gamma_kv_cast_tail_inline3532__ssa_v0
      ;
      uint64_t v526 = (uint64_t) v17;
      TASSIGN(v525, v526);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      RoundMode v527 = RoundMode::CAST_ROUND;
      SaturationMode v528 = SaturationMode::ON;
      TCVT(v525, v489, v527, v528);
      // pto: %gamma_kv_chunk_tail_inline3533__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v529 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
      // pto: %gamma_kv_chunk_tail_inline3533__ssa_v0
      ;
      uint64_t v530 = (uint64_t) v17;
      TASSIGN(v529, v530);
      // pto: %t__tmp_v76
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v531 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %t__tmp_v76
      ;
      uint64_t v532 = (uint64_t) v16;
      TASSIGN(v531, v532);
      TROWEXPANDMUL(v531, v521, v472);
      // pto: %kv_normed_tail_inline3534__ssa_v0
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v533 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %kv_normed_tail_inline3534__ssa_v0
      ;
      uint64_t v534 = (uint64_t) v16;
      TASSIGN(v533, v534);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v533, v531, v529);
      // pto: %kv_normed_bf16_tail_inline3535__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v535 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %kv_normed_bf16_tail_inline3535__ssa_v0
      ;
      uint64_t v536 = (uint64_t) v16;
      TASSIGN(v535, v536);
      pipe_barrier(PIPE_V);
      RoundMode v537 = RoundMode::CAST_RINT;
      SaturationMode v538 = SaturationMode::ON;
      TCVT(v535, v533, v537, v538);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
      v535.SetValidShape(v96, v24);
      // pto: %124
      ;
      int64_t v539 = v97 < v27 ? v27 : v97;
      // pto: %kv_view_inline3486__ssa_v0_pview
      ;
      const int64_t v540 = 0;
      // pto: %kv_view_inline3486__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v541 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %kv_view_inline3486__ssa_v0_pview
      ;
      const int64_t v542 = 1;
      // pto: %kv_view_inline3486__ssa_v0_pview
      ;
      const int64_t v543 = 1;
      // pto: %kv_view_inline3486__ssa_v0_pview
      ;
      const int64_t v544 = 1;
      // pto: %kv_view_inline3486__ssa_v0_pview
      ;
      int64_t v545 = v96 * v22;
      // pto: %kv_view_inline3486__ssa_v0_pview
      ;
      int64_t v546 = v544 * v545;
      // pto: %kv_view_inline3486__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 64> v547 = pto::Shape<1, 1, 1, -1, 64>(v542, v543, v544, v96, v24);
      // pto: %kv_view_inline3486__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v548 = pto::Stride<-1, -1, -1, -1, -1>(v543 * v546, v546, v545, v22, v23);
      // pto: %kv_view_inline3486__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v549 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v541 + (v540 + v539 * v22 + v478 * v23), v547, v548);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v549, v535);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      // pto: %45
      ;
      Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v550 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %45
      ;
      uint64_t v551 = (uint64_t) v18;
      TASSIGN(v550, v551);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      RoundMode v552 = RoundMode::CAST_RINT;
      SaturationMode v553 = SaturationMode::ON;
      TCVT(v550, v496, v552, v553);
      // pto: %46
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v554 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %46
      ;
      uint64_t v555 = (uint64_t) v15;
      TASSIGN(v554, v555);
      pipe_barrier(PIPE_V);
      RoundMode v556 = RoundMode::CAST_ROUND;
      SaturationMode v557 = SaturationMode::ON;
      TCVT(v554, v550, v556, v557);
      // pto: %47
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v558 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
      // pto: %47
      ;
      uint64_t v559 = (uint64_t) v18;
      TASSIGN(v558, v559);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      RoundMode v560 = RoundMode::CAST_ROUND;
      SaturationMode v561 = SaturationMode::ON;
      TCVT(v558, v510, v560, v561);
      // pto: %48
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v562 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
      // pto: %48
      ;
      uint64_t v563 = (uint64_t) v18;
      TASSIGN(v562, v563);
      // pto: %49
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v564 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %49
      ;
      uint64_t v565 = (uint64_t) v15;
      TASSIGN(v564, v565);
      TROWEXPANDMUL(v564, v554, v472);
      // pto: %50
      ;
      Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v566 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %50
      ;
      uint64_t v567 = (uint64_t) v15;
      TASSIGN(v566, v567);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v566, v564, v562);
      // pto: %51
      ;
      Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v568 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
      // pto: %51
      ;
      uint64_t v569 = (uint64_t) v15;
      TASSIGN(v568, v569);
      pipe_barrier(PIPE_V);
      RoundMode v570 = RoundMode::CAST_RINT;
      SaturationMode v571 = SaturationMode::ON;
      TCVT(v568, v566, v570, v571);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
      v568.SetValidShape(v96, v24);
      // pto: %130
      ;
      const int64_t v572 = 0;
      // pto: %130
      ;
      __gm__ bfloat16_t* v573 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %130
      ;
      const int64_t v574 = 1;
      // pto: %130
      ;
      const int64_t v575 = 1;
      // pto: %130
      ;
      const int64_t v576 = 1;
      // pto: %130
      ;
      int64_t v577 = v96 * v22;
      // pto: %130
      ;
      int64_t v578 = v576 * v577;
      // pto: %130
      ;
      pto::Shape<1, 1, 1, -1, 64> v579 = pto::Shape<1, 1, 1, -1, 64>(v574, v575, v576, v96, v24);
      // pto: %130
      ;
      pto::Stride<-1, -1, -1, -1, -1> v580 = pto::Stride<-1, -1, -1, -1, -1>(v575 * v578, v578, v577, v22, v23);
      // pto: %130
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v581 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v573 + (v572 + v539 * v22 + v499 * v23), v579, v580);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v581, v568);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    };
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
    // pto: %53
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v582 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
    // pto: %53
    ;
    uint64_t v583 = (uint64_t) v16;
    TASSIGN(v582, v583);
    // pto: %131
    ;
    int64_t v584 = v94 < v27 ? v27 : v94;
    // pto: %132
    ;
    const int64_t v585 = 0;
    // pto: %132
    ;
    __gm__ float* v586 = PTOAS__GLOBAL_TENSOR_DATA(v47);
    // pto: %132
    ;
    const int64_t v587 = 1;
    // pto: %132
    ;
    const int64_t v588 = 1;
    // pto: %132
    ;
    const int64_t v589 = 1;
    // pto: %132
    ;
    int64_t v590 = v96 * v22;
    // pto: %132
    ;
    int64_t v591 = v589 * v590;
    // pto: %132
    ;
    pto::Shape<1, 1, 1, -1, 64> v592 = pto::Shape<1, 1, 1, -1, 64>(v587, v588, v589, v96, v24);
    // pto: %132
    ;
    pto::Stride<-1, -1, -1, -1, -1> v593 = pto::Stride<-1, -1, -1, -1, -1>(v588 * v591, v591, v590, v22, v23);
    // pto: %132
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v594 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v586 + (v585 + v584 * v22 + v32 * v23), v592, v593);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
    TLOAD(v582, v594);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %54
    ;
    Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v595 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
    // pto: %54
    ;
    uint64_t v596 = (uint64_t) v15;
    TASSIGN(v595, v596);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    RoundMode v597 = RoundMode::CAST_RINT;
    SaturationMode v598 = SaturationMode::ON;
    TCVT(v595, v582, v597, v598);
    // pto: %55
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v599 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
    // pto: %55
    ;
    uint64_t v600 = (uint64_t) v16;
    TASSIGN(v599, v600);
    pipe_barrier(PIPE_V);
    RoundMode v601 = RoundMode::CAST_ROUND;
    SaturationMode v602 = SaturationMode::ON;
    TCVT(v599, v595, v601, v602);
    // pto: %56
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v603 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
    // pto: %56
    ;
    uint64_t v604 = (uint64_t) v17;
    TASSIGN(v603, v604);
    // pto: %133
    ;
    __gm__ bfloat16_t* v605 = PTOAS__GLOBAL_TENSOR_DATA(v66);
    // pto: %133
    ;
    unsigned v606 = 384;
    // pto: %133
    ;
    pto::Shape<1, 1, 1, 1, 64> v607 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %133
    ;
    pto::Stride<64, 64, 64, 64, 1> v608 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %133
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v609 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v605 + v606, v607, v608);
    TLOAD(v603, v609);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %57
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v610 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
    // pto: %57
    ;
    uint64_t v611 = (uint64_t) v15;
    TASSIGN(v610, v611);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    RoundMode v612 = RoundMode::CAST_ROUND;
    SaturationMode v613 = SaturationMode::ON;
    TCVT(v610, v603, v612, v613);
    // pto: %58
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v614 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
    // pto: %58
    ;
    uint64_t v615 = (uint64_t) v15;
    TASSIGN(v614, v615);
    // pto: %59
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v616 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
    // pto: %59
    ;
    uint64_t v617 = (uint64_t) v16;
    TASSIGN(v616, v617);
    TROWEXPANDMUL(v616, v599, v472);
    // pto: %60
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v618 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
    // pto: %60
    ;
    uint64_t v619 = (uint64_t) v16;
    TASSIGN(v618, v619);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v618, v616, v614);
    // pto: %61
    ;
    Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v620 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
    // pto: %61
    ;
    uint64_t v621 = (uint64_t) v16;
    TASSIGN(v620, v621);
    pipe_barrier(PIPE_V);
    RoundMode v622 = RoundMode::CAST_RINT;
    SaturationMode v623 = SaturationMode::ON;
    TCVT(v620, v618, v622, v623);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    v620.SetValidShape(v96, v24);
    // pto: %135
    ;
    int64_t v624 = v97 < v27 ? v27 : v97;
    // pto: %136
    ;
    const int64_t v625 = 0;
    // pto: %136
    ;
    __gm__ bfloat16_t* v626 = PTOAS__GLOBAL_TENSOR_DATA(v56);
    // pto: %136
    ;
    const int64_t v627 = 1;
    // pto: %136
    ;
    const int64_t v628 = 1;
    // pto: %136
    ;
    const int64_t v629 = 1;
    // pto: %136
    ;
    int64_t v630 = v96 * v22;
    // pto: %136
    ;
    int64_t v631 = v629 * v630;
    // pto: %136
    ;
    pto::Shape<1, 1, 1, -1, 64> v632 = pto::Shape<1, 1, 1, -1, 64>(v627, v628, v629, v96, v24);
    // pto: %136
    ;
    pto::Stride<-1, -1, -1, -1, -1> v633 = pto::Stride<-1, -1, -1, -1, -1>(v628 * v631, v631, v630, v22, v23);
    // pto: %136
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v634 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v626 + (v625 + v624 * v22 + v32 * v23), v632, v633);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    TSTORE(v634, v620);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
    // pto: %gamma_rope_input_tail_inline3537__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v635 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
    // pto: %gamma_rope_input_tail_inline3537__ssa_v0
    ;
    uint64_t v636 = (uint64_t) v16;
    TASSIGN(v635, v636);
    // pto: %137
    ;
    __gm__ bfloat16_t* v637 = PTOAS__GLOBAL_TENSOR_DATA(v66);
    // pto: %137
    ;
    unsigned v638 = 448;
    // pto: %137
    ;
    pto::Shape<1, 1, 1, 1, 64> v639 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %137
    ;
    pto::Stride<64, 64, 64, 64, 1> v640 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %137
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v641 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v637 + v638, v639, v640);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
    TLOAD(v635, v641);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %gamma_rope_cast_tail_inline3538__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v642 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
    // pto: %gamma_rope_cast_tail_inline3538__ssa_v0
    ;
    uint64_t v643 = (uint64_t) v17;
    TASSIGN(v642, v643);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v644 = RoundMode::CAST_ROUND;
    SaturationMode v645 = SaturationMode::ON;
    TCVT(v642, v635, v644, v645);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    // pto: %gamma_rope_tail_inline3539__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v646 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
    // pto: %gamma_rope_tail_inline3539__ssa_v0
    ;
    uint64_t v647 = (uint64_t) v17;
    TASSIGN(v646, v647);
    // pto: %kv_rope_chunk_tail_inline3540__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v648 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
    // pto: %kv_rope_chunk_tail_inline3540__ssa_v0
    ;
    uint64_t v649 = (uint64_t) v16;
    TASSIGN(v648, v649);
    // pto: %139
    ;
    const int64_t v650 = 0;
    // pto: %139
    ;
    __gm__ float* v651 = PTOAS__GLOBAL_TENSOR_DATA(v47);
    // pto: %139
    ;
    const int64_t v652 = 1;
    // pto: %139
    ;
    const int64_t v653 = 1;
    // pto: %139
    ;
    const int64_t v654 = 1;
    // pto: %139
    ;
    int64_t v655 = v96 * v22;
    // pto: %139
    ;
    int64_t v656 = v654 * v655;
    // pto: %139
    ;
    pto::Shape<1, 1, 1, -1, 64> v657 = pto::Shape<1, 1, 1, -1, 64>(v652, v653, v654, v96, v24);
    // pto: %139
    ;
    pto::Stride<-1, -1, -1, -1, -1> v658 = pto::Stride<-1, -1, -1, -1, -1>(v653 * v656, v656, v655, v22, v23);
    // pto: %139
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v659 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v651 + (v650 + v584 * v22 + v33 * v23), v657, v658);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    TLOAD(v648, v659);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %t__tmp_v77
    ;
    Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v660 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
    // pto: %t__tmp_v77
    ;
    uint64_t v661 = (uint64_t) v15;
    TASSIGN(v660, v661);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v662 = RoundMode::CAST_RINT;
    SaturationMode v663 = SaturationMode::ON;
    TCVT(v660, v648, v662, v663);
    // pto: %kv_rope_chunk_tail_v1_inline3541__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v664 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
    // pto: %kv_rope_chunk_tail_v1_inline3541__ssa_v0
    ;
    uint64_t v665 = (uint64_t) v16;
    TASSIGN(v664, v665);
    pipe_barrier(PIPE_V);
    RoundMode v666 = RoundMode::CAST_ROUND;
    SaturationMode v667 = SaturationMode::ON;
    TCVT(v664, v660, v666, v667);
    // pto: %t__tmp_v78
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v668 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
    // pto: %t__tmp_v78
    ;
    uint64_t v669 = (uint64_t) v16;
    TASSIGN(v668, v669);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v668, v664, v472);
    // pto: %kv_rope_norm_tail_inline3542__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v670 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
    // pto: %kv_rope_norm_tail_inline3542__ssa_v0
    ;
    uint64_t v671 = (uint64_t) v16;
    TASSIGN(v670, v671);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v670, v668, v646);
    // pto: %t__tmp_v79
    ;
    Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v672 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
    // pto: %t__tmp_v79
    ;
    uint64_t v673 = (uint64_t) v15;
    TASSIGN(v672, v673);
    pipe_barrier(PIPE_V);
    RoundMode v674 = RoundMode::CAST_RINT;
    SaturationMode v675 = SaturationMode::ON;
    TCVT(v672, v670, v674, v675);
    // pto: %kv_rope_norm_tail_v1_inline3543__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v676 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
    // pto: %kv_rope_norm_tail_v1_inline3543__ssa_v0
    ;
    uint64_t v677 = (uint64_t) v16;
    TASSIGN(v676, v677);
    pipe_barrier(PIPE_V);
    RoundMode v678 = RoundMode::CAST_ROUND;
    SaturationMode v679 = SaturationMode::ON;
    TCVT(v676, v672, v678, v679);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    // pto: %kv_cos_il_tail_inline3544__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v680 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
    // pto: %kv_cos_il_tail_inline3544__ssa_v0
    ;
    uint64_t v681 = (uint64_t) v15;
    TASSIGN(v680, v681);
    // pto: %141
    ;
    const int64_t v682 = 0;
    // pto: %141
    ;
    __gm__ float* v683 = PTOAS__GLOBAL_TENSOR_DATA(v75);
    // pto: %141
    ;
    const int64_t v684 = 1;
    // pto: %141
    ;
    const int64_t v685 = 1;
    // pto: %141
    ;
    const int64_t v686 = 1;
    // pto: %141
    ;
    int64_t v687 = v96 * v24;
    // pto: %141
    ;
    int64_t v688 = v686 * v687;
    // pto: %141
    ;
    pto::Shape<1, 1, 1, -1, 64> v689 = pto::Shape<1, 1, 1, -1, 64>(v684, v685, v686, v96, v24);
    // pto: %141
    ;
    pto::Stride<-1, -1, -1, -1, -1> v690 = pto::Stride<-1, -1, -1, -1, -1>(v685 * v688, v688, v687, v24, v23);
    // pto: %141
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v691 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v683 + (v682 + v624 * v24 + v27 * v23), v689, v690);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    TLOAD(v680, v691);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %kv_sin_signed_tail_inline3545__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v692 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
    // pto: %kv_sin_signed_tail_inline3545__ssa_v0
    ;
    uint64_t v693 = (uint64_t) v17;
    TASSIGN(v692, v693);
    // pto: %143
    ;
    const int64_t v694 = 0;
    // pto: %143
    ;
    __gm__ float* v695 = PTOAS__GLOBAL_TENSOR_DATA(v84);
    // pto: %143
    ;
    const int64_t v696 = 1;
    // pto: %143
    ;
    const int64_t v697 = 1;
    // pto: %143
    ;
    const int64_t v698 = 1;
    // pto: %143
    ;
    int64_t v699 = v96 * v24;
    // pto: %143
    ;
    int64_t v700 = v698 * v699;
    // pto: %143
    ;
    pto::Shape<1, 1, 1, -1, 64> v701 = pto::Shape<1, 1, 1, -1, 64>(v696, v697, v698, v96, v24);
    // pto: %143
    ;
    pto::Stride<-1, -1, -1, -1, -1> v702 = pto::Stride<-1, -1, -1, -1, -1>(v697 * v700, v700, v699, v24, v23);
    // pto: %143
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v703 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v695 + (v694 + v624 * v24 + v27 * v23), v701, v702);
    TLOAD(v692, v703);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %t__tmp_v80
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v704 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %t__tmp_v80
    ;
    uint64_t v705 = (uint64_t) v18;
    TASSIGN(v704, v705);
    TEXPANDS(v704, v31);
    // pto: %t__ci_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v706 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v34);
    // pto: %t__ci_tmp_v0
    ;
    uint64_t v707 = (uint64_t) v19;
    TASSIGN(v706, v707);
    // pto: %t__tmp_v81
    ;
    Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v708 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
    // pto: %t__tmp_v81
    ;
    uint64_t v709 = (uint64_t) v20;
    TASSIGN(v708, v709);
    // pto: %ci_tmp_view
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v710;
    TRESHAPE(v710, v706);
    // pto: %ci_dst_view
    ;
    Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v711;
    TRESHAPE(v711, v708);
    TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v711, v35, v710);
    // pto: %t__tmp_v82
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v712 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
    // pto: %t__tmp_v82
    ;
    uint64_t v713 = (uint64_t) v19;
    TASSIGN(v712, v713);
    pipe_barrier(PIPE_V);
    RoundMode v714 = RoundMode::CAST_ROUND;
    SaturationMode v715 = SaturationMode::ON;
    TCVT(v712, v708, v714, v715);
    // pto: %kv_col_inline3546__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v716 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_col_inline3546__ssa_v0
    ;
    uint64_t v717 = (uint64_t) v18;
    TASSIGN(v716, v717);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v716, v704, v712);
    // pto: %t__tmp_v83
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v718 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %t__tmp_v83
    ;
    uint64_t v719 = (uint64_t) v19;
    TASSIGN(v718, v719);
    pipe_barrier(PIPE_V);
    TMULS(v718, v716, v36);
    // pto: %t__tmp_v84
    ;
    Tile<TileType::Vec, int32_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v720 = Tile<TileType::Vec, int32_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %t__tmp_v84
    ;
    uint64_t v721 = (uint64_t) v19;
    TASSIGN(v720, v721);
    pipe_barrier(PIPE_V);
    RoundMode v722 = RoundMode::CAST_TRUNC;
    SaturationMode v723 = SaturationMode::ON;
    TCVT(v720, v718, v722, v723);
    // pto: %kv_dup_f_inline3547__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v724 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_dup_f_inline3547__ssa_v0
    ;
    uint64_t v725 = (uint64_t) v19;
    TASSIGN(v724, v725);
    pipe_barrier(PIPE_V);
    RoundMode v726 = RoundMode::CAST_ROUND;
    SaturationMode v727 = SaturationMode::ON;
    TCVT(v724, v720, v726, v727);
    // pto: %t__tmp_v85
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v728 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %t__tmp_v85
    ;
    uint64_t v729 = (uint64_t) v19;
    TASSIGN(v728, v729);
    pipe_barrier(PIPE_V);
    TMULS(v728, v724, v37);
    // pto: %kv_lane_inline3548__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v730 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_lane_inline3548__ssa_v0
    ;
    uint64_t v731 = (uint64_t) v19;
    TASSIGN(v730, v731);
    pipe_barrier(PIPE_V);
    TSUB(v730, v716, v728);
    // pto: %t__tmp_v86
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v732 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %t__tmp_v86
    ;
    uint64_t v733 = (uint64_t) v18;
    TASSIGN(v732, v733);
    pipe_barrier(PIPE_V);
    TADDS(v732, v716, v31);
    // pto: %t__tmp_v87
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v734 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %t__tmp_v87
    ;
    uint64_t v735 = (uint64_t) v19;
    TASSIGN(v734, v735);
    TMULS(v734, v730, v37);
    // pto: %kv_swap_f_inline3549__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v736 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_swap_f_inline3549__ssa_v0
    ;
    uint64_t v737 = (uint64_t) v18;
    TASSIGN(v736, v737);
    pipe_barrier(PIPE_V);
    TSUB(v736, v732, v734);
    // pto: %t__ci_tmp_v1
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v738 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v34);
    // pto: %t__ci_tmp_v1
    ;
    uint64_t v739 = (uint64_t) v19;
    TASSIGN(v738, v739);
    // pto: %t__tmp_v88
    ;
    Tile<TileType::Vec, int32_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v740 = Tile<TileType::Vec, int32_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v25);
    // pto: %t__tmp_v88
    ;
    uint64_t v741 = (uint64_t) v20;
    TASSIGN(v740, v741);
    // pto: %144
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v742;
    TRESHAPE(v742, v738);
    // pto: %145
    ;
    Tile<TileType::Vec, int32_t, 1, 32, BLayout::RowMajor, 1, 32, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v743;
    TRESHAPE(v743, v740);
    pipe_barrier(PIPE_V);
    TCI<Tile<TileType::Vec, int32_t, 1, 32, BLayout::RowMajor, 1, 32, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v743, v35, v742);
    // pto: %t__tmp_v89
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v744 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v25);
    // pto: %t__tmp_v89
    ;
    uint64_t v745 = (uint64_t) v19;
    TASSIGN(v744, v745);
    pipe_barrier(PIPE_V);
    RoundMode v746 = RoundMode::CAST_ROUND;
    SaturationMode v747 = SaturationMode::ON;
    TCVT(v744, v740, v746, v747);
    // pto: %kv_row_seed_inline3550__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v748 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v25);
    // pto: %kv_row_seed_inline3550__ssa_v0
    ;
    uint64_t v749 = (uint64_t) v20;
    TASSIGN(v748, v749);
    pipe_barrier(PIPE_V);
    TMULS(v748, v744, v38);
    // pto: %t__tmp_v90
    ;
    Tile<TileType::Vec, float, 64, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v750 = Tile<TileType::Vec, float, 64, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v25);
    // pto: %t__tmp_v90
    ;
    uint64_t v751 = (uint64_t) v19;
    TASSIGN(v750, v751);
    pipe_barrier(PIPE_V);
    TEXPANDS(v750, v31);
    // pto: %kv_row_grid_inline3551__ssa_v0
    ;
    Tile<TileType::Vec, float, 64, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v752 = Tile<TileType::Vec, float, 64, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v25);
    // pto: %kv_row_grid_inline3551__ssa_v0
    ;
    uint64_t v753 = (uint64_t) v19;
    TASSIGN(v752, v753);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v752, v750, v748);
    // pto: %transpose_tmp
    ;
    Tile<TileType::Vec, float, 64, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v754 = Tile<TileType::Vec, float, 64, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v25);
    // pto: %transpose_tmp
    ;
    uint64_t v755 = (uint64_t) v20;
    TASSIGN(v754, v755);
    // pto: %kv_row_offset_inline3552__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v756 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_row_offset_inline3552__ssa_v0
    ;
    uint64_t v757 = (uint64_t) v21;
    TASSIGN(v756, v757);
    pipe_barrier(PIPE_V);
    TTRANS(v756, v752, v754);
    // pto: %t__tmp_v91
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v758 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %t__tmp_v91
    ;
    uint64_t v759 = (uint64_t) v18;
    TASSIGN(v758, v759);
    pipe_barrier(PIPE_V);
    TADD(v758, v736, v756);
    // pto: %kv_swap_idx_tail_inline3553__ssa_v0
    ;
    Tile<TileType::Vec, int32_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v760 = Tile<TileType::Vec, int32_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_swap_idx_tail_inline3553__ssa_v0
    ;
    uint64_t v761 = (uint64_t) v18;
    TASSIGN(v760, v761);
    pipe_barrier(PIPE_V);
    RoundMode v762 = RoundMode::CAST_ROUND;
    SaturationMode v763 = SaturationMode::ON;
    TCVT(v760, v758, v762, v763);
    // pto: %kv_gather_tmp_inline3554__ssa_v0
    ;
    Tile<TileType::Vec, int32_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v764 = Tile<TileType::Vec, int32_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_gather_tmp_inline3554__ssa_v0
    ;
    uint64_t v765 = (uint64_t) v19;
    TASSIGN(v764, v765);
    // pto: %kv_swapped_tail_inline3555__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v766 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %kv_swapped_tail_inline3555__ssa_v0
    ;
    uint64_t v767 = (uint64_t) v20;
    TASSIGN(v766, v767);
    pipe_barrier(PIPE_V);
    TGATHER(v766, v676, v760, v764);
    // pto: %t__tmp_v92
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v768 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
    // pto: %t__tmp_v92
    ;
    uint64_t v769 = (uint64_t) v16;
    TASSIGN(v768, v769);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TMUL(v768, v676, v680);
    // pto: %t__tmp_v93
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v770 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v25, v24);
    // pto: %t__tmp_v93
    ;
    uint64_t v771 = (uint64_t) v15;
    TASSIGN(v770, v771);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TMUL(v770, v766, v692);
    // pto: %kv_rope_rot_tail_inline3556__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v772 = Tile<TileType::Vec, float, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
    // pto: %kv_rope_rot_tail_inline3556__ssa_v0
    ;
    uint64_t v773 = (uint64_t) v16;
    TASSIGN(v772, v773);
    pipe_barrier(PIPE_V);
    TADD(v772, v768, v770);
    // pto: %kv_rope_i16_tail_inline3557__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v774 = Tile<TileType::Vec, bfloat16_t, 32, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v96, v24);
    // pto: %kv_rope_i16_tail_inline3557__ssa_v0
    ;
    uint64_t v775 = (uint64_t) v16;
    TASSIGN(v774, v775);
    pipe_barrier(PIPE_V);
    RoundMode v776 = RoundMode::CAST_RINT;
    SaturationMode v777 = SaturationMode::ON;
    TCVT(v774, v772, v776, v777);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    v774.SetValidShape(v96, v24);
    // pto: %147
    ;
    const int64_t v778 = 0;
    // pto: %147
    ;
    __gm__ bfloat16_t* v779 = PTOAS__GLOBAL_TENSOR_DATA(v56);
    // pto: %147
    ;
    const int64_t v780 = 1;
    // pto: %147
    ;
    const int64_t v781 = 1;
    // pto: %147
    ;
    const int64_t v782 = 1;
    // pto: %147
    ;
    int64_t v783 = v96 * v22;
    // pto: %147
    ;
    int64_t v784 = v782 * v783;
    // pto: %147
    ;
    pto::Shape<1, 1, 1, -1, 64> v785 = pto::Shape<1, 1, 1, -1, 64>(v780, v781, v782, v96, v24);
    // pto: %147
    ;
    pto::Stride<-1, -1, -1, -1, -1> v786 = pto::Stride<-1, -1, -1, -1, -1>(v781 * v784, v784, v783, v22, v23);
    // pto: %147
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v787 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v779 + (v778 + v624 * v22 + v33 * v23), v785, v786);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    TSTORE(v787, v774);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}