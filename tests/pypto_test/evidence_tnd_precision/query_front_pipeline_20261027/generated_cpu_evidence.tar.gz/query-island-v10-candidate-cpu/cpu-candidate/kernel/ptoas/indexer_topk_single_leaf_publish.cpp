#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void indexer_topk_single_leaf_publish(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ int32_t* v3, __gm__ float* v4, __gm__ float* v5, __gm__ int32_t* v6, int64_t v7, int64_t v8, int32_t v9, int32_t v10) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  pto::MrgSortExecutedNumList v11 = pto::MrgSortExecutedNumList{0, 0, 0, 0};
  // pto: %c32768_i64
  const int64_t v12 = 32768;
  // pto: %c98304_i64
  const int64_t v13 = 98304;
  // pto: %c0_i64
  const int64_t v14 = 0;
  const int64_t v15 = 114688;
  const int64_t v16 = 131072;
  const int64_t v17 = 147456;
  // pto: %c1_index
  const int64_t v18 = 1;
  // pto: %c432_index
  const int64_t v19 = 432;
  // pto: %c8192_index
  const int64_t v20 = 8192;
  // pto: %c512_index
  const int64_t v21 = 512;
  // pto: %c48_index
  const int64_t v22 = 48;
  // pto: %c0_index
  const int64_t v23 = 0;
  // pto: %c4_index
  const int64_t v24 = 4;
  // pto: %c1_i64
  const int64_t v25 = 1;
  // pto: %c4_i64
  const int64_t v26 = 4;
  // pto: %c2048_index
  const int64_t v27 = 2048;
  // pto: %c192_index
  const int64_t v28 = 192;
  // pto: %c0_i32
  const int32_t v29 = 0;
  // pto: %cst_18
  const float v30 = -3.40282347E+38f;
  // pto: %c4096_index
  const int64_t v31 = 4096;
  // pto: %c64_i32
  const int32_t v32 = 64;
  // pto: %c256_i32
  const int32_t v33 = 256;
  // pto: %c1024_i32
  const int32_t v34 = 1024;
  // pto: %c1024_index
  const int64_t v35 = 1024;
  // pto: %cn1_i32
  const int32_t v36 = -1;
  // pto: %c16384_index
  const int64_t v37 = 16384;
  // pto: %score_arena__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %score_arena__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %score_arena__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %score_arena__ssa_v0_view
  int64_t v41 = v19 * v20;
  // pto: %score_arena__ssa_v0_view
  int64_t v42 = v40 * v41;
  // pto: %score_arena__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v43 = pto::Shape<1, 1, 1, -1, -1>(v38, v39, v40, v19, v20);
  // pto: %score_arena__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v44 = pto::Stride<-1, -1, -1, -1, -1>(v39 * v42, v42, v41, v20, v18);
  // pto: %score_arena__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v45 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v43, v44);
  // pto: %topk_scores__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %topk_scores__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %topk_scores__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %topk_scores__ssa_v0_view
  int64_t v49 = (int64_t) v7;
  // pto: %topk_scores__ssa_v0_view
  int64_t v50 = v49 * v21;
  // pto: %topk_scores__ssa_v0_view
  int64_t v51 = v48 * v50;
  // pto: %topk_scores__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v52 = pto::Shape<1, 1, 1, -1, -1>(v46, v47, v48, v49, v21);
  // pto: %topk_scores__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v53 = pto::Stride<-1, -1, -1, -1, -1>(v47 * v51, v51, v50, v21, v18);
  // pto: %topk_scores__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v54 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v52, v53);
  // pto: %topk_indices__ssa_v0_view
  const int64_t v55 = 1;
  // pto: %topk_indices__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %topk_indices__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %topk_indices__ssa_v0_view
  int64_t v58 = (int64_t) v7;
  // pto: %topk_indices__ssa_v0_view
  int64_t v59 = v58 * v21;
  // pto: %topk_indices__ssa_v0_view
  int64_t v60 = v57 * v59;
  // pto: %topk_indices__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v61 = pto::Shape<1, 1, 1, -1, -1>(v55, v56, v57, v58, v21);
  // pto: %topk_indices__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v62 = pto::Stride<-1, -1, -1, -1, -1>(v56 * v60, v60, v59, v21, v18);
  // pto: %topk_indices__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v63 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v61, v62);
  // pto: %worker__ssa_v0
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t v64 = (int64_t) v9; v64 < v7; v64 += v22) {
    // pto: %position__tile
    ;
    int64_t v65 = (v1)[v64];
    // pto: %t__tile
    ;
    int32_t v66 = (v3)[v64];
    // pto: %0
    ;
    int64_t v67 = (int64_t) v66;
    // pto: %2
    ;
    int64_t v68 = v67 < v23 ? v23 : v67;
    // pto: %1
    ;
    int32_t v69 = (v2)[v68];
    // pto: %3
    ;
    int64_t v70 = (int64_t) v69;
    // pto: %4
    ;
    const int64_t v71 = 1;
    // pto: %4
    ;
    const int64_t v72 = 0;
    // pto: %4
    ;
    int64_t v73 = v70 / v24;
    // pto: %4
    ;
    bool v74 = v70 < v72;
    // pto: %4
    ;
    bool v75 = v24 < v72;
    // pto: %4
    ;
    bool v76 = v74 == v75;
    // pto: %4
    ;
    bool v77 = v70 % v24 != v72 && v74 != v75;
    // pto: %4
    ;
    int64_t v78 = v77 ? v73 - v71 : v73;
    // pto: %5, %cache_len__phi_v2
    ;
    int64_t v79 = v67 < v23 ? v23 : v78;
    // pto: %6
    ;
    int64_t v80 = (int64_t) ((uint64_t) v65 + (uint64_t) v25);
    // pto: %7
    ;
    const int64_t v81 = 1;
    // pto: %7
    ;
    const int64_t v82 = 0;
    // pto: %7
    ;
    int64_t v83 = v80 / v26;
    // pto: %7
    ;
    bool v84 = v80 < v82;
    // pto: %7
    ;
    bool v85 = v26 < v82;
    // pto: %7
    ;
    bool v86 = v84 == v85;
    // pto: %7
    ;
    bool v87 = v80 % v26 != v82 && v84 != v85;
    // pto: %7
    ;
    int64_t v88 = v87 ? v83 - v81 : v83;
    // pto: %9
    ;
    int64_t v89 = v79 < v88 ? v79 : v88;
    // pto: %10
    ;
    int64_t v90 = v89 < v23 ? v23 : v89;
    // pto: %11
    ;
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    if (v90 > v23) {
      // pto: %12
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
      pipe_barrier(PIPE_ALL);
      if (v90 <= v27) {
        // pto: %short_indices_inline7228__ci_tmp_v0
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v91 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v28);
        // pto: %short_indices_inline7228__ci_tmp_v0
        ;
        uint64_t v92 = (uint64_t) v12;
        TASSIGN(v91, v92);
        // pto: %short_indices_inline7228__ssa_v0
        ;
        Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v27);
        // pto: %short_indices_inline7228__ssa_v0
        ;
        uint64_t v94 = (uint64_t) v13;
        TASSIGN(v93, v94);
        // pto: %ci_tmp_view
        ;
        Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v95;
        TRESHAPE(v95, v91);
        // pto: %ci_dst_view
        ;
        Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v96;
        TRESHAPE(v96, v93);
        pipe_barrier(PIPE_ALL);
        pipe_barrier(PIPE_V);
        TCI<Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v96, v29, v95);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
        // pto: %short_raw_inline7229__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v90);
        // pto: %short_raw_inline7229__ssa_v0
        ;
        uint64_t v98 = (uint64_t) v12;
        TASSIGN(v97, v98);
        // pto: %13
        ;
        int64_t v99 = v64 < v23 ? v23 : v64;
        // pto: %score_arena__ssa_v0_pview
        ;
        const int64_t v100 = 0;
        // pto: %score_arena__ssa_v0_pview
        ;
        __gm__ float* v101 = PTOAS__GLOBAL_TENSOR_DATA(v45);
        // pto: %score_arena__ssa_v0_pview
        ;
        const int64_t v102 = 1;
        // pto: %score_arena__ssa_v0_pview
        ;
        const int64_t v103 = 1;
        // pto: %score_arena__ssa_v0_pview
        ;
        const int64_t v104 = 1;
        // pto: %score_arena__ssa_v0_pview
        ;
        int64_t v105 = v18 * v20;
        // pto: %score_arena__ssa_v0_pview
        ;
        int64_t v106 = v104 * v105;
        // pto: %score_arena__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, -1> v107 = pto::Shape<1, 1, 1, 1, -1>(v102, v103, v104, v18, v90);
        // pto: %score_arena__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v108 = pto::Stride<-1, -1, -1, -1, -1>(v103 * v106, v106, v105, v20, v18);
        // pto: %score_arena__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v109 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v101 + (v100 + v99 * v20 + v23 * v18), v107, v108);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
        TLOAD(v97, v109);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %short_scores_inline7230__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v110 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v27);
        // pto: %short_scores_inline7230__ssa_v0
        ;
        uint64_t v111 = (uint64_t) v12;
        TASSIGN(v110, v111);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        TFILLPAD<pto::TFillPadMode::InPlace>(v110, v97);
        // pto: %short_scores_v1_inline7231__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v112 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v27);
        // pto: %short_scores_v1_inline7231__ssa_v0
        ;
        uint64_t v113 = (uint64_t) v14;
        TASSIGN(v112, v113);
        pipe_barrier(PIPE_V);
        pipe_barrier(PIPE_ALL);
        TMAXS(v112, v110, v30);
        // pto: %t__tmp_v2
        ;
        Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v114 = Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v27);
        // pto: %t__tmp_v2
        ;
        uint64_t v115 = (uint64_t) v13;
        TASSIGN(v114, v115);
        // pto: %short_pairs_inline7232__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v116 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v31);
        // pto: %short_pairs_inline7232__ssa_v0
        ;
        uint64_t v117 = (uint64_t) v12;
        TASSIGN(v116, v117);
        // pto: %sort32_src_view
        ;
        Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v118;
        TRESHAPE(v118, v112);
        // pto: %sort32_idx_view
        ;
        Tile<TileType::Vec, uint32_t, 1, 2048, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v119;
        TRESHAPE(v119, v114);
        // pto: %sort32_dst_view
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v120;
        TRESHAPE(v120, v116);
        pipe_barrier(PIPE_V);
        TSORT32(v120, v118, v119);
        // pto: %short_pairs_v1_inline7233__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v121 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v31);
        // pto: %short_pairs_v1_inline7233__ssa_v0
        ;
        uint64_t v122 = (uint64_t) v13;
        TASSIGN(v121, v122);
        pipe_barrier(PIPE_V);
        TMRGSORT(v121, v116, v32);
        // pto: %short_pairs_v2_inline7234__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v123 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v31);
        // pto: %short_pairs_v2_inline7234__ssa_v0
        ;
        uint64_t v124 = (uint64_t) v12;
        TASSIGN(v123, v124);
        pipe_barrier(PIPE_V);
        TMRGSORT(v123, v121, v33);
        // pto: %short_pairs_v3_inline7235__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v125 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v31);
        // pto: %short_pairs_v3_inline7235__ssa_v0
        ;
        uint64_t v126 = (uint64_t) v13;
        TASSIGN(v125, v126);
        pipe_barrier(PIPE_V);
        TMRGSORT(v125, v123, v34);
        // pto: %short_top_inline7236__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v127 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v35);
        // pto: %short_top_inline7236__ssa_v0
        ;
        uint64_t v128 = (uint64_t) v13;
        TASSIGN(v127, v128);
        // pto: %slice_view
        ;
        Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v129;
        // pto: %slice_view
        ;
        uint64_t v130 = (uint64_t) v13;
        TASSIGN(v129, v130);
        // pto: %short_values_inline7237__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v131 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v21);
        // pto: %short_values_inline7237__ssa_v0
        ;
        uint64_t v132 = (uint64_t) v12;
        TASSIGN(v131, v132);
        pipe_barrier(PIPE_V);
        TGATHER<Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, MaskPattern::P0101>(v131, v129);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %short_selected_inline7238__ssa_v0
        ;
        Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v133 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v21);
        // pto: %short_selected_inline7238__ssa_v0
        ;
        uint64_t v134 = (uint64_t) v14;
        TASSIGN(v133, v134);
        TGATHER<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, MaskPattern::P1010>(v133, v129);
        set_flag(PIPE_V, PIPE_S, EVENT_ID0);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        // pto: %topk_scores__ssa_v0_pview
        ;
        __gm__ float* v135 = PTOAS__GLOBAL_TENSOR_DATA(v54);
        // pto: %topk_scores__ssa_v0_pview
        ;
        const int64_t v136 = 0;
        // pto: %topk_scores__ssa_v0_pview
        ;
        const int64_t v137 = 512;
        // pto: %topk_scores__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 512> v138 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %topk_scores__ssa_v0_pview
        ;
        pto::Stride<512, 512, 512, 512, 1> v139 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %topk_scores__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v140 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v135 + (v136 + v99 * v137), v138, v139);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v140, v131);
        // pto: %15
        ;
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        pipe_barrier(PIPE_ALL);
        wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
        if (v90 >= v21) {
          // pto: %topk_indices__ssa_v0_pview
          ;
          __gm__ int32_t* v141 = PTOAS__GLOBAL_TENSOR_DATA(v63);
          // pto: %topk_indices__ssa_v0_pview
          ;
          const int64_t v142 = 0;
          // pto: %topk_indices__ssa_v0_pview
          ;
          const int64_t v143 = 512;
          // pto: %topk_indices__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 1, 512> v144 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %topk_indices__ssa_v0_pview
          ;
          pto::Stride<512, 512, 512, 512, 1> v145 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %topk_indices__ssa_v0_pview
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v146 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v141 + (v142 + v99 * v143), v144, v145);
          TSTORE(v146, v133);
        } else {
          // pto: %short_output_inline7239__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v21);
          // pto: %short_output_inline7239__ssa_v0
          ;
          uint64_t v148 = (uint64_t) v12;
          TASSIGN(v147, v148);
          TEXPANDS(v147, v36);
          set_flag(PIPE_V, PIPE_S, EVENT_ID1);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
          for (int64_t v149 = v23; v149 < v90; v149 += v18) {
            // pto: %t__tmp_v3
            ;
            int32_t v150 = v133.GetValue(v149);
            v147.SetValue(v149, v150);
          };
          set_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
          // pto: %20
          ;
          __gm__ int32_t* v151 = PTOAS__GLOBAL_TENSOR_DATA(v63);
          // pto: %20
          ;
          const int64_t v152 = 0;
          // pto: %20
          ;
          const int64_t v153 = 512;
          // pto: %20
          ;
          pto::Shape<1, 1, 1, 1, 512> v154 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %20
          ;
          pto::Stride<512, 512, 512, 512, 1> v155 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %20
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v156 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v151 + (v152 + v99 * v153), v154, v155);
          wait_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          TSTORE(v156, v147);
        };
      } else {
        // pto: %21
        ;
        pipe_barrier(PIPE_ALL);
        if (v90 <= v31) {
          // pto: %medium_indices_inline7241__ci_tmp_v1
          ;
          Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v28);
          // pto: %medium_indices_inline7241__ci_tmp_v1
          ;
          uint64_t v158 = (uint64_t) v12;
          TASSIGN(v157, v158);
          // pto: %medium_indices_inline7241__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v159 = Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v31);
          // pto: %medium_indices_inline7241__ssa_v0
          ;
          uint64_t v160 = (uint64_t) v13;
          TASSIGN(v159, v160);
          // pto: %22
          ;
          Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v161;
          TRESHAPE(v161, v157);
          // pto: %23
          ;
          Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v162;
          TRESHAPE(v162, v159);
          pipe_barrier(PIPE_V);
          pipe_barrier(PIPE_ALL);
          TCI<Tile<TileType::Vec, int32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v162, v29, v161);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          // pto: %medium_raw_inline7242__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v163 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v90);
          // pto: %medium_raw_inline7242__ssa_v0
          ;
          uint64_t v164 = (uint64_t) v12;
          TASSIGN(v163, v164);
          // pto: %24
          ;
          int64_t v165 = v64 < v23 ? v23 : v64;
          // pto: %25
          ;
          const int64_t v166 = 0;
          // pto: %25
          ;
          __gm__ float* v167 = PTOAS__GLOBAL_TENSOR_DATA(v45);
          // pto: %25
          ;
          const int64_t v168 = 1;
          // pto: %25
          ;
          const int64_t v169 = 1;
          // pto: %25
          ;
          const int64_t v170 = 1;
          // pto: %25
          ;
          int64_t v171 = v18 * v20;
          // pto: %25
          ;
          int64_t v172 = v170 * v171;
          // pto: %25
          ;
          pto::Shape<1, 1, 1, 1, -1> v173 = pto::Shape<1, 1, 1, 1, -1>(v168, v169, v170, v18, v90);
          // pto: %25
          ;
          pto::Stride<-1, -1, -1, -1, -1> v174 = pto::Stride<-1, -1, -1, -1, -1>(v169 * v172, v172, v171, v20, v18);
          // pto: %25
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v175 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v167 + (v166 + v165 * v20 + v23 * v18), v173, v174);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          TLOAD(v163, v175);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          // pto: %medium_scores_inline7243__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v176 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v31);
          // pto: %medium_scores_inline7243__ssa_v0
          ;
          uint64_t v177 = (uint64_t) v12;
          TASSIGN(v176, v177);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          TFILLPAD<pto::TFillPadMode::InPlace>(v176, v163);
          // pto: %medium_scores_v1_inline7244__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v178 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v31);
          // pto: %medium_scores_v1_inline7244__ssa_v0
          ;
          uint64_t v179 = (uint64_t) v14;
          TASSIGN(v178, v179);
          pipe_barrier(PIPE_V);
          TMAXS(v178, v176, v30);
          // pto: %t__tmp_v4
          ;
          Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v180 = Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v31);
          // pto: %t__tmp_v4
          ;
          uint64_t v181 = (uint64_t) v13;
          TASSIGN(v180, v181);
          // pto: %medium_pairs_inline7245__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v182 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v20);
          // pto: %medium_pairs_inline7245__ssa_v0
          ;
          uint64_t v183 = (uint64_t) v12;
          TASSIGN(v182, v183);
          // pto: %26
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v184;
          TRESHAPE(v184, v178);
          // pto: %27
          ;
          Tile<TileType::Vec, uint32_t, 1, 4096, BLayout::RowMajor, 1, 4096, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v185;
          TRESHAPE(v185, v180);
          // pto: %28
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 8192, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v186;
          TRESHAPE(v186, v182);
          pipe_barrier(PIPE_V);
          TSORT32(v186, v184, v185);
          // pto: %medium_pairs_v1_inline7246__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v187 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v20);
          // pto: %medium_pairs_v1_inline7246__ssa_v0
          ;
          uint64_t v188 = (uint64_t) v13;
          TASSIGN(v187, v188);
          pipe_barrier(PIPE_V);
          TMRGSORT(v187, v182, v32);
          // pto: %medium_pairs_v2_inline7247__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v189 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v20);
          // pto: %medium_pairs_v2_inline7247__ssa_v0
          ;
          uint64_t v190 = (uint64_t) v12;
          TASSIGN(v189, v190);
          pipe_barrier(PIPE_V);
          TMRGSORT(v189, v187, v33);
          // pto: %medium_pairs_v3_inline7248__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v191 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v20);
          // pto: %medium_pairs_v3_inline7248__ssa_v0
          ;
          uint64_t v192 = (uint64_t) v13;
          TASSIGN(v191, v192);
          pipe_barrier(PIPE_V);
          TMRGSORT(v191, v189, v34);
          // pto: %medium_left_inline7249__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v193 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v35);
          // pto: %medium_left_inline7249__ssa_v0
          ;
          uint64_t v194 = (uint64_t) v13;
          TASSIGN(v193, v194);
          // pto: %29
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v195;
          // pto: %29
          ;
          uint64_t v196 = (uint64_t) v13;
          TASSIGN(v195, v196);
          // pto: %medium_right_inline7250__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v197 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v35);
          // pto: %medium_right_inline7250__ssa_v0
          ;
          uint64_t v198 = (uint64_t) v15;
          TASSIGN(v197, v198);
          // pto: %30
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v199;
          // pto: %30
          ;
          uint64_t v200 = (uint64_t) v15;
          TASSIGN(v199, v200);
          // pto: %medium_tmp_inline7251__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v201 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v27);
          // pto: %medium_tmp_inline7251__ssa_v0
          ;
          uint64_t v202 = (uint64_t) v12;
          TASSIGN(v201, v202);
          // pto: %medium_merged_inline7252__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v203 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v27);
          // pto: %medium_merged_inline7252__ssa_v0
          ;
          uint64_t v204 = (uint64_t) v14;
          TASSIGN(v203, v204);
          pipe_barrier(PIPE_V);
          TMRGSORT<Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v203, v11, v201, v199, v195);
          // pto: %medium_top_inline7253__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v205 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v35);
          // pto: %medium_top_inline7253__ssa_v0
          ;
          uint64_t v206 = (uint64_t) v14;
          TASSIGN(v205, v206);
          // pto: %31
          ;
          Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v207;
          // pto: %31
          ;
          uint64_t v208 = (uint64_t) v14;
          TASSIGN(v207, v208);
          // pto: %medium_values_inline7254__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v209 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v21);
          // pto: %medium_values_inline7254__ssa_v0
          ;
          uint64_t v210 = (uint64_t) v12;
          TASSIGN(v209, v210);
          pipe_barrier(PIPE_V);
          TGATHER<Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, MaskPattern::P0101>(v209, v207);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
          // pto: %medium_selected_inline7255__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v211 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v21);
          // pto: %medium_selected_inline7255__ssa_v0
          ;
          uint64_t v212 = (uint64_t) v13;
          TASSIGN(v211, v212);
          TGATHER<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, MaskPattern::P1010>(v211, v207);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
          // pto: %33
          ;
          __gm__ float* v213 = PTOAS__GLOBAL_TENSOR_DATA(v54);
          // pto: %33
          ;
          const int64_t v214 = 0;
          // pto: %33
          ;
          const int64_t v215 = 512;
          // pto: %33
          ;
          pto::Shape<1, 1, 1, 1, 512> v216 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %33
          ;
          pto::Stride<512, 512, 512, 512, 1> v217 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %33
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v218 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v213 + (v214 + v165 * v215), v216, v217);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
          TSTORE(v218, v209);
          // pto: %35
          ;
          __gm__ int32_t* v219 = PTOAS__GLOBAL_TENSOR_DATA(v63);
          // pto: %35
          ;
          const int64_t v220 = 0;
          // pto: %35
          ;
          const int64_t v221 = 512;
          // pto: %35
          ;
          pto::Shape<1, 1, 1, 1, 512> v222 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %35
          ;
          pto::Stride<512, 512, 512, 512, 1> v223 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %35
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v224 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v219 + (v220 + v165 * v221), v222, v223);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
          TSTORE(v224, v211);
        } else {
          // pto: %full_indices_inline7256__ci_tmp_v2
          ;
          Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v225 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v28);
          // pto: %full_indices_inline7256__ci_tmp_v2
          ;
          uint64_t v226 = (uint64_t) v12;
          TASSIGN(v225, v226);
          // pto: %full_indices_inline7256__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v227 = Tile<TileType::Vec, int32_t, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v20);
          // pto: %full_indices_inline7256__ssa_v0
          ;
          uint64_t v228 = (uint64_t) v13;
          TASSIGN(v227, v228);
          // pto: %36
          ;
          Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v229;
          TRESHAPE(v229, v225);
          // pto: %37
          ;
          Tile<TileType::Vec, int32_t, 1, 8192, BLayout::RowMajor, 1, 8192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v230;
          TRESHAPE(v230, v227);
          pipe_barrier(PIPE_V);
          pipe_barrier(PIPE_ALL);
          TCI<Tile<TileType::Vec, int32_t, 1, 8192, BLayout::RowMajor, 1, 8192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v230, v29, v229);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
          // pto: %full_raw_inline7257__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v231 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v90);
          // pto: %full_raw_inline7257__ssa_v0
          ;
          uint64_t v232 = (uint64_t) v12;
          TASSIGN(v231, v232);
          // pto: %38
          ;
          int64_t v233 = v64 < v23 ? v23 : v64;
          // pto: %39
          ;
          const int64_t v234 = 0;
          // pto: %39
          ;
          __gm__ float* v235 = PTOAS__GLOBAL_TENSOR_DATA(v45);
          // pto: %39
          ;
          const int64_t v236 = 1;
          // pto: %39
          ;
          const int64_t v237 = 1;
          // pto: %39
          ;
          const int64_t v238 = 1;
          // pto: %39
          ;
          int64_t v239 = v18 * v20;
          // pto: %39
          ;
          int64_t v240 = v238 * v239;
          // pto: %39
          ;
          pto::Shape<1, 1, 1, 1, -1> v241 = pto::Shape<1, 1, 1, 1, -1>(v236, v237, v238, v18, v90);
          // pto: %39
          ;
          pto::Stride<-1, -1, -1, -1, -1> v242 = pto::Stride<-1, -1, -1, -1, -1>(v237 * v240, v240, v239, v20, v18);
          // pto: %39
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v243 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v235 + (v234 + v233 * v20 + v23 * v18), v241, v242);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
          TLOAD(v231, v243);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          // pto: %full_scores_inline7258__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v244 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v20);
          // pto: %full_scores_inline7258__ssa_v0
          ;
          uint64_t v245 = (uint64_t) v12;
          TASSIGN(v244, v245);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          TFILLPAD<pto::TFillPadMode::InPlace>(v244, v231);
          // pto: %full_min_inline7259__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v20);
          // pto: %full_min_inline7259__ssa_v0
          ;
          uint64_t v247 = (uint64_t) v14;
          TASSIGN(v246, v247);
          TEXPANDS(v246, v30);
          // pto: %full_scores_v1_inline7260__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v248 = Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v20);
          // pto: %full_scores_v1_inline7260__ssa_v0
          ;
          uint64_t v249 = (uint64_t) v14;
          TASSIGN(v248, v249);
          pipe_barrier(PIPE_V);
          TMAX(v248, v244, v246);
          // pto: %t__tmp_v5
          ;
          Tile<TileType::Vec, uint32_t, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v250 = Tile<TileType::Vec, uint32_t, 1, 8192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v20);
          // pto: %t__tmp_v5
          ;
          uint64_t v251 = (uint64_t) v13;
          TASSIGN(v250, v251);
          // pto: %full_pairs_inline7261__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v252 = Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v37);
          // pto: %full_pairs_inline7261__ssa_v0
          ;
          uint64_t v253 = (uint64_t) v12;
          TASSIGN(v252, v253);
          // pto: %40
          ;
          Tile<TileType::Vec, float, 1, 8192, BLayout::RowMajor, 1, 8192, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v254;
          TRESHAPE(v254, v248);
          // pto: %41
          ;
          Tile<TileType::Vec, uint32_t, 1, 8192, BLayout::RowMajor, 1, 8192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v255;
          TRESHAPE(v255, v250);
          // pto: %42
          ;
          Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, 1, 16384, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v256;
          TRESHAPE(v256, v252);
          pipe_barrier(PIPE_V);
          TSORT32(v256, v254, v255);
          // pto: %full_pairs_v1_inline7262__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v257 = Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v37);
          // pto: %full_pairs_v1_inline7262__ssa_v0
          ;
          uint64_t v258 = (uint64_t) v13;
          TASSIGN(v257, v258);
          pipe_barrier(PIPE_V);
          TMRGSORT(v257, v252, v32);
          // pto: %full_pairs_v2_inline7263__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v259 = Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v37);
          // pto: %full_pairs_v2_inline7263__ssa_v0
          ;
          uint64_t v260 = (uint64_t) v12;
          TASSIGN(v259, v260);
          pipe_barrier(PIPE_V);
          TMRGSORT(v259, v257, v33);
          // pto: %full_pairs_v3_inline7264__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v261 = Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v37);
          // pto: %full_pairs_v3_inline7264__ssa_v0
          ;
          uint64_t v262 = (uint64_t) v13;
          TASSIGN(v261, v262);
          pipe_barrier(PIPE_V);
          TMRGSORT(v261, v259, v34);
          // pto: %full_first_inline7265__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v263 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v35);
          // pto: %full_first_inline7265__ssa_v0
          ;
          uint64_t v264 = (uint64_t) v13;
          TASSIGN(v263, v264);
          // pto: %43
          ;
          Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v265;
          // pto: %43
          ;
          uint64_t v266 = (uint64_t) v13;
          TASSIGN(v265, v266);
          // pto: %full_second_inline7266__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v267 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v35);
          // pto: %full_second_inline7266__ssa_v0
          ;
          uint64_t v268 = (uint64_t) v15;
          TASSIGN(v267, v268);
          // pto: %44
          ;
          Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v269;
          // pto: %44
          ;
          uint64_t v270 = (uint64_t) v15;
          TASSIGN(v269, v270);
          // pto: %full_third_inline7267__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v271 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v35);
          // pto: %full_third_inline7267__ssa_v0
          ;
          uint64_t v272 = (uint64_t) v16;
          TASSIGN(v271, v272);
          // pto: %45
          ;
          Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v273;
          // pto: %45
          ;
          uint64_t v274 = (uint64_t) v16;
          TASSIGN(v273, v274);
          // pto: %full_fourth_inline7268__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v275 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v35);
          // pto: %full_fourth_inline7268__ssa_v0
          ;
          uint64_t v276 = (uint64_t) v17;
          TASSIGN(v275, v276);
          // pto: %46
          ;
          Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v277;
          // pto: %46
          ;
          uint64_t v278 = (uint64_t) v17;
          TASSIGN(v277, v278);
          // pto: %full_tmp_inline7269__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v31);
          // pto: %full_tmp_inline7269__ssa_v0
          ;
          uint64_t v280 = (uint64_t) v12;
          TASSIGN(v279, v280);
          // pto: %full_merged_inline7270__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v281 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v31);
          // pto: %full_merged_inline7270__ssa_v0
          ;
          uint64_t v282 = (uint64_t) v14;
          TASSIGN(v281, v282);
          pipe_barrier(PIPE_V);
          TMRGSORT<Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 16384, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, false>(v281, v11, v279, v277, v273, v269, v265);
          // pto: %full_top_inline7271__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v283 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v35);
          // pto: %full_top_inline7271__ssa_v0
          ;
          uint64_t v284 = (uint64_t) v14;
          TASSIGN(v283, v284);
          // pto: %48
          ;
          Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v285;
          // pto: %48
          ;
          uint64_t v286 = (uint64_t) v14;
          TASSIGN(v285, v286);
          // pto: %full_values_inline7272__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v287 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v21);
          // pto: %full_values_inline7272__ssa_v0
          ;
          uint64_t v288 = (uint64_t) v12;
          TASSIGN(v287, v288);
          pipe_barrier(PIPE_V);
          TGATHER<Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, MaskPattern::P0101>(v287, v285);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
          // pto: %full_selected_inline7273__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v289 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v18, v21);
          // pto: %full_selected_inline7273__ssa_v0
          ;
          uint64_t v290 = (uint64_t) v13;
          TASSIGN(v289, v290);
          TGATHER<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>, MaskPattern::P1010>(v289, v285);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
          // pto: %50
          ;
          __gm__ float* v291 = PTOAS__GLOBAL_TENSOR_DATA(v54);
          // pto: %50
          ;
          const int64_t v292 = 0;
          // pto: %50
          ;
          const int64_t v293 = 512;
          // pto: %50
          ;
          pto::Shape<1, 1, 1, 1, 512> v294 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %50
          ;
          pto::Stride<512, 512, 512, 512, 1> v295 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %50
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v296 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v291 + (v292 + v233 * v293), v294, v295);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
          TSTORE(v296, v287);
          // pto: %52
          ;
          __gm__ int32_t* v297 = PTOAS__GLOBAL_TENSOR_DATA(v63);
          // pto: %52
          ;
          const int64_t v298 = 0;
          // pto: %52
          ;
          const int64_t v299 = 512;
          // pto: %52
          ;
          pto::Shape<1, 1, 1, 1, 512> v300 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %52
          ;
          pto::Stride<512, 512, 512, 512, 1> v301 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %52
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v302 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v297 + (v298 + v233 * v299), v300, v301);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
          TSTORE(v302, v289);
        };
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
    } else {
      // pto: %t__tmp_v6
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v21);
      // pto: %t__tmp_v6
      ;
      uint64_t v304 = (uint64_t) v12;
      TASSIGN(v303, v304);
      pipe_barrier(PIPE_ALL);
      TEXPANDS(v303, v30);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
      // pto: %53
      ;
      int64_t v305 = v64 < v23 ? v23 : v64;
      // pto: %54
      ;
      __gm__ float* v306 = PTOAS__GLOBAL_TENSOR_DATA(v54);
      // pto: %54
      ;
      const int64_t v307 = 0;
      // pto: %54
      ;
      const int64_t v308 = 512;
      // pto: %54
      ;
      pto::Shape<1, 1, 1, 1, 512> v309 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %54
      ;
      pto::Stride<512, 512, 512, 512, 1> v310 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %54
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v311 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v306 + (v307 + v305 * v308), v309, v310);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
      TSTORE(v311, v303);
      // pto: %t__tmp_v7
      ;
      Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v18, v21);
      // pto: %t__tmp_v7
      ;
      uint64_t v313 = (uint64_t) v12;
      TASSIGN(v312, v313);
      pipe_barrier(PIPE_ALL);
      TEXPANDS(v312, v36);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %56
      ;
      __gm__ int32_t* v314 = PTOAS__GLOBAL_TENSOR_DATA(v63);
      // pto: %56
      ;
      const int64_t v315 = 0;
      // pto: %56
      ;
      const int64_t v316 = 512;
      // pto: %56
      ;
      pto::Shape<1, 1, 1, 1, 512> v317 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %56
      ;
      pto::Stride<512, 512, 512, 512, 1> v318 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %56
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v319 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v314 + (v315 + v305 * v316), v317, v318);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v319, v312);
    };
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}