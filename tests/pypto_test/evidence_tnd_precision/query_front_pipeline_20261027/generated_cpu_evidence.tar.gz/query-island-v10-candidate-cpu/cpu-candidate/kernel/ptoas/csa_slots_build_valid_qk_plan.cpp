#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void csa_slots_build_valid_qk_plan(__gm__ float* v1, __gm__ int32_t* v2, __gm__ int64_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, __gm__ int32_t* v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int64_t v12, int32_t v13, int32_t v14) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c1536_i64
  const int64_t v15 = 1536;
  // pto: %c17920_i64
  const int64_t v16 = 17920;
  // pto: %c0_i64
  const int64_t v17 = 0;
  // pto: %c512_i64
  const int64_t v18 = 512;
  // pto: %c1024_i64
  const int64_t v19 = 1024;
  // pto: %c1024_index
  const int64_t v20 = 1024;
  // pto: %c1_index
  const int64_t v21 = 1;
  // pto: %c512_index
  const int64_t v22 = 512;
  // pto: %c16_index
  const int64_t v23 = 16;
  // pto: %c8_index
  const int64_t v24 = 8;
  // pto: %c256_index
  const int64_t v25 = 256;
  // pto: %c0_index
  const int64_t v26 = 0;
  // pto: %c128_index
  const int64_t v27 = 128;
  // pto: %c32_index
  const int64_t v28 = 32;
  // pto: %c192_index
  const int64_t v29 = 192;
  // pto: %c0_i32
  const int32_t v30 = 0;
  // pto: %cst_16
  const float v31 = 0.0f;
  // pto: %c5_index
  const int64_t v32 = 5;
  // pto: %c1_i32
  const int32_t v33 = 1;
  // pto: %cst_19
  const float v34 = 1.0f;
  // pto: %cst_20
  const float v35 = 1.00000002E+20f;
  // pto: %c384_index
  const int64_t v36 = 384;
  // pto: %cst_22
  const float v37 = -1.00000002E+20f;
  // pto: %sparse_bias_inline5289__ssa_v0_view
  const int64_t v38 = 1;
  // pto: %sparse_bias_inline5289__ssa_v0_view
  const int64_t v39 = 1;
  // pto: %sparse_bias_inline5289__ssa_v0_view
  const int64_t v40 = 1;
  // pto: %sparse_bias_inline5289__ssa_v0_view
  int64_t v41 = (int64_t) v9;
  // pto: %sparse_bias_inline5289__ssa_v0_view
  int64_t v42 = v41 * v20;
  // pto: %sparse_bias_inline5289__ssa_v0_view
  int64_t v43 = v40 * v42;
  // pto: %sparse_bias_inline5289__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v44 = pto::Shape<1, 1, 1, -1, -1>(v38, v39, v40, v41, v20);
  // pto: %sparse_bias_inline5289__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v45 = pto::Stride<-1, -1, -1, -1, -1>(v39 * v43, v43, v42, v20, v21);
  // pto: %sparse_bias_inline5289__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v46 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v44, v45);
  // pto: %cmp_sparse_indices_inline5291__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %cmp_sparse_indices_inline5291__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %cmp_sparse_indices_inline5291__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %cmp_sparse_indices_inline5291__ssa_v0_view
  int64_t v50 = (int64_t) v9;
  // pto: %cmp_sparse_indices_inline5291__ssa_v0_view
  int64_t v51 = v50 * v22;
  // pto: %cmp_sparse_indices_inline5291__ssa_v0_view
  int64_t v52 = v49 * v51;
  // pto: %cmp_sparse_indices_inline5291__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v47, v48, v49, v50, v22);
  // pto: %cmp_sparse_indices_inline5291__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v48 * v52, v52, v51, v22, v21);
  // pto: %cmp_sparse_indices_inline5291__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v53, v54);
  // pto: %v_valid_inline5341__phi_v5
  Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v56 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
  // pto: %v_valid_inline5341__phi_v5
  uint64_t v57 = (uint64_t) v17;
  TASSIGN(v56, v57);
  // pto: %v_valid_inline5341__phi_v4
  Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v58 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
  // pto: %v_valid_inline5341__phi_v4
  uint64_t v59 = (uint64_t) v17;
  TASSIGN(v58, v59);
  // pto: %plan_worker_inline5330__ssa_v0, %14
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v60 = (int64_t) ((uint64_t) ((int64_t) v13) * (uint64_t) v24); v60 < v9; v60 += v25) {
    // pto: %15
    ;
    int64_t v61 = (int64_t) ((uint64_t) v9 - (uint64_t) v60);
    // pto: %16
    ;
    int64_t v62 = v61 < v24 ? v61 : v24;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    for (int64_t v63 = v26; v63 < v62; v63 += v21) {
      // pto: %17
      ;
      int64_t v64 = (int64_t) ((uint64_t) v60 + (uint64_t) v63);
      // pto: %18
      ;
      int32_t v65 = (v2)[v64];
      // pto: %19
      ;
      int64_t v66 = (int64_t) v65;
      // pto: %20
      ;
      int64_t v67 = v66 < v26 ? v26 : v66;
      // pto: %21
      ;
      int64_t v68 = (v3)[v64];
      // pto: %t__tile
      ;
      Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v69 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %t__tile
      ;
      uint64_t v70 = (uint64_t) v15;
      TASSIGN(v69, v70);
      // pto: %23
      ;
      int64_t v71 = v64 < v26 ? v26 : v64;
      // pto: %cmp_sparse_indices_inline5291__ssa_v0_pview
      ;
      __gm__ int32_t* v72 = PTOAS__GLOBAL_TENSOR_DATA(v55);
      // pto: %cmp_sparse_indices_inline5291__ssa_v0_pview
      ;
      const int64_t v73 = 0;
      // pto: %cmp_sparse_indices_inline5291__ssa_v0_pview
      ;
      const int64_t v74 = 512;
      // pto: %cmp_sparse_indices_inline5291__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v75 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %cmp_sparse_indices_inline5291__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 512, 1> v76 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %cmp_sparse_indices_inline5291__ssa_v0_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v77 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v72 + (v73 + v71 * v74), v75, v76);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      TLOAD(v69, v77);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %c_out_inline5336__tile
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v78 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %c_out_inline5336__tile
      ;
      uint64_t v79 = (uint64_t) v15;
      TASSIGN(v78, v79);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      RoundMode v80 = RoundMode::CAST_ROUND;
      SaturationMode v81 = SaturationMode::ON;
      TCVT(v78, v69, v80, v81);
      // pto: %24
      ;
      int64_t v82 = (int64_t) ((uint64_t) v68 + (uint64_t) v21);
      // pto: %25
      ;
      int64_t v83 = v82 < v27 ? v82 : v27;
      // pto: %26
      ;
      int32_t v84 = (v2)[v64];
      // pto: %27
      ;
      int32_t v85 = (v5)[v67];
      // pto: %28, %29, %30, %31, %32
      ;
      bool v86 = (int64_t) v84 < v26 | (int64_t) v85 <= v26;
      // pto: %v_length_inline5337__phi_v2
      ;
      int64_t v87 = v86 ? v26 : v83;
      // pto: %33, %34
      ;
      int64_t v88 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v68 - (uint64_t) v87) + (uint64_t) v21);
      // pto: %35
      ;
      int64_t v89 = v88 % v28;
      // pto: %36, %37, %38
      ;
      int64_t v90 = v89 < v26 ? (int64_t) ((uint64_t) v89 + (uint64_t) v28) : v89;
      // pto: %t__ci_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v91 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v29);
      // pto: %t__ci_tmp_v0
      ;
      uint64_t v92 = (uint64_t) v16;
      TASSIGN(v91, v92);
      // pto: %0
      ;
      Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v93 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
      // pto: %0
      ;
      uint64_t v94 = (uint64_t) v17;
      TASSIGN(v93, v94);
      // pto: %ci_tmp_view
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v95;
      TRESHAPE(v95, v91);
      // pto: %ci_dst_view
      ;
      Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v96;
      TRESHAPE(v96, v93);
      TCI<Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v96, v30, v95);
      // pto: %v_columns_inline5340__tile
      ;
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v97 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
      // pto: %v_columns_inline5340__tile
      ;
      uint64_t v98 = (uint64_t) v16;
      TASSIGN(v97, v98);
      pipe_barrier(PIPE_V);
      RoundMode v99 = RoundMode::CAST_ROUND;
      SaturationMode v100 = SaturationMode::ON;
      TCVT(v97, v93, v99, v100);
      // pto: %v_valid_inline5341__tile
      ;
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v101 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
      // pto: %v_valid_inline5341__tile
      ;
      uint64_t v102 = (uint64_t) v17;
      TASSIGN(v101, v102);
      pipe_barrier(PIPE_V);
      TEXPANDS(v101, v31);
      // pto: %v_block_valid_inline5342__rv_v2
      ;
      int32_t v103;
      v103 = v30;
      for (int64_t v104 = v26; v104 < v32; v104 += v21) {
        // pto: %39, %40
        ;
        int64_t v105 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v104 * (uint64_t) v28) - (uint64_t) v90);
        // pto: %41
        ;
        int64_t v106 = v105 < v26 ? v26 : v105;
        // pto: %44
        ;
        int64_t v107 = (int64_t) ((uint64_t) v105 + (uint64_t) v28);
        // pto: %45
        ;
        int64_t v108 = v107 < v87 ? v107 : v87;
        // pto: %46
        ;
        // pto: %v_block_valid_inline5342__phi_v5
        ;
        int32_t v109;
        if (v106 < v108) {
          // pto: %47
          ;
          int64_t v110 = (int64_t) ((uint64_t) v88 + (uint64_t) v106);
          // pto: %48
          ;
          const int64_t v111 = 1;
          // pto: %48
          ;
          const int64_t v112 = 0;
          // pto: %48
          ;
          int64_t v113 = v110 / v28;
          // pto: %48
          ;
          bool v114 = v110 < v112;
          // pto: %48
          ;
          bool v115 = v28 < v112;
          // pto: %48
          ;
          bool v116 = v114 == v115;
          // pto: %48
          ;
          bool v117 = v110 % v28 != v112 && v114 != v115;
          // pto: %48
          ;
          int64_t v118 = v117 ? v113 - v111 : v113;
          // pto: %49, %50, %v_page_inline5346__tile
          ;
          int32_t v119 = (v6)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v67 * (uint64_t) v12) + (uint64_t) v118)];
          // pto: %51, %52
          ;
          bool v120 = (int64_t) v119 >= v26;
          // pto: %v_block_valid_inline5342__phi_v4
          ;
          int32_t v121 = v120 ? v33 : v103;
          if (v120) {
            // pto: %53, %54
            ;
            float v122 = (float) ((int32_t) v106);
            // pto: %55, %56
            ;
            float v123 = (float) ((int32_t) v108);
            // pto: %1
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v124 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
            // pto: %1
            ;
            uint64_t v125 = (uint64_t) v18;
            TASSIGN(v124, v125);
            pipe_barrier(PIPE_V);
            TSUBS(v124, v97, v122);
            // pto: %2
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v126 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
            // pto: %2
            ;
            uint64_t v127 = (uint64_t) v18;
            TASSIGN(v126, v127);
            pipe_barrier(PIPE_V);
            TADDS(v126, v124, v34);
            // pto: %3
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v128 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
            // pto: %3
            ;
            uint64_t v129 = (uint64_t) v18;
            TASSIGN(v128, v129);
            pipe_barrier(PIPE_V);
            TMAXS(v128, v126, v31);
            // pto: %v_ge_inline5349__tile
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v130 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
            // pto: %v_ge_inline5349__tile
            ;
            uint64_t v131 = (uint64_t) v18;
            TASSIGN(v130, v131);
            pipe_barrier(PIPE_V);
            TMINS(v130, v128, v34);
            // pto: %4
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v132 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
            // pto: %4
            ;
            uint64_t v133 = (uint64_t) v19;
            TASSIGN(v132, v133);
            TNEG(v132, v97);
            // pto: %5
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v134 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
            // pto: %5
            ;
            uint64_t v135 = (uint64_t) v19;
            TASSIGN(v134, v135);
            pipe_barrier(PIPE_V);
            TADDS(v134, v132, v123);
            // pto: %6
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v136 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
            // pto: %6
            ;
            uint64_t v137 = (uint64_t) v19;
            TASSIGN(v136, v137);
            pipe_barrier(PIPE_V);
            TMAXS(v136, v134, v31);
            // pto: %v_lt_inline5350__tile
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v138 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
            // pto: %v_lt_inline5350__tile
            ;
            uint64_t v139 = (uint64_t) v19;
            TASSIGN(v138, v139);
            pipe_barrier(PIPE_V);
            TMINS(v138, v136, v34);
            // pto: %7
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v140 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
            // pto: %7
            ;
            uint64_t v141 = (uint64_t) v18;
            TASSIGN(v140, v141);
            pipe_barrier(PIPE_V);
            TMUL(v140, v130, v138);
            // pto: %8
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v142 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
            // pto: %8
            ;
            uint64_t v143 = (uint64_t) v17;
            TASSIGN(v142, v143);
            pipe_barrier(PIPE_V);
            TADD(v142, v101, v140);
          };
          v109 = v121;
        } else {
          v109 = v103;
        };
        v103 = v109;
      };
      // pto: %57
      ;
      int64_t v144 = (int64_t) ((uint64_t) v64 * (uint64_t) v23);
      (v7)[v144] = v103;
      // pto: %9
      ;
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
      // pto: %9
      ;
      uint64_t v146 = (uint64_t) v16;
      TASSIGN(v145, v146);
      pipe_barrier(PIPE_V);
      TSUBS(v145, v101, v34);
      // pto: %10
      ;
      Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v27);
      // pto: %10
      ;
      uint64_t v148 = (uint64_t) v16;
      TASSIGN(v147, v148);
      pipe_barrier(PIPE_V);
      TMULS(v147, v145, v35);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      // pto: %sparse_bias_inline5289__iter_v3_pview
      ;
      __gm__ float* v149 = PTOAS__GLOBAL_TENSOR_DATA(v46);
      // pto: %sparse_bias_inline5289__iter_v3_pview
      ;
      const int64_t v150 = 0;
      // pto: %sparse_bias_inline5289__iter_v3_pview
      ;
      const int64_t v151 = 1024;
      // pto: %sparse_bias_inline5289__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 1, 128> v152 = pto::Shape<1, 1, 1, 1, 128>();
      // pto: %sparse_bias_inline5289__iter_v3_pview
      ;
      pto::Stride<1024, 1024, 1024, 1024, 1> v153 = pto::Stride<1024, 1024, 1024, 1024, 1>();
      // pto: %sparse_bias_inline5289__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v154 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v149 + (v150 + v71 * v151), v152, v153);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      TSTORE(v154, v147);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      // pto: %11
      ;
      Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Vec, float, 1, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v36);
      // pto: %11
      ;
      uint64_t v156 = (uint64_t) v16;
      TASSIGN(v155, v156);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      TEXPANDS(v155, v37);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      // pto: %sparse_bias_inline5289__tile_pview
      ;
      __gm__ float* v157 = PTOAS__GLOBAL_TENSOR_DATA(v46);
      // pto: %sparse_bias_inline5289__tile_pview
      ;
      const int64_t v158 = 128;
      // pto: %sparse_bias_inline5289__tile_pview
      ;
      const int64_t v159 = 1024;
      // pto: %sparse_bias_inline5289__tile_pview
      ;
      pto::Shape<1, 1, 1, 1, 384> v160 = pto::Shape<1, 1, 1, 1, 384>();
      // pto: %sparse_bias_inline5289__tile_pview
      ;
      pto::Stride<1024, 1024, 1024, 1024, 1> v161 = pto::Stride<1024, 1024, 1024, 1024, 1>();
      // pto: %sparse_bias_inline5289__tile_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 384>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v162 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 384>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v157 + (v158 + v71 * v159), v160, v161);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      TSTORE(v162, v155);
      // pto: %12
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v163 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %12
      ;
      uint64_t v164 = (uint64_t) v15;
      TASSIGN(v163, v164);
      TMINS(v163, v78, v31);
      // pto: %13
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v21, v22);
      // pto: %13
      ;
      uint64_t v166 = (uint64_t) v15;
      TASSIGN(v165, v166);
      pipe_barrier(PIPE_V);
      TMULS(v165, v163, v35);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      // pto: %64
      ;
      __gm__ float* v167 = PTOAS__GLOBAL_TENSOR_DATA(v46);
      // pto: %64
      ;
      const int64_t v168 = 512;
      // pto: %64
      ;
      const int64_t v169 = 1024;
      // pto: %64
      ;
      pto::Shape<1, 1, 1, 1, 512> v170 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %64
      ;
      pto::Stride<1024, 1024, 1024, 1024, 1> v171 = pto::Stride<1024, 1024, 1024, 1024, 1>();
      // pto: %64
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v172 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v167 + (v168 + v71 * v169), v170, v171);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v172, v165);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    // pto: %c_blk_tmp_inline5351__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v173 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v24, v22);
    // pto: %c_blk_tmp_inline5351__ssa_v0
    ;
    uint64_t v174 = (uint64_t) v15;
    TASSIGN(v173, v174);
    // pto: %t__tmp_v863
    ;
    Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v22);
    // pto: %t__tmp_v863
    ;
    uint64_t v176 = (uint64_t) v16;
    TASSIGN(v175, v176);
    // pto: %65
    ;
    int64_t v177 = v60 < v26 ? v26 : v60;
    // pto: %67
    ;
    const int64_t v178 = 0;
    // pto: %67
    ;
    __gm__ int32_t* v179 = PTOAS__GLOBAL_TENSOR_DATA(v55);
    // pto: %67
    ;
    const int64_t v180 = 1;
    // pto: %67
    ;
    const int64_t v181 = 1;
    // pto: %67
    ;
    const int64_t v182 = 1;
    // pto: %67
    ;
    int64_t v183 = v62 * v22;
    // pto: %67
    ;
    int64_t v184 = v182 * v183;
    // pto: %67
    ;
    pto::Shape<1, 1, 1, -1, 512> v185 = pto::Shape<1, 1, 1, -1, 512>(v180, v181, v182, v62, v22);
    // pto: %67
    ;
    pto::Stride<-1, -1, -1, -1, -1> v186 = pto::Stride<-1, -1, -1, -1, -1>(v181 * v184, v184, v183, v22, v21);
    // pto: %67
    ;
    GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v187 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v179 + (v178 + v177 * v22 + v26 * v21), v185, v186);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    TLOAD(v175, v187);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %c_block_slots_inline5354__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v188 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v22);
    // pto: %c_block_slots_inline5354__ssa_v0
    ;
    uint64_t v189 = (uint64_t) v16;
    TASSIGN(v188, v189);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    RoundMode v190 = RoundMode::CAST_ROUND;
    SaturationMode v191 = SaturationMode::ON;
    TCVT(v188, v175, v190, v191);
    // pto: %t__tmp_v864
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v22);
    // pto: %t__tmp_v864
    ;
    uint64_t v193 = (uint64_t) v16;
    TASSIGN(v192, v193);
    pipe_barrier(PIPE_V);
    TADDS(v192, v188, v34);
    // pto: %t__tmp_v865
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v194 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v22);
    // pto: %t__tmp_v865
    ;
    uint64_t v195 = (uint64_t) v16;
    TASSIGN(v194, v195);
    pipe_barrier(PIPE_V);
    TMAXS(v194, v192, v31);
    // pto: %t__tmp_v866
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v22);
    // pto: %t__tmp_v866
    ;
    uint64_t v197 = (uint64_t) v16;
    TASSIGN(v196, v197);
    pipe_barrier(PIPE_V);
    TMINS(v196, v194, v34);
    // pto: %c_blk_valid_inline5355__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v198 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v62, v21);
    // pto: %c_blk_valid_inline5355__ssa_v0
    ;
    uint64_t v199 = (uint64_t) v17;
    TASSIGN(v198, v199);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    TROWMAX(v198, v196, v173);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    for (int64_t v200 = v26; v200 < v62; v200 += v21) {
      // pto: %t__tmp_v867
      ;
      float v201 = v198.GetValue(v200);
      // pto: %70
      ;
      int32_t v202 = (int32_t) v201;
      // pto: %71, %72, %73
      ;
      int64_t v203 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v60 + (uint64_t) v200) * (uint64_t) v23) + (uint64_t) v21);
      (v7)[v203] = v202;
    };
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  #endif // __DAV_VEC__

  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  dsb((mem_dsb_t)0);
  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}