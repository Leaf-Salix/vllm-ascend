#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void island_cube(__gm__ bfloat16_t* v1, __gm__ int8_t* v2, __gm__ int8_t* v3, __gm__ bfloat16_t* v4, __gm__ int8_t* v5, __gm__ int8_t* v6, __gm__ int32_t* v7, __gm__ bfloat16_t* v8, __gm__ float* v9, __gm__ int32_t* v10, __gm__ int64_t* v11, __gm__ float* v12, __gm__ float* v13, __gm__ float* v14, __gm__ float* v15, __gm__ float* v16, __gm__ float* v17, __gm__ int32_t* v18, __gm__ float* v19, __gm__ int32_t* v20, __gm__ bfloat16_t* v21, __gm__ float* v22, __gm__ int32_t* v23, __gm__ bfloat16_t* v24, __gm__ int8_t* v25, __gm__ float* v26, int64_t v27, int64_t v28, int32_t v29, int32_t v30) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v31 = 147;
  // pto: %c0_i64
  const int64_t v32 = 0;
  // pto: %c262144_i64
  const int64_t v33 = 262144;
  // pto: %c8192_i64
  const int64_t v34 = 8192;
  // pto: %c32768_i64
  const int64_t v35 = 32768;
  // pto: %c1_index
  const int64_t v36 = 1;
  // pto: %c1024_index
  const int64_t v37 = 1024;
  // pto: %c8192_index
  const int64_t v38 = 8192;
  // pto: %c128_index
  const int64_t v39 = 128;
  // pto: %c64_index
  const int64_t v40 = 64;
  // pto: %c16_index
  const int64_t v41 = 16;
  // pto: %c32_index
  const int64_t v42 = 32;
  // pto: %c33554432_index
  const int64_t v43 = 33554432;
  // pto: %c32768_index
  const int64_t v44 = 32768;
  // pto: %c512_index
  const int64_t v45 = 512;
  // pto: %c448_index
  const int64_t v46 = 448;
  // pto: %c27648_index
  const int64_t v47 = 27648;
  // pto: %c256_index
  const int64_t v48 = 256;
  // pto: %c63_index
  const int64_t v49 = 63;
  // pto: %c24_index
  const int64_t v50 = 24;
  // pto: %c0_index
  const int64_t v51 = 0;
  // pto: %cn128_index
  const int64_t v52 = -128;
  // pto: %c20_index
  const int64_t v53 = 20;
  // pto: %c4_index
  const int64_t v54 = 4;
  // pto: %qr__ssa_v0_view
  const int64_t v55 = 1;
  // pto: %qr__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %qr__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %qr__ssa_v0_view
  int64_t v58 = (int64_t) v27;
  // pto: %qr__ssa_v0_view
  int64_t v59 = v58 * v37;
  // pto: %qr__ssa_v0_view
  int64_t v60 = v57 * v59;
  // pto: %qr__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v61 = pto::Shape<1, 1, 1, -1, -1>(v55, v56, v57, v58, v37);
  // pto: %qr__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v62 = pto::Stride<-1, -1, -1, -1, -1>(v56 * v60, v60, v59, v37, v36);
  // pto: %qr__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v63 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v61, v62);
  // pto: %idx_wq_b__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %idx_wq_b__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %idx_wq_b__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %idx_wq_b__ssa_v0_view
  int64_t v67 = v37 * v38;
  // pto: %idx_wq_b__ssa_v0_view
  int64_t v68 = v66 * v67;
  // pto: %idx_wq_b__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v69 = pto::Shape<1, 1, 1, -1, -1>(v64, v65, v66, v37, v38);
  // pto: %idx_wq_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v70 = pto::Stride<-1, -1, -1, -1, -1>(v65 * v68, v68, v67, v38, v36);
  // pto: %idx_wq_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v71 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v69, v70);
  // pto: %hadamard_idx__ssa_v0_view
  const int64_t v72 = 1;
  // pto: %hadamard_idx__ssa_v0_view
  const int64_t v73 = 1;
  // pto: %hadamard_idx__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %hadamard_idx__ssa_v0_view
  int64_t v75 = v39 * v39;
  // pto: %hadamard_idx__ssa_v0_view
  int64_t v76 = v74 * v75;
  // pto: %hadamard_idx__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v77 = pto::Shape<1, 1, 1, -1, -1>(v72, v73, v74, v39, v39);
  // pto: %hadamard_idx__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v78 = pto::Stride<-1, -1, -1, -1, -1>(v73 * v76, v76, v75, v39, v36);
  // pto: %hadamard_idx__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v79 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v77, v78);
  // pto: %wq_b__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v80 = pto::Shape<-1, -1, -1, -1, -1>(v36, v37, v40, v41, v42);
  // pto: %wq_b__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v81 = pto::Stride<-1, -1, -1, -1, -1>(v43, v44, v45, v42, v36);
  // pto: %wq_b__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v82 = GlobalTensor<int8_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v5, v80, v81);
  // pto: %island_qr_pad__rv_v2_view
  const int64_t v83 = 1;
  // pto: %island_qr_pad__rv_v2_view
  const int64_t v84 = 1;
  // pto: %island_qr_pad__rv_v2_view
  const int64_t v85 = 1;
  // pto: %island_qr_pad__rv_v2_view
  int64_t v86 = v45 * v37;
  // pto: %island_qr_pad__rv_v2_view
  int64_t v87 = v85 * v86;
  // pto: %island_qr_pad__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v88 = pto::Shape<1, 1, 1, -1, -1>(v83, v84, v85, v45, v37);
  // pto: %island_qr_pad__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v89 = pto::Stride<-1, -1, -1, -1, -1>(v84 * v87, v87, v86, v37, v36);
  // pto: %island_qr_pad__rv_v2_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v90 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v88, v89);
  // pto: %idx_acc_inline3908__ssa_v0_view
  const int64_t v91 = 1;
  // pto: %idx_acc_inline3908__ssa_v0_view
  const int64_t v92 = 1;
  // pto: %idx_acc_inline3908__ssa_v0_view
  const int64_t v93 = 1;
  // pto: %idx_acc_inline3908__ssa_v0_view
  int64_t v94 = v46 * v38;
  // pto: %idx_acc_inline3908__ssa_v0_view
  int64_t v95 = v93 * v94;
  // pto: %idx_acc_inline3908__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v96 = pto::Shape<1, 1, 1, -1, -1>(v91, v92, v93, v46, v38);
  // pto: %idx_acc_inline3908__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v97 = pto::Stride<-1, -1, -1, -1, -1>(v92 * v95, v95, v94, v38, v36);
  // pto: %idx_acc_inline3908__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v98 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v96, v97);
  // pto: %idx_bf_read_inline3911__ssa_v0_view
  const int64_t v99 = 1;
  // pto: %idx_bf_read_inline3911__ssa_v0_view
  const int64_t v100 = 1;
  // pto: %idx_bf_read_inline3911__ssa_v0_view
  const int64_t v101 = 1;
  // pto: %idx_bf_read_inline3911__ssa_v0_view
  int64_t v102 = v47 * v39;
  // pto: %idx_bf_read_inline3911__ssa_v0_view
  int64_t v103 = v101 * v102;
  // pto: %idx_bf_read_inline3911__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v104 = pto::Shape<1, 1, 1, -1, -1>(v99, v100, v101, v47, v39);
  // pto: %idx_bf_read_inline3911__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v105 = pto::Stride<-1, -1, -1, -1, -1>(v100 * v103, v103, v102, v39, v36);
  // pto: %idx_bf_read_inline3911__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v106 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v104, v105);
  // pto: %61
  int64_t v107 = (int64_t) ((uint64_t) v28 * (uint64_t) v40);
  // pto: %had_acc_inline3913__ssa_v0_view
  const int64_t v108 = 1;
  // pto: %had_acc_inline3913__ssa_v0_view
  const int64_t v109 = 1;
  // pto: %had_acc_inline3913__ssa_v0_view
  const int64_t v110 = 1;
  // pto: %had_acc_inline3913__ssa_v0_view
  int64_t v111 = v107 * v39;
  // pto: %had_acc_inline3913__ssa_v0_view
  int64_t v112 = v110 * v111;
  // pto: %had_acc_inline3913__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v113 = pto::Shape<1, 1, 1, -1, -1>(v108, v109, v110, v107, v39);
  // pto: %had_acc_inline3913__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v114 = pto::Stride<-1, -1, -1, -1, -1>(v109 * v112, v112, v111, v39, v36);
  // pto: %had_acc_inline3913__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v115 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v113, v114);
  // pto: %main_acc_inline3916__ssa_v0_view
  const int64_t v116 = 1;
  // pto: %main_acc_inline3916__ssa_v0_view
  const int64_t v117 = 1;
  // pto: %main_acc_inline3916__ssa_v0_view
  const int64_t v118 = 1;
  // pto: %main_acc_inline3916__ssa_v0_view
  int64_t v119 = v48 * v44;
  // pto: %main_acc_inline3916__ssa_v0_view
  int64_t v120 = v118 * v119;
  // pto: %main_acc_inline3916__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v121 = pto::Shape<1, 1, 1, -1, -1>(v116, v117, v118, v48, v44);
  // pto: %main_acc_inline3916__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v122 = pto::Stride<-1, -1, -1, -1, -1>(v117 * v120, v120, v119, v44, v36);
  // pto: %main_acc_inline3916__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v123 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v10, v121, v122);
  uint64_t v124 = reinterpret_cast<uint64_t>(v11);
  set_ffts_base_addr(v124);
  // pto: %worker__ssa_v0
  int64_t v125 = (int64_t) v29;
  // pto: %9
  int64_t v126 = (int64_t) ((uint64_t) v27 + (uint64_t) v49);
  // pto: %10
  const int64_t v127 = 1;
  // pto: %10
  const int64_t v128 = 0;
  // pto: %10
  int64_t v129 = v126 / v40;
  // pto: %10
  bool v130 = v126 < v128;
  // pto: %10
  bool v131 = v40 < v128;
  // pto: %10
  bool v132 = v130 == v131;
  // pto: %10
  bool v133 = v126 % v40 != v128 && v130 != v131;
  // pto: %10
  int64_t v134 = v133 ? v129 - v127 : v129;
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
  for (int64_t v135 = v125; v135 < v42; v135 += v50) {
    // pto: %11
    ;
    int64_t v136 = (int64_t) ((uint64_t) v135 * (uint64_t) v48);
    // pto: %wq_tile_inline7378__tile
    ;
    Tile<TileType::Mat, int8_t, 1024, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Mat, int8_t, 1024, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v37, v48);
    // pto: %wq_tile_inline7378__tile
    ;
    uint64_t v138 = (uint64_t) v32;
    TASSIGN(v137, v138);
    // pto: %12
    ;
    int64_t v139 = v136 < v51 ? v51 : v136;
    // pto: %idx_wq_b__ssa_v0_pview
    ;
    __gm__ int8_t* v140 = PTOAS__GLOBAL_TENSOR_DATA(v71);
    // pto: %idx_wq_b__ssa_v0_pview
    ;
    const int64_t v141 = 0;
    // pto: %idx_wq_b__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1024, 256> v142 = pto::Shape<1, 1, 1, 1024, 256>();
    // pto: %idx_wq_b__ssa_v0_pview
    ;
    pto::Stride<8388608, 8388608, 8388608, 8192, 1> v143 = pto::Stride<8388608, 8388608, 8388608, 8192, 1>();
    // pto: %idx_wq_b__ssa_v0_pview
    ;
    GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1024, 256>, pto::Stride<8388608, 8388608, 8388608, 8192, 1>, pto::Layout::ND> v144 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 1024, 256>, pto::Stride<8388608, 8388608, 8388608, 8192, 1>, pto::Layout::ND>(v140 + (v141 + v139), v142, v143);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v137, v144);
    for (int64_t v145 = v51; v145 < v134; v145 += v36) {
      // pto: %13
      ;
      int64_t v146 = (int64_t) ((uint64_t) v145 * (uint64_t) v40);
      // pto: %14
      ;
      int64_t v147 = (int64_t) ((uint64_t) v27 - (uint64_t) v146);
      // pto: %15
      ;
      int64_t v148 = v147 < v40 ? v147 : v40;
      // pto: %qr_tile_inline7382__tile
      ;
      Tile<TileType::Mat, int8_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v149 = Tile<TileType::Mat, int8_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v148, v37);
      // pto: %qr_tile_inline7382__tile
      ;
      uint64_t v150 = (uint64_t) v33;
      TASSIGN(v149, v150);
      // pto: %16
      ;
      int64_t v151 = v146 < v51 ? v51 : v146;
      // pto: %qr__ssa_v0_pview
      ;
      const int64_t v152 = 0;
      // pto: %qr__ssa_v0_pview
      ;
      __gm__ int8_t* v153 = PTOAS__GLOBAL_TENSOR_DATA(v63);
      // pto: %qr__ssa_v0_pview
      ;
      const int64_t v154 = 1;
      // pto: %qr__ssa_v0_pview
      ;
      const int64_t v155 = 1;
      // pto: %qr__ssa_v0_pview
      ;
      const int64_t v156 = 1;
      // pto: %qr__ssa_v0_pview
      ;
      int64_t v157 = v148 * v37;
      // pto: %qr__ssa_v0_pview
      ;
      int64_t v158 = v156 * v157;
      // pto: %qr__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 1024> v159 = pto::Shape<1, 1, 1, -1, 1024>(v154, v155, v156, v148, v37);
      // pto: %qr__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v160 = pto::Stride<-1, -1, -1, -1, -1>(v155 * v158, v158, v157, v37, v36);
      // pto: %qr__ssa_v0_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v161 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v153 + (v152 + v151 * v37 + v51 * v36), v159, v160);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v149, v161);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %qr_acc_inline7383__tile_l0_init_storage
      ;
      Tile<TileType::Acc, int32_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v162 = Tile<TileType::Acc, int32_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v40, v48);
      // pto: %qr_acc_inline7383__tile_l0_init_storage
      ;
      uint64_t v163 = (uint64_t) v32;
      TASSIGN(v162, v163);
      v162.SetValidShape(v148, v48);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      for (int64_t v164 = v51; v164 < v37; v164 += v48) {
        // pto: %qr_acc_inline7383__tile_l0_a
        ;
        Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v165 = Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v148, v39);
        // pto: %qr_acc_inline7383__tile_l0_a
        ;
        uint64_t v166 = (uint64_t) v34;
        TASSIGN(v165, v166);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        pipe_barrier(PIPE_MTE1);
        uint16_t v167 = static_cast<uint16_t>(v51);
        uint16_t v168 = static_cast<uint16_t>(v164);
        TEXTRACT(v165, v149, v167, v168);
        // pto: %qr_acc_inline7383__tile_l0_b
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v39, v48);
        // pto: %qr_acc_inline7383__tile_l0_b
        ;
        uint64_t v170 = (uint64_t) v32;
        TASSIGN(v169, v170);
        uint16_t v171 = static_cast<uint16_t>(v164);
        uint16_t v172 = static_cast<uint16_t>(v51);
        TEXTRACT(v169, v137, v171, v172);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %0
        ;
        Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v173 = Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v148, v39);
        // pto: %0
        ;
        uint64_t v174 = (uint64_t) v32;
        TASSIGN(v173, v174);
        // pto: %17
        ;
        int64_t v175 = (int64_t) ((uint64_t) v164 + (uint64_t) v39);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        uint16_t v176 = static_cast<uint16_t>(v51);
        uint16_t v177 = static_cast<uint16_t>(v175);
        TEXTRACT(v173, v149, v176, v177);
        // pto: %1
        ;
        Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v178 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v39, v48);
        // pto: %1
        ;
        uint64_t v179 = (uint64_t) v35;
        TASSIGN(v178, v179);
        uint16_t v180 = static_cast<uint16_t>(v175);
        uint16_t v181 = static_cast<uint16_t>(v51);
        TEXTRACT(v178, v137, v180, v181);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %19
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v164 == v51) {
          pipe_barrier(PIPE_M);
          TMATMUL(v162, v165, v169);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v162, v162, v165, v169);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        // pto: %20
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        if (v164 == v52) {
          pipe_barrier(PIPE_M);
          TMATMUL(v162, v173, v178);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v162, v162, v173, v178);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %idx_acc__iter_v3_pview
      ;
      const int64_t v182 = 0;
      // pto: %idx_acc__iter_v3_pview
      ;
      __gm__ int32_t* v183 = PTOAS__GLOBAL_TENSOR_DATA(v98);
      // pto: %idx_acc__iter_v3_pview
      ;
      const int64_t v184 = 1;
      // pto: %idx_acc__iter_v3_pview
      ;
      const int64_t v185 = 1;
      // pto: %idx_acc__iter_v3_pview
      ;
      const int64_t v186 = 1;
      // pto: %idx_acc__iter_v3_pview
      ;
      int64_t v187 = v148 * v38;
      // pto: %idx_acc__iter_v3_pview
      ;
      int64_t v188 = v186 * v187;
      // pto: %idx_acc__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, -1, 256> v189 = pto::Shape<1, 1, 1, -1, 256>(v184, v185, v186, v148, v48);
      // pto: %idx_acc__iter_v3_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v190 = pto::Stride<-1, -1, -1, -1, -1>(v185 * v188, v188, v187, v38, v36);
      // pto: %idx_acc__iter_v3_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v191 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v183 + (v182 + v151 * v38 + v139 * v36), v189, v190);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      pipe_barrier(PIPE_FIX);
      TSTORE(v191, v162);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %23
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  if (v125 < v53) {
    // pto: %26
    ;
    // pto: %27
    ;
    const int64_t v192 = 1;
    // pto: %27
    ;
    const int64_t v193 = 0;
    // pto: %27
    ;
    int64_t v194 = v27 / v40;
    // pto: %27
    ;
    bool v195 = v27 < v193;
    // pto: %27
    ;
    bool v196 = v40 < v193;
    // pto: %27
    ;
    bool v197 = v195 == v196;
    // pto: %27
    ;
    bool v198 = v27 % v40 != v193 && v195 != v196;
    // pto: %27
    ;
    int64_t v199 = v198 ? v194 - v192 : v194;
    // pto: %28
    ;
    int64_t v200 = (int64_t) ((uint64_t) v199 * (uint64_t) v40);
    int64_t v201 = (int64_t) ((uint64_t) v31 - (uint64_t) v125);
    // pto: %31
    ;
    const int64_t v202 = 1;
    // pto: %31
    ;
    const int64_t v203 = 0;
    // pto: %31
    ;
    int64_t v204 = v201 / v53;
    // pto: %31
    ;
    bool v205 = v201 < v203;
    // pto: %31
    ;
    bool v206 = v53 < v203;
    // pto: %31
    ;
    bool v207 = v205 == v206;
    // pto: %31
    ;
    bool v208 = v201 % v53 != v203 && v205 != v206;
    // pto: %31
    ;
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
    for (int64_t v209 = v51; v209 < (v208 ? v204 - v202 : v204); v209 += v36) {
      // pto: %33, %32, %34
      ;
      int64_t v210 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v125 + (uint64_t) ((int64_t) (uint64_t) v209 * (uint64_t) v53)) * (uint64_t) v48);
      // pto: %wq_full_inline7389__tile
      ;
      Tile<TileType::Mat, int8_t, 1024, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Mat, int8_t, 1024, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v37, v48);
      // pto: %wq_full_inline7389__tile
      ;
      uint64_t v212 = (uint64_t) v32;
      TASSIGN(v211, v212);
      // pto: %35
      ;
      const int64_t v213 = 1;
      // pto: %35
      ;
      const int64_t v214 = 0;
      // pto: %35
      ;
      int64_t v215 = v210 / v42;
      // pto: %35
      ;
      bool v216 = v210 < v214;
      // pto: %35
      ;
      bool v217 = v42 < v214;
      // pto: %35
      ;
      bool v218 = v216 == v217;
      // pto: %35
      ;
      bool v219 = v210 % v42 != v214 && v216 != v217;
      // pto: %35
      ;
      int64_t v220 = v219 ? v215 - v213 : v215;
      // pto: %36
      ;
      int64_t v221 = v220 < v51 ? v51 : v220;
      // pto: %wq_b__ssa_v0_pview
      ;
      __gm__ int8_t* v222 = PTOAS__GLOBAL_TENSOR_DATA(v82);
      // pto: %wq_b__ssa_v0_pview
      ;
      const int64_t v223 = 0;
      // pto: %wq_b__ssa_v0_pview
      ;
      const int64_t v224 = 32768;
      // pto: %wq_b__ssa_v0_pview
      ;
      pto::Shape<1, 8, 64, 16, 32> v225 = pto::Shape<1, 8, 64, 16, 32>();
      // pto: %wq_b__ssa_v0_pview
      ;
      pto::Stride<33554432, 32768, 512, 32, 1> v226 = pto::Stride<33554432, 32768, 512, 32, 1>();
      // pto: %wq_b__ssa_v0_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 8, 64, 16, 32>, pto::Stride<33554432, 32768, 512, 32, 1>, pto::Layout::NZ> v227 = GlobalTensor<int8_t, pto::Shape<1, 8, 64, 16, 32>, pto::Stride<33554432, 32768, 512, 32, 1>, pto::Layout::NZ>(v222 + (v223 + v221 * v224), v225, v226);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      TLOAD(v211, v227);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
      for (int64_t v228 = v51; v228 < v200; v228 += v40) {
        // pto: %qr_full_inline7391__tile
        ;
        Tile<TileType::Mat, int8_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v229 = Tile<TileType::Mat, int8_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v40, v37);
        // pto: %qr_full_inline7391__tile
        ;
        uint64_t v230 = (uint64_t) v33;
        TASSIGN(v229, v230);
        // pto: %37
        ;
        int64_t v231 = v228 < v51 ? v51 : v228;
        // pto: %island_qr_pad__rv_v2_pview
        ;
        __gm__ int8_t* v232 = PTOAS__GLOBAL_TENSOR_DATA(v90);
        // pto: %island_qr_pad__rv_v2_pview
        ;
        const int64_t v233 = 0;
        // pto: %island_qr_pad__rv_v2_pview
        ;
        const int64_t v234 = 1024;
        // pto: %island_qr_pad__rv_v2_pview
        ;
        pto::Shape<1, 1, 1, 64, 1024> v235 = pto::Shape<1, 1, 1, 64, 1024>();
        // pto: %island_qr_pad__rv_v2_pview
        ;
        pto::Stride<65536, 65536, 65536, 1024, 1> v236 = pto::Stride<65536, 65536, 65536, 1024, 1>();
        // pto: %island_qr_pad__rv_v2_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND> v237 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 64, 1024>, pto::Stride<65536, 65536, 65536, 1024, 1>, pto::Layout::ND>(v232 + (v233 + v231 * v234), v235, v236);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        TLOAD(v229, v237);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %col_acc_inline7392__tile_l0_init
        ;
        Tile<TileType::Acc, int32_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v238 = Tile<TileType::Acc, int32_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v40, v48);
        // pto: %col_acc_inline7392__tile_l0_init
        ;
        uint64_t v239 = (uint64_t) v32;
        TASSIGN(v238, v239);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        for (int64_t v240 = v51; v240 < v37; v240 += v48) {
          // pto: %col_acc_inline7392__tile_l0_a
          ;
          Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v241 = Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v40, v39);
          // pto: %col_acc_inline7392__tile_l0_a
          ;
          uint64_t v242 = (uint64_t) v34;
          TASSIGN(v241, v242);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
          pipe_barrier(PIPE_MTE1);
          uint16_t v243 = static_cast<uint16_t>(v51);
          uint16_t v244 = static_cast<uint16_t>(v240);
          TEXTRACT(v241, v229, v243, v244);
          // pto: %col_acc_inline7392__tile_l0_b
          ;
          Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v245 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v39, v48);
          // pto: %col_acc_inline7392__tile_l0_b
          ;
          uint64_t v246 = (uint64_t) v32;
          TASSIGN(v245, v246);
          uint16_t v247 = static_cast<uint16_t>(v240);
          uint16_t v248 = static_cast<uint16_t>(v51);
          TEXTRACT(v245, v211, v247, v248);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
          // pto: %3
          ;
          Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v249 = Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v40, v39);
          // pto: %3
          ;
          uint64_t v250 = (uint64_t) v32;
          TASSIGN(v249, v250);
          // pto: %38
          ;
          int64_t v251 = (int64_t) ((uint64_t) v240 + (uint64_t) v39);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          uint16_t v252 = static_cast<uint16_t>(v51);
          uint16_t v253 = static_cast<uint16_t>(v251);
          TEXTRACT(v249, v229, v252, v253);
          // pto: %4
          ;
          Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v254 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v39, v48);
          // pto: %4
          ;
          uint64_t v255 = (uint64_t) v35;
          TASSIGN(v254, v255);
          uint16_t v256 = static_cast<uint16_t>(v251);
          uint16_t v257 = static_cast<uint16_t>(v51);
          TEXTRACT(v254, v211, v256, v257);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
          // pto: %40
          ;
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
          if (v240 == v51) {
            pipe_barrier(PIPE_M);
            TMATMUL(v238, v241, v245);
          } else {
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v238, v238, v241, v245);
          };
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
          // pto: %41
          ;
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
          if (v240 == v52) {
            pipe_barrier(PIPE_M);
            TMATMUL(v238, v249, v254);
          } else {
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v238, v238, v249, v254);
          };
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        };
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
        // pto: %43
        ;
        int64_t v258 = v210 < v51 ? v51 : v210;
        // pto: %main_acc__iter_v3_pview
        ;
        __gm__ int32_t* v259 = PTOAS__GLOBAL_TENSOR_DATA(v123);
        // pto: %main_acc__iter_v3_pview
        ;
        const int64_t v260 = 0;
        // pto: %main_acc__iter_v3_pview
        ;
        const int64_t v261 = 32768;
        // pto: %main_acc__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 64, 256> v262 = pto::Shape<1, 1, 1, 64, 256>();
        // pto: %main_acc__iter_v3_pview
        ;
        pto::Stride<2097152, 2097152, 2097152, 32768, 1> v263 = pto::Stride<2097152, 2097152, 2097152, 32768, 1>();
        // pto: %main_acc__iter_v3_pview
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<2097152, 2097152, 2097152, 32768, 1>, pto::Layout::ND> v264 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 64, 256>, pto::Stride<2097152, 2097152, 2097152, 32768, 1>, pto::Layout::ND>(v259 + (v260 + v231 * v261 + v258), v262, v263);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
        pipe_barrier(PIPE_FIX);
        TSTORE(v264, v238);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
      for (int64_t v265 = v200; v265 < ((int64_t) ((uint64_t) v134 * (uint64_t) v40)); v265 += v40) {
        // pto: %44
        ;
        int64_t v266 = (int64_t) ((uint64_t) v27 - (uint64_t) v265);
        // pto: %45
        ;
        int64_t v267 = v266 < v40 ? v266 : v40;
        // pto: %qr_tail_inline7395__tile
        ;
        Tile<TileType::Mat, int8_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v268 = Tile<TileType::Mat, int8_t, 64, 1024, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v267, v37);
        // pto: %qr_tail_inline7395__tile
        ;
        uint64_t v269 = (uint64_t) v33;
        TASSIGN(v268, v269);
        // pto: %46
        ;
        int64_t v270 = v265 < v51 ? v51 : v265;
        // pto: %47
        ;
        const int64_t v271 = 0;
        // pto: %47
        ;
        __gm__ int8_t* v272 = PTOAS__GLOBAL_TENSOR_DATA(v90);
        // pto: %47
        ;
        const int64_t v273 = 1;
        // pto: %47
        ;
        const int64_t v274 = 1;
        // pto: %47
        ;
        const int64_t v275 = 1;
        // pto: %47
        ;
        int64_t v276 = v267 * v37;
        // pto: %47
        ;
        int64_t v277 = v275 * v276;
        // pto: %47
        ;
        pto::Shape<1, 1, 1, -1, 1024> v278 = pto::Shape<1, 1, 1, -1, 1024>(v273, v274, v275, v267, v37);
        // pto: %47
        ;
        pto::Stride<-1, -1, -1, -1, -1> v279 = pto::Stride<-1, -1, -1, -1, -1>(v274 * v277, v277, v276, v37, v36);
        // pto: %47
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v280 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 1024>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v272 + (v271 + v270 * v37 + v51 * v36), v278, v279);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
        TLOAD(v268, v280);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        // pto: %tail_acc_inline7396__tile_l0_init_storage
        ;
        Tile<TileType::Acc, int32_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v281 = Tile<TileType::Acc, int32_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v40, v48);
        // pto: %tail_acc_inline7396__tile_l0_init_storage
        ;
        uint64_t v282 = (uint64_t) v32;
        TASSIGN(v281, v282);
        v281.SetValidShape(v267, v48);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        for (int64_t v283 = v51; v283 < v37; v283 += v48) {
          // pto: %tail_acc_inline7396__tile_l0_a
          ;
          Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v284 = Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v267, v39);
          // pto: %tail_acc_inline7396__tile_l0_a
          ;
          uint64_t v285 = (uint64_t) v34;
          TASSIGN(v284, v285);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          uint16_t v286 = static_cast<uint16_t>(v51);
          uint16_t v287 = static_cast<uint16_t>(v283);
          TEXTRACT(v284, v268, v286, v287);
          // pto: %tail_acc_inline7396__tile_l0_b
          ;
          Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v288 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v39, v48);
          // pto: %tail_acc_inline7396__tile_l0_b
          ;
          uint64_t v289 = (uint64_t) v32;
          TASSIGN(v288, v289);
          uint16_t v290 = static_cast<uint16_t>(v283);
          uint16_t v291 = static_cast<uint16_t>(v51);
          TEXTRACT(v288, v211, v290, v291);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
          // pto: %6
          ;
          Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v292 = Tile<TileType::Left, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v267, v39);
          // pto: %6
          ;
          uint64_t v293 = (uint64_t) v32;
          TASSIGN(v292, v293);
          // pto: %48
          ;
          int64_t v294 = (int64_t) ((uint64_t) v283 + (uint64_t) v39);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
          uint16_t v295 = static_cast<uint16_t>(v51);
          uint16_t v296 = static_cast<uint16_t>(v294);
          TEXTRACT(v292, v268, v295, v296);
          // pto: %7
          ;
          Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Right, int8_t, 128, 256, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v39, v48);
          // pto: %7
          ;
          uint64_t v298 = (uint64_t) v35;
          TASSIGN(v297, v298);
          pipe_barrier(PIPE_MTE1);
          uint16_t v299 = static_cast<uint16_t>(v294);
          uint16_t v300 = static_cast<uint16_t>(v51);
          TEXTRACT(v297, v211, v299, v300);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          // pto: %50
          ;
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
          if (v283 == v51) {
            pipe_barrier(PIPE_M);
            TMATMUL(v281, v284, v288);
          } else {
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v281, v281, v284, v288);
          };
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          // pto: %51
          ;
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          if (v283 == v52) {
            pipe_barrier(PIPE_M);
            TMATMUL(v281, v292, v297);
          } else {
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v281, v281, v292, v297);
          };
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        };
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
        // pto: %54
        ;
        int64_t v301 = v210 < v51 ? v51 : v210;
        // pto: %main_acc__iter_v6_pview
        ;
        const int64_t v302 = 0;
        // pto: %main_acc__iter_v6_pview
        ;
        __gm__ int32_t* v303 = PTOAS__GLOBAL_TENSOR_DATA(v123);
        // pto: %main_acc__iter_v6_pview
        ;
        const int64_t v304 = 1;
        // pto: %main_acc__iter_v6_pview
        ;
        const int64_t v305 = 1;
        // pto: %main_acc__iter_v6_pview
        ;
        const int64_t v306 = 1;
        // pto: %main_acc__iter_v6_pview
        ;
        int64_t v307 = v267 * v44;
        // pto: %main_acc__iter_v6_pview
        ;
        int64_t v308 = v306 * v307;
        // pto: %main_acc__iter_v6_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v309 = pto::Shape<1, 1, 1, -1, 256>(v304, v305, v306, v267, v48);
        // pto: %main_acc__iter_v6_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v310 = pto::Stride<-1, -1, -1, -1, -1>(v305 * v308, v308, v307, v44, v36);
        // pto: %main_acc__iter_v6_pview
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v311 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v303 + (v302 + v270 * v44 + v301 * v36), v309, v310);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
        pipe_barrier(PIPE_FIX);
        TSTORE(v311, v281);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    };
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
  } else {
    // pto: %55
    ;
    int64_t v312 = (int64_t) ((uint64_t) v27 * (uint64_t) v40);
    // pto: %qh_hadamard_inline7399__tile
    ;
    Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Mat, bfloat16_t, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v39, v39);
    // pto: %qh_hadamard_inline7399__tile
    ;
    uint64_t v314 = (uint64_t) v32;
    TASSIGN(v313, v314);
    // pto: %hadamard_idx__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v315 = PTOAS__GLOBAL_TENSOR_DATA(v79);
    // pto: %hadamard_idx__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 128, 128> v316 = pto::Shape<1, 1, 1, 128, 128>();
    // pto: %hadamard_idx__ssa_v0_pview
    ;
    pto::Stride<16384, 16384, 16384, 128, 1> v317 = pto::Stride<16384, 16384, 16384, 128, 1>();
    // pto: %hadamard_idx__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 128>, pto::Stride<16384, 16384, 16384, 128, 1>, pto::Layout::ND> v318 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 128>, pto::Stride<16384, 16384, 16384, 128, 1>, pto::Layout::ND>(v315, v316, v317);
    TLOAD(v313, v318);
    // pto: %56
    ;
    // pto: %57
    ;
    const int64_t v319 = 1;
    // pto: %57
    ;
    const int64_t v320 = 0;
    // pto: %57
    ;
    int64_t v321 = v312 / v40;
    // pto: %57
    ;
    bool v322 = v312 < v320;
    // pto: %57
    ;
    bool v323 = v40 < v320;
    // pto: %57
    ;
    bool v324 = v322 == v323;
    // pto: %57
    ;
    bool v325 = v312 % v40 != v320 && v322 != v323;
    // pto: %57
    ;
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    for (int64_t v326 = (int64_t) ((uint64_t) v125 - (uint64_t) v53); v326 < (v325 ? v321 - v319 : v321); v326 += v54) {
      // pto: %58
      ;
      int64_t v327 = (int64_t) ((uint64_t) v326 * (uint64_t) v40);
      // pto: %t__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v40, v39);
      // pto: %t__tile
      ;
      uint64_t v329 = (uint64_t) v33;
      TASSIGN(v328, v329);
      // pto: %59
      ;
      int64_t v330 = v327 < v51 ? v51 : v327;
      // pto: %idx_bf_read_inline3911__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v331 = PTOAS__GLOBAL_TENSOR_DATA(v106);
      // pto: %idx_bf_read_inline3911__ssa_v0_pview
      ;
      const int64_t v332 = 0;
      // pto: %idx_bf_read_inline3911__ssa_v0_pview
      ;
      const int64_t v333 = 128;
      // pto: %idx_bf_read_inline3911__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 64, 128> v334 = pto::Shape<1, 1, 1, 64, 128>();
      // pto: %idx_bf_read_inline3911__ssa_v0_pview
      ;
      pto::Stride<8192, 8192, 8192, 128, 1> v335 = pto::Stride<8192, 8192, 8192, 128, 1>();
      // pto: %idx_bf_read_inline3911__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND> v336 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND>(v331 + (v332 + v330 * v333), v334, v335);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      TLOAD(v328, v336);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %t__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v337 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v40, v39);
      // pto: %t__tile_Left
      ;
      uint64_t v338 = (uint64_t) v34;
      TASSIGN(v337, v338);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v337, v328);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      // pto: %qh_hadamard_inline7399__tile_Right
      ;
      Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v339 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v39, v39);
      // pto: %qh_hadamard_inline7399__tile_Right
      ;
      uint64_t v340 = (uint64_t) v32;
      TASSIGN(v339, v340);
      TMOV(v339, v313);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
      // pto: %qh_acc_inline7402__tile
      ;
      Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v341 = Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v40, v39);
      // pto: %qh_acc_inline7402__tile
      ;
      uint64_t v342 = (uint64_t) v32;
      TASSIGN(v341, v342);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
      TMATMUL(v341, v337, v339);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      // pto: %had_acc__iter_v1_pview
      ;
      __gm__ float* v343 = PTOAS__GLOBAL_TENSOR_DATA(v115);
      // pto: %had_acc__iter_v1_pview
      ;
      const int64_t v344 = 0;
      // pto: %had_acc__iter_v1_pview
      ;
      const int64_t v345 = 128;
      // pto: %had_acc__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, 64, 128> v346 = pto::Shape<1, 1, 1, 64, 128>();
      // pto: %had_acc__iter_v1_pview
      ;
      pto::Stride<8192, 8192, 8192, 128, 1> v347 = pto::Stride<8192, 8192, 8192, 128, 1>();
      // pto: %had_acc__iter_v1_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND> v348 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND>(v343 + (v344 + v330 * v345), v346, v347);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
      TSTORE(v348, v341);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    };
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void island_vector(__gm__ bfloat16_t* v1, __gm__ int8_t* v2, __gm__ int8_t* v3, __gm__ bfloat16_t* v4, __gm__ int8_t* v5, __gm__ int8_t* v6, __gm__ int32_t* v7, __gm__ bfloat16_t* v8, __gm__ float* v9, __gm__ int32_t* v10, __gm__ int64_t* v11, __gm__ float* v12, __gm__ float* v13, __gm__ float* v14, __gm__ float* v15, __gm__ float* v16, __gm__ float* v17, __gm__ int32_t* v18, __gm__ float* v19, __gm__ int32_t* v20, __gm__ bfloat16_t* v21, __gm__ float* v22, __gm__ int32_t* v23, __gm__ bfloat16_t* v24, __gm__ int8_t* v25, __gm__ float* v26, int64_t v27, int64_t v28, int32_t v29, int32_t v30, int32_t v31) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v32 = 512;
  // pto: %c0_i64
  const int64_t v33 = 0;
  // pto: %c49152_i64
  const int64_t v34 = 49152;
  // pto: %c32768_i64
  const int64_t v35 = 32768;
  // pto: %c110592_i64
  const int64_t v36 = 110592;
  // pto: %c112640_i64
  const int64_t v37 = 112640;
  // pto: %c112672_i64
  const int64_t v38 = 112672;
  // pto: %c114720_i64
  const int64_t v39 = 114720;
  // pto: %c81920_i64
  const int64_t v40 = 81920;
  // pto: %c83968_i64
  const int64_t v41 = 83968;
  const int64_t v42 = 256;
  // pto: %c86016_i64
  const int64_t v43 = 86016;
  // pto: %c88064_i64
  const int64_t v44 = 88064;
  // pto: %c90112_i64
  const int64_t v45 = 90112;
  const int64_t v46 = 49408;
  // pto: %c106496_i64
  const int64_t v47 = 106496;
  // pto: %c108544_i64
  const int64_t v48 = 108544;
  const int64_t v49 = 33024;
  const int64_t v50 = 33792;
  const int64_t v51 = 34048;
  const int64_t v52 = 33280;
  const int64_t v53 = 34304;
  const int64_t v54 = 33536;
  const int64_t v55 = 34560;
  const int64_t v56 = 1792;
  const int64_t v57 = 91136;
  const int64_t v58 = 90368;
  const int64_t v59 = 91392;
  const int64_t v60 = 90624;
  const int64_t v61 = 91648;
  const int64_t v62 = 90880;
  const int64_t v63 = 91904;
  const int64_t v64 = 50944;
  const int64_t v65 = 50176;
  const int64_t v66 = 50432;
  const int64_t v67 = 49664;
  const int64_t v68 = 50688;
  const int64_t v69 = 49920;
  // pto: %c1_index
  const int64_t v70 = 1;
  // pto: %c8192_index
  const int64_t v71 = 8192;
  // pto: %c128_index
  const int64_t v72 = 128;
  // pto: %c64_index
  const int64_t v73 = 64;
  // pto: %c16_index
  const int64_t v74 = 16;
  // pto: %c32768_index
  const int64_t v75 = 32768;
  // pto: %c512_index
  const int64_t v76 = 512;
  // pto: %c448_index
  const int64_t v77 = 448;
  // pto: %c27648_index
  const int64_t v78 = 27648;
  // pto: %c256_index
  const int64_t v79 = 256;
  // pto: %c432_index
  const int64_t v80 = 432;
  // pto: %c2_index
  const int64_t v81 = 2;
  // pto: %c7_index
  const int64_t v82 = 7;
  // pto: %c8_index
  const int64_t v83 = 8;
  // pto: %c48_index
  const int64_t v84 = 48;
  // pto: %cst_56
  const float v85 = 1.0f;
  // pto: %c192_index
  const int64_t v86 = 192;
  // pto: %c0_i32
  const int32_t v87 = 0;
  // pto: %cst_59
  const float v88 = 0.5f;
  // pto: %cst_60
  const float v89 = 2.0f;
  // pto: %c0_index
  const int64_t v90 = 0;
  // pto: %c4_index
  const int64_t v91 = 4;
  // pto: %cst_63
  const float v92 = 0.0883883461f;
  // pto: %cst_64
  const float v93 = 9.99999974E-5f;
  // pto: %cst_65
  const float v94 = 127.0f;
  // pto: %c384_index
  const int64_t v95 = 384;
  // pto: %c96_index
  const int64_t v96 = 96;
  // pto: %cst_69
  const float v97 = 0.001953125f;
  // pto: %cst_70
  const float v98 = 9.99999997E-7f;
  // pto: %cst_71
  const float v99 = 64.0f;
  // pto: %qr_scale__ssa_v0_view
  const int64_t v100 = 1;
  // pto: %qr_scale__ssa_v0_view
  const int64_t v101 = 1;
  // pto: %qr_scale__ssa_v0_view
  const int64_t v102 = 1;
  // pto: %qr_scale__ssa_v0_view
  int64_t v103 = (int64_t) v27;
  // pto: %qr_scale__ssa_v0_view
  int64_t v104 = v103 * v70;
  // pto: %qr_scale__ssa_v0_view
  int64_t v105 = v102 * v104;
  // pto: %qr_scale__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v106 = pto::Shape<1, 1, 1, -1, -1>(v100, v101, v102, v103, v70);
  // pto: %qr_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v107 = pto::Stride<-1, -1, -1, -1, -1>(v101 * v105, v105, v104, v70, (int64_t) v27);
  // pto: %qr_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v108 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v12, v106, v107);
  // pto: %idx_wq_b_scale__ssa_v0_view
  const int64_t v109 = 1;
  // pto: %idx_wq_b_scale__ssa_v0_view
  const int64_t v110 = 1;
  // pto: %idx_wq_b_scale__ssa_v0_view
  const int64_t v111 = 1;
  // pto: %idx_wq_b_scale__ssa_v0_view
  const int64_t v112 = 1;
  // pto: %idx_wq_b_scale__ssa_v0_view
  int64_t v113 = v71 * v70;
  // pto: %idx_wq_b_scale__ssa_v0_view
  int64_t v114 = v112 * v113;
  // pto: %idx_wq_b_scale__ssa_v0_view
  int64_t v115 = v111 * v114;
  // pto: %idx_wq_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v116 = pto::Shape<1, 1, 1, 1, -1>(v109, v110, v111, v112, v71);
  // pto: %idx_wq_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v117 = pto::Stride<-1, -1, -1, -1, -1>(v110 * v115, v115, v114, v113, v70);
  // pto: %idx_wq_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v118 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v116, v117);
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v119 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v120 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v121 = 1;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v122 = (int64_t) v27;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v123 = v122 * v73;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v124 = v121 * v123;
  // pto: %freqs_cos__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v125 = pto::Shape<1, 1, 1, -1, -1>(v119, v120, v121, v122, v73);
  // pto: %freqs_cos__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v126 = pto::Stride<-1, -1, -1, -1, -1>(v120 * v124, v124, v123, v73, v70);
  // pto: %freqs_cos__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v127 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v125, v126);
  // pto: %idx_sin_signed__ssa_v1_view
  const int64_t v128 = 1;
  // pto: %idx_sin_signed__ssa_v1_view
  const int64_t v129 = 1;
  // pto: %idx_sin_signed__ssa_v1_view
  const int64_t v130 = 1;
  // pto: %idx_sin_signed__ssa_v1_view
  int64_t v131 = (int64_t) v27;
  // pto: %idx_sin_signed__ssa_v1_view
  int64_t v132 = v131 * v73;
  // pto: %idx_sin_signed__ssa_v1_view
  int64_t v133 = v130 * v132;
  // pto: %idx_sin_signed__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v134 = pto::Shape<1, 1, 1, -1, -1>(v128, v129, v130, v131, v73);
  // pto: %idx_sin_signed__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v135 = pto::Stride<-1, -1, -1, -1, -1>(v129 * v133, v133, v132, v73, v70);
  // pto: %idx_sin_signed__ssa_v1_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v136 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v134, v135);
  // pto: %wq_b_scale__ssa_v0_view
  const int64_t v137 = 1;
  // pto: %wq_b_scale__ssa_v0_view
  const int64_t v138 = 1;
  // pto: %wq_b_scale__ssa_v0_view
  const int64_t v139 = 1;
  // pto: %wq_b_scale__ssa_v0_view
  const int64_t v140 = 1;
  // pto: %wq_b_scale__ssa_v0_view
  int64_t v141 = v75 * v70;
  // pto: %wq_b_scale__ssa_v0_view
  int64_t v142 = v140 * v141;
  // pto: %wq_b_scale__ssa_v0_view
  int64_t v143 = v139 * v142;
  // pto: %wq_b_scale__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v144 = pto::Shape<1, 1, 1, 1, -1>(v137, v138, v139, v140, v75);
  // pto: %wq_b_scale__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v145 = pto::Stride<-1, -1, -1, -1, -1>(v138 * v143, v143, v142, v141, v70);
  // pto: %wq_b_scale__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v146 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v144, v145);
  // pto: %island_signed__ssa_v0_view
  const int64_t v147 = 1;
  // pto: %island_signed__ssa_v0_view
  const int64_t v148 = 1;
  // pto: %island_signed__ssa_v0_view
  const int64_t v149 = 1;
  // pto: %island_signed__ssa_v0_view
  int64_t v150 = (int64_t) v27;
  // pto: %island_signed__ssa_v0_view
  int64_t v151 = v150 * v73;
  // pto: %island_signed__ssa_v0_view
  int64_t v152 = v149 * v151;
  // pto: %island_signed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v153 = pto::Shape<1, 1, 1, -1, -1>(v147, v148, v149, v150, v73);
  // pto: %island_signed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v154 = pto::Stride<-1, -1, -1, -1, -1>(v148 * v152, v152, v151, v73, v70);
  // pto: %island_signed__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v155 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v17, v153, v154);
  // pto: %island_swap__ssa_v0_view
  const int64_t v156 = 1;
  // pto: %island_swap__ssa_v0_view
  const int64_t v157 = 1;
  // pto: %island_swap__ssa_v0_view
  const int64_t v158 = 1;
  // pto: %island_swap__ssa_v0_view
  int64_t v159 = (int64_t) v27;
  // pto: %island_swap__ssa_v0_view
  int64_t v160 = v159 * v73;
  // pto: %island_swap__ssa_v0_view
  int64_t v161 = v158 * v160;
  // pto: %island_swap__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v162 = pto::Shape<1, 1, 1, -1, -1>(v156, v157, v158, v159, v73);
  // pto: %island_swap__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v163 = pto::Stride<-1, -1, -1, -1, -1>(v157 * v161, v161, v160, v73, v70);
  // pto: %island_swap__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v164 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v18, v162, v163);
  // pto: %island_scale_pad__rv_v2_view
  const int64_t v165 = 1;
  // pto: %island_scale_pad__rv_v2_view
  const int64_t v166 = 1;
  // pto: %island_scale_pad__rv_v2_view
  const int64_t v167 = 1;
  // pto: %island_scale_pad__rv_v2_view
  int64_t v168 = v76 * v70;
  // pto: %island_scale_pad__rv_v2_view
  int64_t v169 = v167 * v168;
  // pto: %island_scale_pad__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v170 = pto::Shape<1, 1, 1, -1, -1>(v165, v166, v167, v76, v70);
  // pto: %island_scale_pad__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v171 = pto::Stride<-1, -1, -1, -1, -1>(v166 * v169, v169, v168, v70, v76);
  // pto: %island_scale_pad__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v172 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v19, v170, v171);
  // pto: %idx_acc_read_inline3909__ssa_v0_view
  const int64_t v173 = 1;
  // pto: %idx_acc_read_inline3909__ssa_v0_view
  const int64_t v174 = 1;
  // pto: %idx_acc_read_inline3909__ssa_v0_view
  const int64_t v175 = 1;
  // pto: %idx_acc_read_inline3909__ssa_v0_view
  int64_t v176 = v77 * v71;
  // pto: %idx_acc_read_inline3909__ssa_v0_view
  int64_t v177 = v175 * v176;
  // pto: %idx_acc_read_inline3909__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v178 = pto::Shape<1, 1, 1, -1, -1>(v173, v174, v175, v77, v71);
  // pto: %idx_acc_read_inline3909__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v179 = pto::Stride<-1, -1, -1, -1, -1>(v174 * v177, v177, v176, v71, v70);
  // pto: %idx_acc_read_inline3909__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v180 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v20, v178, v179);
  // pto: %idx_bf_flat_inline3912__ssa_v0_view
  const int64_t v181 = 1;
  // pto: %idx_bf_flat_inline3912__ssa_v0_view
  const int64_t v182 = 1;
  // pto: %idx_bf_flat_inline3912__ssa_v0_view
  const int64_t v183 = 1;
  // pto: %idx_bf_flat_inline3912__ssa_v0_view
  int64_t v184 = v80 * v71;
  // pto: %idx_bf_flat_inline3912__ssa_v0_view
  int64_t v185 = v183 * v184;
  // pto: %idx_bf_flat_inline3912__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v186 = pto::Shape<1, 1, 1, -1, -1>(v181, v182, v183, v80, v71);
  // pto: %idx_bf_flat_inline3912__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v187 = pto::Stride<-1, -1, -1, -1, -1>(v182 * v185, v185, v184, v71, v70);
  // pto: %idx_bf_flat_inline3912__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v188 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v21, v186, v187);
  // pto: %474
  int64_t v189 = (int64_t) ((uint64_t) v28 * (uint64_t) v73);
  // pto: %had_acc_read_inline3914__ssa_v0_view
  const int64_t v190 = 1;
  // pto: %had_acc_read_inline3914__ssa_v0_view
  const int64_t v191 = 1;
  // pto: %had_acc_read_inline3914__ssa_v0_view
  const int64_t v192 = 1;
  // pto: %had_acc_read_inline3914__ssa_v0_view
  int64_t v193 = v189 * v72;
  // pto: %had_acc_read_inline3914__ssa_v0_view
  int64_t v194 = v192 * v193;
  // pto: %had_acc_read_inline3914__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v195 = pto::Shape<1, 1, 1, -1, -1>(v190, v191, v192, v189, v72);
  // pto: %had_acc_read_inline3914__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v196 = pto::Stride<-1, -1, -1, -1, -1>(v191 * v194, v194, v193, v72, v70);
  // pto: %had_acc_read_inline3914__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v197 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v22, v195, v196);
  // pto: %main_acc_read_inline3917__ssa_v0_view
  const int64_t v198 = 1;
  // pto: %main_acc_read_inline3917__ssa_v0_view
  const int64_t v199 = 1;
  // pto: %main_acc_read_inline3917__ssa_v0_view
  const int64_t v200 = 1;
  // pto: %main_acc_read_inline3917__ssa_v0_view
  int64_t v201 = v79 * v75;
  // pto: %main_acc_read_inline3917__ssa_v0_view
  int64_t v202 = v200 * v201;
  // pto: %main_acc_read_inline3917__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v203 = pto::Shape<1, 1, 1, -1, -1>(v198, v199, v200, v79, v75);
  // pto: %main_acc_read_inline3917__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v204 = pto::Stride<-1, -1, -1, -1, -1>(v199 * v202, v202, v201, v75, v70);
  // pto: %main_acc_read_inline3917__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v205 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v23, v203, v204);
  // pto: %q_flat_inline3905__ssa_v0_view
  const int64_t v206 = 1;
  // pto: %q_flat_inline3905__ssa_v0_view
  const int64_t v207 = 1;
  // pto: %q_flat_inline3905__ssa_v0_view
  const int64_t v208 = 1;
  // pto: %q_flat_inline3905__ssa_v0_view
  int64_t v209 = (int64_t) v28;
  // pto: %q_flat_inline3905__ssa_v0_view
  int64_t v210 = v209 * v75;
  // pto: %q_flat_inline3905__ssa_v0_view
  int64_t v211 = v208 * v210;
  // pto: %q_flat_inline3905__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v212 = pto::Shape<1, 1, 1, -1, -1>(v206, v207, v208, v209, v75);
  // pto: %q_flat_inline3905__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v213 = pto::Stride<-1, -1, -1, -1, -1>(v207 * v211, v211, v210, v75, v70);
  // pto: %q_flat_inline3905__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v214 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v24, v212, v213);
  // pto: %qr_hadamard_i8_inline3906__ssa_v0_view
  const int64_t v215 = 1;
  // pto: %qr_hadamard_i8_inline3906__ssa_v0_view
  const int64_t v216 = 1;
  // pto: %qr_hadamard_i8_inline3906__ssa_v0_view
  const int64_t v217 = 1;
  // pto: %qr_hadamard_i8_inline3906__ssa_v0_view
  int64_t v218 = v78 * v72;
  // pto: %qr_hadamard_i8_inline3906__ssa_v0_view
  int64_t v219 = v217 * v218;
  // pto: %qr_hadamard_i8_inline3906__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v220 = pto::Shape<1, 1, 1, -1, -1>(v215, v216, v217, v78, v72);
  // pto: %qr_hadamard_i8_inline3906__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v221 = pto::Stride<-1, -1, -1, -1, -1>(v216 * v219, v219, v218, v72, v70);
  // pto: %qr_hadamard_i8_inline3906__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v222 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v25, v220, v221);
  // pto: %qr_hadamard_scale_dq_inline3907__ssa_v0_view
  const int64_t v223 = 1;
  // pto: %qr_hadamard_scale_dq_inline3907__ssa_v0_view
  const int64_t v224 = 1;
  // pto: %qr_hadamard_scale_dq_inline3907__ssa_v0_view
  const int64_t v225 = 1;
  // pto: %qr_hadamard_scale_dq_inline3907__ssa_v0_view
  int64_t v226 = v78 * v70;
  // pto: %qr_hadamard_scale_dq_inline3907__ssa_v0_view
  int64_t v227 = v225 * v226;
  // pto: %qr_hadamard_scale_dq_inline3907__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v228 = pto::Shape<1, 1, 1, -1, -1>(v223, v224, v225, v78, v70);
  // pto: %qr_hadamard_scale_dq_inline3907__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v229 = pto::Stride<-1, -1, -1, -1, -1>(v224 * v227, v227, v226, v70, v78);
  // pto: %qr_hadamard_scale_dq_inline3907__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v230 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v26, v228, v229);
  uint64_t v231 = reinterpret_cast<uint64_t>(v11);
  set_ffts_base_addr(v231);
  // pto: %t__tmp_v0, %204, %205, %t__tmp_v1
  int64_t v232 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v29) * (uint64_t) v81) + (uint64_t) ((int64_t) v31));
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %206
  int64_t v233 = (int64_t) ((uint64_t) v27 + (uint64_t) v82);
  // pto: %207
  const int64_t v234 = 1;
  // pto: %207
  const int64_t v235 = 0;
  // pto: %207
  int64_t v236 = v233 / v83;
  // pto: %207
  bool v237 = v233 < v235;
  // pto: %207
  bool v238 = v83 < v235;
  // pto: %207
  bool v239 = v237 == v238;
  // pto: %207
  bool v240 = v233 % v83 != v235 && v237 != v238;
  // pto: %207
  int64_t v241 = v240 ? v236 - v234 : v236;
  // pto: %208
  int64_t v242 = (int64_t) ((uint64_t) v241 * (uint64_t) v74);
  // pto: %209
  int64_t v243 = v242 < v84 ? v242 : v84;
  // pto: %210
  if (v232 < v243) {
    // pto: %sw_ones_inline8765__tile
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v244 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
    // pto: %sw_ones_inline8765__tile
    ;
    uint64_t v245 = (uint64_t) v33;
    TASSIGN(v244, v245);
    TEXPANDS(v244, v85);
    // pto: %t__ci_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v86);
    // pto: %t__ci_tmp_v0
    ;
    uint64_t v247 = (uint64_t) v34;
    TASSIGN(v246, v247);
    // pto: %t__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v248 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
    // pto: %t__tile
    ;
    uint64_t v249 = (uint64_t) v35;
    TASSIGN(v248, v249);
    // pto: %ci_tmp_view
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v250;
    TRESHAPE(v250, v246);
    // pto: %ci_dst_view
    ;
    Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v251;
    TRESHAPE(v251, v248);
    TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v251, v87, v250);
    // pto: %sw_index_inline8766__tile
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v252 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
    // pto: %sw_index_inline8766__tile
    ;
    uint64_t v253 = (uint64_t) v34;
    TASSIGN(v252, v253);
    pipe_barrier(PIPE_V);
    RoundMode v254 = RoundMode::CAST_ROUND;
    SaturationMode v255 = SaturationMode::ON;
    TCVT(v252, v248, v254, v255);
    // pto: %sw_col_inline8767__tile
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v256 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
    // pto: %sw_col_inline8767__tile
    ;
    uint64_t v257 = (uint64_t) v33;
    TASSIGN(v256, v257);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v256, v244, v252);
    // pto: %0
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v258 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
    // pto: %0
    ;
    uint64_t v259 = (uint64_t) v34;
    TASSIGN(v258, v259);
    pipe_barrier(PIPE_V);
    TMULS(v258, v256, v88);
    // pto: %1
    ;
    Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v260 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
    // pto: %1
    ;
    uint64_t v261 = (uint64_t) v34;
    TASSIGN(v260, v261);
    pipe_barrier(PIPE_V);
    RoundMode v262 = RoundMode::CAST_TRUNC;
    SaturationMode v263 = SaturationMode::ON;
    TCVT(v260, v258, v262, v263);
    // pto: %sw_dup_f_inline8768__tile
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v264 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
    // pto: %sw_dup_f_inline8768__tile
    ;
    uint64_t v265 = (uint64_t) v34;
    TASSIGN(v264, v265);
    pipe_barrier(PIPE_V);
    RoundMode v266 = RoundMode::CAST_ROUND;
    SaturationMode v267 = SaturationMode::ON;
    TCVT(v264, v260, v266, v267);
    // pto: %2
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v268 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
    // pto: %2
    ;
    uint64_t v269 = (uint64_t) v34;
    TASSIGN(v268, v269);
    pipe_barrier(PIPE_V);
    TMULS(v268, v264, v89);
    // pto: %sw_lane_inline8769__tile
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v270 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
    // pto: %sw_lane_inline8769__tile
    ;
    uint64_t v271 = (uint64_t) v34;
    TASSIGN(v270, v271);
    pipe_barrier(PIPE_V);
    TSUB(v270, v256, v268);
    // pto: %3
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v272 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
    // pto: %3
    ;
    uint64_t v273 = (uint64_t) v33;
    TASSIGN(v272, v273);
    pipe_barrier(PIPE_V);
    TADDS(v272, v256, v85);
    // pto: %4
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v274 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
    // pto: %4
    ;
    uint64_t v275 = (uint64_t) v34;
    TASSIGN(v274, v275);
    TMULS(v274, v270, v89);
    // pto: %5
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v276 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
    // pto: %5
    ;
    uint64_t v277 = (uint64_t) v33;
    TASSIGN(v276, v277);
    pipe_barrier(PIPE_V);
    TSUB(v276, v272, v274);
    // pto: %rope_swap_idx_inline8770__tile
    ;
    Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v278 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
    // pto: %rope_swap_idx_inline8770__tile
    ;
    uint64_t v279 = (uint64_t) v36;
    TASSIGN(v278, v279);
    pipe_barrier(PIPE_V);
    RoundMode v280 = RoundMode::CAST_ROUND;
    SaturationMode v281 = SaturationMode::ON;
    TCVT(v278, v276, v280, v281);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    for (int64_t v282 = v232; v282 < v242; v282 += v243) {
      // pto: %211
      ;
      int64_t v283 = v282 % v74;
      // pto: %212, %213, %214
      ;
      int64_t v284 = v283 < v90 ? (int64_t) ((uint64_t) v283 + (uint64_t) v74) : v283;
      // pto: %215
      ;
      int64_t v285 = (int64_t) ((uint64_t) v284 * (uint64_t) v91);
      // pto: %216
      ;
      const int64_t v286 = 1;
      // pto: %216
      ;
      const int64_t v287 = 0;
      // pto: %216
      ;
      int64_t v288 = v282 / v74;
      // pto: %216
      ;
      bool v289 = v282 < v287;
      // pto: %216
      ;
      bool v290 = v74 < v287;
      // pto: %216
      ;
      bool v291 = v289 == v290;
      // pto: %216
      ;
      bool v292 = v282 % v74 != v287 && v289 != v290;
      // pto: %216
      ;
      int64_t v293 = v292 ? v288 - v286 : v288;
      // pto: %217
      ;
      int64_t v294 = (int64_t) ((uint64_t) v293 * (uint64_t) v83);
      // pto: %218, %219
      ;
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      if ((int64_t) ((uint64_t) v294 + (uint64_t) v83) <= v27) {
        // pto: %qr_scale_tile_inline8774__tile
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v70);
        // pto: %qr_scale_tile_inline8774__tile
        ;
        uint64_t v296 = (uint64_t) v37;
        TASSIGN(v295, v296);
        // pto: %220
        ;
        int64_t v297 = v294 < v90 ? v90 : v294;
        // pto: %qr_scale__ssa_v0_pview
        ;
        int64_t v298 = (int64_t) v27;
        // pto: %qr_scale__ssa_v0_pview
        ;
        const int64_t v299 = 0;
        // pto: %qr_scale__ssa_v0_pview
        ;
        __gm__ float* v300 = PTOAS__GLOBAL_TENSOR_DATA(v108);
        // pto: %qr_scale__ssa_v0_pview
        ;
        const int64_t v301 = 1;
        // pto: %qr_scale__ssa_v0_pview
        ;
        const int64_t v302 = 1;
        // pto: %qr_scale__ssa_v0_pview
        ;
        const int64_t v303 = 1;
        // pto: %qr_scale__ssa_v0_pview
        ;
        int64_t v304 = v83 * v70;
        // pto: %qr_scale__ssa_v0_pview
        ;
        int64_t v305 = v303 * v304;
        // pto: %qr_scale__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 8, 1> v306 = pto::Shape<1, 1, 1, 8, 1>(v301, v302, v303, v83, v70);
        // pto: %qr_scale__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v307 = pto::Stride<-1, -1, -1, -1, -1>(v302 * v305, v305, v304, v70, v298);
        // pto: %qr_scale__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v308 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v300 + (v299 + v297 * v70 + v90 * v298), v306, v307);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
        TLOAD(v295, v308);
        // pto: %cos_tile_inline8775__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %cos_tile_inline8775__tile
        ;
        uint64_t v310 = (uint64_t) v38;
        TASSIGN(v309, v310);
        // pto: %freqs_cos__ssa_v0_pview
        ;
        __gm__ float* v311 = PTOAS__GLOBAL_TENSOR_DATA(v127);
        // pto: %freqs_cos__ssa_v0_pview
        ;
        const int64_t v312 = 0;
        // pto: %freqs_cos__ssa_v0_pview
        ;
        const int64_t v313 = 64;
        // pto: %freqs_cos__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 8, 64> v314 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %freqs_cos__ssa_v0_pview
        ;
        pto::Stride<512, 512, 512, 64, 1> v315 = pto::Stride<512, 512, 512, 64, 1>();
        // pto: %freqs_cos__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v316 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v311 + (v312 + v297 * v313), v314, v315);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
        TLOAD(v309, v316);
        // pto: %sin_tile_inline8776__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %sin_tile_inline8776__tile
        ;
        uint64_t v318 = (uint64_t) v39;
        TASSIGN(v317, v318);
        // pto: %idx_sin_signed__ssa_v1_pview
        ;
        __gm__ float* v319 = PTOAS__GLOBAL_TENSOR_DATA(v136);
        // pto: %idx_sin_signed__ssa_v1_pview
        ;
        const int64_t v320 = 0;
        // pto: %idx_sin_signed__ssa_v1_pview
        ;
        const int64_t v321 = 64;
        // pto: %idx_sin_signed__ssa_v1_pview
        ;
        pto::Shape<1, 1, 1, 8, 64> v322 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %idx_sin_signed__ssa_v1_pview
        ;
        pto::Stride<512, 512, 512, 64, 1> v323 = pto::Stride<512, 512, 512, 64, 1>();
        // pto: %idx_sin_signed__ssa_v1_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v324 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v319 + (v320 + v297 * v321), v322, v323);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
        TLOAD(v317, v324);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        for (int64_t v325 = v90; v325 < v91; v325 += v81) {
          // pto: %223, %224
          ;
          int64_t v326 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v285 + (uint64_t) v325) * (uint64_t) v72);
          // pto: %226, %225, %227
          ;
          int64_t v327 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v285 + (uint64_t) ((int64_t) (uint64_t) v325 + (uint64_t) v70)) * (uint64_t) v72);
          // pto: %6
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
          // pto: %6
          ;
          uint64_t v329 = (uint64_t) v40;
          TASSIGN(v328, v329);
          // pto: %228
          ;
          int64_t v330 = v326 < v90 ? v90 : v326;
          // pto: %idx_wq_b_scale__ssa_v0_pview
          ;
          __gm__ float* v331 = PTOAS__GLOBAL_TENSOR_DATA(v118);
          // pto: %idx_wq_b_scale__ssa_v0_pview
          ;
          const int64_t v332 = 0;
          // pto: %idx_wq_b_scale__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 1, 128> v333 = pto::Shape<1, 1, 1, 1, 128>();
          // pto: %idx_wq_b_scale__ssa_v0_pview
          ;
          pto::Stride<128, 128, 128, 128, 1> v334 = pto::Stride<128, 128, 128, 128, 1>();
          // pto: %idx_wq_b_scale__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v335 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v331 + (v332 + v330), v333, v334);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          TLOAD(v328, v335);
          // pto: %7
          ;
          Tile<TileType::Vec, int32_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v336 = Tile<TileType::Vec, int32_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
          // pto: %7
          ;
          uint64_t v337 = (uint64_t) v33;
          TASSIGN(v336, v337);
          // pto: %idx_acc_read_inline3909__ssa_v0_pview
          ;
          __gm__ int32_t* v338 = PTOAS__GLOBAL_TENSOR_DATA(v180);
          // pto: %idx_acc_read_inline3909__ssa_v0_pview
          ;
          const int64_t v339 = 0;
          // pto: %idx_acc_read_inline3909__ssa_v0_pview
          ;
          const int64_t v340 = 8192;
          // pto: %idx_acc_read_inline3909__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 8, 128> v341 = pto::Shape<1, 1, 1, 8, 128>();
          // pto: %idx_acc_read_inline3909__ssa_v0_pview
          ;
          pto::Stride<65536, 65536, 65536, 8192, 1> v342 = pto::Stride<65536, 65536, 65536, 8192, 1>();
          // pto: %idx_acc_read_inline3909__ssa_v0_pview
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v343 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v338 + (v339 + v297 * v340 + v330), v341, v342);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
          TLOAD(v336, v343);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
          // pto: %8
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v344 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
          // pto: %8
          ;
          uint64_t v345 = (uint64_t) v41;
          TASSIGN(v344, v345);
          // pto: %231
          ;
          int64_t v346 = v327 < v90 ? v90 : v327;
          // pto: %232
          ;
          __gm__ float* v347 = PTOAS__GLOBAL_TENSOR_DATA(v118);
          // pto: %232
          ;
          const int64_t v348 = 0;
          // pto: %232
          ;
          pto::Shape<1, 1, 1, 1, 128> v349 = pto::Shape<1, 1, 1, 1, 128>();
          // pto: %232
          ;
          pto::Stride<128, 128, 128, 128, 1> v350 = pto::Stride<128, 128, 128, 128, 1>();
          // pto: %232
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v351 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v347 + (v348 + v346), v349, v350);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
          TLOAD(v344, v351);
          // pto: %9
          ;
          Tile<TileType::Vec, int32_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v352 = Tile<TileType::Vec, int32_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
          // pto: %9
          ;
          uint64_t v353 = (uint64_t) v34;
          TASSIGN(v352, v353);
          // pto: %235
          ;
          __gm__ int32_t* v354 = PTOAS__GLOBAL_TENSOR_DATA(v180);
          // pto: %235
          ;
          const int64_t v355 = 0;
          // pto: %235
          ;
          const int64_t v356 = 8192;
          // pto: %235
          ;
          pto::Shape<1, 1, 1, 8, 128> v357 = pto::Shape<1, 1, 1, 8, 128>();
          // pto: %235
          ;
          pto::Stride<65536, 65536, 65536, 8192, 1> v358 = pto::Stride<65536, 65536, 65536, 8192, 1>();
          // pto: %235
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v359 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v354 + (v355 + v297 * v356 + v346), v357, v358);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
          TLOAD(v352, v359);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          // pto: %wq_scale_inline8779__tile
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v360 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
          // pto: %wq_scale_inline8779__tile
          ;
          uint64_t v361 = (uint64_t) v40;
          TASSIGN(v360, v361);
          // pto: %acc_fp32_inline8780__tile
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v362 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
          // pto: %acc_fp32_inline8780__tile
          ;
          uint64_t v363 = (uint64_t) v33;
          TASSIGN(v362, v363);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
          RoundMode v364 = RoundMode::CAST_NONE;
          SaturationMode v365 = SaturationMode::ON;
          TCVT(v362, v336, v364, v365);
          // pto: %10
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v366 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
          // pto: %10
          ;
          uint64_t v367 = (uint64_t) v35;
          TASSIGN(v366, v367);
          TEXPANDS(v366, v85);
          // pto: %11
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v368 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
          // pto: %11
          ;
          uint64_t v369 = (uint64_t) v35;
          TASSIGN(v368, v369);
          pipe_barrier(PIPE_V);
          TROWEXPANDMUL(v368, v366, v295);
          // pto: %qr_dequant_scale_inline8781__tile
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v370 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
          // pto: %qr_dequant_scale_inline8781__tile
          ;
          uint64_t v371 = (uint64_t) v35;
          TASSIGN(v370, v371);
          pipe_barrier(PIPE_V);
          TCOLEXPANDMUL(v370, v368, v360);
          // pto: %qr_dequant_inline8782__tile
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v372 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
          // pto: %qr_dequant_inline8782__tile
          ;
          uint64_t v373 = (uint64_t) v33;
          TASSIGN(v372, v373);
          pipe_barrier(PIPE_V);
          TMUL(v372, v362, v370);
          // pto: %12
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v374 = Tile<TileType::Vec, bfloat16_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
          // pto: %12
          ;
          uint64_t v375 = (uint64_t) v35;
          TASSIGN(v374, v375);
          pipe_barrier(PIPE_V);
          RoundMode v376 = RoundMode::CAST_RINT;
          SaturationMode v377 = SaturationMode::ON;
          TCVT(v374, v372, v376, v377);
          // pto: %qr_dequant_v1_inline8783__tile
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v378 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
          // pto: %qr_dequant_v1_inline8783__tile
          ;
          uint64_t v379 = (uint64_t) v33;
          TASSIGN(v378, v379);
          pipe_barrier(PIPE_V);
          RoundMode v380 = RoundMode::CAST_ROUND;
          SaturationMode v381 = SaturationMode::ON;
          TCVT(v378, v374, v380, v381);
          // pto: %13
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v382 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
          // pto: %13
          ;
          uint64_t v383 = (uint64_t) v33;
          TASSIGN(v382, v383);
          // pto: %slice_view
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v384;
          // pto: %slice_view
          ;
          uint64_t v385 = (uint64_t) v33;
          TASSIGN(v384, v385);
          // pto: %qr_nope_bf16_inline8784__tile
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v386 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
          // pto: %qr_nope_bf16_inline8784__tile
          ;
          uint64_t v387 = (uint64_t) v40;
          TASSIGN(v386, v387);
          pipe_barrier(PIPE_V);
          RoundMode v388 = RoundMode::CAST_RINT;
          SaturationMode v389 = SaturationMode::ON;
          TCVT(v386, v384, v388, v389);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
          // pto: %qr_rope_slice_inline8785__tile
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v390 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
          // pto: %qr_rope_slice_inline8785__tile
          ;
          uint64_t v391 = (uint64_t) v42;
          TASSIGN(v390, v391);
          // pto: %236
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v392;
          // pto: %236
          ;
          uint64_t v393 = (uint64_t) v42;
          TASSIGN(v392, v393);
          // pto: %gather_acc_init
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v394 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
          // pto: %gather_acc_init
          ;
          uint64_t v395 = (uint64_t) v35;
          TASSIGN(v394, v395);
          for (int64_t v396 = v90; v396 < v83; v396 += v70) {
            // pto: %gather_inp_row
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v397 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %gather_inp_row
            ;
            uint64_t v398 = (uint64_t) v33;
            TASSIGN(v397, v398);
            // pto: %237
            ;
            Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v399;
            // pto: %237
            ;
            uint64_t v400 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v396 * (uint64_t) v32) + (uint64_t) v42);
            TASSIGN(v399, v400);
            // pto: %gather_idx_row
            ;
            Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v401 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %gather_idx_row
            ;
            uint64_t v402 = (uint64_t) v36;
            TASSIGN(v401, v402);
            // pto: %238
            ;
            int64_t v403 = (int64_t) ((uint64_t) v396 * (uint64_t) v42);
            // pto: %238
            ;
            Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v404;
            // pto: %238
            ;
            uint64_t v405 = (uint64_t) ((int64_t) (uint64_t) v403 + (uint64_t) v36);
            TASSIGN(v404, v405);
            // pto: %gather_row_tmp
            ;
            Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v406 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %gather_row_tmp
            ;
            uint64_t v407 = (uint64_t) v43;
            TASSIGN(v406, v407);
            // pto: %gather_row
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v408 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %gather_row
            ;
            uint64_t v409 = (uint64_t) v44;
            TASSIGN(v408, v409);
            pipe_barrier(PIPE_V);
            TGATHER(v408, v399, v404, v406);
            // pto: %assemble_view
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v410;
            // pto: %assemble_view
            ;
            uint64_t v411 = (uint64_t) ((int64_t) (uint64_t) v403 + (uint64_t) v35);
            TASSIGN(v410, v411);
            pipe_barrier(PIPE_V);
            TMOV(v410, v408);
          };
          // pto: %qr_swapped_inline8786__tile
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v412 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
          // pto: %qr_swapped_inline8786__tile
          ;
          uint64_t v413 = (uint64_t) v35;
          TASSIGN(v412, v413);
          // pto: %14
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v414 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
          // pto: %14
          ;
          uint64_t v415 = (uint64_t) v33;
          TASSIGN(v414, v415);
          pipe_barrier(PIPE_V);
          TMUL(v414, v392, v309);
          // pto: %15
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v416 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
          // pto: %15
          ;
          uint64_t v417 = (uint64_t) v35;
          TASSIGN(v416, v417);
          TMUL(v416, v412, v317);
          // pto: %rope_rot_inline8787__tile
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v418 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
          // pto: %rope_rot_inline8787__tile
          ;
          uint64_t v419 = (uint64_t) v33;
          TASSIGN(v418, v419);
          pipe_barrier(PIPE_V);
          TADD(v418, v414, v416);
          // pto: %rope_bf16_inline8788__tile
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v420 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
          // pto: %rope_bf16_inline8788__tile
          ;
          uint64_t v421 = (uint64_t) v33;
          TASSIGN(v420, v421);
          pipe_barrier(PIPE_V);
          RoundMode v422 = RoundMode::CAST_RINT;
          SaturationMode v423 = SaturationMode::ON;
          TCVT(v420, v418, v422, v423);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
          // pto: %idx_bf__iter_v3_pview
          ;
          __gm__ bfloat16_t* v424 = PTOAS__GLOBAL_TENSOR_DATA(v188);
          // pto: %idx_bf__iter_v3_pview
          ;
          const int64_t v425 = 0;
          // pto: %idx_bf__iter_v3_pview
          ;
          const int64_t v426 = 8192;
          // pto: %idx_bf__iter_v3_pview
          ;
          pto::Shape<1, 1, 1, 8, 64> v427 = pto::Shape<1, 1, 1, 8, 64>();
          // pto: %idx_bf__iter_v3_pview
          ;
          pto::Stride<65536, 65536, 65536, 8192, 1> v428 = pto::Stride<65536, 65536, 65536, 8192, 1>();
          // pto: %idx_bf__iter_v3_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v429 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v424 + (v425 + v297 * v426 + v330), v427, v428);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
          pipe_barrier(PIPE_MTE3);
          TSTORE(v429, v386);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          // pto: %243
          ;
          int64_t v430 = (int64_t) ((uint64_t) v326 + (uint64_t) v73);
          // pto: %244
          ;
          int64_t v431 = v430 < v90 ? v90 : v430;
          // pto: %idx_bf__tile_pview
          ;
          __gm__ bfloat16_t* v432 = PTOAS__GLOBAL_TENSOR_DATA(v188);
          // pto: %idx_bf__tile_pview
          ;
          const int64_t v433 = 0;
          // pto: %idx_bf__tile_pview
          ;
          const int64_t v434 = 8192;
          // pto: %idx_bf__tile_pview
          ;
          pto::Shape<1, 1, 1, 8, 64> v435 = pto::Shape<1, 1, 1, 8, 64>();
          // pto: %idx_bf__tile_pview
          ;
          pto::Stride<65536, 65536, 65536, 8192, 1> v436 = pto::Stride<65536, 65536, 65536, 8192, 1>();
          // pto: %idx_bf__tile_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v437 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v432 + (v433 + v297 * v434 + v431), v435, v436);
          pipe_barrier(PIPE_MTE3);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
          TSTORE(v437, v420);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
          // pto: %16
          ;
          Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v438 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
          // pto: %16
          ;
          uint64_t v439 = (uint64_t) v41;
          TASSIGN(v438, v439);
          // pto: %17
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v440 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
          // pto: %17
          ;
          uint64_t v441 = (uint64_t) v34;
          TASSIGN(v440, v441);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          RoundMode v442 = RoundMode::CAST_NONE;
          SaturationMode v443 = SaturationMode::ON;
          TCVT(v440, v352, v442, v443);
          // pto: %18
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v444 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
          // pto: %18
          ;
          uint64_t v445 = (uint64_t) v45;
          TASSIGN(v444, v445);
          TEXPANDS(v444, v85);
          // pto: %19
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v446 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
          // pto: %19
          ;
          uint64_t v447 = (uint64_t) v45;
          TASSIGN(v446, v447);
          pipe_barrier(PIPE_V);
          TROWEXPANDMUL(v446, v444, v295);
          // pto: %20
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v448 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
          // pto: %20
          ;
          uint64_t v449 = (uint64_t) v45;
          TASSIGN(v448, v449);
          pipe_barrier(PIPE_V);
          TCOLEXPANDMUL(v448, v446, v438);
          // pto: %21
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v450 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
          // pto: %21
          ;
          uint64_t v451 = (uint64_t) v34;
          TASSIGN(v450, v451);
          pipe_barrier(PIPE_V);
          TMUL(v450, v440, v448);
          // pto: %22
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v452 = Tile<TileType::Vec, bfloat16_t, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
          // pto: %22
          ;
          uint64_t v453 = (uint64_t) v45;
          TASSIGN(v452, v453);
          pipe_barrier(PIPE_V);
          RoundMode v454 = RoundMode::CAST_RINT;
          SaturationMode v455 = SaturationMode::ON;
          TCVT(v452, v450, v454, v455);
          // pto: %23
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v456 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
          // pto: %23
          ;
          uint64_t v457 = (uint64_t) v34;
          TASSIGN(v456, v457);
          pipe_barrier(PIPE_V);
          RoundMode v458 = RoundMode::CAST_ROUND;
          SaturationMode v459 = SaturationMode::ON;
          TCVT(v456, v452, v458, v459);
          // pto: %24
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v460 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
          // pto: %24
          ;
          uint64_t v461 = (uint64_t) v34;
          TASSIGN(v460, v461);
          // pto: %245
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v462;
          // pto: %245
          ;
          uint64_t v463 = (uint64_t) v34;
          TASSIGN(v462, v463);
          // pto: %25
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v464 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
          // pto: %25
          ;
          uint64_t v465 = (uint64_t) v41;
          TASSIGN(v464, v465);
          pipe_barrier(PIPE_V);
          RoundMode v466 = RoundMode::CAST_RINT;
          SaturationMode v467 = SaturationMode::ON;
          TCVT(v464, v462, v466, v467);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          // pto: %26
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v468 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
          // pto: %26
          ;
          uint64_t v469 = (uint64_t) v46;
          TASSIGN(v468, v469);
          // pto: %246
          ;
          Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v470;
          // pto: %246
          ;
          uint64_t v471 = (uint64_t) v46;
          TASSIGN(v470, v471);
          // pto: %27
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v472 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
          // pto: %27
          ;
          uint64_t v473 = (uint64_t) v45;
          TASSIGN(v472, v473);
          for (int64_t v474 = v90; v474 < v83; v474 += v70) {
            // pto: %28
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v475 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %28
            ;
            uint64_t v476 = (uint64_t) v34;
            TASSIGN(v475, v476);
            // pto: %248
            ;
            Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v477;
            // pto: %248
            ;
            uint64_t v478 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v474 * (uint64_t) v32) + (uint64_t) v46);
            TASSIGN(v477, v478);
            // pto: %29
            ;
            Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v479 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %29
            ;
            uint64_t v480 = (uint64_t) v36;
            TASSIGN(v479, v480);
            // pto: %249
            ;
            int64_t v481 = (int64_t) ((uint64_t) v474 * (uint64_t) v42);
            // pto: %249
            ;
            Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v482;
            // pto: %249
            ;
            uint64_t v483 = (uint64_t) ((int64_t) (uint64_t) v481 + (uint64_t) v36);
            TASSIGN(v482, v483);
            // pto: %30
            ;
            Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v484 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %30
            ;
            uint64_t v485 = (uint64_t) v47;
            TASSIGN(v484, v485);
            // pto: %31
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v486 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %31
            ;
            uint64_t v487 = (uint64_t) v48;
            TASSIGN(v486, v487);
            pipe_barrier(PIPE_V);
            TGATHER(v486, v477, v482, v484);
            // pto: %250
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v488;
            // pto: %250
            ;
            uint64_t v489 = (uint64_t) ((int64_t) (uint64_t) v481 + (uint64_t) v45);
            TASSIGN(v488, v489);
            pipe_barrier(PIPE_V);
            TMOV(v488, v486);
          };
          // pto: %33
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v490 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
          // pto: %33
          ;
          uint64_t v491 = (uint64_t) v45;
          TASSIGN(v490, v491);
          // pto: %34
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v492 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
          // pto: %34
          ;
          uint64_t v493 = (uint64_t) v34;
          TASSIGN(v492, v493);
          pipe_barrier(PIPE_V);
          TMUL(v492, v470, v309);
          // pto: %35
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v494 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
          // pto: %35
          ;
          uint64_t v495 = (uint64_t) v45;
          TASSIGN(v494, v495);
          TMUL(v494, v490, v317);
          // pto: %36
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v496 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
          // pto: %36
          ;
          uint64_t v497 = (uint64_t) v34;
          TASSIGN(v496, v497);
          pipe_barrier(PIPE_V);
          TADD(v496, v492, v494);
          // pto: %37
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v498 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
          // pto: %37
          ;
          uint64_t v499 = (uint64_t) v34;
          TASSIGN(v498, v499);
          pipe_barrier(PIPE_V);
          RoundMode v500 = RoundMode::CAST_RINT;
          SaturationMode v501 = SaturationMode::ON;
          TCVT(v498, v496, v500, v501);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
          // pto: %254
          ;
          __gm__ bfloat16_t* v502 = PTOAS__GLOBAL_TENSOR_DATA(v188);
          // pto: %254
          ;
          const int64_t v503 = 0;
          // pto: %254
          ;
          const int64_t v504 = 8192;
          // pto: %254
          ;
          pto::Shape<1, 1, 1, 8, 64> v505 = pto::Shape<1, 1, 1, 8, 64>();
          // pto: %254
          ;
          pto::Stride<65536, 65536, 65536, 8192, 1> v506 = pto::Stride<65536, 65536, 65536, 8192, 1>();
          // pto: %254
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v507 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v502 + (v503 + v297 * v504 + v346), v505, v506);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
          pipe_barrier(PIPE_MTE3);
          TSTORE(v507, v464);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
          // pto: %257
          ;
          int64_t v508 = (int64_t) ((uint64_t) v327 + (uint64_t) v73);
          // pto: %258
          ;
          int64_t v509 = v508 < v90 ? v90 : v508;
          // pto: %259
          ;
          __gm__ bfloat16_t* v510 = PTOAS__GLOBAL_TENSOR_DATA(v188);
          // pto: %259
          ;
          const int64_t v511 = 0;
          // pto: %259
          ;
          const int64_t v512 = 8192;
          // pto: %259
          ;
          pto::Shape<1, 1, 1, 8, 64> v513 = pto::Shape<1, 1, 1, 8, 64>();
          // pto: %259
          ;
          pto::Stride<65536, 65536, 65536, 8192, 1> v514 = pto::Stride<65536, 65536, 65536, 8192, 1>();
          // pto: %259
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND> v515 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<65536, 65536, 65536, 8192, 1>, pto::Layout::ND>(v510 + (v511 + v297 * v512 + v509), v513, v514);
          pipe_barrier(PIPE_MTE3);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
          TSTORE(v515, v498);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        };
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      } else {
        // pto: %tail_swap_idx_inline8789__tile
        ;
        Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v516 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
        // pto: %tail_swap_idx_inline8789__tile
        ;
        uint64_t v517 = (uint64_t) v36;
        TASSIGN(v516, v517);
        // pto: %260
        ;
        uint64_t v518 = (uint64_t) v36;
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        for (int64_t v519 = v294; v519 < v27; v519 += v70) {
          // pto: %tail_qr_scale_value_inline8791__tile
          ;
          float v520 = (v12)[v519];
          // pto: %tail_cos_tile_inline8792__tile
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v521 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
          // pto: %tail_cos_tile_inline8792__tile
          ;
          uint64_t v522 = (uint64_t) v38;
          TASSIGN(v521, v522);
          // pto: %261
          ;
          int64_t v523 = v519 < v90 ? v90 : v519;
          // pto: %262
          ;
          __gm__ float* v524 = PTOAS__GLOBAL_TENSOR_DATA(v127);
          // pto: %262
          ;
          const int64_t v525 = 0;
          // pto: %262
          ;
          const int64_t v526 = 64;
          // pto: %262
          ;
          pto::Shape<1, 1, 1, 1, 64> v527 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %262
          ;
          pto::Stride<64, 64, 64, 64, 1> v528 = pto::Stride<64, 64, 64, 64, 1>();
          // pto: %262
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v529 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v524 + (v525 + v523 * v526), v527, v528);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          TLOAD(v521, v529);
          // pto: %tail_sin_tile_inline8793__tile
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v530 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
          // pto: %tail_sin_tile_inline8793__tile
          ;
          uint64_t v531 = (uint64_t) v39;
          TASSIGN(v530, v531);
          // pto: %264
          ;
          __gm__ float* v532 = PTOAS__GLOBAL_TENSOR_DATA(v136);
          // pto: %264
          ;
          const int64_t v533 = 0;
          // pto: %264
          ;
          const int64_t v534 = 64;
          // pto: %264
          ;
          pto::Shape<1, 1, 1, 1, 64> v535 = pto::Shape<1, 1, 1, 1, 64>();
          // pto: %264
          ;
          pto::Stride<64, 64, 64, 64, 1> v536 = pto::Stride<64, 64, 64, 64, 1>();
          // pto: %264
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v537 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v532 + (v533 + v523 * v534), v535, v536);
          pipe_barrier(PIPE_ALL);
          TLOAD(v530, v537);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
          for (int64_t v538 = v90; v538 < v91; v538 += v81) {
            // pto: %265, %266
            ;
            int64_t v539 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v285 + (uint64_t) v538) * (uint64_t) v72);
            // pto: %268, %267, %269
            ;
            int64_t v540 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v285 + (uint64_t) ((int64_t) (uint64_t) v538 + (uint64_t) v70)) * (uint64_t) v72);
            // pto: %38
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v541 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
            // pto: %38
            ;
            uint64_t v542 = (uint64_t) v33;
            TASSIGN(v541, v542);
            // pto: %270
            ;
            int64_t v543 = v539 < v90 ? v90 : v539;
            // pto: %271
            ;
            __gm__ float* v544 = PTOAS__GLOBAL_TENSOR_DATA(v118);
            // pto: %271
            ;
            const int64_t v545 = 0;
            // pto: %271
            ;
            pto::Shape<1, 1, 1, 1, 128> v546 = pto::Shape<1, 1, 1, 1, 128>();
            // pto: %271
            ;
            pto::Stride<128, 128, 128, 128, 1> v547 = pto::Stride<128, 128, 128, 128, 1>();
            // pto: %271
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v548 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v544 + (v545 + v543), v546, v547);
            wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
            TLOAD(v541, v548);
            // pto: %39
            ;
            Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v549 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
            // pto: %39
            ;
            uint64_t v550 = (uint64_t) v34;
            TASSIGN(v549, v550);
            // pto: %274
            ;
            __gm__ int32_t* v551 = PTOAS__GLOBAL_TENSOR_DATA(v180);
            // pto: %274
            ;
            const int64_t v552 = 0;
            // pto: %274
            ;
            const int64_t v553 = 8192;
            // pto: %274
            ;
            pto::Shape<1, 1, 1, 1, 128> v554 = pto::Shape<1, 1, 1, 1, 128>();
            // pto: %274
            ;
            pto::Stride<8192, 8192, 8192, 8192, 1> v555 = pto::Stride<8192, 8192, 8192, 8192, 1>();
            // pto: %274
            ;
            GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v556 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v551 + (v552 + v523 * v553 + v543), v554, v555);
            TLOAD(v549, v556);
            set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
            // pto: %40
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v557 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
            // pto: %40
            ;
            uint64_t v558 = (uint64_t) v35;
            TASSIGN(v557, v558);
            // pto: %275
            ;
            int64_t v559 = v540 < v90 ? v90 : v540;
            // pto: %276
            ;
            __gm__ float* v560 = PTOAS__GLOBAL_TENSOR_DATA(v118);
            // pto: %276
            ;
            const int64_t v561 = 0;
            // pto: %276
            ;
            pto::Shape<1, 1, 1, 1, 128> v562 = pto::Shape<1, 1, 1, 1, 128>();
            // pto: %276
            ;
            pto::Stride<128, 128, 128, 128, 1> v563 = pto::Stride<128, 128, 128, 128, 1>();
            // pto: %276
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND> v564 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<128, 128, 128, 128, 1>, pto::Layout::ND>(v560 + (v561 + v559), v562, v563);
            wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
            TLOAD(v557, v564);
            // pto: %41
            ;
            Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v565 = Tile<TileType::Vec, int32_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
            // pto: %41
            ;
            uint64_t v566 = (uint64_t) v45;
            TASSIGN(v565, v566);
            // pto: %279
            ;
            __gm__ int32_t* v567 = PTOAS__GLOBAL_TENSOR_DATA(v180);
            // pto: %279
            ;
            const int64_t v568 = 0;
            // pto: %279
            ;
            const int64_t v569 = 8192;
            // pto: %279
            ;
            pto::Shape<1, 1, 1, 1, 128> v570 = pto::Shape<1, 1, 1, 1, 128>();
            // pto: %279
            ;
            pto::Stride<8192, 8192, 8192, 8192, 1> v571 = pto::Stride<8192, 8192, 8192, 8192, 1>();
            // pto: %279
            ;
            GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v572 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 128>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v567 + (v568 + v523 * v569 + v559), v570, v571);
            TLOAD(v565, v572);
            set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
            // pto: %tail_wq_scale_inline8796__tile
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v573 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
            // pto: %tail_wq_scale_inline8796__tile
            ;
            uint64_t v574 = (uint64_t) v33;
            TASSIGN(v573, v574);
            // pto: %tail_acc_fp32_inline8797__tile
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v575 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
            // pto: %tail_acc_fp32_inline8797__tile
            ;
            uint64_t v576 = (uint64_t) v34;
            TASSIGN(v575, v576);
            wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
            RoundMode v577 = RoundMode::CAST_NONE;
            SaturationMode v578 = SaturationMode::ON;
            TCVT(v575, v549, v577, v578);
            // pto: %tail_qr_dequant_scale_inline8798__tile
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v579 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
            // pto: %tail_qr_dequant_scale_inline8798__tile
            ;
            uint64_t v580 = (uint64_t) v33;
            TASSIGN(v579, v580);
            TMULS(v579, v573, v520);
            // pto: %tail_qr_dequant_inline8799__tile
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v581 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
            // pto: %tail_qr_dequant_inline8799__tile
            ;
            uint64_t v582 = (uint64_t) v33;
            TASSIGN(v581, v582);
            pipe_barrier(PIPE_V);
            TMUL(v581, v575, v579);
            // pto: %42
            ;
            Tile<TileType::Vec, bfloat16_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v583 = Tile<TileType::Vec, bfloat16_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
            // pto: %42
            ;
            uint64_t v584 = (uint64_t) v34;
            TASSIGN(v583, v584);
            pipe_barrier(PIPE_V);
            RoundMode v585 = RoundMode::CAST_RINT;
            SaturationMode v586 = SaturationMode::ON;
            TCVT(v583, v581, v585, v586);
            // pto: %tail_qr_dequant_v1_inline8800__tile
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v587 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
            // pto: %tail_qr_dequant_v1_inline8800__tile
            ;
            uint64_t v588 = (uint64_t) v33;
            TASSIGN(v587, v588);
            pipe_barrier(PIPE_V);
            RoundMode v589 = RoundMode::CAST_ROUND;
            SaturationMode v590 = SaturationMode::ON;
            TCVT(v587, v583, v589, v590);
            // pto: %43
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v591 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %43
            ;
            uint64_t v592 = (uint64_t) v33;
            TASSIGN(v591, v592);
            // pto: %280
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v593;
            // pto: %280
            ;
            uint64_t v594 = (uint64_t) v33;
            TASSIGN(v593, v594);
            // pto: %tail_qr_nope_bf16_inline8801__tile
            ;
            Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v595 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %tail_qr_nope_bf16_inline8801__tile
            ;
            uint64_t v596 = (uint64_t) v47;
            TASSIGN(v595, v596);
            pipe_barrier(PIPE_V);
            RoundMode v597 = RoundMode::CAST_RINT;
            SaturationMode v598 = SaturationMode::ON;
            TCVT(v595, v593, v597, v598);
            set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
            // pto: %tail_qr_rope_slice_inline8802__tile
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v599 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %tail_qr_rope_slice_inline8802__tile
            ;
            uint64_t v600 = (uint64_t) v42;
            TASSIGN(v599, v600);
            // pto: %281
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v601;
            // pto: %281
            ;
            uint64_t v602 = (uint64_t) v42;
            TASSIGN(v601, v602);
            // pto: %44
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v603 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %44
            ;
            uint64_t v604 = (uint64_t) v34;
            TASSIGN(v603, v604);
            // pto: %45
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v605 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %45
            ;
            uint64_t v606 = (uint64_t) v33;
            TASSIGN(v605, v606);
            // pto: %282
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v607;
            // pto: %282
            ;
            uint64_t v608 = (uint64_t) v42;
            TASSIGN(v607, v608);
            // pto: %46
            ;
            Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v609 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %46
            ;
            uint64_t v610 = (uint64_t) v36;
            TASSIGN(v609, v610);
            // pto: %283
            ;
            Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v611;
            // pto: %283
            ;
            uint64_t v612 = (uint64_t) v36;
            TASSIGN(v611, v612);
            // pto: %47
            ;
            Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v613 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %47
            ;
            uint64_t v614 = (uint64_t) v40;
            TASSIGN(v613, v614);
            // pto: %48
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v615 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %48
            ;
            uint64_t v616 = (uint64_t) v41;
            TASSIGN(v615, v616);
            TGATHER(v615, v607, v611, v613);
            // pto: %284
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v617;
            // pto: %284
            ;
            uint64_t v618 = (uint64_t) v34;
            TASSIGN(v617, v618);
            pipe_barrier(PIPE_V);
            TMOV(v617, v615);
            // pto: %tail_qr_swapped_inline8803__tile
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v619 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %tail_qr_swapped_inline8803__tile
            ;
            uint64_t v620 = (uint64_t) v34;
            TASSIGN(v619, v620);
            // pto: %50
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v621 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %50
            ;
            uint64_t v622 = (uint64_t) v33;
            TASSIGN(v621, v622);
            TMUL(v621, v601, v521);
            // pto: %51
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v623 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %51
            ;
            uint64_t v624 = (uint64_t) v34;
            TASSIGN(v623, v624);
            pipe_barrier(PIPE_V);
            TMUL(v623, v619, v530);
            // pto: %tail_rope_rot_inline8804__tile
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v625 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %tail_rope_rot_inline8804__tile
            ;
            uint64_t v626 = (uint64_t) v33;
            TASSIGN(v625, v626);
            pipe_barrier(PIPE_V);
            TADD(v625, v621, v623);
            // pto: %tail_rope_bf16_inline8805__tile
            ;
            Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v627 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %tail_rope_bf16_inline8805__tile
            ;
            uint64_t v628 = (uint64_t) v33;
            TASSIGN(v627, v628);
            pipe_barrier(PIPE_V);
            RoundMode v629 = RoundMode::CAST_RINT;
            SaturationMode v630 = SaturationMode::ON;
            TCVT(v627, v625, v629, v630);
            set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
            // pto: %idx_bf__iter_v9_pview
            ;
            __gm__ bfloat16_t* v631 = PTOAS__GLOBAL_TENSOR_DATA(v188);
            // pto: %idx_bf__iter_v9_pview
            ;
            const int64_t v632 = 0;
            // pto: %idx_bf__iter_v9_pview
            ;
            const int64_t v633 = 8192;
            // pto: %idx_bf__iter_v9_pview
            ;
            pto::Shape<1, 1, 1, 1, 64> v634 = pto::Shape<1, 1, 1, 1, 64>();
            // pto: %idx_bf__iter_v9_pview
            ;
            pto::Stride<8192, 8192, 8192, 8192, 1> v635 = pto::Stride<8192, 8192, 8192, 8192, 1>();
            // pto: %idx_bf__iter_v9_pview
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v636 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v631 + (v632 + v523 * v633 + v543), v634, v635);
            wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
            pipe_barrier(PIPE_MTE3);
            TSTORE(v636, v595);
            // pto: %290
            ;
            int64_t v637 = (int64_t) ((uint64_t) v539 + (uint64_t) v73);
            // pto: %291
            ;
            int64_t v638 = v637 < v90 ? v90 : v637;
            // pto: %292
            ;
            __gm__ bfloat16_t* v639 = PTOAS__GLOBAL_TENSOR_DATA(v188);
            // pto: %292
            ;
            const int64_t v640 = 0;
            // pto: %292
            ;
            const int64_t v641 = 8192;
            // pto: %292
            ;
            pto::Shape<1, 1, 1, 1, 64> v642 = pto::Shape<1, 1, 1, 1, 64>();
            // pto: %292
            ;
            pto::Stride<8192, 8192, 8192, 8192, 1> v643 = pto::Stride<8192, 8192, 8192, 8192, 1>();
            // pto: %292
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v644 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v639 + (v640 + v523 * v641 + v638), v642, v643);
            pipe_barrier(PIPE_MTE3);
            wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
            TSTORE(v644, v627);
            set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
            // pto: %52
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v645 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
            // pto: %52
            ;
            uint64_t v646 = (uint64_t) v35;
            TASSIGN(v645, v646);
            // pto: %53
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v647 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
            // pto: %53
            ;
            uint64_t v648 = (uint64_t) v45;
            TASSIGN(v647, v648);
            wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
            RoundMode v649 = RoundMode::CAST_NONE;
            SaturationMode v650 = SaturationMode::ON;
            TCVT(v647, v565, v649, v650);
            // pto: %54
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v651 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
            // pto: %54
            ;
            uint64_t v652 = (uint64_t) v35;
            TASSIGN(v651, v652);
            TMULS(v651, v645, v520);
            // pto: %55
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v653 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
            // pto: %55
            ;
            uint64_t v654 = (uint64_t) v35;
            TASSIGN(v653, v654);
            pipe_barrier(PIPE_V);
            TMUL(v653, v647, v651);
            // pto: %56
            ;
            Tile<TileType::Vec, bfloat16_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v655 = Tile<TileType::Vec, bfloat16_t, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
            // pto: %56
            ;
            uint64_t v656 = (uint64_t) v45;
            TASSIGN(v655, v656);
            pipe_barrier(PIPE_V);
            RoundMode v657 = RoundMode::CAST_RINT;
            SaturationMode v658 = SaturationMode::ON;
            TCVT(v655, v653, v657, v658);
            // pto: %57
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v659 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v72);
            // pto: %57
            ;
            uint64_t v660 = (uint64_t) v35;
            TASSIGN(v659, v660);
            pipe_barrier(PIPE_V);
            RoundMode v661 = RoundMode::CAST_ROUND;
            SaturationMode v662 = SaturationMode::ON;
            TCVT(v659, v655, v661, v662);
            // pto: %58
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v663 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %58
            ;
            uint64_t v664 = (uint64_t) v35;
            TASSIGN(v663, v664);
            // pto: %293
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v665;
            // pto: %293
            ;
            uint64_t v666 = (uint64_t) v35;
            TASSIGN(v665, v666);
            // pto: %59
            ;
            Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v667 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %59
            ;
            uint64_t v668 = (uint64_t) v48;
            TASSIGN(v667, v668);
            pipe_barrier(PIPE_V);
            RoundMode v669 = RoundMode::CAST_RINT;
            SaturationMode v670 = SaturationMode::ON;
            TCVT(v667, v665, v669, v670);
            set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
            // pto: %60
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v671 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %60
            ;
            uint64_t v672 = (uint64_t) v49;
            TASSIGN(v671, v672);
            // pto: %294
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v673;
            // pto: %294
            ;
            uint64_t v674 = (uint64_t) v49;
            TASSIGN(v673, v674);
            // pto: %61
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v675 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %61
            ;
            uint64_t v676 = (uint64_t) v45;
            TASSIGN(v675, v676);
            // pto: %62
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v677 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %62
            ;
            uint64_t v678 = (uint64_t) v35;
            TASSIGN(v677, v678);
            // pto: %295
            ;
            Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v679;
            // pto: %295
            ;
            uint64_t v680 = (uint64_t) v49;
            TASSIGN(v679, v680);
            // pto: %63
            ;
            Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v681 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %63
            ;
            uint64_t v682 = (uint64_t) v36;
            TASSIGN(v681, v682);
            // pto: %296
            ;
            Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v683;
            // pto: %296
            ;
            uint64_t v684 = (uint64_t) v36;
            TASSIGN(v683, v684);
            // pto: %64
            ;
            Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v685 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %64
            ;
            uint64_t v686 = (uint64_t) v43;
            TASSIGN(v685, v686);
            // pto: %65
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v687 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %65
            ;
            uint64_t v688 = (uint64_t) v44;
            TASSIGN(v687, v688);
            TGATHER(v687, v679, v683, v685);
            // pto: %297
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v689;
            // pto: %297
            ;
            uint64_t v690 = (uint64_t) v45;
            TASSIGN(v689, v690);
            pipe_barrier(PIPE_V);
            TMOV(v689, v687);
            // pto: %67
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v691 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %67
            ;
            uint64_t v692 = (uint64_t) v45;
            TASSIGN(v691, v692);
            // pto: %68
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v693 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %68
            ;
            uint64_t v694 = (uint64_t) v35;
            TASSIGN(v693, v694);
            TMUL(v693, v673, v521);
            // pto: %69
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v695 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %69
            ;
            uint64_t v696 = (uint64_t) v45;
            TASSIGN(v695, v696);
            pipe_barrier(PIPE_V);
            TMUL(v695, v691, v530);
            // pto: %70
            ;
            Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v697 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %70
            ;
            uint64_t v698 = (uint64_t) v35;
            TASSIGN(v697, v698);
            pipe_barrier(PIPE_V);
            TADD(v697, v693, v695);
            // pto: %71
            ;
            Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v699 = Tile<TileType::Vec, bfloat16_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
            // pto: %71
            ;
            uint64_t v700 = (uint64_t) v35;
            TASSIGN(v699, v700);
            pipe_barrier(PIPE_V);
            RoundMode v701 = RoundMode::CAST_RINT;
            SaturationMode v702 = SaturationMode::ON;
            TCVT(v699, v697, v701, v702);
            set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
            // pto: %301
            ;
            __gm__ bfloat16_t* v703 = PTOAS__GLOBAL_TENSOR_DATA(v188);
            // pto: %301
            ;
            const int64_t v704 = 0;
            // pto: %301
            ;
            const int64_t v705 = 8192;
            // pto: %301
            ;
            pto::Shape<1, 1, 1, 1, 64> v706 = pto::Shape<1, 1, 1, 1, 64>();
            // pto: %301
            ;
            pto::Stride<8192, 8192, 8192, 8192, 1> v707 = pto::Stride<8192, 8192, 8192, 8192, 1>();
            // pto: %301
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v708 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v703 + (v704 + v523 * v705 + v559), v706, v707);
            wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
            pipe_barrier(PIPE_MTE3);
            TSTORE(v708, v667);
            // pto: %304
            ;
            int64_t v709 = (int64_t) ((uint64_t) v540 + (uint64_t) v73);
            // pto: %305
            ;
            int64_t v710 = v709 < v90 ? v90 : v709;
            // pto: %306
            ;
            __gm__ bfloat16_t* v711 = PTOAS__GLOBAL_TENSOR_DATA(v188);
            // pto: %306
            ;
            const int64_t v712 = 0;
            // pto: %306
            ;
            const int64_t v713 = 8192;
            // pto: %306
            ;
            pto::Shape<1, 1, 1, 1, 64> v714 = pto::Shape<1, 1, 1, 1, 64>();
            // pto: %306
            ;
            pto::Stride<8192, 8192, 8192, 8192, 1> v715 = pto::Stride<8192, 8192, 8192, 8192, 1>();
            // pto: %306
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND> v716 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<8192, 8192, 8192, 8192, 1>, pto::Layout::ND>(v711 + (v712 + v523 * v713 + v710), v714, v715);
            pipe_barrier(PIPE_MTE3);
            wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
            TSTORE(v716, v699);
            set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          };
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
        };
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  }
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %307
  int64_t v717 = (int64_t) ((uint64_t) v27 * (uint64_t) v73);
  // pto: %308
  const int64_t v718 = 1;
  // pto: %308
  const int64_t v719 = 0;
  // pto: %308
  int64_t v720 = v717 / v73;
  // pto: %308
  bool v721 = v717 < v719;
  // pto: %308
  bool v722 = v73 < v719;
  // pto: %308
  bool v723 = v721 == v722;
  // pto: %308
  bool v724 = v717 % v73 != v719 && v721 != v722;
  // pto: %308
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v725 = v232; v725 < (v724 ? v720 - v718 : v720); v725 += v84) {
    // pto: %309
    ;
    int64_t v726 = (int64_t) ((uint64_t) v725 * (uint64_t) v73);
    // pto: %qh_full_f32_inline8810__tile
    ;
    Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v727 = Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v72);
    // pto: %qh_full_f32_inline8810__tile
    ;
    uint64_t v728 = (uint64_t) v33;
    TASSIGN(v727, v728);
    // pto: %310
    ;
    int64_t v729 = v726 < v90 ? v90 : v726;
    // pto: %had_acc_read_inline3914__ssa_v0_pview
    ;
    __gm__ float* v730 = PTOAS__GLOBAL_TENSOR_DATA(v197);
    // pto: %had_acc_read_inline3914__ssa_v0_pview
    ;
    const int64_t v731 = 0;
    // pto: %had_acc_read_inline3914__ssa_v0_pview
    ;
    const int64_t v732 = 128;
    // pto: %had_acc_read_inline3914__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 64, 128> v733 = pto::Shape<1, 1, 1, 64, 128>();
    // pto: %had_acc_read_inline3914__ssa_v0_pview
    ;
    pto::Stride<8192, 8192, 8192, 128, 1> v734 = pto::Stride<8192, 8192, 8192, 128, 1>();
    // pto: %had_acc_read_inline3914__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND> v735 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND>(v730 + (v731 + v729 * v732), v733, v734);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v727, v735);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    // pto: %72
    ;
    Tile<TileType::Vec, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v736 = Tile<TileType::Vec, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v72);
    // pto: %72
    ;
    uint64_t v737 = (uint64_t) v34;
    TASSIGN(v736, v737);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    RoundMode v738 = RoundMode::CAST_RINT;
    SaturationMode v739 = SaturationMode::ON;
    TCVT(v736, v727, v738, v739);
    // pto: %qh_full_f32_v1_inline8811__tile
    ;
    Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v740 = Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v72);
    // pto: %qh_full_f32_v1_inline8811__tile
    ;
    uint64_t v741 = (uint64_t) v33;
    TASSIGN(v740, v741);
    pipe_barrier(PIPE_V);
    RoundMode v742 = RoundMode::CAST_ROUND;
    SaturationMode v743 = SaturationMode::ON;
    TCVT(v740, v736, v742, v743);
    // pto: %73
    ;
    Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v744 = Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v72);
    // pto: %73
    ;
    uint64_t v745 = (uint64_t) v33;
    TASSIGN(v744, v745);
    pipe_barrier(PIPE_V);
    TMULS(v744, v740, v92);
    // pto: %74
    ;
    Tile<TileType::Vec, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v746 = Tile<TileType::Vec, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v72);
    // pto: %74
    ;
    uint64_t v747 = (uint64_t) v34;
    TASSIGN(v746, v747);
    pipe_barrier(PIPE_V);
    RoundMode v748 = RoundMode::CAST_RINT;
    SaturationMode v749 = SaturationMode::ON;
    TCVT(v746, v744, v748, v749);
    // pto: %qh_full_f32_v2_inline8812__tile
    ;
    Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v750 = Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v72);
    // pto: %qh_full_f32_v2_inline8812__tile
    ;
    uint64_t v751 = (uint64_t) v33;
    TASSIGN(v750, v751);
    pipe_barrier(PIPE_V);
    RoundMode v752 = RoundMode::CAST_ROUND;
    SaturationMode v753 = SaturationMode::ON;
    TCVT(v750, v746, v752, v753);
    // pto: %qh_amax_inline8813__tile
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v754 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
    // pto: %qh_amax_inline8813__tile
    ;
    uint64_t v755 = (uint64_t) v45;
    TASSIGN(v754, v755);
    TEXPANDS(v754, v93);
    for (int64_t v756 = v90; v756 < v72; v756 += v73) {
      // pto: %qh_a_f32_inline8815__tile_textract
      ;
      Tile<TileType::Vec, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v757 = Tile<TileType::Vec, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v73);
      // pto: %qh_a_f32_inline8815__tile_textract
      ;
      uint64_t v758 = (uint64_t) v34;
      TASSIGN(v757, v758);
      pipe_barrier(PIPE_V);
      uint16_t v759 = static_cast<uint16_t>(v90);
      uint16_t v760 = static_cast<uint16_t>(v756);
      TEXTRACT(v757, v750, v759, v760);
      // pto: %qh_a_neg_inline8816__tile
      ;
      Tile<TileType::Vec, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v761 = Tile<TileType::Vec, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v73);
      // pto: %qh_a_neg_inline8816__tile
      ;
      uint64_t v762 = (uint64_t) v34;
      TASSIGN(v761, v762);
      pipe_barrier(PIPE_V);
      TNEG(v761, v757);
      // pto: %75
      ;
      Tile<TileType::Vec, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v763 = Tile<TileType::Vec, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v73);
      // pto: %75
      ;
      uint64_t v764 = (uint64_t) v35;
      TASSIGN(v763, v764);
      uint16_t v765 = static_cast<uint16_t>(v90);
      uint16_t v766 = static_cast<uint16_t>(v756);
      TEXTRACT(v763, v750, v765, v766);
      // pto: %qh_a_abs_inline8817__tile
      ;
      Tile<TileType::Vec, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v767 = Tile<TileType::Vec, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v73);
      // pto: %qh_a_abs_inline8817__tile
      ;
      uint64_t v768 = (uint64_t) v35;
      TASSIGN(v767, v768);
      pipe_barrier(PIPE_V);
      TMAX(v767, v763, v761);
      // pto: %tmp_tile
      ;
      Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v769 = Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v72);
      // pto: %tmp_tile
      ;
      uint64_t v770 = (uint64_t) v34;
      TASSIGN(v769, v770);
      // pto: %qh_a_max_col_inline8818__tile
      ;
      Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v771 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v70);
      // pto: %qh_a_max_col_inline8818__tile
      ;
      uint64_t v772 = (uint64_t) v36;
      TASSIGN(v771, v772);
      pipe_barrier(PIPE_V);
      TROWMAX(v771, v767, v769);
      // pto: %qh_a_max_inline8819__tile
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v773 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
      // pto: %qh_a_max_inline8819__tile
      ;
      uint64_t v774 = (uint64_t) v36;
      TASSIGN(v773, v774);
      // pto: %76
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v775 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
      // pto: %76
      ;
      uint64_t v776 = (uint64_t) v45;
      TASSIGN(v775, v776);
      pipe_barrier(PIPE_V);
      TMAX(v775, v754, v773);
    };
    // pto: %qh_scale_numerator_inline8820__tile
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v777 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
    // pto: %qh_scale_numerator_inline8820__tile
    ;
    uint64_t v778 = (uint64_t) v34;
    TASSIGN(v777, v778);
    pipe_barrier(PIPE_V);
    TEXPANDS(v777, v94);
    // pto: %qh_scale_quant_row_inline8821__tile
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v779 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
    // pto: %qh_scale_quant_row_inline8821__tile
    ;
    uint64_t v780 = (uint64_t) v34;
    TASSIGN(v779, v780);
    pipe_barrier(PIPE_V);
    TDIV(v779, v777, v754);
    // pto: %qh_scale_recip_inline8822__tile
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v781 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
    // pto: %qh_scale_recip_inline8822__tile
    ;
    uint64_t v782 = (uint64_t) v35;
    TASSIGN(v781, v782);
    pipe_barrier(PIPE_V);
    TRECIP(v781, v779);
    // pto: %qh_scale_dq_inline8823__tile
    ;
    Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v783 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v70);
    // pto: %qh_scale_dq_inline8823__tile
    ;
    uint64_t v784 = (uint64_t) v35;
    TASSIGN(v783, v784);
    // pto: %t__rm_a0_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v785 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
    // pto: %t__rm_a0_tmp_v0
    ;
    uint64_t v786 = (uint64_t) v35;
    TASSIGN(v785, v786);
    // pto: %t__row_major_tmp_v1
    ;
    Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v787 = Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
    // pto: %t__row_major_tmp_v1
    ;
    uint64_t v788 = (uint64_t) v45;
    TASSIGN(v787, v788);
    pipe_barrier(PIPE_V);
    RoundMode v789 = RoundMode::CAST_RINT;
    SaturationMode v790 = SaturationMode::ON;
    TCVT(v787, v785, v789, v790);
    // pto: %77
    ;
    Tile<TileType::Vec, half, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v791 = Tile<TileType::Vec, half, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v70);
    // pto: %77
    ;
    uint64_t v792 = (uint64_t) v45;
    TASSIGN(v791, v792);
    // pto: %t__rm_a0_tmp_v2
    ;
    Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v793 = Tile<TileType::Vec, half, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
    // pto: %t__rm_a0_tmp_v2
    ;
    uint64_t v794 = (uint64_t) v45;
    TASSIGN(v793, v794);
    // pto: %t__row_major_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v795 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
    // pto: %t__row_major_tmp_v3
    ;
    uint64_t v796 = (uint64_t) v35;
    TASSIGN(v795, v796);
    pipe_barrier(PIPE_V);
    RoundMode v797 = RoundMode::CAST_ROUND;
    SaturationMode v798 = SaturationMode::ON;
    TCVT(v795, v793, v797, v798);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %78
    ;
    Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v799 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v70);
    // pto: %78
    ;
    uint64_t v800 = (uint64_t) v35;
    TASSIGN(v799, v800);
    // pto: %out_scale__iter_v1_pview
    ;
    __gm__ float* v801 = PTOAS__GLOBAL_TENSOR_DATA(v230);
    // pto: %out_scale__iter_v1_pview
    ;
    const int64_t v802 = 0;
    // pto: %out_scale__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 64, 1> v803 = pto::Shape<1, 1, 1, 64, 1>();
    // pto: %out_scale__iter_v1_pview
    ;
    pto::Stride<64, 64, 64, 1, 27648> v804 = pto::Stride<64, 64, 64, 1, 27648>();
    // pto: %out_scale__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 64, 1>, pto::Stride<64, 64, 64, 1, 27648>, pto::Layout::DN> v805 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 1>, pto::Stride<64, 64, 64, 1, 27648>, pto::Layout::DN>(v801 + (v802 + v729), v803, v804);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v805, v799);
    // pto: %qh_scale_quant_inline8824__tile
    ;
    Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v806 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v70);
    // pto: %qh_scale_quant_inline8824__tile
    ;
    uint64_t v807 = (uint64_t) v34;
    TASSIGN(v806, v807);
    // pto: %qh_q_scaled_inline8825__tile
    ;
    Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v808 = Tile<TileType::Vec, float, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v72);
    // pto: %qh_q_scaled_inline8825__tile
    ;
    uint64_t v809 = (uint64_t) v33;
    TASSIGN(v808, v809);
    TROWEXPANDMUL(v808, v750, v806);
    // pto: %qh_q_i32_inline8826__tile
    ;
    Tile<TileType::Vec, int32_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v810 = Tile<TileType::Vec, int32_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v72);
    // pto: %qh_q_i32_inline8826__tile
    ;
    uint64_t v811 = (uint64_t) v33;
    TASSIGN(v810, v811);
    pipe_barrier(PIPE_V);
    RoundMode v812 = RoundMode::CAST_RINT;
    SaturationMode v813 = SaturationMode::ON;
    TCVT(v810, v808, v812, v813);
    // pto: %qh_q_half_inline8827__tile
    ;
    Tile<TileType::Vec, half, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v814 = Tile<TileType::Vec, half, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v72);
    // pto: %qh_q_half_inline8827__tile
    ;
    uint64_t v815 = (uint64_t) v33;
    TASSIGN(v814, v815);
    pipe_barrier(PIPE_V);
    RoundMode v816 = RoundMode::CAST_ROUND;
    SaturationMode v817 = SaturationMode::ON;
    TCVT(v814, v810, v816, v817);
    // pto: %qh_i8_inline8828__tile
    ;
    Tile<TileType::Vec, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v818 = Tile<TileType::Vec, int8_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v72);
    // pto: %qh_i8_inline8828__tile
    ;
    uint64_t v819 = (uint64_t) v33;
    TASSIGN(v818, v819);
    pipe_barrier(PIPE_V);
    RoundMode v820 = RoundMode::CAST_TRUNC;
    SaturationMode v821 = SaturationMode::ON;
    TCVT(v818, v814, v820, v821);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %out_i8__iter_v1_pview
    ;
    __gm__ int8_t* v822 = PTOAS__GLOBAL_TENSOR_DATA(v222);
    // pto: %out_i8__iter_v1_pview
    ;
    const int64_t v823 = 0;
    // pto: %out_i8__iter_v1_pview
    ;
    const int64_t v824 = 128;
    // pto: %out_i8__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 64, 128> v825 = pto::Shape<1, 1, 1, 64, 128>();
    // pto: %out_i8__iter_v1_pview
    ;
    pto::Stride<8192, 8192, 8192, 128, 1> v826 = pto::Stride<8192, 8192, 8192, 128, 1>();
    // pto: %out_i8__iter_v1_pview
    ;
    GlobalTensor<int8_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND> v827 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<8192, 8192, 8192, 128, 1>, pto::Layout::ND>(v822 + (v823 + v729 * v824), v825, v826);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v827, v818);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  // pto: %314
  int64_t v828 = v27 % v95;
  // pto: %315, %316, %317
  int64_t v829 = v828 < v90 ? (int64_t) ((uint64_t) v828 + (uint64_t) v95) : v828;
  // pto: %313, %318, %319
  // pto: %dq_head_tile_inline8829__phi_v4
  int64_t v830;
  if (v27 >= v95 & v829 == v90) {
    v830 = v73;
  } else {
    // pto: %321
    ;
    int64_t v831 = v27 % v96;
    // pto: %322, %323, %324
    ;
    int64_t v832 = v831 < v90 ? (int64_t) ((uint64_t) v831 + (uint64_t) v96) : v831;
    // pto: %320, %325, %326, %dq_head_tile_inline8829__phi_v3
    ;
    v830 = v27 >= v96 & v832 == v90 ? v74 : v91;
  }
  // pto: %329
  const int64_t v833 = 1;
  // pto: %329
  const int64_t v834 = 0;
  // pto: %329
  int64_t v835 = v73 / v830;
  // pto: %329
  int64_t v836 = v73 % v830;
  // pto: %329
  bool v837 = v73 < v834;
  // pto: %329
  bool v838 = v830 < v834;
  // pto: %329
  bool v839 = v837 == v838;
  // pto: %329
  bool v840 = v836 != v834 && v837 != v838;
  // pto: %329
  int64_t v841 = v840 ? v835 - v833 : v835;
  // pto: %330
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  pipe_barrier(PIPE_ALL);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  for (int64_t v842 = v232; v842 < ((int64_t) ((uint64_t) v241 * (uint64_t) v841)); v842 += v84) {
    // pto: %332
    ;
    int64_t v843 = v842 % v841;
    // pto: %333, %334, %335
    ;
    bool v844 = v843 < v90 ^ v841 < v90;
    // pto: %336, %337, %338, %339
    ;
    int64_t v845 = v843 != v90 & v844 ? (int64_t) ((uint64_t) v843 + (uint64_t) v841) : v843;
    // pto: %340
    ;
    uint64_t v846 = (uint64_t) v830;
    // pto: %340
    ;
    int64_t v847 = (int64_t) ((uint64_t) v845 * v846);
    // pto: %342
    ;
    const int64_t v848 = 1;
    // pto: %342
    ;
    const int64_t v849 = 0;
    // pto: %342
    ;
    int64_t v850 = v842 / v841;
    // pto: %342
    ;
    bool v851 = v842 < v849;
    // pto: %342
    ;
    bool v852 = v841 < v849;
    // pto: %342
    ;
    bool v853 = v851 == v852;
    // pto: %342
    ;
    bool v854 = v842 % v841 != v849 && v851 != v852;
    // pto: %342
    ;
    int64_t v855 = v854 ? v850 - v848 : v850;
    // pto: %343
    ;
    int64_t v856 = (int64_t) ((uint64_t) v855 * (uint64_t) v83);
    // pto: %344, %345
    ;
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    if ((int64_t) ((uint64_t) v856 + (uint64_t) v83) <= v27) {
      // pto: %qr_scale_dq_t_inline8834__tile
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v857 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v70);
      // pto: %qr_scale_dq_t_inline8834__tile
      ;
      uint64_t v858 = (uint64_t) v37;
      TASSIGN(v857, v858);
      // pto: %346
      ;
      int64_t v859 = v856 < v90 ? v90 : v856;
      // pto: %island_scale_pad__rv_v2_pview
      ;
      __gm__ float* v860 = PTOAS__GLOBAL_TENSOR_DATA(v172);
      // pto: %island_scale_pad__rv_v2_pview
      ;
      const int64_t v861 = 0;
      // pto: %island_scale_pad__rv_v2_pview
      ;
      pto::Shape<1, 1, 1, 8, 1> v862 = pto::Shape<1, 1, 1, 8, 1>();
      // pto: %island_scale_pad__rv_v2_pview
      ;
      pto::Stride<8, 8, 8, 1, 512> v863 = pto::Stride<8, 8, 8, 1, 512>();
      // pto: %island_scale_pad__rv_v2_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN> v864 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN>(v860 + (v861 + v859), v862, v863);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      pipe_barrier(PIPE_ALL);
      TLOAD(v857, v864);
      // pto: %q_cos_il_inline8835__tile
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v865 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
      // pto: %q_cos_il_inline8835__tile
      ;
      uint64_t v866 = (uint64_t) v36;
      TASSIGN(v865, v866);
      // pto: %348
      ;
      __gm__ float* v867 = PTOAS__GLOBAL_TENSOR_DATA(v127);
      // pto: %348
      ;
      const int64_t v868 = 0;
      // pto: %348
      ;
      const int64_t v869 = 64;
      // pto: %348
      ;
      pto::Shape<1, 1, 1, 8, 64> v870 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %348
      ;
      pto::Stride<512, 512, 512, 64, 1> v871 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %348
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v872 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v867 + (v868 + v859 * v869), v870, v871);
      pipe_barrier(PIPE_ALL);
      TLOAD(v865, v872);
      // pto: %q_sin_signed_inline8836__tile
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v873 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
      // pto: %q_sin_signed_inline8836__tile
      ;
      uint64_t v874 = (uint64_t) v38;
      TASSIGN(v873, v874);
      // pto: %island_signed__ssa_v0_pview
      ;
      __gm__ float* v875 = PTOAS__GLOBAL_TENSOR_DATA(v155);
      // pto: %island_signed__ssa_v0_pview
      ;
      const int64_t v876 = 0;
      // pto: %island_signed__ssa_v0_pview
      ;
      const int64_t v877 = 64;
      // pto: %island_signed__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v878 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %island_signed__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v879 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %island_signed__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v880 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v875 + (v876 + v859 * v877), v878, v879);
      pipe_barrier(PIPE_ALL);
      TLOAD(v873, v880);
      // pto: %q_swap_idx_inline8837__tile
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v881 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
      // pto: %q_swap_idx_inline8837__tile
      ;
      uint64_t v882 = (uint64_t) v39;
      TASSIGN(v881, v882);
      // pto: %island_swap__ssa_v0_pview
      ;
      __gm__ int32_t* v883 = PTOAS__GLOBAL_TENSOR_DATA(v164);
      // pto: %island_swap__ssa_v0_pview
      ;
      const int64_t v884 = 0;
      // pto: %island_swap__ssa_v0_pview
      ;
      const int64_t v885 = 64;
      // pto: %island_swap__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 64> v886 = pto::Shape<1, 1, 1, 8, 64>();
      // pto: %island_swap__ssa_v0_pview
      ;
      pto::Stride<512, 512, 512, 64, 1> v887 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %island_swap__ssa_v0_pview
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v888 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v883 + (v884 + v859 * v885), v886, v887);
      TLOAD(v881, v888);
      // pto: %351
      ;
      const int64_t v889 = 1;
      // pto: %351
      ;
      const int64_t v890 = 0;
      // pto: %351
      ;
      int64_t v891 = v830 / v81;
      // pto: %351
      ;
      int64_t v892 = v830 % v81;
      // pto: %351
      ;
      bool v893 = v830 < v890;
      // pto: %351
      ;
      bool v894 = v81 < v890;
      // pto: %351
      ;
      bool v895 = v893 == v894;
      // pto: %351
      ;
      bool v896 = v892 != v890 && v893 != v894;
      // pto: %351
      ;
      int64_t v897 = v896 ? v891 - v889 : v891;
      // pto: %352
      ;
      int64_t v898 = (int64_t) ((uint64_t) v897 * (uint64_t) v81);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      for (int64_t v899 = v90; v899 < v898; v899 += v81) {
        // pto: %353, %354
        ;
        int64_t v900 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v847 + (uint64_t) v899) * (uint64_t) v76);
        // pto: %356, %355, %357
        ;
        int64_t v901 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v847 + (uint64_t) ((int64_t) (uint64_t) v899 + (uint64_t) v70)) * (uint64_t) v76);
        // pto: %q_head_acc_inline8841__tile
        ;
        Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v902 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %q_head_acc_inline8841__tile
        ;
        uint64_t v903 = (uint64_t) v33;
        TASSIGN(v902, v903);
        // pto: %359
        ;
        int64_t v904 = v900 < v90 ? v90 : v900;
        // pto: %main_acc_read_inline3917__ssa_v0_pview
        ;
        __gm__ int32_t* v905 = PTOAS__GLOBAL_TENSOR_DATA(v205);
        // pto: %main_acc_read_inline3917__ssa_v0_pview
        ;
        const int64_t v906 = 0;
        // pto: %main_acc_read_inline3917__ssa_v0_pview
        ;
        const int64_t v907 = 32768;
        // pto: %main_acc_read_inline3917__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 8, 512> v908 = pto::Shape<1, 1, 1, 8, 512>();
        // pto: %main_acc_read_inline3917__ssa_v0_pview
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v909 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %main_acc_read_inline3917__ssa_v0_pview
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v910 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v905 + (v906 + v859 * v907 + v904), v908, v909);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        TLOAD(v902, v910);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %79
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v911 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
        // pto: %79
        ;
        uint64_t v912 = (uint64_t) v40;
        TASSIGN(v911, v912);
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        __gm__ float* v913 = PTOAS__GLOBAL_TENSOR_DATA(v146);
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        const int64_t v914 = 0;
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 512> v915 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        pto::Stride<512, 512, 512, 512, 1> v916 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %wq_b_scale__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v917 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v913 + (v914 + v904), v915, v916);
        TLOAD(v911, v917);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %80
        ;
        Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v918 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %80
        ;
        uint64_t v919 = (uint64_t) v34;
        TASSIGN(v918, v919);
        // pto: %362
        ;
        int64_t v920 = v901 < v90 ? v90 : v901;
        // pto: %363
        ;
        __gm__ int32_t* v921 = PTOAS__GLOBAL_TENSOR_DATA(v205);
        // pto: %363
        ;
        const int64_t v922 = 0;
        // pto: %363
        ;
        const int64_t v923 = 32768;
        // pto: %363
        ;
        pto::Shape<1, 1, 1, 8, 512> v924 = pto::Shape<1, 1, 1, 8, 512>();
        // pto: %363
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v925 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %363
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v926 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v921 + (v922 + v859 * v923 + v920), v924, v925);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
        TLOAD(v918, v926);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        // pto: %81
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v927 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
        // pto: %81
        ;
        uint64_t v928 = (uint64_t) v41;
        TASSIGN(v927, v928);
        // pto: %365
        ;
        __gm__ float* v929 = PTOAS__GLOBAL_TENSOR_DATA(v146);
        // pto: %365
        ;
        const int64_t v930 = 0;
        // pto: %365
        ;
        pto::Shape<1, 1, 1, 1, 512> v931 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %365
        ;
        pto::Stride<512, 512, 512, 512, 1> v932 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %365
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v933 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v929 + (v930 + v920), v931, v932);
        TLOAD(v927, v933);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        // pto: %q_head_scale_inline8842__tile
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v934 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
        // pto: %q_head_scale_inline8842__tile
        ;
        uint64_t v935 = (uint64_t) v40;
        TASSIGN(v934, v935);
        // pto: %q_head_acc_fp32_inline8843__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v936 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %q_head_acc_fp32_inline8843__tile
        ;
        uint64_t v937 = (uint64_t) v33;
        TASSIGN(v936, v937);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v938 = RoundMode::CAST_NONE;
        SaturationMode v939 = SaturationMode::ON;
        TCVT(v936, v902, v938, v939);
        // pto: %82
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v940 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %82
        ;
        uint64_t v941 = (uint64_t) v35;
        TASSIGN(v940, v941);
        TEXPANDS(v940, v85);
        // pto: %83
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v942 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %83
        ;
        uint64_t v943 = (uint64_t) v35;
        TASSIGN(v942, v943);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v942, v940, v857);
        // pto: %q_head_scale_combined_inline8844__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v944 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %q_head_scale_combined_inline8844__tile
        ;
        uint64_t v945 = (uint64_t) v35;
        TASSIGN(v944, v945);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        TCOLEXPANDMUL(v944, v942, v934);
        // pto: %q_head_dq_inline8845__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v946 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %q_head_dq_inline8845__tile
        ;
        uint64_t v947 = (uint64_t) v33;
        TASSIGN(v946, v947);
        pipe_barrier(PIPE_V);
        TMUL(v946, v936, v944);
        // pto: %84
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v948 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %84
        ;
        uint64_t v949 = (uint64_t) v35;
        TASSIGN(v948, v949);
        pipe_barrier(PIPE_V);
        RoundMode v950 = RoundMode::CAST_RINT;
        SaturationMode v951 = SaturationMode::ON;
        TCVT(v948, v946, v950, v951);
        // pto: %q_head_dq_v1_inline8846__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v952 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %q_head_dq_v1_inline8846__tile
        ;
        uint64_t v953 = (uint64_t) v33;
        TASSIGN(v952, v953);
        pipe_barrier(PIPE_V);
        RoundMode v954 = RoundMode::CAST_ROUND;
        SaturationMode v955 = SaturationMode::ON;
        TCVT(v952, v948, v954, v955);
        // pto: %q_head_sq_inline8847__tile
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v956 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %q_head_sq_inline8847__tile
        ;
        uint64_t v957 = (uint64_t) v35;
        TASSIGN(v956, v957);
        pipe_barrier(PIPE_V);
        TMUL(v956, v952, v952);
        // pto: %85
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v958 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %85
        ;
        uint64_t v959 = (uint64_t) v35;
        TASSIGN(v958, v959);
        // pto: %366
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v960;
        // pto: %366
        ;
        uint64_t v961 = (uint64_t) v35;
        TASSIGN(v960, v961);
        // pto: %86
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v962 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %86
        ;
        uint64_t v963 = (uint64_t) v50;
        TASSIGN(v962, v963);
        // pto: %367
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v964;
        // pto: %367
        ;
        uint64_t v965 = (uint64_t) v50;
        TASSIGN(v964, v965);
        // pto: %q_sq_04_inline8848__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v966 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_sq_04_inline8848__tile
        ;
        uint64_t v967 = (uint64_t) v40;
        TASSIGN(v966, v967);
        pipe_barrier(PIPE_V);
        TADD(v966, v960, v964);
        // pto: %87
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v968 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %87
        ;
        uint64_t v969 = (uint64_t) v49;
        TASSIGN(v968, v969);
        // pto: %368
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v970;
        // pto: %368
        ;
        uint64_t v971 = (uint64_t) v49;
        TASSIGN(v970, v971);
        // pto: %88
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v972 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %88
        ;
        uint64_t v973 = (uint64_t) v51;
        TASSIGN(v972, v973);
        // pto: %369
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v974;
        // pto: %369
        ;
        uint64_t v975 = (uint64_t) v51;
        TASSIGN(v974, v975);
        // pto: %q_sq_15_inline8849__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v976 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_sq_15_inline8849__tile
        ;
        uint64_t v977 = (uint64_t) v43;
        TASSIGN(v976, v977);
        TADD(v976, v970, v974);
        // pto: %89
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v978 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %89
        ;
        uint64_t v979 = (uint64_t) v52;
        TASSIGN(v978, v979);
        // pto: %370
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v980;
        // pto: %370
        ;
        uint64_t v981 = (uint64_t) v52;
        TASSIGN(v980, v981);
        // pto: %90
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v982 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %90
        ;
        uint64_t v983 = (uint64_t) v53;
        TASSIGN(v982, v983);
        // pto: %371
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v984;
        // pto: %371
        ;
        uint64_t v985 = (uint64_t) v53;
        TASSIGN(v984, v985);
        // pto: %q_sq_26_inline8850__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v986 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_sq_26_inline8850__tile
        ;
        uint64_t v987 = (uint64_t) v44;
        TASSIGN(v986, v987);
        TADD(v986, v980, v984);
        // pto: %91
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v988 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %91
        ;
        uint64_t v989 = (uint64_t) v54;
        TASSIGN(v988, v989);
        // pto: %372
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v990;
        // pto: %372
        ;
        uint64_t v991 = (uint64_t) v54;
        TASSIGN(v990, v991);
        // pto: %92
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v992 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %92
        ;
        uint64_t v993 = (uint64_t) v55;
        TASSIGN(v992, v993);
        // pto: %373
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v994;
        // pto: %373
        ;
        uint64_t v995 = (uint64_t) v55;
        TASSIGN(v994, v995);
        // pto: %q_sq_37_inline8851__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v996 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_sq_37_inline8851__tile
        ;
        uint64_t v997 = (uint64_t) v35;
        TASSIGN(v996, v997);
        pipe_barrier(PIPE_V);
        TADD(v996, v990, v994);
        // pto: %q_sq_0246_inline8852__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v998 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_sq_0246_inline8852__tile
        ;
        uint64_t v999 = (uint64_t) v40;
        TASSIGN(v998, v999);
        TADD(v998, v966, v986);
        // pto: %q_sq_1357_inline8853__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1000 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_sq_1357_inline8853__tile
        ;
        uint64_t v1001 = (uint64_t) v35;
        TASSIGN(v1000, v1001);
        pipe_barrier(PIPE_V);
        TADD(v1000, v976, v996);
        // pto: %q_sq_64_inline8854__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1002 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_sq_64_inline8854__tile
        ;
        uint64_t v1003 = (uint64_t) v40;
        TASSIGN(v1002, v1003);
        pipe_barrier(PIPE_V);
        TADD(v1002, v998, v1000);
        // pto: %93
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1004 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
        // pto: %93
        ;
        uint64_t v1005 = (uint64_t) v35;
        TASSIGN(v1004, v1005);
        // pto: %q_head_sq_row_inline8855__tile
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1006 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v70);
        // pto: %q_head_sq_row_inline8855__tile
        ;
        uint64_t v1007 = (uint64_t) v43;
        TASSIGN(v1006, v1007);
        pipe_barrier(PIPE_V);
        TROWSUM(v1006, v1002, v1004);
        // pto: %q_head_sq_sum_inline8856__tile
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1008 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %q_head_sq_sum_inline8856__tile
        ;
        uint64_t v1009 = (uint64_t) v43;
        TASSIGN(v1008, v1009);
        // pto: %q_head_sq_mean_inline8857__tile
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1010 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %q_head_sq_mean_inline8857__tile
        ;
        uint64_t v1011 = (uint64_t) v35;
        TASSIGN(v1010, v1011);
        pipe_barrier(PIPE_V);
        TMULS(v1010, v1008, v97);
        // pto: %q_head_var_inline8858__tile
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1012 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %q_head_var_inline8858__tile
        ;
        uint64_t v1013 = (uint64_t) v35;
        TASSIGN(v1012, v1013);
        pipe_barrier(PIPE_V);
        TADDS(v1012, v1010, v98);
        // pto: %rsqrt_tmp
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1014 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %rsqrt_tmp
        ;
        uint64_t v1015 = (uint64_t) v40;
        TASSIGN(v1014, v1015);
        // pto: %q_head_inv_rms_inline8859__tile
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1016 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %q_head_inv_rms_inline8859__tile
        ;
        uint64_t v1017 = (uint64_t) v43;
        TASSIGN(v1016, v1017);
        pipe_barrier(PIPE_V);
        TRSQRT(v1016, v1012, v1014);
        // pto: %q_head_inv_rms_t_inline8860__tile
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1018 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v70);
        // pto: %q_head_inv_rms_t_inline8860__tile
        ;
        uint64_t v1019 = (uint64_t) v43;
        TASSIGN(v1018, v1019);
        // pto: %94
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1020 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v77);
        // pto: %94
        ;
        uint64_t v1021 = (uint64_t) v33;
        TASSIGN(v1020, v1021);
        // pto: %374
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1022;
        // pto: %374
        ;
        uint64_t v1023 = (uint64_t) v33;
        TASSIGN(v1022, v1023);
        // pto: %q_nope_normed_inline8861__tile
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1024 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v77);
        // pto: %q_nope_normed_inline8861__tile
        ;
        uint64_t v1025 = (uint64_t) v35;
        TASSIGN(v1024, v1025);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v1024, v1022, v1018);
        // pto: %q_nope_bf16_inline8862__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1026 = Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v77);
        // pto: %q_nope_bf16_inline8862__tile
        ;
        uint64_t v1027 = (uint64_t) v35;
        TASSIGN(v1026, v1027);
        pipe_barrier(PIPE_V);
        RoundMode v1028 = RoundMode::CAST_RINT;
        SaturationMode v1029 = SaturationMode::ON;
        TCVT(v1026, v1024, v1028, v1029);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %q_rope_chunk_raw_inline8863__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1030 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_rope_chunk_raw_inline8863__tile
        ;
        uint64_t v1031 = (uint64_t) v56;
        TASSIGN(v1030, v1031);
        // pto: %375
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1032;
        // pto: %375
        ;
        uint64_t v1033 = (uint64_t) v56;
        TASSIGN(v1032, v1033);
        // pto: %q_rope_chunk_inline8864__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1034 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_rope_chunk_inline8864__tile
        ;
        uint64_t v1035 = (uint64_t) v33;
        TASSIGN(v1034, v1035);
        TROWEXPANDMUL(v1034, v1032, v1018);
        // pto: %95
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1036 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %95
        ;
        uint64_t v1037 = (uint64_t) v40;
        TASSIGN(v1036, v1037);
        pipe_barrier(PIPE_V);
        RoundMode v1038 = RoundMode::CAST_RINT;
        SaturationMode v1039 = SaturationMode::ON;
        TCVT(v1036, v1034, v1038, v1039);
        // pto: %q_rope_chunk_v1_inline8865__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1040 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_rope_chunk_v1_inline8865__tile
        ;
        uint64_t v1041 = (uint64_t) v33;
        TASSIGN(v1040, v1041);
        pipe_barrier(PIPE_V);
        RoundMode v1042 = RoundMode::CAST_ROUND;
        SaturationMode v1043 = SaturationMode::ON;
        TCVT(v1040, v1036, v1042, v1043);
        // pto: %96
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1044 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %96
        ;
        uint64_t v1045 = (uint64_t) v40;
        TASSIGN(v1044, v1045);
        for (int64_t v1046 = v90; v1046 < v83; v1046 += v70) {
          // pto: %97
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1047 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
          // pto: %97
          ;
          uint64_t v1048 = (uint64_t) v33;
          TASSIGN(v1047, v1048);
          // pto: %377
          ;
          int64_t v1049 = (int64_t) ((uint64_t) v1046 * (uint64_t) v42);
          // pto: %377
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1050;
          // pto: %377
          ;
          uint64_t v1051 = (uint64_t) v1049;
          TASSIGN(v1050, v1051);
          // pto: %98
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1052 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
          // pto: %98
          ;
          uint64_t v1053 = (uint64_t) v39;
          TASSIGN(v1052, v1053);
          // pto: %378
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1054;
          // pto: %378
          ;
          uint64_t v1055 = (uint64_t) ((int64_t) (uint64_t) v1049 + (uint64_t) v39);
          TASSIGN(v1054, v1055);
          // pto: %99
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1056 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
          // pto: %99
          ;
          uint64_t v1057 = (uint64_t) v43;
          TASSIGN(v1056, v1057);
          // pto: %100
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1058 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
          // pto: %100
          ;
          uint64_t v1059 = (uint64_t) v44;
          TASSIGN(v1058, v1059);
          pipe_barrier(PIPE_V);
          TGATHER(v1058, v1050, v1054, v1056);
          // pto: %379
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1060;
          // pto: %379
          ;
          uint64_t v1061 = (uint64_t) ((int64_t) (uint64_t) v1049 + (uint64_t) v40);
          TASSIGN(v1060, v1061);
          pipe_barrier(PIPE_V);
          TMOV(v1060, v1058);
        };
        // pto: %q_rope_swapped_inline8866__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1062 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_rope_swapped_inline8866__tile
        ;
        uint64_t v1063 = (uint64_t) v40;
        TASSIGN(v1062, v1063);
        // pto: %q_rope_base_inline8867__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1064 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_rope_base_inline8867__tile
        ;
        uint64_t v1065 = (uint64_t) v33;
        TASSIGN(v1064, v1065);
        pipe_barrier(PIPE_V);
        TMUL(v1064, v1040, v865);
        // pto: %q_rope_delta_inline8868__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1066 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_rope_delta_inline8868__tile
        ;
        uint64_t v1067 = (uint64_t) v40;
        TASSIGN(v1066, v1067);
        TMUL(v1066, v1062, v873);
        // pto: %q_rope_rot_inline8869__tile
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1068 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_rope_rot_inline8869__tile
        ;
        uint64_t v1069 = (uint64_t) v33;
        TASSIGN(v1068, v1069);
        pipe_barrier(PIPE_V);
        TADD(v1068, v1064, v1066);
        // pto: %q_rope_bf16_inline8870__tile
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1070 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_rope_bf16_inline8870__tile
        ;
        uint64_t v1071 = (uint64_t) v33;
        TASSIGN(v1070, v1071);
        pipe_barrier(PIPE_V);
        RoundMode v1072 = RoundMode::CAST_RINT;
        SaturationMode v1073 = SaturationMode::ON;
        TCVT(v1070, v1068, v1072, v1073);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        // pto: %q__iter_v3_pview
        ;
        __gm__ bfloat16_t* v1074 = PTOAS__GLOBAL_TENSOR_DATA(v214);
        // pto: %q__iter_v3_pview
        ;
        const int64_t v1075 = 0;
        // pto: %q__iter_v3_pview
        ;
        const int64_t v1076 = 32768;
        // pto: %q__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 8, 448> v1077 = pto::Shape<1, 1, 1, 8, 448>();
        // pto: %q__iter_v3_pview
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v1078 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %q__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v1079 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v1074 + (v1075 + v859 * v1076 + v904), v1077, v1078);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v1079, v1026);
        // pto: %384
        ;
        int64_t v1080 = (int64_t) ((uint64_t) v900 + (uint64_t) v77);
        // pto: %385
        ;
        int64_t v1081 = v1080 < v90 ? v90 : v1080;
        // pto: %q__tile_pview
        ;
        __gm__ bfloat16_t* v1082 = PTOAS__GLOBAL_TENSOR_DATA(v214);
        // pto: %q__tile_pview
        ;
        const int64_t v1083 = 0;
        // pto: %q__tile_pview
        ;
        const int64_t v1084 = 32768;
        // pto: %q__tile_pview
        ;
        pto::Shape<1, 1, 1, 8, 64> v1085 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %q__tile_pview
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v1086 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %q__tile_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v1087 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v1082 + (v1083 + v859 * v1084 + v1081), v1085, v1086);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v1087, v1070);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        // pto: %102
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1088 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
        // pto: %102
        ;
        uint64_t v1089 = (uint64_t) v41;
        TASSIGN(v1088, v1089);
        // pto: %103
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1090 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %103
        ;
        uint64_t v1091 = (uint64_t) v34;
        TASSIGN(v1090, v1091);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
        RoundMode v1092 = RoundMode::CAST_NONE;
        SaturationMode v1093 = SaturationMode::ON;
        TCVT(v1090, v918, v1092, v1093);
        // pto: %104
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1094 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %104
        ;
        uint64_t v1095 = (uint64_t) v45;
        TASSIGN(v1094, v1095);
        TEXPANDS(v1094, v85);
        // pto: %105
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1096 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %105
        ;
        uint64_t v1097 = (uint64_t) v45;
        TASSIGN(v1096, v1097);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v1096, v1094, v857);
        // pto: %106
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1098 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %106
        ;
        uint64_t v1099 = (uint64_t) v45;
        TASSIGN(v1098, v1099);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
        TCOLEXPANDMUL(v1098, v1096, v1088);
        // pto: %107
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1100 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %107
        ;
        uint64_t v1101 = (uint64_t) v34;
        TASSIGN(v1100, v1101);
        pipe_barrier(PIPE_V);
        TMUL(v1100, v1090, v1098);
        // pto: %108
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1102 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %108
        ;
        uint64_t v1103 = (uint64_t) v45;
        TASSIGN(v1102, v1103);
        pipe_barrier(PIPE_V);
        RoundMode v1104 = RoundMode::CAST_RINT;
        SaturationMode v1105 = SaturationMode::ON;
        TCVT(v1102, v1100, v1104, v1105);
        // pto: %109
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1106 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %109
        ;
        uint64_t v1107 = (uint64_t) v34;
        TASSIGN(v1106, v1107);
        pipe_barrier(PIPE_V);
        RoundMode v1108 = RoundMode::CAST_ROUND;
        SaturationMode v1109 = SaturationMode::ON;
        TCVT(v1106, v1102, v1108, v1109);
        // pto: %110
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1110 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %110
        ;
        uint64_t v1111 = (uint64_t) v45;
        TASSIGN(v1110, v1111);
        pipe_barrier(PIPE_V);
        TMUL(v1110, v1106, v1106);
        // pto: %111
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1112 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %111
        ;
        uint64_t v1113 = (uint64_t) v45;
        TASSIGN(v1112, v1113);
        // pto: %386
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1114;
        // pto: %386
        ;
        uint64_t v1115 = (uint64_t) v45;
        TASSIGN(v1114, v1115);
        // pto: %112
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1116 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %112
        ;
        uint64_t v1117 = (uint64_t) v57;
        TASSIGN(v1116, v1117);
        // pto: %387
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1118;
        // pto: %387
        ;
        uint64_t v1119 = (uint64_t) v57;
        TASSIGN(v1118, v1119);
        // pto: %113
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1120 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %113
        ;
        uint64_t v1121 = (uint64_t) v41;
        TASSIGN(v1120, v1121);
        pipe_barrier(PIPE_V);
        TADD(v1120, v1114, v1118);
        // pto: %114
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1122 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %114
        ;
        uint64_t v1123 = (uint64_t) v58;
        TASSIGN(v1122, v1123);
        // pto: %388
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1124;
        // pto: %388
        ;
        uint64_t v1125 = (uint64_t) v58;
        TASSIGN(v1124, v1125);
        // pto: %115
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1126 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %115
        ;
        uint64_t v1127 = (uint64_t) v59;
        TASSIGN(v1126, v1127);
        // pto: %389
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1128;
        // pto: %389
        ;
        uint64_t v1129 = (uint64_t) v59;
        TASSIGN(v1128, v1129);
        // pto: %116
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1130 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %116
        ;
        uint64_t v1131 = (uint64_t) v47;
        TASSIGN(v1130, v1131);
        TADD(v1130, v1124, v1128);
        // pto: %117
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1132 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %117
        ;
        uint64_t v1133 = (uint64_t) v60;
        TASSIGN(v1132, v1133);
        // pto: %390
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1134;
        // pto: %390
        ;
        uint64_t v1135 = (uint64_t) v60;
        TASSIGN(v1134, v1135);
        // pto: %118
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1136 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %118
        ;
        uint64_t v1137 = (uint64_t) v61;
        TASSIGN(v1136, v1137);
        // pto: %391
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1138;
        // pto: %391
        ;
        uint64_t v1139 = (uint64_t) v61;
        TASSIGN(v1138, v1139);
        // pto: %119
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1140 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %119
        ;
        uint64_t v1141 = (uint64_t) v48;
        TASSIGN(v1140, v1141);
        TADD(v1140, v1134, v1138);
        // pto: %120
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1142 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %120
        ;
        uint64_t v1143 = (uint64_t) v62;
        TASSIGN(v1142, v1143);
        // pto: %392
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1144;
        // pto: %392
        ;
        uint64_t v1145 = (uint64_t) v62;
        TASSIGN(v1144, v1145);
        // pto: %121
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1146 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %121
        ;
        uint64_t v1147 = (uint64_t) v63;
        TASSIGN(v1146, v1147);
        // pto: %393
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1148;
        // pto: %393
        ;
        uint64_t v1149 = (uint64_t) v63;
        TASSIGN(v1148, v1149);
        // pto: %122
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1150 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %122
        ;
        uint64_t v1151 = (uint64_t) v45;
        TASSIGN(v1150, v1151);
        pipe_barrier(PIPE_V);
        TADD(v1150, v1144, v1148);
        // pto: %123
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1152 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %123
        ;
        uint64_t v1153 = (uint64_t) v41;
        TASSIGN(v1152, v1153);
        TADD(v1152, v1120, v1140);
        // pto: %124
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1154 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %124
        ;
        uint64_t v1155 = (uint64_t) v45;
        TASSIGN(v1154, v1155);
        pipe_barrier(PIPE_V);
        TADD(v1154, v1130, v1150);
        // pto: %125
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1156 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %125
        ;
        uint64_t v1157 = (uint64_t) v41;
        TASSIGN(v1156, v1157);
        pipe_barrier(PIPE_V);
        TADD(v1156, v1152, v1154);
        // pto: %126
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1158 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
        // pto: %126
        ;
        uint64_t v1159 = (uint64_t) v45;
        TASSIGN(v1158, v1159);
        // pto: %127
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1160 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v70);
        // pto: %127
        ;
        uint64_t v1161 = (uint64_t) v47;
        TASSIGN(v1160, v1161);
        pipe_barrier(PIPE_V);
        TROWSUM(v1160, v1156, v1158);
        // pto: %128
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1162 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %128
        ;
        uint64_t v1163 = (uint64_t) v47;
        TASSIGN(v1162, v1163);
        // pto: %129
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1164 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %129
        ;
        uint64_t v1165 = (uint64_t) v45;
        TASSIGN(v1164, v1165);
        pipe_barrier(PIPE_V);
        TMULS(v1164, v1162, v97);
        // pto: %130
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1166 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %130
        ;
        uint64_t v1167 = (uint64_t) v45;
        TASSIGN(v1166, v1167);
        pipe_barrier(PIPE_V);
        TADDS(v1166, v1164, v98);
        // pto: %131
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1168 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %131
        ;
        uint64_t v1169 = (uint64_t) v41;
        TASSIGN(v1168, v1169);
        // pto: %132
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1170 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %132
        ;
        uint64_t v1171 = (uint64_t) v47;
        TASSIGN(v1170, v1171);
        pipe_barrier(PIPE_V);
        TRSQRT(v1170, v1166, v1168);
        // pto: %133
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1172 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v70);
        // pto: %133
        ;
        uint64_t v1173 = (uint64_t) v47;
        TASSIGN(v1172, v1173);
        // pto: %134
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1174 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v77);
        // pto: %134
        ;
        uint64_t v1175 = (uint64_t) v34;
        TASSIGN(v1174, v1175);
        // pto: %394
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1176;
        // pto: %394
        ;
        uint64_t v1177 = (uint64_t) v34;
        TASSIGN(v1176, v1177);
        // pto: %135
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1178 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v77);
        // pto: %135
        ;
        uint64_t v1179 = (uint64_t) v45;
        TASSIGN(v1178, v1179);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v1178, v1176, v1172);
        // pto: %136
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1180 = Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v77);
        // pto: %136
        ;
        uint64_t v1181 = (uint64_t) v45;
        TASSIGN(v1180, v1181);
        pipe_barrier(PIPE_V);
        RoundMode v1182 = RoundMode::CAST_RINT;
        SaturationMode v1183 = SaturationMode::ON;
        TCVT(v1180, v1178, v1182, v1183);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %137
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1184 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %137
        ;
        uint64_t v1185 = (uint64_t) v64;
        TASSIGN(v1184, v1185);
        // pto: %395
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1186;
        // pto: %395
        ;
        uint64_t v1187 = (uint64_t) v64;
        TASSIGN(v1186, v1187);
        // pto: %138
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1188 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %138
        ;
        uint64_t v1189 = (uint64_t) v34;
        TASSIGN(v1188, v1189);
        TROWEXPANDMUL(v1188, v1186, v1172);
        // pto: %139
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1190 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %139
        ;
        uint64_t v1191 = (uint64_t) v41;
        TASSIGN(v1190, v1191);
        pipe_barrier(PIPE_V);
        RoundMode v1192 = RoundMode::CAST_RINT;
        SaturationMode v1193 = SaturationMode::ON;
        TCVT(v1190, v1188, v1192, v1193);
        // pto: %140
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1194 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %140
        ;
        uint64_t v1195 = (uint64_t) v34;
        TASSIGN(v1194, v1195);
        pipe_barrier(PIPE_V);
        RoundMode v1196 = RoundMode::CAST_ROUND;
        SaturationMode v1197 = SaturationMode::ON;
        TCVT(v1194, v1190, v1196, v1197);
        // pto: %141
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1198 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %141
        ;
        uint64_t v1199 = (uint64_t) v41;
        TASSIGN(v1198, v1199);
        for (int64_t v1200 = v90; v1200 < v83; v1200 += v70) {
          // pto: %142
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1201 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
          // pto: %142
          ;
          uint64_t v1202 = (uint64_t) v34;
          TASSIGN(v1201, v1202);
          // pto: %397
          ;
          int64_t v1203 = (int64_t) ((uint64_t) v1200 * (uint64_t) v42);
          // pto: %397
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1204;
          // pto: %397
          ;
          uint64_t v1205 = (uint64_t) ((int64_t) (uint64_t) v1203 + (uint64_t) v34);
          TASSIGN(v1204, v1205);
          // pto: %143
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1206 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
          // pto: %143
          ;
          uint64_t v1207 = (uint64_t) v39;
          TASSIGN(v1206, v1207);
          // pto: %398
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1208;
          // pto: %398
          ;
          uint64_t v1209 = (uint64_t) ((int64_t) (uint64_t) v1203 + (uint64_t) v39);
          TASSIGN(v1208, v1209);
          // pto: %144
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1210 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
          // pto: %144
          ;
          uint64_t v1211 = (uint64_t) v47;
          TASSIGN(v1210, v1211);
          // pto: %145
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1212 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
          // pto: %145
          ;
          uint64_t v1213 = (uint64_t) v48;
          TASSIGN(v1212, v1213);
          pipe_barrier(PIPE_V);
          TGATHER(v1212, v1204, v1208, v1210);
          // pto: %399
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1214;
          // pto: %399
          ;
          uint64_t v1215 = (uint64_t) ((int64_t) (uint64_t) v1203 + (uint64_t) v41);
          TASSIGN(v1214, v1215);
          pipe_barrier(PIPE_V);
          TMOV(v1214, v1212);
        };
        // pto: %147
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1216 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %147
        ;
        uint64_t v1217 = (uint64_t) v41;
        TASSIGN(v1216, v1217);
        // pto: %148
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1218 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %148
        ;
        uint64_t v1219 = (uint64_t) v34;
        TASSIGN(v1218, v1219);
        pipe_barrier(PIPE_V);
        TMUL(v1218, v1194, v865);
        // pto: %149
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1220 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %149
        ;
        uint64_t v1221 = (uint64_t) v41;
        TASSIGN(v1220, v1221);
        TMUL(v1220, v1216, v873);
        // pto: %150
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1222 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %150
        ;
        uint64_t v1223 = (uint64_t) v34;
        TASSIGN(v1222, v1223);
        pipe_barrier(PIPE_V);
        TADD(v1222, v1218, v1220);
        // pto: %151
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1224 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %151
        ;
        uint64_t v1225 = (uint64_t) v34;
        TASSIGN(v1224, v1225);
        pipe_barrier(PIPE_V);
        RoundMode v1226 = RoundMode::CAST_RINT;
        SaturationMode v1227 = SaturationMode::ON;
        TCVT(v1224, v1222, v1226, v1227);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        // pto: %403
        ;
        __gm__ bfloat16_t* v1228 = PTOAS__GLOBAL_TENSOR_DATA(v214);
        // pto: %403
        ;
        const int64_t v1229 = 0;
        // pto: %403
        ;
        const int64_t v1230 = 32768;
        // pto: %403
        ;
        pto::Shape<1, 1, 1, 8, 448> v1231 = pto::Shape<1, 1, 1, 8, 448>();
        // pto: %403
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v1232 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %403
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v1233 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v1228 + (v1229 + v859 * v1230 + v920), v1231, v1232);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v1233, v1180);
        // pto: %406
        ;
        int64_t v1234 = (int64_t) ((uint64_t) v901 + (uint64_t) v77);
        // pto: %407
        ;
        int64_t v1235 = v1234 < v90 ? v90 : v1234;
        // pto: %408
        ;
        __gm__ bfloat16_t* v1236 = PTOAS__GLOBAL_TENSOR_DATA(v214);
        // pto: %408
        ;
        const int64_t v1237 = 0;
        // pto: %408
        ;
        const int64_t v1238 = 32768;
        // pto: %408
        ;
        pto::Shape<1, 1, 1, 8, 64> v1239 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %408
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v1240 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %408
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v1241 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v1236 + (v1237 + v859 * v1238 + v1235), v1239, v1240);
        pipe_barrier(PIPE_MTE3);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
        TSTORE(v1241, v1224);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      };
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
      // pto: %409
      ;
      uint64_t v1242 = (uint64_t) v830;
      // pto: %409, %410
      ;
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
      if ((int64_t) (v1242 - (uint64_t) v898) == v70) {
        // pto: %411, %412
        ;
        int64_t v1243 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v847 + (uint64_t) v898) * (uint64_t) v76);
        // pto: %152
        ;
        Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1244 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %152
        ;
        uint64_t v1245 = (uint64_t) v33;
        TASSIGN(v1244, v1245);
        // pto: %414
        ;
        int64_t v1246 = v1243 < v90 ? v90 : v1243;
        // pto: %415
        ;
        __gm__ int32_t* v1247 = PTOAS__GLOBAL_TENSOR_DATA(v205);
        // pto: %415
        ;
        const int64_t v1248 = 0;
        // pto: %415
        ;
        const int64_t v1249 = 32768;
        // pto: %415
        ;
        pto::Shape<1, 1, 1, 8, 512> v1250 = pto::Shape<1, 1, 1, 8, 512>();
        // pto: %415
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v1251 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %415
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v1252 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v1247 + (v1248 + v859 * v1249 + v1246), v1250, v1251);
        TLOAD(v1244, v1252);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %153
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1253 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
        // pto: %153
        ;
        uint64_t v1254 = (uint64_t) v35;
        TASSIGN(v1253, v1254);
        // pto: %417
        ;
        __gm__ float* v1255 = PTOAS__GLOBAL_TENSOR_DATA(v146);
        // pto: %417
        ;
        const int64_t v1256 = 0;
        // pto: %417
        ;
        pto::Shape<1, 1, 1, 1, 512> v1257 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %417
        ;
        pto::Stride<512, 512, 512, 512, 1> v1258 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %417
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v1259 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v1255 + (v1256 + v1246), v1257, v1258);
        TLOAD(v1253, v1259);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %154
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1260 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
        // pto: %154
        ;
        uint64_t v1261 = (uint64_t) v35;
        TASSIGN(v1260, v1261);
        // pto: %155
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1262 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %155
        ;
        uint64_t v1263 = (uint64_t) v33;
        TASSIGN(v1262, v1263);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v1264 = RoundMode::CAST_NONE;
        SaturationMode v1265 = SaturationMode::ON;
        TCVT(v1262, v1244, v1264, v1265);
        // pto: %156
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1266 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %156
        ;
        uint64_t v1267 = (uint64_t) v34;
        TASSIGN(v1266, v1267);
        TEXPANDS(v1266, v85);
        // pto: %157
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1268 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %157
        ;
        uint64_t v1269 = (uint64_t) v34;
        TASSIGN(v1268, v1269);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v1268, v1266, v857);
        // pto: %158
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1270 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %158
        ;
        uint64_t v1271 = (uint64_t) v34;
        TASSIGN(v1270, v1271);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        TCOLEXPANDMUL(v1270, v1268, v1260);
        // pto: %159
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1272 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %159
        ;
        uint64_t v1273 = (uint64_t) v33;
        TASSIGN(v1272, v1273);
        pipe_barrier(PIPE_V);
        TMUL(v1272, v1262, v1270);
        // pto: %160
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1274 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %160
        ;
        uint64_t v1275 = (uint64_t) v34;
        TASSIGN(v1274, v1275);
        pipe_barrier(PIPE_V);
        RoundMode v1276 = RoundMode::CAST_RINT;
        SaturationMode v1277 = SaturationMode::ON;
        TCVT(v1274, v1272, v1276, v1277);
        // pto: %161
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1278 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %161
        ;
        uint64_t v1279 = (uint64_t) v33;
        TASSIGN(v1278, v1279);
        pipe_barrier(PIPE_V);
        RoundMode v1280 = RoundMode::CAST_ROUND;
        SaturationMode v1281 = SaturationMode::ON;
        TCVT(v1278, v1274, v1280, v1281);
        // pto: %162
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1282 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %162
        ;
        uint64_t v1283 = (uint64_t) v34;
        TASSIGN(v1282, v1283);
        pipe_barrier(PIPE_V);
        TMUL(v1282, v1278, v1278);
        // pto: %163
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1284 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %163
        ;
        uint64_t v1285 = (uint64_t) v34;
        TASSIGN(v1284, v1285);
        // pto: %418
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1286;
        // pto: %418
        ;
        uint64_t v1287 = (uint64_t) v34;
        TASSIGN(v1286, v1287);
        // pto: %164
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1288 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %164
        ;
        uint64_t v1289 = (uint64_t) v65;
        TASSIGN(v1288, v1289);
        // pto: %419
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1290;
        // pto: %419
        ;
        uint64_t v1291 = (uint64_t) v65;
        TASSIGN(v1290, v1291);
        // pto: %165
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1292 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %165
        ;
        uint64_t v1293 = (uint64_t) v35;
        TASSIGN(v1292, v1293);
        pipe_barrier(PIPE_V);
        TADD(v1292, v1286, v1290);
        // pto: %166
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1294 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %166
        ;
        uint64_t v1295 = (uint64_t) v46;
        TASSIGN(v1294, v1295);
        // pto: %420
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1296;
        // pto: %420
        ;
        uint64_t v1297 = (uint64_t) v46;
        TASSIGN(v1296, v1297);
        // pto: %167
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1298 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %167
        ;
        uint64_t v1299 = (uint64_t) v66;
        TASSIGN(v1298, v1299);
        // pto: %421
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1300;
        // pto: %421
        ;
        uint64_t v1301 = (uint64_t) v66;
        TASSIGN(v1300, v1301);
        // pto: %168
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1302 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %168
        ;
        uint64_t v1303 = (uint64_t) v45;
        TASSIGN(v1302, v1303);
        TADD(v1302, v1296, v1300);
        // pto: %169
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1304 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %169
        ;
        uint64_t v1305 = (uint64_t) v67;
        TASSIGN(v1304, v1305);
        // pto: %422
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1306;
        // pto: %422
        ;
        uint64_t v1307 = (uint64_t) v67;
        TASSIGN(v1306, v1307);
        // pto: %170
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1308 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %170
        ;
        uint64_t v1309 = (uint64_t) v68;
        TASSIGN(v1308, v1309);
        // pto: %423
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1310;
        // pto: %423
        ;
        uint64_t v1311 = (uint64_t) v68;
        TASSIGN(v1310, v1311);
        // pto: %171
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1312 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %171
        ;
        uint64_t v1313 = (uint64_t) v40;
        TASSIGN(v1312, v1313);
        TADD(v1312, v1306, v1310);
        // pto: %172
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1314 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %172
        ;
        uint64_t v1315 = (uint64_t) v69;
        TASSIGN(v1314, v1315);
        // pto: %424
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1316;
        // pto: %424
        ;
        uint64_t v1317 = (uint64_t) v69;
        TASSIGN(v1316, v1317);
        // pto: %173
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1318 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %173
        ;
        uint64_t v1319 = (uint64_t) v64;
        TASSIGN(v1318, v1319);
        // pto: %425
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1320;
        // pto: %425
        ;
        uint64_t v1321 = (uint64_t) v64;
        TASSIGN(v1320, v1321);
        // pto: %174
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1322 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %174
        ;
        uint64_t v1323 = (uint64_t) v34;
        TASSIGN(v1322, v1323);
        pipe_barrier(PIPE_V);
        TADD(v1322, v1316, v1320);
        // pto: %175
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1324 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %175
        ;
        uint64_t v1325 = (uint64_t) v35;
        TASSIGN(v1324, v1325);
        TADD(v1324, v1292, v1312);
        // pto: %176
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1326 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %176
        ;
        uint64_t v1327 = (uint64_t) v34;
        TASSIGN(v1326, v1327);
        pipe_barrier(PIPE_V);
        TADD(v1326, v1302, v1322);
        // pto: %177
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1328 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %177
        ;
        uint64_t v1329 = (uint64_t) v35;
        TASSIGN(v1328, v1329);
        pipe_barrier(PIPE_V);
        TADD(v1328, v1324, v1326);
        // pto: %178
        ;
        Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1330 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v72);
        // pto: %178
        ;
        uint64_t v1331 = (uint64_t) v34;
        TASSIGN(v1330, v1331);
        // pto: %179
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1332 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v70);
        // pto: %179
        ;
        uint64_t v1333 = (uint64_t) v45;
        TASSIGN(v1332, v1333);
        pipe_barrier(PIPE_V);
        TROWSUM(v1332, v1328, v1330);
        // pto: %180
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1334 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %180
        ;
        uint64_t v1335 = (uint64_t) v45;
        TASSIGN(v1334, v1335);
        // pto: %181
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1336 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %181
        ;
        uint64_t v1337 = (uint64_t) v34;
        TASSIGN(v1336, v1337);
        pipe_barrier(PIPE_V);
        TMULS(v1336, v1334, v97);
        // pto: %182
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1338 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %182
        ;
        uint64_t v1339 = (uint64_t) v34;
        TASSIGN(v1338, v1339);
        pipe_barrier(PIPE_V);
        TADDS(v1338, v1336, v98);
        // pto: %183
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1340 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %183
        ;
        uint64_t v1341 = (uint64_t) v35;
        TASSIGN(v1340, v1341);
        // pto: %184
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1342 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %184
        ;
        uint64_t v1343 = (uint64_t) v45;
        TASSIGN(v1342, v1343);
        pipe_barrier(PIPE_V);
        TRSQRT(v1342, v1338, v1340);
        // pto: %185
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1344 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v70);
        // pto: %185
        ;
        uint64_t v1345 = (uint64_t) v45;
        TASSIGN(v1344, v1345);
        // pto: %186
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1346 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v77);
        // pto: %186
        ;
        uint64_t v1347 = (uint64_t) v33;
        TASSIGN(v1346, v1347);
        // pto: %426
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1348;
        // pto: %426
        ;
        uint64_t v1349 = (uint64_t) v33;
        TASSIGN(v1348, v1349);
        // pto: %187
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1350 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v77);
        // pto: %187
        ;
        uint64_t v1351 = (uint64_t) v34;
        TASSIGN(v1350, v1351);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v1350, v1348, v1344);
        // pto: %188
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1352 = Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v77);
        // pto: %188
        ;
        uint64_t v1353 = (uint64_t) v34;
        TASSIGN(v1352, v1353);
        pipe_barrier(PIPE_V);
        RoundMode v1354 = RoundMode::CAST_RINT;
        SaturationMode v1355 = SaturationMode::ON;
        TCVT(v1352, v1350, v1354, v1355);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %q__rv_v4_main_pview
        ;
        __gm__ bfloat16_t* v1356 = PTOAS__GLOBAL_TENSOR_DATA(v214);
        // pto: %q__rv_v4_main_pview
        ;
        const int64_t v1357 = 0;
        // pto: %q__rv_v4_main_pview
        ;
        const int64_t v1358 = 32768;
        // pto: %q__rv_v4_main_pview
        ;
        pto::Shape<1, 1, 1, 8, 448> v1359 = pto::Shape<1, 1, 1, 8, 448>();
        // pto: %q__rv_v4_main_pview
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v1360 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %q__rv_v4_main_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v1361 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 448>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v1356 + (v1357 + v859 * v1358 + v1246), v1359, v1360);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1361, v1352);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
        // pto: %189
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1362 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %189
        ;
        uint64_t v1363 = (uint64_t) v56;
        TASSIGN(v1362, v1363);
        // pto: %430
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1364;
        // pto: %430
        ;
        uint64_t v1365 = (uint64_t) v56;
        TASSIGN(v1364, v1365);
        // pto: %190
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1366 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %190
        ;
        uint64_t v1367 = (uint64_t) v33;
        TASSIGN(v1366, v1367);
        TROWEXPANDMUL(v1366, v1364, v1344);
        // pto: %191
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1368 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %191
        ;
        uint64_t v1369 = (uint64_t) v34;
        TASSIGN(v1368, v1369);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
        RoundMode v1370 = RoundMode::CAST_RINT;
        SaturationMode v1371 = SaturationMode::ON;
        TCVT(v1368, v1366, v1370, v1371);
        // pto: %192
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1372 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %192
        ;
        uint64_t v1373 = (uint64_t) v33;
        TASSIGN(v1372, v1373);
        pipe_barrier(PIPE_V);
        RoundMode v1374 = RoundMode::CAST_ROUND;
        SaturationMode v1375 = SaturationMode::ON;
        TCVT(v1372, v1368, v1374, v1375);
        // pto: %193
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1376 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %193
        ;
        uint64_t v1377 = (uint64_t) v34;
        TASSIGN(v1376, v1377);
        for (int64_t v1378 = v90; v1378 < v83; v1378 += v70) {
          // pto: %194
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1379 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
          // pto: %194
          ;
          uint64_t v1380 = (uint64_t) v33;
          TASSIGN(v1379, v1380);
          // pto: %432
          ;
          int64_t v1381 = (int64_t) ((uint64_t) v1378 * (uint64_t) v42);
          // pto: %432
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1382;
          // pto: %432
          ;
          uint64_t v1383 = (uint64_t) v1381;
          TASSIGN(v1382, v1383);
          // pto: %195
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1384 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
          // pto: %195
          ;
          uint64_t v1385 = (uint64_t) v39;
          TASSIGN(v1384, v1385);
          // pto: %433
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1386;
          // pto: %433
          ;
          uint64_t v1387 = (uint64_t) ((int64_t) (uint64_t) v1381 + (uint64_t) v39);
          TASSIGN(v1386, v1387);
          // pto: %196
          ;
          Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1388 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
          // pto: %196
          ;
          uint64_t v1389 = (uint64_t) v35;
          TASSIGN(v1388, v1389);
          // pto: %197
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1390 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
          // pto: %197
          ;
          uint64_t v1391 = (uint64_t) v45;
          TASSIGN(v1390, v1391);
          pipe_barrier(PIPE_V);
          TGATHER(v1390, v1382, v1386, v1388);
          // pto: %434
          ;
          Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1392;
          // pto: %434
          ;
          uint64_t v1393 = (uint64_t) ((int64_t) (uint64_t) v1381 + (uint64_t) v34);
          TASSIGN(v1392, v1393);
          pipe_barrier(PIPE_V);
          TMOV(v1392, v1390);
        };
        // pto: %199
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1394 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %199
        ;
        uint64_t v1395 = (uint64_t) v34;
        TASSIGN(v1394, v1395);
        // pto: %200
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1396 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %200
        ;
        uint64_t v1397 = (uint64_t) v33;
        TASSIGN(v1396, v1397);
        pipe_barrier(PIPE_V);
        TMUL(v1396, v1372, v865);
        // pto: %201
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1398 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %201
        ;
        uint64_t v1399 = (uint64_t) v34;
        TASSIGN(v1398, v1399);
        TMUL(v1398, v1394, v873);
        // pto: %202
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1400 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %202
        ;
        uint64_t v1401 = (uint64_t) v33;
        TASSIGN(v1400, v1401);
        pipe_barrier(PIPE_V);
        TADD(v1400, v1396, v1398);
        // pto: %203
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1402 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %203
        ;
        uint64_t v1403 = (uint64_t) v33;
        TASSIGN(v1402, v1403);
        pipe_barrier(PIPE_V);
        RoundMode v1404 = RoundMode::CAST_RINT;
        SaturationMode v1405 = SaturationMode::ON;
        TCVT(v1402, v1400, v1404, v1405);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        // pto: %437
        ;
        int64_t v1406 = (int64_t) ((uint64_t) v1243 + (uint64_t) v77);
        // pto: %438
        ;
        int64_t v1407 = v1406 < v90 ? v90 : v1406;
        // pto: %439
        ;
        __gm__ bfloat16_t* v1408 = PTOAS__GLOBAL_TENSOR_DATA(v214);
        // pto: %439
        ;
        const int64_t v1409 = 0;
        // pto: %439
        ;
        const int64_t v1410 = 32768;
        // pto: %439
        ;
        pto::Shape<1, 1, 1, 8, 64> v1411 = pto::Shape<1, 1, 1, 8, 64>();
        // pto: %439
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v1412 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %439
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v1413 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v1408 + (v1409 + v859 * v1410 + v1407), v1411, v1412);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1413, v1402);
      };
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    } else {
      // pto: %440
      ;
      int64_t v1414 = (int64_t) ((uint64_t) v27 - (uint64_t) v856);
      // pto: %qr_scale_dq_tail_inline8872__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1415 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v70);
      // pto: %qr_scale_dq_tail_inline8872__ssa_v0
      ;
      uint64_t v1416 = (uint64_t) v44;
      TASSIGN(v1415, v1416);
      // pto: %441
      ;
      int64_t v1417 = v856 < v90 ? v90 : v856;
      // pto: %442
      ;
      __gm__ float* v1418 = PTOAS__GLOBAL_TENSOR_DATA(v172);
      // pto: %442
      ;
      const int64_t v1419 = 0;
      // pto: %442
      ;
      pto::Shape<1, 1, 1, 8, 1> v1420 = pto::Shape<1, 1, 1, 8, 1>();
      // pto: %442
      ;
      pto::Stride<8, 8, 8, 1, 512> v1421 = pto::Stride<8, 8, 8, 1, 512>();
      // pto: %442
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN> v1422 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN>(v1418 + (v1419 + v1417), v1420, v1421);
      pipe_barrier(PIPE_ALL);
      TLOAD(v1415, v1422);
      // pto: %q_cos_il_tail_inline8873__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1423 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1414, v73);
      // pto: %q_cos_il_tail_inline8873__ssa_v0
      ;
      uint64_t v1424 = (uint64_t) v35;
      TASSIGN(v1423, v1424);
      // pto: %444
      ;
      const int64_t v1425 = 0;
      // pto: %444
      ;
      __gm__ float* v1426 = PTOAS__GLOBAL_TENSOR_DATA(v127);
      // pto: %444
      ;
      const int64_t v1427 = 1;
      // pto: %444
      ;
      const int64_t v1428 = 1;
      // pto: %444
      ;
      const int64_t v1429 = 1;
      // pto: %444
      ;
      int64_t v1430 = v1414 * v73;
      // pto: %444
      ;
      int64_t v1431 = v1429 * v1430;
      // pto: %444
      ;
      pto::Shape<1, 1, 1, -1, 64> v1432 = pto::Shape<1, 1, 1, -1, 64>(v1427, v1428, v1429, v1414, v73);
      // pto: %444
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1433 = pto::Stride<-1, -1, -1, -1, -1>(v1428 * v1431, v1431, v1430, v73, v70);
      // pto: %444
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1434 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1426 + (v1425 + v1417 * v73 + v90 * v70), v1432, v1433);
      pipe_barrier(PIPE_ALL);
      TLOAD(v1423, v1434);
      // pto: %q_sin_signed_tail_inline8874__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1435 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1414, v73);
      // pto: %q_sin_signed_tail_inline8874__ssa_v0
      ;
      uint64_t v1436 = (uint64_t) v45;
      TASSIGN(v1435, v1436);
      // pto: %446
      ;
      const int64_t v1437 = 0;
      // pto: %446
      ;
      __gm__ float* v1438 = PTOAS__GLOBAL_TENSOR_DATA(v155);
      // pto: %446
      ;
      const int64_t v1439 = 1;
      // pto: %446
      ;
      const int64_t v1440 = 1;
      // pto: %446
      ;
      const int64_t v1441 = 1;
      // pto: %446
      ;
      int64_t v1442 = v1414 * v73;
      // pto: %446
      ;
      int64_t v1443 = v1441 * v1442;
      // pto: %446
      ;
      pto::Shape<1, 1, 1, -1, 64> v1444 = pto::Shape<1, 1, 1, -1, 64>(v1439, v1440, v1441, v1414, v73);
      // pto: %446
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1445 = pto::Stride<-1, -1, -1, -1, -1>(v1440 * v1443, v1443, v1442, v73, v70);
      // pto: %446
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1446 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1438 + (v1437 + v1417 * v73 + v90 * v70), v1444, v1445);
      pipe_barrier(PIPE_ALL);
      TLOAD(v1435, v1446);
      // pto: %t__tmp_v42
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1447 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
      // pto: %t__tmp_v42
      ;
      uint64_t v1448 = (uint64_t) v33;
      TASSIGN(v1447, v1448);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      TEXPANDS(v1447, v85);
      // pto: %t__ci_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1449 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v86);
      // pto: %t__ci_tmp_v1
      ;
      uint64_t v1450 = (uint64_t) v34;
      TASSIGN(v1449, v1450);
      // pto: %t__tmp_v43
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1451 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
      // pto: %t__tmp_v43
      ;
      uint64_t v1452 = (uint64_t) v36;
      TASSIGN(v1451, v1452);
      // pto: %447
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1453;
      TRESHAPE(v1453, v1449);
      // pto: %448
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1454;
      TRESHAPE(v1454, v1451);
      TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v1454, v87, v1453);
      // pto: %t__tmp_v44
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1455 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v73);
      // pto: %t__tmp_v44
      ;
      uint64_t v1456 = (uint64_t) v34;
      TASSIGN(v1455, v1456);
      pipe_barrier(PIPE_V);
      RoundMode v1457 = RoundMode::CAST_ROUND;
      SaturationMode v1458 = SaturationMode::ON;
      TCVT(v1455, v1451, v1457, v1458);
      // pto: %q_col_inline8875__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1459 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
      // pto: %q_col_inline8875__ssa_v0
      ;
      uint64_t v1460 = (uint64_t) v33;
      TASSIGN(v1459, v1460);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v1459, v1447, v1455);
      // pto: %t__tmp_v45
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1461 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
      // pto: %t__tmp_v45
      ;
      uint64_t v1462 = (uint64_t) v34;
      TASSIGN(v1461, v1462);
      pipe_barrier(PIPE_V);
      TMULS(v1461, v1459, v88);
      // pto: %t__tmp_v46
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1463 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
      // pto: %t__tmp_v46
      ;
      uint64_t v1464 = (uint64_t) v34;
      TASSIGN(v1463, v1464);
      pipe_barrier(PIPE_V);
      RoundMode v1465 = RoundMode::CAST_TRUNC;
      SaturationMode v1466 = SaturationMode::ON;
      TCVT(v1463, v1461, v1465, v1466);
      // pto: %q_dup_f_inline8876__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1467 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
      // pto: %q_dup_f_inline8876__ssa_v0
      ;
      uint64_t v1468 = (uint64_t) v34;
      TASSIGN(v1467, v1468);
      pipe_barrier(PIPE_V);
      RoundMode v1469 = RoundMode::CAST_ROUND;
      SaturationMode v1470 = SaturationMode::ON;
      TCVT(v1467, v1463, v1469, v1470);
      // pto: %t__tmp_v47
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1471 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
      // pto: %t__tmp_v47
      ;
      uint64_t v1472 = (uint64_t) v34;
      TASSIGN(v1471, v1472);
      pipe_barrier(PIPE_V);
      TMULS(v1471, v1467, v89);
      // pto: %q_lane_inline8877__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1473 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
      // pto: %q_lane_inline8877__ssa_v0
      ;
      uint64_t v1474 = (uint64_t) v34;
      TASSIGN(v1473, v1474);
      pipe_barrier(PIPE_V);
      TSUB(v1473, v1459, v1471);
      // pto: %t__tmp_v48
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1475 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
      // pto: %t__tmp_v48
      ;
      uint64_t v1476 = (uint64_t) v33;
      TASSIGN(v1475, v1476);
      pipe_barrier(PIPE_V);
      TADDS(v1475, v1459, v85);
      // pto: %t__tmp_v49
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1477 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
      // pto: %t__tmp_v49
      ;
      uint64_t v1478 = (uint64_t) v34;
      TASSIGN(v1477, v1478);
      TMULS(v1477, v1473, v89);
      // pto: %q_swap_f_inline8878__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1479 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
      // pto: %q_swap_f_inline8878__ssa_v0
      ;
      uint64_t v1480 = (uint64_t) v33;
      TASSIGN(v1479, v1480);
      pipe_barrier(PIPE_V);
      TSUB(v1479, v1475, v1477);
      // pto: %t__ci_tmp_v2
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1481 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v86);
      // pto: %t__ci_tmp_v2
      ;
      uint64_t v1482 = (uint64_t) v34;
      TASSIGN(v1481, v1482);
      // pto: %t__tmp_v50
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1483 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
      // pto: %t__tmp_v50
      ;
      uint64_t v1484 = (uint64_t) v36;
      TASSIGN(v1483, v1484);
      // pto: %449
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1485;
      TRESHAPE(v1485, v1481);
      // pto: %450
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1486;
      TRESHAPE(v1486, v1483);
      pipe_barrier(PIPE_V);
      TCI<Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v1486, v87, v1485);
      // pto: %t__tmp_v51
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1487 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
      // pto: %t__tmp_v51
      ;
      uint64_t v1488 = (uint64_t) v34;
      TASSIGN(v1487, v1488);
      pipe_barrier(PIPE_V);
      RoundMode v1489 = RoundMode::CAST_ROUND;
      SaturationMode v1490 = SaturationMode::ON;
      TCVT(v1487, v1483, v1489, v1490);
      // pto: %q_row_seed_inline8879__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1491 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
      // pto: %q_row_seed_inline8879__ssa_v0
      ;
      uint64_t v1492 = (uint64_t) v36;
      TASSIGN(v1491, v1492);
      pipe_barrier(PIPE_V);
      TMULS(v1491, v1487, v99);
      // pto: %t__tmp_v52
      ;
      Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1493 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v83);
      // pto: %t__tmp_v52
      ;
      uint64_t v1494 = (uint64_t) v34;
      TASSIGN(v1493, v1494);
      pipe_barrier(PIPE_V);
      TEXPANDS(v1493, v85);
      // pto: %q_row_grid_inline8880__ssa_v0
      ;
      Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1495 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v83);
      // pto: %q_row_grid_inline8880__ssa_v0
      ;
      uint64_t v1496 = (uint64_t) v34;
      TASSIGN(v1495, v1496);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v1495, v1493, v1491);
      // pto: %transpose_tmp
      ;
      Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1497 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v83);
      // pto: %transpose_tmp
      ;
      uint64_t v1498 = (uint64_t) v36;
      TASSIGN(v1497, v1498);
      // pto: %q_row_offset_inline8881__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1499 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
      // pto: %q_row_offset_inline8881__ssa_v0
      ;
      uint64_t v1500 = (uint64_t) v38;
      TASSIGN(v1499, v1500);
      pipe_barrier(PIPE_V);
      TTRANS(v1499, v1495, v1497);
      // pto: %t__tmp_v53
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1501 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
      // pto: %t__tmp_v53
      ;
      uint64_t v1502 = (uint64_t) v33;
      TASSIGN(v1501, v1502);
      pipe_barrier(PIPE_V);
      TADD(v1501, v1479, v1499);
      // pto: %q_swap_idx_tail_inline8882__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1503 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
      // pto: %q_swap_idx_tail_inline8882__ssa_v0
      ;
      uint64_t v1504 = (uint64_t) v36;
      TASSIGN(v1503, v1504);
      pipe_barrier(PIPE_V);
      RoundMode v1505 = RoundMode::CAST_ROUND;
      SaturationMode v1506 = SaturationMode::ON;
      TCVT(v1503, v1501, v1505, v1506);
      // pto: %q_head_reduce_tmp_inline8883__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1507 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
      // pto: %q_head_reduce_tmp_inline8883__ssa_v0
      ;
      uint64_t v1508 = (uint64_t) v38;
      TASSIGN(v1507, v1508);
      // pto: %q_rsqrt_tmp_inline8884__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1509 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v70);
      // pto: %q_rsqrt_tmp_inline8884__ssa_v0
      ;
      uint64_t v1510 = (uint64_t) v47;
      TASSIGN(v1509, v1510);
      // pto: %q_gather_tmp_inline8885__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1511 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
      // pto: %q_gather_tmp_inline8885__ssa_v0
      ;
      uint64_t v1512 = (uint64_t) v39;
      TASSIGN(v1511, v1512);
      pipe_barrier(PIPE_ALL);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      for (int64_t v1513 = v90; v1513 < v830; v1513 += v70) {
        // pto: %451, %452
        ;
        int64_t v1514 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v847 + (uint64_t) v1513) * (uint64_t) v76);
        // pto: %q_head_acc_tail_inline8889__ssa_v0
        ;
        Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1515 = Tile<TileType::Vec, int32_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %q_head_acc_tail_inline8889__ssa_v0
        ;
        uint64_t v1516 = (uint64_t) v33;
        TASSIGN(v1515, v1516);
        // pto: %454
        ;
        int64_t v1517 = v1514 < v90 ? v90 : v1514;
        // pto: %455
        ;
        __gm__ int32_t* v1518 = PTOAS__GLOBAL_TENSOR_DATA(v205);
        // pto: %455
        ;
        const int64_t v1519 = 0;
        // pto: %455
        ;
        const int64_t v1520 = 32768;
        // pto: %455
        ;
        pto::Shape<1, 1, 1, 8, 512> v1521 = pto::Shape<1, 1, 1, 8, 512>();
        // pto: %455
        ;
        pto::Stride<262144, 262144, 262144, 32768, 1> v1522 = pto::Stride<262144, 262144, 262144, 32768, 1>();
        // pto: %455
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND> v1523 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<262144, 262144, 262144, 32768, 1>, pto::Layout::ND>(v1518 + (v1519 + v1417 * v1520 + v1517), v1521, v1522);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        TLOAD(v1515, v1523);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %q_head_scale_input_tail_inline8890__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1524 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
        // pto: %q_head_scale_input_tail_inline8890__ssa_v0
        ;
        uint64_t v1525 = (uint64_t) v40;
        TASSIGN(v1524, v1525);
        // pto: %457
        ;
        __gm__ float* v1526 = PTOAS__GLOBAL_TENSOR_DATA(v146);
        // pto: %457
        ;
        const int64_t v1527 = 0;
        // pto: %457
        ;
        pto::Shape<1, 1, 1, 1, 512> v1528 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %457
        ;
        pto::Stride<512, 512, 512, 512, 1> v1529 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %457
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v1530 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v1526 + (v1527 + v1517), v1528, v1529);
        TLOAD(v1524, v1530);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        // pto: %q_head_scale_tail_inline8891__ssa_v0
        ;
        Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1531 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
        // pto: %q_head_scale_tail_inline8891__ssa_v0
        ;
        uint64_t v1532 = (uint64_t) v40;
        TASSIGN(v1531, v1532);
        // pto: %q_head_acc_fp32_tail_inline8892__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1533 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %q_head_acc_fp32_tail_inline8892__ssa_v0
        ;
        uint64_t v1534 = (uint64_t) v33;
        TASSIGN(v1533, v1534);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        RoundMode v1535 = RoundMode::CAST_NONE;
        SaturationMode v1536 = SaturationMode::ON;
        TCVT(v1533, v1515, v1535, v1536);
        // pto: %t__tmp_v54
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1537 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %t__tmp_v54
        ;
        uint64_t v1538 = (uint64_t) v34;
        TASSIGN(v1537, v1538);
        TEXPANDS(v1537, v85);
        // pto: %t__tmp_v55
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1539 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %t__tmp_v55
        ;
        uint64_t v1540 = (uint64_t) v34;
        TASSIGN(v1539, v1540);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v1539, v1537, v1415);
        // pto: %q_head_scale_combined_tail_inline8893__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1541 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %q_head_scale_combined_tail_inline8893__ssa_v0
        ;
        uint64_t v1542 = (uint64_t) v34;
        TASSIGN(v1541, v1542);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
        TCOLEXPANDMUL(v1541, v1539, v1531);
        // pto: %q_head_dq_tail_inline8894__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1543 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %q_head_dq_tail_inline8894__ssa_v0
        ;
        uint64_t v1544 = (uint64_t) v33;
        TASSIGN(v1543, v1544);
        pipe_barrier(PIPE_V);
        TMUL(v1543, v1533, v1541);
        // pto: %t__tmp_v56
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1545 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %t__tmp_v56
        ;
        uint64_t v1546 = (uint64_t) v34;
        TASSIGN(v1545, v1546);
        pipe_barrier(PIPE_V);
        RoundMode v1547 = RoundMode::CAST_RINT;
        SaturationMode v1548 = SaturationMode::ON;
        TCVT(v1545, v1543, v1547, v1548);
        // pto: %q_head_dq_tail_v1_inline8895__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1549 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %q_head_dq_tail_v1_inline8895__ssa_v0
        ;
        uint64_t v1550 = (uint64_t) v33;
        TASSIGN(v1549, v1550);
        pipe_barrier(PIPE_V);
        RoundMode v1551 = RoundMode::CAST_ROUND;
        SaturationMode v1552 = SaturationMode::ON;
        TCVT(v1549, v1545, v1551, v1552);
        // pto: %q_head_sq_tail_inline8896__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1553 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v76);
        // pto: %q_head_sq_tail_inline8896__ssa_v0
        ;
        uint64_t v1554 = (uint64_t) v34;
        TASSIGN(v1553, v1554);
        pipe_barrier(PIPE_V);
        TMUL(v1553, v1549, v1549);
        // pto: %t__tmp_v57
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1555 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %t__tmp_v57
        ;
        uint64_t v1556 = (uint64_t) v34;
        TASSIGN(v1555, v1556);
        // pto: %458
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1557;
        // pto: %458
        ;
        uint64_t v1558 = (uint64_t) v34;
        TASSIGN(v1557, v1558);
        // pto: %t__tmp_v58
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1559 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %t__tmp_v58
        ;
        uint64_t v1560 = (uint64_t) v65;
        TASSIGN(v1559, v1560);
        // pto: %459
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1561;
        // pto: %459
        ;
        uint64_t v1562 = (uint64_t) v65;
        TASSIGN(v1561, v1562);
        // pto: %q_sq_04_tail_inline8897__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1563 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_sq_04_tail_inline8897__ssa_v0
        ;
        uint64_t v1564 = (uint64_t) v40;
        TASSIGN(v1563, v1564);
        pipe_barrier(PIPE_V);
        TADD(v1563, v1557, v1561);
        // pto: %t__tmp_v59
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1565 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %t__tmp_v59
        ;
        uint64_t v1566 = (uint64_t) v46;
        TASSIGN(v1565, v1566);
        // pto: %460
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1567;
        // pto: %460
        ;
        uint64_t v1568 = (uint64_t) v46;
        TASSIGN(v1567, v1568);
        // pto: %t__tmp_v60
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1569 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %t__tmp_v60
        ;
        uint64_t v1570 = (uint64_t) v66;
        TASSIGN(v1569, v1570);
        // pto: %461
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1571;
        // pto: %461
        ;
        uint64_t v1572 = (uint64_t) v66;
        TASSIGN(v1571, v1572);
        // pto: %q_sq_15_tail_inline8898__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1573 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_sq_15_tail_inline8898__ssa_v0
        ;
        uint64_t v1574 = (uint64_t) v41;
        TASSIGN(v1573, v1574);
        TADD(v1573, v1567, v1571);
        // pto: %t__tmp_v61
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1575 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %t__tmp_v61
        ;
        uint64_t v1576 = (uint64_t) v67;
        TASSIGN(v1575, v1576);
        // pto: %462
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1577;
        // pto: %462
        ;
        uint64_t v1578 = (uint64_t) v67;
        TASSIGN(v1577, v1578);
        // pto: %t__tmp_v62
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1579 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %t__tmp_v62
        ;
        uint64_t v1580 = (uint64_t) v68;
        TASSIGN(v1579, v1580);
        // pto: %463
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1581;
        // pto: %463
        ;
        uint64_t v1582 = (uint64_t) v68;
        TASSIGN(v1581, v1582);
        // pto: %q_sq_26_tail_inline8899__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1583 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_sq_26_tail_inline8899__ssa_v0
        ;
        uint64_t v1584 = (uint64_t) v43;
        TASSIGN(v1583, v1584);
        TADD(v1583, v1577, v1581);
        // pto: %t__tmp_v63
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1585 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %t__tmp_v63
        ;
        uint64_t v1586 = (uint64_t) v69;
        TASSIGN(v1585, v1586);
        // pto: %464
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1587;
        // pto: %464
        ;
        uint64_t v1588 = (uint64_t) v69;
        TASSIGN(v1587, v1588);
        // pto: %t__tmp_v64
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1589 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %t__tmp_v64
        ;
        uint64_t v1590 = (uint64_t) v64;
        TASSIGN(v1589, v1590);
        // pto: %465
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1591;
        // pto: %465
        ;
        uint64_t v1592 = (uint64_t) v64;
        TASSIGN(v1591, v1592);
        // pto: %q_sq_37_tail_inline8900__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1593 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_sq_37_tail_inline8900__ssa_v0
        ;
        uint64_t v1594 = (uint64_t) v34;
        TASSIGN(v1593, v1594);
        pipe_barrier(PIPE_V);
        TADD(v1593, v1587, v1591);
        // pto: %q_sq_0246_tail_inline8901__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1595 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_sq_0246_tail_inline8901__ssa_v0
        ;
        uint64_t v1596 = (uint64_t) v40;
        TASSIGN(v1595, v1596);
        TADD(v1595, v1563, v1583);
        // pto: %q_sq_1357_tail_inline8902__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1597 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_sq_1357_tail_inline8902__ssa_v0
        ;
        uint64_t v1598 = (uint64_t) v34;
        TASSIGN(v1597, v1598);
        pipe_barrier(PIPE_V);
        TADD(v1597, v1573, v1593);
        // pto: %q_sq_64_tail_inline8903__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1599 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_sq_64_tail_inline8903__ssa_v0
        ;
        uint64_t v1600 = (uint64_t) v34;
        TASSIGN(v1599, v1600);
        pipe_barrier(PIPE_V);
        TADD(v1599, v1595, v1597);
        // pto: %q_head_sq_sum_tail_inline8904__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1601 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v70);
        // pto: %q_head_sq_sum_tail_inline8904__ssa_v0
        ;
        uint64_t v1602 = (uint64_t) v40;
        TASSIGN(v1601, v1602);
        pipe_barrier(PIPE_V);
        TROWSUM(v1601, v1599, v1507);
        // pto: %t__rm_a0_tmp_v4
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1603 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %t__rm_a0_tmp_v4
        ;
        uint64_t v1604 = (uint64_t) v40;
        TASSIGN(v1603, v1604);
        // pto: %t__row_major_tmp_v5
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1605 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %t__row_major_tmp_v5
        ;
        uint64_t v1606 = (uint64_t) v34;
        TASSIGN(v1605, v1606);
        pipe_barrier(PIPE_V);
        TMULS(v1605, v1603, v97);
        // pto: %t__tmp_v65
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1607 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v70);
        // pto: %t__tmp_v65
        ;
        uint64_t v1608 = (uint64_t) v34;
        TASSIGN(v1607, v1608);
        // pto: %q_head_var_tail_inline8905__rm_a0_tmp_v6
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1609 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %q_head_var_tail_inline8905__rm_a0_tmp_v6
        ;
        uint64_t v1610 = (uint64_t) v34;
        TASSIGN(v1609, v1610);
        // pto: %q_head_var_tail_inline8905__row_major_tmp_v7
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1611 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %q_head_var_tail_inline8905__row_major_tmp_v7
        ;
        uint64_t v1612 = (uint64_t) v34;
        TASSIGN(v1611, v1612);
        pipe_barrier(PIPE_V);
        TADDS(v1611, v1609, v98);
        // pto: %q_head_var_tail_inline8905__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1613 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v70);
        // pto: %q_head_var_tail_inline8905__ssa_v0
        ;
        uint64_t v1614 = (uint64_t) v34;
        TASSIGN(v1613, v1614);
        // pto: %q_head_inv_rms_tail_inline8906__rm_a0_tmp_v8
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1615 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %q_head_inv_rms_tail_inline8906__rm_a0_tmp_v8
        ;
        uint64_t v1616 = (uint64_t) v34;
        TASSIGN(v1615, v1616);
        // pto: %q_head_inv_rms_tail_inline8906__rm_a1_tmp_v9
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1617 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %q_head_inv_rms_tail_inline8906__rm_a1_tmp_v9
        ;
        uint64_t v1618 = (uint64_t) v47;
        TASSIGN(v1617, v1618);
        // pto: %q_head_inv_rms_tail_inline8906__row_major_tmp_v10
        ;
        Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1619 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v83);
        // pto: %q_head_inv_rms_tail_inline8906__row_major_tmp_v10
        ;
        uint64_t v1620 = (uint64_t) v40;
        TASSIGN(v1619, v1620);
        pipe_barrier(PIPE_V);
        TRSQRT(v1619, v1615, v1617);
        // pto: %q_head_inv_rms_tail_inline8906__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1621 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v70);
        // pto: %q_head_inv_rms_tail_inline8906__ssa_v0
        ;
        uint64_t v1622 = (uint64_t) v40;
        TASSIGN(v1621, v1622);
        // pto: %t__tmp_v66
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1623 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v77);
        // pto: %t__tmp_v66
        ;
        uint64_t v1624 = (uint64_t) v33;
        TASSIGN(v1623, v1624);
        // pto: %466
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1625;
        // pto: %466
        ;
        uint64_t v1626 = (uint64_t) v33;
        TASSIGN(v1625, v1626);
        // pto: %q_nope_normed_tail_inline8907__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1627 = Tile<TileType::Vec, float, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v77);
        // pto: %q_nope_normed_tail_inline8907__ssa_v0
        ;
        uint64_t v1628 = (uint64_t) v34;
        TASSIGN(v1627, v1628);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v1627, v1625, v1621);
        // pto: %q_nope_bf16_tail_inline8908__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1629 = Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v77);
        // pto: %q_nope_bf16_tail_inline8908__ssa_v0
        ;
        uint64_t v1630 = (uint64_t) v34;
        TASSIGN(v1629, v1630);
        pipe_barrier(PIPE_V);
        RoundMode v1631 = RoundMode::CAST_RINT;
        SaturationMode v1632 = SaturationMode::ON;
        TCVT(v1629, v1627, v1631, v1632);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1629.SetValidShape(v1414, v77);
        // pto: %q__iter_v1_pview
        ;
        const int64_t v1633 = 0;
        // pto: %q__iter_v1_pview
        ;
        __gm__ bfloat16_t* v1634 = PTOAS__GLOBAL_TENSOR_DATA(v214);
        // pto: %q__iter_v1_pview
        ;
        const int64_t v1635 = 1;
        // pto: %q__iter_v1_pview
        ;
        const int64_t v1636 = 1;
        // pto: %q__iter_v1_pview
        ;
        const int64_t v1637 = 1;
        // pto: %q__iter_v1_pview
        ;
        int64_t v1638 = v1414 * v75;
        // pto: %q__iter_v1_pview
        ;
        int64_t v1639 = v1637 * v1638;
        // pto: %q__iter_v1_pview
        ;
        pto::Shape<1, 1, 1, -1, 448> v1640 = pto::Shape<1, 1, 1, -1, 448>(v1635, v1636, v1637, v1414, v77);
        // pto: %q__iter_v1_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1641 = pto::Stride<-1, -1, -1, -1, -1>(v1636 * v1639, v1639, v1638, v75, v70);
        // pto: %q__iter_v1_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 448>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1642 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 448>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1634 + (v1633 + v1417 * v75 + v1517 * v70), v1640, v1641);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1642, v1629);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
        // pto: %q_rope_chunk_raw_tail_inline8910__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1643 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_rope_chunk_raw_tail_inline8910__ssa_v0
        ;
        uint64_t v1644 = (uint64_t) v56;
        TASSIGN(v1643, v1644);
        // pto: %469
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1645;
        // pto: %469
        ;
        uint64_t v1646 = (uint64_t) v56;
        TASSIGN(v1645, v1646);
        // pto: %q_rope_chunk_tail_inline8911__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1647 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_rope_chunk_tail_inline8911__ssa_v0
        ;
        uint64_t v1648 = (uint64_t) v33;
        TASSIGN(v1647, v1648);
        TROWEXPANDMUL(v1647, v1645, v1621);
        // pto: %t__tmp_v67
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1649 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %t__tmp_v67
        ;
        uint64_t v1650 = (uint64_t) v34;
        TASSIGN(v1649, v1650);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
        RoundMode v1651 = RoundMode::CAST_RINT;
        SaturationMode v1652 = SaturationMode::ON;
        TCVT(v1649, v1647, v1651, v1652);
        // pto: %q_rope_chunk_tail_v1_inline8912__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1653 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_rope_chunk_tail_v1_inline8912__ssa_v0
        ;
        uint64_t v1654 = (uint64_t) v33;
        TASSIGN(v1653, v1654);
        pipe_barrier(PIPE_V);
        RoundMode v1655 = RoundMode::CAST_ROUND;
        SaturationMode v1656 = SaturationMode::ON;
        TCVT(v1653, v1649, v1655, v1656);
        // pto: %q_rope_swapped_tail_inline8913__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1657 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v83, v73);
        // pto: %q_rope_swapped_tail_inline8913__ssa_v0
        ;
        uint64_t v1658 = (uint64_t) v34;
        TASSIGN(v1657, v1658);
        pipe_barrier(PIPE_V);
        TGATHER(v1657, v1653, v1503, v1511);
        v1653.SetValidShape(v1414, v73);
        v1657.SetValidShape(v1414, v73);
        // pto: %q_rope_base_tail_inline8916__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1659 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1414, v73);
        // pto: %q_rope_base_tail_inline8916__ssa_v0
        ;
        uint64_t v1660 = (uint64_t) v33;
        TASSIGN(v1659, v1660);
        pipe_barrier(PIPE_V);
        TMUL(v1659, v1653, v1423);
        // pto: %q_rope_delta_tail_inline8917__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1661 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1414, v73);
        // pto: %q_rope_delta_tail_inline8917__ssa_v0
        ;
        uint64_t v1662 = (uint64_t) v34;
        TASSIGN(v1661, v1662);
        TMUL(v1661, v1657, v1435);
        // pto: %q_rope_rot_tail_inline8918__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1663 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1414, v73);
        // pto: %q_rope_rot_tail_inline8918__ssa_v0
        ;
        uint64_t v1664 = (uint64_t) v33;
        TASSIGN(v1663, v1664);
        pipe_barrier(PIPE_V);
        TADD(v1663, v1659, v1661);
        // pto: %q_rope_bf16_tail_inline8919__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1665 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1414, v73);
        // pto: %q_rope_bf16_tail_inline8919__ssa_v0
        ;
        uint64_t v1666 = (uint64_t) v33;
        TASSIGN(v1665, v1666);
        pipe_barrier(PIPE_V);
        RoundMode v1667 = RoundMode::CAST_RINT;
        SaturationMode v1668 = SaturationMode::ON;
        TCVT(v1665, v1663, v1667, v1668);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        v1665.SetValidShape(v1414, v73);
        // pto: %471
        ;
        int64_t v1669 = (int64_t) ((uint64_t) v1514 + (uint64_t) v77);
        // pto: %472
        ;
        int64_t v1670 = v1669 < v90 ? v90 : v1669;
        // pto: %473
        ;
        const int64_t v1671 = 0;
        // pto: %473
        ;
        __gm__ bfloat16_t* v1672 = PTOAS__GLOBAL_TENSOR_DATA(v214);
        // pto: %473
        ;
        const int64_t v1673 = 1;
        // pto: %473
        ;
        const int64_t v1674 = 1;
        // pto: %473
        ;
        const int64_t v1675 = 1;
        // pto: %473
        ;
        int64_t v1676 = v1414 * v75;
        // pto: %473
        ;
        int64_t v1677 = v1675 * v1676;
        // pto: %473
        ;
        pto::Shape<1, 1, 1, -1, 64> v1678 = pto::Shape<1, 1, 1, -1, 64>(v1673, v1674, v1675, v1414, v73);
        // pto: %473
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1679 = pto::Stride<-1, -1, -1, -1, -1>(v1674 * v1677, v1677, v1676, v75, v70);
        // pto: %473
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1680 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1672 + (v1671 + v1417 * v75 + v1670 * v70), v1678, v1679);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
        TSTORE(v1680, v1665);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      };
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    };
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}