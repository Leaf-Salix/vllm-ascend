#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void oproj_a(__gm__ float* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, int64_t v5, int64_t v6, int64_t v7, int64_t v8, int64_t v9, int32_t v10, int32_t v11) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c131072_i64
  const int64_t v12 = 131072;
  // pto: %c196608_i64
  const int64_t v13 = 196608;
  // pto: %c0_i64
  const int64_t v14 = 0;
  // pto: %c32768_i64
  const int64_t v15 = 32768;
  // pto: %c65536_i64
  const int64_t v16 = 65536;
  // pto: %c8192_index
  const int64_t v17 = 8192;
  // pto: %c1_index
  const int64_t v18 = 1;
  // pto: %c16_index
  const int64_t v19 = 16;
  // pto: %c8_index
  const int64_t v20 = 8;
  // pto: %c32768_index
  const int64_t v21 = 32768;
  const int64_t v22 = 64;
  // pto: %c256_index
  const int64_t v23 = 256;
  // pto: %c4194304_index
  const int64_t v24 = 4194304;
  // pto: %c65536_index
  const int64_t v25 = 65536;
  const int64_t v26 = 128;
  // pto: %c0_index
  const int64_t v27 = 0;
  // pto: %c7_index
  const int64_t v28 = 7;
  // pto: %c2_index
  const int64_t v29 = 2;
  // pto: %c3_index
  const int64_t v30 = 3;
  // pto: %c4_index
  const int64_t v31 = 4;
  // pto: %c5_index
  const int64_t v32 = 5;
  // pto: %c6_index
  const int64_t v33 = 6;
  // pto: %c240_index
  const int64_t v34 = 240;
  // pto: %c4096_index
  const int64_t v35 = 4096;
  // pto: %c15_index
  const int64_t v36 = 15;
  // pto: %c1024_index
  const int64_t v37 = 1024;
  // pto: %c127_index
  const int64_t v38 = 127;
  // pto: %313
  int64_t v39 = (int64_t) ((uint64_t) v8 + (uint64_t) v38);
  // pto: %accum_inline5581__iter_v1_view
  const int64_t v40 = 1;
  // pto: %accum_inline5581__iter_v1_view
  const int64_t v41 = 1;
  // pto: %accum_inline5581__iter_v1_view
  const int64_t v42 = 1;
  // pto: %accum_inline5581__iter_v1_view
  int64_t v43 = v39 * v17;
  // pto: %accum_inline5581__iter_v1_view
  int64_t v44 = v42 * v43;
  // pto: %accum_inline5581__iter_v1_view
  pto::Shape<1, 1, 1, -1, -1> v45 = pto::Shape<1, 1, 1, -1, -1>(v40, v41, v42, v39, v17);
  // pto: %accum_inline5581__iter_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v46 = pto::Stride<-1, -1, -1, -1, -1>(v41 * v44, v44, v43, v17, v18);
  // pto: %accum_inline5581__iter_v1_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v47 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v45, v46);
  // pto: %heads__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v49 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v50 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v51 = (int64_t) v9;
  // pto: %heads__ssa_v0_view
  int64_t v52 = v51 * v21;
  // pto: %heads__ssa_v0_view
  int64_t v53 = v50 * v52;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v54 = pto::Shape<1, 1, 1, -1, -1>(v48, v49, v50, v51, v21);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v55 = pto::Stride<-1, -1, -1, -1, -1>(v49 * v53, v53, v52, v21, v18);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v56 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v54, v55);
  // pto: %wo_a__ssa_v0_view
  pto::Shape<-1, -1, -1, -1, -1> v57 = pto::Shape<-1, -1, -1, -1, -1>(v20, v22, v23, v19, v19);
  // pto: %wo_a__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v58 = pto::Stride<-1, -1, -1, -1, -1>(v24, v25, v23, v19, v18);
  // pto: %wo_a__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ> v59 = GlobalTensor<bfloat16_t, pto::Shape<-1, -1, -1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::NZ>(v4, v57, v58);
  // pto: %seed_fast_acc_inline5594__phi_v7
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v60 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
  // pto: %seed_fast_acc_inline5594__phi_v7
  uint64_t v61 = (uint64_t) v14;
  TASSIGN(v60, v61);
  // pto: %183
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v62 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
  // pto: %183
  uint64_t v63 = (uint64_t) v14;
  TASSIGN(v62, v63);
  // pto: %221
  Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v64 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
  // pto: %221
  uint64_t v65 = (uint64_t) v14;
  TASSIGN(v64, v65);
  // pto: %seed_narrow_acc_inline5609__phi_v7
  Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v66 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v19, v26);
  // pto: %seed_narrow_acc_inline5609__phi_v7
  uint64_t v67 = (uint64_t) v14;
  TASSIGN(v66, v67);
  // pto: %seed_block_inline5583__ssa_v0
  int64_t v68 = (int64_t) v10;
  // pto: %37
  int64_t v69 = (int64_t) ((uint64_t) v68 * (uint64_t) v26);
  // pto: %38
  int64_t v70 = (int64_t) ((uint64_t) v5 + (uint64_t) v28);
  // pto: %39
  const int64_t v71 = 1;
  // pto: %39
  const int64_t v72 = 0;
  // pto: %39
  int64_t v73 = v70 / v20;
  // pto: %39
  bool v74 = v70 < v72;
  // pto: %39
  bool v75 = v20 < v72;
  // pto: %39
  bool v76 = v74 == v75;
  // pto: %39
  bool v77 = v70 % v20 != v72 && v74 != v75;
  // pto: %39
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  for (int64_t v78 = v27; v78 < (v77 ? v73 - v71 : v73); v78 += v18) {
    // pto: %40
    ;
    int64_t v79 = (int64_t) ((uint64_t) v78 * (uint64_t) v20);
    // pto: %flat_offset, %41, %42, %t__tile
    ;
    int32_t v80 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v78 * (uint64_t) v22) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
    // pto: %43
    ;
    int64_t v81 = (int64_t) v80;
    // pto: %44
    ;
    int64_t v82 = v81 < v27 ? v27 : v81;
    // pto: %45
    ;
    int64_t v83 = (int64_t) ((uint64_t) v79 + (uint64_t) v18);
    // pto: %46
    ;
    // pto: %seed_same_start_inline5588__phi_v3
    ;
    int64_t v84;
    if (v83 < v5) {
      // pto: %49, %50, %51, %52, %47
      ;
      int32_t v85 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v83 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %53
      ;
      int64_t v86 = (int64_t) v85;
      // pto: %54
      ;
      int64_t v87 = v86 < v27 ? v27 : v86;
      // pto: %55, %seed_same_start_inline5588__phi_v2
      ;
      v84 = v87 != v82 ? v27 : v18;
    } else {
      v84 = v18;
    };
    // pto: %56
    ;
    int64_t v88 = (int64_t) ((uint64_t) v79 + (uint64_t) v29);
    // pto: %57
    ;
    // pto: %seed_same_start_inline5588__phi_v6
    ;
    int64_t v89;
    if (v88 < v5) {
      // pto: %60, %61, %62, %63, %58
      ;
      int32_t v90 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v88 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %64
      ;
      int64_t v91 = (int64_t) v90;
      // pto: %65
      ;
      int64_t v92 = v91 < v27 ? v27 : v91;
      // pto: %66, %seed_same_start_inline5588__phi_v5
      ;
      int64_t v93 = v92 != v82 ? v27 : v84;
      v89 = v93;
    } else {
      v89 = v84;
    };
    // pto: %67
    ;
    int64_t v94 = (int64_t) ((uint64_t) v79 + (uint64_t) v30);
    // pto: %68
    ;
    // pto: %seed_same_start_inline5588__phi_v9
    ;
    int64_t v95;
    if (v94 < v5) {
      // pto: %71, %72, %73, %74, %69
      ;
      int32_t v96 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v94 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %75
      ;
      int64_t v97 = (int64_t) v96;
      // pto: %76
      ;
      int64_t v98 = v97 < v27 ? v27 : v97;
      // pto: %77, %seed_same_start_inline5588__phi_v8
      ;
      int64_t v99 = v98 != v82 ? v27 : v89;
      v95 = v99;
    } else {
      v95 = v89;
    };
    // pto: %78
    ;
    int64_t v100 = (int64_t) ((uint64_t) v79 + (uint64_t) v31);
    // pto: %79
    ;
    // pto: %seed_same_start_inline5588__phi_v12
    ;
    int64_t v101;
    if (v100 < v5) {
      // pto: %82, %83, %84, %85, %80
      ;
      int32_t v102 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v100 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %86
      ;
      int64_t v103 = (int64_t) v102;
      // pto: %87
      ;
      int64_t v104 = v103 < v27 ? v27 : v103;
      // pto: %88, %seed_same_start_inline5588__phi_v11
      ;
      int64_t v105 = v104 != v82 ? v27 : v95;
      v101 = v105;
    } else {
      v101 = v95;
    };
    // pto: %89
    ;
    int64_t v106 = (int64_t) ((uint64_t) v79 + (uint64_t) v32);
    // pto: %90
    ;
    // pto: %seed_same_start_inline5588__phi_v15
    ;
    int64_t v107;
    if (v106 < v5) {
      // pto: %93, %94, %95, %96, %91
      ;
      int32_t v108 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v106 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %97
      ;
      int64_t v109 = (int64_t) v108;
      // pto: %98
      ;
      int64_t v110 = v109 < v27 ? v27 : v109;
      // pto: %99, %seed_same_start_inline5588__phi_v14
      ;
      int64_t v111 = v110 != v82 ? v27 : v101;
      v107 = v111;
    } else {
      v107 = v101;
    };
    // pto: %100
    ;
    int64_t v112 = (int64_t) ((uint64_t) v79 + (uint64_t) v33);
    // pto: %101
    ;
    // pto: %seed_same_start_inline5588__phi_v18
    ;
    int64_t v113;
    if (v112 < v5) {
      // pto: %104, %105, %106, %107, %102
      ;
      int32_t v114 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v112 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %108
      ;
      int64_t v115 = (int64_t) v114;
      // pto: %109
      ;
      int64_t v116 = v115 < v27 ? v27 : v115;
      // pto: %110, %seed_same_start_inline5588__phi_v17
      ;
      int64_t v117 = v116 != v82 ? v27 : v107;
      v113 = v117;
    } else {
      v113 = v107;
    };
    // pto: %111
    ;
    int64_t v118 = (int64_t) ((uint64_t) v79 + (uint64_t) v28);
    // pto: %112
    ;
    // pto: %seed_same_start_inline5588__phi_v21
    ;
    int64_t v119;
    if (v118 < v5) {
      // pto: %115, %116, %117, %118, %113
      ;
      int32_t v120 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v118 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
      // pto: %119
      ;
      int64_t v121 = (int64_t) v120;
      // pto: %120
      ;
      int64_t v122 = v121 < v27 ? v27 : v121;
      // pto: %121, %seed_same_start_inline5588__phi_v20
      ;
      int64_t v123 = v122 != v82 ? v27 : v113;
      v119 = v123;
    } else {
      v119 = v113;
    };
    // pto: %122, %seed_same_start_inline5588__phi_v25
    ;
    int64_t v124 = v82 > v34 ? v27 : v119;
    // pto: %123
    ;
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    if (v124 == v18) {
      int64_t v125 = (int64_t) ((uint64_t) v78 * (uint64_t) v26);
      // pto: %125
      ;
      int64_t v126 = (int64_t) ((uint64_t) v8 - (uint64_t) v125);
      // pto: %126
      ;
      int64_t v127 = v126 < v26 ? v126 : v26;
      // pto: %127
      ;
      int64_t v128 = (int64_t) ((uint64_t) v82 * (uint64_t) v19);
      // pto: %seed_fast_seed_x_inline5592__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v127, v23);
      // pto: %seed_fast_seed_x_inline5592__tile
      ;
      uint64_t v130 = (uint64_t) v12;
      TASSIGN(v129, v130);
      // pto: %128
      ;
      int64_t v131 = v125 < v27 ? v27 : v125;
      // pto: %129
      ;
      int64_t v132 = (int64_t) ((uint64_t) v6 * (uint64_t) v35);
      // pto: %130
      ;
      int64_t v133 = (int64_t) ((uint64_t) v132 + (uint64_t) v128);
      // pto: %131
      ;
      int64_t v134 = v133 < v27 ? v27 : v133;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v135 = 0;
      // pto: %heads__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v136 = PTOAS__GLOBAL_TENSOR_DATA(v56);
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v137 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v138 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      const int64_t v139 = 1;
      // pto: %heads__ssa_v0_pview
      ;
      int64_t v140 = v127 * v21;
      // pto: %heads__ssa_v0_pview
      ;
      int64_t v141 = v139 * v140;
      // pto: %heads__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 256> v142 = pto::Shape<1, 1, 1, -1, 256>(v137, v138, v139, v127, v23);
      // pto: %heads__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v143 = pto::Stride<-1, -1, -1, -1, -1>(v138 * v141, v141, v140, v21, v18);
      // pto: %heads__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v144 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v136 + (v135 + v131 * v21 + v134 * v18), v142, v143);
      TLOAD(v129, v144);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %seed_fast_seed_w_inline5593__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
      // pto: %seed_fast_seed_w_inline5593__tile
      ;
      uint64_t v146 = (uint64_t) v13;
      TASSIGN(v145, v146);
      // pto: %132
      ;
      int64_t v147 = v6 < v27 ? v27 : v6;
      // pto: %133
      ;
      const int64_t v148 = 1;
      // pto: %133
      ;
      const int64_t v149 = 0;
      // pto: %133
      ;
      int64_t v150 = v69 / v19;
      // pto: %133
      ;
      bool v151 = v69 < v149;
      // pto: %133
      ;
      bool v152 = v19 < v149;
      // pto: %133
      ;
      bool v153 = v151 == v152;
      // pto: %133
      ;
      bool v154 = v69 % v19 != v149 && v151 != v152;
      // pto: %133
      ;
      int64_t v155 = v154 ? v150 - v148 : v150;
      // pto: %134
      ;
      int64_t v156 = v155 < v27 ? v27 : v155;
      // pto: %135
      ;
      const int64_t v157 = 1;
      // pto: %135
      ;
      const int64_t v158 = 0;
      // pto: %135
      ;
      int64_t v159 = v128 / v19;
      // pto: %135
      ;
      bool v160 = v128 < v158;
      // pto: %135
      ;
      bool v161 = v19 < v158;
      // pto: %135
      ;
      bool v162 = v160 == v161;
      // pto: %135
      ;
      bool v163 = v128 % v19 != v158 && v160 != v161;
      // pto: %135
      ;
      int64_t v164 = v163 ? v159 - v157 : v159;
      // pto: %136
      ;
      int64_t v165 = v164 < v27 ? v27 : v164;
      // pto: %wo_a__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v166 = PTOAS__GLOBAL_TENSOR_DATA(v59);
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v167 = 0;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v168 = 4194304;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v169 = 65536;
      // pto: %wo_a__ssa_v0_pview
      ;
      const int64_t v170 = 256;
      // pto: %wo_a__ssa_v0_pview
      ;
      pto::Shape<1, 8, 16, 16, 16> v171 = pto::Shape<1, 8, 16, 16, 16>();
      // pto: %wo_a__ssa_v0_pview
      ;
      pto::Stride<4194304, 65536, 256, 16, 1> v172 = pto::Stride<4194304, 65536, 256, 16, 1>();
      // pto: %wo_a__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v173 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v166 + ((v167 + v147 * v168) + v156 * v169 + v165 * v170), v171, v172);
      TLOAD(v145, v173);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %seed_fast_acc_inline5594__tile_l0_init_storage
      ;
      Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v174 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v26, v26);
      // pto: %seed_fast_acc_inline5594__tile_l0_init_storage
      ;
      uint64_t v175 = (uint64_t) v14;
      TASSIGN(v174, v175);
      v174.SetValidShape(v127, v26);
      // pto: %seed_fast_acc_inline5594__tile_l0_a
      ;
      Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v176 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v127, v26);
      // pto: %seed_fast_acc_inline5594__tile_l0_a
      ;
      uint64_t v177 = (uint64_t) v14;
      TASSIGN(v176, v177);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      uint16_t v178 = static_cast<uint16_t>(v27);
      uint16_t v179 = static_cast<uint16_t>(v27);
      TEXTRACT(v176, v129, v178, v179);
      // pto: %seed_fast_acc_inline5594__tile_l0_b
      ;
      Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v180 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
      // pto: %seed_fast_acc_inline5594__tile_l0_b
      ;
      uint64_t v181 = (uint64_t) v15;
      TASSIGN(v180, v181);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      uint16_t v182 = static_cast<uint16_t>(v27);
      uint16_t v183 = static_cast<uint16_t>(v27);
      TEXTRACT(v180, v145, v182, v183);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v184 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v127, v26);
      // pto: %0
      ;
      uint64_t v185 = (uint64_t) v15;
      TASSIGN(v184, v185);
      uint16_t v186 = static_cast<uint16_t>(v27);
      uint16_t v187 = static_cast<uint16_t>(v26);
      TEXTRACT(v184, v129, v186, v187);
      // pto: %1
      ;
      Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v188 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
      // pto: %1
      ;
      uint64_t v189 = (uint64_t) v14;
      TASSIGN(v188, v189);
      uint16_t v190 = static_cast<uint16_t>(v26);
      uint16_t v191 = static_cast<uint16_t>(v27);
      TEXTRACT(v188, v145, v190, v191);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      TMATMUL(v174, v176, v180);
      pipe_barrier(PIPE_M);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
      TMATMUL_ACC(v174, v174, v184, v188);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      for (int64_t v192 = v18; v192 < v36; v192 += v29) {
        // pto: %137
        ;
        int64_t v193 = (int64_t) ((uint64_t) v192 * (uint64_t) v19);
        // pto: %138, %139
        ;
        int64_t v194 = (int64_t) ((uint64_t) v82 + (uint64_t) v193) % v23;
        // pto: %140, %141, %142
        ;
        int64_t v195 = v194 < v27 ? (int64_t) ((uint64_t) v194 + (uint64_t) v23) : v194;
        // pto: %145, %144, %146
        ;
        int64_t v196 = (int64_t) ((uint64_t) v82 + (uint64_t) ((int64_t) (uint64_t) v193 + (uint64_t) v19)) % v23;
        // pto: %147, %148, %149
        ;
        int64_t v197 = v196 < v27 ? (int64_t) ((uint64_t) v196 + (uint64_t) v23) : v196;
        // pto: %150
        ;
        // pto: %151
        ;
        int64_t v198 = v127 < v26 ? v127 : v26;
        v60.SetValidShape(v198, v26);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        if (v195 <= v34) {
          // pto: %152
          ;
          int64_t v199 = (int64_t) ((uint64_t) v195 * (uint64_t) v19);
          // pto: %seed_fast_packet_x_inline5598__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v200 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v127, v23);
          // pto: %seed_fast_packet_x_inline5598__tile
          ;
          uint64_t v201 = (uint64_t) v12;
          TASSIGN(v200, v201);
          // pto: %155
          ;
          int64_t v202 = (int64_t) ((uint64_t) v132 + (uint64_t) v199);
          // pto: %156
          ;
          int64_t v203 = v202 < v27 ? v27 : v202;
          // pto: %157
          ;
          const int64_t v204 = 0;
          // pto: %157
          ;
          __gm__ bfloat16_t* v205 = PTOAS__GLOBAL_TENSOR_DATA(v56);
          // pto: %157
          ;
          const int64_t v206 = 1;
          // pto: %157
          ;
          const int64_t v207 = 1;
          // pto: %157
          ;
          const int64_t v208 = 1;
          // pto: %157
          ;
          int64_t v209 = v127 * v21;
          // pto: %157
          ;
          int64_t v210 = v208 * v209;
          // pto: %157
          ;
          pto::Shape<1, 1, 1, -1, 256> v211 = pto::Shape<1, 1, 1, -1, 256>(v206, v207, v208, v127, v23);
          // pto: %157
          ;
          pto::Stride<-1, -1, -1, -1, -1> v212 = pto::Stride<-1, -1, -1, -1, -1>(v207 * v210, v210, v209, v21, v18);
          // pto: %157
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v213 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v205 + (v204 + v131 * v21 + v203 * v18), v211, v212);
          TLOAD(v200, v213);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          // pto: %seed_fast_packet_w_inline5599__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
          // pto: %seed_fast_packet_w_inline5599__tile
          ;
          uint64_t v215 = (uint64_t) v13;
          TASSIGN(v214, v215);
          // pto: %161
          ;
          const int64_t v216 = 1;
          // pto: %161
          ;
          const int64_t v217 = 0;
          // pto: %161
          ;
          int64_t v218 = v199 / v19;
          // pto: %161
          ;
          bool v219 = v199 < v217;
          // pto: %161
          ;
          bool v220 = v19 < v217;
          // pto: %161
          ;
          bool v221 = v219 == v220;
          // pto: %161
          ;
          bool v222 = v199 % v19 != v217 && v219 != v220;
          // pto: %161
          ;
          int64_t v223 = v222 ? v218 - v216 : v218;
          // pto: %162
          ;
          int64_t v224 = v223 < v27 ? v27 : v223;
          // pto: %163
          ;
          __gm__ bfloat16_t* v225 = PTOAS__GLOBAL_TENSOR_DATA(v59);
          // pto: %163
          ;
          const int64_t v226 = 0;
          // pto: %163
          ;
          const int64_t v227 = 4194304;
          // pto: %163
          ;
          const int64_t v228 = 65536;
          // pto: %163
          ;
          const int64_t v229 = 256;
          // pto: %163
          ;
          pto::Shape<1, 8, 16, 16, 16> v230 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %163
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v231 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %163
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v232 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v225 + ((v226 + v147 * v227) + v156 * v228 + v224 * v229), v230, v231);
          TLOAD(v214, v232);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
          // pto: %seed_fast_acc_inline5594__iter_v1_l0_a
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v233 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v127, v26);
          // pto: %seed_fast_acc_inline5594__iter_v1_l0_a
          ;
          uint64_t v234 = (uint64_t) v14;
          TASSIGN(v233, v234);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
          uint16_t v235 = static_cast<uint16_t>(v27);
          uint16_t v236 = static_cast<uint16_t>(v27);
          TEXTRACT(v233, v200, v235, v236);
          // pto: %seed_fast_acc_inline5594__iter_v1_l0_b
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v237 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %seed_fast_acc_inline5594__iter_v1_l0_b
          ;
          uint64_t v238 = (uint64_t) v15;
          TASSIGN(v237, v238);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
          uint16_t v239 = static_cast<uint16_t>(v27);
          uint16_t v240 = static_cast<uint16_t>(v27);
          TEXTRACT(v237, v214, v239, v240);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
          // pto: %3
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v241 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v127, v26);
          // pto: %3
          ;
          uint64_t v242 = (uint64_t) v15;
          TASSIGN(v241, v242);
          uint16_t v243 = static_cast<uint16_t>(v27);
          uint16_t v244 = static_cast<uint16_t>(v26);
          TEXTRACT(v241, v200, v243, v244);
          // pto: %4
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v245 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %4
          ;
          uint64_t v246 = (uint64_t) v14;
          TASSIGN(v245, v246);
          uint16_t v247 = static_cast<uint16_t>(v26);
          uint16_t v248 = static_cast<uint16_t>(v27);
          TEXTRACT(v245, v214, v247, v248);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v174, v174, v233, v237);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
          TMATMUL_ACC(v174, v174, v241, v245);
        } else {
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
          for (int64_t v249 = v27; v249 < v19; v249 += v18) {
            // pto: %164, %165
            ;
            int64_t v250 = (int64_t) ((uint64_t) v195 + (uint64_t) v249) % v23;
            // pto: %166, %167, %168
            ;
            int64_t v251 = v250 < v27 ? (int64_t) ((uint64_t) v250 + (uint64_t) v23) : v250;
            // pto: %169
            ;
            int64_t v252 = (int64_t) ((uint64_t) v251 * (uint64_t) v19);
            // pto: %seed_fast_wrap_x_inline5602__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v253 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v127, v19);
            // pto: %seed_fast_wrap_x_inline5602__tile
            ;
            uint64_t v254 = (uint64_t) v12;
            TASSIGN(v253, v254);
            // pto: %172
            ;
            int64_t v255 = (int64_t) ((uint64_t) v132 + (uint64_t) v252);
            // pto: %173
            ;
            int64_t v256 = v255 < v27 ? v27 : v255;
            // pto: %174
            ;
            const int64_t v257 = 0;
            // pto: %174
            ;
            __gm__ bfloat16_t* v258 = PTOAS__GLOBAL_TENSOR_DATA(v56);
            // pto: %174
            ;
            const int64_t v259 = 1;
            // pto: %174
            ;
            const int64_t v260 = 1;
            // pto: %174
            ;
            const int64_t v261 = 1;
            // pto: %174
            ;
            int64_t v262 = v127 * v21;
            // pto: %174
            ;
            int64_t v263 = v261 * v262;
            // pto: %174
            ;
            pto::Shape<1, 1, 1, -1, 16> v264 = pto::Shape<1, 1, 1, -1, 16>(v259, v260, v261, v127, v19);
            // pto: %174
            ;
            pto::Stride<-1, -1, -1, -1, -1> v265 = pto::Stride<-1, -1, -1, -1, -1>(v260 * v263, v263, v262, v21, v18);
            // pto: %174
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v266 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v258 + (v257 + v131 * v21 + v256 * v18), v264, v265);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            TLOAD(v253, v266);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
            // pto: %seed_fast_wrap_w_inline5603__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v267 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %seed_fast_wrap_w_inline5603__tile
            ;
            uint64_t v268 = (uint64_t) v13;
            TASSIGN(v267, v268);
            // pto: %178
            ;
            const int64_t v269 = 1;
            // pto: %178
            ;
            const int64_t v270 = 0;
            // pto: %178
            ;
            int64_t v271 = v252 / v19;
            // pto: %178
            ;
            bool v272 = v252 < v270;
            // pto: %178
            ;
            bool v273 = v19 < v270;
            // pto: %178
            ;
            bool v274 = v272 == v273;
            // pto: %178
            ;
            bool v275 = v252 % v19 != v270 && v272 != v273;
            // pto: %178
            ;
            int64_t v276 = v275 ? v271 - v269 : v271;
            // pto: %179
            ;
            int64_t v277 = v276 < v27 ? v27 : v276;
            // pto: %180
            ;
            __gm__ bfloat16_t* v278 = PTOAS__GLOBAL_TENSOR_DATA(v59);
            // pto: %180
            ;
            const int64_t v279 = 0;
            // pto: %180
            ;
            const int64_t v280 = 4194304;
            // pto: %180
            ;
            const int64_t v281 = 65536;
            // pto: %180
            ;
            const int64_t v282 = 256;
            // pto: %180
            ;
            pto::Shape<1, 8, 1, 16, 16> v283 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %180
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v284 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %180
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v285 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v278 + ((v279 + v147 * v280) + v156 * v281 + v277 * v282), v283, v284);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            TLOAD(v267, v285);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
            // pto: %lhs_slice_0_textract
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v286 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v127, v19);
            // pto: %lhs_slice_0_textract
            ;
            uint64_t v287 = (uint64_t) v14;
            TASSIGN(v286, v287);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
            uint16_t v288 = static_cast<uint16_t>(v27);
            uint16_t v289 = static_cast<uint16_t>(v27);
            TEXTRACT(v286, v253, v288, v289);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            // pto: %rhs_slice_0_textract
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %rhs_slice_0_textract
            ;
            uint64_t v291 = (uint64_t) v15;
            TASSIGN(v290, v291);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
            uint16_t v292 = static_cast<uint16_t>(v27);
            uint16_t v293 = static_cast<uint16_t>(v27);
            TEXTRACT(v290, v267, v292, v293);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v174, v174, v286, v290);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        };
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        // pto: %181
        ;
        v62.SetValidShape(v198, v26);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
        if (v197 <= v34) {
          // pto: %184
          ;
          int64_t v294 = (int64_t) ((uint64_t) v197 * (uint64_t) v19);
          // pto: %6
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v127, v23);
          // pto: %6
          ;
          uint64_t v296 = (uint64_t) v14;
          TASSIGN(v295, v296);
          // pto: %187
          ;
          int64_t v297 = (int64_t) ((uint64_t) v132 + (uint64_t) v294);
          // pto: %188
          ;
          int64_t v298 = v297 < v27 ? v27 : v297;
          // pto: %189
          ;
          const int64_t v299 = 0;
          // pto: %189
          ;
          __gm__ bfloat16_t* v300 = PTOAS__GLOBAL_TENSOR_DATA(v56);
          // pto: %189
          ;
          const int64_t v301 = 1;
          // pto: %189
          ;
          const int64_t v302 = 1;
          // pto: %189
          ;
          const int64_t v303 = 1;
          // pto: %189
          ;
          int64_t v304 = v127 * v21;
          // pto: %189
          ;
          int64_t v305 = v303 * v304;
          // pto: %189
          ;
          pto::Shape<1, 1, 1, -1, 256> v306 = pto::Shape<1, 1, 1, -1, 256>(v301, v302, v303, v127, v23);
          // pto: %189
          ;
          pto::Stride<-1, -1, -1, -1, -1> v307 = pto::Stride<-1, -1, -1, -1, -1>(v302 * v305, v305, v304, v21, v18);
          // pto: %189
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v308 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v300 + (v299 + v131 * v21 + v298 * v18), v306, v307);
          TLOAD(v295, v308);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
          // pto: %7
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
          // pto: %7
          ;
          uint64_t v310 = (uint64_t) v16;
          TASSIGN(v309, v310);
          // pto: %193
          ;
          const int64_t v311 = 1;
          // pto: %193
          ;
          const int64_t v312 = 0;
          // pto: %193
          ;
          int64_t v313 = v294 / v19;
          // pto: %193
          ;
          bool v314 = v294 < v312;
          // pto: %193
          ;
          bool v315 = v19 < v312;
          // pto: %193
          ;
          bool v316 = v314 == v315;
          // pto: %193
          ;
          bool v317 = v294 % v19 != v312 && v314 != v315;
          // pto: %193
          ;
          int64_t v318 = v317 ? v313 - v311 : v313;
          // pto: %194
          ;
          int64_t v319 = v318 < v27 ? v27 : v318;
          // pto: %195
          ;
          __gm__ bfloat16_t* v320 = PTOAS__GLOBAL_TENSOR_DATA(v59);
          // pto: %195
          ;
          const int64_t v321 = 0;
          // pto: %195
          ;
          const int64_t v322 = 4194304;
          // pto: %195
          ;
          const int64_t v323 = 65536;
          // pto: %195
          ;
          const int64_t v324 = 256;
          // pto: %195
          ;
          pto::Shape<1, 8, 16, 16, 16> v325 = pto::Shape<1, 8, 16, 16, 16>();
          // pto: %195
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v326 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %195
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v327 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v320 + ((v321 + v147 * v322) + v156 * v323 + v319 * v324), v325, v326);
          TLOAD(v309, v327);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
          // pto: %8
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v328 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v127, v26);
          // pto: %8
          ;
          uint64_t v329 = (uint64_t) v14;
          TASSIGN(v328, v329);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
          uint16_t v330 = static_cast<uint16_t>(v27);
          uint16_t v331 = static_cast<uint16_t>(v27);
          TEXTRACT(v328, v295, v330, v331);
          // pto: %9
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v332 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %9
          ;
          uint64_t v333 = (uint64_t) v15;
          TASSIGN(v332, v333);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
          uint16_t v334 = static_cast<uint16_t>(v27);
          uint16_t v335 = static_cast<uint16_t>(v27);
          TEXTRACT(v332, v309, v334, v335);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          // pto: %10
          ;
          Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v336 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v127, v26);
          // pto: %10
          ;
          uint64_t v337 = (uint64_t) v15;
          TASSIGN(v336, v337);
          uint16_t v338 = static_cast<uint16_t>(v27);
          uint16_t v339 = static_cast<uint16_t>(v26);
          TEXTRACT(v336, v295, v338, v339);
          // pto: %11
          ;
          Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v340 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
          // pto: %11
          ;
          uint64_t v341 = (uint64_t) v14;
          TASSIGN(v340, v341);
          uint16_t v342 = static_cast<uint16_t>(v26);
          uint16_t v343 = static_cast<uint16_t>(v27);
          TEXTRACT(v340, v309, v342, v343);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v60, v60, v328, v332);
          pipe_barrier(PIPE_M);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
          TMATMUL_ACC(v60, v60, v336, v340);
        } else {
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
          for (int64_t v344 = v27; v344 < v19; v344 += v18) {
            // pto: %197, %198
            ;
            int64_t v345 = (int64_t) ((uint64_t) v197 + (uint64_t) v344) % v23;
            // pto: %199, %200, %201
            ;
            int64_t v346 = v345 < v27 ? (int64_t) ((uint64_t) v345 + (uint64_t) v23) : v345;
            // pto: %202
            ;
            int64_t v347 = (int64_t) ((uint64_t) v346 * (uint64_t) v19);
            // pto: %14
            ;
            Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v348 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v127, v19);
            // pto: %14
            ;
            uint64_t v349 = (uint64_t) v14;
            TASSIGN(v348, v349);
            // pto: %205
            ;
            int64_t v350 = (int64_t) ((uint64_t) v132 + (uint64_t) v347);
            // pto: %206
            ;
            int64_t v351 = v350 < v27 ? v27 : v350;
            // pto: %207
            ;
            const int64_t v352 = 0;
            // pto: %207
            ;
            __gm__ bfloat16_t* v353 = PTOAS__GLOBAL_TENSOR_DATA(v56);
            // pto: %207
            ;
            const int64_t v354 = 1;
            // pto: %207
            ;
            const int64_t v355 = 1;
            // pto: %207
            ;
            const int64_t v356 = 1;
            // pto: %207
            ;
            int64_t v357 = v127 * v21;
            // pto: %207
            ;
            int64_t v358 = v356 * v357;
            // pto: %207
            ;
            pto::Shape<1, 1, 1, -1, 16> v359 = pto::Shape<1, 1, 1, -1, 16>(v354, v355, v356, v127, v19);
            // pto: %207
            ;
            pto::Stride<-1, -1, -1, -1, -1> v360 = pto::Stride<-1, -1, -1, -1, -1>(v355 * v358, v358, v357, v21, v18);
            // pto: %207
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v361 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v353 + (v352 + v131 * v21 + v351 * v18), v359, v360);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
            TLOAD(v348, v361);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %15
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v362 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %15
            ;
            uint64_t v363 = (uint64_t) v16;
            TASSIGN(v362, v363);
            // pto: %211
            ;
            const int64_t v364 = 1;
            // pto: %211
            ;
            const int64_t v365 = 0;
            // pto: %211
            ;
            int64_t v366 = v347 / v19;
            // pto: %211
            ;
            bool v367 = v347 < v365;
            // pto: %211
            ;
            bool v368 = v19 < v365;
            // pto: %211
            ;
            bool v369 = v367 == v368;
            // pto: %211
            ;
            bool v370 = v347 % v19 != v365 && v367 != v368;
            // pto: %211
            ;
            int64_t v371 = v370 ? v366 - v364 : v366;
            // pto: %212
            ;
            int64_t v372 = v371 < v27 ? v27 : v371;
            // pto: %213
            ;
            __gm__ bfloat16_t* v373 = PTOAS__GLOBAL_TENSOR_DATA(v59);
            // pto: %213
            ;
            const int64_t v374 = 0;
            // pto: %213
            ;
            const int64_t v375 = 4194304;
            // pto: %213
            ;
            const int64_t v376 = 65536;
            // pto: %213
            ;
            const int64_t v377 = 256;
            // pto: %213
            ;
            pto::Shape<1, 8, 1, 16, 16> v378 = pto::Shape<1, 8, 1, 16, 16>();
            // pto: %213
            ;
            pto::Stride<4194304, 65536, 256, 16, 1> v379 = pto::Stride<4194304, 65536, 256, 16, 1>();
            // pto: %213
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v380 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v373 + ((v374 + v147 * v375) + v156 * v376 + v372 * v377), v378, v379);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
            TLOAD(v362, v380);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %16
            ;
            Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v381 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v127, v19);
            // pto: %16
            ;
            uint64_t v382 = (uint64_t) v14;
            TASSIGN(v381, v382);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
            uint16_t v383 = static_cast<uint16_t>(v27);
            uint16_t v384 = static_cast<uint16_t>(v27);
            TEXTRACT(v381, v348, v383, v384);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
            // pto: %17
            ;
            Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v385 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
            // pto: %17
            ;
            uint64_t v386 = (uint64_t) v15;
            TASSIGN(v385, v386);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            uint16_t v387 = static_cast<uint16_t>(v27);
            uint16_t v388 = static_cast<uint16_t>(v27);
            TEXTRACT(v385, v362, v387, v388);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
            pipe_barrier(PIPE_M);
            TMATMUL_ACC(v60, v60, v381, v385);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
          };
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
        };
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      // pto: %214, %215
      ;
      int64_t v389 = (int64_t) ((uint64_t) v82 + (uint64_t) v34) % v23;
      // pto: %216, %217, %218
      ;
      int64_t v390 = v389 < v27 ? (int64_t) ((uint64_t) v389 + (uint64_t) v23) : v389;
      // pto: %219
      ;
      // pto: %220
      ;
      int64_t v391 = v127 < v26 ? v127 : v26;
      v64.SetValidShape(v391, v26);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      if (v390 <= v34) {
        // pto: %222
        ;
        int64_t v392 = (int64_t) ((uint64_t) v390 * (uint64_t) v19);
        // pto: %19
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v393 = Tile<TileType::Mat, bfloat16_t, 128, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v127, v23);
        // pto: %19
        ;
        uint64_t v394 = (uint64_t) v12;
        TASSIGN(v393, v394);
        // pto: %225
        ;
        int64_t v395 = (int64_t) ((uint64_t) v132 + (uint64_t) v392);
        // pto: %226
        ;
        int64_t v396 = v395 < v27 ? v27 : v395;
        // pto: %227
        ;
        const int64_t v397 = 0;
        // pto: %227
        ;
        __gm__ bfloat16_t* v398 = PTOAS__GLOBAL_TENSOR_DATA(v56);
        // pto: %227
        ;
        const int64_t v399 = 1;
        // pto: %227
        ;
        const int64_t v400 = 1;
        // pto: %227
        ;
        const int64_t v401 = 1;
        // pto: %227
        ;
        int64_t v402 = v127 * v21;
        // pto: %227
        ;
        int64_t v403 = v401 * v402;
        // pto: %227
        ;
        pto::Shape<1, 1, 1, -1, 256> v404 = pto::Shape<1, 1, 1, -1, 256>(v399, v400, v401, v127, v23);
        // pto: %227
        ;
        pto::Stride<-1, -1, -1, -1, -1> v405 = pto::Stride<-1, -1, -1, -1, -1>(v400 * v403, v403, v402, v21, v18);
        // pto: %227
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v406 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v398 + (v397 + v131 * v21 + v396 * v18), v404, v405);
        TLOAD(v393, v406);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %20
        ;
        Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v407 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
        // pto: %20
        ;
        uint64_t v408 = (uint64_t) v13;
        TASSIGN(v407, v408);
        // pto: %231
        ;
        const int64_t v409 = 1;
        // pto: %231
        ;
        const int64_t v410 = 0;
        // pto: %231
        ;
        int64_t v411 = v392 / v19;
        // pto: %231
        ;
        bool v412 = v392 < v410;
        // pto: %231
        ;
        bool v413 = v19 < v410;
        // pto: %231
        ;
        bool v414 = v412 == v413;
        // pto: %231
        ;
        bool v415 = v392 % v19 != v410 && v412 != v413;
        // pto: %231
        ;
        int64_t v416 = v415 ? v411 - v409 : v411;
        // pto: %232
        ;
        int64_t v417 = v416 < v27 ? v27 : v416;
        // pto: %233
        ;
        __gm__ bfloat16_t* v418 = PTOAS__GLOBAL_TENSOR_DATA(v59);
        // pto: %233
        ;
        const int64_t v419 = 0;
        // pto: %233
        ;
        const int64_t v420 = 4194304;
        // pto: %233
        ;
        const int64_t v421 = 65536;
        // pto: %233
        ;
        const int64_t v422 = 256;
        // pto: %233
        ;
        pto::Shape<1, 8, 16, 16, 16> v423 = pto::Shape<1, 8, 16, 16, 16>();
        // pto: %233
        ;
        pto::Stride<4194304, 65536, 256, 16, 1> v424 = pto::Stride<4194304, 65536, 256, 16, 1>();
        // pto: %233
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v425 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v418 + ((v419 + v147 * v420) + v156 * v421 + v417 * v422), v423, v424);
        TLOAD(v407, v425);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %21
        ;
        Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v426 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v127, v26);
        // pto: %21
        ;
        uint64_t v427 = (uint64_t) v14;
        TASSIGN(v426, v427);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        uint16_t v428 = static_cast<uint16_t>(v27);
        uint16_t v429 = static_cast<uint16_t>(v27);
        TEXTRACT(v426, v393, v428, v429);
        // pto: %22
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v430 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
        // pto: %22
        ;
        uint64_t v431 = (uint64_t) v15;
        TASSIGN(v430, v431);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        uint16_t v432 = static_cast<uint16_t>(v27);
        uint16_t v433 = static_cast<uint16_t>(v27);
        TEXTRACT(v430, v407, v432, v433);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %23
        ;
        Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v434 = Tile<TileType::Left, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v127, v26);
        // pto: %23
        ;
        uint64_t v435 = (uint64_t) v15;
        TASSIGN(v434, v435);
        uint16_t v436 = static_cast<uint16_t>(v27);
        uint16_t v437 = static_cast<uint16_t>(v26);
        TEXTRACT(v434, v393, v436, v437);
        // pto: %24
        ;
        Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v438 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
        // pto: %24
        ;
        uint64_t v439 = (uint64_t) v14;
        TASSIGN(v438, v439);
        uint16_t v440 = static_cast<uint16_t>(v26);
        uint16_t v441 = static_cast<uint16_t>(v27);
        TEXTRACT(v438, v407, v440, v441);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        pipe_barrier(PIPE_M);
        TMATMUL_ACC(v174, v174, v426, v430);
        pipe_barrier(PIPE_M);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        TMATMUL_ACC(v174, v174, v434, v438);
      } else {
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        for (int64_t v442 = v27; v442 < v19; v442 += v18) {
          // pto: %235, %236
          ;
          int64_t v443 = (int64_t) ((uint64_t) v390 + (uint64_t) v442) % v23;
          // pto: %237, %238, %239
          ;
          int64_t v444 = v443 < v27 ? (int64_t) ((uint64_t) v443 + (uint64_t) v23) : v443;
          // pto: %240
          ;
          int64_t v445 = (int64_t) ((uint64_t) v444 * (uint64_t) v19);
          // pto: %27
          ;
          Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v446 = Tile<TileType::Mat, bfloat16_t, 128, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v127, v19);
          // pto: %27
          ;
          uint64_t v447 = (uint64_t) v12;
          TASSIGN(v446, v447);
          // pto: %243
          ;
          int64_t v448 = (int64_t) ((uint64_t) v132 + (uint64_t) v445);
          // pto: %244
          ;
          int64_t v449 = v448 < v27 ? v27 : v448;
          // pto: %245
          ;
          const int64_t v450 = 0;
          // pto: %245
          ;
          __gm__ bfloat16_t* v451 = PTOAS__GLOBAL_TENSOR_DATA(v56);
          // pto: %245
          ;
          const int64_t v452 = 1;
          // pto: %245
          ;
          const int64_t v453 = 1;
          // pto: %245
          ;
          const int64_t v454 = 1;
          // pto: %245
          ;
          int64_t v455 = v127 * v21;
          // pto: %245
          ;
          int64_t v456 = v454 * v455;
          // pto: %245
          ;
          pto::Shape<1, 1, 1, -1, 16> v457 = pto::Shape<1, 1, 1, -1, 16>(v452, v453, v454, v127, v19);
          // pto: %245
          ;
          pto::Stride<-1, -1, -1, -1, -1> v458 = pto::Stride<-1, -1, -1, -1, -1>(v453 * v456, v456, v455, v21, v18);
          // pto: %245
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v459 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v451 + (v450 + v131 * v21 + v449 * v18), v457, v458);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          TLOAD(v446, v459);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %28
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v460 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
          // pto: %28
          ;
          uint64_t v461 = (uint64_t) v13;
          TASSIGN(v460, v461);
          // pto: %249
          ;
          const int64_t v462 = 1;
          // pto: %249
          ;
          const int64_t v463 = 0;
          // pto: %249
          ;
          int64_t v464 = v445 / v19;
          // pto: %249
          ;
          bool v465 = v445 < v463;
          // pto: %249
          ;
          bool v466 = v19 < v463;
          // pto: %249
          ;
          bool v467 = v465 == v466;
          // pto: %249
          ;
          bool v468 = v445 % v19 != v463 && v465 != v466;
          // pto: %249
          ;
          int64_t v469 = v468 ? v464 - v462 : v464;
          // pto: %250
          ;
          int64_t v470 = v469 < v27 ? v27 : v469;
          // pto: %251
          ;
          __gm__ bfloat16_t* v471 = PTOAS__GLOBAL_TENSOR_DATA(v59);
          // pto: %251
          ;
          const int64_t v472 = 0;
          // pto: %251
          ;
          const int64_t v473 = 4194304;
          // pto: %251
          ;
          const int64_t v474 = 65536;
          // pto: %251
          ;
          const int64_t v475 = 256;
          // pto: %251
          ;
          pto::Shape<1, 8, 1, 16, 16> v476 = pto::Shape<1, 8, 1, 16, 16>();
          // pto: %251
          ;
          pto::Stride<4194304, 65536, 256, 16, 1> v477 = pto::Stride<4194304, 65536, 256, 16, 1>();
          // pto: %251
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v478 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v471 + ((v472 + v147 * v473) + v156 * v474 + v470 * v475), v476, v477);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          TLOAD(v460, v478);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %29
          ;
          Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v479 = Tile<TileType::Left, bfloat16_t, 128, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v127, v19);
          // pto: %29
          ;
          uint64_t v480 = (uint64_t) v14;
          TASSIGN(v479, v480);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
          uint16_t v481 = static_cast<uint16_t>(v27);
          uint16_t v482 = static_cast<uint16_t>(v27);
          TEXTRACT(v479, v446, v481, v482);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %30
          ;
          Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v483 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
          // pto: %30
          ;
          uint64_t v484 = (uint64_t) v15;
          TASSIGN(v483, v484);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          uint16_t v485 = static_cast<uint16_t>(v27);
          uint16_t v486 = static_cast<uint16_t>(v27);
          TEXTRACT(v483, v460, v485, v486);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v174, v174, v479, v483);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        };
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      };
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      // pto: %seed_fast_acc_inline5594__rv_v2
      ;
      Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v487 = Tile<TileType::Acc, float, 128, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v127, v26);
      // pto: %seed_fast_acc_inline5594__rv_v2
      ;
      uint64_t v488 = (uint64_t) v14;
      TASSIGN(v487, v488);
      // pto: %253, %254
      ;
      int64_t v489 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v37) + (uint64_t) v69);
      // pto: %255
      ;
      int64_t v490 = v489 < v27 ? v27 : v489;
      // pto: %accum_inline5581__iter_v3_pview
      ;
      const int64_t v491 = 0;
      // pto: %accum_inline5581__iter_v3_pview
      ;
      __gm__ float* v492 = PTOAS__GLOBAL_TENSOR_DATA(v47);
      // pto: %accum_inline5581__iter_v3_pview
      ;
      const int64_t v493 = 1;
      // pto: %accum_inline5581__iter_v3_pview
      ;
      const int64_t v494 = 1;
      // pto: %accum_inline5581__iter_v3_pview
      ;
      const int64_t v495 = 1;
      // pto: %accum_inline5581__iter_v3_pview
      ;
      int64_t v496 = v127 * v17;
      // pto: %accum_inline5581__iter_v3_pview
      ;
      int64_t v497 = v495 * v496;
      // pto: %accum_inline5581__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, -1, 128> v498 = pto::Shape<1, 1, 1, -1, 128>(v493, v494, v495, v127, v26);
      // pto: %accum_inline5581__iter_v3_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v499 = pto::Stride<-1, -1, -1, -1, -1>(v494 * v497, v497, v496, v17, v18);
      // pto: %accum_inline5581__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v500 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v492 + (v491 + v131 * v17 + v490 * v18), v498, v499);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      TSTORE(v500, v487);
    } else {
      for (int64_t v501 = v27; v501 < v20; v501 += v18) {
        // pto: %256
        ;
        int64_t v502 = (int64_t) ((uint64_t) v79 + (uint64_t) v501);
        // pto: %257
        ;
        if (v502 < v5) {
          // pto: %258
          ;
          int64_t v503 = (int64_t) ((uint64_t) v502 * (uint64_t) v19);
          // pto: %259
          ;
          int64_t v504 = (int64_t) ((uint64_t) v8 - (uint64_t) v503);
          // pto: %260
          ;
          int64_t v505 = v504 < v19 ? v504 : v19;
          // pto: %262, %263, %264, %265, %261
          ;
          int32_t v506 = (v2)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v502 * (uint64_t) v20) + (uint64_t) v6) * (uint64_t) v20) + (uint64_t) v68)];
          // pto: %266
          ;
          int64_t v507 = (int64_t) v506;
          // pto: %267
          ;
          int64_t v508 = v507 < v27 ? v27 : v507;
          // pto: %seed_narrow_acc_inline5609__tile
          ;
          Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v509 = Tile<TileType::Acc, float, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v19, v26);
          // pto: %seed_narrow_acc_inline5609__tile
          ;
          uint64_t v510 = (uint64_t) v14;
          TASSIGN(v509, v510);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          for (int64_t v511 = v27; v511 < v19; v511 += v18) {
            // pto: %268
            ;
            int64_t v512 = (int64_t) ((uint64_t) v511 * (uint64_t) v19);
            // pto: %269, %270
            ;
            int64_t v513 = (int64_t) ((uint64_t) v508 + (uint64_t) v512) % v23;
            // pto: %271, %272, %273
            ;
            int64_t v514 = v513 < v27 ? (int64_t) ((uint64_t) v513 + (uint64_t) v23) : v513;
            // pto: %274
            ;
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
            if (v514 <= v34) {
              // pto: %275
              ;
              int64_t v515 = (int64_t) ((uint64_t) v514 * (uint64_t) v19);
              // pto: %seed_narrow_packet_x_inline5613__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v516 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v505, v23);
              // pto: %seed_narrow_packet_x_inline5613__tile
              ;
              uint64_t v517 = (uint64_t) v13;
              TASSIGN(v516, v517);
              // pto: %276
              ;
              int64_t v518 = v503 < v27 ? v27 : v503;
              // pto: %277, %278
              ;
              int64_t v519 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v35) + (uint64_t) v515);
              // pto: %279
              ;
              int64_t v520 = v519 < v27 ? v27 : v519;
              // pto: %280
              ;
              const int64_t v521 = 0;
              // pto: %280
              ;
              __gm__ bfloat16_t* v522 = PTOAS__GLOBAL_TENSOR_DATA(v56);
              // pto: %280
              ;
              const int64_t v523 = 1;
              // pto: %280
              ;
              const int64_t v524 = 1;
              // pto: %280
              ;
              const int64_t v525 = 1;
              // pto: %280
              ;
              int64_t v526 = v505 * v21;
              // pto: %280
              ;
              int64_t v527 = v525 * v526;
              // pto: %280
              ;
              pto::Shape<1, 1, 1, -1, 256> v528 = pto::Shape<1, 1, 1, -1, 256>(v523, v524, v525, v505, v23);
              // pto: %280
              ;
              pto::Stride<-1, -1, -1, -1, -1> v529 = pto::Stride<-1, -1, -1, -1, -1>(v524 * v527, v527, v526, v21, v18);
              // pto: %280
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v530 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v522 + (v521 + v518 * v21 + v520 * v18), v528, v529);
              TLOAD(v516, v530);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              // pto: %seed_narrow_packet_w_inline5614__tile
              ;
              Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v531 = Tile<TileType::Mat, bfloat16_t, 256, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v23, v26);
              // pto: %seed_narrow_packet_w_inline5614__tile
              ;
              uint64_t v532 = (uint64_t) v12;
              TASSIGN(v531, v532);
              // pto: %281
              ;
              int64_t v533 = v6 < v27 ? v27 : v6;
              // pto: %282
              ;
              const int64_t v534 = 1;
              // pto: %282
              ;
              const int64_t v535 = 0;
              // pto: %282
              ;
              int64_t v536 = v69 / v19;
              // pto: %282
              ;
              bool v537 = v69 < v535;
              // pto: %282
              ;
              bool v538 = v19 < v535;
              // pto: %282
              ;
              bool v539 = v537 == v538;
              // pto: %282
              ;
              bool v540 = v69 % v19 != v535 && v537 != v538;
              // pto: %282
              ;
              int64_t v541 = v540 ? v536 - v534 : v536;
              // pto: %283
              ;
              int64_t v542 = v541 < v27 ? v27 : v541;
              // pto: %284
              ;
              const int64_t v543 = 1;
              // pto: %284
              ;
              const int64_t v544 = 0;
              // pto: %284
              ;
              int64_t v545 = v515 / v19;
              // pto: %284
              ;
              bool v546 = v515 < v544;
              // pto: %284
              ;
              bool v547 = v19 < v544;
              // pto: %284
              ;
              bool v548 = v546 == v547;
              // pto: %284
              ;
              bool v549 = v515 % v19 != v544 && v546 != v547;
              // pto: %284
              ;
              int64_t v550 = v549 ? v545 - v543 : v545;
              // pto: %285
              ;
              int64_t v551 = v550 < v27 ? v27 : v550;
              // pto: %286
              ;
              __gm__ bfloat16_t* v552 = PTOAS__GLOBAL_TENSOR_DATA(v59);
              // pto: %286
              ;
              const int64_t v553 = 0;
              // pto: %286
              ;
              const int64_t v554 = 4194304;
              // pto: %286
              ;
              const int64_t v555 = 65536;
              // pto: %286
              ;
              const int64_t v556 = 256;
              // pto: %286
              ;
              pto::Shape<1, 8, 16, 16, 16> v557 = pto::Shape<1, 8, 16, 16, 16>();
              // pto: %286
              ;
              pto::Stride<4194304, 65536, 256, 16, 1> v558 = pto::Stride<4194304, 65536, 256, 16, 1>();
              // pto: %286
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v559 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 16, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v552 + ((v553 + v533 * v554) + v542 * v555 + v551 * v556), v557, v558);
              TLOAD(v531, v559);
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              // pto: %seed_narrow_acc_inline5609__iter_v1_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v560 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v505, v26);
              // pto: %seed_narrow_acc_inline5609__iter_v1_l0_a
              ;
              uint64_t v561 = (uint64_t) v14;
              TASSIGN(v560, v561);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
              uint16_t v562 = static_cast<uint16_t>(v27);
              uint16_t v563 = static_cast<uint16_t>(v27);
              TEXTRACT(v560, v516, v562, v563);
              // pto: %seed_narrow_acc_inline5609__iter_v1_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v564 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
              // pto: %seed_narrow_acc_inline5609__iter_v1_l0_b
              ;
              uint64_t v565 = (uint64_t) v15;
              TASSIGN(v564, v565);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
              uint16_t v566 = static_cast<uint16_t>(v27);
              uint16_t v567 = static_cast<uint16_t>(v27);
              TEXTRACT(v564, v531, v566, v567);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              // pto: %32
              ;
              Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v568 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v505, v26);
              // pto: %32
              ;
              uint64_t v569 = (uint64_t) v15;
              TASSIGN(v568, v569);
              uint16_t v570 = static_cast<uint16_t>(v27);
              uint16_t v571 = static_cast<uint16_t>(v26);
              TEXTRACT(v568, v516, v570, v571);
              // pto: %33
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v572 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v26, v26);
              // pto: %33
              ;
              uint64_t v573 = (uint64_t) v14;
              TASSIGN(v572, v573);
              uint16_t v574 = static_cast<uint16_t>(v26);
              uint16_t v575 = static_cast<uint16_t>(v27);
              TEXTRACT(v572, v531, v574, v575);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              // pto: %287
              ;
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              if (v511 == v27) {
                pipe_barrier(PIPE_M);
                TMATMUL(v509, v560, v564);
              } else {
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v509, v509, v560, v564);
              };
              pipe_barrier(PIPE_M);
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              TMATMUL_ACC(v509, v509, v568, v572);
            } else {
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              for (int64_t v576 = v27; v576 < v19; v576 += v18) {
                // pto: %288, %289
                ;
                int64_t v577 = (int64_t) ((uint64_t) v514 + (uint64_t) v576) % v23;
                // pto: %290, %291, %292
                ;
                int64_t v578 = v577 < v27 ? (int64_t) ((uint64_t) v577 + (uint64_t) v23) : v577;
                // pto: %293
                ;
                int64_t v579 = (int64_t) ((uint64_t) v578 * (uint64_t) v19);
                // pto: %seed_narrow_wrap_x_inline5617__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v580 = Tile<TileType::Mat, bfloat16_t, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v505, v19);
                // pto: %seed_narrow_wrap_x_inline5617__tile
                ;
                uint64_t v581 = (uint64_t) v13;
                TASSIGN(v580, v581);
                // pto: %294
                ;
                int64_t v582 = v503 < v27 ? v27 : v503;
                // pto: %295, %296
                ;
                int64_t v583 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v35) + (uint64_t) v579);
                // pto: %297
                ;
                int64_t v584 = v583 < v27 ? v27 : v583;
                // pto: %298
                ;
                const int64_t v585 = 0;
                // pto: %298
                ;
                __gm__ bfloat16_t* v586 = PTOAS__GLOBAL_TENSOR_DATA(v56);
                // pto: %298
                ;
                const int64_t v587 = 1;
                // pto: %298
                ;
                const int64_t v588 = 1;
                // pto: %298
                ;
                const int64_t v589 = 1;
                // pto: %298
                ;
                int64_t v590 = v505 * v21;
                // pto: %298
                ;
                int64_t v591 = v589 * v590;
                // pto: %298
                ;
                pto::Shape<1, 1, 1, -1, 16> v592 = pto::Shape<1, 1, 1, -1, 16>(v587, v588, v589, v505, v19);
                // pto: %298
                ;
                pto::Stride<-1, -1, -1, -1, -1> v593 = pto::Stride<-1, -1, -1, -1, -1>(v588 * v591, v591, v590, v21, v18);
                // pto: %298
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v594 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v586 + (v585 + v582 * v21 + v584 * v18), v592, v593);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                TLOAD(v580, v594);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                // pto: %seed_narrow_wrap_w_inline5618__tile
                ;
                Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v595 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
                // pto: %seed_narrow_wrap_w_inline5618__tile
                ;
                uint64_t v596 = (uint64_t) v12;
                TASSIGN(v595, v596);
                // pto: %299
                ;
                int64_t v597 = v6 < v27 ? v27 : v6;
                // pto: %300
                ;
                const int64_t v598 = 1;
                // pto: %300
                ;
                const int64_t v599 = 0;
                // pto: %300
                ;
                int64_t v600 = v69 / v19;
                // pto: %300
                ;
                bool v601 = v69 < v599;
                // pto: %300
                ;
                bool v602 = v19 < v599;
                // pto: %300
                ;
                bool v603 = v601 == v602;
                // pto: %300
                ;
                bool v604 = v69 % v19 != v599 && v601 != v602;
                // pto: %300
                ;
                int64_t v605 = v604 ? v600 - v598 : v600;
                // pto: %301
                ;
                int64_t v606 = v605 < v27 ? v27 : v605;
                // pto: %302
                ;
                const int64_t v607 = 1;
                // pto: %302
                ;
                const int64_t v608 = 0;
                // pto: %302
                ;
                int64_t v609 = v579 / v19;
                // pto: %302
                ;
                bool v610 = v579 < v608;
                // pto: %302
                ;
                bool v611 = v19 < v608;
                // pto: %302
                ;
                bool v612 = v610 == v611;
                // pto: %302
                ;
                bool v613 = v579 % v19 != v608 && v610 != v611;
                // pto: %302
                ;
                int64_t v614 = v613 ? v609 - v607 : v609;
                // pto: %303
                ;
                int64_t v615 = v614 < v27 ? v27 : v614;
                // pto: %304
                ;
                __gm__ bfloat16_t* v616 = PTOAS__GLOBAL_TENSOR_DATA(v59);
                // pto: %304
                ;
                const int64_t v617 = 0;
                // pto: %304
                ;
                const int64_t v618 = 4194304;
                // pto: %304
                ;
                const int64_t v619 = 65536;
                // pto: %304
                ;
                const int64_t v620 = 256;
                // pto: %304
                ;
                pto::Shape<1, 8, 1, 16, 16> v621 = pto::Shape<1, 8, 1, 16, 16>();
                // pto: %304
                ;
                pto::Stride<4194304, 65536, 256, 16, 1> v622 = pto::Stride<4194304, 65536, 256, 16, 1>();
                // pto: %304
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ> v623 = GlobalTensor<bfloat16_t, pto::Shape<1, 8, 1, 16, 16>, pto::Stride<4194304, 65536, 256, 16, 1>, pto::Layout::NZ>(v616 + ((v617 + v597 * v618) + v606 * v619 + v615 * v620), v621, v622);
                wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                TLOAD(v595, v623);
                set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                // pto: %35
                ;
                Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal> v624 = Tile<TileType::Left, bfloat16_t, 16, 16, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Normal>(v505, v19);
                // pto: %35
                ;
                uint64_t v625 = (uint64_t) v14;
                TASSIGN(v624, v625);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
                uint16_t v626 = static_cast<uint16_t>(v27);
                uint16_t v627 = static_cast<uint16_t>(v27);
                TEXTRACT(v624, v580, v626, v627);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
                // pto: %36
                ;
                Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v628 = Tile<TileType::Right, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v19, v26);
                // pto: %36
                ;
                uint64_t v629 = (uint64_t) v15;
                TASSIGN(v628, v629);
                wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
                uint16_t v630 = static_cast<uint16_t>(v27);
                uint16_t v631 = static_cast<uint16_t>(v27);
                TEXTRACT(v628, v595, v630, v631);
                set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                // pto: %306, %307
                ;
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
                if ((int64_t) ((uint64_t) v512 + (uint64_t) v576) == v27) {
                  pipe_barrier(PIPE_M);
                  TMATMUL(v509, v624, v628);
                } else {
                  pipe_barrier(PIPE_M);
                  TMATMUL_ACC(v509, v509, v624, v628);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              };
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          // pto: %309
          ;
          int64_t v632 = v503 < v27 ? v27 : v503;
          // pto: %310, %311
          ;
          int64_t v633 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v6 * (uint64_t) v37) + (uint64_t) v69);
          // pto: %312
          ;
          int64_t v634 = v633 < v27 ? v27 : v633;
          // pto: %accum_inline5581__iter_v6_pview
          ;
          __gm__ float* v635 = PTOAS__GLOBAL_TENSOR_DATA(v47);
          // pto: %accum_inline5581__iter_v6_pview
          ;
          const int64_t v636 = 0;
          // pto: %accum_inline5581__iter_v6_pview
          ;
          const int64_t v637 = 8192;
          // pto: %accum_inline5581__iter_v6_pview
          ;
          pto::Shape<1, 1, 1, 16, 128> v638 = pto::Shape<1, 1, 1, 16, 128>();
          // pto: %accum_inline5581__iter_v6_pview
          ;
          pto::Stride<131072, 131072, 131072, 8192, 1> v639 = pto::Stride<131072, 131072, 131072, 8192, 1>();
          // pto: %accum_inline5581__iter_v6_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND> v640 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<131072, 131072, 131072, 8192, 1>, pto::Layout::ND>(v635 + (v636 + v632 * v637 + v634), v638, v639);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          pipe_barrier(PIPE_FIX);
          TSTORE(v640, v509);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
        };
      };
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}