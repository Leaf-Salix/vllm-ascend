#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qr_rms_norm_quant(__gm__ int8_t* v1, __gm__ float* v2, __gm__ float* v3, __gm__ int8_t* v4, __gm__ float* v5, __gm__ bfloat16_t* v6, int64_t v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int64_t v12, int32_t v13, int32_t v14) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c17504_i64
  const int64_t v15 = 17504;
  // pto: %c50272_i64
  const int64_t v16 = 50272;
  const int64_t v17 = 19552;
  const int64_t v18 = 18528;
  const int64_t v19 = 18016;
  const int64_t v20 = 17760;
  // pto: %c1088_i64
  const int64_t v21 = 1088;
  // pto: %c0_i64
  const int64_t v22 = 0;
  // pto: %c32_i64
  const int64_t v23 = 32;
  // pto: %c64_i64
  const int64_t v24 = 64;
  // pto: %c576_i64
  const int64_t v25 = 576;
  // pto: %c9280_i64
  const int64_t v26 = 9280;
  // pto: %c17472_i64
  const int64_t v27 = 17472;
  // pto: %c512_index
  const int64_t v28 = 512;
  // pto: %c1024_index
  const int64_t v29 = 1024;
  // pto: %c1_index
  const int64_t v30 = 1;
  // pto: %c8_index
  const int64_t v31 = 8;
  // pto: %c0_index
  const int64_t v32 = 0;
  // pto: %c256_index
  const int64_t v33 = 256;
  // pto: %c128_index
  const int64_t v34 = 128;
  // pto: %c64_index
  const int64_t v35 = 64;
  // pto: %cst_21
  const float v36 = 9.765625E-4f;
  // pto: %cst_22
  const float v37 = 9.99999997E-7f;
  // pto: %c0_i32
  const int32_t v38 = 0;
  // pto: %c8388608_index
  const int64_t v39 = 8388608;
  // pto: %c2139095040_i64
  const int64_t v40 = 2139095040;
  // pto: %c8388608_i64
  const int64_t v41 = 8388608;
  // pto: %c2_index
  const int64_t v42 = 2;
  // pto: %c2_i64
  const int64_t v43 = 2;
  // pto: %c152_i64
  const int64_t v44 = 152;
  // pto: %c1_i64
  const int64_t v45 = 1;
  // pto: %cst_31
  const float v46 = 0.0f;
  // pto: %cst_32
  const float v47 = 1.0f;
  // pto: %cst_33
  const float v48 = 9.99999974E-5f;
  // pto: %cst_34
  const float v49 = 127.0f;
  // pto: %island_qr_pad__iter_v1_view
  const int64_t v50 = 1;
  // pto: %island_qr_pad__iter_v1_view
  const int64_t v51 = 1;
  // pto: %island_qr_pad__iter_v1_view
  const int64_t v52 = 1;
  // pto: %island_qr_pad__iter_v1_view
  int64_t v53 = v28 * v29;
  // pto: %island_qr_pad__iter_v1_view
  int64_t v54 = v52 * v53;
  // pto: %island_qr_pad__iter_v1_view
  pto::Shape<1, 1, 1, -1, -1> v55 = pto::Shape<1, 1, 1, -1, -1>(v50, v51, v52, v28, v29);
  // pto: %island_qr_pad__iter_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v56 = pto::Stride<-1, -1, -1, -1, -1>(v51 * v54, v54, v53, v29, v30);
  // pto: %island_qr_pad__iter_v1_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v57 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v55, v56);
  // pto: %island_scale_pad__iter_v1_view
  const int64_t v58 = 1;
  // pto: %island_scale_pad__iter_v1_view
  const int64_t v59 = 1;
  // pto: %island_scale_pad__iter_v1_view
  const int64_t v60 = 1;
  // pto: %island_scale_pad__iter_v1_view
  int64_t v61 = v28 * v30;
  // pto: %island_scale_pad__iter_v1_view
  int64_t v62 = v60 * v61;
  // pto: %island_scale_pad__iter_v1_view
  pto::Shape<1, 1, 1, -1, -1> v63 = pto::Shape<1, 1, 1, -1, -1>(v58, v59, v60, v28, v30);
  // pto: %island_scale_pad__iter_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v64 = pto::Stride<-1, -1, -1, -1, -1>(v59 * v62, v62, v61, v30, v28);
  // pto: %island_scale_pad__iter_v1_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v65 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v2, v63, v64);
  // pto: %qr_scale_view_inline3406__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %qr_scale_view_inline3406__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %qr_scale_view_inline3406__ssa_v0_view
  const int64_t v68 = 1;
  // pto: %qr_scale_view_inline3406__ssa_v0_view
  int64_t v69 = (int64_t) v11;
  // pto: %qr_scale_view_inline3406__ssa_v0_view
  int64_t v70 = v69 * v30;
  // pto: %qr_scale_view_inline3406__ssa_v0_view
  int64_t v71 = v68 * v70;
  // pto: %qr_scale_view_inline3406__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v72 = pto::Shape<1, 1, 1, -1, -1>(v66, v67, v68, v69, v30);
  // pto: %qr_scale_view_inline3406__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v73 = pto::Stride<-1, -1, -1, -1, -1>(v67 * v71, v71, v70, v30, (int64_t) v11);
  // pto: %qr_scale_view_inline3406__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v74 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v3, v72, v73);
  // pto: %qr_view_inline3405__ssa_v0_view
  const int64_t v75 = 1;
  // pto: %qr_view_inline3405__ssa_v0_view
  const int64_t v76 = 1;
  // pto: %qr_view_inline3405__ssa_v0_view
  const int64_t v77 = 1;
  // pto: %qr_view_inline3405__ssa_v0_view
  int64_t v78 = (int64_t) v11;
  // pto: %qr_view_inline3405__ssa_v0_view
  int64_t v79 = v78 * v29;
  // pto: %qr_view_inline3405__ssa_v0_view
  int64_t v80 = v77 * v79;
  // pto: %qr_view_inline3405__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v81 = pto::Shape<1, 1, 1, -1, -1>(v75, v76, v77, v78, v29);
  // pto: %qr_view_inline3405__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v82 = pto::Stride<-1, -1, -1, -1, -1>(v76 * v80, v80, v79, v29, v30);
  // pto: %qr_view_inline3405__ssa_v0_view
  GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v83 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v81, v82);
  // pto: %qr_fp32_inline3313__phi_v35_view
  const int64_t v84 = 1;
  // pto: %qr_fp32_inline3313__phi_v35_view
  const int64_t v85 = 1;
  // pto: %qr_fp32_inline3313__phi_v35_view
  const int64_t v86 = 1;
  // pto: %qr_fp32_inline3313__phi_v35_view
  int64_t v87 = (int64_t) v12;
  // pto: %qr_fp32_inline3313__phi_v35_view
  int64_t v88 = v87 * v29;
  // pto: %qr_fp32_inline3313__phi_v35_view
  int64_t v89 = v86 * v88;
  // pto: %qr_fp32_inline3313__phi_v35_view
  pto::Shape<1, 1, 1, -1, -1> v90 = pto::Shape<1, 1, 1, -1, -1>(v84, v85, v86, v87, v29);
  // pto: %qr_fp32_inline3313__phi_v35_view
  pto::Stride<-1, -1, -1, -1, -1> v91 = pto::Stride<-1, -1, -1, -1, -1>(v85 * v89, v89, v88, v29, v30);
  // pto: %qr_fp32_inline3313__phi_v35_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v92 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v90, v91);
  // pto: %gamma_cq__ssa_v0_view
  const int64_t v93 = 1;
  // pto: %gamma_cq__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %gamma_cq__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %gamma_cq__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %gamma_cq__ssa_v0_view
  int64_t v97 = v29 * v30;
  // pto: %gamma_cq__ssa_v0_view
  int64_t v98 = v96 * v97;
  // pto: %gamma_cq__ssa_v0_view
  int64_t v99 = v95 * v98;
  // pto: %gamma_cq__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v100 = pto::Shape<1, 1, 1, 1, -1>(v93, v94, v95, v96, v29);
  // pto: %gamma_cq__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v101 = pto::Stride<-1, -1, -1, -1, -1>(v94 * v99, v99, v98, v97, v30);
  // pto: %gamma_cq__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v102 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v100, v101);
  // pto: %tg_idx_worker_inline3409__ssa_v0
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  for (int64_t v103 = (int64_t) v13; v103 < v7; v103 += v8) {
    // pto: %49
    ;
    int64_t v104 = (int64_t) ((uint64_t) v103 * (uint64_t) v31);
    // pto: %50
    ;
    int64_t v105 = (int64_t) ((uint64_t) v9 - (uint64_t) v104);
    // pto: %51
    ;
    int64_t v106 = v105 < v31 ? v105 : v31;
    // pto: %52
    ;
    int64_t v107 = (int64_t) ((uint64_t) v10 + (uint64_t) v104);
    // pto: %t__tile
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v29);
    // pto: %t__tile
    ;
    uint64_t v109 = (uint64_t) v15;
    TASSIGN(v108, v109);
    // pto: %53
    ;
    int64_t v110 = v104 < v32 ? v32 : v104;
    // pto: %qr_fp32_inline3313__phi_v35_pview
    ;
    __gm__ float* v111 = PTOAS__GLOBAL_TENSOR_DATA(v92);
    // pto: %qr_fp32_inline3313__phi_v35_pview
    ;
    const int64_t v112 = 0;
    // pto: %qr_fp32_inline3313__phi_v35_pview
    ;
    const int64_t v113 = 1024;
    // pto: %qr_fp32_inline3313__phi_v35_pview
    ;
    pto::Shape<1, 1, 1, 8, 1024> v114 = pto::Shape<1, 1, 1, 8, 1024>();
    // pto: %qr_fp32_inline3313__phi_v35_pview
    ;
    pto::Stride<8192, 8192, 8192, 1024, 1> v115 = pto::Stride<8192, 8192, 8192, 1024, 1>();
    // pto: %qr_fp32_inline3313__phi_v35_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1024>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v116 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1024>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v111 + (v112 + v110 * v113), v114, v115);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v108, v116);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %0
    ;
    Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v117 = Tile<TileType::Vec, bfloat16_t, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v29);
    // pto: %0
    ;
    uint64_t v118 = (uint64_t) v16;
    TASSIGN(v117, v118);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    RoundMode v119 = RoundMode::CAST_RINT;
    SaturationMode v120 = SaturationMode::ON;
    TCVT(v117, v108, v119, v120);
    // pto: %qr_rms_full_inline3444__tile
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v29);
    // pto: %qr_rms_full_inline3444__tile
    ;
    uint64_t v122 = (uint64_t) v15;
    TASSIGN(v121, v122);
    pipe_barrier(PIPE_V);
    RoundMode v123 = RoundMode::CAST_ROUND;
    SaturationMode v124 = SaturationMode::ON;
    TCVT(v121, v117, v123, v124);
    // pto: %qr_square_full_inline3445__tile
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v125 = Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v29);
    // pto: %qr_square_full_inline3445__tile
    ;
    uint64_t v126 = (uint64_t) v15;
    TASSIGN(v125, v126);
    pipe_barrier(PIPE_V);
    TMUL(v125, v121, v121);
    // pto: %1
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v28);
    // pto: %1
    ;
    uint64_t v128 = (uint64_t) v15;
    TASSIGN(v127, v128);
    // pto: %slice_view
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, 8, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v129;
    // pto: %slice_view
    ;
    uint64_t v130 = (uint64_t) v15;
    TASSIGN(v129, v130);
    // pto: %2
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v28);
    // pto: %2
    ;
    uint64_t v132 = (uint64_t) v17;
    TASSIGN(v131, v132);
    // pto: %54
    ;
    Tile<TileType::Vec, float, 8, 1024, BLayout::RowMajor, 8, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v133;
    // pto: %54
    ;
    uint64_t v134 = (uint64_t) v17;
    TASSIGN(v133, v134);
    // pto: %qr_square_half_inline3446__tile
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v135 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v28);
    // pto: %qr_square_half_inline3446__tile
    ;
    uint64_t v136 = (uint64_t) v15;
    TASSIGN(v135, v136);
    pipe_barrier(PIPE_V);
    TADD(v135, v129, v133);
    // pto: %3
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v137 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
    // pto: %3
    ;
    uint64_t v138 = (uint64_t) v15;
    TASSIGN(v137, v138);
    // pto: %55
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v139;
    // pto: %55
    ;
    uint64_t v140 = (uint64_t) v15;
    TASSIGN(v139, v140);
    // pto: %4
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v141 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
    // pto: %4
    ;
    uint64_t v142 = (uint64_t) v18;
    TASSIGN(v141, v142);
    // pto: %56
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v143;
    // pto: %56
    ;
    uint64_t v144 = (uint64_t) v18;
    TASSIGN(v143, v144);
    // pto: %qr_square_quarter_inline3447__tile
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v145 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
    // pto: %qr_square_quarter_inline3447__tile
    ;
    uint64_t v146 = (uint64_t) v15;
    TASSIGN(v145, v146);
    pipe_barrier(PIPE_V);
    TADD(v145, v139, v143);
    // pto: %5
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v147 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v34);
    // pto: %5
    ;
    uint64_t v148 = (uint64_t) v15;
    TASSIGN(v147, v148);
    // pto: %57
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, 8, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v149;
    // pto: %57
    ;
    uint64_t v150 = (uint64_t) v15;
    TASSIGN(v149, v150);
    // pto: %6
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v151 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v34);
    // pto: %6
    ;
    uint64_t v152 = (uint64_t) v19;
    TASSIGN(v151, v152);
    // pto: %58
    ;
    Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, 8, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v153;
    // pto: %58
    ;
    uint64_t v154 = (uint64_t) v19;
    TASSIGN(v153, v154);
    // pto: %qr_square_eighth_inline3448__tile
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v34);
    // pto: %qr_square_eighth_inline3448__tile
    ;
    uint64_t v156 = (uint64_t) v15;
    TASSIGN(v155, v156);
    pipe_barrier(PIPE_V);
    TADD(v155, v149, v153);
    // pto: %7
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v35);
    // pto: %7
    ;
    uint64_t v158 = (uint64_t) v15;
    TASSIGN(v157, v158);
    // pto: %59
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v159;
    // pto: %59
    ;
    uint64_t v160 = (uint64_t) v15;
    TASSIGN(v159, v160);
    // pto: %8
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v161 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v35);
    // pto: %8
    ;
    uint64_t v162 = (uint64_t) v20;
    TASSIGN(v161, v162);
    // pto: %60
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v163;
    // pto: %60
    ;
    uint64_t v164 = (uint64_t) v20;
    TASSIGN(v163, v164);
    // pto: %qr_square_sixteenth_inline3449__tile
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v165 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v35);
    // pto: %qr_square_sixteenth_inline3449__tile
    ;
    uint64_t v166 = (uint64_t) v16;
    TASSIGN(v165, v166);
    pipe_barrier(PIPE_V);
    TADD(v165, v159, v163);
    // pto: %tmp_tile
    ;
    Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v34);
    // pto: %tmp_tile
    ;
    uint64_t v168 = (uint64_t) v15;
    TASSIGN(v167, v168);
    // pto: %9
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v30);
    // pto: %9
    ;
    uint64_t v170 = (uint64_t) v21;
    TASSIGN(v169, v170);
    pipe_barrier(PIPE_V);
    TROWSUM(v169, v165, v167);
    // pto: %qr_sq_sum_inline3450__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v171 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_sq_sum_inline3450__tile
    ;
    uint64_t v172 = (uint64_t) v21;
    TASSIGN(v171, v172);
    // pto: %10
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v173 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %10
    ;
    uint64_t v174 = (uint64_t) v15;
    TASSIGN(v173, v174);
    pipe_barrier(PIPE_V);
    TMULS(v173, v171, v36);
    // pto: %qr_variance_inline3451__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_variance_inline3451__tile
    ;
    uint64_t v176 = (uint64_t) v15;
    TASSIGN(v175, v176);
    pipe_barrier(PIPE_V);
    TADDS(v175, v173, v37);
    // pto: %qr_rms_approx_inline3452__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v177 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_rms_approx_inline3452__tile
    ;
    uint64_t v178 = (uint64_t) v16;
    TASSIGN(v177, v178);
    pipe_barrier(PIPE_V);
    TSQRT(v177, v175);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %qr_variance_bits_inline3453__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_variance_bits_inline3453__tile
    ;
    uint64_t v180 = (uint64_t) v15;
    TASSIGN(v179, v180);
    // pto: %qr_approx_bits_inline3454__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_approx_bits_inline3454__tile
    ;
    uint64_t v182 = (uint64_t) v16;
    TASSIGN(v181, v182);
    // pto: %qr_rounded_bits_inline3455__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v183 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_rounded_bits_inline3455__tile
    ;
    uint64_t v184 = (uint64_t) v21;
    TASSIGN(v183, v184);
    TEXPANDS(v183, v38);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    for (int64_t v185 = v32; v185 < v31; v185 += v30) {
      // pto: %61
      ;
      int32_t v186 = v179.GetValue(v185);
      // pto: %62
      ;
      int64_t v187 = (int64_t) v186;
      // pto: %63
      ;
      int32_t v188 = v181.GetValue(v185);
      // pto: %66
      ;
      // pto: %68, %69, %70
      ;
      if ((int64_t) v186 >= v39 & v187 < v40) {
        // pto: %71
        ;
        const int64_t v189 = 1;
        // pto: %71
        ;
        const int64_t v190 = 0;
        // pto: %71
        ;
        int64_t v191 = v187 / v41;
        // pto: %71
        ;
        bool v192 = v187 < v190;
        // pto: %71
        ;
        bool v193 = v41 < v190;
        // pto: %71
        ;
        bool v194 = v192 == v193;
        // pto: %71
        ;
        bool v195 = v187 % v41 != v190 && v192 != v193;
        // pto: %71
        ;
        int64_t v196 = v195 ? v191 - v189 : v191;
        // pto: %72
        ;
        int64_t v197 = v187 % v41;
        // pto: %73, %74, %75
        ;
        int64_t v198 = v197 < v22 ? (int64_t) ((uint64_t) v197 + (uint64_t) v41) : v197;
        // pto: %76
        ;
        int64_t v199 = (int64_t) ((uint64_t) v198 + (uint64_t) v41);
        // pto: %qr_y_bits_inline3458__rv_v2
        ;
        int64_t v200;
        v200 = (int64_t) v188;
        for (int64_t v201 = v32; v201 < v42; v201 += v30) {
          // pto: %77
          ;
          const int64_t v202 = 1;
          // pto: %77
          ;
          const int64_t v203 = 0;
          // pto: %77
          ;
          int64_t v204 = v200 / v41;
          // pto: %77
          ;
          int64_t v205 = v200 % v41;
          // pto: %77
          ;
          bool v206 = v200 < v203;
          // pto: %77
          ;
          bool v207 = v41 < v203;
          // pto: %77
          ;
          bool v208 = v206 == v207;
          // pto: %77
          ;
          bool v209 = v205 != v203 && v206 != v207;
          // pto: %77
          ;
          int64_t v210 = v209 ? v204 - v202 : v204;
          // pto: %78
          ;
          int64_t v211 = v200 % v41;
          // pto: %79, %80, %81
          ;
          int64_t v212 = v211 < v22 ? (int64_t) ((uint64_t) v211 + (uint64_t) v41) : v211;
          // pto: %82, %83, %85
          ;
          int64_t v213 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v212 + (uint64_t) v41) * (uint64_t) v43) + (uint64_t) v30);
          // pto: %86
          ;
          int64_t v214 = (int64_t) ((uint64_t) v213 * (uint64_t) v213);
          // pto: %92, %90, %87, %91
          ;
          int64_t v215 = (int64_t) ((uint64_t) v199 << (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v196 - (uint64_t) ((int64_t) (uint64_t) v210 * (uint64_t) v43)) + (uint64_t) v44));
          // pto: %93
          ;
          uint64_t v216 = (uint64_t) v200;
          // pto: %93
          ;
          int64_t v217 = (int64_t) (v216 - (uint64_t) v45);
          // pto: %94
          ;
          const int64_t v218 = 1;
          // pto: %94
          ;
          const int64_t v219 = 0;
          // pto: %94
          ;
          int64_t v220 = v217 / v41;
          // pto: %94
          ;
          bool v221 = v217 < v219;
          // pto: %94
          ;
          bool v222 = v41 < v219;
          // pto: %94
          ;
          bool v223 = v221 == v222;
          // pto: %94
          ;
          bool v224 = v217 % v41 != v219 && v221 != v222;
          // pto: %94
          ;
          int64_t v225 = v224 ? v220 - v218 : v220;
          // pto: %95
          ;
          int64_t v226 = v217 % v41;
          // pto: %96, %97, %98
          ;
          int64_t v227 = v226 < v22 ? (int64_t) ((uint64_t) v226 + (uint64_t) v41) : v226;
          // pto: %99, %100, %102
          ;
          int64_t v228 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v227 + (uint64_t) v41) * (uint64_t) v43) + (uint64_t) v30);
          // pto: %103
          ;
          int64_t v229 = (int64_t) ((uint64_t) v228 * (uint64_t) v228);
          // pto: %109, %107, %104, %108
          ;
          int64_t v230 = (int64_t) ((uint64_t) v199 << (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v196 - (uint64_t) ((int64_t) (uint64_t) v225 * (uint64_t) v43)) + (uint64_t) v44));
          // pto: %114
          ;
          int64_t v231 = v200 % v43;
          // pto: %115, %116, %117
          ;
          int64_t v232 = v231 < v22 ? (int64_t) ((uint64_t) v231 + (uint64_t) v43) : v231;
          // pto: %118
          ;
          bool v233 = v232 == v45;
          // pto: %111, %113, %119, %120
          ;
          // pto: %qr_y_bits_inline3458__phi_v6
          ;
          int64_t v234;
          if (v214 < v215 | v215 == v214 & v233) {
            // pto: %121
            ;
            uint64_t v235 = (uint64_t) v200;
            // pto: %121
            ;
            v234 = (int64_t) (v235 + (uint64_t) v45);
          } else {
            // pto: %123, %125, %131, %132
            ;
            bool v236 = v230 < v229 | v230 == v229 & v233;
            // pto: %qr_y_bits_inline3458__phi_v5
            ;
            int64_t v237 = v236 ? v217 : v200;
            v234 = v237;
          };
          v200 = v234;
        };
        // pto: %134
        ;
        int32_t v238 = (int32_t) v200;
        v183.SetValue(v185, v238);
      } else {
        v183.SetValue(v185, v188);
      };
    };
    set_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
    // pto: %qr_rms_inline3473__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v239 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_rms_inline3473__tile
    ;
    uint64_t v240 = (uint64_t) v21;
    TASSIGN(v239, v240);
    // pto: %qr_inv_rms_inline3474__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v241 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_inv_rms_inline3474__tile
    ;
    uint64_t v242 = (uint64_t) v22;
    TASSIGN(v241, v242);
    TEXPANDS(v241, v46);
    set_flag(PIPE_V, PIPE_S, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
    for (int64_t v243 = v32; v243 < v31; v243 += v30) {
      // pto: %qr_rms_value_inline3476__tile
      ;
      float v244 = v239.GetValue(v243);
      // pto: %142
      ;
      float v245 = v47 / v244;
      v241.SetValue(v243, v245);
    };
    set_flag(PIPE_S, PIPE_V, EVENT_ID0);
    // pto: %qr_inv_rms_inline3416__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_inv_rms_inline3416__ssa_v0
    ;
    uint64_t v247 = (uint64_t) v22;
    TASSIGN(v246, v247);
    // pto: %qr_inv_rms_t_inline3418__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v248 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v30);
    // pto: %qr_inv_rms_t_inline3418__tile
    ;
    uint64_t v249 = (uint64_t) v22;
    TASSIGN(v248, v249);
    // pto: %qr_tile_amax_inline3419__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v250 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_tile_amax_inline3419__tile
    ;
    uint64_t v251 = (uint64_t) v23;
    TASSIGN(v250, v251);
    TEXPANDS(v250, v48);
    wait_flag(PIPE_S, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
    for (int64_t v252 = v32; v252 < v29; v252 += v28) {
      // pto: %11
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v253 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %11
      ;
      uint64_t v254 = (uint64_t) v15;
      TASSIGN(v253, v254);
      // pto: %146
      ;
      int64_t v255 = v252 < v32 ? v32 : v252;
      // pto: %147
      ;
      __gm__ float* v256 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %147
      ;
      const int64_t v257 = 0;
      // pto: %147
      ;
      const int64_t v258 = 1024;
      // pto: %147
      ;
      pto::Shape<1, 1, 1, 8, 256> v259 = pto::Shape<1, 1, 1, 8, 256>();
      // pto: %147
      ;
      pto::Stride<8192, 8192, 8192, 1024, 1> v260 = pto::Stride<8192, 8192, 8192, 1024, 1>();
      // pto: %147
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v261 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v256 + (v257 + v110 * v258 + v255), v259, v260);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      TLOAD(v253, v261);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %12
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v262 = Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %12
      ;
      uint64_t v263 = (uint64_t) v24;
      TASSIGN(v262, v263);
      // pto: %gamma_cq__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v264 = PTOAS__GLOBAL_TENSOR_DATA(v102);
      // pto: %gamma_cq__ssa_v0_pview
      ;
      const int64_t v265 = 0;
      // pto: %gamma_cq__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 256> v266 = pto::Shape<1, 1, 1, 1, 256>();
      // pto: %gamma_cq__ssa_v0_pview
      ;
      pto::Stride<256, 256, 256, 256, 1> v267 = pto::Stride<256, 256, 256, 256, 1>();
      // pto: %gamma_cq__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v268 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v264 + (v265 + v255), v266, v267);
      TLOAD(v262, v268);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %13
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %13
      ;
      uint64_t v270 = (uint64_t) v16;
      TASSIGN(v269, v270);
      // pto: %150
      ;
      int64_t v271 = (int64_t) ((uint64_t) v252 + (uint64_t) v33);
      // pto: %151
      ;
      int64_t v272 = v271 < v32 ? v32 : v271;
      // pto: %152
      ;
      __gm__ float* v273 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %152
      ;
      const int64_t v274 = 0;
      // pto: %152
      ;
      const int64_t v275 = 1024;
      // pto: %152
      ;
      pto::Shape<1, 1, 1, 8, 256> v276 = pto::Shape<1, 1, 1, 8, 256>();
      // pto: %152
      ;
      pto::Stride<8192, 8192, 8192, 1024, 1> v277 = pto::Stride<8192, 8192, 8192, 1024, 1>();
      // pto: %152
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v278 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v273 + (v274 + v110 * v275 + v272), v276, v277);
      TLOAD(v269, v278);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %14
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %14
      ;
      uint64_t v280 = (uint64_t) v25;
      TASSIGN(v279, v280);
      // pto: %155
      ;
      __gm__ bfloat16_t* v281 = PTOAS__GLOBAL_TENSOR_DATA(v102);
      // pto: %155
      ;
      const int64_t v282 = 0;
      // pto: %155
      ;
      pto::Shape<1, 1, 1, 1, 256> v283 = pto::Shape<1, 1, 1, 1, 256>();
      // pto: %155
      ;
      pto::Stride<256, 256, 256, 256, 1> v284 = pto::Stride<256, 256, 256, 256, 1>();
      // pto: %155
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v285 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v281 + (v282 + v272), v283, v284);
      TLOAD(v279, v285);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      // pto: %15
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v286 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %15
      ;
      uint64_t v287 = (uint64_t) v21;
      TASSIGN(v286, v287);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      pipe_barrier(PIPE_V);
      RoundMode v288 = RoundMode::CAST_RINT;
      SaturationMode v289 = SaturationMode::ON;
      TCVT(v286, v253, v288, v289);
      // pto: %qr_max_chunk_inline3421__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v290 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_max_chunk_inline3421__tile
      ;
      uint64_t v291 = (uint64_t) v15;
      TASSIGN(v290, v291);
      pipe_barrier(PIPE_V);
      RoundMode v292 = RoundMode::CAST_ROUND;
      SaturationMode v293 = SaturationMode::ON;
      TCVT(v290, v286, v292, v293);
      // pto: %gamma_max_cast_inline3422__tile
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v294 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %gamma_max_cast_inline3422__tile
      ;
      uint64_t v295 = (uint64_t) v21;
      TASSIGN(v294, v295);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      RoundMode v296 = RoundMode::CAST_ROUND;
      SaturationMode v297 = SaturationMode::ON;
      TCVT(v294, v262, v296, v297);
      // pto: %gamma_max_chunk_inline3423__tile
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %gamma_max_chunk_inline3423__tile
      ;
      uint64_t v299 = (uint64_t) v21;
      TASSIGN(v298, v299);
      // pto: %16
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v300 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %16
      ;
      uint64_t v301 = (uint64_t) v15;
      TASSIGN(v300, v301);
      TROWEXPANDMUL(v300, v290, v248);
      // pto: %qr_normalized_inline3424__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v302 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_normalized_inline3424__tile
      ;
      uint64_t v303 = (uint64_t) v15;
      TASSIGN(v302, v303);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v302, v300, v298);
      // pto: %17
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v304 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %17
      ;
      uint64_t v305 = (uint64_t) v15;
      TASSIGN(v304, v305);
      pipe_barrier(PIPE_V);
      TABS(v304, v302);
      // pto: %18
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %18
      ;
      uint64_t v307 = (uint64_t) v21;
      TASSIGN(v306, v307);
      // pto: %19
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v308 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v30);
      // pto: %19
      ;
      uint64_t v309 = (uint64_t) v24;
      TASSIGN(v308, v309);
      pipe_barrier(PIPE_V);
      TROWMAX(v308, v304, v306);
      // pto: %qr_normalized_max_inline3425__tile
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v310 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
      // pto: %qr_normalized_max_inline3425__tile
      ;
      uint64_t v311 = (uint64_t) v24;
      TASSIGN(v310, v311);
      // pto: %20
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v312 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
      // pto: %20
      ;
      uint64_t v313 = (uint64_t) v15;
      TASSIGN(v312, v313);
      pipe_barrier(PIPE_V);
      TMAX(v312, v250, v310);
      // pto: %21
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v314 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %21
      ;
      uint64_t v315 = (uint64_t) v26;
      TASSIGN(v314, v315);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      RoundMode v316 = RoundMode::CAST_RINT;
      SaturationMode v317 = SaturationMode::ON;
      TCVT(v314, v269, v316, v317);
      // pto: %22
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v318 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %22
      ;
      uint64_t v319 = (uint64_t) v16;
      TASSIGN(v318, v319);
      pipe_barrier(PIPE_V);
      RoundMode v320 = RoundMode::CAST_ROUND;
      SaturationMode v321 = SaturationMode::ON;
      TCVT(v318, v314, v320, v321);
      // pto: %23
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v322 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %23
      ;
      uint64_t v323 = (uint64_t) v26;
      TASSIGN(v322, v323);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      RoundMode v324 = RoundMode::CAST_ROUND;
      SaturationMode v325 = SaturationMode::ON;
      TCVT(v322, v279, v324, v325);
      // pto: %24
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v326 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %24
      ;
      uint64_t v327 = (uint64_t) v26;
      TASSIGN(v326, v327);
      // pto: %25
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %25
      ;
      uint64_t v329 = (uint64_t) v16;
      TASSIGN(v328, v329);
      TROWEXPANDMUL(v328, v318, v248);
      // pto: %26
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v330 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %26
      ;
      uint64_t v331 = (uint64_t) v16;
      TASSIGN(v330, v331);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v330, v328, v326);
      // pto: %27
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v332 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %27
      ;
      uint64_t v333 = (uint64_t) v16;
      TASSIGN(v332, v333);
      pipe_barrier(PIPE_V);
      TABS(v332, v330);
      // pto: %28
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v334 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %28
      ;
      uint64_t v335 = (uint64_t) v26;
      TASSIGN(v334, v335);
      // pto: %29
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v336 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v30);
      // pto: %29
      ;
      uint64_t v337 = (uint64_t) v25;
      TASSIGN(v336, v337);
      pipe_barrier(PIPE_V);
      TROWMAX(v336, v332, v334);
      // pto: %30
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v338 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
      // pto: %30
      ;
      uint64_t v339 = (uint64_t) v25;
      TASSIGN(v338, v339);
      // pto: %31
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v340 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
      // pto: %31
      ;
      uint64_t v341 = (uint64_t) v23;
      TASSIGN(v340, v341);
      pipe_barrier(PIPE_V);
      TMAX(v340, v312, v338);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    };
    // pto: %qr_scale_quant_row_inline3426__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v342 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_scale_quant_row_inline3426__tile
    ;
    uint64_t v343 = (uint64_t) v27;
    TASSIGN(v342, v343);
    TEXPANDS(v342, v46);
    // pto: %qr_scale_dq_row_inline3427__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v344 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v31);
    // pto: %qr_scale_dq_row_inline3427__tile
    ;
    uint64_t v345 = (uint64_t) v15;
    TASSIGN(v344, v345);
    pipe_barrier(PIPE_V);
    TEXPANDS(v344, v46);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_V, PIPE_S, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID2);
    for (int64_t v346 = v32; v346 < v31; v346 += v30) {
      // pto: %qr_amax_value_inline3429__tile
      ;
      float v347 = v250.GetValue(v346);
      // pto: %158
      ;
      float v348 = v49 / v347;
      v342.SetValue(v346, v348);
      // pto: %161
      ;
      float v349 = v47 / v348;
      v344.SetValue(v346, v349);
    };
    set_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
    // pto: %qr_scale_quant_t_inline3431__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v350 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v30);
    // pto: %qr_scale_quant_t_inline3431__tile
    ;
    uint64_t v351 = (uint64_t) v27;
    TASSIGN(v350, v351);
    // pto: %qr_tile_scale_dq_inline3432__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v352 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v30);
    // pto: %qr_tile_scale_dq_inline3432__tile
    ;
    uint64_t v353 = (uint64_t) v15;
    TASSIGN(v352, v353);
    // pto: %island_scale_pad__iter_v3_pview
    ;
    __gm__ float* v354 = PTOAS__GLOBAL_TENSOR_DATA(v65);
    // pto: %island_scale_pad__iter_v3_pview
    ;
    const int64_t v355 = 0;
    // pto: %island_scale_pad__iter_v3_pview
    ;
    pto::Shape<1, 1, 1, 8, 1> v356 = pto::Shape<1, 1, 1, 8, 1>();
    // pto: %island_scale_pad__iter_v3_pview
    ;
    pto::Stride<8, 8, 8, 1, 512> v357 = pto::Stride<8, 8, 8, 1, 512>();
    // pto: %island_scale_pad__iter_v3_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN> v358 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 512>, pto::Layout::DN>(v354 + (v355 + v110), v356, v357);
    wait_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v358, v352);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    // pto: %165
    ;
    bool v359 = v106 == v31;
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    if (v359) {
      // pto: %166
      ;
      int64_t v360 = v107 < v32 ? v32 : v107;
      // pto: %qr_scale_view_inline3406__iter_v1_pview
      ;
      int64_t v361 = (int64_t) v11;
      // pto: %qr_scale_view_inline3406__iter_v1_pview
      ;
      const int64_t v362 = 0;
      // pto: %qr_scale_view_inline3406__iter_v1_pview
      ;
      __gm__ float* v363 = PTOAS__GLOBAL_TENSOR_DATA(v74);
      // pto: %qr_scale_view_inline3406__iter_v1_pview
      ;
      const int64_t v364 = 1;
      // pto: %qr_scale_view_inline3406__iter_v1_pview
      ;
      const int64_t v365 = 1;
      // pto: %qr_scale_view_inline3406__iter_v1_pview
      ;
      const int64_t v366 = 1;
      // pto: %qr_scale_view_inline3406__iter_v1_pview
      ;
      int64_t v367 = v31 * v30;
      // pto: %qr_scale_view_inline3406__iter_v1_pview
      ;
      int64_t v368 = v366 * v367;
      // pto: %qr_scale_view_inline3406__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, 8, 1> v369 = pto::Shape<1, 1, 1, 8, 1>(v364, v365, v366, v31, v30);
      // pto: %qr_scale_view_inline3406__iter_v1_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v370 = pto::Stride<-1, -1, -1, -1, -1>(v365 * v368, v368, v367, v30, v361);
      // pto: %qr_scale_view_inline3406__iter_v1_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v371 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v363 + (v362 + v360 * v30 + v32 * v361), v369, v370);
      TSTORE(v371, v352);
    } else {
      // pto: %qr_scale_tail_inline3433__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v372 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v106, v30);
      // pto: %qr_scale_tail_inline3433__ssa_v0
      ;
      uint64_t v373 = (uint64_t) v15;
      TASSIGN(v372, v373);
      // pto: %island_scale_pad__tile_pview
      ;
      const int64_t v374 = 0;
      // pto: %island_scale_pad__tile_pview
      ;
      __gm__ float* v375 = PTOAS__GLOBAL_TENSOR_DATA(v65);
      // pto: %island_scale_pad__tile_pview
      ;
      const int64_t v376 = 1;
      // pto: %island_scale_pad__tile_pview
      ;
      const int64_t v377 = 1;
      // pto: %island_scale_pad__tile_pview
      ;
      const int64_t v378 = 1;
      // pto: %island_scale_pad__tile_pview
      ;
      int64_t v379 = v106 * v30;
      // pto: %island_scale_pad__tile_pview
      ;
      int64_t v380 = v378 * v379;
      // pto: %island_scale_pad__tile_pview
      ;
      pto::Shape<1, 1, 1, -1, 1> v381 = pto::Shape<1, 1, 1, -1, 1>(v376, v377, v378, v106, v30);
      // pto: %island_scale_pad__tile_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v382 = pto::Stride<-1, -1, -1, -1, -1>(v377 * v380, v380, v379, v30, v28);
      // pto: %island_scale_pad__tile_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v383 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v375 + (v374 + v110 * v30 + v32 * v28), v381, v382);
      TLOAD(v372, v383);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
      // pto: %168
      ;
      int64_t v384 = v107 < v32 ? v32 : v107;
      // pto: %169
      ;
      int64_t v385 = (int64_t) v11;
      // pto: %169
      ;
      const int64_t v386 = 0;
      // pto: %169
      ;
      __gm__ float* v387 = PTOAS__GLOBAL_TENSOR_DATA(v74);
      // pto: %169
      ;
      const int64_t v388 = 1;
      // pto: %169
      ;
      const int64_t v389 = 1;
      // pto: %169
      ;
      const int64_t v390 = 1;
      // pto: %169
      ;
      int64_t v391 = v106 * v30;
      // pto: %169
      ;
      int64_t v392 = v390 * v391;
      // pto: %169
      ;
      pto::Shape<1, 1, 1, -1, 1> v393 = pto::Shape<1, 1, 1, -1, 1>(v388, v389, v390, v106, v30);
      // pto: %169
      ;
      pto::Stride<-1, -1, -1, -1, -1> v394 = pto::Stride<-1, -1, -1, -1, -1>(v389 * v392, v392, v391, v30, v385);
      // pto: %169
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v395 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v387 + (v386 + v384 * v30 + v32 * v385), v393, v394);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
      TSTORE(v395, v372);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    for (int64_t v396 = v32; v396 < v29; v396 += v28) {
      // pto: %32
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v397 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %32
      ;
      uint64_t v398 = (uint64_t) v15;
      TASSIGN(v397, v398);
      // pto: %171
      ;
      int64_t v399 = v396 < v32 ? v32 : v396;
      // pto: %172
      ;
      __gm__ float* v400 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %172
      ;
      const int64_t v401 = 0;
      // pto: %172
      ;
      const int64_t v402 = 1024;
      // pto: %172
      ;
      pto::Shape<1, 1, 1, 8, 256> v403 = pto::Shape<1, 1, 1, 8, 256>();
      // pto: %172
      ;
      pto::Stride<8192, 8192, 8192, 1024, 1> v404 = pto::Stride<8192, 8192, 8192, 1024, 1>();
      // pto: %172
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v405 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v400 + (v401 + v110 * v402 + v399), v403, v404);
      TLOAD(v397, v405);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      // pto: %33
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v406 = Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %33
      ;
      uint64_t v407 = (uint64_t) v24;
      TASSIGN(v406, v407);
      // pto: %174
      ;
      __gm__ bfloat16_t* v408 = PTOAS__GLOBAL_TENSOR_DATA(v102);
      // pto: %174
      ;
      const int64_t v409 = 0;
      // pto: %174
      ;
      pto::Shape<1, 1, 1, 1, 256> v410 = pto::Shape<1, 1, 1, 1, 256>();
      // pto: %174
      ;
      pto::Stride<256, 256, 256, 256, 1> v411 = pto::Stride<256, 256, 256, 256, 1>();
      // pto: %174
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v412 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v408 + (v409 + v399), v410, v411);
      TLOAD(v406, v412);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      // pto: %34
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v413 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %34
      ;
      uint64_t v414 = (uint64_t) v16;
      TASSIGN(v413, v414);
      // pto: %176
      ;
      int64_t v415 = (int64_t) ((uint64_t) v396 + (uint64_t) v33);
      // pto: %177
      ;
      int64_t v416 = v415 < v32 ? v32 : v415;
      // pto: %178
      ;
      __gm__ float* v417 = PTOAS__GLOBAL_TENSOR_DATA(v92);
      // pto: %178
      ;
      const int64_t v418 = 0;
      // pto: %178
      ;
      const int64_t v419 = 1024;
      // pto: %178
      ;
      pto::Shape<1, 1, 1, 8, 256> v420 = pto::Shape<1, 1, 1, 8, 256>();
      // pto: %178
      ;
      pto::Stride<8192, 8192, 8192, 1024, 1> v421 = pto::Stride<8192, 8192, 8192, 1024, 1>();
      // pto: %178
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v422 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v417 + (v418 + v110 * v419 + v416), v420, v421);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      TLOAD(v413, v422);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      // pto: %35
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v423 = Tile<TileType::Vec, bfloat16_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %35
      ;
      uint64_t v424 = (uint64_t) v25;
      TASSIGN(v423, v424);
      // pto: %181
      ;
      __gm__ bfloat16_t* v425 = PTOAS__GLOBAL_TENSOR_DATA(v102);
      // pto: %181
      ;
      const int64_t v426 = 0;
      // pto: %181
      ;
      pto::Shape<1, 1, 1, 1, 256> v427 = pto::Shape<1, 1, 1, 1, 256>();
      // pto: %181
      ;
      pto::Stride<256, 256, 256, 256, 1> v428 = pto::Stride<256, 256, 256, 256, 1>();
      // pto: %181
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND> v429 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 256>, pto::Stride<256, 256, 256, 256, 1>, pto::Layout::ND>(v425 + (v426 + v416), v427, v428);
      TLOAD(v423, v429);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %36
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v430 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %36
      ;
      uint64_t v431 = (uint64_t) v21;
      TASSIGN(v430, v431);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      RoundMode v432 = RoundMode::CAST_RINT;
      SaturationMode v433 = SaturationMode::ON;
      TCVT(v430, v397, v432, v433);
      // pto: %qr_chunk_inline3435__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v434 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_chunk_inline3435__tile
      ;
      uint64_t v435 = (uint64_t) v15;
      TASSIGN(v434, v435);
      pipe_barrier(PIPE_V);
      RoundMode v436 = RoundMode::CAST_ROUND;
      SaturationMode v437 = SaturationMode::ON;
      TCVT(v434, v430, v436, v437);
      // pto: %gamma_q_cast_inline3436__tile
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v438 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %gamma_q_cast_inline3436__tile
      ;
      uint64_t v439 = (uint64_t) v21;
      TASSIGN(v438, v439);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      RoundMode v440 = RoundMode::CAST_ROUND;
      SaturationMode v441 = SaturationMode::ON;
      TCVT(v438, v406, v440, v441);
      // pto: %gamma_q_chunk_inline3437__tile
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v442 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %gamma_q_chunk_inline3437__tile
      ;
      uint64_t v443 = (uint64_t) v21;
      TASSIGN(v442, v443);
      // pto: %37
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v444 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %37
      ;
      uint64_t v445 = (uint64_t) v15;
      TASSIGN(v444, v445);
      TROWEXPANDMUL(v444, v434, v248);
      // pto: %qr_q_normed_inline3438__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v446 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_q_normed_inline3438__tile
      ;
      uint64_t v447 = (uint64_t) v15;
      TASSIGN(v446, v447);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v446, v444, v442);
      // pto: %qr_q_scaled_inline3439__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v448 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_q_scaled_inline3439__tile
      ;
      uint64_t v449 = (uint64_t) v15;
      TASSIGN(v448, v449);
      pipe_barrier(PIPE_V);
      TROWEXPANDMUL(v448, v446, v350);
      // pto: %qr_q_i32_inline3440__tile
      ;
      Tile<TileType::Vec, int32_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v450 = Tile<TileType::Vec, int32_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_q_i32_inline3440__tile
      ;
      uint64_t v451 = (uint64_t) v15;
      TASSIGN(v450, v451);
      pipe_barrier(PIPE_V);
      RoundMode v452 = RoundMode::CAST_RINT;
      SaturationMode v453 = SaturationMode::ON;
      TCVT(v450, v448, v452, v453);
      // pto: %qr_q_half_inline3441__tile
      ;
      Tile<TileType::Vec, half, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v454 = Tile<TileType::Vec, half, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_q_half_inline3441__tile
      ;
      uint64_t v455 = (uint64_t) v15;
      TASSIGN(v454, v455);
      pipe_barrier(PIPE_V);
      RoundMode v456 = RoundMode::CAST_ROUND;
      SaturationMode v457 = SaturationMode::ON;
      TCVT(v454, v450, v456, v457);
      // pto: %qr_q_i8_inline3442__tile
      ;
      Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v458 = Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %qr_q_i8_inline3442__tile
      ;
      uint64_t v459 = (uint64_t) v15;
      TASSIGN(v458, v459);
      pipe_barrier(PIPE_V);
      RoundMode v460 = RoundMode::CAST_TRUNC;
      SaturationMode v461 = SaturationMode::ON;
      TCVT(v458, v454, v460, v461);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      // pto: %island_qr_pad__iter_v5_pview
      ;
      __gm__ int8_t* v462 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %island_qr_pad__iter_v5_pview
      ;
      const int64_t v463 = 0;
      // pto: %island_qr_pad__iter_v5_pview
      ;
      const int64_t v464 = 1024;
      // pto: %island_qr_pad__iter_v5_pview
      ;
      pto::Shape<1, 1, 1, 8, 256> v465 = pto::Shape<1, 1, 1, 8, 256>();
      // pto: %island_qr_pad__iter_v5_pview
      ;
      pto::Stride<8192, 8192, 8192, 1024, 1> v466 = pto::Stride<8192, 8192, 8192, 1024, 1>();
      // pto: %island_qr_pad__iter_v5_pview
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v467 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v462 + (v463 + v110 * v464 + v399), v465, v466);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v467, v458);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      if (v359) {
        // pto: %185
        ;
        int64_t v468 = v107 < v32 ? v32 : v107;
        // pto: %qr_view_inline3405__iter_v3_pview
        ;
        __gm__ int8_t* v469 = PTOAS__GLOBAL_TENSOR_DATA(v83);
        // pto: %qr_view_inline3405__iter_v3_pview
        ;
        const int64_t v470 = 0;
        // pto: %qr_view_inline3405__iter_v3_pview
        ;
        const int64_t v471 = 1024;
        // pto: %qr_view_inline3405__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, 8, 256> v472 = pto::Shape<1, 1, 1, 8, 256>();
        // pto: %qr_view_inline3405__iter_v3_pview
        ;
        pto::Stride<8192, 8192, 8192, 1024, 1> v473 = pto::Stride<8192, 8192, 8192, 1024, 1>();
        // pto: %qr_view_inline3405__iter_v3_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v474 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v469 + (v470 + v468 * v471 + v399), v472, v473);
        TSTORE(v474, v458);
      } else {
        // pto: %qr_q_tail_inline3443__ssa_v0
        ;
        Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v475 = Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v106, v33);
        // pto: %qr_q_tail_inline3443__ssa_v0
        ;
        uint64_t v476 = (uint64_t) v15;
        TASSIGN(v475, v476);
        // pto: %island_qr_pad__tile_pview
        ;
        const int64_t v477 = 0;
        // pto: %island_qr_pad__tile_pview
        ;
        __gm__ int8_t* v478 = PTOAS__GLOBAL_TENSOR_DATA(v57);
        // pto: %island_qr_pad__tile_pview
        ;
        const int64_t v479 = 1;
        // pto: %island_qr_pad__tile_pview
        ;
        const int64_t v480 = 1;
        // pto: %island_qr_pad__tile_pview
        ;
        const int64_t v481 = 1;
        // pto: %island_qr_pad__tile_pview
        ;
        int64_t v482 = v106 * v29;
        // pto: %island_qr_pad__tile_pview
        ;
        int64_t v483 = v481 * v482;
        // pto: %island_qr_pad__tile_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v484 = pto::Shape<1, 1, 1, -1, 256>(v479, v480, v481, v106, v33);
        // pto: %island_qr_pad__tile_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v485 = pto::Stride<-1, -1, -1, -1, -1>(v480 * v483, v483, v482, v29, v30);
        // pto: %island_qr_pad__tile_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v486 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v478 + (v477 + v110 * v29 + v399 * v30), v484, v485);
        TLOAD(v475, v486);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
        // pto: %189
        ;
        int64_t v487 = v107 < v32 ? v32 : v107;
        // pto: %191
        ;
        const int64_t v488 = 0;
        // pto: %191
        ;
        __gm__ int8_t* v489 = PTOAS__GLOBAL_TENSOR_DATA(v83);
        // pto: %191
        ;
        const int64_t v490 = 1;
        // pto: %191
        ;
        const int64_t v491 = 1;
        // pto: %191
        ;
        const int64_t v492 = 1;
        // pto: %191
        ;
        int64_t v493 = v106 * v29;
        // pto: %191
        ;
        int64_t v494 = v492 * v493;
        // pto: %191
        ;
        pto::Shape<1, 1, 1, -1, 256> v495 = pto::Shape<1, 1, 1, -1, 256>(v490, v491, v492, v106, v33);
        // pto: %191
        ;
        pto::Stride<-1, -1, -1, -1, -1> v496 = pto::Stride<-1, -1, -1, -1, -1>(v491 * v494, v494, v493, v29, v30);
        // pto: %191
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v497 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v489 + (v488 + v487 * v29 + v399 * v30), v495, v496);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
        TSTORE(v497, v475);
      };
      // pto: %38
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v498 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %38
      ;
      uint64_t v499 = (uint64_t) v26;
      TASSIGN(v498, v499);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      RoundMode v500 = RoundMode::CAST_RINT;
      SaturationMode v501 = SaturationMode::ON;
      TCVT(v498, v413, v500, v501);
      // pto: %39
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v502 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %39
      ;
      uint64_t v503 = (uint64_t) v16;
      TASSIGN(v502, v503);
      pipe_barrier(PIPE_V);
      RoundMode v504 = RoundMode::CAST_ROUND;
      SaturationMode v505 = SaturationMode::ON;
      TCVT(v502, v498, v504, v505);
      // pto: %40
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v506 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %40
      ;
      uint64_t v507 = (uint64_t) v26;
      TASSIGN(v506, v507);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      RoundMode v508 = RoundMode::CAST_ROUND;
      SaturationMode v509 = SaturationMode::ON;
      TCVT(v506, v423, v508, v509);
      // pto: %41
      ;
      Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v510 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v30, v33);
      // pto: %41
      ;
      uint64_t v511 = (uint64_t) v26;
      TASSIGN(v510, v511);
      // pto: %42
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v512 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %42
      ;
      uint64_t v513 = (uint64_t) v16;
      TASSIGN(v512, v513);
      TROWEXPANDMUL(v512, v502, v248);
      // pto: %43
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v514 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %43
      ;
      uint64_t v515 = (uint64_t) v16;
      TASSIGN(v514, v515);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v514, v512, v510);
      // pto: %44
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v516 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %44
      ;
      uint64_t v517 = (uint64_t) v16;
      TASSIGN(v516, v517);
      pipe_barrier(PIPE_V);
      TROWEXPANDMUL(v516, v514, v350);
      // pto: %45
      ;
      Tile<TileType::Vec, int32_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v518 = Tile<TileType::Vec, int32_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %45
      ;
      uint64_t v519 = (uint64_t) v16;
      TASSIGN(v518, v519);
      pipe_barrier(PIPE_V);
      RoundMode v520 = RoundMode::CAST_RINT;
      SaturationMode v521 = SaturationMode::ON;
      TCVT(v518, v516, v520, v521);
      // pto: %46
      ;
      Tile<TileType::Vec, half, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v522 = Tile<TileType::Vec, half, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %46
      ;
      uint64_t v523 = (uint64_t) v16;
      TASSIGN(v522, v523);
      pipe_barrier(PIPE_V);
      RoundMode v524 = RoundMode::CAST_ROUND;
      SaturationMode v525 = SaturationMode::ON;
      TCVT(v522, v518, v524, v525);
      // pto: %47
      ;
      Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v526 = Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v31, v33);
      // pto: %47
      ;
      uint64_t v527 = (uint64_t) v16;
      TASSIGN(v526, v527);
      pipe_barrier(PIPE_V);
      RoundMode v528 = RoundMode::CAST_TRUNC;
      SaturationMode v529 = SaturationMode::ON;
      TCVT(v526, v522, v528, v529);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      // pto: %196
      ;
      __gm__ int8_t* v530 = PTOAS__GLOBAL_TENSOR_DATA(v57);
      // pto: %196
      ;
      const int64_t v531 = 0;
      // pto: %196
      ;
      const int64_t v532 = 1024;
      // pto: %196
      ;
      pto::Shape<1, 1, 1, 8, 256> v533 = pto::Shape<1, 1, 1, 8, 256>();
      // pto: %196
      ;
      pto::Stride<8192, 8192, 8192, 1024, 1> v534 = pto::Stride<8192, 8192, 8192, 1024, 1>();
      // pto: %196
      ;
      GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v535 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v530 + (v531 + v110 * v532 + v416), v533, v534);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v535, v526);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      if (v359) {
        // pto: %199
        ;
        int64_t v536 = v107 < v32 ? v32 : v107;
        // pto: %qr_view_inline3405__phi_v6_pview
        ;
        __gm__ int8_t* v537 = PTOAS__GLOBAL_TENSOR_DATA(v83);
        // pto: %qr_view_inline3405__phi_v6_pview
        ;
        const int64_t v538 = 0;
        // pto: %qr_view_inline3405__phi_v6_pview
        ;
        const int64_t v539 = 1024;
        // pto: %qr_view_inline3405__phi_v6_pview
        ;
        pto::Shape<1, 1, 1, 8, 256> v540 = pto::Shape<1, 1, 1, 8, 256>();
        // pto: %qr_view_inline3405__phi_v6_pview
        ;
        pto::Stride<8192, 8192, 8192, 1024, 1> v541 = pto::Stride<8192, 8192, 8192, 1024, 1>();
        // pto: %qr_view_inline3405__phi_v6_pview
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND> v542 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, 8, 256>, pto::Stride<8192, 8192, 8192, 1024, 1>, pto::Layout::ND>(v537 + (v538 + v536 * v539 + v416), v540, v541);
        TSTORE(v542, v526);
      } else {
        // pto: %48
        ;
        Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v543 = Tile<TileType::Vec, int8_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v106, v33);
        // pto: %48
        ;
        uint64_t v544 = (uint64_t) v16;
        TASSIGN(v543, v544);
        // pto: %205
        ;
        const int64_t v545 = 0;
        // pto: %205
        ;
        __gm__ int8_t* v546 = PTOAS__GLOBAL_TENSOR_DATA(v57);
        // pto: %205
        ;
        const int64_t v547 = 1;
        // pto: %205
        ;
        const int64_t v548 = 1;
        // pto: %205
        ;
        const int64_t v549 = 1;
        // pto: %205
        ;
        int64_t v550 = v106 * v29;
        // pto: %205
        ;
        int64_t v551 = v549 * v550;
        // pto: %205
        ;
        pto::Shape<1, 1, 1, -1, 256> v552 = pto::Shape<1, 1, 1, -1, 256>(v547, v548, v549, v106, v33);
        // pto: %205
        ;
        pto::Stride<-1, -1, -1, -1, -1> v553 = pto::Stride<-1, -1, -1, -1, -1>(v548 * v551, v551, v550, v29, v30);
        // pto: %205
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v554 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v546 + (v545 + v110 * v29 + v416 * v30), v552, v553);
        TLOAD(v543, v554);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
        // pto: %206
        ;
        int64_t v555 = v107 < v32 ? v32 : v107;
        // pto: %209
        ;
        const int64_t v556 = 0;
        // pto: %209
        ;
        __gm__ int8_t* v557 = PTOAS__GLOBAL_TENSOR_DATA(v83);
        // pto: %209
        ;
        const int64_t v558 = 1;
        // pto: %209
        ;
        const int64_t v559 = 1;
        // pto: %209
        ;
        const int64_t v560 = 1;
        // pto: %209
        ;
        int64_t v561 = v106 * v29;
        // pto: %209
        ;
        int64_t v562 = v560 * v561;
        // pto: %209
        ;
        pto::Shape<1, 1, 1, -1, 256> v563 = pto::Shape<1, 1, 1, -1, 256>(v558, v559, v560, v106, v33);
        // pto: %209
        ;
        pto::Stride<-1, -1, -1, -1, -1> v564 = pto::Stride<-1, -1, -1, -1, -1>(v559 * v562, v562, v561, v29, v30);
        // pto: %209
        ;
        GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v565 = GlobalTensor<int8_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v557 + (v556 + v555 * v29 + v416 * v30), v563, v564);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
        TSTORE(v565, v543);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}