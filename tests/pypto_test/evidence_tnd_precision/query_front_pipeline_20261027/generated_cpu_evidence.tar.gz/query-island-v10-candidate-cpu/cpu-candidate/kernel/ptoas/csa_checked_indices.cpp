#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void csa_checked_indices(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ int32_t* v3, __gm__ int32_t* v4, __gm__ int32_t* v5, __gm__ int32_t* v6, int64_t v7, int64_t v8, int64_t v9, int64_t v10, int64_t v11, int32_t v12, int32_t v13) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c14400_i64
  const int64_t v14 = 14400;
  // pto: %c0_i64
  const int64_t v15 = 0;
  // pto: %c16448_i64
  const int64_t v16 = 16448;
  // pto: %c18496_i64
  const int64_t v17 = 18496;
  // pto: %c8192_i64
  const int64_t v18 = 8192;
  // pto: %c10240_i64
  const int64_t v19 = 10240;
  // pto: %c12288_i64
  const int64_t v20 = 12288;
  // pto: %c12352_i64
  const int64_t v21 = 12352;
  // pto: %c13376_i64
  const int64_t v22 = 13376;
  // pto: %c1_index
  const int64_t v23 = 1;
  // pto: %c512_index
  const int64_t v24 = 512;
  // pto: %c48_index
  const int64_t v25 = 48;
  // pto: %c0_index
  const int64_t v26 = 0;
  // pto: %c4_index
  const int64_t v27 = 4;
  const int32_t v28 = 0;
  // pto: %c2147483647_index
  const int64_t v29 = 2147483647;
  // pto: %c2048_index
  const int64_t v30 = 2048;
  // pto: %c5_i32
  const int32_t v31 = 5;
  // pto: %c8_index
  const int64_t v32 = 8;
  // pto: %c64_index
  const int64_t v33 = 64;
  // pto: %c1_i32
  const int32_t v34 = 1;
  // pto: %cst_21
  const float v35 = 16777216.0f;
  // pto: %c16_index
  const int64_t v36 = 16;
  // pto: %cn1_i32
  const int32_t v37 = -1;
  // pto: %cst_24
  const float v38 = 0.0f;
  // pto: %c192_index
  const int64_t v39 = 192;
  // pto: %c256_index
  const int64_t v40 = 256;
  // pto: %c2_i32
  const int32_t v41 = 2;
  // pto: %c32_index
  const int64_t v42 = 32;
  // pto: %cst_29
  const float v43 = 2097152.0f;
  // pto: %c2_index
  const int64_t v44 = 2;
  // pto: %c1024_index
  const int64_t v45 = 1024;
  // pto: %cmp_block_table__ssa_v0_view
  const int64_t v46 = 1;
  // pto: %cmp_block_table__ssa_v0_view
  const int64_t v47 = 1;
  // pto: %cmp_block_table__ssa_v0_view
  const int64_t v48 = 1;
  // pto: %cmp_block_table__ssa_v0_view
  int64_t v49 = (int64_t) v9;
  // pto: %cmp_block_table__ssa_v0_view
  int64_t v50 = (int64_t) v10;
  // pto: %cmp_block_table__ssa_v0_view
  int64_t v51 = v49 * v50;
  // pto: %cmp_block_table__ssa_v0_view
  int64_t v52 = v48 * v51;
  // pto: %cmp_block_table__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v53 = pto::Shape<1, 1, 1, -1, -1>(v46, v47, v48, v49, (int64_t) v10);
  // pto: %cmp_block_table__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v54 = pto::Stride<-1, -1, -1, -1, -1>(v47 * v52, v52, v51, v50, v23);
  // pto: %cmp_block_table__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v55 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v53, v54);
  // pto: %attention_topk__ssa_v0_view
  const int64_t v56 = 1;
  // pto: %attention_topk__ssa_v0_view
  const int64_t v57 = 1;
  // pto: %attention_topk__ssa_v0_view
  const int64_t v58 = 1;
  // pto: %attention_topk__ssa_v0_view
  int64_t v59 = (int64_t) v8;
  // pto: %attention_topk__ssa_v0_view
  int64_t v60 = v59 * v24;
  // pto: %attention_topk__ssa_v0_view
  int64_t v61 = v58 * v60;
  // pto: %attention_topk__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v62 = pto::Shape<1, 1, 1, -1, -1>(v56, v57, v58, v59, v24);
  // pto: %attention_topk__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v63 = pto::Stride<-1, -1, -1, -1, -1>(v57 * v61, v61, v60, v24, v23);
  // pto: %attention_topk__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v64 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v62, v63);
  // pto: %cmp_sparse_indices_inline5291__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %cmp_sparse_indices_inline5291__ssa_v0_view
  const int64_t v66 = 1;
  // pto: %cmp_sparse_indices_inline5291__ssa_v0_view
  const int64_t v67 = 1;
  // pto: %cmp_sparse_indices_inline5291__ssa_v0_view
  int64_t v68 = (int64_t) v11;
  // pto: %cmp_sparse_indices_inline5291__ssa_v0_view
  int64_t v69 = v68 * v24;
  // pto: %cmp_sparse_indices_inline5291__ssa_v0_view
  int64_t v70 = v67 * v69;
  // pto: %cmp_sparse_indices_inline5291__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v71 = pto::Shape<1, 1, 1, -1, -1>(v65, v66, v67, v68, v24);
  // pto: %cmp_sparse_indices_inline5291__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v72 = pto::Stride<-1, -1, -1, -1, -1>(v66 * v70, v70, v69, v24, v23);
  // pto: %cmp_sparse_indices_inline5291__ssa_v0_view
  GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v73 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v71, v72);
  // pto: %checked_worker_inline5294__ssa_v0
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_S, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  for (int64_t v74 = (int64_t) v12; v74 < v11; v74 += v25) {
    // pto: %t__tile
    ;
    int64_t v75 = (v1)[v74];
    // pto: %c_request_inline5297__tile
    ;
    int32_t v76 = (v2)[v74];
    // pto: %1
    ;
    int64_t v77 = (int64_t) v76;
    // pto: %2, %4, %5
    ;
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    if (v77 >= v26 & v77 < v9) {
      // pto: %6
      ;
      int32_t v78 = (v3)[v77];
      // pto: %7, %8
      ;
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
      if ((int64_t) v78 > v26) {
        // pto: %9
        ;
        int64_t v79 = (int64_t) ((uint64_t) v75 + (uint64_t) v23);
        // pto: %10
        ;
        const int64_t v80 = 1;
        // pto: %10
        ;
        const int64_t v81 = 0;
        // pto: %10
        ;
        int64_t v82 = v79 / v27;
        // pto: %10
        ;
        bool v83 = v79 < v81;
        // pto: %10
        ;
        bool v84 = v27 < v81;
        // pto: %10
        ;
        bool v85 = v83 == v84;
        // pto: %10
        ;
        bool v86 = v79 % v27 != v81 && v83 != v84;
        // pto: %10
        ;
        int64_t v87 = v86 ? v82 - v80 : v82;
        // pto: %11, %12, %13, %14, %15, %16, %17
        ;
        pipe_barrier(PIPE_ALL);
        // pto: %c_vector_done_inline5299__phi_v3
        ;
        int32_t v88;
        if ((v87 >= v26 & v87 <= v29 & v10 > v26) & v10 <= v30) {
          // pto: %c_raw_tile_inline5301__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v89 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
          // pto: %c_raw_tile_inline5301__ssa_v0
          ;
          uint64_t v90 = (uint64_t) v14;
          TASSIGN(v89, v90);
          // pto: %18
          ;
          int64_t v91 = v74 < v26 ? v26 : v74;
          // pto: %attention_topk__ssa_v0_pview
          ;
          __gm__ int32_t* v92 = PTOAS__GLOBAL_TENSOR_DATA(v64);
          // pto: %attention_topk__ssa_v0_pview
          ;
          const int64_t v93 = 0;
          // pto: %attention_topk__ssa_v0_pview
          ;
          const int64_t v94 = 512;
          // pto: %attention_topk__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 1, 512> v95 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %attention_topk__ssa_v0_pview
          ;
          pto::Stride<512, 512, 512, 512, 1> v96 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %attention_topk__ssa_v0_pview
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v97 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v92 + (v93 + v91 * v94), v95, v96);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
          TLOAD(v89, v97);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
          // pto: %c_safe_raw_inline5302__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v98 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
          // pto: %c_safe_raw_inline5302__ssa_v0
          ;
          uint64_t v99 = (uint64_t) v15;
          TASSIGN(v98, v99);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
          pipe_barrier(PIPE_V);
          TMAXS(v98, v89, v28);
          // pto: %c_raw_columns_inline5303__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v100 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
          // pto: %c_raw_columns_inline5303__ssa_v0
          ;
          uint64_t v101 = (uint64_t) v16;
          TASSIGN(v100, v101);
          pipe_barrier(PIPE_V);
          pipe_barrier(PIPE_ALL);
          TSHRS(v100, v98, v31);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          // pto: %c_safe_columns_inline5304__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
          // pto: %c_safe_columns_inline5304__ssa_v0
          ;
          uint64_t v103 = (uint64_t) v17;
          TASSIGN(v102, v103);
          // pto: %19, %20
          ;
          int32_t v104 = (int32_t) ((int64_t) (uint64_t) v10 - (uint64_t) v23);
          pipe_barrier(PIPE_V);
          TMINS(v102, v100, v104);
          // pto: %c_table_tile_inline5305__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v105 = Tile<TileType::Vec, int32_t, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v10);
          // pto: %c_table_tile_inline5305__ssa_v0
          ;
          uint64_t v106 = (uint64_t) v15;
          TASSIGN(v105, v106);
          // pto: %22
          ;
          int64_t v107 = v77 < v26 ? v26 : v77;
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          int64_t v108 = (int64_t) v10;
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          const int64_t v109 = 0;
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          __gm__ int32_t* v110 = PTOAS__GLOBAL_TENSOR_DATA(v55);
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          const int64_t v111 = 1;
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          const int64_t v112 = 1;
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          const int64_t v113 = 1;
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          int64_t v114 = v23 * v108;
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          int64_t v115 = v113 * v114;
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 1, -1> v116 = pto::Shape<1, 1, 1, 1, -1>(v111, v112, v113, v23, (int64_t) v10);
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v117 = pto::Stride<-1, -1, -1, -1, -1>(v112 * v115, v115, v114, v108, v23);
          // pto: %cmp_block_table__ssa_v0_pview
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v118 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v110 + (v109 + v107 * v108 + v26 * v23), v116, v117);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
          TLOAD(v105, v118);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          // pto: %t__tmp_v802
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v119 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
          // pto: %t__tmp_v802
          ;
          uint64_t v120 = (uint64_t) v18;
          TASSIGN(v119, v120);
          // pto: %c_page_tile_inline5306__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v121 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
          // pto: %c_page_tile_inline5306__ssa_v0
          ;
          uint64_t v122 = (uint64_t) v19;
          TASSIGN(v121, v122);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
          TGATHER(v121, v105, v102, v119);
          // pto: %c_pages_f32_inline5307__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v123 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
          // pto: %c_pages_f32_inline5307__ssa_v0
          ;
          uint64_t v124 = (uint64_t) v15;
          TASSIGN(v123, v124);
          pipe_barrier(PIPE_V);
          RoundMode v125 = RoundMode::CAST_ROUND;
          SaturationMode v126 = SaturationMode::ON;
          TCVT(v123, v121, v125, v126);
          // pto: %t__tmp_v803
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v127 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
          // pto: %t__tmp_v803
          ;
          uint64_t v128 = (uint64_t) v15;
          TASSIGN(v127, v128);
          // pto: %t__tmp_v804
          ;
          Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v129 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v33);
          // pto: %t__tmp_v804
          ;
          uint64_t v130 = (uint64_t) v17;
          TASSIGN(v129, v130);
          // pto: %c_max_pages_inline5308__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v131 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v32, v23);
          // pto: %c_max_pages_inline5308__ssa_v0
          ;
          uint64_t v132 = (uint64_t) v18;
          TASSIGN(v131, v132);
          pipe_barrier(PIPE_V);
          TROWMAX(v131, v127, v129);
          set_flag(PIPE_V, PIPE_S, EVENT_ID0);
          wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
          // pto: %c_pages_safe_inline5309__rv_v2
          ;
          int32_t v133;
          v133 = v34;
          for (int64_t v134 = v26; v134 < v32; v134 += v23) {
            // pto: %t__tmp_v805
            ;
            float v135 = v131.GetValue(v134);
            // pto: %25
            ;
            bool v136 = v35 != v35 || v135 != v135;
            // pto: %25
            ;
            bool v137 = v35 == v35 && v135 == v135;
            // pto: %25
            ;
            bool v138 = v137 && v35 <= v135;
            // pto: %c_pages_safe_inline5309__phi_v4
            ;
            int32_t v139 = v138 ? v28 : v133;
            v133 = v139;
          };
          set_flag(PIPE_S, PIPE_V, EVENT_ID1);
          set_flag(PIPE_S, PIPE_V, EVENT_ID0);
          // pto: %26
          ;
          int64_t v140 = (int64_t) v133;
          // pto: %27
          ;
          bool v141 = v140 > v26;
          wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
          // pto: %c_vector_done_inline5299__phi_v2
          ;
          if (v141) {
            // pto: %scratch_inline5549__ssa_v0
            ;
            Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v142 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v36);
            // pto: %scratch_inline5549__ssa_v0
            ;
            uint64_t v143 = (uint64_t) v20;
            TASSIGN(v142, v143);
            // pto: %missing_inline5550__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v144 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %missing_inline5550__ssa_v0
            ;
            uint64_t v145 = (uint64_t) v15;
            TASSIGN(v144, v145);
            pipe_barrier(PIPE_V);
            TEXPANDS(v144, v37);
            // pto: %t__tmp_v806
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v146 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v806
            ;
            uint64_t v147 = (uint64_t) v17;
            TASSIGN(v146, v147);
            RoundMode v148 = RoundMode::CAST_ROUND;
            SaturationMode v149 = SaturationMode::ON;
            TCVT(v146, v89, v148, v149);
            // pto: %t__tmp_v807
            ;
            Tile<TileType::Vec, uint8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v150 = Tile<TileType::Vec, uint8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v33);
            // pto: %t__tmp_v807
            ;
            uint64_t v151 = (uint64_t) v18;
            TASSIGN(v150, v151);
            pipe_barrier(PIPE_V);
            CmpMode v152 = CmpMode::GE;
            TCMPS(v150, v146, v38, v152);
            // pto: %checked_inline5551__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v153 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %checked_inline5551__ssa_v0
            ;
            uint64_t v154 = (uint64_t) v17;
            TASSIGN(v153, v154);
            pipe_barrier(PIPE_V);
            TSEL(v153, v150, v89, v144, v142);
            // pto: %t__tmp_v808
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v155 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v808
            ;
            uint64_t v156 = (uint64_t) v18;
            TASSIGN(v155, v156);
            pipe_barrier(PIPE_V);
            TMAXS(v155, v89, v28);
            // pto: %t__tmp_v809
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v809
            ;
            uint64_t v158 = (uint64_t) v18;
            TASSIGN(v157, v158);
            // pto: %29, %28
            ;
            int32_t v159 = (int32_t) ((uint32_t) v28 - (uint32_t) ((int32_t) v87));
            pipe_barrier(PIPE_V);
            TADDS(v157, v155, v159);
            // pto: %t__tmp_v810
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v160 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v810
            ;
            uint64_t v161 = (uint64_t) v18;
            TASSIGN(v160, v161);
            pipe_barrier(PIPE_V);
            RoundMode v162 = RoundMode::CAST_ROUND;
            SaturationMode v163 = SaturationMode::ON;
            TCVT(v160, v157, v162, v163);
            // pto: %t__tmp_v811
            ;
            Tile<TileType::Vec, uint8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v164 = Tile<TileType::Vec, uint8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v33);
            // pto: %t__tmp_v811
            ;
            uint64_t v165 = (uint64_t) v18;
            TASSIGN(v164, v165);
            pipe_barrier(PIPE_V);
            CmpMode v166 = CmpMode::LT;
            TCMPS(v164, v160, v38, v166);
            // pto: %checked_v1_inline5552__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v167 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %checked_v1_inline5552__ssa_v0
            ;
            uint64_t v168 = (uint64_t) v17;
            TASSIGN(v167, v168);
            pipe_barrier(PIPE_V);
            TSEL(v167, v164, v153, v144, v142);
            // pto: %t__tmp_v812
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v169 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v812
            ;
            uint64_t v170 = (uint64_t) v16;
            TASSIGN(v169, v170);
            // pto: %33, %32
            ;
            int32_t v171 = (int32_t) ((uint32_t) v28 - (uint32_t) ((int32_t) v10));
            TADDS(v169, v100, v171);
            // pto: %t__tmp_v813
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v172 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v813
            ;
            uint64_t v173 = (uint64_t) v16;
            TASSIGN(v172, v173);
            pipe_barrier(PIPE_V);
            RoundMode v174 = RoundMode::CAST_ROUND;
            SaturationMode v175 = SaturationMode::ON;
            TCVT(v172, v169, v174, v175);
            // pto: %t__tmp_v814
            ;
            Tile<TileType::Vec, uint8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v176 = Tile<TileType::Vec, uint8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v33);
            // pto: %t__tmp_v814
            ;
            uint64_t v177 = (uint64_t) v18;
            TASSIGN(v176, v177);
            pipe_barrier(PIPE_V);
            CmpMode v178 = CmpMode::LT;
            TCMPS(v176, v172, v38, v178);
            // pto: %checked_v2_inline5553__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v179 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %checked_v2_inline5553__ssa_v0
            ;
            uint64_t v180 = (uint64_t) v16;
            TASSIGN(v179, v180);
            pipe_barrier(PIPE_V);
            TSEL(v179, v176, v167, v144, v142);
            // pto: %t__tmp_v815
            ;
            Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v181 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v815
            ;
            uint64_t v182 = (uint64_t) v17;
            TASSIGN(v181, v182);
            pipe_barrier(PIPE_V);
            RoundMode v183 = RoundMode::CAST_ROUND;
            SaturationMode v184 = SaturationMode::ON;
            TCVT(v181, v121, v183, v184);
            // pto: %t__tmp_v816
            ;
            Tile<TileType::Vec, uint8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v185 = Tile<TileType::Vec, uint8_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v33);
            // pto: %t__tmp_v816
            ;
            uint64_t v186 = (uint64_t) v17;
            TASSIGN(v185, v186);
            pipe_barrier(PIPE_V);
            CmpMode v187 = CmpMode::GE;
            TCMPS(v185, v181, v38, v187);
            // pto: %checked_v3_inline5554__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v188 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %checked_v3_inline5554__ssa_v0
            ;
            uint64_t v189 = (uint64_t) v15;
            TASSIGN(v188, v189);
            pipe_barrier(PIPE_V);
            TSEL(v188, v185, v179, v144, v142);
            // pto: %safe_raw_inline5555__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v190 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %safe_raw_inline5555__ssa_v0
            ;
            uint64_t v191 = (uint64_t) v14;
            TASSIGN(v190, v191);
            TMAXS(v190, v89, v28);
            // pto: %t__tmp_v817
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v817
            ;
            uint64_t v193 = (uint64_t) v16;
            TASSIGN(v192, v193);
            pipe_barrier(PIPE_V);
            TMAXS(v192, v121, v28);
            // pto: %t__tmp_v818
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v194 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v818
            ;
            uint64_t v195 = (uint64_t) v16;
            TASSIGN(v194, v195);
            pipe_barrier(PIPE_V);
            TSHLS(v194, v192, v31);
            // pto: %t__tmp_v819
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v196 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v819
            ;
            uint64_t v197 = (uint64_t) v17;
            TASSIGN(v196, v197);
            TSHRS(v196, v190, v31);
            // pto: %t__tmp_v820
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v198 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v820
            ;
            uint64_t v199 = (uint64_t) v17;
            TASSIGN(v198, v199);
            pipe_barrier(PIPE_V);
            TSHLS(v198, v196, v31);
            // pto: %t__tmp_v821
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v200 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v821
            ;
            uint64_t v201 = (uint64_t) v14;
            TASSIGN(v200, v201);
            pipe_barrier(PIPE_V);
            TSUB(v200, v190, v198);
            // pto: %physical_inline5556__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v202 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %physical_inline5556__ssa_v0
            ;
            uint64_t v203 = (uint64_t) v14;
            TASSIGN(v202, v203);
            pipe_barrier(PIPE_V);
            TADD(v202, v194, v200);
            // pto: %t__ci_tmp_v0
            ;
            Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v204 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %t__ci_tmp_v0
            ;
            uint64_t v205 = (uint64_t) v17;
            TASSIGN(v204, v205);
            // pto: %t__tmp_v822
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v206 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %t__tmp_v822
            ;
            uint64_t v207 = (uint64_t) v16;
            TASSIGN(v206, v207);
            // pto: %ci_tmp_view
            ;
            Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v208;
            TRESHAPE(v208, v204);
            // pto: %ci_dst_view
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, 1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v209;
            TRESHAPE(v209, v206);
            pipe_barrier(PIPE_V);
            TCI<Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, 1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v209, v28, v208);
            // pto: %pair_columns_inline5557__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v210 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %pair_columns_inline5557__ssa_v0
            ;
            uint64_t v211 = (uint64_t) v16;
            TASSIGN(v210, v211);
            pipe_barrier(PIPE_V);
            TMULS(v210, v206, v41);
            // pto: %odd_columns_inline5558__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v212 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %odd_columns_inline5558__ssa_v0
            ;
            uint64_t v213 = (uint64_t) v17;
            TASSIGN(v212, v213);
            pipe_barrier(PIPE_V);
            TADDS(v212, v210, v34);
            // pto: %gather_tmp_inline5559__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v214 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %gather_tmp_inline5559__ssa_v0
            ;
            uint64_t v215 = (uint64_t) v18;
            TASSIGN(v214, v215);
            // pto: %first_inline5560__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v216 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %first_inline5560__ssa_v0
            ;
            uint64_t v217 = (uint64_t) v19;
            TASSIGN(v216, v217);
            TGATHER(v216, v188, v210, v214);
            // pto: %second_inline5561__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %second_inline5561__ssa_v0
            ;
            uint64_t v219 = (uint64_t) v21;
            TASSIGN(v218, v219);
            pipe_barrier(PIPE_V);
            TGATHER(v218, v188, v212, v214);
            // pto: %first_row_inline5562__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v220 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %first_row_inline5562__ssa_v0
            ;
            uint64_t v221 = (uint64_t) v22;
            TASSIGN(v220, v221);
            pipe_barrier(PIPE_V);
            TGATHER(v220, v202, v210, v214);
            // pto: %second_row_inline5563__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v222 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %second_row_inline5563__ssa_v0
            ;
            uint64_t v223 = (uint64_t) v16;
            TASSIGN(v222, v223);
            pipe_barrier(PIPE_V);
            TGATHER(v222, v202, v212, v214);
            // pto: %difference_inline5564__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v224 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %difference_inline5564__ssa_v0
            ;
            uint64_t v225 = (uint64_t) v14;
            TASSIGN(v224, v225);
            pipe_barrier(PIPE_V);
            TSUB(v224, v220, v222);
            // pto: %zero_inline5565__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v226 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %zero_inline5565__ssa_v0
            ;
            uint64_t v227 = (uint64_t) v16;
            TASSIGN(v226, v227);
            pipe_barrier(PIPE_V);
            TEXPANDS(v226, v28);
            // pto: %swap_inline5566__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v228 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %swap_inline5566__ssa_v0
            ;
            uint64_t v229 = (uint64_t) v17;
            TASSIGN(v228, v229);
            TEXPANDS(v228, v34);
            // pto: %t__tmp_v823
            ;
            Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v230 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %t__tmp_v823
            ;
            uint64_t v231 = (uint64_t) v18;
            TASSIGN(v230, v231);
            RoundMode v232 = RoundMode::CAST_ROUND;
            SaturationMode v233 = SaturationMode::ON;
            TCVT(v230, v216, v232, v233);
            // pto: %t__tmp_v824
            ;
            Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v42);
            // pto: %t__tmp_v824
            ;
            uint64_t v235 = (uint64_t) v18;
            TASSIGN(v234, v235);
            pipe_barrier(PIPE_V);
            CmpMode v236 = CmpMode::GE;
            TCMPS(v234, v230, v38, v236);
            // pto: %swap_v1_inline5567__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v237 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %swap_v1_inline5567__ssa_v0
            ;
            uint64_t v238 = (uint64_t) v17;
            TASSIGN(v237, v238);
            pipe_barrier(PIPE_V);
            TSEL(v237, v234, v228, v226, v142);
            // pto: %t__tmp_v825
            ;
            Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v239 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %t__tmp_v825
            ;
            uint64_t v240 = (uint64_t) v18;
            TASSIGN(v239, v240);
            pipe_barrier(PIPE_V);
            RoundMode v241 = RoundMode::CAST_ROUND;
            SaturationMode v242 = SaturationMode::ON;
            TCVT(v239, v218, v241, v242);
            // pto: %t__tmp_v826
            ;
            Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v42);
            // pto: %t__tmp_v826
            ;
            uint64_t v244 = (uint64_t) v18;
            TASSIGN(v243, v244);
            pipe_barrier(PIPE_V);
            CmpMode v245 = CmpMode::GE;
            TCMPS(v243, v239, v38, v245);
            // pto: %swap_v2_inline5568__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v246 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %swap_v2_inline5568__ssa_v0
            ;
            uint64_t v247 = (uint64_t) v17;
            TASSIGN(v246, v247);
            pipe_barrier(PIPE_V);
            TSEL(v246, v243, v237, v226, v142);
            // pto: %t__tmp_v827
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v248 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %t__tmp_v827
            ;
            uint64_t v249 = (uint64_t) v18;
            TASSIGN(v248, v249);
            // pto: %38, %39
            ;
            int32_t v250 = (int32_t) ((int64_t) (uint64_t) v23 - (uint64_t) v87);
            pipe_barrier(PIPE_V);
            TADDS(v248, v216, v250);
            // pto: %t__tmp_v828
            ;
            Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v251 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %t__tmp_v828
            ;
            uint64_t v252 = (uint64_t) v18;
            TASSIGN(v251, v252);
            pipe_barrier(PIPE_V);
            RoundMode v253 = RoundMode::CAST_ROUND;
            SaturationMode v254 = SaturationMode::ON;
            TCVT(v251, v248, v253, v254);
            // pto: %t__tmp_v829
            ;
            Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v42);
            // pto: %t__tmp_v829
            ;
            uint64_t v256 = (uint64_t) v18;
            TASSIGN(v255, v256);
            pipe_barrier(PIPE_V);
            CmpMode v257 = CmpMode::LT;
            TCMPS(v255, v251, v38, v257);
            // pto: %swap_v3_inline5569__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v258 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %swap_v3_inline5569__ssa_v0
            ;
            uint64_t v259 = (uint64_t) v17;
            TASSIGN(v258, v259);
            pipe_barrier(PIPE_V);
            TSEL(v258, v255, v246, v226, v142);
            // pto: %t__tmp_v830
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v260 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %t__tmp_v830
            ;
            uint64_t v261 = (uint64_t) v18;
            TASSIGN(v260, v261);
            pipe_barrier(PIPE_V);
            TADDS(v260, v218, v250);
            // pto: %t__tmp_v831
            ;
            Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v262 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %t__tmp_v831
            ;
            uint64_t v263 = (uint64_t) v18;
            TASSIGN(v262, v263);
            pipe_barrier(PIPE_V);
            RoundMode v264 = RoundMode::CAST_ROUND;
            SaturationMode v265 = SaturationMode::ON;
            TCVT(v262, v260, v264, v265);
            // pto: %t__tmp_v832
            ;
            Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v266 = Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v42);
            // pto: %t__tmp_v832
            ;
            uint64_t v267 = (uint64_t) v18;
            TASSIGN(v266, v267);
            pipe_barrier(PIPE_V);
            CmpMode v268 = CmpMode::LT;
            TCMPS(v266, v262, v38, v268);
            // pto: %swap_v4_inline5570__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %swap_v4_inline5570__ssa_v0
            ;
            uint64_t v270 = (uint64_t) v17;
            TASSIGN(v269, v270);
            pipe_barrier(PIPE_V);
            TSEL(v269, v266, v258, v226, v142);
            // pto: %t__tmp_v833
            ;
            Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v271 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %t__tmp_v833
            ;
            uint64_t v272 = (uint64_t) v18;
            TASSIGN(v271, v272);
            pipe_barrier(PIPE_V);
            RoundMode v273 = RoundMode::CAST_ROUND;
            SaturationMode v274 = SaturationMode::ON;
            TCVT(v271, v224, v273, v274);
            // pto: %t__tmp_v834
            ;
            Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275 = Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v42);
            // pto: %t__tmp_v834
            ;
            uint64_t v276 = (uint64_t) v18;
            TASSIGN(v275, v276);
            pipe_barrier(PIPE_V);
            CmpMode v277 = CmpMode::GT;
            TCMPS(v275, v271, v38, v277);
            // pto: %swap_v5_inline5571__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v278 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %swap_v5_inline5571__ssa_v0
            ;
            uint64_t v279 = (uint64_t) v17;
            TASSIGN(v278, v279);
            pipe_barrier(PIPE_V);
            TSEL(v278, v275, v269, v226, v142);
            // pto: %t__tmp_v835
            ;
            Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v280 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %t__tmp_v835
            ;
            uint64_t v281 = (uint64_t) v14;
            TASSIGN(v280, v281);
            RoundMode v282 = RoundMode::CAST_ROUND;
            SaturationMode v283 = SaturationMode::ON;
            TCVT(v280, v224, v282, v283);
            // pto: %t__tmp_v836
            ;
            Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v284 = Tile<TileType::Vec, uint8_t, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v42);
            // pto: %t__tmp_v836
            ;
            uint64_t v285 = (uint64_t) v14;
            TASSIGN(v284, v285);
            pipe_barrier(PIPE_V);
            CmpMode v286 = CmpMode::LE;
            TCMPS(v284, v280, v43, v286);
            // pto: %swap_v6_inline5572__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, int32_t, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v40);
            // pto: %swap_v6_inline5572__ssa_v0
            ;
            uint64_t v288 = (uint64_t) v19;
            TASSIGN(v287, v288);
            pipe_barrier(PIPE_V);
            TSEL(v287, v284, v278, v226, v142);
            // pto: %output_columns_inline5573__ci_tmp_v1
            ;
            Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v39);
            // pto: %output_columns_inline5573__ci_tmp_v1
            ;
            uint64_t v290 = (uint64_t) v16;
            TASSIGN(v289, v290);
            // pto: %output_columns_inline5573__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %output_columns_inline5573__ssa_v0
            ;
            uint64_t v292 = (uint64_t) v14;
            TASSIGN(v291, v292);
            // pto: %44
            ;
            Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v293;
            TRESHAPE(v293, v289);
            // pto: %45
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v294;
            TRESHAPE(v294, v291);
            pipe_barrier(PIPE_V);
            TCI<Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v294, v28, v293);
            // pto: %pair_ids_inline5574__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %pair_ids_inline5574__ssa_v0
            ;
            uint64_t v296 = (uint64_t) v16;
            TASSIGN(v295, v296);
            pipe_barrier(PIPE_V);
            TSHRS(v295, v291, v34);
            // pto: %output_tmp_inline5575__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %output_tmp_inline5575__ssa_v0
            ;
            uint64_t v298 = (uint64_t) v17;
            TASSIGN(v297, v298);
            // pto: %duplicate_swap_inline5576__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %duplicate_swap_inline5576__ssa_v0
            ;
            uint64_t v300 = (uint64_t) v18;
            TASSIGN(v299, v300);
            pipe_barrier(PIPE_V);
            TGATHER(v299, v287, v295, v297);
            // pto: %t__tmp_v837
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v837
            ;
            uint64_t v302 = (uint64_t) v16;
            TASSIGN(v301, v302);
            pipe_barrier(PIPE_V);
            TEXPANDS(v301, v34);
            // pto: %t__tmp_v838
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v838
            ;
            uint64_t v304 = (uint64_t) v19;
            TASSIGN(v303, v304);
            TSHRS(v303, v291, v34);
            // pto: %t__tmp_v839
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v839
            ;
            uint64_t v306 = (uint64_t) v19;
            TASSIGN(v305, v306);
            pipe_barrier(PIPE_V);
            TSHLS(v305, v303, v34);
            // pto: %t__tmp_v840
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v840
            ;
            uint64_t v308 = (uint64_t) v19;
            TASSIGN(v307, v308);
            pipe_barrier(PIPE_V);
            TSUB(v307, v291, v305);
            // pto: %t__tmp_v841
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v841
            ;
            uint64_t v310 = (uint64_t) v19;
            TASSIGN(v309, v310);
            pipe_barrier(PIPE_V);
            TMULS(v309, v307, v41);
            // pto: %offset_inline5577__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %offset_inline5577__ssa_v0
            ;
            uint64_t v312 = (uint64_t) v16;
            TASSIGN(v311, v312);
            pipe_barrier(PIPE_V);
            TSUB(v311, v301, v309);
            // pto: %t__tmp_v842
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %t__tmp_v842
            ;
            uint64_t v314 = (uint64_t) v16;
            TASSIGN(v313, v314);
            pipe_barrier(PIPE_V);
            TMUL(v313, v299, v311);
            // pto: %order_inline5578__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %order_inline5578__ssa_v0
            ;
            uint64_t v316 = (uint64_t) v14;
            TASSIGN(v315, v316);
            pipe_barrier(PIPE_V);
            TADD(v315, v291, v313);
            // pto: %c_reordered_inline5311__ssa_v0
            ;
            Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
            // pto: %c_reordered_inline5311__ssa_v0
            ;
            uint64_t v318 = (uint64_t) v16;
            TASSIGN(v317, v318);
            pipe_barrier(PIPE_V);
            TGATHER(v317, v188, v315, v297);
            set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
            // pto: %cmp_sparse_indices_inline5291__ssa_v0_pview
            ;
            __gm__ int32_t* v319 = PTOAS__GLOBAL_TENSOR_DATA(v73);
            // pto: %cmp_sparse_indices_inline5291__ssa_v0_pview
            ;
            const int64_t v320 = 0;
            // pto: %cmp_sparse_indices_inline5291__ssa_v0_pview
            ;
            const int64_t v321 = 512;
            // pto: %cmp_sparse_indices_inline5291__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 1, 512> v322 = pto::Shape<1, 1, 1, 1, 512>();
            // pto: %cmp_sparse_indices_inline5291__ssa_v0_pview
            ;
            pto::Stride<512, 512, 512, 512, 1> v323 = pto::Stride<512, 512, 512, 512, 1>();
            // pto: %cmp_sparse_indices_inline5291__ssa_v0_pview
            ;
            GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v324 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v319 + (v320 + v91 * v321), v322, v323);
            wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
            TSTORE(v324, v317);
          };
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
          v88 = (int32_t) v141;
        } else {
          v88 = v28;
        };
        // pto: %47
        ;
        int64_t v325 = (int64_t) v88;
        // pto: %48
        ;
        if (v325 == v26) {
          // pto: %c_scalar_output_inline5312__ssa_v0
          ;
          Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v326 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
          // pto: %c_scalar_output_inline5312__ssa_v0
          ;
          uint64_t v327 = (uint64_t) v15;
          TASSIGN(v326, v327);
          pipe_barrier(PIPE_V);
          pipe_barrier(PIPE_ALL);
          TEXPANDS(v326, v37);
          set_flag(PIPE_V, PIPE_S, EVENT_ID1);
          set_flag(PIPE_V, PIPE_S, EVENT_ID2);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
          wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
          wait_flag(PIPE_V, PIPE_S, EVENT_ID2);
          for (int64_t v328 = v26; v328 < v40; v328 += v23) {
            // pto: %49
            ;
            int64_t v329 = (int64_t) ((uint64_t) v328 * (uint64_t) v44);
            // pto: %50
            ;
            int64_t v330 = (int64_t) ((uint64_t) v74 * (uint64_t) v24);
            // pto: %51, %c_first_inline5315__tile
            ;
            int32_t v331 = (v5)[(int64_t) ((uint64_t) v330 + (uint64_t) v329)];
            // pto: %52
            ;
            int64_t v332 = (int64_t) ((uint64_t) v329 + (uint64_t) v23);
            // pto: %54, %c_second_inline5316__tile
            ;
            int32_t v333 = (v5)[(int64_t) ((uint64_t) v330 + (uint64_t) v332)];
            // pto: %55
            ;
            int64_t v334 = (int64_t) v331;
            // pto: %56, %58, %59
            ;
            // pto: %c_first_page_inline5317__phi_v3
            ;
            int32_t v335;
            if (v334 >= v26 & v334 < v87) {
              // pto: %61
              ;
              const int64_t v336 = 1;
              // pto: %61
              ;
              const int64_t v337 = 0;
              // pto: %61
              ;
              int64_t v338 = v334 / v42;
              // pto: %61
              ;
              bool v339 = v334 < v337;
              // pto: %61
              ;
              bool v340 = v42 < v337;
              // pto: %61
              ;
              bool v341 = v339 == v340;
              // pto: %61
              ;
              bool v342 = v334 % v42 != v337 && v339 != v340;
              // pto: %61
              ;
              int64_t v343 = v342 ? v338 - v336 : v338;
              // pto: %62
              ;
              // pto: %c_first_page_inline5317__phi_v2
              ;
              int32_t v344;
              if (v343 < v10) {
                // pto: %64, %65, %c_first_page_inline5317__tile
                ;
                int32_t v345 = (v4)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v77 * (uint64_t) v10) + (uint64_t) v343)];
                v344 = v345;
              } else {
                v344 = v37;
              };
              v335 = v344;
            } else {
              v335 = v37;
            };
            // pto: %66
            ;
            int64_t v346 = (int64_t) v333;
            // pto: %67, %69, %70
            ;
            // pto: %c_second_page_inline5318__phi_v3
            ;
            int32_t v347;
            if (v346 >= v26 & v346 < v87) {
              // pto: %72
              ;
              const int64_t v348 = 1;
              // pto: %72
              ;
              const int64_t v349 = 0;
              // pto: %72
              ;
              int64_t v350 = v346 / v42;
              // pto: %72
              ;
              bool v351 = v346 < v349;
              // pto: %72
              ;
              bool v352 = v42 < v349;
              // pto: %72
              ;
              bool v353 = v351 == v352;
              // pto: %72
              ;
              bool v354 = v346 % v42 != v349 && v351 != v352;
              // pto: %72
              ;
              int64_t v355 = v354 ? v350 - v348 : v350;
              // pto: %73
              ;
              // pto: %c_second_page_inline5318__phi_v2
              ;
              int32_t v356;
              if (v355 < v10) {
                // pto: %75, %76, %c_second_page_inline5318__tile
                ;
                int32_t v357 = (v4)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v77 * (uint64_t) v10) + (uint64_t) v355)];
                v356 = v357;
              } else {
                v356 = v37;
              };
              v347 = v356;
            } else {
              v347 = v37;
            };
            // pto: %77
            ;
            int64_t v358 = (int64_t) v335;
            // pto: %78, %c_first_inline5315__phi_v2
            ;
            int32_t v359 = v358 < v26 ? v37 : v331;
            // pto: %79
            ;
            int64_t v360 = (int64_t) v347;
            // pto: %80, %c_second_inline5316__phi_v2
            ;
            int32_t v361 = v360 < v26 ? v37 : v333;
            // pto: %81
            ;
            int64_t v362 = (int64_t) v359;
            // pto: %82
            ;
            int64_t v363 = (int64_t) v361;
            // pto: %84, %86, %87
            ;
            // pto: %c_swap_inline5323__phi_v5
            ;
            int32_t v364;
            if (v362 >= v26 & v363 >= v26) {
              // pto: %88, %89, %90, %91, %92
              ;
              // pto: %c_swap_inline5323__phi_v4
              ;
              int32_t v365;
              if ((int64_t) ((uint64_t) v362 + (uint64_t) v23) < v87 & (int64_t) ((uint64_t) v363 + (uint64_t) v23) < v87) {
                // pto: %77
                ;
                int64_t v366 = (int64_t) v335;
                // pto: %95
                ;
                int64_t v367 = v362 % v42;
                // pto: %96, %97, %98
                ;
                int64_t v368 = v367 < v26 ? (int64_t) ((uint64_t) v367 + (uint64_t) v42) : v367;
                // pto: %94, %99
                ;
                int64_t v369 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v366 * (uint64_t) v42) + (uint64_t) v368);
                // pto: %79
                ;
                int64_t v370 = (int64_t) v347;
                // pto: %102
                ;
                int64_t v371 = v363 % v42;
                // pto: %103, %104, %105
                ;
                int64_t v372 = v371 < v26 ? (int64_t) ((uint64_t) v371 + (uint64_t) v42) : v371;
                // pto: %101, %106
                ;
                int64_t v373 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v370 * (uint64_t) v42) + (uint64_t) v372);
                // pto: %107
                ;
                // pto: %c_swap_inline5323__phi_v3
                ;
                int32_t v374;
                if (v373 < v369) {
                  // pto: %108, %109, %110, %111, %c_swap_inline5323__phi_v2
                  ;
                  v374 = (int32_t) ((int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v369 - (uint64_t) v373) - (uint64_t) v23) * (uint64_t) v45) < v29);
                } else {
                  v374 = v28;
                };
                v365 = v374;
              } else {
                v365 = v28;
              };
              v364 = v365;
            } else {
              v364 = v28;
            };
            // pto: %112
            ;
            int64_t v375 = (int64_t) v364;
            // pto: %113
            ;
            if (v375 > v26) {
              v326.SetValue(v329, v361);
              v326.SetValue(v332, v359);
            } else {
              v326.SetValue(v329, v359);
              v326.SetValue(v332, v361);
            };
          };
          set_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
          set_flag(PIPE_S, PIPE_MTE3, EVENT_ID1);
          // pto: %124
          ;
          int64_t v376 = v74 < v26 ? v26 : v74;
          // pto: %125
          ;
          __gm__ int32_t* v377 = PTOAS__GLOBAL_TENSOR_DATA(v73);
          // pto: %125
          ;
          const int64_t v378 = 0;
          // pto: %125
          ;
          const int64_t v379 = 512;
          // pto: %125
          ;
          pto::Shape<1, 1, 1, 1, 512> v380 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %125
          ;
          pto::Stride<512, 512, 512, 512, 1> v381 = pto::Stride<512, 512, 512, 512, 1>();
          // pto: %125
          ;
          GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v382 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v377 + (v378 + v376 * v379), v380, v381);
          wait_flag(PIPE_S, PIPE_MTE3, EVENT_ID0);
          wait_flag(PIPE_S, PIPE_MTE3, EVENT_ID1);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
          pipe_barrier(PIPE_MTE3);
          TSTORE(v382, v326);
        };
      } else {
        // pto: %c_inactive_inline5327__ssa_v0
        ;
        Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v383 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
        // pto: %c_inactive_inline5327__ssa_v0
        ;
        uint64_t v384 = (uint64_t) v15;
        TASSIGN(v383, v384);
        pipe_barrier(PIPE_V);
        pipe_barrier(PIPE_ALL);
        TEXPANDS(v383, v37);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        // pto: %126
        ;
        int64_t v385 = v74 < v26 ? v26 : v74;
        // pto: %127
        ;
        __gm__ int32_t* v386 = PTOAS__GLOBAL_TENSOR_DATA(v73);
        // pto: %127
        ;
        const int64_t v387 = 0;
        // pto: %127
        ;
        const int64_t v388 = 512;
        // pto: %127
        ;
        pto::Shape<1, 1, 1, 1, 512> v389 = pto::Shape<1, 1, 1, 1, 512>();
        // pto: %127
        ;
        pto::Stride<512, 512, 512, 512, 1> v390 = pto::Stride<512, 512, 512, 512, 1>();
        // pto: %127
        ;
        GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v391 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v386 + (v387 + v385 * v388), v389, v390);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v391, v383);
      };
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    } else {
      // pto: %c_missing_inline5328__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v392 = Tile<TileType::Vec, int32_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v23, v24);
      // pto: %c_missing_inline5328__ssa_v0
      ;
      uint64_t v393 = (uint64_t) v15;
      TASSIGN(v392, v393);
      pipe_barrier(PIPE_V);
      pipe_barrier(PIPE_ALL);
      TEXPANDS(v392, v37);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      // pto: %128
      ;
      int64_t v394 = v74 < v26 ? v26 : v74;
      // pto: %129
      ;
      __gm__ int32_t* v395 = PTOAS__GLOBAL_TENSOR_DATA(v73);
      // pto: %129
      ;
      const int64_t v396 = 0;
      // pto: %129
      ;
      const int64_t v397 = 512;
      // pto: %129
      ;
      pto::Shape<1, 1, 1, 1, 512> v398 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %129
      ;
      pto::Stride<512, 512, 512, 512, 1> v399 = pto::Stride<512, 512, 512, 512, 1>();
      // pto: %129
      ;
      GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v400 = GlobalTensor<int32_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v395 + (v396 + v394 * v397), v398, v399);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v400, v392);
    };
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}