#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void native_indexer_weights(__gm__ half* v1, __gm__ float* v2, int64_t v3, int64_t v4, int32_t v5, int32_t v6) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %c0_i64
  const int64_t v7 = 0;
  // pto: %c2048_i64
  const int64_t v8 = 2048;
  // pto: %c64_index
  const int64_t v9 = 64;
  // pto: %c1_index
  const int64_t v10 = 1;
  // pto: %c432_index
  const int64_t v11 = 432;
  // pto: %c16_index
  const int64_t v12 = 16;
  // pto: %c0_index
  const int64_t v13 = 0;
  // pto: %indexer_weights__ssa_v1_view
  const int64_t v14 = 1;
  // pto: %indexer_weights__ssa_v1_view
  const int64_t v15 = 1;
  // pto: %indexer_weights__ssa_v1_view
  const int64_t v16 = 1;
  // pto: %indexer_weights__ssa_v1_view
  int64_t v17 = (int64_t) v4;
  // pto: %indexer_weights__ssa_v1_view
  int64_t v18 = v17 * v9;
  // pto: %indexer_weights__ssa_v1_view
  int64_t v19 = v16 * v18;
  // pto: %indexer_weights__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v20 = pto::Shape<1, 1, 1, -1, -1>(v14, v15, v16, v17, v9);
  // pto: %indexer_weights__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v21 = pto::Stride<-1, -1, -1, -1, -1>(v15 * v19, v19, v18, v9, v10);
  // pto: %indexer_weights__ssa_v1_view
  GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v22 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v20, v21);
  // pto: %weights_inline3932__ssa_v0_view
  const int64_t v23 = 1;
  // pto: %weights_inline3932__ssa_v0_view
  const int64_t v24 = 1;
  // pto: %weights_inline3932__ssa_v0_view
  const int64_t v25 = 1;
  // pto: %weights_inline3932__ssa_v0_view
  int64_t v26 = v11 * v9;
  // pto: %weights_inline3932__ssa_v0_view
  int64_t v27 = v25 * v26;
  // pto: %weights_inline3932__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v28 = pto::Shape<1, 1, 1, -1, -1>(v23, v24, v25, v11, v9);
  // pto: %weights_inline3932__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v29 = pto::Stride<-1, -1, -1, -1, -1>(v24 * v27, v27, v26, v9, v10);
  // pto: %weights_inline3932__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v30 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v28, v29);
  // pto: %t__tmp_v251, %0
  int64_t v31 = (int64_t) ((uint64_t) ((int64_t) v5) * (uint64_t) v12);
  // pto: %1
  int64_t v32 = (int64_t) ((uint64_t) v3 - (uint64_t) v31);
  // pto: %2
  int64_t v33 = v32 < v12 ? v32 : v12;
  // pto: %values_inline3936__ssa_v0
  Tile<TileType::Vec, half, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v34 = Tile<TileType::Vec, half, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v33, v9);
  // pto: %values_inline3936__ssa_v0
  uint64_t v35 = (uint64_t) v7;
  TASSIGN(v34, v35);
  // pto: %3
  int64_t v36 = v31 < v13 ? v13 : v31;
  // pto: %indexer_weights__ssa_v1_pview
  const int64_t v37 = 0;
  // pto: %indexer_weights__ssa_v1_pview
  __gm__ half* v38 = PTOAS__GLOBAL_TENSOR_DATA(v22);
  // pto: %indexer_weights__ssa_v1_pview
  const int64_t v39 = 1;
  // pto: %indexer_weights__ssa_v1_pview
  const int64_t v40 = 1;
  // pto: %indexer_weights__ssa_v1_pview
  const int64_t v41 = 1;
  // pto: %indexer_weights__ssa_v1_pview
  int64_t v42 = v33 * v9;
  // pto: %indexer_weights__ssa_v1_pview
  int64_t v43 = v41 * v42;
  // pto: %indexer_weights__ssa_v1_pview
  pto::Shape<1, 1, 1, -1, 64> v44 = pto::Shape<1, 1, 1, -1, 64>(v39, v40, v41, v33, v9);
  // pto: %indexer_weights__ssa_v1_pview
  pto::Stride<-1, -1, -1, -1, -1> v45 = pto::Stride<-1, -1, -1, -1, -1>(v40 * v43, v43, v42, v9, v10);
  // pto: %indexer_weights__ssa_v1_pview
  GlobalTensor<half, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v46 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v38 + (v37 + v36 * v9 + v13 * v10), v44, v45);
  TLOAD(v34, v46);
  set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  // pto: %t__tmp_v252
  Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v47 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v33, v9);
  // pto: %t__tmp_v252
  uint64_t v48 = (uint64_t) v8;
  TASSIGN(v47, v48);
  wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
  RoundMode v49 = RoundMode::CAST_ROUND;
  SaturationMode v50 = SaturationMode::ON;
  TCVT(v47, v34, v49, v50);
  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  // pto: %weights_inline3932__ssa_v0_pview
  const int64_t v51 = 0;
  // pto: %weights_inline3932__ssa_v0_pview
  __gm__ float* v52 = PTOAS__GLOBAL_TENSOR_DATA(v30);
  // pto: %weights_inline3932__ssa_v0_pview
  const int64_t v53 = 1;
  // pto: %weights_inline3932__ssa_v0_pview
  const int64_t v54 = 1;
  // pto: %weights_inline3932__ssa_v0_pview
  const int64_t v55 = 1;
  // pto: %weights_inline3932__ssa_v0_pview
  int64_t v56 = v33 * v9;
  // pto: %weights_inline3932__ssa_v0_pview
  int64_t v57 = v55 * v56;
  // pto: %weights_inline3932__ssa_v0_pview
  pto::Shape<1, 1, 1, -1, 64> v58 = pto::Shape<1, 1, 1, -1, 64>(v53, v54, v55, v33, v9);
  // pto: %weights_inline3932__ssa_v0_pview
  pto::Stride<-1, -1, -1, -1, -1> v59 = pto::Stride<-1, -1, -1, -1, -1>(v54 * v57, v57, v56, v9, v10);
  // pto: %weights_inline3932__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v60 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v52 + (v51 + v36 * v9 + v13 * v10), v58, v59);
  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
  TSTORE(v60, v47);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}