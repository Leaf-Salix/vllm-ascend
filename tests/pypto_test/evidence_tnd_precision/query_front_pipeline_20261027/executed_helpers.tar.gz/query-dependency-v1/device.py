from pathlib import Path
import hashlib,json,runpy,sys
here=Path(__file__).resolve().parent
assert all(hashlib.sha256((here/k).read_bytes()).hexdigest()==v for k,v in json.loads((here/'manifest.json').read_text()).items())
parent=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-sdk-alignment-20261026-codex/query-island-v14')
assert hashlib.sha256((parent/'probe_perf.py').read_bytes()).hexdigest()=='7f9b6b5aefe61499026f1626fa007bf514f17a38a644d271fc674d9a9a2255ef'
sys.path.insert(0,str(parent))
runpy.run_path(str(parent/'sdk_bind.py'),run_name='__sdk_preflight__')
text=(here/'derived_probe.py').read_text()
assert hashlib.sha256(text.encode()).hexdigest()=='c5d5490d055911503a9496409f2288b89b0860b19e6d402bc7a15ad28fdf8875'
exec(compile(text,str(parent/'probe_perf.py'),'exec'),{'__name__':'__main__','__file__':str(parent/'probe_perf.py'),'PARENT_SHA':'7f9b6b5aefe61499026f1626fa007bf514f17a38a644d271fc674d9a9a2255ef','DERIVED_SHA':'c5d5490d055911503a9496409f2288b89b0860b19e6d402bc7a15ad28fdf8875'})
