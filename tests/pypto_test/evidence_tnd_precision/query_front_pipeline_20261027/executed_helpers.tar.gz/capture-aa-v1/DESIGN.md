# 完全相同实现的A/A计时控制

HC pack正向0.74%较快、逆捕获0.89%较慢，先核验测量地板。双臂都是原Direct，只有不同Python注册/fixture，叶子源码和数学完全相同；不含unroll。双CPU64/load/NPUfalse后要求63leaf全SHA一致。设备捕获后，两个实际entry缓存artifact的63leaf name/funcID/SHA都必须匹配CPU基准，且两边八个外部状态字节相同，才允许计时。

普通event12×100先后均衡，独立L19窗，逐次guards/readonly。qualified固定False、winners为空：A/A不是优化，即使差异通过旧方向门槛也不声称优化收益，不扩测Native或整模型。数据只用于判断注册/fixture/捕获顺序相关的不确定性，未定位具体物理原因前不称cache coloring。每任务780/750秒。
