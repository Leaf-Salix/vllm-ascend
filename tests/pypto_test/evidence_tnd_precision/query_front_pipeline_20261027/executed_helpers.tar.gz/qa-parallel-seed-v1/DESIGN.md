# Q_A清零按行并行单因素

实际旧控制qr_proj_seed单AIV包含跨度约74.3us，是前段候选。保留每个FP32零值和16x32 tile写入，把外层行块按最多48个AIV分配；每行块完整覆盖1024列，跨worker的16行块起点按64KiB对齐，不共64B缓存行。原matmul K/packet顺序、atomic sentinel/覆盖规则、dtype及所有后处理完全不改。不是此前删除seed或guard分支候选。

枚举T1..256，ceil16(T)所有行块恰由一个owner写一次；T<16仍单worker。保留pad行初始化。只冻结原3399源126/168/generic，未声明formal95或atomic模式资格。需检查生成实际seed并行、全部写入bounds/Task依赖、其他leaf SHA、资源/原作用域。CPU64/load/NPUfalse后，先完整8K/B32普通event性能/独立L1，>=0.5%/10wins/L1低后才Native A/B8/ABA及反向重复；随后正式完整路由和短T/混长、128K及真实token，未验证前不合入。
