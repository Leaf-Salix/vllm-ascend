import re,ast,json,hashlib
from pathlib import Path
TOKENS = re.compile('(?P<protected>(?:u8|u|U|L)?R"(?P<delimiter>[^ ()\\\\\\t\\r\\n]{0,16})\\(.*?\\)(?P=delimiter)"|(?:u8|u|U|L)?"(?:\\\\.|[^"\\\\])*"|(?:u8|u|U|L)?\'(?:\\\\.|[^\'\\\\])*\'|/\\*.*?\\*/|//[^\\n]*|^[ \\t]*\\#(?:[^\\n\\\\]|\\\\[^\\n]|\\\\\\n)*)|(?P<identifier>\\b[A-Za-z_]\\w*\\b)', re.DOTALL | re.MULTILINE)
INLINE = re.compile('[A-Za-z_]\\w*inline[0-9]+\\w*\\Z')
DECL = re.compile('\\b(?:int64_t|int32_t|uint32_t|uint64_t|float|Tensor|TensorCreateInfo|TaskOutputTensors|TaskId)(?:\\s*&\\s*|\\s+)([A-Za-z_]\\w*inline[0-9]+\\w*)\\b')

def normalize(text):
    assert 'CSA_ALPHA_INLINE_' not in text
    protected = []

    def mask(match):
        if match.group('protected') is not None:
            protected.append(match.group())
            return ''.join(('\n' if c == '\n' else ' ' for c in match.group()))
        return match.group()
    plain = TOKENS.sub(mask, text)
    declared = set(DECL.findall(plain))
    renamed = {m.group() for m in TOKENS.finditer(plain) if m.group('identifier') and INLINE.fullmatch(m.group())}
    assert renamed <= declared, ('non-local identifier', sorted(renamed - declared))
    mapping = {}

    def replace(match):
        word = match.group()
        if match.group('identifier') is None or not INLINE.fullmatch(word):
            return word
        if word not in mapping:
            stem = re.sub('inline[0-9]+', 'inline', word)
            mapping[word] = f'CSA_ALPHA_INLINE_{len(mapping)}_{stem}'
        return mapping[word]
    return (TOKENS.sub(replace, text), protected, mapping)

def leaf_maps(manifest):
    return ({str(k['func_id']): k['name'] for k in manifest['kernels']}, {str(k['func_id']): k['binary']['sha256'] for k in manifest['kernels']})

def configuration(text):
    """解析两种已知生成配置，不执行模块或导入 simpler。"""
    tree = ast.parse(text)
    values = {}

    def value(node):
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.List):
            return [value(n) for n in node.elts]
        if isinstance(node, ast.Dict):
            return {value(k): value(v) for k, v in zip(node.keys, node.values, strict=True)}
        if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name) and (node.value.id == '_D'):
            assert node.attr in ('IN', 'OUT', 'INOUT')
            return node.attr
        if isinstance(node, ast.Name) and node.id == '_ROOT_DIR':
            return ''
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div):
            left, right = (value(node.left), value(node.right))
            assert isinstance(left, str) and isinstance(right, str)
            return left + ('/' if left else '') + right
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and (node.func.id == 'str') and (len(node.args) == 1) and (not node.keywords):
            return value(node.args[0])
        raise AssertionError(('unexpected configuration expression', ast.dump(node)))
    expected_root = ast.parse('_ROOT_DIR = Path(__file__).parent').body[0]
    expected_imports = {'from pathlib import Path', 'from simpler.task_interface import ArgDirection as _D'}
    expected_tail = ast.parse("for _entry in [*KERNELS, ORCHESTRATION]:\n    _entry['source'] = str(_ROOT_DIR / _entry['source'])\n    _entry['signature'] = [getattr(_D, s) for s in _entry['signature']]\n    if 'extra_include_dirs' in _entry:\n        _entry['extra_include_dirs'] = [str(_ROOT_DIR / p) for p in _entry['extra_include_dirs']]\n").body[0]
    for node in tree.body:
        if isinstance(node, ast.ImportFrom):
            assert ast.unparse(node) in expected_imports
        elif isinstance(node, ast.Assign):
            assert len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
            name = node.targets[0].id
            if name == '_ROOT_DIR':
                assert ast.dump(node) == ast.dump(expected_root)
            else:
                assert name in ('KERNELS', 'ORCHESTRATION', 'RUNTIME_CONFIG') and name not in values
                values[name] = value(node.value)
        elif isinstance(node, ast.For):
            assert ast.dump(node) == ast.dump(expected_tail)
        else:
            raise AssertionError(('unexpected configuration statement', ast.dump(node)))
    assert values.keys() == {'KERNELS', 'ORCHESTRATION', 'RUNTIME_CONFIG'}
    assert all(('extra_include_dirs' not in e for e in [*values['KERNELS'], values['ORCHESTRATION']]))
    return values
def prepared_artifact(entry):
    from pypto.runtime.kernel.context import get_process_kernel_state
    state=get_process_kernel_state()
    # Read only, under the SDK lock; no loading/registering/cache mutation.
    with state._condition:
        registrations=[registration for key,registration in state._specializations.items()
            if isinstance(key,tuple) and len(key)==3 and key[0] is entry]
        assert len(registrations)==1,('expected one actually prepared root',len(registrations))
        registration=registrations[0]
        state.require_registration(registration)
        return registration.artifact

def verify_aa(entry_for,parent):
    cpu=Path(parent)/'cpu-baseline/kernel'
    cpu_manifest=json.loads((cpu/'binary_manifest.json').read_text())
    cpu_map=leaf_maps(cpu_manifest)
    cpu_files=list((cpu/'orchestration').glob('*.cpp'));assert len(cpu_files)==1
    cpu_normal,cpu_protected,cpu_ids=normalize(cpu_files[0].read_text())
    result={}
    for arm in ('baseline','candidate'):
        artifact=prepared_artifact(entry_for(arm));actual=Path(artifact.output_dir)
        manifest=json.loads((actual/'binary_manifest.json').read_text())
        assert leaf_maps(manifest)==cpu_map,(arm,'leaf mismatch')
        files=list((actual/'orchestration').glob('*.cpp'));assert len(files)==1
        normal,protected,ids=normalize(files[0].read_text())
        assert normal==cpu_normal and protected==cpu_protected and len(ids)==len(cpu_ids),(arm,'orchestration mismatch')
        assert (actual/'compiled_meta.json').read_bytes()==(cpu/'compiled_meta.json').read_bytes()
        assert configuration((actual/'kernel_config.py').read_text())==configuration((cpu/'kernel_config.py').read_text())
        result[arm]={'artifact_directory':str(actual),'artifact_identity':artifact.identity().hex(),'leaf_count':len(cpu_map[0]),'all_leaf_names_funcIDs_SHA_match':True,'orchestration_strict_alpha_equal':True,'orchestration_normalized_sha256':hashlib.sha256(normal.encode()).hexdigest(),'compiled_meta_byte_equal':True,'all_kernel_config_values_equal':True}
    return result
