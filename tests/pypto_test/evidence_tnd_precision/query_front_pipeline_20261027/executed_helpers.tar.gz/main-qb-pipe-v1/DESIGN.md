# 主Q_B INT8流水单因素候选

只借鉴nalinaly NZ q_b_stage的M128/N256/K256双缓冲，保留24个worker和原Native NZ权重。控制为已验Direct，无Query融合或owner等待。Q_A、QR、Indexer、所有FP32反量化/RMS/RoPE、Sparse、输出模块均不改；只复制原q_proj_q的allocation上取整到128，完整保留其原后处理调用。

每个INT8点积1024项，最坏绝对值上界1024×128²=16777216<2³¹，不发生INT32溢出，因此改变M行盒子与K片大小不改变整数和；仍须真实Native逐bit验收，不能只凭理论通过。尾部pl.slice显式valid，输出只消费真实T，未对每个请求padding到S6。QR暂存原512行足够，INT32临时空间改ceil128(T)，不是读取未初始化补行。

先双臂CPU64、原后处理AST与生成INT32/有效行/读写边界/资源/生命周期独立审查。按>=0.5%/10wins/L1低做性能门槛，赢后Native A/B8和ABA，反向重复、短尾及混长，再整模型8K/128K。未改SDK或生成C++，尚无性能或精度资格。
