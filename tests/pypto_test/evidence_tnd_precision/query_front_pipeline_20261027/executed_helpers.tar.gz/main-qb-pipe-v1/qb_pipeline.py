import pypto.language as pl
from ..deepseek_v4_flash_csa_tnd_precision.q_projection import *
@pl.jit.inline(auto_scope=False)
def q_proj_q_matmul(wq_b: pl.Tensor[[Q_LORA, H * HEAD_DIM], pl.INT8, QUANT_WEIGHT_LAYOUT], qr_i8_matmul: pl.Tensor[[QPROJ_T_PAD, Q_LORA], pl.INT8], q_proj_i32: pl.Tensor[[QPROJ_MM_T_DYN, H * HEAD_DIM], pl.INT32], tile_rows: pl.Scalar[pl.INDEX], qproj_dep: pl.Scalar[pl.TASK_ID]):
    qproj_t_matmul = pl.tensor.dim(q_proj_i32, 0)
    with pl.spmd(QPROJ_WORKERS, name_hint='qproj_matmul', deps=[qproj_dep]) as qproj_tid:
        pl.set_cache_policy(wq_b, pl.CachePolicy.BYPASS)
        worker = pl.tile.get_block_idx()
        for qround in pl.range(0, (QPROJ_N_BLOCKS - worker + QPROJ_WORKERS - 1) // QPROJ_WORKERS):
            nidx = worker + qround * QPROJ_WORKERS
            col = nidx * QPROJ_MM_N_TILE
            for t0 in pl.range(0, qproj_t_matmul, 128):
                valid = pl.min(128, tile_rows - t0)
                first = pl.slice(qr_i8_matmul, [128, 256], [t0, 0], valid_shape=[valid, 256])
                weight = wq_b[0:256, col:col + QPROJ_MM_N_TILE]
                acc = pl.matmul(first, weight, out_dtype=pl.INT32)
                for k0 in pl.pipeline(256, Q_LORA, 256, stage=2):
                    chunk = pl.slice(qr_i8_matmul, [128, 256], [t0, k0], valid_shape=[valid, 256])
                    part = wq_b[k0:k0 + 256, col:col + QPROJ_MM_N_TILE]
                    acc = pl.matmul_acc(acc, chunk, part)
                q_proj_i32[t0:t0 + 128, col:col + QPROJ_MM_N_TILE] = acc
    return (q_proj_i32, qproj_tid)
