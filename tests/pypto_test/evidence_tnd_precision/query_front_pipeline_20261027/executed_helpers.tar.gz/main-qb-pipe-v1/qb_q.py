import pypto.language as pl
from ..deepseek_v4_flash_csa_tnd_precision.qkv_proj_rope import *
from .gap_qb_pipeline import q_proj_q_matmul
@pl.jit.inline(auto_scope=False)
def q_proj_q(x: pl.Tensor[[T_DYN, D], pl.BF16], wq_b: pl.Tensor[[Q_LORA, H * HEAD_DIM], pl.INT8, QUANT_WEIGHT_LAYOUT], wq_b_scale: pl.Tensor[[H * HEAD_DIM], pl.FP32], rope_cos_il: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32], rope_sin_signed: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32], rope_swap_idx: pl.Tensor[[T_DYN, ROPE_DIM], pl.INT32], q: pl.Tensor[[T_DYN, H, HEAD_DIM], pl.BF16], qr_i8_matmul: pl.Tensor[[QPROJ_T_PAD, Q_LORA], pl.INT8], qr_scale_pad_store: pl.Tensor[[QPROJ_T_PAD, 1], pl.FP32], qproj_dep: pl.Scalar[pl.TASK_ID]):
    """Q projection and its dequant + RMSNorm + RoPE over bounded tiles."""
    t_dim = pl.tensor.dim(x, 0)
    for tile_base in pl.range(0, t_dim, PREFILL_DENSE_TILE):
        tile_rows = pl.min(PREFILL_DENSE_TILE, t_dim - tile_base)
        with pl.scope():
            qproj_t_matmul = (tile_rows + 127) // 128 * 128
            q_proj_i32 = pl.create_tensor([qproj_t_matmul, H * HEAD_DIM], dtype=pl.INT32)
            q_proj_i32, _qproj_tid = q_proj_q_matmul(wq_b, qr_i8_matmul, q_proj_i32, tile_rows, qproj_dep)
            q_proj_q_dequant(wq_b_scale, rope_cos_il, rope_sin_signed, rope_swap_idx, q, qr_scale_pad_store, q_proj_i32, tile_base, tile_rows)
    return q
