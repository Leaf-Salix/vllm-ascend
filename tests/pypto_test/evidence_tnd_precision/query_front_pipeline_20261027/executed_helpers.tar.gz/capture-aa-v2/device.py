from pathlib import Path
import hashlib,json,runpy,sys
here=Path(__file__).resolve().parent
assert all(hashlib.sha256((here/k).read_bytes()).hexdigest()==v for k,v in json.loads((here/'manifest.json').read_text()).items())
parent=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-sdk-alignment-20261026-codex/capture-aa-v1')
assert hashlib.sha256((parent/'probe_perf.py').read_bytes()).hexdigest()=='710682e86520bacbd9008c818f4b4acbeeccf26540c61677c0b7ab40a9c36485'
sys.path.insert(0,str(parent));sys.path.insert(0,str(here))
runpy.run_path(str(parent/'sdk_bind.py'),run_name='__sdk_preflight__')
s=(here/'derived_probe.py').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='c28a1df28ce07aae4a0f0a0006cf1211a4dfb6b694c29c86d9da570d8583332d'
exec(compile(s,str(parent/'probe_perf.py'),'exec'),{'__name__':'__main__','__file__':str(parent/'probe_perf.py')})
