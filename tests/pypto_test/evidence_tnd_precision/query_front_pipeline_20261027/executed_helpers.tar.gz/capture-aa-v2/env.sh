#!/usr/bin/env bash
set -euo pipefail
source /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-sdk-alignment-20261026-codex/capture-aa-v1/env.sh
export PYPTO_PROG_BUILD_DIR=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-sdk-alignment-20261026-codex/capture-aa-v2/build
