from pathlib import Path
import hashlib,json,runpy,sys
here=Path(__file__).resolve().parent
assert all(hashlib.sha256((here/k).read_bytes()).hexdigest()==v for k,v in json.loads((here/'manifest.json').read_text()).items())
parent=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-sdk-alignment-20261026-codex/qa-parallel-seed-v1')
assert hashlib.sha256((parent/'probe_perf.py').read_bytes()).hexdigest()=='bafb33d8dfaa92edc50aaa3d1b96153c6734fbdfad2383bf5d12a1458975aacb'
sys.path.insert(0,str(parent))
runpy.run_path(str(parent/'sdk_bind.py'),run_name='__sdk_preflight__')
s=(here/'derived_probe.py').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='2b1b79ef0226f998da3574de831e6e7dc31727835f3345aaba13b3a997f6066c'
exec(compile(s,str(parent/'probe_perf.py'),'exec'),{'__name__':'__main__','__file__':str(parent/'probe_perf.py'),'PARENT_SHA':'bafb33d8dfaa92edc50aaa3d1b96153c6734fbdfad2383bf5d12a1458975aacb','DERIVED_SHA':'2b1b79ef0226f998da3574de831e6e7dc31727835f3345aaba13b3a997f6066c'})
