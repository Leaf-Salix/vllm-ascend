import pypto.language as pl
from .gap_island_math import *
from ..deepseek_v4_flash_csa_tnd_precision_spmd.rendezvous import handoff, GROUPS
from ..deepseek_v4_flash_csa_tnd_precision_spmd.indexer import indexer_weights_score
from ..deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.qkv_precision126 import q_proj_qr
from ..deepseek_v4_flash_csa_tnd_precision_spmd.qkv_proj_rope import kv_proj_rope
from ..deepseek_v4_flash_csa_tnd_precision.qkv_proj_rope import rope_prepare, BF16_WEIGHT_LAYOUT
from ..deepseek_v4_flash_csa_tnd_precision.decode_indexer import B_DYN, IDX_TOPK, IDX_NATIVE_CACHE_BLOCK_NUM_DYN, INDEXER_PAGE_BYTES_DYN, INDEXER_TABLE_COLUMNS_DYN, QUERY_BOUNDS_DYN, TP1_WEIGHTS_WORKERS
BRANCH_GROUPS = 4

@pl.jit.incore
def island_cube(x: pl.Tensor[[T_DYN, D], pl.BF16], qr: pl.Tensor[[T_DYN, Q_LORA], pl.INT8], idx_w: pl.Tensor[[Q_LORA, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT8], had: pl.Tensor[[IDX_HEAD_DIM, IDX_HEAD_DIM], pl.BF16], main_w: pl.Tensor[[Q_LORA, H * HEAD_DIM], pl.INT8, QUANT_WEIGHT_LAYOUT], qr_pad: pl.Tensor[[QPROJ_T_PAD, Q_LORA], pl.INT8], idx_acc: pl.InOut[pl.Tensor[[QR_MM_T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT32]], idx_bf_read: pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.BF16], had_acc: pl.InOut[pl.Tensor[[QH_ROWS, IDX_HEAD_DIM], pl.FP32]], main_acc: pl.InOut[pl.Tensor[[256, H * HEAD_DIM], pl.INT32]], ffts: pl.Tensor[[256], pl.INT64]):
    pl.func_attr({'cache_policy': [(4, 1)]})
    pl.system.set_ffts(ffts)
    worker = pl.tile.get_block_idx()
    rows = pl.tensor.dim(x, 0)
    idx_acc = idx_cube(x, qr, idx_w, idx_acc, worker)
    handoff()
    handoff()
    if worker < GROUPS - BRANCH_GROUPS:
        main_acc = main_cube(main_w, qr_pad, main_acc, rows, worker, GROUPS - BRANCH_GROUPS)
    else:
        had_acc = had_cube(x, idx_bf_read, had, had_acc, worker - (GROUPS - BRANCH_GROUPS), BRANCH_GROUPS)
    handoff()
    handoff()
    return (idx_acc, had_acc, main_acc)

@pl.jit.incore
def island_vector(x: pl.Tensor[[T_DYN, D], pl.BF16], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], idx_scale: pl.Tensor[[IDX_N_HEADS * IDX_HEAD_DIM], pl.FP32], cos: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32], idx_sin: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32], main_scale: pl.Tensor[[H * HEAD_DIM], pl.FP32], main_sin: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32], main_swap: pl.Tensor[[T_DYN, ROPE_DIM], pl.INT32], scale_pad: pl.Tensor[[QPROJ_T_PAD, 1], pl.FP32], idx_acc_read: pl.Tensor[[QR_MM_T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT32], idx_bf: pl.InOut[pl.Tensor[[T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], pl.BF16]], had_acc_read: pl.Tensor[[QH_ROWS, IDX_HEAD_DIM], pl.FP32], main_acc_read: pl.Tensor[[256, H * HEAD_DIM], pl.INT32], q: pl.InOut[pl.Tensor[[T_DYN, H * HEAD_DIM], pl.BF16]], out_i8: pl.InOut[pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.INT8]], out_scale: pl.InOut[pl.Tensor[[T_PAD * IDX_N_HEADS, 1], pl.FP32]], ffts: pl.Tensor[[256], pl.INT64]):
    pl.func_attr({'split_aiv': True})
    pl.system.set_ffts(ffts)
    worker = pl.tile.get_block_idx() * 2 + pl.tile.get_subblock_idx()
    rows = pl.tensor.dim(x, 0)
    handoff()
    idx_bf = idx_vector(x, qr_scale, idx_scale, cos, idx_sin, idx_acc_read, idx_bf, worker)
    handoff()
    handoff()
    out_i8, out_scale = had_vector(x, had_acc_read, out_i8, out_scale, worker)
    q = main_vector(main_scale, cos, main_sin, main_swap, q, scale_pad, main_acc_read, 0, rows, worker)
    handoff()
    return (idx_bf, out_i8, out_scale, q)

@pl.jit.inline(auto_scope=False)
def island_group(x: pl.Tensor[[T_DYN, D], pl.BF16], qr: pl.Tensor[[T_DYN, Q_LORA], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], idx_w: pl.Tensor[[Q_LORA, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT8], idx_scale: pl.Tensor[[IDX_N_HEADS * IDX_HEAD_DIM], pl.FP32], cos: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32], idx_sin: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32], had: pl.Tensor[[IDX_HEAD_DIM, IDX_HEAD_DIM], pl.BF16], main_w: pl.Tensor[[Q_LORA, H * HEAD_DIM], pl.INT8, QUANT_WEIGHT_LAYOUT], main_scale: pl.Tensor[[H * HEAD_DIM], pl.FP32], main_sin: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32], main_swap: pl.Tensor[[T_DYN, ROPE_DIM], pl.INT32], qr_pad: pl.Tensor[[QPROJ_T_PAD, Q_LORA], pl.INT8], scale_pad: pl.Tensor[[QPROJ_T_PAD, 1], pl.FP32], idx_acc: pl.InOut[pl.Tensor[[QR_MM_T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT32]], idx_acc_read: pl.Tensor[[QR_MM_T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT32], idx_bf: pl.InOut[pl.Tensor[[T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], pl.BF16]], idx_bf_read: pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.BF16], had_acc: pl.InOut[pl.Tensor[[QH_ROWS, IDX_HEAD_DIM], pl.FP32]], had_acc_read: pl.Tensor[[QH_ROWS, IDX_HEAD_DIM], pl.FP32], main_acc: pl.InOut[pl.Tensor[[256, H * HEAD_DIM], pl.INT32]], main_acc_read: pl.Tensor[[256, H * HEAD_DIM], pl.INT32], q: pl.InOut[pl.Tensor[[T_DYN, H * HEAD_DIM], pl.BF16]], out_i8: pl.InOut[pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.INT8]], out_scale: pl.InOut[pl.Tensor[[T_PAD * IDX_N_HEADS, 1], pl.FP32]], ffts: pl.Tensor[[256], pl.INT64]):
    with pl.cluster(name_hint='post_qr_query_island'):
        idx_acc, had_acc, main_acc = island_cube(x, qr, idx_w, had, main_w, qr_pad, idx_acc, idx_bf_read, had_acc, main_acc, ffts)
        idx_bf, out_i8, out_scale, q = island_vector(x, qr_scale, idx_scale, cos, idx_sin, main_scale, main_sin, main_swap, scale_pad, idx_acc_read, idx_bf, had_acc_read, main_acc_read, q, out_i8, out_scale, ffts)
    return (idx_acc, had_acc, main_acc, idx_bf, out_i8, out_scale, q)

@pl.jit.inline(auto_scope=False)
def split_qkv(x: pl.Tensor[[T_DYN, D], pl.BF16], wq_a: pl.Tensor[[Q_LORA, D], pl.BF16, BF16_WEIGHT_LAYOUT], wq_b: pl.Tensor[[Q_LORA, H * HEAD_DIM], pl.INT8, QUANT_WEIGHT_LAYOUT], wq_b_scale: pl.Tensor[[H * HEAD_DIM], pl.FP32], rope_cos: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32], rope_sin: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32], gamma_cq: pl.Tensor[[Q_LORA], pl.BF16], gamma_ckv: pl.Tensor[[HEAD_DIM], pl.BF16], q: pl.Tensor[[T_DYN, H, HEAD_DIM], pl.BF16], kv: pl.Tensor[[T_DYN, HEAD_DIM], pl.BF16], qr: pl.Tensor[[T_DYN, Q_LORA], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], late_dep: pl.Scalar[pl.TASK_ID], native_kv_projected: pl.Tensor[[T_DYN, HEAD_DIM], pl.BF16], qr_pad: pl.InOut[pl.Tensor[[QPROJ_T_PAD, Q_LORA], pl.INT8]], scale_pad: pl.InOut[pl.Tensor[[QPROJ_T_PAD, 1], pl.FP32]], q_signed: pl.InOut[pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32]], q_swap: pl.InOut[pl.Tensor[[T_DYN, ROPE_DIM], pl.INT32]]):
    rope_prepare(rope_sin, q_signed, q_swap)
    q_proj_qr(x, wq_a, gamma_cq, qr, qr_scale, qr_pad, scale_pad)
    kv_proj_rope(x, gamma_ckv, rope_cos, q_signed, q_swap, kv, late_dep, native_kv_projected)
    marker = pl.system.task_dummy(deps=[late_dep])
    return (q, marker)

@pl.jit.inline(auto_scope=False)
def island_indexer(x: pl.Tensor[[T_DYN, D], pl.BF16], qr: pl.Tensor[[T_DYN, Q_LORA], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], wq_b: pl.Tensor[[Q_LORA, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT8], wq_b_scale: pl.Tensor[[IDX_N_HEADS * IDX_HEAD_DIM], pl.FP32], native_indexer_weights: pl.Tensor[[T_DYN, IDX_N_HEADS], pl.FP16], cos: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], sin: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], hadamard: pl.Tensor[[IDX_HEAD_DIM, IDX_HEAD_DIM], pl.BF16], idx_native_kv_cache: pl.Tensor[[IDX_NATIVE_CACHE_BLOCK_NUM_DYN, INDEXER_PAGE_BYTES_DYN], pl.INT8], idx_block_table: pl.Tensor[[B_DYN, INDEXER_TABLE_COLUMNS_DYN], pl.INT32], topk_scores: pl.Out[pl.Tensor[[T_DYN, IDX_TOPK], pl.FP32]], topk_idxs: pl.Out[pl.Tensor[[T_DYN, IDX_TOPK], pl.INT32]], position_ids: pl.Tensor[[T_DYN], pl.INT64], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], late_dep: pl.Scalar[pl.TASK_ID], cache_write_dep: pl.Scalar[pl.TASK_ID], host_max_seq_len: pl.Scalar[pl.INT32], main_w: pl.Tensor[[Q_LORA, H * HEAD_DIM], pl.INT8, QUANT_WEIGHT_LAYOUT], main_scale: pl.Tensor[[H * HEAD_DIM], pl.FP32], main_sin: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32], main_swap: pl.Tensor[[T_DYN, ROPE_DIM], pl.INT32], qr_pad: pl.Tensor[[QPROJ_T_PAD, Q_LORA], pl.INT8], scale_pad: pl.Tensor[[QPROJ_T_PAD, 1], pl.FP32], q: pl.InOut[pl.Tensor[[T_DYN, H, HEAD_DIM], pl.BF16]], ffts: pl.Tensor[[256], pl.INT64]):
    rows = pl.tensor.dim(x, 0)
    q_flat = pl.reshape(q, [rows, H * HEAD_DIM])
    qr_hadamard_i8 = pl.create_tensor([T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], dtype=pl.INT8)
    qr_hadamard_scale_dq = pl.create_tensor([T_PAD * IDX_N_HEADS, 1], dtype=pl.FP32)
    with pl.scope():
        idx_acc = pl.create_tensor([QR_MM_T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], dtype=pl.INT32)
        idx_acc_read = pl.reshape(idx_acc, [QR_MM_T_PAD, IDX_N_HEADS * IDX_HEAD_DIM])
        idx_bf = pl.create_tensor([T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], dtype=pl.BF16)
        idx_bf_read = pl.reshape(idx_bf, [T_PAD * IDX_N_HEADS, IDX_HEAD_DIM])
        idx_bf_flat = pl.reshape(idx_bf, [T_PAD, IDX_N_HEADS * IDX_HEAD_DIM])
        had_acc = pl.create_tensor([rows * IDX_N_HEADS, IDX_HEAD_DIM], dtype=pl.FP32)
        had_acc_read = pl.reshape(had_acc, [rows * IDX_N_HEADS, IDX_HEAD_DIM])
        padded = (rows + QPROJ_M_TILE - 1) // QPROJ_M_TILE * QPROJ_M_TILE
        main_acc = pl.create_tensor([256, H * HEAD_DIM], dtype=pl.INT32)
        main_acc_read = pl.reshape(main_acc, [256, H * HEAD_DIM])
        with pl.spmd(GROUPS, sync_start=True, name_hint='post_qr_query_island') as island_tid:
            _island_result = island_group(x, qr, qr_scale, wq_b, wq_b_scale, cos, sin, hadamard, main_w, main_scale, main_sin, main_swap, qr_pad, scale_pad, idx_acc, idx_acc_read, idx_bf_flat, idx_bf_read, had_acc, had_acc_read, main_acc, main_acc_read, q_flat, qr_hadamard_i8, qr_hadamard_scale_dq, ffts)
    weights_gate_dep = pl.system.task_dummy(deps=[])
    topk_scores, topk_idxs, _leaf_tid = indexer_weights_score(x, native_indexer_weights, qr_hadamard_i8, qr_hadamard_scale_dq, idx_native_kv_cache, idx_block_table, topk_scores, topk_idxs, position_ids, kv_seq_lens, token_request, query_start_loc, cache_write_dep, weights_gate_dep, weights_gate_dep, TP1_WEIGHTS_WORKERS, host_max_seq_len)
    return (topk_scores, topk_idxs)
