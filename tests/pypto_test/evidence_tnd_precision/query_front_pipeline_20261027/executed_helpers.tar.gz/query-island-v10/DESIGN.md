# Post-QR Query岛候选（尚未设备执行）

保持冻结控制来源，未组合QA seed/NZ/HC split。只抽取原Native顺序数学为worker helper。拟用同一MIX内IndexerQ投影→RoPE→Had/主QB→量化/主Q后处理，私有query缓冲与Score arena为兄弟scope，外部Score仅在岛退出后读取。24串行和4/20分核必须分别计时，不把复合收益都归因于fusion。首轮保守FFTS全核handoff，不改数值，不等待岛外cache。必须先生成物/源AST/同步/内存审查，然后才可申请NPU。
