"""Independent post-QR persistent query island; Native math copied unchanged, no cache waits inside MIX."""
import pypto.language as pl
QH_ROWS = pl.dynamic('ISLAND_QH_ROWS')
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.decode_indexer import D, IDX_HEAD_DIM, IDX_N_HEADS, QR_MM_N_TILE, QR_MM_ROW_TILE, QR_MM_T_PAD, QR_PROJ_WORKERS, Q_LORA, T_DYN

@pl.jit.inline(auto_scope=False)
def idx_cube(x: pl.Tensor[[T_DYN, D], pl.BF16], qr: pl.Tensor[[T_DYN, Q_LORA], pl.INT8], wq_b: pl.Tensor[[Q_LORA, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT8], acc: pl.InOut[pl.Tensor[[QR_MM_T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT32]], worker: pl.Scalar[pl.INDEX]):
    bs = pl.tensor.dim(x, 0)
    row_blocks = (bs + QR_MM_ROW_TILE - 1) // QR_MM_ROW_TILE
    for qr_col in pl.range(worker, IDX_N_HEADS * IDX_HEAD_DIM // QR_MM_N_TILE, QR_PROJ_WORKERS):
        o_base = qr_col * QR_MM_N_TILE
        wq_tile = wq_b[0:Q_LORA, o_base:o_base + QR_MM_N_TILE]
        for qr_rb in pl.range(row_blocks):
            qr_r0 = qr_rb * QR_MM_ROW_TILE
            qr_rows = pl.min(QR_MM_ROW_TILE, bs - qr_r0)
            qr_tile = pl.slice(qr, [QR_MM_ROW_TILE, Q_LORA], [qr_r0, 0], valid_shape=[qr_rows, Q_LORA])
            qr_acc = pl.matmul(qr_tile, wq_tile, out_dtype=pl.INT32)
            acc[qr_r0:qr_r0 + QR_MM_ROW_TILE, o_base:o_base + QR_MM_N_TILE] = qr_acc
    return acc
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.decode_indexer import D, DEQUANT_T_TILE, DQ_ROPE_H_TILE, DQ_ROPE_WORKERS, IDX_HEAD_DIM, IDX_NOPE_HEAD_DIM, IDX_N_HEADS, QR_MM_T_PAD, ROPE_HEAD_DIM, T_DYN, T_PAD

@pl.jit.inline(auto_scope=False)
def idx_vector(x: pl.Tensor[[T_DYN, D], pl.BF16], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], wq_b_scale: pl.Tensor[[IDX_N_HEADS * IDX_HEAD_DIM], pl.FP32], cos: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], sin: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], qr_acc_pad: pl.Tensor[[QR_MM_T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT32], qr_bf16: pl.InOut[pl.Tensor[[T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], pl.BF16]], worker: pl.Scalar[pl.INDEX]):
    bs = pl.tensor.dim(x, 0)
    dq_rope_units = (bs + DEQUANT_T_TILE - 1) // DEQUANT_T_TILE * (IDX_N_HEADS // DQ_ROPE_H_TILE)
    dq_rope_workers = pl.min(dq_rope_units, DQ_ROPE_WORKERS)
    if worker < dq_rope_workers:
        sw_ones = pl.full([DEQUANT_T_TILE, ROPE_HEAD_DIM], dtype=pl.FP32, value=1.0)
        sw_index = pl.cast(pl.arange(0, [1, ROPE_HEAD_DIM], dtype=pl.INT32), target_type=pl.FP32)
        sw_col = pl.col_expand_mul(sw_ones, sw_index)
        sw_dup_f = pl.cast(pl.cast(pl.mul(sw_col, 0.5), target_type=pl.INT32, mode='trunc'), target_type=pl.FP32)
        sw_lane = pl.sub(sw_col, pl.mul(sw_dup_f, 2.0))
        rope_swap_idx = pl.cast(pl.sub(pl.add(sw_col, 1.0), pl.mul(sw_lane, 2.0)), target_type=pl.INT32)
        for dq_unit in pl.range(worker, dq_rope_units, dq_rope_workers):
            hg = dq_unit % (IDX_N_HEADS // DQ_ROPE_H_TILE) * DQ_ROPE_H_TILE
            dq_t0 = dq_unit // (IDX_N_HEADS // DQ_ROPE_H_TILE) * DEQUANT_T_TILE
            if dq_t0 + DEQUANT_T_TILE <= bs:
                qr_scale_tile = qr_scale[dq_t0:dq_t0 + DEQUANT_T_TILE, :]
                cos_tile = cos[dq_t0:dq_t0 + DEQUANT_T_TILE, 0:ROPE_HEAD_DIM]
                sin_tile = sin[dq_t0:dq_t0 + DEQUANT_T_TILE, 0:ROPE_HEAD_DIM]
                for h_inner in pl.pipeline(DQ_ROPE_H_TILE, stage=2):
                    h0 = (hg + h_inner) * IDX_HEAD_DIM
                    wq_scale = pl.reshape(wq_b_scale[h0:h0 + IDX_HEAD_DIM], [1, IDX_HEAD_DIM])
                    acc_fp32 = pl.cast(qr_acc_pad[dq_t0:dq_t0 + DEQUANT_T_TILE, h0:h0 + IDX_HEAD_DIM], target_type=pl.FP32, mode='none')
                    qr_dequant_scale = pl.col_expand_mul(pl.row_expand_mul(pl.full([DEQUANT_T_TILE, IDX_HEAD_DIM], dtype=pl.FP32, value=1.0), qr_scale_tile), wq_scale)
                    qr_dequant = pl.mul(acc_fp32, qr_dequant_scale)
                    qr_dequant = pl.cast(pl.cast(qr_dequant, pl.BF16, mode='rint'), pl.FP32)
                    qr_nope_bf16 = pl.cast(qr_dequant[:, 0:IDX_NOPE_HEAD_DIM], target_type=pl.BF16, mode='rint')
                    qr_rope_slice = qr_dequant[:, IDX_NOPE_HEAD_DIM:IDX_HEAD_DIM]
                    qr_swapped = pl.gather(qr_rope_slice, dim=-1, index=rope_swap_idx)
                    rope_rot = pl.add(pl.mul(qr_rope_slice, cos_tile), pl.mul(qr_swapped, sin_tile))
                    rope_bf16 = pl.cast(rope_rot, target_type=pl.BF16, mode='rint')
                    qr_bf16[dq_t0:dq_t0 + DEQUANT_T_TILE, h0:h0 + IDX_NOPE_HEAD_DIM] = qr_nope_bf16
                    qr_bf16[dq_t0:dq_t0 + DEQUANT_T_TILE, h0 + IDX_NOPE_HEAD_DIM:h0 + IDX_HEAD_DIM] = rope_bf16
            else:
                tail_swap_idx = rope_swap_idx[0:1, :]
                for tail_t0 in pl.range(dq_t0, bs):
                    tail_qr_scale_value = pl.read(qr_scale, [tail_t0, 0])
                    tail_cos_tile = cos[tail_t0:tail_t0 + 1, 0:ROPE_HEAD_DIM]
                    tail_sin_tile = sin[tail_t0:tail_t0 + 1, 0:ROPE_HEAD_DIM]
                    for tail_h_inner in pl.pipeline(DQ_ROPE_H_TILE, stage=2):
                        tail_h0 = (hg + tail_h_inner) * IDX_HEAD_DIM
                        tail_wq_scale = pl.reshape(wq_b_scale[tail_h0:tail_h0 + IDX_HEAD_DIM], [1, IDX_HEAD_DIM])
                        tail_acc_fp32 = pl.cast(qr_acc_pad[tail_t0:tail_t0 + 1, tail_h0:tail_h0 + IDX_HEAD_DIM], target_type=pl.FP32, mode='none')
                        tail_qr_dequant_scale = pl.mul(tail_wq_scale, tail_qr_scale_value)
                        tail_qr_dequant = pl.mul(tail_acc_fp32, tail_qr_dequant_scale)
                        tail_qr_dequant = pl.cast(pl.cast(tail_qr_dequant, pl.BF16, mode='rint'), pl.FP32)
                        tail_qr_nope_bf16 = pl.cast(tail_qr_dequant[:, 0:IDX_NOPE_HEAD_DIM], target_type=pl.BF16, mode='rint')
                        tail_qr_rope_slice = tail_qr_dequant[:, IDX_NOPE_HEAD_DIM:IDX_HEAD_DIM]
                        tail_qr_swapped = pl.gather(tail_qr_rope_slice, dim=-1, index=tail_swap_idx)
                        tail_rope_rot = pl.add(pl.mul(tail_qr_rope_slice, tail_cos_tile), pl.mul(tail_qr_swapped, tail_sin_tile))
                        tail_rope_bf16 = pl.cast(tail_rope_rot, target_type=pl.BF16, mode='rint')
                        qr_bf16[tail_t0:tail_t0 + 1, tail_h0:tail_h0 + IDX_NOPE_HEAD_DIM] = tail_qr_nope_bf16
                        qr_bf16[tail_t0:tail_t0 + 1, tail_h0 + IDX_NOPE_HEAD_DIM:tail_h0 + IDX_HEAD_DIM] = tail_rope_bf16
    return qr_bf16
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.decode_indexer import D, IDX_HEAD_DIM, IDX_N_HEADS, QH_MM_TILE, T_DYN, T_PAD

@pl.jit.inline(auto_scope=False)
def had_cube(x: pl.Tensor[[T_DYN, D], pl.BF16], qr_bf16: pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.BF16], hadamard: pl.Tensor[[IDX_HEAD_DIM, IDX_HEAD_DIM], pl.BF16], qh_acc_gm: pl.InOut[pl.Tensor[[QH_ROWS, IDX_HEAD_DIM], pl.FP32]], worker: pl.Scalar[pl.INDEX], HAD_WORKERS: pl.constexpr):
    bs = pl.tensor.dim(x, 0)
    bs_heads = bs * IDX_N_HEADS
    qh_hadamard = hadamard[0:IDX_HEAD_DIM, 0:IDX_HEAD_DIM]
    for idx in pl.range(worker, bs_heads // QH_MM_TILE, HAD_WORKERS):
        o0 = idx * QH_MM_TILE
        qh_acc = pl.matmul(qr_bf16[o0:o0 + QH_MM_TILE, :], qh_hadamard, out_dtype=pl.FP32)
        qh_acc_gm[o0:o0 + QH_MM_TILE, :] = qh_acc
    return qh_acc_gm
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.decode_indexer import D, HADAMARD_SCALE, IDX_HEAD_DIM, IDX_N_HEADS, INT8_AMAX_EPS, INT8_SCALE_MAX, QH_HEAD_DIM_TILE, QH_QUANT_TILE, QH_QUANT_WORKERS, T_DYN, T_PAD

@pl.jit.inline(auto_scope=False)
def had_vector(x: pl.Tensor[[T_DYN, D], pl.BF16], qh_acc_gm: pl.Tensor[[QH_ROWS, IDX_HEAD_DIM], pl.FP32], qr_hadamard_i8: pl.InOut[pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.INT8]], qr_hadamard_scale_dq: pl.InOut[pl.Tensor[[T_PAD * IDX_N_HEADS, 1], pl.FP32]], worker: pl.Scalar[pl.INDEX]):
    bs = pl.tensor.dim(x, 0)
    bs_heads = bs * IDX_N_HEADS
    for idx in pl.range(worker, bs_heads // QH_QUANT_TILE, QH_QUANT_WORKERS):
        o0 = idx * QH_QUANT_TILE
        qh_full_f32 = qh_acc_gm[o0:o0 + QH_QUANT_TILE, 0:IDX_HEAD_DIM]
        qh_full_f32 = pl.cast(pl.cast(qh_full_f32, pl.BF16, mode='rint'), pl.FP32)
        qh_full_f32 = pl.cast(pl.cast(pl.mul(qh_full_f32, HADAMARD_SCALE), pl.BF16, mode='rint'), pl.FP32)
        qh_amax = pl.full([1, QH_QUANT_TILE], dtype=pl.FP32, value=INT8_AMAX_EPS)
        for h0 in pl.range(0, IDX_HEAD_DIM, QH_HEAD_DIM_TILE):
            qh_a_f32 = qh_full_f32[:, h0:h0 + QH_HEAD_DIM_TILE]
            qh_a_neg = pl.neg(qh_a_f32)
            qh_a_abs = pl.maximum(qh_a_f32, qh_a_neg)
            qh_a_max_col = pl.row_max(qh_a_abs)
            qh_a_max = pl.reshape(qh_a_max_col, [1, QH_QUANT_TILE])
            qh_amax = pl.maximum(qh_amax, qh_a_max)
        qh_scale_numerator = pl.full([1, QH_QUANT_TILE], dtype=pl.FP32, value=INT8_SCALE_MAX)
        qh_scale_quant_row = pl.div(qh_scale_numerator, qh_amax)
        qh_scale_recip = pl.recip(qh_scale_quant_row)
        qh_scale_dq = pl.reshape(qh_scale_recip, [QH_QUANT_TILE, 1])
        qr_hadamard_scale_dq[o0:o0 + QH_QUANT_TILE, :] = pl.cast(pl.cast(qh_scale_dq, pl.FP16, mode='rint'), pl.FP32)
        qh_scale_quant = pl.reshape(qh_scale_quant_row, [QH_QUANT_TILE, 1])
        qh_q_scaled = pl.row_expand_mul(qh_full_f32, qh_scale_quant)
        qh_q_i32 = pl.cast(qh_q_scaled, target_type=pl.INT32, mode='rint')
        qh_q_half = pl.cast(qh_q_i32, target_type=pl.FP16, mode='round')
        qh_i8 = pl.cast(qh_q_half, target_type=pl.INT8, mode='trunc')
        qr_hadamard_i8[o0:o0 + QH_QUANT_TILE, 0:IDX_HEAD_DIM] = qh_i8
    return (qr_hadamard_i8, qr_hadamard_scale_dq)
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.q_projection import H, HEAD_DIM, QPROJ_MM_N_TILE, QPROJ_MM_T_DYN, QPROJ_M_TILE, QPROJ_N_BLOCKS, QPROJ_TAIL_M_TILE, QPROJ_T_PAD, QUANT_WEIGHT_LAYOUT, Q_LORA

@pl.jit.inline(auto_scope=False)
def main_cube(wq_b: pl.Tensor[[Q_LORA, H * HEAD_DIM], pl.INT8, QUANT_WEIGHT_LAYOUT], qr_i8_matmul: pl.Tensor[[QPROJ_T_PAD, Q_LORA], pl.INT8], q_proj_i32: pl.InOut[pl.Tensor[[256, H * HEAD_DIM], pl.INT32]], tile_rows: pl.Scalar[pl.INDEX], worker: pl.Scalar[pl.INDEX], QB_WORKERS: pl.constexpr):
    qproj_t_matmul = (tile_rows + QPROJ_M_TILE - 1) // QPROJ_M_TILE * QPROJ_M_TILE
    qproj_full_rows = tile_rows // QPROJ_M_TILE * QPROJ_M_TILE
    for qproj_round in pl.range(0, (QPROJ_N_BLOCKS - worker + QB_WORKERS - 1) // QB_WORKERS):
        qproj_n_idx = worker + qproj_round * QB_WORKERS
        w_col0 = qproj_n_idx * QPROJ_MM_N_TILE
        wq_full = wq_b[0:Q_LORA, w_col0:w_col0 + QPROJ_MM_N_TILE]
        for t0 in pl.range(0, qproj_full_rows, QPROJ_M_TILE):
            qr_full = qr_i8_matmul[t0:t0 + QPROJ_M_TILE, 0:Q_LORA]
            col_acc = pl.matmul(qr_full, wq_full, out_dtype=pl.INT32)
            q_proj_i32[t0:t0 + QPROJ_M_TILE, w_col0:w_col0 + QPROJ_MM_N_TILE] = col_acc
        for tail_t0 in pl.range(qproj_full_rows, qproj_t_matmul, QPROJ_TAIL_M_TILE):
            tail_rows = pl.min(QPROJ_TAIL_M_TILE, tile_rows - tail_t0)
            qr_tail = pl.slice(qr_i8_matmul, [QPROJ_TAIL_M_TILE, Q_LORA], [tail_t0, 0], valid_shape=[tail_rows, Q_LORA])
            tail_acc = pl.matmul(qr_tail, wq_full, out_dtype=pl.INT32)
            q_proj_i32[tail_t0:tail_t0 + QPROJ_TAIL_M_TILE, w_col0:w_col0 + QPROJ_MM_N_TILE] = tail_acc
    return q_proj_i32
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.qkv_proj_rope import EPS, H, HEAD_DIM, NOPE_DIM, QPROJ_MM_T_DYN, QPROJ_T_PAD, Q_DEQUANT_WORKERS, Q_ROPE_H_TILE, Q_ROPE_T_TILE, ROPE_DIM, ROPE_DIM_SCALE, T_DYN

@pl.jit.inline(auto_scope=False)
def main_vector(wq_b_scale: pl.Tensor[[H * HEAD_DIM], pl.FP32], rope_cos_il: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32], rope_sin_signed: pl.Tensor[[T_DYN, ROPE_DIM], pl.FP32], rope_swap_idx: pl.Tensor[[T_DYN, ROPE_DIM], pl.INT32], q_flat: pl.Tensor[[T_DYN, H * HEAD_DIM], pl.BF16], qr_scale_pad_store: pl.Tensor[[QPROJ_T_PAD, 1], pl.FP32], q_proj_i32: pl.Tensor[[256, H * HEAD_DIM], pl.INT32], tile_base: pl.Scalar[pl.INDEX], tile_rows: pl.Scalar[pl.INDEX], worker: pl.Scalar[pl.INDEX]):
    """Dequantize, normalize, and rotate one projected Q tile."""
    dq_head_tile = Q_ROPE_H_TILE
    if tile_rows >= Q_DEQUANT_WORKERS * Q_ROPE_T_TILE and tile_rows % (Q_DEQUANT_WORKERS * Q_ROPE_T_TILE) == 0:
        dq_head_tile = H
    elif tile_rows >= Q_DEQUANT_WORKERS * Q_ROPE_T_TILE * 16 // H and tile_rows % (Q_DEQUANT_WORKERS * Q_ROPE_T_TILE * 16 // H) == 0:
        dq_head_tile = 16
    for dq_work in pl.range(worker, (tile_rows + Q_ROPE_T_TILE - 1) // Q_ROPE_T_TILE * (H // dq_head_tile), Q_DEQUANT_WORKERS):
        hg = dq_work % (H // dq_head_tile) * dq_head_tile
        tg = dq_work // (H // dq_head_tile) * Q_ROPE_T_TILE
        out_tg = tile_base + tg
        if tg + Q_ROPE_T_TILE <= tile_rows:
            qr_scale_dq_t = qr_scale_pad_store[tg:tg + Q_ROPE_T_TILE, :]
            q_cos_il = rope_cos_il[out_tg:out_tg + Q_ROPE_T_TILE, :]
            q_sin_signed = rope_sin_signed[out_tg:out_tg + Q_ROPE_T_TILE, :]
            q_swap_idx = rope_swap_idx[out_tg:out_tg + Q_ROPE_T_TILE, :]
            for h_inner in pl.pipeline(dq_head_tile, stage=2):
                h = hg + h_inner
                h0 = h * HEAD_DIM
                q_head_acc = q_proj_i32[tg:tg + Q_ROPE_T_TILE, h0:h0 + HEAD_DIM]
                q_head_scale = pl.reshape(wq_b_scale[h0:h0 + HEAD_DIM], [1, HEAD_DIM])
                q_head_acc_fp32 = pl.cast(q_head_acc, target_type=pl.FP32, mode='none')
                q_head_scale_combined = pl.col_expand_mul(pl.row_expand_mul(pl.full([Q_ROPE_T_TILE, HEAD_DIM], dtype=pl.FP32, value=1.0), qr_scale_dq_t), q_head_scale)
                q_head_dq = pl.mul(q_head_acc_fp32, q_head_scale_combined)
                q_head_dq = pl.cast(pl.cast(q_head_dq, pl.BF16, mode='rint'), pl.FP32)
                q_head_sq = pl.mul(q_head_dq, q_head_dq)
                q_sq_04 = pl.add(q_head_sq[:, 0:64], q_head_sq[:, 256:320])
                q_sq_15 = pl.add(q_head_sq[:, 64:128], q_head_sq[:, 320:384])
                q_sq_26 = pl.add(q_head_sq[:, 128:192], q_head_sq[:, 384:448])
                q_sq_37 = pl.add(q_head_sq[:, 192:256], q_head_sq[:, 448:512])
                q_sq_0246 = pl.add(q_sq_04, q_sq_26)
                q_sq_1357 = pl.add(q_sq_15, q_sq_37)
                q_sq_64 = pl.add(q_sq_0246, q_sq_1357)
                q_head_sq_row = pl.row_sum(q_sq_64)
                q_head_sq_sum = pl.reshape(q_head_sq_row, [1, Q_ROPE_T_TILE])
                q_head_sq_mean = pl.mul(q_head_sq_sum, 1.0 / HEAD_DIM)
                q_head_var = pl.add(q_head_sq_mean, EPS)
                q_head_inv_rms = pl.rsqrt(q_head_var, high_precision=True)
                q_head_inv_rms_t = pl.reshape(q_head_inv_rms, [Q_ROPE_T_TILE, 1])
                q_nope_normed = pl.row_expand_mul(q_head_dq[:, 0:NOPE_DIM], q_head_inv_rms_t)
                q_nope_bf16 = pl.cast(q_nope_normed, target_type=pl.BF16, mode='rint')
                q_flat[out_tg:out_tg + Q_ROPE_T_TILE, h0:h0 + NOPE_DIM] = q_nope_bf16
                q_rope_chunk_raw = q_head_dq[:, NOPE_DIM:HEAD_DIM]
                q_rope_chunk = pl.row_expand_mul(q_rope_chunk_raw, q_head_inv_rms_t)
                q_rope_chunk = pl.cast(pl.cast(q_rope_chunk, pl.BF16, mode='rint'), pl.FP32)
                q_rope_swapped = pl.gather(q_rope_chunk, dim=-1, index=q_swap_idx)
                q_rope_base = pl.mul(q_rope_chunk, q_cos_il)
                q_rope_delta = pl.mul(q_rope_swapped, q_sin_signed)
                q_rope_rot = pl.add(q_rope_base, q_rope_delta)
                q_rope_bf16 = pl.cast(q_rope_rot, target_type=pl.BF16, mode='rint')
                q_flat[out_tg:out_tg + Q_ROPE_T_TILE, h0 + NOPE_DIM:h0 + HEAD_DIM] = q_rope_bf16
        else:
            valid_tail_rows = tile_rows - tg
            qr_scale_dq_tail = pl.load(qr_scale_pad_store, [tg, 0], [Q_ROPE_T_TILE, 1], target_memory=pl.MemorySpace.Vec)
            q_cos_il_tail = pl.load(rope_cos_il, [out_tg, 0], [Q_ROPE_T_TILE, ROPE_DIM], valid_shape=[valid_tail_rows, ROPE_DIM], target_memory=pl.MemorySpace.Vec)
            q_sin_signed_tail = pl.load(rope_sin_signed, [out_tg, 0], [Q_ROPE_T_TILE, ROPE_DIM], valid_shape=[valid_tail_rows, ROPE_DIM], target_memory=pl.MemorySpace.Vec)
            q_col = pl.col_expand_mul(pl.tile.full([Q_ROPE_T_TILE, ROPE_DIM], dtype=pl.FP32, value=1.0), pl.cast(pl.tile.arange(0, [1, ROPE_DIM], dtype=pl.INT32), target_type=pl.FP32))
            q_dup_f = pl.cast(pl.cast(pl.mul(q_col, 0.5), target_type=pl.INT32, mode='trunc'), pl.FP32)
            q_lane = pl.sub(q_col, pl.mul(q_dup_f, 2.0))
            q_swap_f = pl.sub(pl.add(q_col, 1.0), pl.mul(q_lane, 2.0))
            q_row_seed = pl.mul(pl.cast(pl.tile.arange(0, [1, Q_ROPE_T_TILE], dtype=pl.INT32), target_type=pl.FP32), ROPE_DIM_SCALE)
            q_row_grid = pl.col_expand_mul(pl.tile.full([ROPE_DIM, Q_ROPE_T_TILE], dtype=pl.FP32, value=1.0), q_row_seed)
            q_row_offset = pl.transpose(q_row_grid, axis1=0, axis2=1)
            q_swap_idx_tail = pl.cast(pl.add(q_swap_f, q_row_offset), target_type=pl.INT32)
            q_head_reduce_tmp = pl.create_tile([Q_ROPE_T_TILE, 64], dtype=pl.FP32, target_memory=pl.MemorySpace.Vec)
            q_rsqrt_tmp = pl.create_tile([Q_ROPE_T_TILE, 1], dtype=pl.FP32, target_memory=pl.MemorySpace.Vec)
            q_gather_tmp = pl.create_tile([Q_ROPE_T_TILE, ROPE_DIM], dtype=pl.INT32, target_memory=pl.MemorySpace.Vec)
            for h_inner_tail in pl.range(dq_head_tile):
                h_tail = hg + h_inner_tail
                h0_tail = h_tail * HEAD_DIM
                q_head_acc_tail = pl.load(q_proj_i32, [tg, h0_tail], [Q_ROPE_T_TILE, HEAD_DIM], target_memory=pl.MemorySpace.Vec)
                q_head_scale_input_tail = pl.load(wq_b_scale, [h0_tail], [HEAD_DIM], target_memory=pl.MemorySpace.Vec)
                q_head_scale_tail = pl.reshape(q_head_scale_input_tail, [1, HEAD_DIM])
                q_head_acc_fp32_tail = pl.cast(q_head_acc_tail, target_type=pl.FP32, mode='none')
                q_head_scale_combined_tail = pl.col_expand_mul(pl.row_expand_mul(pl.tile.full([Q_ROPE_T_TILE, HEAD_DIM], dtype=pl.FP32, value=1.0), qr_scale_dq_tail), q_head_scale_tail)
                q_head_dq_tail = pl.mul(q_head_acc_fp32_tail, q_head_scale_combined_tail)
                q_head_dq_tail = pl.cast(pl.cast(q_head_dq_tail, pl.BF16, mode='rint'), pl.FP32)
                q_head_sq_tail = pl.mul(q_head_dq_tail, q_head_dq_tail)
                q_sq_04_tail = pl.add(q_head_sq_tail[:, 0:64], q_head_sq_tail[:, 256:320])
                q_sq_15_tail = pl.add(q_head_sq_tail[:, 64:128], q_head_sq_tail[:, 320:384])
                q_sq_26_tail = pl.add(q_head_sq_tail[:, 128:192], q_head_sq_tail[:, 384:448])
                q_sq_37_tail = pl.add(q_head_sq_tail[:, 192:256], q_head_sq_tail[:, 448:512])
                q_sq_0246_tail = pl.add(q_sq_04_tail, q_sq_26_tail)
                q_sq_1357_tail = pl.add(q_sq_15_tail, q_sq_37_tail)
                q_sq_64_tail = pl.add(q_sq_0246_tail, q_sq_1357_tail)
                q_head_sq_sum_tail = pl.row_sum(q_sq_64_tail, q_head_reduce_tmp)
                q_head_var_tail = pl.add(pl.mul(q_head_sq_sum_tail, 1.0 / HEAD_DIM), EPS)
                q_head_inv_rms_tail = pl.tile.rsqrt(q_head_var_tail, q_rsqrt_tmp)
                q_nope_normed_tail = pl.row_expand_mul(q_head_dq_tail[:, 0:NOPE_DIM], q_head_inv_rms_tail)
                q_nope_bf16_tail = pl.cast(q_nope_normed_tail, target_type=pl.BF16, mode='rint')
                q_nope_valid = pl.set_validshape(q_nope_bf16_tail, valid_tail_rows, NOPE_DIM)
                pl.store(q_nope_valid, [out_tg, h0_tail], q_flat)
                q_rope_chunk_raw_tail = q_head_dq_tail[:, NOPE_DIM:HEAD_DIM]
                q_rope_chunk_tail = pl.row_expand_mul(q_rope_chunk_raw_tail, q_head_inv_rms_tail)
                q_rope_chunk_tail = pl.cast(pl.cast(q_rope_chunk_tail, pl.BF16, mode='rint'), pl.FP32)
                q_rope_swapped_tail = pl.tile.gather(q_rope_chunk_tail, q_swap_idx_tail, q_gather_tmp)
                q_rope_chunk_tail = pl.set_validshape(q_rope_chunk_tail, valid_tail_rows, ROPE_DIM)
                q_rope_swapped_tail = pl.set_validshape(q_rope_swapped_tail, valid_tail_rows, ROPE_DIM)
                q_rope_base_tail = pl.mul(q_rope_chunk_tail, q_cos_il_tail)
                q_rope_delta_tail = pl.mul(q_rope_swapped_tail, q_sin_signed_tail)
                q_rope_rot_tail = pl.add(q_rope_base_tail, q_rope_delta_tail)
                q_rope_bf16_tail = pl.cast(q_rope_rot_tail, target_type=pl.BF16, mode='rint')
                q_rope_valid = pl.set_validshape(q_rope_bf16_tail, valid_tail_rows, ROPE_DIM)
                pl.store(q_rope_valid, [out_tg, h0_tail + NOPE_DIM], q_flat)
    return q_flat
