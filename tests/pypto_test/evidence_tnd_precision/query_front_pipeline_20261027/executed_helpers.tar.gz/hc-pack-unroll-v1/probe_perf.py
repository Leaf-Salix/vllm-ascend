"""完整CSA布局候选：先性能筛选，只有收益候选再对Native验精度。"""
import argparse
import contextlib
import hashlib
import importlib
import json
import os
from pathlib import Path
import statistics
import sys
import types

import torch
import torch_npu
import pypto.torch
from vllm.config import CUDAGraphMode
from vllm.engine.arg_utils import EngineArgs
from vllm.forward_context import get_forward_context
from vllm.platforms import current_platform
from vllm_ascend.ascend_forward_context import set_ascend_forward_context
import vllm_ascend.ops.dsv4_csa
from dsv4_csa_native_case import native_session
from dsv4_csa_single_layer import make_layer, restore, collect_state, guard_checks
from ragged_fixture import make_ragged_fixture
from npugraph_ex._acl_concrete_graph.acl_graph import AclGraph

ROOT = Path(__file__).resolve().parent
BASE = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
META_SHA = '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--expected-batch', type=int, required=True)
parser.add_argument('--lengths', default='1,1,1,1')
parser.add_argument('--layer', type=int, default=4)
parser.add_argument('--history', type=int, default=8191)
parser.add_argument('--trace', action='store_true')
parser.add_argument('--reverse-capture', action='store_true')
parser.add_argument('--qualify-boundary', action='store_true')
args = parser.parse_args()
lengths = list(map(int,args.lengths.split(',')))
tokens, batch = sum(lengths), len(lengths)
assert batch==args.expected_batch, ('batch label differs from actual query count',batch,args.expected_batch)
assert all(1<=q<=6 for q in lengths) and batch<=40 and 0<tokens<=256
assert not (args.out/'result.json').exists()
args.out.mkdir(parents=True,exist_ok=True)
expected_helpers=json.loads((ROOT/'manifest.json').read_text())
helper_sha={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in expected_helpers}
assert helper_sha==expected_helpers,'helper source identity mismatch'
manifest_sha=hashlib.sha256((ROOT/'manifest.json').read_bytes()).hexdigest()
report = {'helper_sha':helper_sha,'manifest_sha256':manifest_sha,'complete':False,'pass':False,'scope':'real layer weights, synthetic hidden/history, Native/TND complete CSA half-layer FULL graph; not whole model',
          'lengths':lengths,'true_tokens':tokens,'physical_graph_tokens':tokens,'per_request_padding':0,
          'hypothetical_s6_tokens':batch*6,'hypothetical_s6_extra_rows':batch*6-tokens,
          'baseline_experiment':'Native direct HC-pre through HC-post', 'candidate_experiment':'accepted Direct vs HC input packing copy unroll32; performance first',
          'candidate_variant':'Only hc_pack_input_bf16 32 independent copy iterations statically unrolled; same cast,transpose,assemble addresses and all math/handshakes; no other candidates combined',
          'layer':args.layer,'history':args.history,'graphs':{},'comparisons':{},'static':{}}
def save():
    (args.out/'result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
def exact(x,y):
    return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def metric(x,y):
    if x.shape!=y.shape or x.dtype!=y.dtype:
        return {'bit_equal':False,'shapes':[list(x.shape),list(y.shape)],'dtypes':[str(x.dtype),str(y.dtype)]}
    if x.is_floating_point():
        assert bool(torch.isfinite(x).all()) and bool(torch.isfinite(y).all()), 'nonfinite external float boundary'
    equal=exact(x,y)
    delta=x.float()-y.float()
    return {'bit_equal':equal,'different_elements':int((x!=y).sum()),'max_abs':float(delta.abs().max()),
            'relative_l2':float(torch.linalg.vector_norm(delta)/torch.linalg.vector_norm(y.float()).clamp_min(1e-30)),
            'first_coordinates':(x!=y).nonzero()[:6].tolist()}

from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.native_adapter import CSAOperators
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.service import CSAServiceRuntime
from source_identity import source_identity
from load_candidate import operators_for
source_record=source_identity()
candidate_proof=json.loads((ROOT/'SOURCE.json').read_text())
report['isolated_candidates']=candidate_proof
report['sdk']=json.loads(Path(os.environ['PREFLIGHT_RECEIPT']).read_text())
for compile_arm in ('baseline','candidate'):
    receipt=json.loads((ROOT/('cpu-'+compile_arm)/'receipt.json').read_text())
    assert receipt['pass'] and receipt['device_execution'] is False and receipt['source']==source_record
    assert receipt['arm']==compile_arm
    for key in ('source_heads','binary_sha256','ptoas_binary_sha256'):
        assert receipt['sdk'][key]==report['sdk'][key],key
    assert receipt['helper_manifest_sha256']==manifest_sha
    assert receipt['npu_initialized'] is False and receipt['root_tensors']==64
    assert receipt['candidate_source_sha256']==hashlib.sha256((ROOT/'SOURCE.json').read_bytes()).hexdigest()
report['no_device_compile_pass']=True
report.update(source_record)
import vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.decode_csa as formal_root
package=Path(formal_root.__file__).resolve().parent
assert package.is_relative_to(Path(os.environ['SOURCE_ROOT']).resolve())
report['candidate_sources']={q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in package.glob('*.py')}
report['candidate_package']=str(package)
report['compile_receipt_sha256']=source_record['canonical_compile_receipt_sha256']
report['formal_root_file']=formal_root.__file__

class NativeHalf(torch.nn.Module):
    def __init__(self,layer):
        super().__init__();self.layer=layer
    def forward(self,hidden,positions,output):
        l=self.layer
        mixed,post,comb=l.hc_pre(hidden,l.hc_attn_fn,l.hc_attn_scale,l.hc_attn_base)
        normed=l.input_layernorm(mixed)
        attended=l.self_attn(positions=positions,hidden_states=normed,llama_4_scaling=None)
        output.copy_(l.hc_post(attended,hidden,post,comb))
        return output

class PTOHalf(torch.nn.Module):
    def __init__(self,prefix):
        super().__init__();self.prefix=prefix
    def forward(self,hidden,positions,output):
        torch.ops.vllm.dsv4_csa_forward(hidden,positions,output,self.prefix)
        return output

class RequirePTO:
    def __init__(self,delegate):
        self.delegate,self.calls=delegate,0
    def eligible(self,*values):
        if not self.delegate.eligible(*values):
            raise RuntimeError('Unexpected PTO fallback')
        return True
    def __call__(self,*values,**kwargs):
        self.calls+=1
        return self.delegate(*values,**kwargs)

current_platform.pre_register_and_update()
torch.npu.set_device(0)
torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
from vllm_ascend.utils import enable_custom_op
assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,
 tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},
 max_model_len=max(16384,args.history+128),max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,
 enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},
 compilation_config={'cudagraph_mode':'FULL_DECODE_ONLY','cudagraph_capture_sizes':[tokens],'cache_dir':str(args.out/'vllm-cache')},
 additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},
 'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False,'multistream_dsv4_dsa_overlap':True}).create_engine_config()

states, fixtures, rows, keepalive, b_states = {}, {}, {}, [], {}
packets_by_arm = {}
save()
try:
 with native_session(config,0),torch.inference_mode():
    layer,details=make_layer(config,checkpoint,torch.device('npu:0'),args.layer)
    report['weight_details']=details
    report['native_DSA_multistream_config']=bool(layer.self_attn.dsa_attn.dsa_attn.impl.multistream_dsv4_dsa_overlap)
    assert report['native_DSA_multistream_config']
    ring_kwargs={} if args.history<131000 else {'ring_heap':tuple(m*1024**2 for m in (56,96,176,1)),'ring_task_window':2048}
    report['explicit_runtime_init_kwargs']=ring_kwargs
    pypto.torch.init(enable_chip_swimlane=1,enable_dep_gen=False,output_dir=args.out/'dfx',**ring_kwargs)
    impl=layer.self_attn.dsa_attn.dsa_attn.impl
    observed={}
    original_qli=torch.ops._C_ascend.npu_vllm_quant_lightning_indexer
    def observe_qli(*values,**kwargs):
        result=original_qli(*values,**kwargs);observed['topk']=result[0];return result
    torch.ops._C_ascend.npu_vllm_quant_lightning_indexer=observe_qli
    # 保留原13包校验桥；只在首次真实reselect后复用选择，禁止捕获之后变更选择。
    selection=[]
    original_reselect=torch_npu.npu._aclnn_reselect_static_kernel
    def qualified_reselect(*values,**kwargs):
        assert hashlib.sha256((Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE'])/'metadata.json').read_bytes()).hexdigest()==META_SHA
        assert not values and not kwargs
        if not selection:
            selection.append(original_reselect())
            report['static']['actual_reselect_count']=1
        else:
            report['static']['validated_reuses']=report['static'].get('validated_reuses',0)+1
        report['static']['metadata_sha256']=META_SHA
        return selection[0]
    # 框架可能已from-import compile_static_kernel；在实际API边界观测，避免漏掉别名调用。
    torch_npu.npu._aclnn_reselect_static_kernel=qualified_reselect

    capture_order=('native','candidate','baseline') if args.reverse_capture else ('native','baseline','candidate')
    report['planned_capture_order']=list(capture_order)
    report['actual_capture_order']=[]
    for arm in capture_order:
        assert torch.are_deterministic_algorithms_enabled()
        assert torch_npu._C._npu_get_deterministic_level()==1
        assert os.environ.get('HCCL_DETERMINISTIC')=='true'
        print('ARM_START',arm,flush=True)
        torch._dynamo.reset()
        f=make_ragged_fixture(config,layer.self_attn,batch,args.history,1024,torch.device('npu:0'),lengths)
        idx_group=f['groups']['indexer']
        scale=idx_group['views'][1]
        scale_rows=torch.arange(scale.numel(),dtype=torch.int64,device=scale.device)
        scale.copy_((0.00390625+((scale_rows*37)%251).float()/16384).to(scale.dtype).reshape(scale.shape))
        idx_group['initial']=idx_group['allocation'].cpu()
        fixtures[arm]=f
        if arm!='native':
            for field in ('hidden','positions'):
                assert exact(f[field],fixtures['native'][field]),(arm,field)
            for name,g in f['groups'].items():
                assert exact(g['initial'],fixtures['native']['groups'][name]['initial']),(arm,name)
            assert f['readonly'].keys()==fixtures['native']['readonly'].keys()
            for name,(_,snapshot) in f['readonly'].items():
                assert exact(snapshot,fixtures['native']['readonly'][name][1]),(arm,name,'metadata input')
            for name,parts in f['compact'].items():
                assert all(exact(x,y) for x,y in zip(parts,fixtures['native']['compact'][name],strict=True)),(arm,name,'compact input')
        runtime=None
        if arm!='native':
            operators=operators_for(arm)
            with torch.inference_mode(False), torch.enable_grad():
                keepalive.append(layer.hc_attn_fn)  # Retain captured Native weight storage.
                layer.hc_attn_fn=torch.nn.Parameter(layer.hc_attn_fn.detach().clone(),requires_grad=True)
                runtime_type=CSAServiceRuntime
                if arm in ('baseline','candidate'):
                    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_combined.service import CSAServiceRuntime as CombinedRuntime
                    runtime_type=CombinedRuntime
                runtime=runtime_type(layer.self_attn,operators,40,layer)
                report['model_loading_prepare_context']={'grad_enabled_after_constructor':torch.is_grad_enabled(),'source_requires_grad':layer.hc_attn_fn.requires_grad,'source_inference':torch.is_inference(layer.hc_attn_fn),'packed_requires_grad':runtime.weights['hc_packed_weight'].requires_grad}
                assert torch.is_grad_enabled() and layer.hc_attn_fn.requires_grad
                assert not runtime.weights['hc_packed_weight'].requires_grad

            from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.workspace import NORM_PARAMETERS
            norm_offset=0
            norm_packet_checks={}
            for name,size in NORM_PARAMETERS:
                norm_packet_checks[name]=exact(runtime.norm_packet[norm_offset:norm_offset+size].cpu(),runtime.weights[name].cpu())
                norm_offset+=size
            assert norm_offset==6272 and all(norm_packet_checks.values())
            order_checks={}
            for (w,i,o),packet in operators.workspace.order_packets.items():
                cpu=packet.cpu()
                order_checks[str((w,i,o))]=all((exact(cpu[:512],runtime.wkv_orders[w].cpu().reshape(-1)),
                    exact(cpu[512:1536],runtime.indexer_orders[i].cpu().reshape(-1)),
                    exact(cpu[1536:],runtime.oproj_starts[o].cpu().reshape(-1))))
            assert len(order_checks)==33 and all(order_checks.values())
            report['packet_checks']={'norm_byte_equal':norm_packet_checks,'order_byte_equal':order_checks,
                'norm_bytes_per_layer':runtime.norm_packet.numel()*runtime.norm_packet.element_size(),
                'order_bytes_per_model':sum(t.numel()*t.element_size() for t in operators.workspace.order_packets.values())}
            readonly_packets={'norm':runtime.norm_packet,'hc_packed':runtime.weights['hc_packed_weight'],**{str(k):v for k,v in operators.workspace.order_packets.items()}}
            packet_snapshots={k:v.cpu() for k,v in readonly_packets.items()}
            report['hc_weight_qualification']=dict(runtime.hc_weight_qualification)
            assert report['hc_weight_qualification']['version']==1
            assert selection,'Native graph did not install and select static packages'
            runtime.qualify_static_wkv(metadata_sha256=META_SHA,reselected=True)
        @contextlib.contextmanager
        def context():
            with set_ascend_forward_context(f['metadata'],config,num_tokens=tokens,num_actual_tokens=tokens,
                                            aclgraph_runtime_mode=CUDAGraphMode.FULL):
                assert get_forward_context().cudagraph_runtime_mode is CUDAGraphMode.FULL
                yield
        if runtime is not None:
            with context():
                eligible=runtime.eligible(get_forward_context(),f['hidden'],f['positions'])
            report.setdefault('entry',{})[arm]={'eligible':eligible,'route':'PTO' if eligible else 'Native fallback','metadata':{
                name:{'bounds':f['metadata'][g['prefix']].decode.query_start_loc.cpu().tolist(),
                      'max_q':f['metadata'][g['prefix']].decode.max_seqlen_q,
                      'num_decodes':f['metadata'][g['prefix']].num_decodes,
                      'actual_tokens':f['metadata'][g['prefix']].num_actual_tokens} for name,g in f['groups'].items()}}
            save()
            assert eligible, 'TND precision fallback is forbidden'
            guarded=RequirePTO(runtime)
            layer.self_attn.dsa_attn._pto_csa_runtime=guarded
        else:
            layer.self_attn.dsa_attn._pto_csa_runtime=None
        output=torch.empty_like(f['hidden'])
        module=NativeHalf(layer) if arm=='native' else PTOHalf(layer.self_attn.dsa_attn.prefix)
        restore(f)
        with context():module(f['hidden'],f['positions'],output)
        torch.npu.synchronize()
        instances={}
        old_run=AclGraph.run
        def record(owner,key,*values,**kwargs):
            instances[(id(owner),key)]=owner
            return old_run(owner,key,*values,**kwargs)
        AclGraph.run=record
        options={'force_eager':False,'inplace_pass':True,'clone_input':False,'clone_output':False,
                 'static_kernel_compile':True,'super_kernel_optimize':False}
        torch.npu.set_compile_mode(jit_compile=False)
        try:
            compiled=torch.compile(module,backend='npugraph_ex',fullgraph=True,dynamic=False,options=options)
            restore(f)
            with context():compiled(f['hidden'],f['positions'],output)
            torch.npu.synchronize()
            assert len(instances)==1,(arm,'not exactly one actual graph',len(instances))
            (_,key),owner=next(iter(instances.items()))
            assert not owner._updated_node_infos,'Host updated nodes invalidate raw replay test'
            graph=owner.graph[key]
        finally:
            AclGraph.run=old_run
        topk=runtime.topk[:tokens] if runtime is not None and report['entry'][arm]['eligible'] else observed['topk']
        # Execution-validity checks only; no Native/PTO numerical comparison yet.
        restore(f);output.fill_(float('nan'));topk.fill_(-12345);graph.replay();torch.npu.synchronize()
        assert bool(torch.isfinite(output).all()),(arm,'nonfinite output')
        assert not bool((topk==-12345).any()),(arm,'unwritten TopK')
        guards=guard_checks(f)
        assert all(value['status']=='PASS' for value in guards.values()),(arm,'guard',guards)
        states[arm]=collect_state(f,output,topk)
        rows[arm]=(graph,f,output,topk)
        keepalive.append((compiled,module,owner,runtime))
        report['graphs'][arm]={'actual_acl_graph':True,'fullgraph':True,'options':options,
            'true_tokens':tokens,'graph_tokens':tokens,'guards':guards,'output_poison_written':True}
        if runtime is not None:
            assert guarded.calls>0,'PTO runtime was never invoked'
            selected_op=runtime.operators.attention.for_tokens(tokens) if hasattr(runtime.operators.attention,'for_tokens') else runtime.operators.attention
            schema=str(selected_op._schema)
            expected='csa_directpub_'+arm+'::attention'
            assert schema.startswith(expected+'(') and schema.split(' -> ')[0].count('Tensor')==64,(arm,schema)
            report['graphs'][arm].update(root_schema=schema,pto_dispatch_calls=guarded.calls)
            packets_by_arm[arm]=(readonly_packets,packet_snapshots)
        save()
        report['actual_capture_order'].append(arm)
        save()
        print('ARM_CAPTURED_NO_ACCURACY_COMPARISON',arm,flush=True)
    def restore_readonly(fixture):
        for live,expected in fixture['readonly'].values():live.copy_(expected)
    report['test_order']='performance persisted first; then Native precision if query-island wins or explicit boundary regression'
    report['accuracy_executed']=False
    arms=('baseline','candidate')
    report['performance']={'event_windows':[],'l1_windows':[],'replays_per_event_window':100,
        'warmup':3,'dep_gen':False,'criterion':'positive event median and >=10/12 paired wins; L1 median faster; gains need independent repeat'}
    report['execution_checks']=[]
    def check_execution(arm,phase,repeat):
        graph,f,output,topk=rows[arm]
        assert bool(torch.isfinite(output).all()),(arm,phase,repeat,'nonfinite output')
        guards=guard_checks(f)
        assert all(g['status']=='PASS' for g in guards.values()),(arm,phase,repeat,guards)
        live,snapshots=packets_by_arm[arm]
        assert all(exact(v.cpu(),snapshots[k]) for k,v in live.items()),(arm,phase,repeat,'readonly packet')
        report['execution_checks'].append({'arm':arm,'phase':phase,'repeat':repeat,'guards':len(guards),'pass':True})
    for arm in arms:
        graph,f,output,topk=rows[arm]
        restore(f);restore_readonly(f);torch.npu.synchronize()
        for _ in range(3):graph.replay()
        torch.npu.synchronize()
        check_execution(arm,'warmup',0)
    # Each round changes order to balance clock and position effects.
    for repeat in range(12):
        offset=repeat%len(arms)
        order=list(arms[offset:]+arms[:offset])
        for arm in order:
            graph,f,output,topk=rows[arm]
            restore(f);restore_readonly(f);torch.npu.synchronize()
            start=torch.npu.Event(enable_timing=True);end=torch.npu.Event(enable_timing=True)
            start.record()
            for _ in range(100):graph.replay()
            end.record();end.synchronize()
            value=start.elapsed_time(end)*1000/100
            report['performance']['event_windows'].append({'repeat':repeat,'arm':arm,'order':order,'us':value})
            check_execution(arm,'event',repeat)
            print('EVENT_WINDOW',repeat,arm,value,flush=True)
    dfx_index=0
    for repeat in range(9):
        offset=repeat%len(arms)
        order=list(arms[offset:]+arms[:offset])
        for arm in order:
            graph,f,output,topk=rows[arm]
            restore(f);restore_readonly(f);torch.npu.synchronize()
            pypto.torch.begin_dfx();graph.replay();pypto.torch.end_dfx()
            raw_path=args.out/'dfx'
            if dfx_index:raw_path=raw_path/f'window_{dfx_index}'
            raw_path=raw_path/'chip_swimlane_records.json'
            raw=json.loads(raw_path.read_text());records=raw['aicore_tasks'];frequency=raw['metadata']['clock_freq_hz']
            assert raw['chip_swimlane_level']==1 and frequency>0
            assert raw['metadata']['core_types']==['aic']*24+['aiv']*48
            assert raw['metadata']['dropped_run_boundaries']==0 and len(raw['metadata']['run_boundaries'])==1
            assert {r[0] for r in records}==set(range(72))
            assert all(len(r)==6 and 0<r[3]<=r[4] for r in records)
            span=(max(r[4] for r in records)-min(r[3] for r in records))*1e6/frequency
            report['performance']['l1_windows'].append({'repeat':repeat,'arm':arm,'order':order,'us':span,'raw':str(raw_path)})
            check_execution(arm,'l1',repeat)
            print('L1_WINDOW',repeat,arm,span,flush=True)
            dfx_index+=1
    summary={}
    for arm in arms:
        event=[r['us'] for r in report['performance']['event_windows'] if r['arm']==arm]
        l1=[r['us'] for r in report['performance']['l1_windows'] if r['arm']==arm]
        summary[arm]={'event_us':event,'event_median_us':statistics.median(event),
                      'l1_us':l1,'l1_median_us':statistics.median(l1)}
        graph,f,output,topk=rows[arm]
        assert bool(torch.isfinite(output).all())
        assert all(g['status']=='PASS' for g in guard_checks(f).values()),(arm,'post-performance guards')
        live,snapshots=packets_by_arm[arm]
        assert all(exact(v.cpu(),snapshots[k]) for k,v in live.items()),(arm,'readonly packet')
    paired={}
    candidate=summary['candidate']
    for control_arm in ('baseline',):
        control=summary[control_arm]
        improvement=1-candidate['event_median_us']/control['event_median_us']
        wins=sum(a<b for a,b in zip(candidate['event_us'],control['event_us'],strict=True))
        paired[control_arm]={'event_improvement':improvement,'paired_event_wins':wins,
                             'l1_improvement':1-candidate['l1_median_us']/control['l1_median_us']}
    qualified=all(v['event_improvement']>=0.005 and v['paired_event_wins']>=10 and v['l1_improvement']>0 for v in paired.values())
    report['performance']['candidate_vs_control']=paired
    report['performance']['criterion']='query-island >=0.5% lower event median vs accepted Direct control, >=10/12 wins each, L1 lower; independent reverse repeat'
    winners=['candidate'] if qualified else []
    report['performance']['summary']=summary
    report['performance']['winners']=winners
    report['precision_regression_reason']='explicit boundary qualification after performance; never infer it from performance status' if args.qualify_boundary else 'precision only after Direct-versus-query-island two-arm performance screen'
    precision_arms=['native',*arms] if qualified or args.qualify_boundary else []
    report['timing_executed']=True
    save()
    print('PERFORMANCE_SCREEN_COMPLETE',json.dumps(summary),winners,flush=True)
    # Only after the performance result is persisted do we begin numerical A/B.
    for arm in precision_arms:
        graph,f,output,topk=rows[arm]
        restore(f);restore_readonly(f);graph.replay();torch.npu.synchronize()
        actual=collect_state(f,output,topk)
        if arm=='native':
            reference=actual
        else:
            checks={name:metric(value,reference[name]) for name,value in actual.items()}
            report['comparisons'][arm]=checks;report['accuracy_executed']=True;save()
            if not all(m['bit_equal'] for m in checks.values()):
                report['first_failed_arm']=arm
                report['failed_boundaries']=[n for n,m in checks.items() if not m['bit_equal']]
                raise RuntimeError(arm+': first accuracy difference after performance; stop')
        before=f['hidden'].clone()
        restore(f);f['hidden'].add_(0.125);graph.replay();torch.npu.synchronize()
        b_states[arm]=collect_state(f,output,topk)
        if arm!='native':
            checks={name:metric(value,b_states['native'][name]) for name,value in b_states[arm].items()}
            report.setdefault('B_comparisons',{})[arm]=checks;save()
            if not all(m['bit_equal'] for m in checks.values()):raise RuntimeError(arm+': first B accuracy difference')
        f['hidden'].copy_(before);restore(f);graph.replay();torch.npu.synchronize()
        restored=collect_state(f,output,topk)
        assert all(exact(v,actual[n]) for n,v in restored.items()),(arm,'ABA')
        assert all(g['status']=='PASS' for g in guard_checks(f).values()),(arm,'precision guards')
        report['graphs'][arm]['live_input_ABA']=True
        save()
    report['accuracy_skipped_for']=[a for a in arms if a not in precision_arms]
    if precision_arms:
        for a in arms:
            assert len(report['comparisons'][a])==len(report['B_comparisons'][a])==8
            assert all(v['bit_equal'] for v in report['comparisons'][a].values())
            assert all(v['bit_equal'] for v in report['B_comparisons'][a].values())
        assert all(report['graphs'][a]['live_input_ABA'] for a in ('native',*arms))
    report['complete']=True
    report['pass']=True
    save()
except Exception as exc:
    report['error']=repr(exc)
    save()
    torch.save({'states':states,'b_states':b_states,'inputs':{arm:{'hidden':f['hidden'].cpu(),'positions':f['positions'].cpu(),
                    'initial':{name:g['initial'] for name,g in f['groups'].items()}} for arm,f in fixtures.items()}},args.out/'first-difference.pt')
    raise
print('COMPLETE',report['pass'],lengths,flush=True)
