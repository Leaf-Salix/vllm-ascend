# HC输入布局复制静态展开单因素

依据前段最大差距和实际HC Vector跨度约185us，先只改布局复制中的Scalar循环。把每个256列panel内32个独立8列块的重复复制从运行时循环改成静态展开；保留先FP32到BF16、transpose、两次assemble和最后transpose/GM store，输入尾行清零、每worker分配与所有同步不变。纯DSL，不改SDK或数学。

不是nalinaly同一实现：nalinaly可用不同HC数学链，本候选只借鉴减少Scalar调度的原则。每列j在复制后对应2个8列区组：dst16*(j//8)+(j%8)与其+8，必须0..511各覆盖一次。

先CPU编译检查：只允许prefix Vector leaf变化，Cube及其余leaf逐SHA相同，检查生成物确实无32次运行时循环；然后8K/B32完整FULL graph性能，>=0.5%/10wins/L1更低后才Native A/B8/ABA及反向重复。不继承128K或整模型资格。
