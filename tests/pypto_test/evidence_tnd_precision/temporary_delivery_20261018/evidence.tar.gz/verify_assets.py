"""无设备逐文件比较交付冻结清单；缺失或SHA变化立即失败。"""
import argparse
import hashlib
import json
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('assets',type=Path)
args=parser.parse_args()
assets=json.loads(args.assets.read_text())
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024*1024),b''):h.update(block)
    return h.hexdigest()
verified={}
def check(row):
    p=Path(row['path'])
    assert p.is_file(),('missing frozen dependency',str(p))
    assert p.stat().st_size==row['bytes'],('size changed',str(p))
    actual=verified.get(str(p))
    if actual is None:
        actual=sha(p);verified[str(p)]=actual
    assert actual==row['sha256'],('SHA changed',str(p))
for group in ('private_verified_files','private_extensions','static_verified_packages',
              'simpler_python_files','vllm_python_files','toolchain_and_selected_libraries'):
    assert assets[group],('empty dependency group',group)
    for row in assets[group].values():check(row)
for row in assets['modules'].values():check(row['entry'])
for group in ('private_package_manifest','static_metadata','source_manifest'):check(assets[group])
manifest_path=Path(assets['source_manifest']['path'])
source=manifest_path.parent/'source'
manifest=json.loads(manifest_path.read_text())
for name,digest in manifest['files'].items():
    p=source/name
    assert p.is_file(),('missing source',name)
    assert sha(p)==digest,('source SHA changed',name)
print('FROZEN_ASSETS_PASS',len(verified),'dependencies',len(manifest['files']),'source files',flush=True)
