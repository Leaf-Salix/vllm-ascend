#!/usr/bin/env bash
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
job="$base/tnd-precision-delivery-20261018"
export LOW_ACCEPTANCE_RUNTIME_PACKAGE="$base/low-acceptance-20261010/runtime-package"
export LOW_ACCEPTANCE_OFFICIAL_CACHE="$base/low-acceptance-20261010/official-static-cache"
source "$base/root-fix-20261016/env.sh"
export SOURCE_ROOT="$base/full-dsl-single-entry-20261018/single-v1/source"
export PYTHONPATH="$job:$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
export PTO_CSA_VARIANT=tnd_full_precision
export PYTHONNOUSERSITE=1 HCCL_DETERMINISTIC=true
export LOCAL_WORLD_SIZE=1 OMP_NUM_THREADS=4 OMP_PROC_BIND=false
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache
export CMAKE_BUILD_PARALLEL_LEVEL=4
unset ADMISSION_TRACE_DIR FULL_PROBE_DIR FULL_PROBE_MODE LOW_ACCEPTANCE_FIRST_STEP_DIR
