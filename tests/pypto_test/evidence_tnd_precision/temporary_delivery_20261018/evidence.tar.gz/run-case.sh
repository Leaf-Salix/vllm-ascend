#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
source /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/tnd-precision-delivery-20261018/env.sh
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
out="/data/pyptouser/yejia/td18/${1:?}"
mkdir -p /data/pyptouser/yejia/td18
mkdir "$out"
python "$job/preflight.py" > "$out/preflight.log" 2>&1
ccache -s > "$out/ccache.log"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out/opp_env")
export PYPTO_PROG_BUILD_DIR="$out/build" VLLM_CACHE_ROOT="$out/vllm-cache"
export ASCEND_CACHE_PATH="$out/ascend-cache" ASCEND_PROCESS_LOG_PATH="$out/ascend"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/td18.XXXXXX)
trap 'rmdir "$TMPDIR" 2>/dev/null || true' EXIT
cd "$out"
python "$job/probe.py" --out "$out" --lengths "${2:-1,1,1,1}" --layer "${3:-4}" --history "${4:-8191}" > "$out/run.log" 2>&1
