# TND临时精度交付验收（2026-10-18）

- 用户批准：只比较Native/TND；TND首bit差异即定位修正；每任务<15分钟；通过后冻结、文档、commit push。
- [x] 阅读项目AGENTS/CLAUDE、karpathy-guidelines和227环境skill；上轮BSH材料保持原样。
- [x] 建立独立报告/227目录；确认原SDK/静态13包/source manifest未改变。
- [x] 独立审查测试助手；不允许TND回退，真实FULL图/raw replay、TopK与output毒化、输入A/B/A、B也对Native。
- [x] 小任务1：L4/H8191，B4/S1/T4，零请求/图桶padding。
- [x] 小任务2：L4/H8191，B4/S3/T12，零请求/图桶padding。
- [x] 小任务3：L4/H8191，B6/q=[1,2,3,4,5,6]/T21，零请求/图桶padding。
- [x] 必要补充：L26/H8189反向混合；覆盖另一层/压缩相位，按此前结果决定是否需定位。
- [x] 全部输出、TopK、cache/state及保护区门禁通过，首差不执行下一任务。
- [x] 冻结数学文件/依赖、SDK、静态包及助手manifest；保留原性能/精度基准。
- [ ] 项目文档：8K短query/混合FULL范围，原8K/B40与128K/B24整模型192token证据，不扩张未测配置。
- [ ] 写明SK0单层和整模型性能限制，纯DSL当前forward约13.62x/9.51x。
- [ ] 独立结果审查、增量pre-commit、隔离full format门禁；不改历史原件凑通过。
- [ ] 正常signed-off commit并push Leaf-Salix当前branch，验证远端SHA；不force push、不提交PR。
