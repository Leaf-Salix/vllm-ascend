"""无设备核验交付依赖；记录实际文件，不仅记录版本字符串。"""
import hashlib
import importlib
import json
import os
from pathlib import Path
import subprocess

BASE=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
JOB=Path(__file__).parent
ROOT=Path(os.environ['SOURCE_ROOT'])
def record(path):
    p=Path(path)
    h=hashlib.sha256()
    with p.open('rb') as handle:
        for block in iter(lambda:handle.read(4*1024*1024),b''):h.update(block)
    return {'path':str(p),'resolved_path':str(p.resolve()),'sha256':h.hexdigest(),'bytes':p.stat().st_size}
package=Path(os.environ['LOW_ACCEPTANCE_RUNTIME_PACKAGE'])
private=json.loads((package/'manifest.json').read_text())
private_files={name:record(package/name) for name in private['files']}
assert all(row['sha256']==private['files'][name] for name,row in private_files.items())
static_path=Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE'])/'metadata.json'
static=json.loads(static_path.read_text())
static_files={name:record(name) for name in static['packages']}
assert len(static_files)==13 and all(row['sha256']==static['packages'][name] for name,row in static_files.items())
modules={}
for name in ('torch','torch_npu','vllm','vllm_ascend','pypto','simpler','npugraph_ex'):
    m=importlib.import_module(name)
    modules[name]={'version':getattr(m,'__version__',None),'entry':record(m.__file__)}
simple_root=Path(importlib.import_module('simpler').__file__).parent
simpler_files={str(p.relative_to(simple_root)):record(p) for p in sorted(simple_root.rglob('*.py'))}
targets=[Path(os.environ['PTOAS_ROOT'])/'ptoas',Path(static['compiler_path']),Path(os.environ['ATB_HOME_PATH'])/'lib/libatb.so']
npu_root=Path(importlib.import_module('torch_npu').__file__).parent
for name in ('libtorch_npu.so','libop_plugin_atb.so'):
    targets.extend(npu_root.rglob(name))
extension_records={}
for item in private.get('extensions',[]):
    path=item if isinstance(item,str) else item['target']
    extension_records[path]=record(path)
    if isinstance(item,dict):assert extension_records[path]['sha256']==item['sha256']
assert len(extension_records)==2
vllm_root=Path(importlib.import_module('vllm').__file__).parent
vllm_files={str(p.relative_to(vllm_root)):record(p) for p in sorted(vllm_root.rglob('*.py'))}
runtime_build=simple_root.parents[1]/'build'
for pattern in ('libhost_runtime.so','libaicpu*.so'):
    targets.extend(runtime_build.rglob(pattern))
out={'scope':'selected actual runtime dependencies, not a full operating-system image','source_manifest':record(ROOT.parent/'manifest.json'),
     'private_package_manifest':record(package/'manifest.json'),'private_package':private,'private_verified_files':private_files,
     'static_metadata':record(static_path),'static_metadata_content':static,'static_verified_packages':static_files,
     'modules':modules,'simpler_python_files':simpler_files,'vllm_python_files':vllm_files,'private_extensions':extension_records,
     'toolchain_and_selected_libraries':{str(p):record(p) for p in targets if p.is_file()},
     'environment':{n:os.environ.get(n) for n in ('PTOAS_ROOT','ASCEND_HOME_PATH','ATB_HOME_PATH','HCCL_DETERMINISTIC','PTO_CSA_VARIANT','PTO_CSA_RUNTIME')},
     'commits':{}}
for name,path in [('vllm',Path(importlib.import_module('vllm').__file__).parents[1]),('pypto_simpler_reference',simple_root.parents[2])]:
    value=subprocess.run(['git','-C',str(path),'rev-parse','HEAD'],text=True,capture_output=True)
    out['commits'][name]={'path':str(path),'head':value.stdout.strip() if value.returncode==0 else None}
assert out['source_manifest']['sha256']=='7b0650b926a557241b622eba4f032731e7b21d75d807c3b6baccfe689b29c960'
assert out['static_metadata']['sha256']=='863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
(JOB/'assets-verified.json').write_text(json.dumps(out,indent=2)+'\n')
print('ASSETS_VERIFIED',len(private_files),len(static_files),len(simpler_files),flush=True)
