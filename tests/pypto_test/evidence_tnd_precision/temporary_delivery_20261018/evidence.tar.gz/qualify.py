"""CPU重读原始tensor见证，独立复算Native/TND外部边界。"""
import argparse
import hashlib
import json
from pathlib import Path

import torch

parser=argparse.ArgumentParser()
parser.add_argument('directory',type=Path)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
assert not args.output.exists()
r=json.loads((args.directory/'result.json').read_text())
assert r['complete'] and r['pass'] and r['per_request_padding']==0
assert r['true_tokens']==r['physical_graph_tokens']==sum(r['lengths'])
assert r['entry']['tnd']['eligible'] and r['entry']['tnd']['route']=='PTO'
assert r['static']['actual_reselect_count']==1 and r['static']['validated_reuses']>=1
bounds=[0]
for q in r['lengths']:bounds.append(bounds[-1]+q)
for item in r['entry']['tnd']['metadata'].values():
    assert item['bounds']==bounds and item['actual_tokens']==r['true_tokens']
    assert item['num_decodes']==len(r['lengths'])
for row in r['graphs'].values():
    assert row['actual_acl_graph'] and row['fullgraph'] and row['compiled_raw_equal']
    assert row['live_input_ABA'] and row['topk_poison_replay_restored']
    assert row['options']['force_eager'] is False and row['options']['static_kernel_compile']
    assert all(g['status']=='PASS' for g in row['guards'].values())
assert r['graphs']['tnd']['pto_dispatch_calls']>0
assert r['graphs']['tnd']['root_schema'].startswith('dsv4_csa_tnd_full_precision::attention(')
assert r['graphs']['tnd']['root_schema'].split(' -> ')[0].count('Tensor')==62
native=torch.load(args.directory/'native-witness.pt',map_location='cpu',weights_only=False)
tnd=torch.load(args.directory/'tnd-witness.pt',map_location='cpu',weights_only=False)
def equal(x,y):
    return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
assert equal(native['fixture_input'],tnd['fixture_input'])
comparisons={}
expected={'x_out','idx_topk','swa.0','compressed.0','state.0','indexer.0','indexer.1','indexer_state.0'}
for phase in ('A','B'):
    left,right=native['states_'+phase],tnd['states_'+phase]
    assert set(left)==set(right)==expected
    comparisons[phase]={}
    for name in sorted(expected):
        assert equal(left[name],right[name]),(phase,name,'first bit difference in saved witness')
        comparisons[phase][name]={'bit_equal':True,'elements':left[name].numel(),'dtype':str(left[name].dtype)}
for group in (r['comparisons']['tnd'],r['B_comparisons']):
    assert set(group)==expected and all(row['bit_equal'] for row in group.values())
sources={}
for name in ('result.json','native-witness.pt','tnd-witness.pt','run.log','preflight.log'):
    p=args.directory/name
    sources[name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
result={'pass':True,'lengths':r['lengths'],'true_tokens':r['true_tokens'],'graph_tokens':r['physical_graph_tokens'],
        'layer':r['layer'],'history':r['history'],'comparisons':comparisons,'sources':sources,
        'scope':'CPU byte-exact recomputation of saved A/B external tensors; fixed query bounds FULL replay, not arbitrary metadata mutation'}
args.output.write_text(json.dumps(result,indent=2)+'\n')
print('QUALIFIED',r['lengths'],'A/B 16 external tensor comparisons',flush=True)
