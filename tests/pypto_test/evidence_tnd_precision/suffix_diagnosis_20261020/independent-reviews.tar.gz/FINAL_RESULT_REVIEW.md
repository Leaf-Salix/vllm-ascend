# 本轮最终结果独立审查

## 最终结论

**通过，无阻止归档/提交的问题。** 本轮仅保留phase1八owner作为后续实验起点，正式冻结后缀不切换；新增M128对phase1回退后停止扩大组合，不做完整CSA集成或整模型复测，决策与实际证据一致。

本审查只读当前报告、14份原始结果/任务收据、DFX与PMU归档及冻结源码版本，不运行设备或修改源码/原结果。当前主checkout HEAD为93f21dc7f3e841c946269b26859f67f78645052d，正式运行源码相对48c58ce7c未变；本轮报告与证据为待提交文件，实验候选独立留reports。

## 核验内容

### 14项结果及收据

RUNS共14项，与总收据summary键集合完全一致；每项任务ID/status completed(exit=0)、raw result SHA、最终pass/complete、guard/readonly/实际FULL标记均匹配。归档结果与已有本地JSON逐字节相同。每项task日志都有唯一START/END及设备锁释放；没有把未完成快照当最终结果。

8项无插桩AB每项160个逐位指标全部bit_equal、差异元素/max_abs=0，双generation各1204；配对DFX两项各70指标与最终双generation7正确。阶段/stages每项检查计数14、独立DFX5、PMU3；all-ready targets为空，报告已明确它不是新数学精度资格。

精度范围仍是冻结PTO后缀金值，不是本轮直接Native后缀/完整CSA或整模型。source_baseline、父a31、实际候选proof、harness SHA和基线两个实际模块SHA完整对应。早期4项AB绑定ab_probe_v1.py；phase1绑定扩展CLI后的ab_probe.py；combo及incremental各有独立文件，不误把后改helper字节赋予旧任务。

### 数字与保留决策

所有无插桩timing各12个100回放窗口，无删样。独立从raw samples重算min/mean/median/max及paired方向，与RESULT_VALIDATION和报告一致。

- phase1：T126降低36.764494%、T240降低16.326395%，各12/12窗改善；仍慢于同任务frozen23.129698%/15.059371%。只能叫改进旧resident，不能叫已超越正式后缀。
- phase5：T126改善12.109025%，T240回退6.549317%；不作为通用保留正确。
- M128对a31：T126/T240改善12.956512%/4.247901%；这是其各自同任务的真实结果，不等于对phase1也获益。
- combo对a31：T126改善29.497338%，12/12窗；直接incremental对phase1却回退2.495925%，0/12窗改善。停止组合T240及不保留M128叠加策略有直接证据。
- 不用不同任务的parent绝对数排名，不相加因素收益，也不把三臂当四格factorial交互估计；报告已经保持这些限定。

## DFX和PMU原始数据

独立从三个DFX归档读取全部42窗（独立阶段24窗、两项AB各9窗）：六列schema/start-end有效、freq>0、24aic+48aiv类型、实际core集合、record数量及run round数、dropped=0均通过；total/role包络重新计算与JSON一致。

记录数：frozen304，resident/new72，孤立WO-A/WO-B24，孤立Vector阶段48。run_boundaries是每root round的开始标记，frozen两个root为2条，其余单root为1条，不是起止对。初次错误的离线假设保留在CHECK_HISTORY，修正语义后没有改raw或重跑来挑数据。

独立L1：resident633.78 μs；配对phase5原/新646.04/626.14；配对phase1原/新694.20/415.82，均与raw一致。DFX来源/插桩标记明确，不用其收益替代正式AB，更不拿T126诊断撤销T240回退。角色包络可重叠，不能相加或将差额全分配给等待/搬运。

PMU归档7臂每个CSV保留3个AICPU及3个AICore行；汇总仅取对应3个aicore_kernel_mode_0记录，独立重算各列中位值与PMU_SUMMARY一致。报告没有把Scalar全称signal等待，也没有把MTE2 busy等同搬运stall；host-flow关联告警保留且未冒称全链无告警。PMU不混入无插桩计时。

TWAIT头文件内容fcb4e369…与tar压缩包dfb3175b…分别绑定。其轮询机制支持待验证假说，不构成每次poll走DDR或唯一根因的证明；当前文档解释准确。

## 时间收据

实际Python探针范围80.141989～129.438986秒，PMU为129.438986秒；REPRO的“约80–130秒”正确。START/END包含导入等额外开销，范围96～149秒，不等同probe字段或纯kernel时间。全部远低于15分钟。外部排队时间不能算占卡；日志START之前的环境准备也不能由这些标记单独估算。

| case | 探针秒 | START→END秒 |
| --- | ---: | ---: |
| stages-t126-v1 | 110.727 | 129 |
| pmu-t126-v1 | 129.439 | 149 |
| dfx-t126-v1 | 95.713 | 112 |
| waits-t126-v1 | 100.713 | 120 |
| ab-phase5-t126-v1 | 95.378 | 115 |
| ab-m128-t126-v1 | 90.528 | 107 |
| ab-phase5-t240-v1 | 86.009 | 104 |
| ab-m128-t240-v1 | 82.193 | 101 |
| ab-dfx-phase5-t126-v1 | 80.142 | 96 |
| ab-phase1-t126-v1 | 89.826 | 111 |
| ab-phase1-t240-v1 | 95.315 | 114 |
| ab-dfx-phase1-t126-v1 | 92.593 | 112 |
| ab-combo-t126-v1 | 99.115 | 121 |
| ab-incremental-t126-v1 | 87.083 | 104 |

## 文档及复现口径

REPORT_DRAFT、WHY_SLOW与REPRODUCTION对参考nalinaly固定beaefa6f、SDK2dfa/57e/ISA327与PTOAS隔离wheel源Git未证明均有明确限定，没有把Nal数值链当Native金值，也没有冒认其最新未获取提交。

CPU检查脚本输出路径固定且exist_ok=False；复跑应按REPRO要求使用未存在目录。实际操作可复制检查helper只修改其输出目录并保留新helper SHA，勿删除旧结果或改已冻结数学源。prepare*.py是历史派生工具，冻结probe是硬件身份依据，这一点已说明。

没有新增8K/B40或128K/B24 192-token结果，没有将本轮五边界资格赋予整模型或正式根64ABI。当前不集成root的决定合理，亦避免将未包含zero/alloc成本的后缀结果外推完整CSA。

## 审阅身份

审阅对象截至本文件生成时SHA如下；父线程后续归档/迁入项目若仅改链接或措辞，仍应保留raw及冻结probe身份，不为格式化后的数学源沿用资格。

- `REPORT_DRAFT.md`：`ce17d109149cd27b750546c5084fc1673aa3656cccfb54a4c49071eef1832601`
- `WHY_SLOW.md`：`f7efedf67c6888a399d8e81f8ae8e1a2a83e570f6ee192cbdbfe2d96b1926772`
- `REPRODUCTION.md`：`067036fca0c33d9cec5d9941651e921ed4e213f21648c2548c38ce0eeb063cd7`
- `RUNS.json`：`a45ee4a67ec286b01f677428f92dbfe9b1ceea290801ce5b87fa13c1345b55f1`
- `RESULT_VALIDATION.json`：`429348e18e38a000a7966ee5611b220882832ba09cb30be3b9401333c5d30785`
- `AB_DFX_INTEGRITY.json`：`666f8b3723a0e6919722646ecec78a2fef6f0e326ae632e88e79c24d113a5ca6`
- `DFX_INTEGRITY.json`：`5e89c785bfb1c450f4ca69fcd2101e0b38505cdd51f0face253834414bd4f259`
- `PMU_SUMMARY.json`：`73ba4824eaa5221c84da1dcc0f0c91c2cf19d65e2f6a0f89d78cbdd7447a60cf`
- `suffix-diagnosis-run-receipts-v1.tar.gz`：`454a51a2e7e99351aadd75780531ac348c535312e62958f5c78375a404dee13f`
- `suffix-dfx-t126-v1-evidence.tar.gz`：`733b51129a1b30f9aeceea4b476d0217b938f1bf42c04ede9ad70c8987ec7895`
- `suffix-ab-dfx-phase1-t126-v1-evidence.tar.gz`：`a20064f5608fe6970d32cb43edb9b9a6795854010ad76d5d8b72b838cc8b7e53`
- `suffix-ab-dfx-phase5-t126-v1-evidence.tar.gz`：`64e0e4dde4d6d2b1ba04d6e79e07f43e65b6a7d8e58c6aab940cbcc36b16b09b`
- `suffix-pmu-t126-v1-evidence.tar.gz`：`201babaf989c89284604a3760cf3833bd974e105666bc894f7857129eb624298`
