# phase1候选理论、T126结果与三臂DFX独立审查

## 结论

**phase1依赖公式正确，可作为新的独立因果实验；尚未证明有效，不应与phase5组合后再归因。** 当前没有phase1源码，本结论只批准设计合理性，不代表候选实现、编译或硬件资格。真实TND与全8192统一量化不变。

两项T126单因素AB结果与原始JSON统计一致；新三臂DFX的双generation/整轮比较逻辑合理。DFX用于观察AIC/AIV整体跨度谁变化，不能把phase5收益直接称为固定wait指令成本。

## T126原始结果独立复核

| 独立任务 | frozen μs | parent μs | new μs | 中位延迟降低 | 配对窗改善 |
| --- | ---: | ---: | ---: | ---: | --- |
| suffix-ab-phase5-t126-v1.json | 408.170013 | 775.104599 | 681.246986 | 12.109025% | 12/12 |
| suffix-ab-m128-t126-v1.json | 409.788494 | 737.519989 | 641.963120 | 12.956512% | 12/12 |

独立读取两份JSON，12窗各臂min/mean/median/max重算一致，160项逐位比较全部bit_equal、different_elements=0，pass/complete为true，parent/new最终generation均1204，无删样。160项是4次eager/FULL前置与12窗各10项比较，不是160个不同输入。

两任务parent基线775.1046和737.5200 μs已有差别。因此只能分别说明同任务的候选收益，不能按681.2470与641.9631跨任务绝对值直接判m128一定优于phase5。T240及重复性还应另行判断；目前均仍慢于各自frozen。

all-ready微基准中位wait0=86.213899、wait24=88.369598、wait48=94.558401 μs；相对wait0仅+2.155700/+8.344502 μs。这说明“已经就绪的轮询及固定维护”在该微基准环境下的量级，不能用它解释完整任务中所有生产者未就绪、资源争用、调度重叠，也不能把phase5约93.86 μs的同任务下降全部命名为删除40条wait的固定成本。

## phase1实际依赖证明

当前AIV的BF16 cast loop：

```text
block = worker + 48*k
rb = floor(block/8)          # 每个块16行
cast_group = block % 8 = worker % 8
```

当前Cube的WO-A每个逻辑worker对应：

```text
logical = group*8 + N128block
producer_aic = logical % 24
```

每个cast读取accum的该group全部1024列，恰好横跨8个N128 Cube块，所需owner为：

```text
(8*(worker%8)+n)%24, n=0..7
```

每个AIV的所有cast任务保持同一group，只改变rb；该AIC phase1在自身所有逻辑worker及所有行panel完成后才发布，所以等待一次这8个producer足以覆盖其全部cast。即使WO-A因为start不统一走M16回退，logical group/N128归属也没变。

有cast任务的条件为`worker < ceil(T/16)*8`；无任务核可跳phase1获取，但仍执行原publish2。独立CPU枚举T=1..256、全部48个AIV及其所有实际cast block，公式产生的owner集合与实际读取生产者集合完全相同；空核集合也一致。

## 安全条件和最小变更

只替换原vector phase1 wait_group(0..24)为：有工作量时等待上述8个AIC，再原样执行一次fence/cacheinvalid/fence；随后**所有cast数学、任务顺序、BF16舍入、GM store及publish2原位不变**。不动Cube数学/WO-A Native K序、不动quant全8192 amax、不动phase2/3/4/5等待或工作区。

- accum每个行/N128块唯一生产者；signal发布前原bar/fence/cache维护保留，consumer最后一个必要signal后仍获取payload。
- cast各group写入1024个BF16列，块间不相交，地址/尾行写回原样；不同group提前开始不改变单个值的计算顺序。
- 无工作AIV的publish2只是其空任务完成，不能因此省掉begin/publish或改signal布局。quant仍按原phase2完整集合等待，必须取得该行全部8组，不能提前只量化某1024列。
- 原Cube不等待cast再发布phase1；AIV先等WO-A→cast→publish2的DAG没有新增反向边。部分AIV提前到phase2等待不会阻止其它Cube完成phase1。
- accum/projected本代没有循环覆盖；完成信号仍不是consumer ACK。跨调用依旧要等待整个MIX完成，工作区/信号必须顺序独占。

这只减少每个有cast任务AIV的无关producer集合，并非逐tile完成通知。一个AIC可能负责2～3个不同group，phase1只有全部完成才发布，因此仍保守等待它的其它group，不声称依赖达到最细。

## 可以验证的因果假设

phase1实验作用于前段：部分cast可在无关AIC仍做WO-A时开始，且减少就绪信号读取；phase5实验作用于末段：HC-post不等无关dequant owner。两项作用位置不同，因此phase1可区分“只消尾部集合等待”与“前段获取/资源重叠”的影响。

但提前cast还可能与WO-A争用GM/L2/MTE资源，导致AIC变慢；cacheinvalid时机也可能改变。不能仅因删除更多等待就承诺更快。先从a31独立派生并同任务三臂/五边界/双generation/guards验证，再比较实际AIC/AIV跨度和无插桩窗口，不和phase5/m128混成一个候选。

## 新三臂DFX harness

相对已审AB源，改动是独立启用L1（dep_gen=False）、每臂三次单回放采集及对应原始span解析；前置eager/FULL A/B/A、五边界、两臂独立scratch/signals与readonly保留。

每一arm采集前分别保存parent/new generation；只有当前arm对应的一方+1，另一方必须+0。frozen两方均+0。两resident在同一轮未全部推进时，暂时不要求两方generation相等；每个arm只做guards，整轮三臂各完成一次后才调用compare恢复“两个代际相等、五边界一致”约束。这与三个独立root分别执行的事实一致，不是放宽generation门禁。

当前inputs保持A，三臂在本轮内没有重复覆盖同一臂输出，因此把位比较放到整轮结束不会在比较前由该臂下一次回放修复首差；每arm独立工作区及guards仍在。发现差异时end-of-round立即抛出，不能声称逐arm结束即比较过五边界。

metadata.core_types现已严格核24aic+48aiv，run_boundaries按frozen两次root/其它单次root校验，dropped=0。SDK run_boundary是每root prepare成功的开始标记，不是起止对。按同任务相同role的包络比较，能观察AIC/AIV整体任务持续时间变化，但仍没有原位phase1/5内部时戳，不直接证明某一条wait占多少时间。

### DFX剩余限定

- `{core_id}=0..71`的断言适用于本轮T126/T240三臂；frozen短T可能不使用全部48个AIV，不能不经修改就把此脚本宣称为T1..256通用DFX。
- 当前解析仍建议核6列schema、start<=end、freq>0及每token/core记录计数，而不只核core集合；集合完整不能排除某些任务重复/少记录。异常raw不应进入跨度结论。
- 三轮rotate/reverse不完全平衡三个位置；这是结构诊断，不是正式延迟统计。不得混用无插桩AB与DFX span的差值进行精确耗时分摊。

## 进入实现后的门禁

本次没有生成phase1候选。之后应核实际源码只改phase1获取块、其余math及所有producer发布AST相同；无设备完整编译后核actual signal索引/维护与store顺序。T126先验收，T240再验收，五边界任何bit首差即停，不新增SDK/后端能力，不改真实TND布局。

## 审阅文件SHA256

- `ab_probe.py`：`bf0ffabaf4ef12dd8d66e005e32db753a0222ab18f58f1b443c4be751b04afce`
- `ab_probe_dfx.py`：`b2287ad99c5b96f65fda23463d891364a41eb109d3593719d488e1ea89dab417`
- `run-ab-dfx.sh`：`193b2fa2171b906dfdff2200a42329fc35bc1d9e2161cdcee5974b000cab5649`
- `suffix-ab-phase5-t126-v1.json`：`9aee0f87b87b8b6b240c222377b4888a6809c1b24d43c3b0a5aa8942490579b6`
- `suffix-ab-m128-t126-v1.json`：`c5e4d689ba65594390ab68ff0bbc152375413acdfc921ccc76b547ac3971fda6`
- `suffix-waits-t126-v1.json`：`b74da2677c37788ae49136e35ba5fe642c160a6ff82e62a80c1ce4f4c9c66651`
- `candidate-phase5.py`：`03121a6b0bda9d793f3f0fe5f47d8f953472bd596ef733f9b7ba0f0a6106d35e`
- `candidate-m128.py`：`aaa880cd8d96c54fa560a1d9949288eefb487c24d1bbda93739640513368f0bb`
