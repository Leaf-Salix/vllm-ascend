# phase1→combo增量三臂harness独立审查

## 结论

**通过，无阻断。** 当前脚本可以用于同任务的frozen / phase1 / phase1+M128三臂对拍，直接判断在已经采用phase1的后缀上新增WO-B M128的净效果。它不再把跨任务phase1与combo绝对延迟直接比较。

本审查只读，不运行设备、不修改源码。候选仍需本次硬件首差停止及原始12窗统计验收；不提前认定有收益。

## 实际改动与身份链

对照combo_probe逐文本核验：执行/毒化/graph/事件/比较函数与窗口循环未改；新增的变化为比较parent从a31文件切换到`candidate-phase1.py`，加载其proof并绑定actual文件SHA，保存`comparison_parent_proof`和准确scope标签。

校验链为：

```text
冻结O-proj/HC-post source ← a31 RESIDENT_SUFFIX_SOURCE_PROOF.sources
硬pin a31 SHA            ← RESIDENT_SUFFIX_SOURCE_PROOF.candidate_sha256
phase1实际文件SHA       ← parent_proof.candidate_sha256
phase1所基于父版本       ← parent_proof.parent_sha256 == a31
combo实际文件SHA        ← candidate_proof.candidate_sha256
combo的phase1 component ← 与当前parent_proof.candidate_sha256相同
```

因此不是只更改报告名称而继续运行旧a31；实际被注册到parent算子的Python模块已来自phase1文件。new仍加载combo独立模块，namespace不同，不能与parent同一个函数对象混淆。后续需保留actual编译收据/源SHA，以排除cache身份误用。

独立再次核函数AST：phase1与combo只有cube不同；combo.cube来自已审m128，vector均为同一phase1，phase5都保持原等待48 AIV。故此任务的算子源码差异仅WO-B M128及必要行grid/有效行大小。

## 容量及守卫

- parent integer=T+63适配M64，足够ceil(T/64)*64；new integer=T+127适配M128，足够ceil(T/128)*128。
- 两臂accum均T+127，公开五输出/signal独立、new_flat零拷贝与pointer唯一性断言不变。
- 两种integer都经buffer()进入外围guard，signal首尾/used/unused槽和全体只读SHA仍检查。
- T≥96且T≤256限制继承；尚未将M128资格扩大到小T。

较大integer容量是M128策略的配套成本，新增对拍应按整个增量策略解释，不声称两臂连内存地址与容量都完全相同。

## 精度、代际和计时

保留原eager、FULL A/B/A、所有五边界相对frozen逐bit、NaN/整数逐元素反码poison、首差抛出、只读输入与guard。phase1与combo已采用同一generation协议；每窗分别+100，compare时必须相等，正常最终各1204。

12窗三臂rotate/reverse、100回放事件计时原样，每个位置各臂出现4次；检查在event外，无PMU/DFX。原始全部样本需保留，以paired phase1/combo窗口方向与幅度判断。frozen仍作为同任务控制，不能将父臂改成phase1后继续把其延迟标成a31。

## 报告/统计口径

结果字典中的`resident`键现在表示**phase1**；`source_proof`字段仍保留a31到冻结数学的原始参考链，新增`comparison_parent`和`comparison_parent_proof`才是本任务实际父臂身份。汇总脚本应读取这些字段，不能硬编码resident=a31。

本任务可报告“相对phase1新增M128的净收益/回退”，以及combo与frozen的差距。它仍不是同任务四格factorial，无法估计完整phase1×M128交互项；但解决了本轮最关键的增量选择问题。若M128没有稳定增益，仅保留phase1；即使combo比a31快，也不构成必须保留M128的证据。

相对阶段/后缀收益不自动赋予完整CSA，更不赋予整模型资格。不要把T126结果外推T240，或把不同任务的改善百分比相加。

## 审阅SHA256

- `combo_incremental_probe.py`：`fad3cdc4415ed2c06228e11e8647b750d31da3a143de145e67d7276fd364f4b5`
- `run-combo-incremental.sh`：`de3cb0f9cf916bcb484fd22404737f3d1040d4a4c603dd23d7ef975dd1e489ec`
- `combo_probe.py`：`3ad1c726ca39d552e8cb6bddab473698e5e0a6654de347b3a388949725128f04`
- `candidate-phase1.py`：`f22d7d8dd6ef2a48f640b88511c6c32c672ade0b116fa922f18c6a6a23237fe6`
- `candidate-phase1.json`：`6ab6a5bbe8eef6386d648265a065a7067fa6e719aa266648dd7f0b8702381afe`
- `candidate-combo.py`：`21ba383eb60c7c2c4a7a377d96c0caac4500f6fc60ab370c54d0d8e1adbc757b`
- `candidate-combo.json`：`22c948d24094f419658c8e4c93e1bc535a5801da449ae733a34fe99cf1d9f6e2`
