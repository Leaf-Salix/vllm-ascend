# 独立L1 DFX采集审查

## 结论

**采集接口及基本跨度计算合理，无阻止采集的问题。** 当前仍须在拿到原始窗口后核实core类型与记录完整性，才能把AIC/AIV分组跨度用于结论。L1只能提供任务执行包络与单核持续时间，不能独立识别纯Cube计算、搬运等待、阶段signal等待或完整入口开销。

本审查只读脚本和本次固定SDK源码；不修改运行文件、不提交设备任务。六阶段数学沿用已审版本，未把DFX结果混入无插桩性能样本。

## 接口及目录核对

对照当前归档PyPTO `python/pypto/torch/execution.py:122`及`runtime/kernel/context.py:257`：

- `init(enable_chip_swimlane=1, enable_dep_gen=False, output_dir=...)`满足窗口采集配置；没有同时开依赖图或CANN PMU。
- begin/end均在原显式stream上下文，位于capture之外。SDK检查当前设备/是否正在capture，begin/end各自先drain framework当前stream，end还会收集并落盘；因此脚本不额外synchronize也不会过早读文件。
- 开窗在单次graph replay前，关窗在其后。窗口外的warmup、A/B/A、毒化、CPU检查不会被当作该窗业务；后续generation/phase/guard检查在end之后。
- SDK约定首窗直接写output_dir，后续window_1、window_2…；脚本从counter=0连续至23定位八臂×三次窗口，目录规则一致。
- 原stage探针文件未被替换；新DFX脚本没有12×100正式计时段，也没有启动PMU。run-dfx.sh指向独立DFX源。

## 六列含义与单位

对照当前Simpler `src/common/platform/shared/host/chip_swimlane_collector.cpp:1250`实际导出：

```text
[core_id, task_token_raw, reg_task_id,
 start_cycles, end_cycles, receive_to_start_cycles]
```

所以idx3/idx4用于执行开始/结束是正确的，idx1不是时戳。时钟频率由metadata.clock_freq_hz读取，而非假定设备GHz，换算`cycles*1e6/frequency`正确。原始记录要求长度6、0<start<=end、频率>0、非空，符合当前schema。

`aicore_executor.cpp:184`在execute_task前记录start，随后执行函数，execute_task返回后记录end；commit记录动作在之后。因此该区间包含函数内数学、GM/L1/L0移动、流水/分支、核内signal等待，以及execute_task分派/参数相关工作；并不是“仅数学内核”。它不含全部Python/graph replay入口、host task queue和完整AICPU调度时间。

第6列是receive→start的32bit delta，当前未用它不会导致span计算错误。但它也不是全部入口开销，early-dispatch路径还可能包含门铃等待；若后续使用，需按运行时实际语义独立解释，不能把它改名为纯host开销。

## role分类需用metadata证明

脚本按core<24作为AIC，其余AIV。当前24AIC/48AIV拓扑预期如此，但同一原始JSON已经提供`metadata.core_types`和num_cores。建议离线分析时：

1. 验证所有record core在metadata索引范围内；
2. 以core_types[core]读取aic/aiv，或先硬断言0..23均aic、24..71均aiv再接受当前阈值；
3. 保存每role的原始core集合/记录数，不能只看span正数。

这是解析身份限定；不需要为了它重跑设备，现有raw可离线检查。若metadata与阈值不一致，应重算roles，不要保留错误分类。

## 窗口完整性与精度检查

- 原始level必须1、频率有效；建议核metadata中run_boundaries与dropped_run_boundaries（字段存在时）以及实际root/compiled kernel配置，保证每窗只含预期PyPTO调用。
- resident是一个24组MIX，应从actual orchestration核对24 AIC/48 AIV任务的记录覆盖；isolated阶段仅相应角色，具体record数以其实际submit为准。frozen由两个注册root执行，不能强套resident的一条MIX任务模型。
- 当前只断言items非空，不能单靠此证明没有少核、少任务或意外旧记录。采集后应核记录token/reg_task与actual artifact，再判跨度有效。没有必要在此先假定某一具体缺失已经发生。
- 完整resident每窗要求generation+1，frozen/六阶段要求+0。每次仍执行五边界、阶段target、guard与readonly；phase每项计数应5（原eager与FULL各1，再三窗各1）。完整graph仍先A/B/A过门禁。
- 内部accum/integer的expected继续来自完整resident，不是直接Native内部金值；DFX不能扩大该既有精度范围。

## 能说什么，不能说什么

| 当前字段 | 合法解释 | 不能直接推出 |
| --- | --- | --- |
| total.span_us | 最早任务开始到最晚任务结束的执行包络，包含核启动偏斜与空隙 | 整个graph replay延迟、纯入口开销 |
| role.span_us | 某role最早start到最晚end的包络 | 所有AIC/AIV时间之和、纯Cube/Vector利用率 |
| role.max_core_us | 该role最长单条task持续时间 | 相同核所有tasks的合计、全role关键路径的精确分解 |
| 独立WO-A/WO-B span | 已填充输入下阶段执行成本，含转运及runtime环境 | 纯MMA时间，或在完整resident中的原位阶段成本 |
| resident与孤立阶段的差 | 两种执行与cache/调度环境的观测差 | 独立同步耗时，或总和/差值严格分摊 |

三个DFX窗口无位置完全平衡，也不是稳定性能统计。必须保留原始三窗；用于检查大的结构差异，不替代已测无插桩12×100的中位延迟。不能用另任务的无插桩event减本任务DFX包络宣称精确入口耗时：插桩、单次/百次热态及采集边界都不同。最多把它作为定位线索，并明确交叉任务比较。

PMU可另给流水利用率证据，但利用率不是可相加耗时。若要细分原位WO-A/quant/WO-B之间的signal等待，需额外核内阶段时戳或保持其它条件的单因素，L1只有整个task边界不足以直接辨认。

## 退出和归档

异常会保存error并raise，finally记录时间；process750秒、调度780秒仍由外部任务命令控制后者。不得将parser成功或phase门禁通过等同DFX数据完整。归档保存原始24窗JSON、probe/run脚本SHA、actual artifact身份以及离线类型/计数复核，再发布观察结论。

## 审阅SHA256

- `suffix-diagnosis-20261020/stage_probe.py`：`74297ecc806ab3bad8ac474da0a6807c907a9ca2ee635947edf3278706b3e355`
- `suffix-diagnosis-20261020/stage_probe_dfx.py`：`420df6b2d3a8ca536f795232f64f71c1f1ab344e64238a89b0ddb1b9f402ec9d`
- `suffix-diagnosis-20261020/run-dfx.sh`：`26c0d5db7a541fdcbce70c9d73b49b8390456637f1f587d98f3b678d8c46fac5`
- `sdk-sources/pypto/python/pypto/torch/execution.py`：`7da6e475ede157d9860a68613c63d95b139a42a22d58bd24ce579cb40ff7a560`
- `sdk-sources/pypto/python/pypto/runtime/kernel/context.py`：`8b758077ae5782d02d761a27d458a5f46c5422171454b87bcbcb1eef681cf989`
- `sdk-sources/simpler/src/common/platform/shared/host/chip_swimlane_collector.cpp`：`1e83a077a51bb64b1dccc592c885c1ecdef306b47eb5bb2e5b2ba08a52a4eaa5`
- `sdk-sources/simpler/src/a2a3/runtime/tensormap_and_ringbuffer/aicore/aicore_executor.cpp`：`1a4a03af1f92578430a4248463bbc0b706859b23d30d93666aad9b44bef0a382`
