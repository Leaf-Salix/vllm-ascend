# 两个单因素候选独立审查

## 结论

**phase5与m128源级审查通过，无需修改SDK。m128工作区容量问题已修正；硬件前后仍须核实实际尾行写回与资源。** 当前只认可两项互不组合的实验；m128替代此前phase3建议。本审查不执行编译或设备，不将尚在CPU编译中的候选宣称已验收。

DFX已有resident约633.78 μs、孤立WO-A约141.54 μs、WO-B约41.94 μs，只支持存在调度/占用差异的线索；不能将这些相减命名为纯等待。以下候选分别验证缩小等待集合与增加WO-B共享M维，不预先断言收益。

## 实际diff

逐AST独立比较所有函数：phase5仅vector函数变化；m128仅cube函数变化，且cube内除第7项WO-B分支外全部节点逐AST一致。两者均保留原16Tensor/8InOut、generation布局、WO-A的Native cyclic K序、projected BF16落点、全8192共同amax及量化/反量化/HC-post运算。

### phase5

实际diff只将无条件wait_group(phase5,core24..71)替换为：有HC-post任务的AIV等8个实际dequant owner，之后保留原fence/cacheinvalid/fence。所有生产者phase5发布仍在原位置。

owner=(8*floor(worker/4)+dep)%48，signal core=24+owner。独立CPU枚举T1..256全部48 AIV、所有有效HC-post tile/token及8个512列块，候选集合与实际dequant生产者集合完全相同。跨下一个本核token tile增加192行，owner偏移8*12 mod48=0，因此每AIV等待一次8-owner集合即可覆盖其所有HC-post任务。

没有HC-post任务的核仍先发布phase5，只是无需获取attended；其后原空数学loop及本核结束bar保留。原DAG不新增反向边；attended不在本代循环覆盖，下一次调用仍须等整个MIX完成。不能把完成信号当消费者ACK，不能因这项减wait开始复用buffer。

该改动可以减少无关轮询及stage集合牵制，但全部8个真实owner仍可能已经就绪，收益须实测。实际T1..256信号索引均在原6×72×128范围内。

### m128

实际仅将wide WO-B分支的行块由64改128：row grid ceil(T/128)、wide_row=block//32*128、wide_valid=min(128,T-row)、两处activation slice [128,512]。N128列块、32列块分配、首K512 matmul seed、后15个K512 matmul_acc与GM assemble原样；rows≤16分支不变。

对每个有效输出(row,col)，仍有唯一writer，K范围按0,512,…7680顺序各512元素，覆盖8192。独立CPU枚举T17..256，M64/M128两种实际映射的所有有效row及N128块，各自无重叠无遗漏且覆盖T×32块；N块内128列固定连续。

INT8×INT8点积每项绝对≤128×128，8192项绝对和≤2^27，含任一部分和也不超过该界，不发生INT32溢出。M维共享不改变某行点积、量化输入或整数转FP32后的数值边界；首包初始化条件不变。**这不替代实际NPU逐位门禁**：必须拒绝编译器有效行/布局/别名错误。

当前AB通过argparse将m128限定T≥96；候选本身仍对T17..95走M128，不能因harness限制就声称全部形状硬件已验证。若最终只需T126/240，先严格维持该范围。

## scratch与生成代码门禁

审查曾指出：若m128仍沿用new_integer=T+63，在T129..192区间不足完整M128尾tile容量。当前已修正为m128专用(T+127)×4096，其它variant仍(T+63)×4096，且两种均经buffer()进入外围guard；独立复核该行已落实。因为T+127≥ceil(T/128)*128，对T1..256都保证完整M128行tile容量，不再依赖尾store裁剪来证明GM容量安全。公开前T输出/数学边界没有改变。

主线程已报告两候选完整CPU编译与Artifact.load成功。本审查不冒认独立重编或actual ISA复核，但源级范围没有要求新增SDK能力：两者使用现有DSL/同步/MatMul接口，**不需要修改SDK或codegen**。本轮硬件仍仅拟T126和T240，保持首差即停。

还须核实际：M128N128 INT32 Acc约64 KiB、M128K512 INT8 activation约64 KiB、K512N128 weight约64 KiB的资源/tiler分割，CCEC完整通过且无额外GM spill、L0C别名或输出owner变化。此为源码名义规模；真实资源以生成物为准，不用估算替代门禁。

phase4仍等全部24 AIC，因此m128改变WO-B owner后没有套用旧精简owner公式；phase5的dequant任务划分未变。两个候选不组合运行以保持单因素解释。

## AB门禁与身份

当前AB补齐new_flat pointer/offset/contiguous断言、两resident输出/工作区pointer唯一性，以及new_module WORDS/CORES/STRIDE与parent一致。候选proof必须parent=a31且文件SHA匹配；当前两份SHA正确。

eager、FULL A/B/A及12窗五边界逐位，全部外围guard、只读SHA和双generation每窗+100应全部保留。实际硬件前需收据证明新root/生成核确实来自各候选，而非只看到proof.json就认可缓存身份。若candidate在编译/资源阶段失败，记录工具/实现阻断，不算数值失败；若任意bit首差立即停止定位。

只有同任务parent/new稳定收益才考虑后续完整CSA，frozen臂用于控制既有性能参照。不把孤立WO-B下降比例或阶段wait调用数直接外推整层/整模型提升。

## 审阅SHA256

- `prepare_candidates.py`：`ab58028772285cae8ec22790b246012a3e8276de6402486ec8cd1d5256b0832b`
- `candidate-phase5.py`：`03121a6b0bda9d793f3f0fe5f47d8f953472bd596ef733f9b7ba0f0a6106d35e`
- `candidate-phase5.json`：`539381ba046c2bf249d369b92f39003f59f2eda3e941eaa595d350b684954a15`
- `candidate-m128.py`：`aaa880cd8d96c54fa560a1d9949288eefb487c24d1bbda93739640513368f0bb`
- `candidate-m128.json`：`f86bfa80b0b6d2ec74c08ee238f31523e912f4daab8073d9cec80603aad90ccc`
- `ab_probe.py`：`d0db9035988410eb14ff761fcf3d750f03c2dd1ded101f73f7f309d6eea41e5a`
- `run-ab.sh`：`8da6b5156e343c421e43a7ca4e81bffd34bf0a32917e94b8fa03c46461012588`
