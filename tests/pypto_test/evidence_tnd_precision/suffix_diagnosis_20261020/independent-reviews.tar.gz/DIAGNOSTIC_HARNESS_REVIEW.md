# 阶段诊断harness独立审查

## 结论

**通过，无阻断。数学提取、工作区数据流、FULL图及计时逻辑未发现问题；三项门禁/身份补强均已落实并独立复核。** 当前阶段诊断可以用于排序“包含executor的独立阶段成本”，不能将六个耗时相加或从完整常驻耗时中相减得到同步耗时。本审查不修改源码、不提交设备。

当前审阅`stage_probe.py` SHA见末表；结论针对该版本。主线程记录六阶段已完整CPU编译，本审查另外独立检查本地AST/哈希，不冒认完成新的设备或编译测试。

## 复核中提出并已修复的三项

1. 原先整数目标统一poison=-91，可能与正确值重合。当前`poison_phase`改用每元素expected的bitwise_not（dtype/shape保留后拷贝到原目标），保证每个INT8/INT32位置都与正确位模式不同；浮点仍NaN。eager阶段执行和FULL replay前均走该helper，修复完整。
2. 当前保存整份`stage_source_proof`到result，并断言其parent等于已经hard-pin的a31；实际导入的六模块仍逐个校验文件SHA。足以绑定阶段源，建议归档继续保存原始文件与proof。模块绝对路径虽未单列，但import路径由固定SDK目录构造，不存在另一个搜索路径模块冒名问题。
3. 当前增加`phase_check_counts`，每次独立阶段比较都会更新计数。stages模式每phase应为14（eager毒化检查1、FULL毒化检查1、12窗1/窗）；PMU模式应为3。原bit-equal assert保持不变。结果需按模式核对此计数，不把它当作设备完成前的预置PASS。

这些修复没有改变被测数学、图顺序或计时窗口。当前实际探针是`stage_probe.py`，SHA见末表。`prepare_harness.py`仍保留最初派生版本；不能将其再次执行的输出当作已修复探针。复现应直接使用归档的当前stage_probe/run脚本，或先将三项修复同步到生成器再重新冻结新SHA。此差异应在归档中明确，而不是静默重新生成。

## 原数学提取独立核对

独立解析a31父源和六个派生文件，核验proof parent及六文件SHA，并逐AST比较每个选中顶层节点：全部一致。

| 阶段 | 父函数/节点 | 实际目标 | 备注 |
| --- | --- | --- | --- |
| WO-A | cube [0,2,3,4] | accum前T×8192 FP32 | 保留大T/小T分支、原K起点与packet/tail |
| BF16 | vector [0,1,4,5,7] | projected前T×8192 BF16 | 独立cast及store原样 |
| quant | vector [0,1,4,10,11] | quantized、token_scale | 8组1024共同amax、原RNE链原样 |
| WO-B | cube [0,2,3,7] | integer前T×4096 INT32 | M16/M64、16个K512顺序原样 |
| dequant | vector [0,1,4,5,14] | attended前T×4096 BF16 | scale/channel乘法落点原样 |
| HC-post | vector [0,1,4,17..23] | output前T×4×4096 BF16 | 四残差左折叠及末尾本核bar_all原样 |

每阶段root/incore均为16Tensor参数，root保留24组SPMD。AIV阶段保留split_aiv与worker=block*2+subblock。完整parent的begin/publish/wait全部移除，六阶段不读写signals；HC-post保留原本结束处本核bar_all。因而孤立阶段会丢失原producer/consumer重叠及原MIX占用环境，不是只把“同步时间”从同一个执行图切掉。

## expected、毒化及工作区时序

- 先用真实L4权重、合成输入运行冻结O-proj+HC-post和完整resident，通过eager与FULL A/B/A五边界逐位门禁。A恢复之后才取expected。
- accum/integer expected来自这一次完整resident实际写回，公开五边界已通过冻结PTO桥接；**不是直接Native FP32/INT32阶段gold**，报告需保持此范围。
- expected使用前T行的CPU clone，先snapshot再poison；expected不会与后续设备写回共享storage。六阶段逐个poison自身写入目标、执行、检查目标，并复核五个公开边界。各阶段输入在同一stream按序恢复到A的正确值，当前无源数据被提前poison的错误。
- WO-A/WOB工作区物理padding不全毒化、不全比较；当前只检验真实前T行及workspace外围guard，这与消费者仅读取真实行的现有合同一致，不应声称完整padding内容已对拍。
- phase FULL capture先于该phase raw replay的第二次poison，因此可排除依赖capture时旧输出的主要假通过路径；整数目标现已使用逐元素反码，不能靠保留正确旧值通过该写回门禁。

## signal及图时序

- 完整resident独占原signals、accum、integer；phase均只复用独立结果工作区，没有第二个并发stream。stream先wait当前stream，graph capture、poison、replay、event在同一个stream上下文，CPU比较和同步发生在计时窗口之外。
- stages模式每个arm单独记录generation：resident须+100；frozen及六phase必须+0。`generation()`同时验证当前所有已用槽一致、未用槽/隔离区仍0，因此误把完整root当phase注册会被增量门禁抓到。
- 需要保留本次完整root曾通过A/B/A的事实：阶段本身不带generation协议，不能从它们的图证明完整跨核同步正确。
- PMU模式与普通计时分支互斥；只有PMU分支开启profiler。PMU分支目前没有逐arm generation增量断言，仅有状态一致性检查；若要在PMU报告中声称增量也已验证，需加显式+3/+0断言。它不影响stages模式已有+100/+0门禁。
- PMU多profile上下文可能遇运行环境的重复注册限制；这应报告为工具/观测失败，不能算kernel数值错误。没有因此建议修改SDK或放宽门禁。

## 计时解释

- 八个arms是frozen完整后缀、resident完整后缀、六个孤立阶段。每窗按rotate并在奇数窗reverse，12窗×100回放无插桩；同一stream事件覆盖当前graph replay。完整/阶段实际可执行类型不同，均包含各自executor与kernel启动成本。
- 12窗不是8种位置的完整平衡轮次；因此保留每窗原样，不把极小百分比差距解释成可靠收益。当前任务目的是找大成本阶段，后续单因素仍需同任务AB交错复测。
- 单阶段重复100次会形成热cache，前一arm也影响下一arm；完整resident还存在不同资源占用、跨角色等待与重叠。因此`sum(phase)`或`resident-sum(phase)`都不是可识别的“纯计算/搬运/同步”分解。
- WO-A/WO-B阶段同样包含GM↔L1/L0转运与编排，不能仅凭阶段延迟标成纯Cube计算。需要PMU/真实流水或另外受控单因素证据。HC-post独立保留本核bar，其他publish前流水排空也已移除，尤其不能将差值直接命名为跨核等待。
- 报告所称median严格是100回放窗口均值的中位数，不是逐次回放p50。stages模式timing的unit字符串目前统一写isolated phase，也覆盖两个full arms；应按arm区分scope解释，不能误将两个full arms标成单阶段。

## run脚本与退出

`TASK_DEVICE`强制存在，ASCEND_RT_VISIBLE_DEVICES映射后使用npu:0，旧环境只作为基础source，PyPTO/PTOAS实际由独立SDK覆盖并预检；独立OPP/cache/log目录，进程timeout750秒。脚本没有提交任务；780秒调度上限仍由外部提交命令负责，不能只靠脚本声称已设定scheduler上限。任何assert失败进入exception保存error并raise，finally记录结束时间，外壳set-e会保留非零退出。

## 审阅SHA256

- `prepare.py`：`1b2426dc898ad1ebba17120daeeef08bc453486a30b56fbd2b8af70610e56f60`
- `STAGE_SOURCE_PROOF.json`：`e4af5451026f70de9f81aa97259f6e05e13b88deb93b638e066bd634efdc7a47`
- `woa.py`：`2a88fd9410945d2dc357f2c00711174fb21781b006df6d9a60089ccdf8a321df`
- `bf16.py`：`06ef287c3396d959ae9b93b9bb46bdfbaef04d7b1ec88ae6af24ea57f04bf457`
- `quant.py`：`fc086409e437a8581e53223e4b4a3b06e3b55cb732d553229f71fcb19e56695d`
- `wob.py`：`5dc5d3b7aa3d548daf6715fb76be7d08cc077556d09e49b258e6a78966591ffe`
- `dequant.py`：`e23b9943782daedfb86a6e6c4784eb00475c94cad40435c5026641a571ee3894`
- `hcpost.py`：`89af19a920b8101fb41ec189a3823e53dcbee2049c88f4d312a3b631b51f8412`
- `stage_probe.py`：`74297ecc806ab3bad8ac474da0a6807c907a9ca2ee635947edf3278706b3e355`
- `run-stages.sh`：`259caeff484604d3b29a75d74a284cf4aea66fa5f6de7da9b2d8da6afef9e9a4`
- `prepare_harness.py`：`fac58bcb9345aafa77b260a925038082a67751f392a98840b0864f671e5a91e8`
