# 常驻后缀接入完整CSA的最小方案独立审查

## 判断

**方案原则合理：可以保留64Tensor根ABI、单PTO顶层、纯DSL及真正TND。** 在O-proj的兄弟scope内部创建私有GM工作区、显式零填signal，再调用24组MIX的inline group，不需要增加第65个根参数，不需要更改SDK/codegen或加入C++数学。

这是待实现/待编译/待整层验收的方案判断，不是现有后缀已可正式替换的结论。phase1 T126虽然对原resident改善36.76%，仍比同任务冻结后缀慢23.13%；T240尚待完成。完整接入只宜私有实验，正式旧路径继续保留，不因相对慢resident的改善就推断相对正式CSA有收益。

只读审查，未修改源码或运行设备。

## 当前正式根及替换边界

已核当前`deepseek_v4_flash_csa_tnd_precision_spmd_overlap/decode_csa.py`：`_full_csa_tnd_prepacked`为64参数，prefix使用既有FFTS workspace；heads在Attention的内部scope产生后写入父级heads；最后两个兄弟scope分别调用`o_proj_entry`和`hc_post_entry`。

最小改法是只替换这两个末尾scope为一个后缀scope：

```text
父级原有heads/post/comb、projected_o/quantized_o/scale_o/attention_out保持
根级flat residual = reshape(x_hc, [tokens,16384])
根级flat output   = reshape(x_out,[tokens,16384])
后缀scope:
    private accum[tokens+127,8192] FP32
    private integer[tokens+127,4096] INT32
    private signals[6*72*128] INT32
    独立DSL zero任务完整写零signals
    真实zero→MIX任务依赖
    with pl.spmd(24,sync_start=True):
        调用已验收后缀的inline group(..., private workspace, signals)
返回原父级x_out描述符
```

不要在PTO根内部调用`pypto.torch.register`后的另一个运行算子，也不要嵌入另一个`@pl.jit`顶层。复用inline group且保留cluster/cube/vector实现，仍是一个PTO程序入口。原prefix、metadata、cache、Attention路径与其FFTS协议不应一起改。

## 第一个硬条件：初始化必须是实际依赖，不是代码顺序

`pl.create_tensor`只声明/分配存储，不保证内存为0；ring复用的signals可能含旧代际/旧phase值。必须每次完整根执行都重置全部55296个INT32（221184 bytes），不能只清phase0或部分used槽。

zero任务应把signals作为真正的Out，返回同一父级描述符，并在consumer侧作为InOut传给MIX。生成的orchestration应明确MIX依赖**全部**zero任务完成；可用既有task join/dummy机制确保依赖，但不能只认为两个语句相邻便会按设备完成顺序执行。

独立zero task最后需完成本核MTE3写回；优先显式保留DSL `bar_all()`及现有合法发布语义。不得把zero放入MIX某个角色再让其它角色无依赖地先begin；那会出现读旧phase0/旧phase完成值的竞态，GE wait可能错误提前通过或永久等待。

原heads/post/comb也必须通过实际Tensor读写依赖连接到MIX。前序scope退出不替代这些依赖。局部alias若跨inline/scope，应核actual task参数的tensor基址/owner，不用额外GM复制制造表面依赖。

### scope不是设备完成屏障

已读本次SDK：`OrchestratorState::end_scope()`调用`scheduler.on_scope_end()`；后者释放producer scope引用，并由任务完成/consumer引用控制回收。它不在源码中无条件等待该scope所有AIC/AIV完成。

因此“进入下一个兄弟scope”不等于前scope GPU已经空闲。正确Tensor依赖和allocator引用才保证scratch不提前复用。新scope的signals也须在zero/MIX完成前始终持有，最后一个consumer结束后方可回收。旧Indexer/Attention scratch在异步执行时是否已退休，要以实际task/ring依赖和峰值审计为准。

## 第二个硬条件：fresh generation=1的适用范围

signals每次由zero完全完成后，原begin读phase0=0，各核推进到1；本次其它phase发布1，wait使用本次1。下一次完整调用必须在此前整次MIX完成、再zero之后开始；同一buffer不能跨stream或跨调用并发。

这与当前外部persistent signals每次generation单调推进的诊断不同，但在“每次彻底重置、重置严格先于任何consumer”的合同下正确，不存在本次代际溢出。不能为节省初始化而隔次清零，也不能只清控制槽：旧phase5=1配合新generation=1会被误认为本轮完成。

集成门禁要明确验证：每次完整调用重置后所有used槽均为1、unused槽/隔离区为0；旧外部harness每次+100的预期不适用于内部fresh工作区。必须单独证明zero每次执行，而不能把generation始终1当作充分证据。可用debug初始化poison/连续A/B/A多次回放、DFX/实际DAG及zero/MIX执行计数联合检查；不要只读到常数1就宣布同步正确。

## 零填实现的最小选择与成本

可先用一个独立AIV任务，循环对小的合法tile写零全部signal区域；或用独立SPMD按互不重叠tile条带分摊。总216KiB超过常见单UB可用容量，不能创建一个全尺寸Vec tile后期待免费放下。单核/多核方案应先选最简单能完整编译、Out覆盖可证明的一种，不在首次接入时做复杂初始化流水。

多zero任务必须合成完整Out依赖，不能MIX只依赖最后一个零填worker。零填与MIX属于额外内部任务，但不增加顶层runtime入口或根参数。它会增加runtime调度/任务记录/GM清零和cache维护成本；完整性能比较必须包含这些成本，不能只拿不含init的后缀诊断数字外推。

## 第三个硬条件：零拷贝view与Out纪律

x_hc/x_out均为根级真实[T,4,4096]BF16连续Tensor，reshape成[T,16384]在这里应只是GM描述符变化，数学不变。创建view应在父级，避免把内层scope返回SSA别名误当成仍有效的根输出。

须在实际IR/生成物核：

- flat residual与x_hc同GM地址/offset，flat output与x_out同地址/offset；没有新增copy/transpose/GM重排；
- 索引及stride对应原四残差布局，符合已经验收的HC-post左折叠；
- 根x_out仍是Out，没有真实读未初始化output的指令；helper虽将全部中间值声明为InOut，不能通过清零x_out来掩盖方向/SSA错误；
- MIX返回全部8个InOut，合法重绑，同时保持返回原父级x_out描述符，子scope alias不逃逸；
- root仍恰64Tensor，prefix的32Tensor/FFTS参数不变，suffix内部16Tensor不意外提升为第65个外部参数。

如果现有DSL对动态shape/Out alias不能推断，先定位到最小caller/descriptor结构；不要放宽verifier、修改SDK或换成Native/C++实现。

## 内存规模与256MiB ring风险

候选拟用accum=(T+127)*8192*4、integer=(T+127)*4096*4、signals=221184 bytes：

| T | 这三份私有scratch合计 MiB |
| --- | ---: |
| 18 | 7.007812 |
| 96 | 10.664062 |
| 126 | 12.070312 |
| 240 | 17.414062 |
| 256 | 18.164062 |

当前正式O-proj原本已有accum(T+127)和integer(T+63)，因此本提案相对其名义scratch仅增加64*4096*4+216KiB=**1.2109375 MiB**。但两个旧scope原先的任务数、回收顺序和长生命周期输出不同，不能由此断言实际ring峰值也恰好只增加该值。

保留兄弟scope关系有助于释放阶段私有scratch；不要把signals/accum/integer移到根级让所有阶段一直持有，也不要把Indexer大arena与新后缀scratch放入同一巨型scope。父级heads、Q、cache view、中间结果、task/dep描述符及对齐碎片仍需计入；ring容量应按实际每ring峰值而不是全程序静态tensor字节和判定。

进入硬件前检查actual alloc_tensors/scope/ring分组，确保zero与MIX在合适的同生命周期域、没有隐藏扩大临时tensor或重复分配。首个复杂配置前检查heap占用与allocator等待，不能复用历史B16 arena问题的“scope退出就同步完成”错误假设。

## 不能采用的捷径

- 不借用spmd_ffts当GM signals：当前前缀是256个INT64 FFTS协议，与55296个INT32/216KiB的payload及生命周期完全不同。
- 不覆盖order_packet、权重packet或只读root Tensor作信号，不能通过改dtype/view把未获容量合同的workspace强塞进去。
- 不直接复用prefix临时workspace而忽略它的其它alias/读consumer；scope源代码靠后不证明读完。
- 不为了保64ABI隐藏全局Python singleton signals；那会引入跨层/stream并发与图生命周期问题，且改变当前单根纯DSL合同。

## 替代方案

1. **继续保留正式旧后缀**作为控制/回退，私有新根先试局部集成。当前这是无风险方案，也符合尚未证明resident快于frozen的事实。
2. 若局部signals重置和分配成本吞掉收益，之后可另立版本，把信号作为现有某个外部scratch packet的显式尾区，扩大该packet容量而保持参数数量。但这实际上改变workspace ABI/alias/服务生命周期合同，必须独立设计、资格检查及零初始化，不能在本次最小集成里偷偷实施。
3. 给根增加第65个workspace参数是更直接的长期方案，但不满足本次64ABI目标，不作为当前实施建议。单独绑定后缀root则会破坏单PTO顶层，也不建议。

## 最小验证顺序

1. 等phase1 T240/同任务DFX结论，先确认值得私有集成；不切正式路径。
2. 建报告目录独立根，保持prefix/QKV/Indexer/Attention全部源码及ABI原样，替换末两个scope；CPU核actual math/zero全覆盖、64根参数、16内部参数、Out alias及DAG。
3. 完整GCC/PTOAS/CCEC与actual物理审查：zero写回完成→MIX、heads/post/comb生产者、全部task completion引用/环内分配、最终输出store。
4. 单层短T/混合真实请求FULL A/B/A，同Native与正式旧根逐位检查既有八边界；通过后再大T。内部fresh signals采用本方案专用观测，不能照搬外置persistent代际断言。
5. 同任务无插桩完整CSA性能必须包括zero/alloc，再判断相对正式旧根是否稳定改善；只有通过且确有必要，才做已约定8K/128K真实整模型token验收。各任务继续≤15分钟，首差停止。

## 审阅源身份

- `vllm-ascend-nalinaly-tnd-20261008-codex/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision_spmd_overlap/decode_csa.py`：`0bf0a034f92e4a34f50a42eaa217edfe2d043b793afc382c15b67cdd5e3c52be`
- `reports/dsv4-tnd-spmd-baseline-20261020/resident-suffix-candidate.py`：`a31a78f89e1ed71c007de2b692434cc0a0f1bc35626b22188418b3e715edd022`
- `reports/dsv4-tnd-spmd-baseline-20261020/sdk-sources/simpler/src/a2a3/runtime/tensormap_and_ringbuffer/runtime/orchestrator.cpp`：`29e93a0bee716cb788e20dd7ffce2795246819d916abb010925f10d1158d95e7`
- `reports/dsv4-tnd-spmd-baseline-20261020/sdk-sources/simpler/src/a2a3/runtime/tensormap_and_ringbuffer/runtime/scheduler/scheduler.h`：`d3d565fc8485cdd06fd20e1d984e40211be5805d1bbf106048da19fa5eb5d20e`
