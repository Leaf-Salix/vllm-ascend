# 三臂单因素后缀harness独立审查

## 结论

**通用harness审查通过，未发现阻断。** 新候选尚未生成或编译，本结论不代表任何新候选已通过精度、同步或性能验收。只读审查，无设备执行、无源码修改。

三臂均为真实L4 WO-A/B权重、合成heads/residual/post/comb，比较范围O-proj+HC-post；金值为冻结PTO数学，不是直接Native后缀、完整CSA或整模型。

## 三臂隔离和guard

| 对象 | 原resident | new单因素候选 | 检查 |
| --- | --- | --- | --- |
| 五个公开输出 | resident独立bundle | new独立bundle | 各自与frozen五边界逐位比较 |
| FP32 accum | `buffer(T+127,8192)` | 另一次`buffer(T+127,8192)` | 两者均进入同一guard列表 |
| INT32 integer | `buffer(T+63,4096)` | 另一次`buffer(T+63,4096)` | 两者均进入同一guard列表 |
| signals | 独立owner，首次0 | 另一独立owner，首次0 | 两个owner首尾各128个INT32 guard；used槽同generation、unused槽和隔离区0 |
| HC-post二维Out | resident output的view | new output的view | 原生torch.view保持同storage，公开三维output直接逐位检查 |

新增工作区没有遗漏外围guard。五输出与工作区由不同仍存活的torch分配持有，不存在因释放导致的allocator复用。new_flat是直接view而不是copy；实际数学调用确实使用new_flat/new_accum/new_integer/new_signals，未误接到parent工作区。

目前显式pointer唯一性断言只覆盖原resident那组；建议在新候选准备时扩展到两臂全部非alias对象，并对new_flat复制父臂相同的pointer/offset/contiguous断言。这是低成本前置合同补强，不是已发现的实际别名。

## A/B/A、循环毒化与gold

- eager先运行frozen、parent、new，再分别检查parent/new对frozen五边界（共10项）。
- FULL_A、FULL_B、FULL_A_restore均按frozen→parent→new顺序逐臂poison/replay，再检查两臂与当前gold。浮点NaN毒化；parent/new的INT8量化输出以**刚执行的frozen结果逐元素反码**毒化，保证每个位置不同于gold。
- frozen的INT8毒化来自上一轮parent反码。其目标是排除沿用旧输出；当前gold仍是冻结数学重算，parent/new对其独立逐位检查。不能将这里的循环参照误称为独立Native INT8观测金值。
- B输入由heads+0.03125生成，要求frozen输出相对A有变化；恢复A后parent结果与保存的A逐位一致，new与parent共同对frozen逐位一致，因此恢复检查覆盖new，没有因只显式检查parent-A而遗漏new。
- 计时窗口不重复poison，不往event区间插入CPU检查/拷贝。每窗结束重新比较五边界并查所有guards和只读输入，避免以额外毒化成本污染计时。相同输入重复窗口本身不能证明每次每个输出都被重新写回，但预先FULL poison/A-B-A及generation增量构成当前门禁，不应将其夸大为每次逐元素写入监控。
- 未比较内部FP32/INT32 workspace本身的gold；本轮候选应只改等待或pipeline，五边界逐位输出与源码数学AST/原K次序证明是验收合同。若之后改内部数值链，须增加对应阶段观测，不能仅复用本合同。

## 双generation和graph

parent/new的signals分开，`generation()`分别验证完整used槽和隔离区。`compare()`要求两臂当前generation相等；FULL_A额外检查parent+1，再由相等关系约束new。FULL_B/A_restore两臂均重放，父source已固定a31，任一新臂漏推进会在相等检查被拒绝。

每个计时窗口保存两个before，完成三臂后分别要求+100；这可拒绝一臂未执行/执行次数不同。现有检查不是只比较两个相等常数。期望完整常规运行的最终值为1204；result记录两个实际值，归档可另核对该值而不放宽现有增量门禁。

capture和event在同一显式NPU stream，stream预先wait默认流；poison/replay、A/B/A和CPU检查有同步边界，event只覆盖100次graph replay。三个graph的workspace独立，因此顺序轮换不会让一臂读另一臂中间buffer。候选/parent的注册namespace不同，新root没有误用父Python对象。

## 顺序与计时偏差

独立CPU展开12窗rotate+奇数reverse规则：每一臂位于第1/2/3位置均恰好4次，三臂位置平衡。每臂12个100次回放的窗口均值，保留min/mean/median/max和全部原始样本；median仍是**窗口均值中位数**。

同一任务比较parent/new适合归因单因素；frozen是同输入性能控制。三个arm可能具有不同cache热度/资源驻留，轮换减轻顺序偏差但不能完全消除。不能把微小变化凭一个中位数认定稳定收益，应检查配对窗口方向及跨重复任务表现。未开启PMU/DFX的ab计时不能混入另任务的插桩延迟。

## 进入候选验收前的必要限定

1. 当前candidate文件/证明尚无，只有proof.parent==a31和候选文件SHA门禁；这只能绑定身份，不能自行证明“只改一个因素”。需要独立核候选实际AST差异及生成代码。
2. generation和signal分配假定新候选保持原6×72×128槽协议。建议在导入后显式断言new_module.WORDS/CORES/STRIDE等于parent；若协议改变，必须另立harness，不能复用此大小猜测。
3. 共享的PyPTO编译cache不是执行身份的证明。无设备编译收据/实际root及核配置应绑定候选SHA，与parent分别确认，避免旧cache或误注册造成测到相同实现。
4. 公开五边界、readonly、signal/工作区guard、代际检查不可删。单因素候选源码一旦改变数学或输出布局，此通用审批不自动延续。

这些是新候选的进入条件，不是要求当前在没有候选时先提交任务或安装环境。

## PMU派生核对

逐文本diff确认`stage_probe_pmu.py`相对已排队的`stage_probe.py`只增加两行：profile前读generation，profile结束后要求resident+3、阶段+0。没有改变数学、阶段提取、poison、phase检查或普通计时分支。`run-pmu.sh`只改调用文件，原run-stages脚本/排队probe未覆盖。

PMU仍是独立插桩模式，phase检查计数应3；stages模式应14。profile能否在当前运行时重复初始化属于工具兼容性，失败须记录，不是数学失败；利用率/独立阶段耗时不可相加为完整后缀关键路径。

## 可复现性与退出

`prepare_ab_harness.py`当前生成逻辑与实际ab_probe对应。后续若补候选合同，需同步生成器或明确归档运行文件为准。case/variant由CLI及argparse限定，TASK_DEVICE映射、私有SDK/PTOAS、OPP/cache/log、750秒process timeout沿用已审版本；780秒task上限仍依赖提交命令。异常保存error并raise，finally写结束时间，set-e保留非零状态。

## 审阅文件SHA256

- `prepare_ab_harness.py`：`bc12fc259cd51c144abb6d40e5aa11034d40b6784e5d858fca6f39a5362d5339`
- `ab_probe.py`：`6f3f8b5d15130f3b474cd9d79e51cc09cb156ba2c91ba2850aa1defbcc7d3e48`
- `run-ab.sh`：`8da6b5156e343c421e43a7ca4e81bffd34bf0a32917e94b8fa03c46461012588`
- `stage_probe.py`：`74297ecc806ab3bad8ac474da0a6807c907a9ca2ee635947edf3278706b3e355`
- `stage_probe_pmu.py`：`b493b9f084c2651608757f594e9b171d17ea805bb62abf81be1fa73f9ef2238c`
- `run-pmu.sh`：`588fd15db8d58d1fa15a21e0cffcc09720f88950f4deb4d08cf0ecdff6c6c361`
