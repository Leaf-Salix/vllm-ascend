# phase1 + WO-B M128组合独立审查

## 结论

**源码及通用三臂harness审查通过，无实现阻断；仍为私有待测组合，不能提前晋升。** 按当前流程先等phase1 T240稳定通过，再决定提交组合NPU。无需修改SDK、ISA或正式运行源。本审查没有提交任务或重编译。

## 组合完整性

独立解析当前文件逐函数AST核验：

- combo.cube逐AST等于已审m128.cube；
- combo.vector逐AST等于已审phase1.vector；
- begin/publish/wait_group/group/resident_suffix全部等于a31父实现；
- 根16Tensor、8InOut返回及24组MIX结构保持；
- phase5仍是原`wait_group(signals,5,24,72,generation)`，没有混入phase5优化。

candidate-combo.json的候选字节SHA与文件相符，components记录的两个源SHA正确。该证明是两个不相交源码块的组合，不等于二者设备资源/性能独立。

## 数学、依赖和容量

phase1只缩小BF16 cast取得accum的生产者集合。其group=worker%8、8个AIC owner公式及空worker条件沿用已证明实现；获取维护和publish2原位保留。WO-A Native K序、投影BF16边界、全8192共同amax、INT8舍入链、反量化和HC-post数学逐AST未变。

WO-B M128把独立输出行共享同一权重，仍N128，按首K512 seed和后15个K512累加覆盖8192。INT8点积所有部分和绝对≤2^27，不溢出INT32。有效行输出唯一writer/全覆盖证明可直接复用m128源码；phase1不改变这些地址或数值。

新AB限T≥96；new_integer=T+127，完整M128尾tile容量始终足够；new_accum仍T+127，两个工作区均经buffer()纳入外围guard。signals独立、清零且WORDS/CORES/STRIDE与parent一致；new_flat的pointer/offset/contiguous和两臂16个独立对象断言均保留。未用prefix FFTS，也不改变formal64根ABI。

WO-B owner随M128改变，但phase4仍等待全部24 AIC，不存在沿用旧精简owner公式漏等的问题；dequant和phase5任务分配也原样。前段phase1提前cast并未引入反向信号依赖，完整DAG无新增环。

## 编译及硬件前条件

check_combo.py会执行完整specialize、16参ABI、PTOAS/CCEC与Artifact.load，并要求CPU进程未初始化NPU。当前本审查不冒认这些尚未交付的运行结果；通过后仍需actual资源/别名/尾行写回核验及五边界硬件门禁。

即使source cube等于m128，组合生成时仍应确认AIC实际核配置与L0C/L1/GM资源没有受整体编译/liveness变化影响。不能把两个component各自编译通过直接等同组合已通过。前序phase1 T240的“先通过再提交”在proof.scope中是流程合同，combo_probe没有自动读取其JSON；须由主流程严格执行，不能因为CLI可运行就提前提交。

## harness、精度与代际

combo_probe相对当前ab_probe仅变CLI choices/范围、scope标签和combo专用integer容量条件。三臂仍为frozen、a31 parent、combo；前置eager/FULL A/B/A，NaN/整数逐元素反码毒化、五边界相对frozen逐位、所有guard/readonly及双generation增量不放宽。

12窗每臂100次回放，parent/new各每窗+100，末值应各1204。三臂每个位置出现4次的轮换保持，event区间不混入CPU检查/poison；raw样本和失败记录保留。单task≤750秒进程/≤780秒调度仍需外层提交器设置后者。

## 统计解释

当前三臂设计可说明combo对同任务a31和frozen的**组合净效果**，不能独立估计phase1×m128的交互项：同一任务缺少phase1-only和m128-only两个格子，不是四格factorial实验。此前两单因素的跨任务中位数只作背景，不可与combo直接相减计算“新增m128收益”，也不可相加下降百分比预测结果。

因此“two-factor interaction experiment”只宜理解为检查组合是否出现回退/精度问题，不应发表统计意义上的独立交互量。若净收益良好，先不新增更大实验，仅以同任务paired窗判断；如果需要严谨归因交互，才考虑同任务加入两个单因素arm并重新平衡轮换。

组合改善a31仍不代表已追平冻结PTO，更不等于完整CSA/整模型改善。进入完整根的零填/内部alloc成本尚未包含；不能将此结果提前赋予未来集成版本。

## 状态与source identity

正式checkout未被本次审查修改；候选、helper、证明均留reports。以下SHA固定当前审查对象；任何改动应重新冻结，并保持首差停止。

- `candidate-combo.py`：`21ba383eb60c7c2c4a7a377d96c0caac4500f6fc60ab370c54d0d8e1adbc757b`
- `candidate-combo.json`：`22c948d24094f419658c8e4c93e1bc535a5801da449ae733a34fe99cf1d9f6e2`
- `combo_probe.py`：`3ad1c726ca39d552e8cb6bddab473698e5e0a6654de347b3a388949725128f04`
- `check_combo.py`：`09054bfd62d53f3f4443770543643dda8da2b5ed875c2160441a138c9576875f`
- `run-combo.sh`：`55b998cb2d22a9b30cc6772e9521397494386a341d11de046915c4abb88b4e03`
- `check-combo.sh`：`1589c8617391a572e9fb79b1cc00c2175873956ff3110c8ac7c0f29a74fe4162`
- `candidate-phase1.py`：`f22d7d8dd6ef2a48f640b88511c6c32c672ade0b116fa922f18c6a6a23237fe6`
- `candidate-m128.py`：`aaa880cd8d96c54fa560a1d9949288eefb487c24d1bbda93739640513368f0bb`
