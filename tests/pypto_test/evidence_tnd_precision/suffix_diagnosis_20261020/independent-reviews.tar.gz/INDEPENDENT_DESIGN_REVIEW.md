# 常驻后缀与nalinaly SPMD后缀：独立设计审查

## 结论和范围

当前常驻候选存在可静态证明的过宽等待集合，值得做单因素实验；**尚无证据证明它们就是性能回退的主要来源**。先等待本轮独立DFX/阶段时间结果，再判断实施顺序与是否保留。

本审查只读本地归档源码，不修改运行源、SDK或环境，不提交设备任务。参考归档为主线程固定的nalinaly `beaefa6f`；我们审查的候选为 `a31a78f89e1ed71c007de2b692434cc0a0f1bc35626b22188418b3e715edd022`。本轮三档后缀已通过冻结PTO数学五边界门禁，但这不是Native整层或整模型资格。

最多建议两个独立候选：**只缩小phase5等待集合**；**只排除phase3空闲量化核**。两项先各自对基线测，不合并成一个无法归因的实验。两项均不改K顺序、全8192统一量化、张量布局、任务分配、数据转运指令或缓存维护。

## 实现差异：哪些可借鉴，哪些不能照搬

| 部分 | nalinaly归档SPMD | 我们当前常驻后缀 | 对优化的约束 |
| --- | --- | --- | --- |
| WO-A | `output_projection_a_stages.py:115`，M128、K256递增、stage2；按group/行块/N列块归worker | `resident-suffix-candidate.py:66`起，64逻辑group/N128条带分给24 AIC；每行使用Native校准的cyclic K16次序；大T seed256，其余保留旧路径 | 不能为模仿Nal将Native K起点重置0；当前v4 wide的stage2→range也是已知实验变量 |
| WO-A写回边界 | FP32 O_A GM供量化消费 | FP32 accum GM，AIV独立cast到BF16 projected GM | 当前BF16落点必须保留，不能把Nal FP32量化入口当作等价实现 |
| 动态量化 | `output_projection_a_stages.py:184`，每token每组1024独立amax与scale；`act_scale_dq[8,T]` | `resident-suffix-candidate.py:287`，每token先遍历8组1024的BF16结果，求**全8192共同amax**；`token_scale[T,1]` | Nal可在一个group就绪时先量化/开始其WO-B，我们必须等该行全部8组WO-A，不能按1024独立放行 |
| WO-B | `output_projection_b_stages.py:116`起，按组1024 INT8点积，GM保存8组INT32 partial；NZ路径按形状选M及weight/activation驻留次序 | `resident-suffix-candidate.py:226`起，全8192按16个K512累加到一个INT32结果；M16或M64、N128 | INT32有效域无溢出仍不代表可以不加门禁地改量化/反量化结构；当前只借鉴依赖所有权 |
| 反量化与HC-post | `output_projection_b_stages.py:281`起，每行把8组partial×各自scale按组左折叠，乘channel，BF16后直接进入HC-post | `resident-suffix-candidate.py:315`起，INT32×(token_scale×channel)→BF16 attended GM；独立HC-post再读全行4096 | 两者不是相同数值链。直接移植Nal fused helper会改变数学，不能作为本轮安全单因素 |
| 阶段发布 | `phase_sync.py`发布每实际owner；`cube_schedule.py:422`、`vector_schedule.py:980`对组就绪选择wait_row_owners | 每个阶段所有24 AIC/48 AIV都发布，包含没有工作量的核；消费者无条件wait_group覆盖全部同类核 | 可以保留发布协议，仅缩小消费者等待集合，不需要引入新signal ABI |
| 数据寿命 | 文档明确阶段信号不是消费者ACK，业务缓存需另维护 | accum/integer/projected/quantized/attended独立、每代不循环覆盖 | 减等待不能意味着可复用上一阶段存储；本次候选不改变任何存储寿命 |

`bar_all()`只排空**本核**流水，不是跨24/48核屏障。`wait_group`是逐owner等待的依赖集合；当前无条件覆盖全部同类生产者，效果上形成阶段集合等待，但不能把每条signal_wait的总数直接乘常数得到墙钟同步耗时。Nal的notify适配同样保留本核PIPE_ALL及payload cache维护，不能以“借鉴Nal”为由直接删除我们的bar/fence/cacheinvalid。

## 当前五条跨角色/阶段依赖的实际所有权

以下公式来自当前候选的实际loop/offset，而不是Nal通用`wait_row_owners`假定。T限定当前入口`1..256`；`rb=floor(token/16)`、`qb=floor(token/8)`，AIV硬件signal core为`24+worker`。

| 消费阶段 | 当前等待 | 实际需要的生产者 | 能否直接删除等待 |
| --- | --- | --- | --- |
| WO-A FP32→BF16 cast | phase1全部24 AIC | 对group g的1024列，需要8个N128 owner：`(8*g+n)%24, n=0..7`；每owner信号覆盖其所有行panel | 不能删除，8个块可能不同核；可后续缩小但本轮不列第3候选 |
| 全8192 quant | phase2全部48 AIV | 该8行块所在16行rb的8个group-cast owner：`(8*rb+g)%48, g=0..7` | 不能只等单group；完整8192 amax跨所有8个owner |
| WO-B | phase3全部48 AIV | 每个M64块读取其有效行对应8行quant tile；当前全任务保守并集为`worker=0..ceil(T/8)-1` | 非空quant owner完成是必需的；空核完成不携带payload依赖 |
| INT32→BF16 attended | phase4全部24 AIC | 当前512列块dc读取4个N128；大T owner=`(32*floor(rb/4)+4*dc+n)%24, n=0..3`；T≤16窄路径为`(4*dc+n)%24` | 不能删除；每个512列tile跨4个Cube producer |
| HC-post | phase5全部48 AIV | 每个token的4096列来自8个512列dequant owner：`(8*rb+dc)%48, dc=0..7` | 不能只等HCpost所在AIV；但其余40个owner不写该token的attended |

注意：信号是“这个owner本阶段的**全部**任务都完成”，因此上表即使只需某owner一块，也会等待其其它块；这是保守正确，不是tile级最细通知。此处不新增逐tile复用槽/ACK，以免扩大同步与存储协议。

## 单因素一：phase5只等HC-post所读8个owner

保持所有phase5 publish原样，包括空工作核；仅替换`resident-suffix-candidate.py:329`处无条件等待全部48核。

当前HC-post将4行tile编号`token_block`按`worker+48*k`分配。对该AIV的任一有效tile：

```text
row = 4*(worker+48*k)
rb = floor(row/16) = floor(worker/4)+12*k
dequant_owner = (8*rb+dc)%48
              = (8*floor(worker/4)+dc)%48, dc=0..7
```

所以一个AIV的所有HC-post任务恰好依赖同一组8个dequant owner。可在HC-post原loop前：仅`worker < ceil(T/4)`的核，等待这8个owner的phase5当前generation；随后保留与原wait_group相同的一次fence/cacheinvalid/fence，再原样执行HC-post loop。没有HC-post任务的核无需获取attended，但仍已按原协议publish5。

CPU只读枚举已验证T=1..256的所有worker、所有有效token与512列块，公式产生的owner集合与实际生产者集合完全相同。T18/T126/T240 signal_wait调用数从固定2304减为40/256/384。**这是静态调用数变化，不是预测节省对应比例的设备时间。**

为什么安全：全部8个写入owner在publish5前完成业务写回并维护cache；consumer等待后仍获取payload。不同owner只写不相交的attended行列块；attended本代内不再覆盖。数学、BF16落点、HC-post四项左折叠、最终store顺序均不变。

潜在收益来自减少空核/无关owner轮询及全阶段慢核牵制；若DFX显示phase5或Scalar轮询不在关键路径，收益可能为零。必须以设备原始计时和逐位门禁判定。

## 单因素二：phase3不等没有quant任务的AIV

保持quant任务、全8192取amax、量化顺序、所有phase3 publish以及WO-B loop原样，只把`resident-suffix-candidate.py:225`中的等待区间由`[24,72)`缩为`[24,24+ceil(T/8))`。

证明：quant循环为`block=worker; block<ceil(T/8); block+=48`；当前T≤256，`ceil(T/8)≤32<48`，因此每个活动worker恰好负责一个8行块，且活动owner严格是连续区间`0..ceil(T/8)-1`。区间外AIV没有quant payload写入。继续等待所有真实量化owner属于保守做法，覆盖每个AIC WO-B所读行的并集，无需在Cube各块之间插新等待或更改流水。

CPU只读枚举T=1..256，每个有效token的quant owner均在该区间，区间内每个owner都有有效任务。T18/T126/T240 AIC侧signal_wait总数从固定1152减为72/384/720。保持一次原样payload cache维护，不删除publish和begin，也不修改signal工作区布局/代际检测。

本项主要去掉空核等待及循环指令，不保证形成跨阶段重叠；只要活动量化完成才是WO-B启动限制，实际节省可能很小。可单独测试三个T，不与单因素一一起初测。

## 缓存、覆盖与死锁边界

1. 两项都保留begin/publish及所有72个参与核，generation/信号槽布局完全不变。空核仍发布，现有harness的代际及零隔离区门禁无需放宽。
2. 原DAG仍是WO-A→cast→quant→WO-B→dequant→HC-post；没有任何消费者反向阻止生产者发布所等待阶段。缩小等待集合只删除不必要边，不引入循环。
3. 发布前本核流水排空和payload cache维护不能删除；获取最后一个必需signal后仍做原fence/cacheinvalid/fence。不能以Scalar信号可见替代GM payload可见。
4. accum、integer_accum与五类公开中间输出继续独立且不可alias。不能把“某owner完成”当作所有consumer读完，不允许提前覆盖projected/quantized/attended或循环复用其存储。
5. 缓冲区/信号仍由单个顺序图/流独占，下一次调用只能在本次整个MIX完成后开始；kernel完成及末尾本核bar必须保证所有输出写回完成。若跨stream并发或提前启动下一代，以上简单完成通知不提供ACK或隔离能力。
6. 原workspace需首次清零，失败后重建，INT32generation不得绕回。不得为减少等待移除无工作核begin或改变代际推进。

## 验证及解释方式

- CPU先对候选实际AST证明：只改所选依赖集合；所有MMA/K16轨迹、量化8组最大值顺序、五个公开输出的数学AST原样。再次枚举T1..256所有行/列读写owner，空闲核也发布。
- 无设备生成核对signal_wait实参、所有payload store先于publish、cache/fence保留、全部8个InOut返值/16参ABI不变。不要以仅CPU数学证明代替设备内存可见性门禁。
- 原有T18/126/240真实L4权重五边界，eager+FULL A/B/A、zero/tiny如现有fixture、poison、read-only、workspace/信号guard、代际推进全部保留；发现首差即停。先不扩大整模型。
- 无DFX的同卡交错12×100记录所有窗口，与同任务原基线比较；DFX/阶段测量另跑，不能拿DFX采样延迟当正式延迟。阶段包络与等待可重叠，不能相加推导总耗时。
- 计算、转运、等待归因须看实际AIC/AIV流水和关键路径；现有三档后缀回退不证明同步唯一主因，也不证明Nal数学可直接移植。

## 审阅源SHA256

- `resident-suffix-candidate.py`：`a31a78f89e1ed71c007de2b692434cc0a0f1bc35626b22188418b3e715edd022`
- `vllm_ascend/ops/pypto/deepseek_v4_flash_csa_spmd/output_projection_a_stages.py`：`0875df14c79482242bf00a665006ac8e30e98c91a3f50650d75d6cec9843b739`
- `vllm_ascend/ops/pypto/deepseek_v4_flash_csa_spmd/output_projection_b_stages.py`：`b50707b2f7c806350bf7c6404df32136c1596f0764f9677afc4bff0436a8f0de`
- `vllm_ascend/ops/pypto/deepseek_v4_flash_csa_spmd/phase_sync.py`：`2ced215a4fc0be24604e626e451e7c0eca176b0b1e670051c8616aae1d7e20e7`
- `vllm_ascend/ops/pypto/deepseek_v4_flash_csa_spmd/signals.py`：`170ea7766ba335f3611e55718c8b82918af04dd232393c134a3ace4e0bbbb933`
- `vllm_ascend/ops/pypto/deepseek_v4_flash_csa_spmd/cube_schedule.py`：`b43a85dd6ebeef5915478a7bcbac127026bbbe0a7fc2709882a0876e56f00cb5`
- `vllm_ascend/ops/pypto/deepseek_v4_flash_csa_spmd/vector_schedule.py`：`e1a6725a2668e6f010e7971a4295bc47e3e7211767095a4c56f6b7d6428c71ad`
