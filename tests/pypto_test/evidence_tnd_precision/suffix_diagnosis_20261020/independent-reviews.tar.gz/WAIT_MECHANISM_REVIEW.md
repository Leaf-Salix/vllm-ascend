# 等待机制、phase1候选及T126实证独立审查

## 结论

**phase1源码与现有owner证明一致，T126单任务性能/精度结果可信。** 可以表述为“精简前段真实依赖集合后，本任务后缀性能显著改善，保持五边界逐位一致”。

归档TWAIT实现支持“多个AIV持续轮询可能与生产者/其它消费者争用缓存或访问资源”的机制假说；当前没有独立signal/cache/DDR流量或未就绪轮询次数计数，**不能写成已经证明的唯一根因，也不能说每次poll都访问DDR**。T240和同任务DFX尚待完成，本审查没有提前赋予其结果。

只读审查，无源码修改、无设备提交。正式环境和原始基准保持。

## 实际候选源码

父源a31a78f8，新源f22d7d8d。独立逐函数AST比较：仅vector函数phase1获取块不同，其余所有函数原样；vector的数学、所有任务owner、BF16 cast、store、publish2以及后续quant/WO-B/HC-post未改。

实际变更：

```text
原：所有AIV等待phase1 AIC0..23
新：有cast任务的AIV等待
    owner=(8*(worker%8)+dep)%24，dep=0..7
    然后保留原fence/cacheinvalid/fence
    空cast核跳获取，但仍执行原publish2
```

证明：cast block=worker+48*k，group=block%8=worker%8。读取的1024列由WO-A的8个N128块组成；Cube逻辑编号group*8+n，producer为其mod24。该owner的phase1在其全部逻辑任务和全部行panel完成后发布，覆盖同AIV所有cast rb。独立CPU再枚举T1..256、全部48个AIV和所有有效cast任务，owner集合及空核判断完全一致。

每组写入独立1024列，地址/有效尾行原样；所有必要生产者完成及payload获取都保留。Cube在发布phase1之前不等待cast，不产生反向依赖；quant仍保持原phase2等待与全8192共同amax，未把Nal的每1024独立量化移植进来。工作区本代无循环覆盖，信号仍不是consumer ACK；跨调用必须顺序独占并等待整个MIX完成。

## T126原始JSON独立核验

| 臂 | 中位数 μs | 平均 μs | 范围 μs |
| --- | ---: | ---: | ---: |
| frozen | 407.814198 | 408.265273 | 406.157417～411.608200 |
| parent resident | 794.079819 | 793.318996 | 789.451370～795.562363 |
| phase1候选 | 502.140388 | 501.885583 | 499.686394～503.498611 |

独立重算12窗每臂min/median/mean/max，与原始字段一致。候选对同任务parent中位延迟下降**36.764494%**，12/12配对窗口改善；仍比同任务frozen慢**23.129698%**。保留全部样本，没有删样。

160项bit_equal均true、different_elements/max_abs均0，eager、FULL A/B/A及12窗门禁均保留；parent/new最终generation各1204，guards/readonly/actual_acl_graph均true，source proof绑定实际f22d候选。160项指多个检查点的五边界比较，不是160个不同输入。

此为真实L4权重、合成后缀输入、单卡O-proj+HC-post FULL图；不是完整CSA或真实整模型192-token验收。跨任务parent值存在漂移，不能将本候选与先前phase5/m128的绝对延迟直接排序或把各下降百分比相加。

## TWAIT实际实现能证明什么

本地归档包含`include/pto/comm/a2a3/TWait.hpp`，内容SHA为fcb4e369…；压缩包SHA为dfb3175b…，二者不是同一身份。归档被主线程记录为实际ISA327cd…源；本审查读到的是该头文件内容，不冒认另做了二进制反汇编或重新编译。

头文件中：

1. signal通过`volatile __gm__ int32_t*`读取；
2. 每轮对待检查槽先`dcci(...SINGLE_CACHE_LINE)`，再按比较条件读取；
3. 若某个值未满足，退出本轮信号遍历，while继续；
4. spin每64个未满足轮次执行一次`pipe_barrier(PIPE_ALL)`；
5. 没有显式sleep、yield或递增backoff；有1亿次spin的deadlock断言。

这说明未满足时存在反复cache维护/读指令。PIPE_ALL是本核流水屏障，不等于已实现面向其它核的退避或fairness。单行dcci也不证明请求穿透全部cache抵达DDR；共享缓存命中、合并和实际总线事务尚未观测。

## 为什么“固定wait成本”不是充分解释

all-ready微基准相对wait0只增加约2.156/8.345 μs（24/48槽），而phase1改善约291.939 μs。因此把本次收益全部解释为“少了16次固定TWAIT调用”不符合该环境下的观测量级。

这并不反驳未就绪期间反复轮询的影响：微基准所有producer早已完成，每个wait很快满足；完整resident必须等待真实WO-A生产，失败循环次数和并发时序完全不同。两种测量的cache/任务环境也不同，不应用微基准差值做精确换算。

## 多人忙等干扰：合理假说及其它解释

静态可见的原位行为：旧phase1中48个AIV从同一个AIC0槽开始按0..23顺序等待，可能同时轮询第一个未就绪槽。新phase1按group分流，初始槽为0/8/16；T126的48个活动AIV按group%3分布为18/18/12，减少了单一初始槽上的消费者数，同时放行只依赖已完成那一组的cast。

这提供了两个同时发生、尚未被拆开的机制：

- 同一signal热点及总未就绪轮询可能减少，进而降低Scalar/cache访问压力；
- 消费者不再等无关AIC，可提前cast/发布phase2，改变前后阶段真实重叠和尾部关键路径。

此外，提前cast改变MTE/GM/cache并发，可能改善或恶化生产者速度；获取cacheinvalid的时间也变了。原AIC owner负责的逻辑任务数不完全相同，选8-owner会改变等慢核集合；这本身无需任何DDR争用也可能带来收益。因此目前没有充分依据把大幅改善唯一归因于“轮询拖慢生产者DDR”。

## 反证/证据强度判断

- 现有all-ready结果反对的是“纯固定指令成本解释”，不是对动态未就绪争用的反证。
- 目前没有Native精度反证：本T126五边界逐位通过；但不能据此保证其它T/输入或整模型。
- 如果后续同任务DFX显示候选AIC任务跨度也显著缩短，而AIC实际生成数学/搬运指令与父臂相同，可增强“跨角色并发环境影响生产者”的解释；仍不能单凭AIC更快区分signal流量、cache时序、资源重叠或地址分布。
- 若仅AIV跨度缩短，也与删除不必要依赖相符；不支持宣称生产者本身被优化。
- 无插桩AB负责收益，DFX只观察角色包络；两任务时间不可相减为内部phase成本。没有内部phase时戳/未就绪次数/traffic counter，唯一根因声明应继续保留为待证。

## 建议的最小后续判断

先读已提交T240和同任务L1结果，不因此加新任务或改SDK。核两臂AIC/AIV跨度、记录完整性和actual AIC生成体是否等同，结合五边界/双generation门禁确认范围。若T240不稳定，先保留T126局部结论，不把候选默认接入完整CSA。

只有确需进一步区分机制时，再另立单因素：例如维持原24-owner依赖全集但轮转首次等待顺序，或维持依赖/owner不变仅控制失败轮询节奏；它们分别更接近热点/轮询因果检验。但后者涉及SDK/接口授权和可见性风险，不属于当前批准实现，不建议直接修改ISA。当前不需要新增SDK改动。

## 审阅SHA256

- `candidate-phase1.py`：`f22d7d8dd6ef2a48f640b88511c6c32c672ade0b116fa922f18c6a6a23237fe6`
- `candidate-phase1.json`：`6ab6a5bbe8eef6386d648265a065a7067fa6e719aa266648dd7f0b8702381afe`
- `suffix-ab-phase1-t126-v1.json`：`e1c851f0025a803e810adf3b30ecf0bc77cbae39d9f5fcb5840f801e0c78f943`
- `OWNER_PROOF.json`：`2d4807257448582a65a09aacc4a5200202a8b15dcd721b8d0aece8cdadb2b6d9`
- `wait-isa-source-20261020.tar.gz`：`dfb3175b90b2755e07ceef8b5ca8bad6369e7b321de13745ae9622356874b210`
- `ab_probe.py`：`bf0ffabaf4ef12dd8d66e005e32db753a0222ab18f58f1b443c4be751b04afce`
- 包内`TWait.hpp`：`fcb4e369aa756e8aa3b39eaf86f896b79a15a848ce2ce8c3c81e786f783a5c07`
