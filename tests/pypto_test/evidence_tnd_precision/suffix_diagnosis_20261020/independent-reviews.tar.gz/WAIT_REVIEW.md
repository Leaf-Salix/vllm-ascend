# 就绪wait微基准独立审查

## 结论

**协议与计时设计通过，无阻断。** 这是48个AIV在producer已经全部完成时，重复读取已就绪signal并执行固定cache维护的微基准。它不测真实producer阻塞、完整后缀同步关键路径或数学性能；空targets是有意定义，不得将`phase_checks={}`的all([])=true写成数学精度通过。

本审查只读源码、独立静态分析，不执行设备。

## all-ready协议

- 前序完整resident已通过eager及FULL A/B/A，恢复A后取用其signals。`generation()`验证全部used槽同代、unused槽和隔离区0。
- 每个wait root保留16参ABI、24组SPMD及split_aiv，48个AIV均先对signals[0] cacheinvalid+fence，再读phase0 core0的当前generation；它不调用begin，不推进任何代际。
- wait24读取phase1的24个AIC槽；wait48读取phase5的48个AIV槽。这些槽由同一stream前序完整resident完成后已全部发布该generation；此处没有新producer，更没有等尚未到达的future generation。
- 窗口中若先跑resident，它完成后其信号统一推进；后续wait root每次从phase0读取新generation，仍对应已完成的一代。wait/frozen不会写signals。每arm的+100或+0门禁及最终槽一致性可拒绝意外推进。
- 前序FULL图完成、同stream串行与全部工作区独占是必要条件；不能将此root放到与producer并发的另一个stream仍称all-ready。

## wait0与公平性

wait0保留相同phase0读取、核数、ABI、root开销以及wait_group退出处的fence/cacheinvalid/fence，只将wait循环迭代设为0。wait24/48仅增加相应循环次数，但后者位于phase5/owner24起，地址和cache访问集合也不同，因此wait48-wait24不能严格解释成24次相同硬件指令的常数成本。

五臂是frozen、resident、wait0/24/48，12窗×100回放轮换并奇数反转；不混PMU的stages模式event在同stream记录，检查/CPU拷贝在event之外。12窗对5个位置不是完全平衡样本，不应根据微小差值估计精确每wait成本。应保留所有原始窗、看差距量级及重复结果。

每次wait root的48个AIV都读同一批只读槽，体现真实many-consumer访问开销，但不体现业务payload访问或producer同时写入引起的争用。wait0/24/48不处理工作区数学，不能拿其时间按完整后缀wait组数量相乘得到可节省总时间。

## 精度和数据保护

完整frozen/resident的五边界与A/B/A保留，保证微基准前的工作区资格。wait stages不写目标，targets为空，所以phase计数14只证明检查点执行过，不代表得到14次独立数学结果。公开五边界应在wait后保持不变，readonly与所有guard仍须通过。

若需要声称内部accum/integer也完全未改变，目前五公开边界不能直接证明，应额外做内部buffer SHA；当前正确窄声明只需要无数学输出、signals不推进、公开输出和外围guard不变。原数学写入器AST中没有wait-root数据store，支持这一窄声明。

## 身份与生成器

实际wait0/24/48文件的SHA均与WAIT_SOURCE_PROOF一致，proof parent为硬pin的a31。当前prepare_waits.py从a31抽取原wait_group及header，wait_group数学/维护AST没有改。生成器的parent字段是硬编码，未来若父文件变动，不能沿用此证明；建议重生成前校验父字节SHA，但当前父文件实际就是a31，不构成本轮阻断。

stages模式每wait阶段预期检查14次；PMU分支仍未有单独+3/+0增量断言，只具备状态一致性检查。若此次只提交stages，不受影响；PMU数据不得冒认该额外增量门禁已执行。

## DFX边界语义补充

已独立核对本次SDK `chip_swimlane_collector_aicpu.cpp:273`：每次record_run_boundary只写start_cycles和epoch=slot；`tensormap_and_ringbuffer/aicpu/aicpu_executor.cpp:1002`在每个kernel round prepare_execution成功后调用一次。run_boundaries不是起止对。

因此同一DFX窗内frozen执行O-proj及HC-post两个root，应有两条epoch0/1；resident和各isolated root只有一次apply，应各有一条epoch0。按实际root launch数量核验而不是强行每窗两条，是修正解析语义，不是放宽精度门禁，无需因此重跑。仍需dropped_run_boundaries=0及core/task记录完整。

## 审阅SHA256

- `prepare_waits.py`：`b2f38023559cb5f6d2e1a74ce6e50014e321b53c3d99c5f66a8f81896dc86276`
- `WAIT_SOURCE_PROOF.json`：`ad58203cb715a22def059d60be1e83218d684993eb14511bcad4642c0a287f2e`
- `wait0.py`：`a35af0d9a8d831b9f961befe1c9904e88896ec096f4b54fa67bc3d1082ceb2d3`
- `wait24.py`：`b62415a668423c52e31cdfd45b4d8462d8ad2b831ec90e3829db4dd8e46445a9`
- `wait48.py`：`99ad005eb04a6351d4d891d8a46e6047ad6c05c49fa1ca2fc311a4ee4dd86838`
- `wait_probe.py`：`aa426d672b24a6bb01725f23d322dc0339930c4492d4e103b9ab2ae85130a29c`
- `run-waits.sh`：`3524834ccda88214849a357187a727aa9ee860cfc27f05f6ffbc0db91585531f`
