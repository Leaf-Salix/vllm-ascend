"""独立O-proj/HC-post常驻候选；只换worker/grid/同步，未获设备资格。"""
import pypto.language as pl
T = pl.dynamic('RESIDENT_SUFFIX_T')
ACC_ROWS = pl.dynamic('RESIDENT_SUFFIX_ACC_ROWS')
INT_ROWS = pl.dynamic('RESIDENT_SUFFIX_INT_ROWS')
WO_A_WEIGHT_LAYOUT = pl.NZ
QUANT_WEIGHT_LAYOUT = pl.NZ
D = 4096
HC_MULT = 4
T_TILE = 4
STRIDE = 128
CORES = 72
WORDS = 6 * CORES * STRIDE

@pl.jit.incore
def incore_hcpost(heads: pl.Tensor[[T, 32768], pl.BF16], wo_a: pl.Tensor[[8, 4096, 1024], pl.BF16, WO_A_WEIGHT_LAYOUT], wo_b: pl.Tensor[[8192, 4096], pl.INT8, QUANT_WEIGHT_LAYOUT], wo_b_scale: pl.Tensor[[4096], pl.FP32], start: pl.Tensor[[16, 8, 8], pl.INT32], projected: pl.InOut[pl.Tensor[[T, 8192], pl.BF16]], quantized: pl.InOut[pl.Tensor[[T, 8192], pl.INT8]], token_scale: pl.InOut[pl.Tensor[[T, 1], pl.FP32]], attended: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], residual: pl.Tensor[[T, 16384], pl.BF16], post: pl.Tensor[[T, 4], pl.FP32], comb: pl.Tensor[[T, 16], pl.FP32], output: pl.InOut[pl.Tensor[[T, 16384], pl.BF16]], accum: pl.InOut[pl.Tensor[[ACC_ROWS, 8192], pl.FP32]], integer_accum: pl.InOut[pl.Tensor[[INT_ROWS, 4096], pl.INT32]], signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]]):
    pl.func_attr({'split_aiv': True})
    worker = pl.tile.get_block_idx() * 2 + pl.tile.get_subblock_idx()
    rows = pl.tensor.dim(heads, 0)
    t_dim = rows
    residual_flat = residual
    y_flat = output
    x = attended
    token_tiles = (t_dim + T_TILE - 1) // T_TILE
    for token_block in pl.range(worker, token_tiles, 48):
        t0 = token_block * T_TILE
        for t in pl.pipeline(t0, t0 + T_TILE, stage=2):
            if t < t_dim:
                x_block = pl.slice(x, [1, D], [t, 0])
                x_f32 = pl.cast(x_block, pl.FP32)
                res_0 = pl.cast(pl.slice(residual_flat, [1, D], [t, 0], valid_shape=[1, D], clamp=True), pl.FP32)
                res_1 = pl.cast(pl.slice(residual_flat, [1, D], [t, D + 0], valid_shape=[1, D], clamp=True), pl.FP32)
                res_2 = pl.cast(pl.slice(residual_flat, [1, D], [t, 2 * D + 0], valid_shape=[1, D], clamp=True), pl.FP32)
                res_3 = pl.cast(pl.slice(residual_flat, [1, D], [t, 3 * D + 0], valid_shape=[1, D], clamp=True), pl.FP32)
                for out_h in pl.unroll(HC_MULT):
                    post_scalar = pl.read(post, [t, out_h])
                    single_y = pl.mul(x_f32, post_scalar)
                    comb_scalar_0 = pl.read(comb, [t, out_h])
                    single_weighted_0 = pl.mul(res_0, comb_scalar_0)
                    single_y = pl.add(single_y, single_weighted_0)
                    comb_scalar_1 = pl.read(comb, [t, HC_MULT + out_h])
                    single_weighted_1 = pl.mul(res_1, comb_scalar_1)
                    single_y = pl.add(single_y, single_weighted_1)
                    comb_scalar_2 = pl.read(comb, [t, 2 * HC_MULT + out_h])
                    single_weighted_2 = pl.mul(res_2, comb_scalar_2)
                    single_y = pl.add(single_y, single_weighted_2)
                    comb_scalar_3 = pl.read(comb, [t, 3 * HC_MULT + out_h])
                    single_weighted_3 = pl.mul(res_3, comb_scalar_3)
                    single_y = pl.add(single_y, single_weighted_3)
                    single_result = pl.cast(single_y, pl.BF16, mode='rint')
                    y_flat[t:t + 1, out_h * D + 0:out_h * D + 0 + D] = pl.set_validshape(single_result, 1, D)
    pl.system.bar_all()
    return (projected, quantized, token_scale, attended, output, accum, integer_accum, signals)

@pl.jit
def hcpost(heads: pl.Tensor[[T, 32768], pl.BF16], wo_a: pl.Tensor[[8, 4096, 1024], pl.BF16, WO_A_WEIGHT_LAYOUT], wo_b: pl.Tensor[[8192, 4096], pl.INT8, QUANT_WEIGHT_LAYOUT], wo_b_scale: pl.Tensor[[4096], pl.FP32], start: pl.Tensor[[16, 8, 8], pl.INT32], projected: pl.InOut[pl.Tensor[[T, 8192], pl.BF16]], quantized: pl.InOut[pl.Tensor[[T, 8192], pl.INT8]], token_scale: pl.InOut[pl.Tensor[[T, 1], pl.FP32]], attended: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], residual: pl.Tensor[[T, 16384], pl.BF16], post: pl.Tensor[[T, 4], pl.FP32], comb: pl.Tensor[[T, 16], pl.FP32], output: pl.InOut[pl.Tensor[[T, 16384], pl.BF16]], accum: pl.InOut[pl.Tensor[[ACC_ROWS, 8192], pl.FP32]], integer_accum: pl.InOut[pl.Tensor[[INT_ROWS, 4096], pl.INT32]], signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]]):
    with pl.spmd(24, sync_start=True):
        projected, quantized, token_scale, attended, output, accum, integer_accum, signals = incore_hcpost(heads, wo_a, wo_b, wo_b_scale, start, projected, quantized, token_scale, attended, residual, post, comb, output, accum, integer_accum, signals)
    return (projected, quantized, token_scale, attended, output, accum, integer_accum, signals)
