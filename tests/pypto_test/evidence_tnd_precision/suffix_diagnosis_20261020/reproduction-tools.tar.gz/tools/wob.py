"""独立O-proj/HC-post常驻候选；只换worker/grid/同步，未获设备资格。"""
import pypto.language as pl
T = pl.dynamic('RESIDENT_SUFFIX_T')
ACC_ROWS = pl.dynamic('RESIDENT_SUFFIX_ACC_ROWS')
INT_ROWS = pl.dynamic('RESIDENT_SUFFIX_INT_ROWS')
WO_A_WEIGHT_LAYOUT = pl.NZ
QUANT_WEIGHT_LAYOUT = pl.NZ
D = 4096
HC_MULT = 4
T_TILE = 4
STRIDE = 128
CORES = 72
WORDS = 6 * CORES * STRIDE

@pl.jit.incore
def incore_wob(heads: pl.Tensor[[T, 32768], pl.BF16], wo_a: pl.Tensor[[8, 4096, 1024], pl.BF16, WO_A_WEIGHT_LAYOUT], wo_b: pl.Tensor[[8192, 4096], pl.INT8, QUANT_WEIGHT_LAYOUT], wo_b_scale: pl.Tensor[[4096], pl.FP32], start: pl.Tensor[[16, 8, 8], pl.INT32], projected: pl.InOut[pl.Tensor[[T, 8192], pl.BF16]], quantized: pl.InOut[pl.Tensor[[T, 8192], pl.INT8]], token_scale: pl.InOut[pl.Tensor[[T, 1], pl.FP32]], attended: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], residual: pl.Tensor[[T, 16384], pl.BF16], post: pl.Tensor[[T, 4], pl.FP32], comb: pl.Tensor[[T, 16], pl.FP32], output: pl.InOut[pl.Tensor[[T, 16384], pl.BF16]], accum: pl.InOut[pl.Tensor[[ACC_ROWS, 8192], pl.FP32]], integer_accum: pl.InOut[pl.Tensor[[INT_ROWS, 4096], pl.INT32]], signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]]):
    worker = pl.tile.get_block_idx()
    rows = pl.tensor.dim(heads, 0)
    row_tiles = (rows + 15) // 16
    if rows <= 16:
        for block in pl.range(worker, row_tiles * 32, 24):
            row = block // 32 * 16
            col = pl.max(block % 32, 0) * 128
            valid = pl.min(16, rows - row)
            b_acc = pl.create_tensor([16, 128], dtype=pl.INT32)
            for step in pl.range(16):
                k = step * 512
                b_input = pl.slice(quantized, [16, 512], [row, k], valid_shape=[valid, 512])
                b_weight = wo_b[k:k + 512, col:col + 128]
                b_acc = pl.matmul_acc(b_acc, b_input, b_weight, init_cond=step == 0)
            pl.assemble(integer_accum, b_acc, [row, col])
    else:
        for wide_block in pl.range(worker, (rows + 63) // 64 * 32, 24):
            wide_row = wide_block // 32 * 64
            wide_col = pl.max(wide_block % 32, 0) * 128
            wide_valid = pl.min(64, rows - wide_row)
            wide_first_input = pl.slice(quantized, [64, 512], [wide_row, 0], valid_shape=[wide_valid, 512])
            wide_first_weight = wo_b[0:512, wide_col:wide_col + 128]
            wide_b_acc = pl.matmul(wide_first_input, wide_first_weight, out_dtype=pl.INT32)
            for wide_step in pl.range(1, 16):
                wide_k = wide_step * 512
                wide_b_input = pl.slice(quantized, [64, 512], [wide_row, wide_k], valid_shape=[wide_valid, 512])
                wide_b_weight = wo_b[wide_k:wide_k + 512, wide_col:wide_col + 128]
                wide_b_acc = pl.matmul_acc(wide_b_acc, wide_b_input, wide_b_weight, init_cond=False)
            pl.assemble(integer_accum, wide_b_acc, [wide_row, wide_col])
    return (projected, quantized, token_scale, attended, output, accum, integer_accum, signals)

@pl.jit
def wob(heads: pl.Tensor[[T, 32768], pl.BF16], wo_a: pl.Tensor[[8, 4096, 1024], pl.BF16, WO_A_WEIGHT_LAYOUT], wo_b: pl.Tensor[[8192, 4096], pl.INT8, QUANT_WEIGHT_LAYOUT], wo_b_scale: pl.Tensor[[4096], pl.FP32], start: pl.Tensor[[16, 8, 8], pl.INT32], projected: pl.InOut[pl.Tensor[[T, 8192], pl.BF16]], quantized: pl.InOut[pl.Tensor[[T, 8192], pl.INT8]], token_scale: pl.InOut[pl.Tensor[[T, 1], pl.FP32]], attended: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], residual: pl.Tensor[[T, 16384], pl.BF16], post: pl.Tensor[[T, 4], pl.FP32], comb: pl.Tensor[[T, 16], pl.FP32], output: pl.InOut[pl.Tensor[[T, 16384], pl.BF16]], accum: pl.InOut[pl.Tensor[[ACC_ROWS, 8192], pl.FP32]], integer_accum: pl.InOut[pl.Tensor[[INT_ROWS, 4096], pl.INT32]], signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]]):
    with pl.spmd(24, sync_start=True):
        projected, quantized, token_scale, attended, output, accum, integer_accum, signals = incore_wob(heads, wo_a, wo_b, wo_b_scale, start, projected, quantized, token_scale, attended, residual, post, comb, output, accum, integer_accum, signals)
    return (projected, quantized, token_scale, attended, output, accum, integer_accum, signals)
