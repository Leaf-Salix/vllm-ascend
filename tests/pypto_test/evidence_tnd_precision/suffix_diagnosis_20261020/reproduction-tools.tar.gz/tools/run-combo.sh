#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
case_name=${1:?}; tokens=${2:?}; variant=${3:?}; batch=4; history=8191
sdk=/data/pyptouser/yejia/csa-spmd-sdk-20261020
[[ "$case_name" =~ ^[a-z0-9-]+$ && "$batch" =~ ^[0-9]+$ && "$history" =~ ^[0-9]+$ ]]
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/vector-mte2-20261019-codex/full-csa-live-staging-v2/env.sh"
export SPMD_EXPERIMENT="$base/precision-overlap-20261020"
exp="$base/spmd-baseline-20261020"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE" PYTHONNOUSERSITE=1 HCCL_DETERMINISTIC=true
export PYPTO_PROG_BUILD_DIR="$sdk/frozen-device-build" PYPTO_CACHE_DIR="$sdk/frozen-device-cache"
export PTOAS_ROOT="$sdk/toolchain-wheel"
export PATH="$sdk/sources/pypto/.venv/bin:$PTOAS_ROOT/bin:$PATH"
export CCACHE_DIR="$sdk/sources/pypto/.ccache" CMAKE_BUILD_PARALLEL_LEVEL=2
out="$sdk/results/$case_name"
test ! -e "$out"
mkdir -p "$exp/results"
export ASCEND_CACHE_PATH="$out-ascend-cache" ASCEND_PROCESS_LOG_PATH="$out-ascend-log" VLLM_CACHE_ROOT="$out-vllm-cache"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out-opp-env")
trap 'printf "launcher_failed line=%s rc=%s\n" "$LINENO" "$?" >&2' ERR
ccache -s > "$out-ccache.log"
printf 'TASK_RUN_START %s\n' "$(date -Iseconds)"
trap 'printf "TASK_RUN_END %s\n" "$(date -Iseconds)"' EXIT
timeout 750s python "$sdk/suffix-diagnosis-20261020/combo_probe.py" --out "$out" --tokens "$tokens" --variant "$variant" > "$out-run.log" 2>&1
