"""仅收集本轮清单内已结束自有任务，不触碰共享服务或其它任务。"""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

sdk = Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
root = sdk / 'suffix-diagnosis-20261020'
runs = json.loads((root / 'RUNS.json').read_text())['runs']
receipts = sdk / 'results/suffix-diagnosis-receipts-v1'
receipts.mkdir(exist_ok=False)
files = []
report = {}
for case, item in runs.items():
    task = item['task']
    status = subprocess.check_output(['task-submit', '--status', task], text=True).strip()
    assert status == 'completed (exit=0)', (task, status)
    log = subprocess.check_output(['task-submit', '--log', task], text=True)
    task_log = receipts / (case + '.task.log')
    task_log.write_text(log)
    files.append(task_log)
    case_dir = sdk / 'results' / ('suffix-' + case)
    raw = case_dir / 'result.json'
    assert raw.is_file(), raw
    files.append(raw)
    for suffix in ('-run.log', '-ccache.log'):
        path = Path(str(case_dir) + suffix)
        if path.is_file():
            files.append(path)
    data = json.loads(raw.read_text())
    assert data['pass'] and data['complete']
    report[case] = {'task': task, 'status': status,
                    'result_sha256': hashlib.sha256(raw.read_bytes()).hexdigest(),
                    'probe_seconds': data['finished_unix'] - data['started_unix'],
                    'result': str(raw)}
(receipts / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
files.append(receipts / 'summary.json')
archive = sdk / 'results/suffix-diagnosis-run-receipts-v1.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as handle:
    for path in files:
        handle.add(path, arcname=str(path.relative_to(sdk / 'results')))
print(json.dumps(report, indent=2))
