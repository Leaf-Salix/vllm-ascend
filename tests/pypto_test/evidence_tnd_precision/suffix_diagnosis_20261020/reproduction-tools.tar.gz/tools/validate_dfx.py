"""按真实L1 schema复核配对DFX原始窗口，不把run marker误作起止对。"""
from pathlib import Path
import json
import math
import tarfile

root = Path(__file__).resolve().parent
results = {}
for variant in ('phase1', 'phase5'):
    case = f'suffix-ab-dfx-{variant}-t126-v1'
    recorded = json.loads((root / (case + '.json')).read_text())['DFX']['records']
    assert len(recorded) == 9
    with tarfile.open(root / (case + '-evidence.tar.gz')) as archive:
        windows = []
        for record in recorded:
            i = record['window']
            relative = f'{case}/dfx/' + (f'window_{i}/' if i else '') + 'chip_swimlane_records.json'
            raw = json.load(archive.extractfile(relative))
            metadata, tasks = raw['metadata'], raw['aicore_tasks']
            assert raw['chip_swimlane_level'] == 1
            assert metadata['core_types'] == ['aic'] * 24 + ['aiv'] * 48
            assert metadata['num_cores'] == 72 and metadata['clock_freq_hz'] == 50_000_000
            assert metadata['dropped_run_boundaries'] == 0
            roots = 2 if record['side'] == 'frozen' else 1
            assert [entry[0] for entry in metadata['run_boundaries']] == list(range(roots))
            assert all(len(task) == 6 and all(isinstance(v, int) for v in task) and task[3] <= task[4] for task in tasks)
            assert {task[0] for task in tasks} == set(range(72))
            assert len(tasks) == record['total']['records']
            def span(rows):
                return (max(t[4] for t in rows) - min(t[3] for t in rows)) / 50
            assert math.isclose(span(tasks), record['total']['span_us'], abs_tol=1e-8)
            for role, first, last in (('AIC', 0, 24), ('AIV', 24, 72)):
                subset = [t for t in tasks if first <= t[0] < last]
                assert len(subset) == record['roles'][role]['records']
                assert math.isclose(span(subset), record['roles'][role]['span_us'], abs_tol=1e-8)
                if record['side'] != 'frozen':
                    assert len(subset) == last - first
            windows.append({'window': i, 'side': record['side'], 'records': len(tasks), 'roots': roots, 'pass': True})
        results[case] = windows
(root / 'AB_DFX_INTEGRITY.json').write_text(json.dumps(results, indent=2) + '\n')
print('PASS: 18 paired L1 windows, schema/roles/root rounds/counts/spans')
