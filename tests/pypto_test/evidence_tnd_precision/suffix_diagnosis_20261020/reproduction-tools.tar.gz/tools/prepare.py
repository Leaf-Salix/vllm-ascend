"""从已测后缀派生阶段诊断；数学节点不改，默认路由不改。"""
import ast
import copy
import hashlib
import json
from pathlib import Path

here=Path(__file__).resolve().parent
base=here.parent/'resident-suffix-candidate.py'
tree=ast.parse(base.read_text());functions={f.name:f for f in tree.body if isinstance(f,ast.FunctionDef)}
cube=functions['cube'];vec=functions['vector'];root=functions['resident_suffix']
header=[copy.deepcopy(n) for n in tree.body if not isinstance(n,ast.FunctionDef)]
stages={
 'woa':(cube,[0,2,3,4]),
 'bf16':(vec,[0,1,4,5,7]),
 'quant':(vec,[0,1,4,10,11]),
 'wob':(cube,[0,2,3,7]),
 'dequant':(vec,[0,1,4,5,14]),
 'hcpost':(vec,[0,1,4,17,18,19,20,21,22,23]),
}
proof={'parent_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'scope':'isolated stages on already populated buffers; not additive critical-path or a new precision variant','stages':{}}
for name,(parent,indices) in stages.items():
 inc=copy.deepcopy(parent);inc.name='incore_'+name
 inc.body=[copy.deepcopy(parent.body[i]) for i in indices]+[copy.deepcopy(parent.body[-1])]
 # Stage code keeps every original arithmetic/load/store node verbatim.
 assert all(ast.dump(inc.body[k])==ast.dump(parent.body[i]) for k,i in enumerate(indices))
 ent=copy.deepcopy(root);ent.name=name
 with_scope=ent.body[0]
 call=with_scope.body[0].value
 call.func=ast.Name(id=inc.name,ctx=ast.Load())
 module=ast.Module(body=[*copy.deepcopy(header),inc,ent],type_ignores=[])
 code=ast.unparse(ast.fix_missing_locations(module))+'\n'
 file=here/(name+'.py');file.write_text(code)
 proof['stages'][name]={'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'source_function':parent.name,'source_nodes':indices,'root_tensors':16}
(here/'STAGE_SOURCE_PROOF.json').write_text(json.dumps(proof,indent=2)+'\n')
