"""独立O-proj/HC-post常驻候选；只换worker/grid/同步，未获设备资格。"""
import pypto.language as pl
T = pl.dynamic('RESIDENT_SUFFIX_T')
ACC_ROWS = pl.dynamic('RESIDENT_SUFFIX_ACC_ROWS')
INT_ROWS = pl.dynamic('RESIDENT_SUFFIX_INT_ROWS')
WO_A_WEIGHT_LAYOUT = pl.NZ
QUANT_WEIGHT_LAYOUT = pl.NZ
D = 4096
HC_MULT = 4
T_TILE = 4
STRIDE = 128
CORES = 72
WORDS = 6 * CORES * STRIDE

@pl.jit.incore
def incore_quant(heads: pl.Tensor[[T, 32768], pl.BF16], wo_a: pl.Tensor[[8, 4096, 1024], pl.BF16, WO_A_WEIGHT_LAYOUT], wo_b: pl.Tensor[[8192, 4096], pl.INT8, QUANT_WEIGHT_LAYOUT], wo_b_scale: pl.Tensor[[4096], pl.FP32], start: pl.Tensor[[16, 8, 8], pl.INT32], projected: pl.InOut[pl.Tensor[[T, 8192], pl.BF16]], quantized: pl.InOut[pl.Tensor[[T, 8192], pl.INT8]], token_scale: pl.InOut[pl.Tensor[[T, 1], pl.FP32]], attended: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], residual: pl.Tensor[[T, 16384], pl.BF16], post: pl.Tensor[[T, 4], pl.FP32], comb: pl.Tensor[[T, 16], pl.FP32], output: pl.InOut[pl.Tensor[[T, 16384], pl.BF16]], accum: pl.InOut[pl.Tensor[[ACC_ROWS, 8192], pl.FP32]], integer_accum: pl.InOut[pl.Tensor[[INT_ROWS, 4096], pl.INT32]], signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]]):
    pl.func_attr({'split_aiv': True})
    worker = pl.tile.get_block_idx() * 2 + pl.tile.get_subblock_idx()
    rows = pl.tensor.dim(heads, 0)
    quant_rows = (rows + 7) // 8
    for block in pl.range(worker, quant_rows, 48):
        row = block * 8
        valid = pl.min(8, rows - row)
        first_quant = pl.load(projected, [row, 0], [8, 1024], valid_shape=[valid, 1024])
        first_abs = pl.abs(pl.cast(first_quant, pl.FP32))
        amax = pl.row_max(first_abs, pl.create_tile([8, 1024], dtype=pl.FP32))
        for group in pl.range(1, 8):
            q_bf16 = pl.load(projected, [row, group * 1024], [8, 1024], valid_shape=[valid, 1024])
            q_fp32 = pl.cast(q_bf16, pl.FP32)
            amax = pl.maximum(amax, pl.row_max(pl.abs(q_fp32), pl.create_tile([8, 1024], dtype=pl.FP32)))
        dequant = pl.mul(amax, 1.0 / 127.0)
        denominator = pl.add(amax, 0.0)
        for lane in pl.range(valid):
            magnitude = pl.read(denominator, [lane, 0])
            if magnitude == 0.0:
                pl.write(denominator, [lane, 0], 1.0)
        multiplier = pl.div(pl.add(pl.mul(amax, 0.0), 127.0), denominator)
        pl.store(pl.set_validshape(dequant, valid, 1), [row, 0], token_scale)
        for group in pl.range(8):
            col = group * 1024
            quant_bf16 = pl.load(projected, [row, col], [8, 1024], valid_shape=[valid, 1024])
            quant_scaled = pl.row_expand_mul(pl.cast(quant_bf16, pl.FP32), multiplier)
            integer = pl.cast(quant_scaled, pl.INT32, mode='rint')
            half = pl.cast(integer, pl.FP16, mode='round')
            result = pl.cast(half, pl.INT8, mode='trunc')
            pl.store(pl.set_validshape(result, valid, 1024), [row, col], quantized)
    return (projected, quantized, token_scale, attended, output, accum, integer_accum, signals)

@pl.jit
def quant(heads: pl.Tensor[[T, 32768], pl.BF16], wo_a: pl.Tensor[[8, 4096, 1024], pl.BF16, WO_A_WEIGHT_LAYOUT], wo_b: pl.Tensor[[8192, 4096], pl.INT8, QUANT_WEIGHT_LAYOUT], wo_b_scale: pl.Tensor[[4096], pl.FP32], start: pl.Tensor[[16, 8, 8], pl.INT32], projected: pl.InOut[pl.Tensor[[T, 8192], pl.BF16]], quantized: pl.InOut[pl.Tensor[[T, 8192], pl.INT8]], token_scale: pl.InOut[pl.Tensor[[T, 1], pl.FP32]], attended: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], residual: pl.Tensor[[T, 16384], pl.BF16], post: pl.Tensor[[T, 4], pl.FP32], comb: pl.Tensor[[T, 16], pl.FP32], output: pl.InOut[pl.Tensor[[T, 16384], pl.BF16]], accum: pl.InOut[pl.Tensor[[ACC_ROWS, 8192], pl.FP32]], integer_accum: pl.InOut[pl.Tensor[[INT_ROWS, 4096], pl.INT32]], signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]]):
    with pl.spmd(24, sync_start=True):
        projected, quantized, token_scale, attended, output, accum, integer_accum, signals = incore_quant(heads, wo_a, wo_b, wo_b_scale, start, projected, quantized, token_scale, attended, residual, post, comb, output, accum, integer_accum, signals)
    return (projected, quantized, token_scale, attended, output, accum, integer_accum, signals)
