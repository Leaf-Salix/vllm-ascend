"""就绪信号微基准：只测wait循环/缓存维护，不代表生产者真实阻塞。"""
import ast,copy,hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent;tree=ast.parse((r.parent/'resident-suffix-candidate.py').read_text());functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
header=[copy.deepcopy(n) for n in tree.body if not isinstance(n,ast.FunctionDef)]
proof={'parent_sha256':'a31a78f89e1ed71c007de2b692434cc0a0f1bc35626b22188418b3e715edd022','scope':'all-ready AIV wait+cache-maintenance microbench; no mathematical output or producer delay','stages':{}}
for count,phase,first in ((0,1,0),(24,1,0),(48,5,24)):
 name='wait'+str(count);inc=copy.deepcopy(functions['vector']);inc.name='incore_'+name
 inc.body=[copy.deepcopy(inc.body[0])]+ast.parse(f'''pl.system.cacheinvalid(signals, [1], [0])
pl.system.fence()
generation = pl.read(signals, [0])
signals = wait_group(signals, {phase}, {first}, {first+count}, generation)
''').body+[copy.deepcopy(inc.body[-1])]
 root=copy.deepcopy(functions['resident_suffix']);root.name=name;root.body[0].body[0].value.func=ast.Name(id=inc.name,ctx=ast.Load())
 code=ast.unparse(ast.fix_missing_locations(ast.Module(body=[*copy.deepcopy(header),copy.deepcopy(functions['wait_group']),inc,root],type_ignores=[])))+'\n'
 file=r/(name+'.py');file.write_text(code);proof['stages'][name]={'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'wait_count':count,'phase':phase,'first':first,'root_tensors':16}
(r/'WAIT_SOURCE_PROOF.json').write_text(json.dumps(proof,indent=2)+'\n')
s=(r/'stage_probe.py').read_text().replace("('woa','bf16','quant','wob','dequant','hcpost')","('wait0','wait24','wait48')").replace('STAGE_SOURCE_PROOF.json','WAIT_SOURCE_PROOF.json')
a=s.index("   targets={'woa':");b=s.index('   expected_targets=',a);s=s[:a]+"   targets={name:{} for name in phase_ops}\n"+s[b:]
s=s.replace("'isolated phase diagnosis; real weights, synthetic inputs; not additive critical path'","'ready-wait microbenchmark; not producer stall, math performance or precision qualification'")
s=s.replace("isolated stages incl executor; overlap and cache differ; do not sum/subtract into full synchronization time","all-ready wait microbench incl executor and fixed cache-maintenance; wait0 uses same protocol with zero iterations; not producer stall")
(r/'wait_probe.py').write_text(s)
s=(r/'run-stages.sh').read_text().replace('stage_probe.py','wait_probe.py');(r/'run-waits.sh').write_text(s)
s=(r/'check_stages.py').read_text().replace("('woa','bf16','quant','wob','dequant','hcpost')","('wait0','wait24','wait48')").replace('results/suffix-stage-cpu-v1','results/suffix-waits-cpu-v1');(r/'check_waits.py').write_text(s)
s=(r/'check-stages.sh').read_text().replace('check_stages.py','check_waits.py').replace('suffix-stage-cpu-v1.log','suffix-waits-cpu-v1.log');(r/'check-waits.sh').write_text(s)
