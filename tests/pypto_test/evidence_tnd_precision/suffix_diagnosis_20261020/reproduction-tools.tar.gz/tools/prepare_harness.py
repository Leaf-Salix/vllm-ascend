"""派生阶段性能/PMU探针：保留已测父探针的五边界和A/B/A门禁。"""
from pathlib import Path
import ast
root=Path(__file__).resolve().parent
s=(root.parent/'precision-perf-20261020/suffix_probe.py').read_text()
s=s.replace("args=parser.parse_args()","parser.add_argument('--mode',choices=('stages','pmu'),required=True)\nargs=parser.parse_args()")
s=s.replace("'O-proj+HC-post only; candidate versus frozen PTO math, not Native whole CSA'","'isolated phase diagnosis; real weights, synthetic inputs; not additive critical path'")
s=s.replace('  pypto.torch.init()',"  pypto.torch.init()")
a=s.index('   samples={s:[] for s in bundles}');b=s.index('  assert readonly==',a)
s=s[:a]+'''   phase_ops={}
   for name in ('woa','bf16','quant','wob','dequant','hcpost'):
    spec=importlib.util.spec_from_file_location('stage_'+name,sdk/'suffix-diagnosis-20261020'/f'{name}.py')
    m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
    expected=json.loads((sdk/'suffix-diagnosis-20261020/STAGE_SOURCE_PROOF.json').read_text())['stages'][name]['sha256']
    assert hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()==expected
    phase_ops[name]=pypto.torch.register(getattr(m,name),'suffix_stage_test::'+name)
   def launch_phase(name):
    b=bundles['resident']
    return phase_ops[name](heads,wo_a,wo_b,channel,start,b['projected'],b['quantized'],b['token_scale'],b['attended'],residual_flat,post,comb,out_flat,accum,integer,signals)
   targets={'woa':{'accum':accum},'bf16':{'projected':bundles['resident']['projected']},'quant':{k:bundles['resident'][k] for k in ('quantized','token_scale')},'wob':{'integer':integer},'dequant':{'attended':bundles['resident']['attended']},'hcpost':{'output':bundles['resident']['output']}}
   expected_targets={name:{key:v[:tokens].cpu().clone() for key,v in values.items()} for name,values in targets.items()}
   phase_checks={}
   def phase_check(name):
    values={key:bit_equal(value[:tokens].cpu(),expected_targets[name][key]) for key,value in targets[name].items()}
    phase_checks[name]=values
    report['phase_checks']=phase_checks;save()
    assert all(values.values()),('first isolated-phase difference',name,values)
    compare('isolated_'+name)
   for name in phase_ops:
    for v in targets[name].values():v[:tokens].fill_(float('nan') if v.is_floating_point() else -91)
    launch_phase(name);torch.npu.synchronize();phase_check(name)
    graph=torch.npu.NPUGraph()
    with torch.npu.graph(graph,stream=stream):launch_phase(name)
    graphs[name]=graph
    for v in targets[name].values():v[:tokens].fill_(float('nan') if v.is_floating_point() else -91)
    graph.replay();torch.npu.synchronize();phase_check(name)
   if args.mode=='stages':
    samples={s:[] for s in graphs}
    for window in range(12):
     order=list(graphs);order=order[window%len(order):]+order[:window%len(order)]
     if window%2:order.reverse()
     for side in order:
      before=generation()
      start_event,end_event=torch.npu.Event(enable_timing=True),torch.npu.Event(enable_timing=True)
      start_event.record()
      for _ in range(100):graphs[side].replay()
      end_event.record();end_event.synchronize()
      samples[side].append(start_event.elapsed_time(end_event)*1000/100)
      assert generation()==before+(100 if side=='resident' else 0)
      if side in phase_ops:phase_check(side)
      else:compare('window_'+str(window)+'_'+side)
    report['phase_timing_scope']='isolated stages incl executor; overlap and cache differ; do not sum/subtract into full synchronization time'
    report['timings']={'unit':'us/isolated phase FULL graph replay','windows':12,'replays':100,'outliers_removed':False,'samples':samples,'summary':{s:{'min':min(v),'median':statistics.median(v),'mean':statistics.mean(v),'max':max(v)} for s,v in samples.items()}}
   else:
    for side in ('resident',*phase_ops):
     with torch_npu.profiler.profile(activities=[torch_npu.profiler.ProfilerActivity.CPU,torch_npu.profiler.ProfilerActivity.NPU],record_shapes=True,on_trace_ready=torch_npu.profiler.tensorboard_trace_handler(str(args.out/(side+'-pmu'))),experimental_config=torch_npu.profiler._ExperimentalConfig(profiler_level=torch_npu.profiler.ProfilerLevel.Level1,aic_metrics=torch_npu.profiler.AiCMetrics.PipeUtilization,data_simplification=False)):
      for _ in range(3):graphs[side].replay()
      torch.npu.synchronize()
     if side in phase_ops:phase_check(side)
     else:compare('post_pmu')
    report['PMU']={'scope':'separate instrumentation task; per-phase executor; utilization is not additive elapsed time','replays':3,'phases':list(phase_ops)}
'''+s[b:]
# Preserve the measured timing dictionary; do not assign the old two-arm report over it.
line="  report['timings']={'unit':'us/O-proj+HC-post FULL graph replay','windows':12,'replays':100,'outliers_removed':False,'samples':samples,'summary':{s:{'min':min(v),'median':statistics.median(v),'mean':statistics.mean(v),'max':max(v)} for s,v in samples.items()}}\n"
assert line in s;s=s.replace(line,'')
ast.parse(s);(root/'stage_probe.py').write_text(s)
s=(root.parent/'precision-perf-20261020/run-suffix.sh').read_text()
s=s.replace('case_name=${1:?}; tokens=${2:?}; batch=4; history=8191','case_name=${1:?}; tokens=${2:?}; mode=${3:?}; batch=4; history=8191')
s=s.replace('$sdk/precision-perf-20261020/suffix_probe.py','$sdk/suffix-diagnosis-20261020/stage_probe.py').replace('--tokens "$tokens"','--tokens "$tokens" --mode "$mode"')
(root/'run-stages.sh').write_text(s)
