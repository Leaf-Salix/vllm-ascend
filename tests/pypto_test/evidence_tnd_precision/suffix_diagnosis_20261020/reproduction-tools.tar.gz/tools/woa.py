"""独立O-proj/HC-post常驻候选；只换worker/grid/同步，未获设备资格。"""
import pypto.language as pl
T = pl.dynamic('RESIDENT_SUFFIX_T')
ACC_ROWS = pl.dynamic('RESIDENT_SUFFIX_ACC_ROWS')
INT_ROWS = pl.dynamic('RESIDENT_SUFFIX_INT_ROWS')
WO_A_WEIGHT_LAYOUT = pl.NZ
QUANT_WEIGHT_LAYOUT = pl.NZ
D = 4096
HC_MULT = 4
T_TILE = 4
STRIDE = 128
CORES = 72
WORDS = 6 * CORES * STRIDE

@pl.jit.incore
def incore_woa(heads: pl.Tensor[[T, 32768], pl.BF16], wo_a: pl.Tensor[[8, 4096, 1024], pl.BF16, WO_A_WEIGHT_LAYOUT], wo_b: pl.Tensor[[8192, 4096], pl.INT8, QUANT_WEIGHT_LAYOUT], wo_b_scale: pl.Tensor[[4096], pl.FP32], start: pl.Tensor[[16, 8, 8], pl.INT32], projected: pl.InOut[pl.Tensor[[T, 8192], pl.BF16]], quantized: pl.InOut[pl.Tensor[[T, 8192], pl.INT8]], token_scale: pl.InOut[pl.Tensor[[T, 1], pl.FP32]], attended: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], residual: pl.Tensor[[T, 16384], pl.BF16], post: pl.Tensor[[T, 4], pl.FP32], comb: pl.Tensor[[T, 16], pl.FP32], output: pl.InOut[pl.Tensor[[T, 16384], pl.BF16]], accum: pl.InOut[pl.Tensor[[ACC_ROWS, 8192], pl.FP32]], integer_accum: pl.InOut[pl.Tensor[[INT_ROWS, 4096], pl.INT32]], signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]]):
    worker = pl.tile.get_block_idx()
    rows = pl.tensor.dim(heads, 0)
    row_tiles = (rows + 15) // 16
    if rows >= 192:
        for logical in pl.range(worker, 64, 24):
            seed_group = logical // 8
            seed_block = logical % 8
            seed_col = seed_block * 128
            for seed_panel in pl.range((row_tiles + 7) // 8):
                seed_first_rb = seed_panel * 8
                seed_first_start = pl.max(pl.read(start, [seed_first_rb, seed_group, seed_block]), 0)
                seed_same_start = 1
                if seed_first_rb + 1 < row_tiles:
                    if pl.max(pl.read(start, [seed_first_rb + 1, seed_group, seed_block]), 0) != seed_first_start:
                        seed_same_start = 0
                if seed_first_rb + 2 < row_tiles:
                    if pl.max(pl.read(start, [seed_first_rb + 2, seed_group, seed_block]), 0) != seed_first_start:
                        seed_same_start = 0
                if seed_first_rb + 3 < row_tiles:
                    if pl.max(pl.read(start, [seed_first_rb + 3, seed_group, seed_block]), 0) != seed_first_start:
                        seed_same_start = 0
                if seed_first_rb + 4 < row_tiles:
                    if pl.max(pl.read(start, [seed_first_rb + 4, seed_group, seed_block]), 0) != seed_first_start:
                        seed_same_start = 0
                if seed_first_rb + 5 < row_tiles:
                    if pl.max(pl.read(start, [seed_first_rb + 5, seed_group, seed_block]), 0) != seed_first_start:
                        seed_same_start = 0
                if seed_first_rb + 6 < row_tiles:
                    if pl.max(pl.read(start, [seed_first_rb + 6, seed_group, seed_block]), 0) != seed_first_start:
                        seed_same_start = 0
                if seed_first_rb + 7 < row_tiles:
                    if pl.max(pl.read(start, [seed_first_rb + 7, seed_group, seed_block]), 0) != seed_first_start:
                        seed_same_start = 0
                if rows <= 16:
                    seed_same_start = 0
                if seed_first_start > 240:
                    seed_same_start = 0
                if seed_same_start == 1:
                    seed_fast_row = seed_first_rb * 16
                    seed_fast_valid = pl.min(128, rows - seed_fast_row)
                    seed_fast_seed_k = seed_first_start * 16
                    seed_fast_seed_x = pl.slice(heads, [128, 256], [seed_fast_row, seed_group * 4096 + seed_fast_seed_k], valid_shape=[seed_fast_valid, 256])
                    seed_fast_seed_w = wo_a[seed_group:seed_group + 1, seed_fast_seed_k:seed_fast_seed_k + 256, seed_col:seed_col + 128]
                    seed_fast_acc = pl.matmul(seed_fast_seed_x, seed_fast_seed_w, out_dtype=pl.FP32)
                    for seed_fast_packet in pl.pipeline(1, 16, stage=2):
                        seed_fast_packet_kb = (seed_first_start + seed_fast_packet * 16) % 256
                        if seed_fast_packet_kb <= 240:
                            seed_fast_packet_k = seed_fast_packet_kb * 16
                            seed_fast_packet_x = pl.slice(heads, [128, 256], [seed_fast_row, seed_group * 4096 + seed_fast_packet_k], valid_shape=[seed_fast_valid, 256])
                            seed_fast_packet_w = wo_a[seed_group:seed_group + 1, seed_fast_packet_k:seed_fast_packet_k + 256, seed_col:seed_col + 128]
                            seed_fast_acc = pl.matmul_acc(seed_fast_acc, seed_fast_packet_x, seed_fast_packet_w, init_cond=False)
                        else:
                            for seed_fast_inner in pl.range(16):
                                seed_fast_wrap_k = (seed_fast_packet_kb + seed_fast_inner) % 256 * 16
                                seed_fast_wrap_x = pl.slice(heads, [128, 16], [seed_fast_row, seed_group * 4096 + seed_fast_wrap_k], valid_shape=[seed_fast_valid, 16])
                                seed_fast_wrap_w = wo_a[seed_group:seed_group + 1, seed_fast_wrap_k:seed_fast_wrap_k + 16, seed_col:seed_col + 128]
                                seed_fast_acc = pl.matmul_acc(seed_fast_acc, seed_fast_wrap_x, seed_fast_wrap_w, init_cond=False)
                    pl.assemble(accum, seed_fast_acc, [seed_fast_row, seed_group * 1024 + seed_col])
                else:
                    for seed_local_rb in pl.range(8):
                        seed_narrow_rb = seed_first_rb + seed_local_rb
                        if seed_narrow_rb < row_tiles:
                            seed_narrow_row = seed_narrow_rb * 16
                            seed_narrow_valid = pl.min(16, rows - seed_narrow_row)
                            seed_narrow_first_block = pl.max(pl.read(start, [seed_narrow_rb, seed_group, seed_block]), 0)
                            seed_narrow_acc = pl.create_tensor([1, 16, 128], dtype=pl.FP32)
                            for seed_narrow_packet in pl.range(16):
                                seed_narrow_packet_kb = (seed_narrow_first_block + seed_narrow_packet * 16) % 256
                                if seed_narrow_packet_kb <= 240:
                                    seed_narrow_packet_k = seed_narrow_packet_kb * 16
                                    seed_narrow_packet_x = pl.slice(heads, [16, 256], [seed_narrow_row, seed_group * 4096 + seed_narrow_packet_k], valid_shape=[seed_narrow_valid, 256])
                                    seed_narrow_packet_w = wo_a[seed_group:seed_group + 1, seed_narrow_packet_k:seed_narrow_packet_k + 256, seed_col:seed_col + 128]
                                    seed_narrow_acc = pl.matmul_acc(seed_narrow_acc, seed_narrow_packet_x, seed_narrow_packet_w, init_cond=seed_narrow_packet == 0)
                                else:
                                    for seed_narrow_inner in pl.range(16):
                                        seed_narrow_wrap_k = (seed_narrow_packet_kb + seed_narrow_inner) % 256 * 16
                                        seed_narrow_wrap_x = pl.slice(heads, [16, 16], [seed_narrow_row, seed_group * 4096 + seed_narrow_wrap_k], valid_shape=[seed_narrow_valid, 16])
                                        seed_narrow_wrap_w = wo_a[seed_group:seed_group + 1, seed_narrow_wrap_k:seed_narrow_wrap_k + 16, seed_col:seed_col + 128]
                                        seed_narrow_acc = pl.matmul_acc(seed_narrow_acc, seed_narrow_wrap_x, seed_narrow_wrap_w, init_cond=seed_narrow_packet * 16 + seed_narrow_inner == 0)
                            pl.assemble(accum, seed_narrow_acc, [seed_narrow_row, seed_group * 1024 + seed_col])
    else:
        for logical in pl.range(worker, 64, 24):
            v4_group = logical // 8
            v4_block = logical % 8
            v4_col = v4_block * 128
            for v4_panel in pl.range((row_tiles + 7) // 8):
                v4_first_rb = v4_panel * 8
                v4_first_start = pl.max(pl.read(start, [v4_first_rb, v4_group, v4_block]), 0)
                v4_same_start = 1
                if v4_first_rb + 1 < row_tiles:
                    if pl.max(pl.read(start, [v4_first_rb + 1, v4_group, v4_block]), 0) != v4_first_start:
                        v4_same_start = 0
                if v4_first_rb + 2 < row_tiles:
                    if pl.max(pl.read(start, [v4_first_rb + 2, v4_group, v4_block]), 0) != v4_first_start:
                        v4_same_start = 0
                if v4_first_rb + 3 < row_tiles:
                    if pl.max(pl.read(start, [v4_first_rb + 3, v4_group, v4_block]), 0) != v4_first_start:
                        v4_same_start = 0
                if v4_first_rb + 4 < row_tiles:
                    if pl.max(pl.read(start, [v4_first_rb + 4, v4_group, v4_block]), 0) != v4_first_start:
                        v4_same_start = 0
                if v4_first_rb + 5 < row_tiles:
                    if pl.max(pl.read(start, [v4_first_rb + 5, v4_group, v4_block]), 0) != v4_first_start:
                        v4_same_start = 0
                if v4_first_rb + 6 < row_tiles:
                    if pl.max(pl.read(start, [v4_first_rb + 6, v4_group, v4_block]), 0) != v4_first_start:
                        v4_same_start = 0
                if v4_first_rb + 7 < row_tiles:
                    if pl.max(pl.read(start, [v4_first_rb + 7, v4_group, v4_block]), 0) != v4_first_start:
                        v4_same_start = 0
                if rows <= 16:
                    v4_same_start = 0
                if v4_same_start == 1:
                    v4_wide_row = v4_first_rb * 16
                    v4_wide_valid = pl.min(128, rows - v4_wide_row)
                    v4_wide_first_block = v4_first_start
                    v4_wide_seed_k = v4_wide_first_block % 256 * 16
                    v4_wide_seed_x = pl.slice(heads, [128, 16], [v4_wide_row, v4_group * 4096 + v4_wide_seed_k], valid_shape=[v4_wide_valid, 16])
                    v4_wide_seed_w = wo_a[v4_group:v4_group + 1, v4_wide_seed_k:v4_wide_seed_k + 16, v4_col:v4_col + 128]
                    v4_wide_acc = pl.matmul(v4_wide_seed_x, v4_wide_seed_w, out_dtype=pl.FP32)
                    for v4_wide_packet in pl.range(15):
                        v4_wide_packet_kb = (v4_wide_first_block + 1 + v4_wide_packet * 16) % 256
                        if v4_wide_packet_kb <= 240:
                            v4_wide_packet_k = v4_wide_packet_kb * 16
                            v4_wide_packet_x = pl.slice(heads, [128, 256], [v4_wide_row, v4_group * 4096 + v4_wide_packet_k], valid_shape=[v4_wide_valid, 256])
                            v4_wide_packet_w = wo_a[v4_group:v4_group + 1, v4_wide_packet_k:v4_wide_packet_k + 256, v4_col:v4_col + 128]
                            v4_wide_acc = pl.matmul_acc(v4_wide_acc, v4_wide_packet_x, v4_wide_packet_w, init_cond=False)
                        else:
                            for v4_wide_inner in pl.range(16):
                                v4_wide_wrap_k = (v4_wide_packet_kb + v4_wide_inner) % 256 * 16
                                v4_wide_wrap_x = pl.slice(heads, [128, 16], [v4_wide_row, v4_group * 4096 + v4_wide_wrap_k], valid_shape=[v4_wide_valid, 16])
                                v4_wide_wrap_w = wo_a[v4_group:v4_group + 1, v4_wide_wrap_k:v4_wide_wrap_k + 16, v4_col:v4_col + 128]
                                v4_wide_acc = pl.matmul_acc(v4_wide_acc, v4_wide_wrap_x, v4_wide_wrap_w, init_cond=False)
                    for v4_wide_tail in pl.range(241, 256):
                        v4_wide_tail_k = (v4_wide_first_block + v4_wide_tail) % 256 * 16
                        v4_wide_tail_x = pl.slice(heads, [128, 16], [v4_wide_row, v4_group * 4096 + v4_wide_tail_k], valid_shape=[v4_wide_valid, 16])
                        v4_wide_tail_w = wo_a[v4_group:v4_group + 1, v4_wide_tail_k:v4_wide_tail_k + 16, v4_col:v4_col + 128]
                        v4_wide_acc = pl.matmul_acc(v4_wide_acc, v4_wide_tail_x, v4_wide_tail_w, init_cond=False)
                    pl.assemble(accum, v4_wide_acc, [v4_wide_row, v4_group * 1024 + v4_col])
                else:
                    for v4_local_rb in pl.range(8):
                        v4_narrow_rb = v4_first_rb + v4_local_rb
                        if v4_narrow_rb < row_tiles:
                            v4_narrow_row = v4_narrow_rb * 16
                            v4_narrow_valid = pl.min(16, rows - v4_narrow_row)
                            v4_narrow_first_block = pl.max(pl.read(start, [v4_narrow_rb, v4_group, v4_block]), 0)
                            v4_narrow_acc = pl.create_tensor([1, 16, 128], dtype=pl.FP32)
                            for v4_narrow_packet in pl.range(16):
                                v4_narrow_packet_kb = (v4_narrow_first_block + v4_narrow_packet * 16) % 256
                                if v4_narrow_packet_kb <= 240:
                                    v4_narrow_packet_k = v4_narrow_packet_kb * 16
                                    v4_narrow_packet_x = pl.slice(heads, [16, 256], [v4_narrow_row, v4_group * 4096 + v4_narrow_packet_k], valid_shape=[v4_narrow_valid, 256])
                                    v4_narrow_packet_w = wo_a[v4_group:v4_group + 1, v4_narrow_packet_k:v4_narrow_packet_k + 256, v4_col:v4_col + 128]
                                    v4_narrow_acc = pl.matmul_acc(v4_narrow_acc, v4_narrow_packet_x, v4_narrow_packet_w, init_cond=v4_narrow_packet == 0)
                                else:
                                    for v4_narrow_inner in pl.range(16):
                                        v4_narrow_wrap_k = (v4_narrow_packet_kb + v4_narrow_inner) % 256 * 16
                                        v4_narrow_wrap_x = pl.slice(heads, [16, 16], [v4_narrow_row, v4_group * 4096 + v4_narrow_wrap_k], valid_shape=[v4_narrow_valid, 16])
                                        v4_narrow_wrap_w = wo_a[v4_group:v4_group + 1, v4_narrow_wrap_k:v4_narrow_wrap_k + 16, v4_col:v4_col + 128]
                                        v4_narrow_acc = pl.matmul_acc(v4_narrow_acc, v4_narrow_wrap_x, v4_narrow_wrap_w, init_cond=v4_narrow_packet * 16 + v4_narrow_inner == 0)
                            pl.assemble(accum, v4_narrow_acc, [v4_narrow_row, v4_group * 1024 + v4_col])
    return (projected, quantized, token_scale, attended, output, accum, integer_accum, signals)

@pl.jit
def woa(heads: pl.Tensor[[T, 32768], pl.BF16], wo_a: pl.Tensor[[8, 4096, 1024], pl.BF16, WO_A_WEIGHT_LAYOUT], wo_b: pl.Tensor[[8192, 4096], pl.INT8, QUANT_WEIGHT_LAYOUT], wo_b_scale: pl.Tensor[[4096], pl.FP32], start: pl.Tensor[[16, 8, 8], pl.INT32], projected: pl.InOut[pl.Tensor[[T, 8192], pl.BF16]], quantized: pl.InOut[pl.Tensor[[T, 8192], pl.INT8]], token_scale: pl.InOut[pl.Tensor[[T, 1], pl.FP32]], attended: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], residual: pl.Tensor[[T, 16384], pl.BF16], post: pl.Tensor[[T, 4], pl.FP32], comb: pl.Tensor[[T, 16], pl.FP32], output: pl.InOut[pl.Tensor[[T, 16384], pl.BF16]], accum: pl.InOut[pl.Tensor[[ACC_ROWS, 8192], pl.FP32]], integer_accum: pl.InOut[pl.Tensor[[INT_ROWS, 4096], pl.INT32]], signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]]):
    with pl.spmd(24, sync_start=True):
        projected, quantized, token_scale, attended, output, accum, integer_accum, signals = incore_woa(heads, wo_a, wo_b, wo_b_scale, start, projected, quantized, token_scale, attended, residual, post, comb, output, accum, integer_accum, signals)
    return (projected, quantized, token_scale, attended, output, accum, integer_accum, signals)
