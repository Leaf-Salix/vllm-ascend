"""从原始结果生成中文报告；未结束项不冒认通过。"""
from pathlib import Path
import json,statistics
r=Path(__file__).resolve().parent
load=lambda name:json.loads((r/name).read_text())
stage=load('suffix-stages-t126-v1.json');dfx=load('DFX_SUMMARY.json');pmu=load('PMU_SUMMARY.json');ready=load('suffix-waits-t126-v1.json')
rows=[]
for name in ('woa','bf16','quant','wob','dequant','hcpost'):
 s=stage['timings']['summary'][name]['median'];d=dfx['medians'][name]['span_us'];m=pmu['phases'][name+'-pmu']['medians']
 metric=f"AIC MAC {100*m['aic_mac_ratio']:.1f}%，MTE2 {100*m['aic_mte2_ratio']:.1f}%" if name in ('woa','wob') else f"AIV Vector {100*m['aiv_vec_ratio']:.1f}%，Scalar {100*m['aiv_scalar_ratio']:.1f}%"
 rows.append(f'| {name} | {s:.2f} | {d:.2f} | {metric} |')
abs_rows=[]
for variant,title in [('phase5','HC-post所需owner'),('m128','WO-B M128'),('phase1','WO-A→BF16所需owner')]:
 for t in (126,240):
  p=r/f'suffix-ab-{variant}-t{t}-v1.json'
  if not p.exists():continue
  j=json.loads(p.read_text());assert j['pass'] and j['complete'];s=j['timings']['summary'];a=s['resident']['median'];b=s['new']['median'];f=s['frozen']['median'];delta=(b/a-1)*100
  checks=[b<a for a,b in zip(j['timings']['samples']['resident'],j['timings']['samples']['new'])]
  abs_rows.append(f'| {title} | T{t} | {f:.2f} | {a:.2f} | {b:.2f} | {delta:+.2f}% | {sum(checks)}/12窗改善；五边界逐位一致 |')
extra_rows=[]
for name,title in [('combo-t126','组合对首版resident'),('incremental-t126','M128增量，父版phase1'),('incremental-t240','M128增量，父版phase1')]:
 p=r/f'suffix-ab-{name}-v1.json'
 if not p.exists():continue
 j=json.loads(p.read_text());assert j['pass'] and j['complete'];a=j['timings']['summary'];pair=sum(x>y for x,y in zip(j['timings']['samples']['resident'],j['timings']['samples']['new']))
 extra_rows.append(f"| {title} | T{j['tokens']} | {a['frozen']['median']:.2f} | {a['resident']['median']:.2f} | {a['new']['median']:.2f} | {(a['new']['median']/a['resident']['median']-1)*100:+.2f}% | {pair}/12 |")
w=ready['timings']['summary'];base=w['wait0']['median'];waitrows='\n'.join(f"| {name} | {w[name]['median']:.2f} | {w[name]['median']-base:+.2f} |" for name in ('wait0','wait24','wait48'))
report='''# TND精度SPMD后缀：计算、搬运与同步诊断（2026-10-20）

## 本轮结论

- 前段只等真实WO-A owner，T126/T240分别降低常驻后缀延迟36.76%/16.33%，每档12/12窗改善，五边界逐位不变。
- WO-B M128虽单独有效，在前段owner版上却回退2.50%；不保留组合，HC-post尾部精简亦不通用保留。
- 最佳保留方向仍慢于冻结后缀23.13%/15.06%；没有切换正式路径，没有新增整模型资格。

## 版本与范围

分支`dev/pypto-dsv4-csa-nalinaly-tnd-20261008-codex`，本轮起点93f21dc7f；
正式精度运行源48c58ce7c、旧后缀a31a78f8均保留。
所有候选是独立实验文件，未切换正式路径。本轮没有SDK、runtime或手写C++算术修改。
参考nalinaly固定[beaefa6f](https://github.com/nalinaly/vllm-ascend/tree/beaefa6f6788a9448d49293238f6818c246f24f5/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_spmd)的SPMD源码，
归档保留所读原样文件及SDK_SOURCES身份收据，不冒称未拉取的后续提交。

所有数据来自227真实第4层权重、合成heads/residual/gates，FULL graph，确定性level1及HCCL确定性。
金值是冻结PTO O-proj/HC-post，并非本轮直接调用Native后缀或整模型。
采用新隔离SDK：PyPTO2dfa7f1、Simpler57e4992、PTO-ISA327cd58、实际PTOAS wheel0.66、
Python3.12.14、Torch2.10.0+cpu、Torch-NPU2.10.0.post2、vLLM0.25.1、CANN9.2beta2。
精确二进制与完整源SHA保留在原始结果；wheel的Git源未证明。

## 对照nalinaly得到的设计约束

| 方面 | nalinaly参考SPMD | 当前精度后缀 | 本轮处理 |
| --- | --- | --- | --- |
| WO-A | 递增K256、流水/驻留按形状选策略 | Native校准cyclic K起点和舍入边界；部分wide stage2已退为range | 不改Native K轨迹；先测搬运与实际流水 |
| 量化 | 每1024列独立amax和scale | 全8192列共同amax，BF16落点保留 | 不搬入分组scale，以免更改数值链 |
| WO-B | 按组INT32 partial与scale左折叠，复用activation/weight | 全8192按16×K512累加INT32，M64/N128 | 仅测M128行块，K和缩放顺序不改 |
| 跨阶段依赖 | 依据真实owner和行范围等待，可提前消费就绪分组 | 多处等待全部24 AIC/48 AIV | 分别只缩phase5及phase1，未同时修改 |
| HC-post | BF16边界后逐项残差组合 | 同样保留BF16和四项左折叠 | 仅改依赖，数学不动 |

Native精度约束限制了可直接复制的流水方式，但不代表当前慢是不可避免的精度代价。

## 测量分成四种独立任务

1. 无插桩：12个交替/轮换窗口，每窗100次FULL回放。中位数为窗口均值中位数，不是单次p50。
2. L1 DFX：3个窗口，每arm一次回放，dep-gen关闭。取最早incore开始至最晚结束；含内部等待、搬运和start skew。
3. CANN Level1/PipeUtilization：每arm3回放，既不开DFX也不采正式延迟。比例可重叠，不是可加总的耗时。
4. 信号全部就绪微基准：同代际已由前序完整MIX发布，仅比较0/24/48个wait；不测producer真实阻塞。

每任务进程750秒、调度780秒硬上限；精度先于计时，首差停止。缓存和计时负载不同，不跨任务直接相减推出同步耗时。

## T126阶段测量

| 阶段 | 无插桩独立回放 μs | L1核内跨度 μs | 独立PMU中位计数 |
| --- | ---: | ---: | --- |
'''+ '\n'.join(rows)+'''

孤立阶段的事件耗时包含各自运行时入口，缓存/重叠与完整MIX不同，不能把六行相加/相减成为成本分解。
完整旧resident在这次L1任务的跨度633.78 μs，其中AIC598.20、AIV633.76；两角色重叠，不能相加。
完整旧resident的PMU为AIC MAC6.1%、MTE250.3%，AIV Vector1.6%、Scalar92.4%。
计数涵盖executor及空闲角色控制，不可把Scalar全称为signal等待，也不能把MTE2 busy当纯搬运stall。
WO-A编译产物同时报告部分stage2只能容纳单缓冲，属于可核验的流水串行化证据，未认定唯一根因。

六阶段数学逐AST取自旧候选，eager/FULL毒化写回与每窗复核均通过（每阶段14次）；
整数用正确值逐位反码毒化，浮点NaN。L1每阶段5次检查、PMU每阶段3次检查。
24个L1原始窗口核类型、记录数量、时间schema、root round数量与dropped标志均核对。
run_boundaries是每个root round开始的标记，不是起止对：frozen两条，其余单root一条。

## 已就绪wait的固定成本

| 微基准 | 中位回放 μs | 相对wait0 μs |
| --- | ---: | ---: |
'''+waitrows+'''

每个arm含同样读取代际与获取维护，48核参与；每项14次检查，输出和代际保持不变。
因此“仅执行48次已就绪wait”多约8.34 μs，不能解释完整后缀数百微秒回退。
这不是等待未就绪生产者的阻塞时间，也不是新增数学精度资格。

实际ISA的TWAIT每次未满足检查都会single-cache-line dcci并volatile读取，没有退避；
每64次未满足循环执行PIPE_ALL。源固定327cd58，header SHA256
`fcb4e369aa756e8aa3b39eaf86f896b79a15a848ce2ce8c3c81e786f783a5c07`。
多个消费者忙等同一生产者可能干扰访问，属于有源码机制支持、仍需设备实验区分的解释；
本轮没有signal cache/DDR流量计数，不能认定它是唯一根因。

## 单因素三臂结果

单位μs；每行同一任务、同一卡、同输入，三臂位置轮换平衡。负号为候选相对原resident延迟下降。
各任务父基线不同，因此只能按本行配对效果评价，不能用跨任务绝对数直接给候选排名。

| 单因素 | 形状 | 冻结PTO | 原resident | 新候选 | 延迟变化 | 验证 |
| --- | --- | ---: | ---: | ---: | ---: | --- |
'''+ '\n'.join(abs_rows)+'''

每项成功都完成五边界eager/FULL A/B/A、只读SHA、全部输入/工作区/信号guard，双generation=1204。
phase5仅缩HC-post所需8个dequant owner；T240回退，不能作为通用保留。
m128仅改WO-B M64→M128，全16×K512及INT32不变，最坏部分和绝对值≤2^27，不溢出；新integer容量T+127。
phase1仅缩WO-A→BF16所需8个AIC owner；T1..256依赖覆盖已穷举，所有producer仍发布且payload维护保留。
不把几个因素组合后假定收益可相加。

## 组合与直接增量对拍

| 测试 | 形状 | 冻结PTO μs | 父版 μs | 新候选 μs | 延迟变化 | 改善窗 |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
''' + '\n'.join(extra_rows) + '''

组合仅包含phase1与M128，phase5不纳入。每行160项逐位指标、A/B/A、双generation1204与guard通过。
初次组合三臂只能说明相对首版resident的净效果；随后将父版换成phase1，才是只增加M128的同任务增量单因素。
不能拿跨任务绝对数给单项/组合排序，也没有用三臂估计四格factorial交互项。

## 配对L1的限制

phase5另一次同任务L1中，原/新完整跨度646.04/626.14 μs，AIC607.02/596.48、AIV646.04/626.14。
此为单回放插桩诊断，不替代12×100正式收益。角色跨度变化不能唯一分配给删去的wait指令；
新的代码布局、真实依赖与运行负载共同影响结果。该诊断也不撤销T240实测回退。

phase1另一次配对L1原/新跨度694.20/415.82 μs，AIC658.90/377.76、AIV694.20/415.82。
前段依赖修改有实测效果，但仍没有原位逐phase时间戳，不能把包络差唯一分摊为wait或搬运等待。
L1每arm单回放会改变缓存/调度条件，不能用它代替无插桩12×100排名。

## 推广状态

仍以已验收冻结精度版为基准；局部候选胜过旧resident不等于完整CSA已经优化。
本轮没有新增8K/B40或128K/B24真实整模型192-token结果，没有授予新候选Native整模型资格。
仅保留phase1八owner独立候选作为后续实验起点；正式仍用冻结后缀。
新增M128相对phase1在T126明确回退2.50%，0/12窗改善，因此组合不保留，不再扩大组合T240。
M128对a31的单因素收益不等于对phase1也有收益；phase5亦不作为通用候选。
phase1的T126/T240相对各自冻结后缀仍慢23.13%/15.06%，因此本轮不做完整CSA集成和整模型复测。
在完整CSA实测取得收益后再进入8K、128K token门禁。

## 证据

[证据索引](evidence_tnd_precision/suffix_diagnosis_20261020/README.md)保存原始结果、失败/检查历史、源码SHA和复现步骤。
候选与正式代码分开，不覆盖基准。
'''
(r/'REPORT_DRAFT.md').write_text(report)
