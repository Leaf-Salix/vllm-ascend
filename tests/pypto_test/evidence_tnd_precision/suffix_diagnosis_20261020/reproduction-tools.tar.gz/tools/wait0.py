"""独立O-proj/HC-post常驻候选；只换worker/grid/同步，未获设备资格。"""
import pypto.language as pl
T = pl.dynamic('RESIDENT_SUFFIX_T')
ACC_ROWS = pl.dynamic('RESIDENT_SUFFIX_ACC_ROWS')
INT_ROWS = pl.dynamic('RESIDENT_SUFFIX_INT_ROWS')
WO_A_WEIGHT_LAYOUT = pl.NZ
QUANT_WEIGHT_LAYOUT = pl.NZ
D = 4096
HC_MULT = 4
T_TILE = 4
STRIDE = 128
CORES = 72
WORDS = 6 * CORES * STRIDE

@pl.jit.inline(auto_scope=False)
def wait_group(signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]], phase: pl.Scalar[pl.INDEX], first: pl.Scalar[pl.INDEX], last: pl.Scalar[pl.INDEX], generation: pl.Scalar[pl.INT32]):
    for owner in pl.range(first, last):
        pl.system.signal_wait(signals, [(phase * CORES + owner) * STRIDE], generation)
    pl.system.fence()
    pl.system.cacheinvalid()
    pl.system.fence()
    return signals

@pl.jit.incore
def incore_wait0(heads: pl.Tensor[[T, 32768], pl.BF16], wo_a: pl.Tensor[[8, 4096, 1024], pl.BF16, WO_A_WEIGHT_LAYOUT], wo_b: pl.Tensor[[8192, 4096], pl.INT8, QUANT_WEIGHT_LAYOUT], wo_b_scale: pl.Tensor[[4096], pl.FP32], start: pl.Tensor[[16, 8, 8], pl.INT32], projected: pl.InOut[pl.Tensor[[T, 8192], pl.BF16]], quantized: pl.InOut[pl.Tensor[[T, 8192], pl.INT8]], token_scale: pl.InOut[pl.Tensor[[T, 1], pl.FP32]], attended: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], residual: pl.Tensor[[T, 16384], pl.BF16], post: pl.Tensor[[T, 4], pl.FP32], comb: pl.Tensor[[T, 16], pl.FP32], output: pl.InOut[pl.Tensor[[T, 16384], pl.BF16]], accum: pl.InOut[pl.Tensor[[ACC_ROWS, 8192], pl.FP32]], integer_accum: pl.InOut[pl.Tensor[[INT_ROWS, 4096], pl.INT32]], signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]]):
    pl.func_attr({'split_aiv': True})
    pl.system.cacheinvalid(signals, [1], [0])
    pl.system.fence()
    generation = pl.read(signals, [0])
    signals = wait_group(signals, 1, 0, 0, generation)
    return (projected, quantized, token_scale, attended, output, accum, integer_accum, signals)

@pl.jit
def wait0(heads: pl.Tensor[[T, 32768], pl.BF16], wo_a: pl.Tensor[[8, 4096, 1024], pl.BF16, WO_A_WEIGHT_LAYOUT], wo_b: pl.Tensor[[8192, 4096], pl.INT8, QUANT_WEIGHT_LAYOUT], wo_b_scale: pl.Tensor[[4096], pl.FP32], start: pl.Tensor[[16, 8, 8], pl.INT32], projected: pl.InOut[pl.Tensor[[T, 8192], pl.BF16]], quantized: pl.InOut[pl.Tensor[[T, 8192], pl.INT8]], token_scale: pl.InOut[pl.Tensor[[T, 1], pl.FP32]], attended: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], residual: pl.Tensor[[T, 16384], pl.BF16], post: pl.Tensor[[T, 4], pl.FP32], comb: pl.Tensor[[T, 16], pl.FP32], output: pl.InOut[pl.Tensor[[T, 16384], pl.BF16]], accum: pl.InOut[pl.Tensor[[ACC_ROWS, 8192], pl.FP32]], integer_accum: pl.InOut[pl.Tensor[[INT_ROWS, 4096], pl.INT32]], signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]]):
    with pl.spmd(24, sync_start=True):
        projected, quantized, token_scale, attended, output, accum, integer_accum, signals = incore_wait0(heads, wo_a, wo_b, wo_b_scale, start, projected, quantized, token_scale, attended, residual, post, comb, output, accum, integer_accum, signals)
    return (projected, quantized, token_scale, attended, output, accum, integer_accum, signals)
