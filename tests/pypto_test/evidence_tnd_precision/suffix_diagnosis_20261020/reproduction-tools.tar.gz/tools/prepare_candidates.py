"""测量后生成两个互不组合的独立候选，保留a31父候选。"""
import ast,copy,hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent;p=r.parent/'resident-suffix-candidate.py';source=p.read_text();parent_hash=hashlib.sha256(p.read_bytes()).hexdigest()
assert parent_hash=='a31a78f89e1ed71c007de2b692434cc0a0f1bc35626b22188418b3e715edd022'
old='    signals = wait_group(signals, 5, 24, 72, generation)'
new='''    if worker < (rows + 3) // 4:
        for dep in pl.range(8):
            owner = (8 * (worker // 4) + dep) % 48
            pl.system.signal_wait(signals, [(5 * CORES + 24 + owner) * STRIDE], generation)
        pl.system.fence()
        pl.system.cacheinvalid()
        pl.system.fence()'''
assert source.count(old)==1
variants={'phase5':(source.replace(old,new),'only HC-post required dequant owners; math/producer/cache protocol unchanged')}
# Only change wide WO-B M64 to M128; all sixteen K512 int32 steps stay in order.
tree=ast.parse(source);cube=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='cube');branch=cube.body[7]
assert isinstance(branch,ast.If)
class RowTile(ast.NodeTransformer):
 def visit_Constant(self,node):
  return ast.copy_location(ast.Constant({63:127,64:128}[node.value]),node) if node.value in (63,64) else node
m128=RowTile().visit(copy.deepcopy(branch.orelse[0]));original=ast.unparse(branch.orelse[0]);replacement=ast.unparse(ast.fix_missing_locations(m128))
start=branch.orelse[0].lineno-1;end=branch.orelse[0].end_lineno
lines=source.splitlines();rewritten=lines[:start]+['        '+x for x in replacement.splitlines()]+lines[end:]
# indent from ast.unparse starts at column0, original loop starts column8.
variants['m128']=('\n'.join(rewritten)+'\n','only wide WO-B M64 to M128; same K512 int32 order, scaling/quantization unchanged')
for name,(code,description) in variants.items():
 ast.parse(code);file=r/('candidate-'+name+'.py');file.write_text(code)
 proof={'parent_sha256':parent_hash,'candidate_sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'change':description,'scope':'independent experiment, not installed or device qualified','formal_baseline':'48c58ce7c467dfce63d5cb5c41afd225488d6012'}
 (r/('candidate-'+name+'.json')).write_text(json.dumps(proof,indent=2)+'\n')
