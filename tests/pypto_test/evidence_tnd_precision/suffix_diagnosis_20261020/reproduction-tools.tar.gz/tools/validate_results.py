"""离线复核原始三臂结果的源码身份、逐位门禁与窗口统计。"""
import hashlib
import json
import statistics
from pathlib import Path

root = Path(__file__).resolve().parent
sources = {hashlib.sha256(p.read_bytes()).hexdigest(): p.name for p in root.glob('*probe*.py')}
validated = {}
for path in sorted(root.glob('suffix-ab-*-v1.json')):
    data = json.loads(path.read_text())
    assert all(data[k] is True for k in ('pass', 'complete', 'actual_acl_graph', 'guards', 'readonly'))
    assert data['harness_sha256'] in sources, path
    proof = data['candidate_proof']
    candidate = next(p for p in root.glob('candidate-*.py')
                     if hashlib.sha256(p.read_bytes()).hexdigest() == proof['candidate_sha256'])
    assert proof['parent_sha256'] == 'a31a78f89e1ed71c007de2b692434cc0a0f1bc35626b22188418b3e715edd022'
    count = 0
    for comparisons in data['comparisons'].values():
        assert len(comparisons) == 10
        for metric in comparisons.values():
            assert metric['bit_equal'] and metric['different_elements'] == 0 and metric['max_abs'] == 0
            count += 1
    assert data['finished_unix'] - data['started_unix'] < 750
    row = {'harness': sources[data['harness_sha256']], 'candidate': candidate.name,
           'comparison_parent': data.get('comparison_parent', 'original a31 resident'),
           'bit_metrics': count, 'probe_seconds': data['finished_unix'] - data['started_unix']}
    if 'timings' in data:
        timing = data['timings']
        assert timing['windows'] == 12 and timing['replays'] == 100 and not timing['outliers_removed']
        assert data['final_generation'] == {'parent': 1204, 'new': 1204} and count == 160
        if 'comparison_parent_proof' in data:
            parent = data['comparison_parent_proof']
            assert parent['candidate_sha256'] == proof['components']['phase1']['candidate_sha256']
            assert parent['parent_sha256'] == proof['parent_sha256']
        for side, samples in timing['samples'].items():
            assert len(samples) == 12 and all(v > 0 for v in samples)
            expected = {'min': min(samples), 'max': max(samples), 'median': statistics.median(samples),
                        'mean': statistics.mean(samples)}
            assert expected == timing['summary'][side], (path, side)
        row['improved_paired_windows'] = sum(a > b for a, b in zip(timing['samples']['resident'], timing['samples']['new']))
        row['delay_change_percent'] = 100 * (timing['summary']['new']['median'] / timing['summary']['resident']['median'] - 1)
        row['vs_frozen_delay_percent'] = 100 * (timing['summary']['new']['median'] / timing['summary']['frozen']['median'] - 1)
    else:
        assert data['final_generation'] == {'parent': 7, 'new': 7} and count == 70
        assert len(data['DFX']['records']) == 9
    validated[path.name] = row
(root / 'RESULT_VALIDATION.json').write_text(json.dumps(validated, indent=2) + '\n')
print(json.dumps(validated, indent=2))
