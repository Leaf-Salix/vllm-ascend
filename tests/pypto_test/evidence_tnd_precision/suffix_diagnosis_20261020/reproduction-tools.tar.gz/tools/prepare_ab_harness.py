"""生成三臂同输入FULL对拍：冻结PTO、原resident、一个单因素候选。"""
import ast
from pathlib import Path
r=Path(__file__).resolve().parent
s=(r.parent/'precision-perf-20261020/suffix_probe.py').read_text()
s=s.replace('args=parser.parse_args()',"parser.add_argument('--variant',choices=('phase5','phase3','wobpipe'),required=True)\nargs=parser.parse_args()")
s=s.replace("'scope':'O-proj+HC-post only; candidate versus frozen PTO math, not Native whole CSA'","'scope':'one-factor resident suffix versus parent and frozen PTO; not Native whole CSA'")
s=s.replace("for side in ('frozen','resident'):","for side in ('frozen','resident','new'):")
a=s.index('  readonly={n:sha(v)');s=s[:a]+'''  new_accum=buffer((tokens+127,8192),torch.float32)
  new_integer=buffer((tokens+63,4096),torch.int32)
  new_signal_owner=torch.full((module.WORDS+256,),-91,device='npu',dtype=torch.int32)
  new_signals=new_signal_owner[128:-128];new_signals.zero_()
  new_flat=bundles['new']['output'].view(tokens,16384)
  candidate_file=sdk/'suffix-diagnosis-20261020'/('candidate-'+args.variant+'.py')
  candidate_proof=json.loads((sdk/'suffix-diagnosis-20261020'/('candidate-'+args.variant+'.json')).read_text())
  assert candidate_proof['parent_sha256']==proof['candidate_sha256']
  assert hashlib.sha256(candidate_file.read_bytes()).hexdigest()==candidate_proof['candidate_sha256']
  report['candidate_proof']=candidate_proof
  spec=importlib.util.spec_from_file_location('single_factor_candidate',candidate_file)
  new_module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=new_module;spec.loader.exec_module(new_module)
'''+s[a:]
s=s.replace("  def launch(side):", "  new_op=pypto.torch.register(new_module.resident_suffix,'resident_suffix_test::new_candidate')\n  def launch(side):")
s=s.replace("   else:\n    candidate(","   elif side=='resident':\n    candidate(")
line="    candidate(heads,wo_a,wo_b,channel,start,b['projected'],b['quantized'],b['token_scale'],b['attended'],residual_flat,post,comb,out_flat,accum,integer,signals)\n"
assert line in s
s=s.replace(line,line+"   else:\n    new_op(heads,wo_a,wo_b,channel,start,b['projected'],b['quantized'],b['token_scale'],b['attended'],residual_flat,post,comb,new_flat,new_accum,new_integer,new_signals)\n")
s=s.replace("   assert torch.all(signal_owner[:128].cpu()==-91) and torch.all(signal_owner[-128:].cpu()==-91)","   for owner in (signal_owner,new_signal_owner):assert torch.all(owner[:128].cpu()==-91) and torch.all(owner[-128:].cpu()==-91)")
s=s.replace('  def generation():\n   words=signals.cpu()',"  def generation(side='resident'):\n   words=(new_signals if side=='new' else signals).cpu()")
s=s.replace("  def poison(side):\n   for v in bundles[side].values():v.fill_(float('nan') if v.is_floating_point() else -91)","  def poison(side):\n   for key,v in bundles[side].items():\n    if v.is_floating_point():v.fill_(float('nan'))\n    elif side=='frozen':v.copy_(torch.bitwise_not(bundles['resident'][key]))\n    else:v.copy_(torch.bitwise_not(bundles['frozen'][key]))")
a=s.index('  def compare(label):');b=s.index('  for side in bundles:launch(side)',a)
s=s[:a]+'''  def compare(label):
   result={}
   for side in ('resident','new'):
    for key,a in bundles[side].items():
     x=a.cpu();y=bundles['frozen'][key].cpu()
     if x.is_floating_point():assert torch.isfinite(x).all() and torch.isfinite(y).all()
     equal=bit_equal(x,y);diff=x.float()-y.float()
     result[side+'.'+key]={'bit_equal':equal,'different_elements':int((x!=y).sum()),'max_abs':float(diff.abs().max()),'first':(x!=y).nonzero()[:4].tolist()}
   report.setdefault('comparisons',{})[label]=result;save();guards()
   assert generation()==generation('new'),'generation drift'
   if not all(v['bit_equal'] for v in result.values()):
    torch.save({side:{k:v.cpu() for k,v in b.items()} for side,b in bundles.items()},args.out/'first-difference.pt')
    raise RuntimeError('first suffix difference: '+label)
'''+s[b:]
s=s.replace("    order=list(bundles) if window%2==0 else list(reversed(bundles))", "    order=list(bundles);shift=window%len(order);order=order[shift:]+order[:shift]\n    if window%2:order.reverse()")
s=s.replace("    before=generation()\n    for side in order:","    before=generation();before_new=generation('new')\n    for side in order:")
s=s.replace("    assert generation()==before+100\n", "    assert generation()==before+100 and generation('new')==before_new+100\n")
s=s.replace("report['final_generation']=generation()", "report['final_generation']={'parent':generation(),'new':generation('new')}")
ast.parse(s);(r/'ab_probe.py').write_text(s)
s=(r.parent/'precision-perf-20261020/run-suffix.sh').read_text().replace('case_name=${1:?}; tokens=${2:?}; batch=4; history=8191','case_name=${1:?}; tokens=${2:?}; variant=${3:?}; batch=4; history=8191').replace('$sdk/precision-perf-20261020/suffix_probe.py','$sdk/suffix-diagnosis-20261020/ab_probe.py').replace('--tokens "$tokens"','--tokens "$tokens" --variant "$variant"')
(r/'run-ab.sh').write_text(s)
