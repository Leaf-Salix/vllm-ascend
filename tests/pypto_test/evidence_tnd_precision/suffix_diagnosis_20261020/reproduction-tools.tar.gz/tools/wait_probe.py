"""常驻后缀对冻结PTO数学的FULL graph逐位与交替性能；非整层/整模型结论。"""
import argparse
import hashlib
import importlib
import importlib.util
import json
import os
from pathlib import Path
import runpy
import statistics
import sys
import time
import traceback

parser=argparse.ArgumentParser()
parser.add_argument('--tokens',type=int,required=True)
parser.add_argument('--out',type=Path,required=True)
parser.add_argument('--mode',choices=('stages','pmu'),required=True)
args=parser.parse_args()
assert 1<=args.tokens<=256
sdk=Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
sys.argv=[str(sdk/'sdk-preflight.py')]
runpy.run_path(sys.argv[0],run_name='__main__')
import torch
import torch_npu
import pypto.torch
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
from dsv4_csa_native_case import native_session
from dsv4_csa_single_layer import make_layer

args.out.mkdir(exist_ok=False)
report={'pass':False,'complete':False,'tokens':args.tokens,'scope':'ready-wait microbenchmark; not producer stall, math performance or precision qualification','source_baseline':'48c58ce7c467dfce63d5cb5c41afd225488d6012','layout_scope':'token-row suffix only; no request metadata, not a full TND admission test','started_unix':time.time()}
def save():
 (args.out/'result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
def sha(t):
 c=t.detach().cpu().contiguous();return hashlib.sha256(c.view(torch.uint8).numpy().tobytes()).hexdigest()
def bit_equal(a,b):
 return a.shape==b.shape and a.dtype==b.dtype and torch.equal(a.contiguous().view(torch.uint8),b.contiguous().view(torch.uint8))
current_platform.pre_register_and_update()
torch.npu.set_device(0)
torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
from vllm_ascend.utils import enable_custom_op
assert enable_custom_op()
import vllm_ascend.ops.pypto as namespace
source_root=Path(os.environ['SOURCE_ROOT'])
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.o_proj import o_proj_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.hc_post import hc_post_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.oproj_order_data import OPROJ_TILE_STARTS,OPROJ_TOKEN_MODES
spec=importlib.util.spec_from_file_location('private_resident_suffix_device',sdk/'resident-suffix-candidate.py')
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
proof=json.loads((sdk/'RESIDENT_SUFFIX_SOURCE_PROOF.json').read_text())
assert hashlib.sha256((sdk/'resident-suffix-candidate.py').read_bytes()).hexdigest()==proof['candidate_sha256']
assert all(hashlib.sha256((source_root/n).read_bytes()).hexdigest()==h for n,h in proof['sources'].items())
assert proof['candidate_sha256']=='a31a78f89e1ed71c007de2b692434cc0a0f1bc35626b22188418b3e715edd022'
actual_modules={}
for name,relative in (
 ('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.o_proj','vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision/o_proj.py'),
 ('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.hc_post','vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision/hc_post.py')):
 imported=importlib.import_module(name)
 actual=Path(imported.__file__).resolve()
 assert actual==(source_root/relative).resolve(),(name,str(actual))
 assert hashlib.sha256(actual.read_bytes()).hexdigest()==proof['sources'][relative]
 actual_modules[name]={'path':str(actual),'sha256':proof['sources'][relative]}
report['baseline_actual_modules']=actual_modules
report['harness_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
report['PTOAS_ROOT']=os.environ['PTOAS_ROOT']
assert Path(report['PTOAS_ROOT']).resolve()==sdk/'toolchain-wheel'
report['sdk_preflight']=json.loads((sdk/'results/pypto-import-preflight.json').read_text())
report['source_proof']=proof
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
tokens=args.tokens
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,
 tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},
 max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,
 enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},
 compilation_config={'cudagraph_mode':'FULL_DECODE_ONLY','cudagraph_capture_sizes':[tokens],'cache_dir':str(args.out/'vllm-cache')},
 additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},
 'enable_cpu_binding':False,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False}).create_engine_config()
save()
try:
 with native_session(config,0),torch.inference_mode():
  layer,details=make_layer(config,checkpoint,torch.device('npu:0'),4)
  report['weight_details']=details
  wo_a=layer.self_attn.wo_a.weight.detach();wo_b=layer.self_attn.wo_b.weight.detach()
  channel=layer.self_attn.wo_b.weight_scale.detach().reshape(-1).float().contiguous()
  assert wo_a.shape==(8,4096,1024) and wo_a.dtype==torch.bfloat16 and torch_npu.get_npu_format(wo_a)==29
  assert wo_b.shape==(8192,4096) and wo_b.dtype==torch.int8 and torch_npu.get_npu_format(wo_b)==29
  assert torch.count_nonzero(layer.self_attn.wo_b.weight_offset).cpu()==0
  start=torch.tensor(OPROJ_TILE_STARTS[OPROJ_TOKEN_MODES[tokens-1]],device='npu',dtype=torch.int32)
  assert start.shape==(16,8,8)
  torch.manual_seed(4190+tokens);torch.npu.manual_seed(4190+tokens)
  guarded=[]
  def buffer(shape,dtype,fill=-91):
   owner=torch.full((shape[0]+32,*shape[1:]),fill,dtype=dtype,device='npu')
   value=owner[16:16+shape[0]]
   guarded.append((owner,shape[0],fill));return value
  heads=buffer((tokens,32768),torch.bfloat16);heads.normal_(0,0.03)
  residual=buffer((tokens,4,4096),torch.bfloat16);residual.normal_(0,0.1)
  post=buffer((tokens,4),torch.float32);post.uniform_(0,1)
  comb=buffer((tokens,16),torch.float32);comb.uniform_(0,0.25)
  original_heads=heads.clone()
  bundles={}
  for side in ('frozen','resident'):
   bundles[side]={
    'projected':buffer((tokens,8192),torch.bfloat16),
    'quantized':buffer((tokens,8192),torch.int8),
    'token_scale':buffer((tokens,1),torch.float32),
    'attended':buffer((tokens,4096),torch.bfloat16),
    'output':buffer((tokens,4,4096),torch.bfloat16)}
  accum=buffer((tokens+127,8192),torch.float32)
  integer=buffer((tokens+63,4096),torch.int32)
  signal_owner=torch.full((module.WORDS+256,),-91,device='npu',dtype=torch.int32)
  signals=signal_owner[128:-128];signals.zero_()
  residual_flat=residual.view(tokens,16384)
  out_flat=bundles['resident']['output'].view(tokens,16384)
  for a,b in ((residual,residual_flat),(bundles['resident']['output'],out_flat)):
   assert a.is_contiguous() and b.is_contiguous() and a.data_ptr()==b.data_ptr() and a.storage_offset()==b.storage_offset()
  assert len({v.data_ptr() for v in (heads,residual,post,comb,accum,integer,signals,*bundles['resident'].values())})==12
  readonly={n:sha(v) for n,v in {'wo_a':wo_a,'wo_b':wo_b,'channel':channel,'start':start,'residual':residual,'post':post,'comb':comb}.items()}
  report['readonly_sha256']=readonly
  report['input_A_sha256']={'heads':sha(heads),'residual':sha(residual),'post':sha(post),'comb':sha(comb)}
  pypto.torch.init()
  base=pypto.torch.register(o_proj_test,'resident_suffix_test::frozen_oproj')
  hc=pypto.torch.register(hc_post_test,'resident_suffix_test::frozen_post')
  candidate=pypto.torch.register(module.resident_suffix,'resident_suffix_test::candidate')
  def launch(side):
   b=bundles[side]
   if side=='frozen':
    base(heads,wo_a,wo_b,channel,start,b['projected'],b['quantized'],b['token_scale'],b['attended'])
    hc(b['attended'],residual,post,comb,b['output'])
   else:
    candidate(heads,wo_a,wo_b,channel,start,b['projected'],b['quantized'],b['token_scale'],b['attended'],residual_flat,post,comb,out_flat,accum,integer,signals)
  def guards():
   for owner,rows,fill in guarded:
    assert torch.all(owner[:16].cpu()==fill) and torch.all(owner[16+rows:].cpu()==fill),'guard modified'
   assert torch.all(signal_owner[:128].cpu()==-91) and torch.all(signal_owner[-128:].cpu()==-91)
  def generation():
   words=signals.cpu().reshape(6,72,128);g=int(words[0,0,0]);assert g>0
   assert torch.count_nonzero(words[:,:,1:])==0
   used=torch.zeros((6,72),dtype=torch.bool);used[0,:]=True;used[1,:24]=True;used[2,24:]=True;used[3,24:]=True;used[4,:24]=True;used[5,24:]=True
   assert torch.all(words[:,:,0][used]==g) and torch.count_nonzero(words[:,:,0][~used])==0
   return g
  def poison(side):
   for v in bundles[side].values():v.fill_(float('nan') if v.is_floating_point() else -91)
  def compare(label):
   result={}
   for key,a in bundles['resident'].items():
    x=a.cpu();y=bundles['frozen'][key].cpu()
    if x.is_floating_point():assert torch.isfinite(x).all() and torch.isfinite(y).all()
    equal=bit_equal(x,y);diff=x.float()-y.float()
    result[key]={'bit_equal':equal,'different_elements':int((x!=y).sum()),'max_abs':float(diff.abs().max()),'first':(x!=y).nonzero()[:4].tolist()}
   report.setdefault('comparisons',{})[label]=result;save();guards();generation()
   if not all(v['bit_equal'] for v in result.values()):
    torch.save({s:{k:v.cpu() for k,v in b.items()} for s,b in bundles.items()},args.out/'first-difference.pt')
    raise RuntimeError('first suffix difference: '+label)
  for side in bundles:launch(side)
  torch.npu.synchronize();compare('eager_warmup')
  graphs={};stream=torch.npu.Stream();stream.wait_stream(torch.npu.current_stream())
  with torch.npu.stream(stream):
   for side in bundles:
    graph=torch.npu.NPUGraph()
    with torch.npu.graph(graph,stream=stream):launch(side)
    graphs[side]=graph
   torch.npu.synchronize()
   before=generation()
   for side in bundles:poison(side);graphs[side].replay()
   torch.npu.synchronize();assert generation()==before+1;compare('FULL_A')
   baseline_a={k:v.cpu() for k,v in bundles['frozen'].items()}
   heads.add_(0.03125)
   for side in bundles:poison(side);graphs[side].replay()
   torch.npu.synchronize();compare('FULL_B')
   assert not bit_equal(baseline_a['output'],bundles['frozen']['output'].cpu()),'stale input'
   heads.copy_(original_heads)
   for side in bundles:poison(side);graphs[side].replay()
   torch.npu.synchronize();compare('FULL_A_restore')
   assert all(bit_equal(v,bundles['resident'][k].cpu()) for k,v in baseline_a.items())
   stage_proof=json.loads((sdk/'suffix-diagnosis-20261020/WAIT_SOURCE_PROOF.json').read_text())
   assert stage_proof['parent_sha256']==proof['candidate_sha256']
   report['stage_source_proof']=stage_proof
   phase_ops={}
   for name in ('wait0','wait24','wait48'):
    spec=importlib.util.spec_from_file_location('stage_'+name,sdk/'suffix-diagnosis-20261020'/f'{name}.py')
    m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
    expected=json.loads((sdk/'suffix-diagnosis-20261020/WAIT_SOURCE_PROOF.json').read_text())['stages'][name]['sha256']
    assert hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()==expected
    phase_ops[name]=pypto.torch.register(getattr(m,name),'suffix_stage_test::'+name)
   def launch_phase(name):
    b=bundles['resident']
    return phase_ops[name](heads,wo_a,wo_b,channel,start,b['projected'],b['quantized'],b['token_scale'],b['attended'],residual_flat,post,comb,out_flat,accum,integer,signals)
   targets={name:{} for name in phase_ops}
   expected_targets={name:{key:v[:tokens].cpu().clone() for key,v in values.items()} for name,values in targets.items()}
   phase_checks={}
   phase_check_counts={}
   def poison_phase(name):
    for key,v in targets[name].items():
     if v.is_floating_point():v[:tokens].fill_(float('nan'))
     else:v[:tokens].copy_(torch.bitwise_not(expected_targets[name][key]).to(v.device))
   def phase_check(name):
    values={key:bit_equal(value[:tokens].cpu(),expected_targets[name][key]) for key,value in targets[name].items()}
    phase_checks[name]=values
    phase_check_counts[name]=phase_check_counts.get(name,0)+1
    report['phase_check_counts']=phase_check_counts
    report['phase_checks']=phase_checks;save()
    assert all(values.values()),('first isolated-phase difference',name,values)
    compare('isolated_'+name)
   for name in phase_ops:
    poison_phase(name)
    launch_phase(name);torch.npu.synchronize();phase_check(name)
    graph=torch.npu.NPUGraph()
    with torch.npu.graph(graph,stream=stream):launch_phase(name)
    graphs[name]=graph
    poison_phase(name)
    graph.replay();torch.npu.synchronize();phase_check(name)
   if args.mode=='stages':
    samples={s:[] for s in graphs}
    for window in range(12):
     order=list(graphs);order=order[window%len(order):]+order[:window%len(order)]
     if window%2:order.reverse()
     for side in order:
      before=generation()
      start_event,end_event=torch.npu.Event(enable_timing=True),torch.npu.Event(enable_timing=True)
      start_event.record()
      for _ in range(100):graphs[side].replay()
      end_event.record();end_event.synchronize()
      samples[side].append(start_event.elapsed_time(end_event)*1000/100)
      assert generation()==before+(100 if side=='resident' else 0)
      if side in phase_ops:phase_check(side)
      else:compare('window_'+str(window)+'_'+side)
    report['phase_timing_scope']='all-ready wait microbench incl executor and fixed cache-maintenance; wait0 uses same protocol with zero iterations; not producer stall'
    report['timings']={'unit':'us/isolated phase FULL graph replay','windows':12,'replays':100,'outliers_removed':False,'samples':samples,'summary':{s:{'min':min(v),'median':statistics.median(v),'mean':statistics.mean(v),'max':max(v)} for s,v in samples.items()}}
   else:
    for side in ('resident',*phase_ops):
     with torch_npu.profiler.profile(activities=[torch_npu.profiler.ProfilerActivity.CPU,torch_npu.profiler.ProfilerActivity.NPU],record_shapes=True,on_trace_ready=torch_npu.profiler.tensorboard_trace_handler(str(args.out/(side+'-pmu'))),experimental_config=torch_npu.profiler._ExperimentalConfig(profiler_level=torch_npu.profiler.ProfilerLevel.Level1,aic_metrics=torch_npu.profiler.AiCMetrics.PipeUtilization,data_simplification=False)):
      for _ in range(3):graphs[side].replay()
      torch.npu.synchronize()
     if side in phase_ops:phase_check(side)
     else:compare('post_pmu')
    report['PMU']={'scope':'separate instrumentation task; per-phase executor; utilization is not additive elapsed time','replays':3,'phases':list(phase_ops)}
  assert readonly=={n:sha(v) for n,v in {'wo_a':wo_a,'wo_b':wo_b,'channel':channel,'start':start,'residual':residual,'post':post,'comb':comb}.items()}
  assert sha(heads)==sha(original_heads)
  report['actual_acl_graph']=True;report['guards']=True;report['readonly']=True;report['final_generation']=generation();report['pass']=report['complete']=True;save()
except BaseException:
 report['error']=traceback.format_exc();save();raise
finally:
 report['finished_unix']=time.time();save()
