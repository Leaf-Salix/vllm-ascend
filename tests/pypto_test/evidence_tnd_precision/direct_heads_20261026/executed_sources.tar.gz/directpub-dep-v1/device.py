from pathlib import Path
import hashlib,json,runpy,sys
here=Path(__file__).resolve().parent
assert all(hashlib.sha256((here/k).read_bytes()).hexdigest()==v for k,v in json.loads((here/'manifest.json').read_text()).items())
base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-gap-20261026-codex/direct-publish-v5')
assert hashlib.sha256((base/'probe_perf.py').read_bytes()).hexdigest()=='e64dd43a4dade31abc7ae21a51118b2840eda4a02e2a2ae60c90f7bb1ab14540'
sys.path.insert(0,str(base));runpy.run_path(str(base/'sdk_bind.py'),run_name='__sdk_preflight__')
text=(here/'derived_probe.py').read_text()
assert hashlib.sha256(text.encode()).hexdigest()=='3bb6f5c3c973013fb5322457d3d75207d38dd0f6838042600d2b46d66f5a2ad3'
exec(compile(text,str(base/'probe_perf.py'),'exec'),{'__name__':'__main__','__file__':str(base/'probe_perf.py')})
