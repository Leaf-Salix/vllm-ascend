#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit16 required}"
IFS=',' read -r -a fusion_devices <<< "$TASK_DEVICE"
[[ "${#fusion_devices[@]}" == 16 ]]
fusion_seen=,
for fusion_device in "${fusion_devices[@]}"; do
  [[ "$fusion_device" =~ ^[0-9]+$ && "$fusion_seen" != *",$fusion_device,"* ]]
  fusion_seen+="$fusion_device,"
done
case_name=${1:?8k or 128k}
fusion_whole_job_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$fusion_whole_job_root/env.sh"
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
case "$case_name" in
 8k) batch=40;blocks=22000;active=40;bucket=240;util=0.95;bank="$base/low-acceptance-20261010/banks/fixed8192";gold=/data/pyptouser/yejia/lc128/full-pto8k-native-20261016 ;;
 128k) batch=24;blocks=24000;active=21;bucket=144;util=0.97;bank="$base/low-acceptance-128k-b24-20261014/banks/fixed131072";gold=/data/pyptouser/yejia/lc128/retest192-native1-b24000 ;;
 *) exit 2;;
esac
if [[ "$case_name" == 128k ]]; then
 export PTO_CSA_RING_HEAP_MB=56,96,176,1 PTO_CSA_RING_TASK_WINDOW=2048
fi
out="$fusion_whole_job_root/results/directpub-$case_name-v1"
mkdir -p "$fusion_whole_job_root/results"
mkdir "$out"
export PERF_BACKEND=pto PERF_CASE="$case_name" PERF_CAPTURE_BUCKET="$bucket"
export PERF_OUTPUT="$out" PERF_GOLD="$gold" PERF_ACTIVE_REQUESTS="$active"
export LOW_ACCEPTANCE_GPU_BLOCKS="$blocks" LOW_ACCEPTANCE_OFFICIAL_CACHE="$base/low-acceptance-20261010/official-static-cache"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out/opp_env")
export PYPTO_PROG_BUILD_DIR="$out/build" ASCEND_CACHE_PATH="$out/ascend-cache"
export ASCEND_PROCESS_LOG_PATH="$out/ascend" VLLM_CACHE_ROOT="$out/vllm-cache"
mkdir -p "$ASCEND_PROCESS_LOG_PATH" "$ASCEND_CACHE_PATH"
python "$fusion_whole_job_root/preflight.py" "$case_name" "$bank" "$gold" "$out"
export FUSION_WHOLE_ACTIVE=1
cd "$out"
printf 'TASK_MODEL_START %s\n' "$(date -Iseconds)"
trap 'printf "TASK_MODEL_END %s\n" "$(date -Iseconds)"' EXIT
timeout --signal=TERM --kill-after=15s 750s python "$SOURCE_ROOT/tests/pypto_test/offline_pd/run.py" decode \
 --output "$out" --backend pto --pto-attention csa --mixed-requests --batch "$batch" --decode-dp 16 \
 --max-num-batched-tokens 400 --weight-nz-mode 2 --deterministic --port 31863 --gpu-memory-utilization "$util" \
 --event-work-mode 1 --bank "$bank" --decode-tokens 192 --graph-mode full_decode_only --capture-sizes 6 "$bucket" > "$out/launch.log" 2>&1
export FUSION_WHOLE_ACTIVE=0
python "$fusion_whole_job_root/audit.py" "$out"
