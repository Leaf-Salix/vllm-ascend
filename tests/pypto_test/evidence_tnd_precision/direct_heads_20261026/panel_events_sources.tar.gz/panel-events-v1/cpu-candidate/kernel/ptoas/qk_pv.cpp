#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void qk_pv_aic(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, __gm__ int32_t* v4, __gm__ bfloat16_t* v5, __gm__ float* v6, __gm__ bfloat16_t* v7, __gm__ float* v8, __gm__ float* v9, __gm__ float* v10, __gm__ float* v11, __gm__ int64_t* v12, __gm__ int32_t* v13, __gm__ bfloat16_t* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, __gm__ bfloat16_t* v17, __gm__ float* v18, __gm__ float* v19, __gm__ float* v20, __gm__ float* v21, __gm__ float* v22, __gm__ bfloat16_t* v23, int64_t v24, int64_t v25, int64_t v26, int64_t v27, int64_t v28, int64_t v29, int64_t v30, int64_t v31, int64_t v32, int32_t v33, int32_t v34) {
  using T = float;

  #if defined(__DAV_CUBE__)
  const int64_t v35 = 32;
  // pto: %c0_i64
  const int64_t v36 = 0;
  // pto: %c393216_i64
  const int64_t v37 = 393216;
  // pto: %c16384_i64
  const int64_t v38 = 16384;
  // pto: %c32768_i64
  const int64_t v39 = 32768;
  // pto: %c458752_i64
  const int64_t v40 = 458752;
  // pto: %c1_index
  const int64_t v41 = 1;
  // pto: %c512_index
  const int64_t v42 = 512;
  // pto: %c16_index
  const int64_t v43 = 16;
  // pto: %c24576_index
  const int64_t v44 = 24576;
  // pto: %c3072_index
  const int64_t v45 = 3072;
  // pto: %c1536_index
  const int64_t v46 = 1536;
  // pto: %c64_index
  const int64_t v47 = 64;
  // pto: %c128_index
  const int64_t v48 = 128;
  // pto: %c384_index
  const int64_t v49 = 384;
  // pto: %c24_index
  const int64_t v50 = 24;
  // pto: %c0_index
  const int64_t v51 = 0;
  // pto: %c2_index
  const int64_t v52 = 2;
  // pto: %c4_index
  const int64_t v53 = 4;
  // pto: %c5_index
  const int64_t v54 = 5;
  // pto: %c6_index
  const int64_t v55 = 6;
  // pto: %c256_index
  const int64_t v56 = 256;
  // pto: %cn128_index
  const int64_t v57 = -128;
  // pto: %c32_index
  const int64_t v58 = 32;
  // pto: %cn32_index
  const int64_t v59 = -32;
  // pto: %c3_index
  const int64_t v60 = 3;
  // pto: %q_flat_inline5265__ssa_v0_view
  const int64_t v61 = 1;
  // pto: %q_flat_inline5265__ssa_v0_view
  const int64_t v62 = 1;
  // pto: %q_flat_inline5265__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %q_flat_inline5265__ssa_v0_view
  int64_t v64 = (int64_t) v26;
  // pto: %q_flat_inline5265__ssa_v0_view
  int64_t v65 = v64 * v42;
  // pto: %q_flat_inline5265__ssa_v0_view
  int64_t v66 = v63 * v65;
  // pto: %q_flat_inline5265__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v67 = pto::Shape<1, 1, 1, -1, -1>(v61, v62, v63, v64, v42);
  // pto: %q_flat_inline5265__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v68 = pto::Stride<-1, -1, -1, -1, -1>(v62 * v66, v66, v65, v42, v41);
  // pto: %q_flat_inline5265__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v69 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v67, v68);
  // pto: %kv_transfer_inline5176__ssa_v0_view
  const int64_t v70 = 1;
  // pto: %kv_transfer_inline5176__ssa_v0_view
  const int64_t v71 = 1;
  // pto: %kv_transfer_inline5176__ssa_v0_view
  const int64_t v72 = 1;
  // pto: %kv_transfer_inline5176__ssa_v0_view
  int64_t v73 = v44 * v42;
  // pto: %kv_transfer_inline5176__ssa_v0_view
  int64_t v74 = v72 * v73;
  // pto: %kv_transfer_inline5176__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v75 = pto::Shape<1, 1, 1, -1, -1>(v70, v71, v72, v44, v42);
  // pto: %kv_transfer_inline5176__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v76 = pto::Stride<-1, -1, -1, -1, -1>(v71 * v74, v74, v73, v42, v41);
  // pto: %kv_transfer_inline5176__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v77 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v75, v76);
  // pto: %score_transfer_inline5170__ssa_v0_view
  const int64_t v78 = 1;
  // pto: %score_transfer_inline5170__ssa_v0_view
  const int64_t v79 = 1;
  // pto: %score_transfer_inline5170__ssa_v0_view
  const int64_t v80 = 1;
  // pto: %score_transfer_inline5170__ssa_v0_view
  int64_t v81 = v45 * v42;
  // pto: %score_transfer_inline5170__ssa_v0_view
  int64_t v82 = v80 * v81;
  // pto: %score_transfer_inline5170__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v83 = pto::Shape<1, 1, 1, -1, -1>(v78, v79, v80, v45, v42);
  // pto: %score_transfer_inline5170__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v84 = pto::Stride<-1, -1, -1, -1, -1>(v79 * v82, v82, v81, v42, v41);
  // pto: %score_transfer_inline5170__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v85 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v83, v84);
  // pto: %probability_transfer_inline5407__ssa_v0_view
  const int64_t v86 = 1;
  // pto: %probability_transfer_inline5407__ssa_v0_view
  const int64_t v87 = 1;
  // pto: %probability_transfer_inline5407__ssa_v0_view
  const int64_t v88 = 1;
  // pto: %probability_transfer_inline5407__ssa_v0_view
  int64_t v89 = v46 * v42;
  // pto: %probability_transfer_inline5407__ssa_v0_view
  int64_t v90 = v88 * v89;
  // pto: %probability_transfer_inline5407__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v91 = pto::Shape<1, 1, 1, -1, -1>(v86, v87, v88, v46, v42);
  // pto: %probability_transfer_inline5407__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v92 = pto::Stride<-1, -1, -1, -1, -1>(v87 * v90, v90, v89, v42, v41);
  // pto: %probability_transfer_inline5407__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v93 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v91, v92);
  // pto: %pv_transfer_inline5166__ssa_v0_view
  const int64_t v94 = 1;
  // pto: %pv_transfer_inline5166__ssa_v0_view
  const int64_t v95 = 1;
  // pto: %pv_transfer_inline5166__ssa_v0_view
  const int64_t v96 = 1;
  // pto: %pv_transfer_inline5166__ssa_v0_view
  int64_t v97 = v46 * v42;
  // pto: %pv_transfer_inline5166__ssa_v0_view
  int64_t v98 = v96 * v97;
  // pto: %pv_transfer_inline5166__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v99 = pto::Shape<1, 1, 1, -1, -1>(v94, v95, v96, v46, v42);
  // pto: %pv_transfer_inline5166__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v100 = pto::Stride<-1, -1, -1, -1, -1>(v95 * v98, v98, v97, v42, v41);
  // pto: %pv_transfer_inline5166__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v101 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v99, v100);
  // pto: %qk_l1_inline5256__phi_v16
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v102 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v49, v42);
  // pto: %qk_l1_inline5256__phi_v16
  uint64_t v103 = (uint64_t) v36;
  TASSIGN(v102, v103);
  // pto: %qk_l1_inline5256__phi_v8
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v104 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v49, v42);
  // pto: %qk_l1_inline5256__phi_v8
  uint64_t v105 = (uint64_t) v36;
  TASSIGN(v104, v105);
  // pto: %pv_acc_inline5207__phi_v4
  Tile<TileType::Acc, float, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v106 = Tile<TileType::Acc, float, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v47, v42);
  // pto: %pv_acc_inline5207__phi_v4
  uint64_t v107 = (uint64_t) v36;
  TASSIGN(v106, v107);
  // pto: %qk_l1_inline5256__phi_v15
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v108 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v49, v42);
  // pto: %qk_l1_inline5256__phi_v15
  uint64_t v109 = (uint64_t) v36;
  TASSIGN(v108, v109);
  // pto: %qk_l1_inline5256__phi_v14
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v110 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v49, v42);
  // pto: %qk_l1_inline5256__phi_v14
  uint64_t v111 = (uint64_t) v36;
  TASSIGN(v110, v111);
  // pto: %qk_core_inline5174__ssa_v0
  int64_t v112 = (int64_t) v33;
  // pto: %6
  int64_t v113 = (int64_t) ((uint64_t) v112 * (uint64_t) v47);
  uint64_t v114 = reinterpret_cast<uint64_t>(v1);
  set_ffts_base_addr(v114);
  // pto: %qk_l1_inline5256__ssa_v0
  Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v115 = Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v49, v42);
  // pto: %qk_l1_inline5256__ssa_v0
  uint64_t v116 = (uint64_t) v36;
  TASSIGN(v115, v116);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  for (int64_t v117 = v112; v117 < v24; v117 += v50) {
    // pto: %qk_q_inline5216__ssa_v0
    ;
    Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v118 = Tile<TileType::Mat, bfloat16_t, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v42);
    // pto: %qk_q_inline5216__ssa_v0
    ;
    uint64_t v119 = (uint64_t) v37;
    TASSIGN(v118, v119);
    // pto: %8
    ;
    int64_t v120 = (int64_t) ((uint64_t) v117 * (uint64_t) v47);
    // pto: %9
    ;
    int64_t v121 = v120 < v51 ? v51 : v120;
    // pto: %q_flat_inline5265__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v122 = PTOAS__GLOBAL_TENSOR_DATA(v69);
    // pto: %q_flat_inline5265__ssa_v0_pview
    ;
    const int64_t v123 = 0;
    // pto: %q_flat_inline5265__ssa_v0_pview
    ;
    const int64_t v124 = 512;
    // pto: %q_flat_inline5265__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 64, 512> v125 = pto::Shape<1, 1, 1, 64, 512>();
    // pto: %q_flat_inline5265__ssa_v0_pview
    ;
    pto::Stride<32768, 32768, 32768, 512, 1> v126 = pto::Stride<32768, 32768, 32768, 512, 1>();
    // pto: %q_flat_inline5265__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v127 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v122 + (v123 + v121 * v124), v125, v126);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    TLOAD(v118, v127);
    set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    // pto: %flat_offset_mul
    ;
    int64_t v128 = (int64_t) ((uint64_t) v117 * (uint64_t) v43);
    // pto: %t__tile
    ;
    int32_t v129 = (v4)[v128];
    // pto: %13, %11
    ;
    int32_t v130 = (v4)[(int64_t) ((uint64_t) v128 + (uint64_t) v41)];
    wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
    for (int64_t v131 = v51; v131 < v52; v131 += v41) {
      // pto: %22, %20
      ;
      int32_t v132 = (v4)[(int64_t) ((uint64_t) v128 + (uint64_t) v131)];
      // pto: %23, %24
      ;
      if ((int64_t) v132 > v51) {
        // pto: %25, %26, %27
        ;
        int64_t v133 = (int64_t) ((uint64_t) ((int64_t) ((uint64_t) v117 - (uint64_t) v112) / v50) * (uint64_t) v52);
        // pto: %29
        ;
        int64_t v134 = (int64_t) ((uint64_t) v112 * (uint64_t) v52);
        // pto: %28, %30
        ;
        int64_t v135 = (int64_t) ((uint64_t) v133 + (uint64_t) v131) % v52;
        // pto: %31, %32, %33
        ;
        int64_t v136 = v135 < v51 ? (int64_t) ((uint64_t) v135 + (uint64_t) v52) : v135;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        for (int64_t v137 = v51; v137 < v53; v137 += v41) {
          // pto: %36
          ;
          int64_t v138 = (int64_t) ((uint64_t) v137 * (uint64_t) v48);
          // pto: %37
          ;
          int64_t v139 = (int64_t) ((uint64_t) v137 - (uint64_t) v41);
          // pto: %38
          ;
          int64_t v140 = v139 < v51 ? v51 : v139;
          // pto: %39
          ;
          int64_t v141 = (int64_t) ((uint64_t) v140 * (uint64_t) v48);
          // pto: %41
          ;
          bool v142 = v137 == v51;
          // pto: %40, %42
          ;
          if (v131 > v51 | v142) {
            if (v142) {
              int32_t v143 = (int32_t) v51;
              wait_flag_dev(v143);
            } else {
              // pto: %44
              ;
              if (v137 == v41) {
                int32_t v144 = (int32_t) v53;
                wait_flag_dev(v144);
              } else {
                // pto: %45
                ;
                if (v137 == v52) {
                  int32_t v145 = (int32_t) v54;
                  wait_flag_dev(v145);
                } else {
                  int32_t v146 = (int32_t) v55;
                  wait_flag_dev(v146);
                };
              };
            };
            // pto: %gather_row_view
            ;
            Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, 128, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v147;
            // pto: %gather_row_view
            ;
            uint64_t v148 = (uint64_t) ((int64_t) (uint64_t) v141 * (uint64_t) v35);
            TASSIGN(v147, v148);
            // pto: %34, %35, %46
            ;
            int64_t v149 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v134 + (uint64_t) v136) * (uint64_t) v42) + (uint64_t) v138);
            // pto: %47
            ;
            int64_t v150 = v149 < v51 ? v51 : v149;
            // pto: %kv_transfer_inline5176__ssa_v0_pview
            ;
            __gm__ bfloat16_t* v151 = PTOAS__GLOBAL_TENSOR_DATA(v77);
            // pto: %kv_transfer_inline5176__ssa_v0_pview
            ;
            const int64_t v152 = 0;
            // pto: %kv_transfer_inline5176__ssa_v0_pview
            ;
            const int64_t v153 = 512;
            // pto: %kv_transfer_inline5176__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 128, 512> v154 = pto::Shape<1, 1, 1, 128, 512>();
            // pto: %kv_transfer_inline5176__ssa_v0_pview
            ;
            pto::Stride<65536, 65536, 65536, 512, 1> v155 = pto::Stride<65536, 65536, 65536, 512, 1>();
            // pto: %kv_transfer_inline5176__ssa_v0_pview
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND> v156 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND>(v151 + (v152 + v150 * v153), v154, v155);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            TLOAD(v147, v156);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %qk_l1_t_inline5257__ssa_v0
            ;
            Tile<TileType::Mat, bfloat16_t, 512, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v157 = Tile<TileType::Mat, bfloat16_t, 512, 384, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v42, v49);
            // pto: %qk_l1_t_inline5257__ssa_v0
            ;
            uint64_t v158 = (uint64_t) v36;
            TASSIGN(v157, v158);
            // pto: %qk_scores_inline5298__ssa_v0_l0_init
            ;
            Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v159 = Tile<TileType::Acc, float, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v47, v48);
            // pto: %qk_scores_inline5298__ssa_v0_l0_init
            ;
            uint64_t v160 = (uint64_t) v36;
            TASSIGN(v159, v160);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
            for (int64_t v161 = v51; v161 < v42; v161 += v56) {
              // pto: %qk_scores_inline5298__ssa_v0_l0_a
              ;
              Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v162 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v48);
              // pto: %qk_scores_inline5298__ssa_v0_l0_a
              ;
              uint64_t v163 = (uint64_t) v36;
              TASSIGN(v162, v163);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              pipe_barrier(PIPE_MTE1);
              uint16_t v164 = static_cast<uint16_t>(v51);
              uint16_t v165 = static_cast<uint16_t>(v161);
              TEXTRACT(v162, v118, v164, v165);
              // pto: %qk_scores_inline5298__ssa_v0_l0_b
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v166 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v48, v48);
              // pto: %qk_scores_inline5298__ssa_v0_l0_b
              ;
              uint64_t v167 = (uint64_t) v36;
              TASSIGN(v166, v167);
              uint16_t v168 = static_cast<uint16_t>(v161);
              uint16_t v169 = static_cast<uint16_t>(v141);
              TEXTRACT(v166, v157, v168, v169);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              // pto: %0
              ;
              Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v170 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v48);
              // pto: %0
              ;
              uint64_t v171 = (uint64_t) v38;
              TASSIGN(v170, v171);
              // pto: %48
              ;
              int64_t v172 = (int64_t) ((uint64_t) v161 + (uint64_t) v48);
              wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
              uint16_t v173 = static_cast<uint16_t>(v51);
              uint16_t v174 = static_cast<uint16_t>(v172);
              TEXTRACT(v170, v118, v173, v174);
              // pto: %1
              ;
              Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v175 = Tile<TileType::Right, bfloat16_t, 128, 128, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v48, v48);
              // pto: %1
              ;
              uint64_t v176 = (uint64_t) v39;
              TASSIGN(v175, v176);
              uint16_t v177 = static_cast<uint16_t>(v172);
              uint16_t v178 = static_cast<uint16_t>(v141);
              TEXTRACT(v175, v157, v177, v178);
              set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              // pto: %50
              ;
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
              if (v161 == v51) {
                pipe_barrier(PIPE_M);
                TMATMUL(v159, v162, v166);
              } else {
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v159, v159, v162, v166);
              };
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
              // pto: %51
              ;
              wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
              if (v161 == v57) {
                pipe_barrier(PIPE_M);
                TMATMUL(v159, v170, v175);
              } else {
                pipe_barrier(PIPE_M);
                TMATMUL_ACC(v159, v159, v170, v175);
              };
              set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            };
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
            // pto: %7, %53, %52
            ;
            int64_t v179 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v112 * (uint64_t) v48) + (uint64_t) ((int64_t) (uint64_t) v131 * (uint64_t) v47));
            // pto: %54
            ;
            int64_t v180 = v179 < v51 ? v51 : v179;
            // pto: %55
            ;
            int64_t v181 = v138 < v51 ? v51 : v138;
            // pto: %score_transfer_inline5170__ssa_v0_pview
            ;
            __gm__ float* v182 = PTOAS__GLOBAL_TENSOR_DATA(v85);
            // pto: %score_transfer_inline5170__ssa_v0_pview
            ;
            const int64_t v183 = 0;
            // pto: %score_transfer_inline5170__ssa_v0_pview
            ;
            const int64_t v184 = 512;
            // pto: %score_transfer_inline5170__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 64, 128> v185 = pto::Shape<1, 1, 1, 64, 128>();
            // pto: %score_transfer_inline5170__ssa_v0_pview
            ;
            pto::Stride<32768, 32768, 32768, 512, 1> v186 = pto::Stride<32768, 32768, 32768, 512, 1>();
            // pto: %score_transfer_inline5170__ssa_v0_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v187 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v182 + (v183 + v180 * v184 + v181), v185, v186);
            wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
            pipe_barrier(PIPE_FIX);
            TSTORE(v187, v159);
            set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
          };
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        uint16_t v188 = getFFTSMsg(FFTS_MODE_VAL, v41);
        ffts_cross_core_sync(PIPE_FIX, v188);
        // pto: %14, %15, %16, %17, %18, %qk_pair_lookahead_inline5180__phi_v2, %57, %58
        ;
        bool v189 = (int64_t) ((int32_t) (int64_t) v129 > v51 & (int64_t) v130 > v51) > v51;
        // pto: %pv_begin_inline5220__phi_v2
        ;
        int64_t v190 = v189 ? v51 : v131;
        // pto: %pv_count_inline5284__phi_v2
        ;
        int64_t v191;
        if (v189) {
          // pto: %60
          ;
          v191 = (int64_t) ((uint64_t) v131 * (uint64_t) v52);
        } else {
          v191 = v41;
        };
        // pto: %61
        ;
        uint64_t v192 = (uint64_t) v191;
        // pto: %61
        ;
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
        for (int64_t v193 = v190; v193 < ((int64_t) ((uint64_t) v190 + v192)); v193 += v41) {
          // pto: %65, %67
          ;
          int64_t v194 = (int64_t) ((uint64_t) v133 + (uint64_t) v193) % v52;
          // pto: %68, %69, %70
          ;
          int64_t v195 = v194 < v51 ? (int64_t) ((uint64_t) v194 + (uint64_t) v52) : v194;
          int32_t v196 = (int32_t) v52;
          wait_flag_dev(v196);
          // pto: %pv_acc_inline5207__ssa_v0
          ;
          Tile<TileType::Acc, float, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v197 = Tile<TileType::Acc, float, 64, 512, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v47, v42);
          // pto: %pv_acc_inline5207__ssa_v0
          ;
          uint64_t v198 = (uint64_t) v36;
          TASSIGN(v197, v198);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
          for (int64_t v199 = v51; v199 < v53; v199 += v41) {
            // pto: %74
            ;
            bool v200 = v199 == v51;
            // pto: %73, %75
            ;
            if (v193 > v51 | v200) {
              // pto: %76
              ;
              int64_t v201 = (int64_t) ((uint64_t) v199 * (uint64_t) v48);
              // pto: %pv_probability_inline5338__ssa_v0
              ;
              Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v202 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v48);
              // pto: %pv_probability_inline5338__ssa_v0
              ;
              uint64_t v203 = (uint64_t) v40;
              TASSIGN(v202, v203);
              // pto: %77
              ;
              int64_t v204 = v113 < v51 ? v51 : v113;
              // pto: %78
              ;
              int64_t v205 = v201 < v51 ? v51 : v201;
              // pto: %probability_transfer_inline5407__ssa_v0_pview
              ;
              __gm__ bfloat16_t* v206 = PTOAS__GLOBAL_TENSOR_DATA(v93);
              // pto: %probability_transfer_inline5407__ssa_v0_pview
              ;
              const int64_t v207 = 0;
              // pto: %probability_transfer_inline5407__ssa_v0_pview
              ;
              const int64_t v208 = 512;
              // pto: %probability_transfer_inline5407__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 64, 128> v209 = pto::Shape<1, 1, 1, 64, 128>();
              // pto: %probability_transfer_inline5407__ssa_v0_pview
              ;
              pto::Stride<32768, 32768, 32768, 512, 1> v210 = pto::Stride<32768, 32768, 32768, 512, 1>();
              // pto: %probability_transfer_inline5407__ssa_v0_pview
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v211 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 128>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v206 + (v207 + v204 * v208 + v205), v209, v210);
              wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
              TLOAD(v202, v211);
              // pto: %79
              ;
              int64_t v212 = (int64_t) ((uint64_t) v199 - (uint64_t) v41);
              // pto: %80
              ;
              int64_t v213 = v212 < v51 ? v51 : v212;
              // pto: %81
              ;
              int64_t v214 = (int64_t) ((uint64_t) v213 * (uint64_t) v48);
              // pto: %82
              ;
              if (v199 < v52) {
                // pto: %83
                ;
                Tile<TileType::Mat, bfloat16_t, 384, 512, BLayout::ColMajor, 128, 512, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v215;
                // pto: %83
                ;
                uint64_t v216 = (uint64_t) ((int64_t) (uint64_t) v214 * (uint64_t) v35);
                TASSIGN(v215, v216);
                // pto: %71, %72, %84
                ;
                int64_t v217 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v134 + (uint64_t) v195) * (uint64_t) v42) + (uint64_t) v201);
                // pto: %85
                ;
                int64_t v218 = v217 < v51 ? v51 : v217;
                // pto: %86
                ;
                __gm__ bfloat16_t* v219 = PTOAS__GLOBAL_TENSOR_DATA(v77);
                // pto: %86
                ;
                const int64_t v220 = 0;
                // pto: %86
                ;
                const int64_t v221 = 512;
                // pto: %86
                ;
                pto::Shape<1, 1, 1, 128, 512> v222 = pto::Shape<1, 1, 1, 128, 512>();
                // pto: %86
                ;
                pto::Stride<65536, 65536, 65536, 512, 1> v223 = pto::Stride<65536, 65536, 65536, 512, 1>();
                // pto: %86
                ;
                GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND> v224 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 512>, pto::Stride<65536, 65536, 65536, 512, 1>, pto::Layout::ND>(v219 + (v220 + v218 * v221), v222, v223);
                TLOAD(v215, v224);
              };
              set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
              wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
              for (int64_t v225 = v51; v225 < v48; v225 += v47) {
                // pto: %pv_acc_inline5207__ssa_v3_l0_a
                ;
                Tile<TileType::Left, bfloat16_t, 64, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v226 = Tile<TileType::Left, bfloat16_t, 64, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v58);
                // pto: %pv_acc_inline5207__ssa_v3_l0_a
                ;
                uint64_t v227 = (uint64_t) v36;
                TASSIGN(v226, v227);
                pipe_barrier(PIPE_MTE1);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
                uint16_t v228 = static_cast<uint16_t>(v51);
                uint16_t v229 = static_cast<uint16_t>(v225);
                TEXTRACT(v226, v202, v228, v229);
                // pto: %pv_acc_inline5207__ssa_v3_l0_b
                ;
                Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v230 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v58, v42);
                // pto: %pv_acc_inline5207__ssa_v3_l0_b
                ;
                uint64_t v231 = (uint64_t) v36;
                TASSIGN(v230, v231);
                // pto: %87
                ;
                int64_t v232 = (int64_t) ((uint64_t) v225 + (uint64_t) v214);
                uint16_t v233 = static_cast<uint16_t>(v232);
                uint16_t v234 = static_cast<uint16_t>(v51);
                TEXTRACT(v230, v110, v233, v234);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
                // pto: %3
                ;
                Tile<TileType::Left, bfloat16_t, 64, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Left, bfloat16_t, 64, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v47, v58);
                // pto: %3
                ;
                uint64_t v236 = (uint64_t) v38;
                TASSIGN(v235, v236);
                wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
                uint16_t v237 = static_cast<uint16_t>(v51);
                // pto: %88
                ;
                uint16_t v238 = static_cast<uint16_t>((int64_t) ((uint64_t) v225 + (uint64_t) v58));
                TEXTRACT(v235, v202, v237, v238);
                // pto: %4
                ;
                Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v239 = Tile<TileType::Right, bfloat16_t, 32, 512, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v58, v42);
                // pto: %4
                ;
                uint64_t v240 = (uint64_t) v39;
                TASSIGN(v239, v240);
                // pto: %90
                ;
                uint16_t v241 = static_cast<uint16_t>((int64_t) ((uint64_t) v232 + (uint64_t) v58));
                uint16_t v242 = static_cast<uint16_t>(v51);
                TEXTRACT(v239, v110, v241, v242);
                set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
                // pto: %92, %93
                ;
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
                if (v200 & v225 == v51) {
                  pipe_barrier(PIPE_M);
                  TMATMUL(v197, v226, v230);
                } else {
                  pipe_barrier(PIPE_M);
                  TMATMUL_ACC(v197, v197, v226, v230);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
                // pto: %95, %96
                ;
                wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
                if (v200 & v225 == v59) {
                  pipe_barrier(PIPE_M);
                  TMATMUL(v197, v235, v239);
                } else {
                  pipe_barrier(PIPE_M);
                  TMATMUL_ACC(v197, v197, v235, v239);
                };
                set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
              };
              set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
            };
          };
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          // pto: %97
          ;
          int64_t v243 = v113 < v51 ? v51 : v113;
          // pto: %pv_transfer_inline5166__ssa_v0_pview
          ;
          __gm__ float* v244 = PTOAS__GLOBAL_TENSOR_DATA(v101);
          // pto: %pv_transfer_inline5166__ssa_v0_pview
          ;
          const int64_t v245 = 0;
          // pto: %pv_transfer_inline5166__ssa_v0_pview
          ;
          const int64_t v246 = 512;
          // pto: %pv_transfer_inline5166__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 64, 512> v247 = pto::Shape<1, 1, 1, 64, 512>();
          // pto: %pv_transfer_inline5166__ssa_v0_pview
          ;
          pto::Stride<32768, 32768, 32768, 512, 1> v248 = pto::Stride<32768, 32768, 32768, 512, 1>();
          // pto: %pv_transfer_inline5166__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v249 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v244 + (v245 + v243 * v246), v247, v248);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
          pipe_barrier(PIPE_FIX);
          TSTORE(v249, v197);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
          uint16_t v250 = getFFTSMsg(FFTS_MODE_VAL, v60);
          ffts_cross_core_sync(PIPE_FIX, v250);
        };
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      };
    };
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    uint64_t v251 = reinterpret_cast<uint64_t>(v1);
    set_ffts_base_addr(v251);
  }
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void qk_pv_aiv(__gm__ int64_t* v1, __gm__ int32_t* v2, __gm__ bfloat16_t* v3, __gm__ int32_t* v4, __gm__ bfloat16_t* v5, __gm__ float* v6, __gm__ bfloat16_t* v7, __gm__ float* v8, __gm__ float* v9, __gm__ float* v10, __gm__ float* v11, __gm__ int64_t* v12, __gm__ int32_t* v13, __gm__ bfloat16_t* v14, __gm__ int32_t* v15, __gm__ int32_t* v16, __gm__ bfloat16_t* v17, __gm__ float* v18, __gm__ float* v19, __gm__ float* v20, __gm__ float* v21, __gm__ float* v22, __gm__ bfloat16_t* v23, int64_t v24, int64_t v25, int64_t v26, int64_t v27, int64_t v28, int64_t v29, int64_t v30, int64_t v31, int64_t v32, int32_t v33, int32_t v34, int32_t v35) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v36 = 1024;
  // pto: %c128_i64
  const int64_t v37 = 128;
  // pto: %c82048_i64
  const int64_t v38 = 82048;
  // pto: %c82176_i64
  const int64_t v39 = 82176;
  // pto: %c16512_i64
  const int64_t v40 = 16512;
  // pto: %c49280_i64
  const int64_t v41 = 49280;
  // pto: %c110720_i64
  const int64_t v42 = 110720;
  // pto: %c98432_i64
  const int64_t v43 = 98432;
  // pto: %c98464_i64
  const int64_t v44 = 98464;
  // pto: %c116864_i64
  const int64_t v45 = 116864;
  // pto: %c116896_i64
  const int64_t v46 = 116896;
  // pto: %c116928_i64
  const int64_t v47 = 116928;
  // pto: %c116960_i64
  const int64_t v48 = 116960;
  // pto: %c100480_i64
  const int64_t v49 = 100480;
  // pto: %c101248_i64
  const int64_t v50 = 101248;
  const int64_t v51 = 82304;
  // pto: %c102528_i64
  const int64_t v52 = 102528;
  // pto: %c104576_i64
  const int64_t v53 = 104576;
  // pto: %c104832_i64
  const int64_t v54 = 104832;
  const int64_t v55 = 82560;
  const int64_t v56 = 82816;
  const int64_t v57 = 83072;
  const int64_t v58 = 83328;
  const int64_t v59 = 83584;
  const int64_t v60 = 83840;
  // pto: %c114816_i64
  const int64_t v61 = 114816;
  // pto: %c98688_i64
  const int64_t v62 = 98688;
  // pto: %c0_i64
  const int64_t v63 = 0;
  // pto: %c118912_i64
  const int64_t v64 = 118912;
  // pto: %c119168_i64
  const int64_t v65 = 119168;
  // pto: %c84096_i64
  const int64_t v66 = 84096;
  // pto: %c84864_i64
  const int64_t v67 = 84864;
  // pto: %c119424_i64
  const int64_t v68 = 119424;
  // pto: %c106624_i64
  const int64_t v69 = 106624;
  // pto: %c108672_i64
  const int64_t v70 = 108672;
  // pto: %c90240_i64
  const int64_t v71 = 90240;
  // pto: %c1_index
  const int64_t v72 = 1;
  // pto: %c512_index
  const int64_t v73 = 512;
  // pto: %c16_index
  const int64_t v74 = 16;
  // pto: %c24576_index
  const int64_t v75 = 24576;
  // pto: %c3072_index
  const int64_t v76 = 3072;
  // pto: %c1536_index
  const int64_t v77 = 1536;
  // pto: %c64_index
  const int64_t v78 = 64;
  // pto: %c1024_index
  const int64_t v79 = 1024;
  // pto: %c32768_index
  const int64_t v80 = 32768;
  // pto: %c128_index
  const int64_t v81 = 128;
  // pto: %c24_index
  const int64_t v82 = 24;
  // pto: %c0_index
  const int64_t v83 = 0;
  // pto: %c32_index
  const int64_t v84 = 32;
  // pto: %c8_index
  const int64_t v85 = 8;
  // pto: %cst_49
  const float v86 = 0.0f;
  // pto: %cst_50
  const float v87 = 1.0f;
  // pto: %c256_index
  const int64_t v88 = 256;
  // pto: %c2_index
  const int64_t v89 = 2;
  // pto: %c4_index
  const int64_t v90 = 4;
  // pto: %cst_54
  const bfloat16_t v91 = 0.0f;
  // pto: %c96_index
  const int64_t v92 = 96;
  // pto: %c160_index
  const int64_t v93 = 160;
  // pto: %c5_index
  const int64_t v94 = 5;
  // pto: %c6_index
  const int64_t v95 = 6;
  // pto: %c384_index
  const int64_t v96 = 384;
  // pto: %cst_60
  const float v97 = 0.0441941731f;
  // pto: %c192_index
  const int64_t v98 = 192;
  const int32_t v99 = 0;
  // pto: %c320_index
  const int64_t v100 = 320;
  // pto: %c448_index
  const int64_t v101 = 448;
  // pto: %c3_index
  const int64_t v102 = 3;
  // pto: %cst_66
  const float v103 = 0.5f;
  // pto: %cst_67
  const float v104 = 2.0f;
  // pto: %c2_i32
  const int32_t v105 = 2;
  // pto: %c449_i32
  const int32_t v106 = 449;
  // pto: %c512_i32
  const int32_t v107 = 512;
  // pto: %c4096_index
  const int64_t v108 = 4096;
  // pto: %kv_transfer_inline5176__ssa_v0_view
  const int64_t v109 = 1;
  // pto: %kv_transfer_inline5176__ssa_v0_view
  const int64_t v110 = 1;
  // pto: %kv_transfer_inline5176__ssa_v0_view
  const int64_t v111 = 1;
  // pto: %kv_transfer_inline5176__ssa_v0_view
  int64_t v112 = v75 * v73;
  // pto: %kv_transfer_inline5176__ssa_v0_view
  int64_t v113 = v111 * v112;
  // pto: %kv_transfer_inline5176__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v114 = pto::Shape<1, 1, 1, -1, -1>(v109, v110, v111, v75, v73);
  // pto: %kv_transfer_inline5176__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v115 = pto::Stride<-1, -1, -1, -1, -1>(v110 * v113, v113, v112, v73, v72);
  // pto: %kv_transfer_inline5176__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v116 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v114, v115);
  // pto: %score_transfer_inline5170__ssa_v0_view
  const int64_t v117 = 1;
  // pto: %score_transfer_inline5170__ssa_v0_view
  const int64_t v118 = 1;
  // pto: %score_transfer_inline5170__ssa_v0_view
  const int64_t v119 = 1;
  // pto: %score_transfer_inline5170__ssa_v0_view
  int64_t v120 = v76 * v73;
  // pto: %score_transfer_inline5170__ssa_v0_view
  int64_t v121 = v119 * v120;
  // pto: %score_transfer_inline5170__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v122 = pto::Shape<1, 1, 1, -1, -1>(v117, v118, v119, v76, v73);
  // pto: %score_transfer_inline5170__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v123 = pto::Stride<-1, -1, -1, -1, -1>(v118 * v121, v121, v120, v73, v72);
  // pto: %score_transfer_inline5170__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v124 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v122, v123);
  // pto: %probability_transfer_inline5407__ssa_v0_view
  const int64_t v125 = 1;
  // pto: %probability_transfer_inline5407__ssa_v0_view
  const int64_t v126 = 1;
  // pto: %probability_transfer_inline5407__ssa_v0_view
  const int64_t v127 = 1;
  // pto: %probability_transfer_inline5407__ssa_v0_view
  int64_t v128 = v77 * v73;
  // pto: %probability_transfer_inline5407__ssa_v0_view
  int64_t v129 = v127 * v128;
  // pto: %probability_transfer_inline5407__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v130 = pto::Shape<1, 1, 1, -1, -1>(v125, v126, v127, v77, v73);
  // pto: %probability_transfer_inline5407__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v131 = pto::Stride<-1, -1, -1, -1, -1>(v126 * v129, v129, v128, v73, v72);
  // pto: %probability_transfer_inline5407__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v132 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v130, v131);
  // pto: %pv_transfer_inline5166__ssa_v0_view
  const int64_t v133 = 1;
  // pto: %pv_transfer_inline5166__ssa_v0_view
  const int64_t v134 = 1;
  // pto: %pv_transfer_inline5166__ssa_v0_view
  const int64_t v135 = 1;
  // pto: %pv_transfer_inline5166__ssa_v0_view
  int64_t v136 = v77 * v73;
  // pto: %pv_transfer_inline5166__ssa_v0_view
  int64_t v137 = v135 * v136;
  // pto: %pv_transfer_inline5166__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v138 = pto::Shape<1, 1, 1, -1, -1>(v133, v134, v135, v77, v73);
  // pto: %pv_transfer_inline5166__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v139 = pto::Stride<-1, -1, -1, -1, -1>(v134 * v137, v137, v136, v73, v72);
  // pto: %pv_transfer_inline5166__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v140 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v8, v138, v139);
  // pto: %attn_sink_col_inline5179__ssa_v0_view
  const int64_t v141 = 1;
  // pto: %attn_sink_col_inline5179__ssa_v0_view
  const int64_t v142 = 1;
  // pto: %attn_sink_col_inline5179__ssa_v0_view
  const int64_t v143 = 1;
  // pto: %attn_sink_col_inline5179__ssa_v0_view
  int64_t v144 = v78 * v72;
  // pto: %attn_sink_col_inline5179__ssa_v0_view
  int64_t v145 = v143 * v144;
  // pto: %attn_sink_col_inline5179__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v146 = pto::Shape<1, 1, 1, -1, -1>(v141, v142, v143, v78, v72);
  // pto: %attn_sink_col_inline5179__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v147 = pto::Stride<-1, -1, -1, -1, -1>(v142 * v145, v145, v144, v72, v78);
  // pto: %attn_sink_col_inline5179__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v148 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v9, v146, v147);
  // pto: %mi_transfer_inline5181__ssa_v0_view
  const int64_t v149 = 1;
  // pto: %mi_transfer_inline5181__ssa_v0_view
  const int64_t v150 = 1;
  // pto: %mi_transfer_inline5181__ssa_v0_view
  const int64_t v151 = 1;
  // pto: %mi_transfer_inline5181__ssa_v0_view
  int64_t v152 = v77 * v72;
  // pto: %mi_transfer_inline5181__ssa_v0_view
  int64_t v153 = v151 * v152;
  // pto: %mi_transfer_inline5181__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v154 = pto::Shape<1, 1, 1, -1, -1>(v149, v150, v151, v77, v72);
  // pto: %mi_transfer_inline5181__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v155 = pto::Stride<-1, -1, -1, -1, -1>(v150 * v153, v153, v152, v72, v77);
  // pto: %mi_transfer_inline5181__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v156 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v10, v154, v155);
  // pto: %li_transfer_inline5253__ssa_v0_view
  const int64_t v157 = 1;
  // pto: %li_transfer_inline5253__ssa_v0_view
  const int64_t v158 = 1;
  // pto: %li_transfer_inline5253__ssa_v0_view
  const int64_t v159 = 1;
  // pto: %li_transfer_inline5253__ssa_v0_view
  int64_t v160 = v77 * v72;
  // pto: %li_transfer_inline5253__ssa_v0_view
  int64_t v161 = v159 * v160;
  // pto: %li_transfer_inline5253__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v162 = pto::Shape<1, 1, 1, -1, -1>(v157, v158, v159, v77, v72);
  // pto: %li_transfer_inline5253__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v163 = pto::Stride<-1, -1, -1, -1, -1>(v158 * v161, v161, v160, v72, v77);
  // pto: %li_transfer_inline5253__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v164 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v11, v162, v163);
  // pto: %567
  int64_t v165 = (int64_t) ((uint64_t) v30 * (uint64_t) v84);
  // pto: %ori_kv_flat_inline5252__ssa_v1_view
  const int64_t v166 = 1;
  // pto: %ori_kv_flat_inline5252__ssa_v1_view
  const int64_t v167 = 1;
  // pto: %ori_kv_flat_inline5252__ssa_v1_view
  const int64_t v168 = 1;
  // pto: %ori_kv_flat_inline5252__ssa_v1_view
  int64_t v169 = v165 * v73;
  // pto: %ori_kv_flat_inline5252__ssa_v1_view
  int64_t v170 = v168 * v169;
  // pto: %ori_kv_flat_inline5252__ssa_v1_view
  pto::Shape<1, 1, 1, -1, -1> v171 = pto::Shape<1, 1, 1, -1, -1>(v166, v167, v168, v165, v73);
  // pto: %ori_kv_flat_inline5252__ssa_v1_view
  pto::Stride<-1, -1, -1, -1, -1> v172 = pto::Stride<-1, -1, -1, -1, -1>(v167 * v170, v170, v169, v73, v72);
  // pto: %ori_kv_flat_inline5252__ssa_v1_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v173 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v171, v172);
  // pto: %568
  int64_t v174 = (int64_t) ((uint64_t) v32 * (uint64_t) v84);
  // pto: %cmp_kv_flat_inline5197__ssa_v0_view
  const int64_t v175 = 1;
  // pto: %cmp_kv_flat_inline5197__ssa_v0_view
  const int64_t v176 = 1;
  // pto: %cmp_kv_flat_inline5197__ssa_v0_view
  const int64_t v177 = 1;
  // pto: %cmp_kv_flat_inline5197__ssa_v0_view
  int64_t v178 = v174 * v73;
  // pto: %cmp_kv_flat_inline5197__ssa_v0_view
  int64_t v179 = v177 * v178;
  // pto: %cmp_kv_flat_inline5197__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v180 = pto::Shape<1, 1, 1, -1, -1>(v175, v176, v177, v174, v73);
  // pto: %cmp_kv_flat_inline5197__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v181 = pto::Stride<-1, -1, -1, -1, -1>(v176 * v179, v179, v178, v73, v72);
  // pto: %cmp_kv_flat_inline5197__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v182 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v17, v180, v181);
  // pto: %sparse_bias_inline5261__rv_v2_view
  const int64_t v183 = 1;
  // pto: %sparse_bias_inline5261__rv_v2_view
  const int64_t v184 = 1;
  // pto: %sparse_bias_inline5261__rv_v2_view
  const int64_t v185 = 1;
  // pto: %sparse_bias_inline5261__rv_v2_view
  int64_t v186 = (int64_t) v27;
  // pto: %sparse_bias_inline5261__rv_v2_view
  int64_t v187 = v186 * v79;
  // pto: %sparse_bias_inline5261__rv_v2_view
  int64_t v188 = v185 * v187;
  // pto: %sparse_bias_inline5261__rv_v2_view
  pto::Shape<1, 1, 1, -1, -1> v189 = pto::Shape<1, 1, 1, -1, -1>(v183, v184, v185, v186, v79);
  // pto: %sparse_bias_inline5261__rv_v2_view
  pto::Stride<-1, -1, -1, -1, -1> v190 = pto::Stride<-1, -1, -1, -1, -1>(v184 * v188, v188, v187, v79, v72);
  // pto: %sparse_bias_inline5261__rv_v2_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v191 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v18, v189, v190);
  // pto: %softmax_copy64_inline5267__ssa_v0_view
  const int64_t v192 = 1;
  // pto: %softmax_copy64_inline5267__ssa_v0_view
  const int64_t v193 = 1;
  // pto: %softmax_copy64_inline5267__ssa_v0_view
  const int64_t v194 = 1;
  // pto: %softmax_copy64_inline5267__ssa_v0_view
  int64_t v195 = v77 * v78;
  // pto: %softmax_copy64_inline5267__ssa_v0_view
  int64_t v196 = v194 * v195;
  // pto: %softmax_copy64_inline5267__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v197 = pto::Shape<1, 1, 1, -1, -1>(v192, v193, v194, v77, v78);
  // pto: %softmax_copy64_inline5267__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v198 = pto::Stride<-1, -1, -1, -1, -1>(v193 * v196, v196, v195, v78, v72);
  // pto: %softmax_copy64_inline5267__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v199 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v19, v197, v198);
  // pto: %alpha_transfer_inline5171__ssa_v0_view
  const int64_t v200 = 1;
  // pto: %alpha_transfer_inline5171__ssa_v0_view
  const int64_t v201 = 1;
  // pto: %alpha_transfer_inline5171__ssa_v0_view
  const int64_t v202 = 1;
  // pto: %alpha_transfer_inline5171__ssa_v0_view
  int64_t v203 = v77 * v72;
  // pto: %alpha_transfer_inline5171__ssa_v0_view
  int64_t v204 = v202 * v203;
  // pto: %alpha_transfer_inline5171__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v205 = pto::Shape<1, 1, 1, -1, -1>(v200, v201, v202, v77, v72);
  // pto: %alpha_transfer_inline5171__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v206 = pto::Stride<-1, -1, -1, -1, -1>(v201 * v204, v204, v203, v72, v77);
  // pto: %alpha_transfer_inline5171__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN> v207 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::DN>(v20, v205, v206);
  // pto: %freqs_sin__ssa_v0_view
  const int64_t v208 = 1;
  // pto: %freqs_sin__ssa_v0_view
  const int64_t v209 = 1;
  // pto: %freqs_sin__ssa_v0_view
  const int64_t v210 = 1;
  // pto: %freqs_sin__ssa_v0_view
  int64_t v211 = (int64_t) v25;
  // pto: %freqs_sin__ssa_v0_view
  int64_t v212 = v211 * v78;
  // pto: %freqs_sin__ssa_v0_view
  int64_t v213 = v210 * v212;
  // pto: %freqs_sin__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v214 = pto::Shape<1, 1, 1, -1, -1>(v208, v209, v210, v211, v78);
  // pto: %freqs_sin__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v215 = pto::Stride<-1, -1, -1, -1, -1>(v209 * v213, v213, v212, v78, v72);
  // pto: %freqs_sin__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v216 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v21, v214, v215);
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v217 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v218 = 1;
  // pto: %freqs_cos__ssa_v0_view
  const int64_t v219 = 1;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v220 = (int64_t) v25;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v221 = v220 * v78;
  // pto: %freqs_cos__ssa_v0_view
  int64_t v222 = v219 * v221;
  // pto: %freqs_cos__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v223 = pto::Shape<1, 1, 1, -1, -1>(v217, v218, v219, v220, v78);
  // pto: %freqs_cos__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v224 = pto::Stride<-1, -1, -1, -1, -1>(v218 * v222, v222, v221, v78, v72);
  // pto: %freqs_cos__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v225 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v22, v223, v224);
  // pto: %heads__ssa_v0_view
  const int64_t v226 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v227 = 1;
  // pto: %heads__ssa_v0_view
  const int64_t v228 = 1;
  // pto: %heads__ssa_v0_view
  int64_t v229 = (int64_t) v25;
  // pto: %heads__ssa_v0_view
  int64_t v230 = v229 * v80;
  // pto: %heads__ssa_v0_view
  int64_t v231 = v228 * v230;
  // pto: %heads__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v232 = pto::Shape<1, 1, 1, -1, -1>(v226, v227, v228, v229, v80);
  // pto: %heads__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v233 = pto::Stride<-1, -1, -1, -1, -1>(v227 * v231, v231, v230, v80, v72);
  // pto: %heads__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v234 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v23, v232, v233);
  // pto: %left_after_inline5363__rv_v0
  Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v235 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
  // pto: %left_after_inline5363__rv_v0
  uint64_t v236 = (uint64_t) v40;
  TASSIGN(v235, v236);
  // pto: %right_after_inline5169__rv_v0
  Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v237 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
  // pto: %right_after_inline5169__rv_v0
  uint64_t v238 = (uint64_t) v41;
  TASSIGN(v237, v238);
  // pto: %qk_kv_half_inline5376__phi_v22
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v239 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5376__phi_v22
  uint64_t v240 = (uint64_t) v38;
  TASSIGN(v239, v240);
  // pto: %qk_kv_half_inline5376__phi_v3
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v241 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5376__phi_v3
  uint64_t v242 = (uint64_t) v38;
  TASSIGN(v241, v242);
  // pto: %qk_kv_half_inline5376__phi_v2
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v243 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5376__phi_v2
  uint64_t v244 = (uint64_t) v38;
  TASSIGN(v243, v244);
  // pto: %qk_kv_half_inline5376__phi_v6
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v245 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5376__phi_v6
  uint64_t v246 = (uint64_t) v38;
  TASSIGN(v245, v246);
  // pto: %qk_kv_half_inline5376__phi_v5
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v247 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5376__phi_v5
  uint64_t v248 = (uint64_t) v38;
  TASSIGN(v247, v248);
  // pto: %qk_kv_half_inline5376__phi_v9
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v249 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5376__phi_v9
  uint64_t v250 = (uint64_t) v38;
  TASSIGN(v249, v250);
  // pto: %qk_kv_half_inline5376__phi_v8
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v251 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5376__phi_v8
  uint64_t v252 = (uint64_t) v38;
  TASSIGN(v251, v252);
  // pto: %qk_kv_half_inline5376__phi_v12
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v253 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5376__phi_v12
  uint64_t v254 = (uint64_t) v38;
  TASSIGN(v253, v254);
  // pto: %qk_kv_half_inline5376__phi_v11
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5376__phi_v11
  uint64_t v256 = (uint64_t) v38;
  TASSIGN(v255, v256);
  // pto: %qk_kv_half_inline5376__phi_v15
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v257 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5376__phi_v15
  uint64_t v258 = (uint64_t) v38;
  TASSIGN(v257, v258);
  // pto: %qk_kv_half_inline5376__phi_v14
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v259 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5376__phi_v14
  uint64_t v260 = (uint64_t) v38;
  TASSIGN(v259, v260);
  // pto: %qk_kv_half_inline5376__phi_v21
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v261 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5376__phi_v21
  uint64_t v262 = (uint64_t) v38;
  TASSIGN(v261, v262);
  // pto: %qk_kv_half_inline5376__phi_v20
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v263 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5376__phi_v20
  uint64_t v264 = (uint64_t) v38;
  TASSIGN(v263, v264);
  // pto: %qk_kv_half_inline5376__phi_v19
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v265 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %qk_kv_half_inline5376__phi_v19
  uint64_t v266 = (uint64_t) v38;
  TASSIGN(v265, v266);
  // pto: %prefetch_kv_half_inline5396__phi_v21
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v267 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_inline5396__phi_v21
  uint64_t v268 = (uint64_t) v38;
  TASSIGN(v267, v268);
  // pto: %prefetch_kv_half_inline5396__phi_v20
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_inline5396__phi_v20
  uint64_t v270 = (uint64_t) v38;
  TASSIGN(v269, v270);
  // pto: %prefetch_kv_half_inline5396__phi_v19
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v271 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_inline5396__phi_v19
  uint64_t v272 = (uint64_t) v38;
  TASSIGN(v271, v272);
  // pto: %sm_scores_inline5409__phi_v2
  Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v273 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
  // pto: %sm_scores_inline5409__phi_v2
  uint64_t v274 = (uint64_t) v38;
  TASSIGN(v273, v274);
  // pto: %sm_block_sum_inline5421__phi_v4
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v275 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
  // pto: %sm_block_sum_inline5421__phi_v4
  uint64_t v276 = (uint64_t) v48;
  TASSIGN(v275, v276);
  // pto: %sm_block_sum_inline5421__phi_v3
  Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
  // pto: %sm_block_sum_inline5421__phi_v3
  uint64_t v278 = (uint64_t) v48;
  TASSIGN(v277, v278);
  // pto: %sm_fold64_inline5423__phi_v4
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5423__phi_v4
  uint64_t v280 = (uint64_t) v52;
  TASSIGN(v279, v280);
  // pto: %sm_fold64_inline5423__phi_v3
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v281 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5423__phi_v3
  uint64_t v282 = (uint64_t) v52;
  TASSIGN(v281, v282);
  // pto: %sm_fold64_inline5423__phi_v8
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v283 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5423__phi_v8
  uint64_t v284 = (uint64_t) v49;
  TASSIGN(v283, v284);
  // pto: %sm_fold64_inline5423__phi_v7
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5423__phi_v7
  uint64_t v286 = (uint64_t) v49;
  TASSIGN(v285, v286);
  // pto: %sm_fold64_inline5423__phi_v12
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v287 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5423__phi_v12
  uint64_t v288 = (uint64_t) v52;
  TASSIGN(v287, v288);
  // pto: %sm_fold64_inline5423__phi_v11
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v289 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5423__phi_v11
  uint64_t v290 = (uint64_t) v52;
  TASSIGN(v289, v290);
  // pto: %sm_fold64_inline5423__phi_v16
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v291 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5423__phi_v16
  uint64_t v292 = (uint64_t) v49;
  TASSIGN(v291, v292);
  // pto: %sm_fold64_inline5423__phi_v15
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v293 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5423__phi_v15
  uint64_t v294 = (uint64_t) v49;
  TASSIGN(v293, v294);
  // pto: %sm_fold64_inline5423__phi_v20
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v295 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5423__phi_v20
  uint64_t v296 = (uint64_t) v52;
  TASSIGN(v295, v296);
  // pto: %sm_fold64_inline5423__phi_v19
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v297 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5423__phi_v19
  uint64_t v298 = (uint64_t) v52;
  TASSIGN(v297, v298);
  // pto: %sm_fold64_inline5423__phi_v24
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v299 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5423__phi_v24
  uint64_t v300 = (uint64_t) v49;
  TASSIGN(v299, v300);
  // pto: %sm_fold64_inline5423__phi_v23
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v301 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5423__phi_v23
  uint64_t v302 = (uint64_t) v49;
  TASSIGN(v301, v302);
  // pto: %sm_fold64_inline5423__phi_v28
  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v303 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
  // pto: %sm_fold64_inline5423__phi_v28
  uint64_t v304 = (uint64_t) v43;
  TASSIGN(v303, v304);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v3
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v305 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v3
  uint64_t v306 = (uint64_t) v38;
  TASSIGN(v305, v306);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v2
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v307 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v2
  uint64_t v308 = (uint64_t) v38;
  TASSIGN(v307, v308);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v6
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v309 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v6
  uint64_t v310 = (uint64_t) v38;
  TASSIGN(v309, v310);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v5
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v311 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v5
  uint64_t v312 = (uint64_t) v38;
  TASSIGN(v311, v312);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v9
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v313 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v9
  uint64_t v314 = (uint64_t) v38;
  TASSIGN(v313, v314);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v8
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v8
  uint64_t v316 = (uint64_t) v38;
  TASSIGN(v315, v316);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v12
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v317 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v12
  uint64_t v318 = (uint64_t) v38;
  TASSIGN(v317, v318);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v11
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v319 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v11
  uint64_t v320 = (uint64_t) v38;
  TASSIGN(v319, v320);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v15
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v321 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v15
  uint64_t v322 = (uint64_t) v38;
  TASSIGN(v321, v322);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v14
  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v323 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
  // pto: %prefetch_kv_half_v1_inline5431__phi_v14
  uint64_t v324 = (uint64_t) v38;
  TASSIGN(v323, v324);
  // pto: %qk_core_inline5174__ssa_v0
  int64_t v325 = (int64_t) v33;
  uint64_t v326 = reinterpret_cast<uint64_t>(v1);
  set_ffts_base_addr(v326);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v327 = v325; v327 < v24; v327 += v82) {
    // pto: %t__tile
    ;
    int32_t v328 = (v2)[v327];
    // pto: %3
    ;
    int64_t v329 = (int64_t) v328;
    // pto: %4
    ;
    int64_t v330 = v329 < v83 ? v83 : v329;
    // pto: %qk_aiv_inline5343__ssa_v0
    ;
    int64_t v331 = (int64_t) v35;
    uint64_t v332 = reinterpret_cast<uint64_t>(v1);
    set_ffts_base_addr(v332);
    // pto: %14
    ;
    int64_t v333 = (int64_t) ((uint64_t) v331 * (uint64_t) v84);
    // pto: %15
    ;
    int64_t v334 = (int64_t) ((uint64_t) v331 * (uint64_t) v78);
    // pto: %qk_reduce_tmp_inline5415__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v335 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
    // pto: %qk_reduce_tmp_inline5415__ssa_v0
    ;
    uint64_t v336 = (uint64_t) v37;
    TASSIGN(v335, v336);
    // pto: %running_m_inline5346__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v337 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v72);
    // pto: %running_m_inline5346__ssa_v0
    ;
    uint64_t v338 = (uint64_t) v38;
    TASSIGN(v337, v338);
    // pto: %16
    ;
    int64_t v339 = v333 < v83 ? v83 : v333;
    // pto: %attn_sink_col_inline5179__ssa_v0_pview
    ;
    __gm__ float* v340 = PTOAS__GLOBAL_TENSOR_DATA(v148);
    // pto: %attn_sink_col_inline5179__ssa_v0_pview
    ;
    const int64_t v341 = 0;
    // pto: %attn_sink_col_inline5179__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 1> v342 = pto::Shape<1, 1, 1, 32, 1>();
    // pto: %attn_sink_col_inline5179__ssa_v0_pview
    ;
    pto::Stride<32, 32, 32, 1, 64> v343 = pto::Stride<32, 32, 32, 1, 64>();
    // pto: %attn_sink_col_inline5179__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 64>, pto::Layout::DN> v344 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 64>, pto::Layout::DN>(v340 + (v341 + v339), v342, v343);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    TLOAD(v337, v344);
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %t__rm_a0_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v345 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v84);
    // pto: %t__rm_a0_tmp_v0
    ;
    uint64_t v346 = (uint64_t) v38;
    TASSIGN(v345, v346);
    // pto: %t__row_major_tmp_v1
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v347 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v84);
    // pto: %t__row_major_tmp_v1
    ;
    uint64_t v348 = (uint64_t) v39;
    TASSIGN(v347, v348);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    TMULS(v347, v345, v86);
    // pto: %t__tmp_v939
    ;
    Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v349 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v72);
    // pto: %t__tmp_v939
    ;
    uint64_t v350 = (uint64_t) v39;
    TASSIGN(v349, v350);
    // pto: %running_l_inline5349__rm_a0_tmp_v2
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v351 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v84);
    // pto: %running_l_inline5349__rm_a0_tmp_v2
    ;
    uint64_t v352 = (uint64_t) v39;
    TASSIGN(v351, v352);
    // pto: %running_l_inline5349__row_major_tmp_v3
    ;
    Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v353 = Tile<TileType::Vec, float, 1, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v84);
    // pto: %running_l_inline5349__row_major_tmp_v3
    ;
    uint64_t v354 = (uint64_t) v39;
    TASSIGN(v353, v354);
    pipe_barrier(PIPE_V);
    TADDS(v353, v351, v87);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %running_l_inline5349__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v355 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v72);
    // pto: %running_l_inline5349__ssa_v0
    ;
    uint64_t v356 = (uint64_t) v39;
    TASSIGN(v355, v356);
    // pto: %running_left_inline5354__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v357 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
    // pto: %running_left_inline5354__ssa_v0
    ;
    uint64_t v358 = (uint64_t) v40;
    TASSIGN(v357, v358);
    TEXPANDS(v357, v86);
    // pto: %running_right_inline5368__ssa_v0
    ;
    Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v359 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
    // pto: %running_right_inline5368__ssa_v0
    ;
    uint64_t v360 = (uint64_t) v41;
    TASSIGN(v359, v360);
    TEXPANDS(v359, v86);
    // pto: %1, %17
    ;
    int64_t v361 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v325 * (uint64_t) v78) + (uint64_t) v333);
    // pto: %18
    ;
    int64_t v362 = v361 < v83 ? v83 : v361;
    // pto: %mi_transfer_inline5181__ssa_v0_pview
    ;
    __gm__ float* v363 = PTOAS__GLOBAL_TENSOR_DATA(v156);
    // pto: %mi_transfer_inline5181__ssa_v0_pview
    ;
    const int64_t v364 = 0;
    // pto: %mi_transfer_inline5181__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 1> v365 = pto::Shape<1, 1, 1, 32, 1>();
    // pto: %mi_transfer_inline5181__ssa_v0_pview
    ;
    pto::Stride<32, 32, 32, 1, 1536> v366 = pto::Stride<32, 32, 32, 1, 1536>();
    // pto: %mi_transfer_inline5181__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN> v367 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN>(v363 + (v364 + v362), v365, v366);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    TSTORE(v367, v337);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    // pto: %li_transfer_inline5253__ssa_v0_pview
    ;
    __gm__ float* v368 = PTOAS__GLOBAL_TENSOR_DATA(v164);
    // pto: %li_transfer_inline5253__ssa_v0_pview
    ;
    const int64_t v369 = 0;
    // pto: %li_transfer_inline5253__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 32, 1> v370 = pto::Shape<1, 1, 1, 32, 1>();
    // pto: %li_transfer_inline5253__ssa_v0_pview
    ;
    pto::Stride<32, 32, 32, 1, 1536> v371 = pto::Stride<32, 32, 32, 1, 1536>();
    // pto: %li_transfer_inline5253__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN> v372 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN>(v368 + (v369 + v362), v370, v371);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v372, v355);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    for (int64_t v373 = v83; v373 < v89; v373 += v72) {
      // pto: %22
      ;
      int64_t v374 = (int64_t) ((uint64_t) v327 * (uint64_t) v74);
      // pto: %23, %21
      ;
      int32_t v375 = (v4)[(int64_t) ((uint64_t) v374 + (uint64_t) v373)];
      // pto: %24, %25
      ;
      if ((int64_t) v375 > v83) {
        // pto: %26, %27, %28, %29
        ;
        int64_t v376 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) ((uint64_t) v327 - (uint64_t) v325) / v82) * (uint64_t) v89) + (uint64_t) v373);
        // pto: %30
        ;
        int64_t v377 = (int64_t) ((uint64_t) v325 * (uint64_t) v89);
        // pto: %31
        ;
        int64_t v378 = v376 % v89;
        // pto: %32, %33, %34
        ;
        int64_t v379 = v378 < v83 ? (int64_t) ((uint64_t) v378 + (uint64_t) v89) : v378;
        // pto: %38
        ;
        bool v380 = v373 > v83;
        // pto: %previous_valid_inline5369__phi_v4
        ;
        int32_t v381;
        if (v380) {
          // pto: %41, %39, %previous_valid_inline5369__tile
          ;
          int32_t v382 = (v4)[(int64_t) ((uint64_t) v374 + (uint64_t) ((int64_t) (uint64_t) v373 - (uint64_t) v72))];
          v381 = v382;
        } else {
          // pto: %42, %43
          ;
          // pto: %previous_valid_inline5369__phi_v3
          ;
          int32_t v383;
          if ((int64_t) ((uint64_t) v325 + (uint64_t) v82) <= v327) {
            // pto: %45, %46, %47, %44
            ;
            int32_t v384 = (v4)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v327 - (uint64_t) v82) * (uint64_t) v74) + (uint64_t) v72)];
            v383 = v384;
          } else {
            v383 = v99;
          };
          v381 = v383;
        };
        // pto: %48
        ;
        int64_t v385 = (int64_t) v381;
        // pto: %49
        ;
        if (v385 <= v83) {
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
          for (int64_t v386 = v83; v386 < v90; v386 += v72) {
            // pto: %51
            ;
            bool v387 = v386 == v83;
            // pto: %52
            ;
            if (v380 | v387) {
              // pto: %53, %54
              ;
              int64_t v388 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v386 * (uint64_t) v81) + (uint64_t) v334);
              // pto: %0
              ;
              Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v389 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
              // pto: %0
              ;
              uint64_t v390 = (uint64_t) v38;
              TASSIGN(v389, v390);
              wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
              pipe_barrier(PIPE_V);
              TEXPANDS(v389, v91);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
              set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
              // pto: %55
              ;
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
              if (v373 == v83) {
                // pto: %56
                ;
                int64_t v391 = (v12)[v327];
                // pto: %60
                ;
                int64_t v392 = (int64_t) ((uint64_t) v391 + (uint64_t) v72);
                // pto: %61
                ;
                int64_t v393 = v392 < v81 ? v392 : v81;
                // pto: %62, %63
                ;
                int64_t v394 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v391 - (uint64_t) v393) + (uint64_t) v72);
                // pto: %64
                ;
                int64_t v395 = v394 % v84;
                // pto: %65, %66, %67
                ;
                int64_t v396 = v395 < v83 ? (int64_t) ((uint64_t) v395 + (uint64_t) v84) : v395;
                // pto: %68
                ;
                int64_t v397 = (int64_t) ((uint64_t) v393 - (uint64_t) v388);
                // pto: %69
                ;
                int64_t v398 = v397 < v83 ? v83 : v397;
                // pto: %70
                ;
                int64_t v399 = v398 < v78 ? v398 : v78;
                // pto: %71, %72
                ;
                int64_t v400 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v84 - (uint64_t) v396) - (uint64_t) v388);
                // pto: %73
                ;
                int64_t v401 = v400 < v399 ? v400 : v399;
                // pto: %74
                ;
                if (v401 > v83) {
                  // pto: %75
                  ;
                  int64_t v402 = (int64_t) ((uint64_t) v394 + (uint64_t) v388);
                  // pto: %78, %79, %77, %qk_raw_page_inline5281__tile
                  ;
                  int32_t v403 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v330 * (uint64_t) v29) + (uint64_t) (v402 / v84))];
                  // pto: %80
                  ;
                  int64_t v404 = (int64_t) v403;
                  // pto: %81
                  ;
                  if (v404 >= v83) {
                    // pto: %84
                    ;
                    int64_t v405 = v402 % v84;
                    // pto: %85, %86, %87
                    ;
                    int64_t v406 = v405 < v83 ? (int64_t) ((uint64_t) v405 + (uint64_t) v84) : v405;
                    // pto: %83, %88
                    ;
                    int64_t v407 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v404 * (uint64_t) v84) + (uint64_t) v406);
                    // pto: %gather_row_view
                    ;
                    Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v408 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v401);
                    // pto: %gather_row_view
                    ;
                    uint64_t v409 = (uint64_t) v38;
                    TASSIGN(v408, v409);
                    // pto: %90
                    ;
                    int64_t v410 = v407 < v83 ? v83 : v407;
                    // pto: %ori_kv_flat_inline5252__ssa_v1_pview
                    ;
                    const int64_t v411 = 0;
                    // pto: %ori_kv_flat_inline5252__ssa_v1_pview
                    ;
                    __gm__ bfloat16_t* v412 = PTOAS__GLOBAL_TENSOR_DATA(v173);
                    // pto: %ori_kv_flat_inline5252__ssa_v1_pview
                    ;
                    const int64_t v413 = 1;
                    // pto: %ori_kv_flat_inline5252__ssa_v1_pview
                    ;
                    const int64_t v414 = 1;
                    // pto: %ori_kv_flat_inline5252__ssa_v1_pview
                    ;
                    const int64_t v415 = 1;
                    // pto: %ori_kv_flat_inline5252__ssa_v1_pview
                    ;
                    int64_t v416 = v401 * v73;
                    // pto: %ori_kv_flat_inline5252__ssa_v1_pview
                    ;
                    int64_t v417 = v415 * v416;
                    // pto: %ori_kv_flat_inline5252__ssa_v1_pview
                    ;
                    pto::Shape<1, 1, 1, -1, 512> v418 = pto::Shape<1, 1, 1, -1, 512>(v413, v414, v415, v401, v73);
                    // pto: %ori_kv_flat_inline5252__ssa_v1_pview
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v419 = pto::Stride<-1, -1, -1, -1, -1>(v414 * v417, v417, v416, v73, v72);
                    // pto: %ori_kv_flat_inline5252__ssa_v1_pview
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v420 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v412 + (v411 + v410 * v73 + v83 * v72), v418, v419);
                    TLOAD(v408, v420);
                  };
                };
                // pto: %93
                ;
                int64_t v421 = v400 < v83 ? v83 : v400;
                // pto: %94, %95
                ;
                int64_t v422 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v78 - (uint64_t) v396) - (uint64_t) v388);
                // pto: %96
                ;
                int64_t v423 = v422 < v399 ? v422 : v399;
                // pto: %97
                ;
                if (v421 < v423) {
                  // pto: %98, %99
                  ;
                  int64_t v424 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v394 + (uint64_t) v388) + (uint64_t) v421);
                  // pto: %102, %103, %101, %100
                  ;
                  int32_t v425 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v330 * (uint64_t) v29) + (uint64_t) (v424 / v84))];
                  // pto: %104
                  ;
                  int64_t v426 = (int64_t) v425;
                  // pto: %105
                  ;
                  if (v426 >= v83) {
                    // pto: %108
                    ;
                    int64_t v427 = v424 % v84;
                    // pto: %109, %110, %111
                    ;
                    int64_t v428 = v427 < v83 ? (int64_t) ((uint64_t) v427 + (uint64_t) v84) : v427;
                    // pto: %107, %112
                    ;
                    int64_t v429 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v426 * (uint64_t) v84) + (uint64_t) v428);
                    // pto: %113
                    ;
                    int64_t v430 = (int64_t) ((uint64_t) v423 - (uint64_t) v421);
                    // pto: %114
                    ;
                    Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v431 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v430);
                    // pto: %114
                    ;
                    uint64_t v432 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v421 * (uint64_t) v36) + (uint64_t) v38);
                    TASSIGN(v431, v432);
                    // pto: %115
                    ;
                    int64_t v433 = v429 < v83 ? v83 : v429;
                    // pto: %116
                    ;
                    const int64_t v434 = 0;
                    // pto: %116
                    ;
                    __gm__ bfloat16_t* v435 = PTOAS__GLOBAL_TENSOR_DATA(v173);
                    // pto: %116
                    ;
                    const int64_t v436 = 1;
                    // pto: %116
                    ;
                    const int64_t v437 = 1;
                    // pto: %116
                    ;
                    const int64_t v438 = 1;
                    // pto: %116
                    ;
                    int64_t v439 = v430 * v73;
                    // pto: %116
                    ;
                    int64_t v440 = v438 * v439;
                    // pto: %116
                    ;
                    pto::Shape<1, 1, 1, -1, 512> v441 = pto::Shape<1, 1, 1, -1, 512>(v436, v437, v438, v430, v73);
                    // pto: %116
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v442 = pto::Stride<-1, -1, -1, -1, -1>(v437 * v440, v440, v439, v73, v72);
                    // pto: %116
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v443 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v435 + (v434 + v433 * v73 + v83 * v72), v441, v442);
                    TLOAD(v431, v443);
                  };
                };
                // pto: %119
                ;
                int64_t v444 = v422 < v83 ? v83 : v422;
                // pto: %120, %121
                ;
                int64_t v445 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v92 - (uint64_t) v396) - (uint64_t) v388);
                // pto: %122
                ;
                int64_t v446 = v445 < v399 ? v445 : v399;
                // pto: %123
                ;
                if (v444 < v446) {
                  // pto: %124, %125
                  ;
                  int64_t v447 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v394 + (uint64_t) v388) + (uint64_t) v444);
                  // pto: %128, %129, %127, %126
                  ;
                  int32_t v448 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v330 * (uint64_t) v29) + (uint64_t) (v447 / v84))];
                  // pto: %130
                  ;
                  int64_t v449 = (int64_t) v448;
                  // pto: %131
                  ;
                  if (v449 >= v83) {
                    // pto: %134
                    ;
                    int64_t v450 = v447 % v84;
                    // pto: %135, %136, %137
                    ;
                    int64_t v451 = v450 < v83 ? (int64_t) ((uint64_t) v450 + (uint64_t) v84) : v450;
                    // pto: %133, %138
                    ;
                    int64_t v452 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v449 * (uint64_t) v84) + (uint64_t) v451);
                    // pto: %139
                    ;
                    int64_t v453 = (int64_t) ((uint64_t) v446 - (uint64_t) v444);
                    // pto: %140
                    ;
                    Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v454 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v453);
                    // pto: %140
                    ;
                    uint64_t v455 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v444 * (uint64_t) v36) + (uint64_t) v38);
                    TASSIGN(v454, v455);
                    // pto: %141
                    ;
                    int64_t v456 = v452 < v83 ? v83 : v452;
                    // pto: %142
                    ;
                    const int64_t v457 = 0;
                    // pto: %142
                    ;
                    __gm__ bfloat16_t* v458 = PTOAS__GLOBAL_TENSOR_DATA(v173);
                    // pto: %142
                    ;
                    const int64_t v459 = 1;
                    // pto: %142
                    ;
                    const int64_t v460 = 1;
                    // pto: %142
                    ;
                    const int64_t v461 = 1;
                    // pto: %142
                    ;
                    int64_t v462 = v453 * v73;
                    // pto: %142
                    ;
                    int64_t v463 = v461 * v462;
                    // pto: %142
                    ;
                    pto::Shape<1, 1, 1, -1, 512> v464 = pto::Shape<1, 1, 1, -1, 512>(v459, v460, v461, v453, v73);
                    // pto: %142
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v465 = pto::Stride<-1, -1, -1, -1, -1>(v460 * v463, v463, v462, v73, v72);
                    // pto: %142
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v466 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v458 + (v457 + v456 * v73 + v83 * v72), v464, v465);
                    TLOAD(v454, v466);
                  };
                };
                // pto: %145
                ;
                int64_t v467 = v445 < v83 ? v83 : v445;
                // pto: %146, %147
                ;
                int64_t v468 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v81 - (uint64_t) v396) - (uint64_t) v388);
                // pto: %148
                ;
                int64_t v469 = v468 < v399 ? v468 : v399;
                // pto: %149
                ;
                if (v467 < v469) {
                  // pto: %150, %151
                  ;
                  int64_t v470 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v394 + (uint64_t) v388) + (uint64_t) v467);
                  // pto: %154, %155, %153, %152
                  ;
                  int32_t v471 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v330 * (uint64_t) v29) + (uint64_t) (v470 / v84))];
                  // pto: %156
                  ;
                  int64_t v472 = (int64_t) v471;
                  // pto: %157
                  ;
                  if (v472 >= v83) {
                    // pto: %160
                    ;
                    int64_t v473 = v470 % v84;
                    // pto: %161, %162, %163
                    ;
                    int64_t v474 = v473 < v83 ? (int64_t) ((uint64_t) v473 + (uint64_t) v84) : v473;
                    // pto: %159, %164
                    ;
                    int64_t v475 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v472 * (uint64_t) v84) + (uint64_t) v474);
                    // pto: %165
                    ;
                    int64_t v476 = (int64_t) ((uint64_t) v469 - (uint64_t) v467);
                    // pto: %166
                    ;
                    Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v477 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v476);
                    // pto: %166
                    ;
                    uint64_t v478 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v467 * (uint64_t) v36) + (uint64_t) v38);
                    TASSIGN(v477, v478);
                    // pto: %167
                    ;
                    int64_t v479 = v475 < v83 ? v83 : v475;
                    // pto: %168
                    ;
                    const int64_t v480 = 0;
                    // pto: %168
                    ;
                    __gm__ bfloat16_t* v481 = PTOAS__GLOBAL_TENSOR_DATA(v173);
                    // pto: %168
                    ;
                    const int64_t v482 = 1;
                    // pto: %168
                    ;
                    const int64_t v483 = 1;
                    // pto: %168
                    ;
                    const int64_t v484 = 1;
                    // pto: %168
                    ;
                    int64_t v485 = v476 * v73;
                    // pto: %168
                    ;
                    int64_t v486 = v484 * v485;
                    // pto: %168
                    ;
                    pto::Shape<1, 1, 1, -1, 512> v487 = pto::Shape<1, 1, 1, -1, 512>(v482, v483, v484, v476, v73);
                    // pto: %168
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v488 = pto::Stride<-1, -1, -1, -1, -1>(v483 * v486, v486, v485, v73, v72);
                    // pto: %168
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v489 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v481 + (v480 + v479 * v73 + v83 * v72), v487, v488);
                    TLOAD(v477, v489);
                  };
                };
                // pto: %171
                ;
                int64_t v490 = v468 < v83 ? v83 : v468;
                // pto: %172, %173
                ;
                int64_t v491 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v93 - (uint64_t) v396) - (uint64_t) v388);
                // pto: %174
                ;
                int64_t v492 = v491 < v399 ? v491 : v399;
                // pto: %175
                ;
                if (v490 < v492) {
                  // pto: %176, %177
                  ;
                  int64_t v493 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v394 + (uint64_t) v388) + (uint64_t) v490);
                  // pto: %180, %181, %179, %178
                  ;
                  int32_t v494 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v330 * (uint64_t) v29) + (uint64_t) (v493 / v84))];
                  // pto: %182
                  ;
                  int64_t v495 = (int64_t) v494;
                  // pto: %183
                  ;
                  if (v495 >= v83) {
                    // pto: %186
                    ;
                    int64_t v496 = v493 % v84;
                    // pto: %187, %188, %189
                    ;
                    int64_t v497 = v496 < v83 ? (int64_t) ((uint64_t) v496 + (uint64_t) v84) : v496;
                    // pto: %185, %190
                    ;
                    int64_t v498 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v495 * (uint64_t) v84) + (uint64_t) v497);
                    // pto: %191
                    ;
                    int64_t v499 = (int64_t) ((uint64_t) v492 - (uint64_t) v490);
                    // pto: %192
                    ;
                    Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v500 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v499);
                    // pto: %192
                    ;
                    uint64_t v501 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v490 * (uint64_t) v36) + (uint64_t) v38);
                    TASSIGN(v500, v501);
                    // pto: %193
                    ;
                    int64_t v502 = v498 < v83 ? v83 : v498;
                    // pto: %194
                    ;
                    const int64_t v503 = 0;
                    // pto: %194
                    ;
                    __gm__ bfloat16_t* v504 = PTOAS__GLOBAL_TENSOR_DATA(v173);
                    // pto: %194
                    ;
                    const int64_t v505 = 1;
                    // pto: %194
                    ;
                    const int64_t v506 = 1;
                    // pto: %194
                    ;
                    const int64_t v507 = 1;
                    // pto: %194
                    ;
                    int64_t v508 = v499 * v73;
                    // pto: %194
                    ;
                    int64_t v509 = v507 * v508;
                    // pto: %194
                    ;
                    pto::Shape<1, 1, 1, -1, 512> v510 = pto::Shape<1, 1, 1, -1, 512>(v505, v506, v507, v499, v73);
                    // pto: %194
                    ;
                    pto::Stride<-1, -1, -1, -1, -1> v511 = pto::Stride<-1, -1, -1, -1, -1>(v506 * v509, v509, v508, v73, v72);
                    // pto: %194
                    ;
                    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v512 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v504 + (v503 + v502 * v73 + v83 * v72), v510, v511);
                    TLOAD(v500, v512);
                  };
                };
              } else {
                pipe_barrier(PIPE_V);
                TEXPANDS(v389, v91);
                set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
                wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
                for (int64_t v513 = v83; v513 < v78; v513 += v72) {
                  // pto: %195, %196, %197, %198
                  ;
                  int64_t v514 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v373 - (uint64_t) v72) * (uint64_t) v73) + (uint64_t) v388) + (uint64_t) v513);
                  // pto: %199
                  ;
                  if (v514 < v73) {
                    // pto: %200, %201, %qk_ridx_inline5383__tile
                    ;
                    int32_t v515 = (v15)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v327 * (uint64_t) v73) + (uint64_t) v514)];
                    // pto: %202
                    ;
                    int64_t v516 = (int64_t) v515;
                    // pto: %203
                    ;
                    if (v516 >= v83) {
                      // pto: %207, %208, %206, %204
                      ;
                      int32_t v517 = (v16)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v330 * (uint64_t) v31) + (uint64_t) (v516 / v84))];
                      // pto: %209
                      ;
                      int64_t v518 = (int64_t) v517;
                      // pto: %210
                      ;
                      if (v518 >= v83) {
                        // pto: %213
                        ;
                        int64_t v519 = v516 % v84;
                        // pto: %214, %215, %216
                        ;
                        int64_t v520 = v519 < v83 ? (int64_t) ((uint64_t) v519 + (uint64_t) v84) : v519;
                        // pto: %211, %217
                        ;
                        int64_t v521 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v518 * (uint64_t) v84) + (uint64_t) v520);
                        // pto: %218
                        ;
                        Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v522;
                        // pto: %218
                        ;
                        uint64_t v523 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v513 * (uint64_t) v36) + (uint64_t) v38);
                        TASSIGN(v522, v523);
                        // pto: %219
                        ;
                        int64_t v524 = v521 < v83 ? v83 : v521;
                        // pto: %cmp_kv_flat_inline5197__ssa_v0_pview
                        ;
                        __gm__ bfloat16_t* v525 = PTOAS__GLOBAL_TENSOR_DATA(v182);
                        // pto: %cmp_kv_flat_inline5197__ssa_v0_pview
                        ;
                        const int64_t v526 = 0;
                        // pto: %cmp_kv_flat_inline5197__ssa_v0_pview
                        ;
                        const int64_t v527 = 512;
                        // pto: %cmp_kv_flat_inline5197__ssa_v0_pview
                        ;
                        pto::Shape<1, 1, 1, 1, 512> v528 = pto::Shape<1, 1, 1, 1, 512>();
                        // pto: %cmp_kv_flat_inline5197__ssa_v0_pview
                        ;
                        pto::Stride<512, 512, 512, 512, 1> v529 = pto::Stride<512, 512, 512, 512, 1>();
                        // pto: %cmp_kv_flat_inline5197__ssa_v0_pview
                        ;
                        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v530 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v525 + (v526 + v524 * v527), v528, v529);
                        TLOAD(v522, v530);
                      };
                    };
                  };
                };
              };
              set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID5);
              set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID4);
              set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
              set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
              set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
              set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
              set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID6);
              // pto: %35, %36, %220
              ;
              int64_t v531 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v377 + (uint64_t) v379) * (uint64_t) v73) + (uint64_t) v388);
              // pto: %221
              ;
              int64_t v532 = v531 < v83 ? v83 : v531;
              // pto: %kv_transfer_inline5176__ssa_v0_pview
              ;
              __gm__ bfloat16_t* v533 = PTOAS__GLOBAL_TENSOR_DATA(v116);
              // pto: %kv_transfer_inline5176__ssa_v0_pview
              ;
              const int64_t v534 = 0;
              // pto: %kv_transfer_inline5176__ssa_v0_pview
              ;
              const int64_t v535 = 512;
              // pto: %kv_transfer_inline5176__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 64, 512> v536 = pto::Shape<1, 1, 1, 64, 512>();
              // pto: %kv_transfer_inline5176__ssa_v0_pview
              ;
              pto::Stride<32768, 32768, 32768, 512, 1> v537 = pto::Stride<32768, 32768, 32768, 512, 1>();
              // pto: %kv_transfer_inline5176__ssa_v0_pview
              ;
              GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v538 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v533 + (v534 + v532 * v535), v536, v537);
              wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
              wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
              wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
              wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID4);
              wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID5);
              wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID6);
              wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
              wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
              TSTORE(v538, v239);
              set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
              if (v387) {
                uint16_t v539 = getFFTSMsg(FFTS_MODE_VAL, v83);
                ffts_cross_core_sync(PIPE_MTE3, v539);
              } else {
                // pto: %223
                ;
                if (v386 == v72) {
                  uint16_t v540 = getFFTSMsg(FFTS_MODE_VAL, v90);
                  ffts_cross_core_sync(PIPE_MTE3, v540);
                } else {
                  // pto: %224
                  ;
                  if (v386 == v89) {
                    uint16_t v541 = getFFTSMsg(FFTS_MODE_VAL, v94);
                    ffts_cross_core_sync(PIPE_MTE3, v541);
                  } else {
                    uint16_t v542 = getFFTSMsg(FFTS_MODE_VAL, v95);
                    ffts_cross_core_sync(PIPE_MTE3, v542);
                  };
                };
              };
            };
          };
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
        };
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
        int32_t v543 = (int32_t) v72;
        wait_flag_dev(v543);
        // pto: %225
        ;
        bool v544 = v373 == v83;
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
        if (v544) {
          // pto: %226
          ;
          int64_t v545 = (int64_t) ((uint64_t) v373 + (uint64_t) v72);
          // pto: %227
          ;
          if (v327 < v24) {
            // pto: %230, %228
            ;
            int32_t v546 = (v4)[(int64_t) ((uint64_t) v374 + (uint64_t) v545)];
            // pto: %231, %232
            ;
            if ((int64_t) v546 > v83) {
              // pto: %233
              ;
              int32_t v547 = (v2)[v327];
              // pto: %234
              ;
              int64_t v548 = (int64_t) v547;
              // pto: %235
              ;
              int64_t v549 = v548 < v83 ? v83 : v548;
              // pto: %237, %238
              ;
              int64_t v550 = (int64_t) ((uint64_t) v376 + (uint64_t) v72) % v89;
              // pto: %239, %240, %241
              ;
              int64_t v551 = v550 < v83 ? (int64_t) ((uint64_t) v550 + (uint64_t) v89) : v550;
              set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
              for (int64_t v552 = v83; v552 < v90; v552 += v72) {
                // pto: %245
                ;
                bool v553 = v552 == v83;
                // pto: %244, %246
                ;
                if (v545 > v83 | v553) {
                  // pto: %247, %248
                  ;
                  int64_t v554 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v552 * (uint64_t) v81) + (uint64_t) v334);
                  // pto: %prefetch_kv_half_inline5396__ssa_v0
                  ;
                  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v555 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %prefetch_kv_half_inline5396__ssa_v0
                  ;
                  uint64_t v556 = (uint64_t) v38;
                  TASSIGN(v555, v556);
                  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
                  pipe_barrier(PIPE_V);
                  TEXPANDS(v555, v91);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                  for (int64_t v557 = v83; v557 < v78; v557 += v72) {
                    // pto: %250, %251, %252
                    ;
                    int64_t v558 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v373 * (uint64_t) v73) + (uint64_t) v554) + (uint64_t) v557);
                    // pto: %253
                    ;
                    if (v558 < v73) {
                      // pto: %254, %255, %prefetch_ridx_inline5227__tile
                      ;
                      int32_t v559 = (v15)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v327 * (uint64_t) v73) + (uint64_t) v558)];
                      // pto: %256
                      ;
                      int64_t v560 = (int64_t) v559;
                      // pto: %257
                      ;
                      if (v560 >= v83) {
                        // pto: %261, %262, %260, %258
                        ;
                        int32_t v561 = (v16)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v549 * (uint64_t) v31) + (uint64_t) (v560 / v84))];
                        // pto: %263
                        ;
                        int64_t v562 = (int64_t) v561;
                        // pto: %264
                        ;
                        if (v562 >= v83) {
                          // pto: %267
                          ;
                          int64_t v563 = v560 % v84;
                          // pto: %268, %269, %270
                          ;
                          int64_t v564 = v563 < v83 ? (int64_t) ((uint64_t) v563 + (uint64_t) v84) : v563;
                          // pto: %265, %271
                          ;
                          int64_t v565 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v562 * (uint64_t) v84) + (uint64_t) v564);
                          // pto: %272
                          ;
                          Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v566;
                          // pto: %272
                          ;
                          uint64_t v567 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v557 * (uint64_t) v36) + (uint64_t) v38);
                          TASSIGN(v566, v567);
                          // pto: %273
                          ;
                          int64_t v568 = v565 < v83 ? v83 : v565;
                          // pto: %274
                          ;
                          __gm__ bfloat16_t* v569 = PTOAS__GLOBAL_TENSOR_DATA(v182);
                          // pto: %274
                          ;
                          const int64_t v570 = 0;
                          // pto: %274
                          ;
                          const int64_t v571 = 512;
                          // pto: %274
                          ;
                          pto::Shape<1, 1, 1, 1, 512> v572 = pto::Shape<1, 1, 1, 1, 512>();
                          // pto: %274
                          ;
                          pto::Stride<512, 512, 512, 512, 1> v573 = pto::Stride<512, 512, 512, 512, 1>();
                          // pto: %274
                          ;
                          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND> v574 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<512, 512, 512, 512, 1>, pto::Layout::ND>(v569 + (v570 + v568 * v571), v572, v573);
                          TLOAD(v566, v574);
                        };
                      };
                    };
                  };
                  set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID7);
                  // pto: %242, %243, %275
                  ;
                  int64_t v575 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v377 + (uint64_t) v551) * (uint64_t) v73) + (uint64_t) v554);
                  // pto: %276
                  ;
                  int64_t v576 = v575 < v83 ? v83 : v575;
                  // pto: %277
                  ;
                  __gm__ bfloat16_t* v577 = PTOAS__GLOBAL_TENSOR_DATA(v116);
                  // pto: %277
                  ;
                  const int64_t v578 = 0;
                  // pto: %277
                  ;
                  const int64_t v579 = 512;
                  // pto: %277
                  ;
                  pto::Shape<1, 1, 1, 64, 512> v580 = pto::Shape<1, 1, 1, 64, 512>();
                  // pto: %277
                  ;
                  pto::Stride<32768, 32768, 32768, 512, 1> v581 = pto::Stride<32768, 32768, 32768, 512, 1>();
                  // pto: %277
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v582 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v577 + (v578 + v576 * v579), v580, v581);
                  wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID7);
                  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
                  TSTORE(v582, v555);
                  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
                  if (v553) {
                    uint16_t v583 = getFFTSMsg(FFTS_MODE_VAL, v83);
                    ffts_cross_core_sync(PIPE_MTE3, v583);
                  } else {
                    // pto: %279
                    ;
                    if (v552 == v72) {
                      uint16_t v584 = getFFTSMsg(FFTS_MODE_VAL, v90);
                      ffts_cross_core_sync(PIPE_MTE3, v584);
                    } else {
                      // pto: %280
                      ;
                      if (v552 == v89) {
                        uint16_t v585 = getFFTSMsg(FFTS_MODE_VAL, v94);
                        ffts_cross_core_sync(PIPE_MTE3, v585);
                      } else {
                        uint16_t v586 = getFFTSMsg(FFTS_MODE_VAL, v95);
                        ffts_cross_core_sync(PIPE_MTE3, v586);
                      };
                    };
                  };
                };
              };
              wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID7);
            };
          };
        };
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        pipe_barrier(PIPE_ALL);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        for (int64_t v587 = v83; v587 < v90; v587 += v72) {
          // pto: %281
          ;
          int64_t v588 = (int64_t) ((uint64_t) v587 * (uint64_t) v85);
          // pto: %283
          ;
          int64_t v589 = (int64_t) ((uint64_t) v361 + (uint64_t) v588);
          // pto: %2, %285, %284, %286, %287
          ;
          int64_t v590 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v325 * (uint64_t) v81) + (uint64_t) ((int64_t) (uint64_t) v373 * (uint64_t) v78)) + (uint64_t) v333) + (uint64_t) v588);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          if (v544) {
            // pto: %sm_live_scores_inline5406__ssa_v0
            ;
            Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v591 = Tile<TileType::Vec, float, 8, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v81);
            // pto: %sm_live_scores_inline5406__ssa_v0
            ;
            uint64_t v592 = (uint64_t) v42;
            TASSIGN(v591, v592);
            // pto: %289
            ;
            int64_t v593 = v590 < v83 ? v83 : v590;
            // pto: %score_transfer_inline5170__ssa_v0_pview
            ;
            __gm__ float* v594 = PTOAS__GLOBAL_TENSOR_DATA(v124);
            // pto: %score_transfer_inline5170__ssa_v0_pview
            ;
            const int64_t v595 = 0;
            // pto: %score_transfer_inline5170__ssa_v0_pview
            ;
            const int64_t v596 = 512;
            // pto: %score_transfer_inline5170__ssa_v0_pview
            ;
            pto::Shape<1, 1, 1, 8, 128> v597 = pto::Shape<1, 1, 1, 8, 128>();
            // pto: %score_transfer_inline5170__ssa_v0_pview
            ;
            pto::Stride<4096, 4096, 4096, 512, 1> v598 = pto::Stride<4096, 4096, 4096, 512, 1>();
            // pto: %score_transfer_inline5170__ssa_v0_pview
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND> v599 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 128>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND>(v594 + (v595 + v593 * v596), v597, v598);
            TLOAD(v591, v599);
            set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
            // pto: %t__tmp_v946
            ;
            Tile<TileType::Vec, float, 8, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v600 = Tile<TileType::Vec, float, 8, 384, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v96);
            // pto: %t__tmp_v946
            ;
            uint64_t v601 = (uint64_t) v43;
            TASSIGN(v600, v601);
            pipe_barrier(PIPE_V);
            TEXPANDS(v600, v86);
            // pto: %sm_scores_inline5409__ssa_v0
            ;
            Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v602 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
            // pto: %sm_scores_inline5409__ssa_v0
            ;
            uint64_t v603 = (uint64_t) v38;
            TASSIGN(v602, v603);
            pipe_barrier(PIPE_V);
            wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
            TCONCAT(v602, v591, v600);
          } else {
            // pto: %sm_scores_inline5409__ssa_v1
            ;
            Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v604 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
            // pto: %sm_scores_inline5409__ssa_v1
            ;
            uint64_t v605 = (uint64_t) v38;
            TASSIGN(v604, v605);
            // pto: %290
            ;
            int64_t v606 = v590 < v83 ? v83 : v590;
            // pto: %291
            ;
            __gm__ float* v607 = PTOAS__GLOBAL_TENSOR_DATA(v124);
            // pto: %291
            ;
            const int64_t v608 = 0;
            // pto: %291
            ;
            const int64_t v609 = 512;
            // pto: %291
            ;
            pto::Shape<1, 1, 1, 8, 512> v610 = pto::Shape<1, 1, 1, 8, 512>();
            // pto: %291
            ;
            pto::Stride<4096, 4096, 4096, 512, 1> v611 = pto::Stride<4096, 4096, 4096, 512, 1>();
            // pto: %291
            ;
            GlobalTensor<float, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND> v612 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND>(v607 + (v608 + v606 * v609), v610, v611);
            TLOAD(v604, v612);
          };
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          // pto: %sm_bias_inline5373__ssa_v0
          ;
          Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v613 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v73);
          // pto: %sm_bias_inline5373__ssa_v0
          ;
          uint64_t v614 = (uint64_t) v43;
          TASSIGN(v613, v614);
          // pto: %292
          ;
          int64_t v615 = v327 < v83 ? v83 : v327;
          // pto: %293
          ;
          int64_t v616 = (int64_t) ((uint64_t) v373 * (uint64_t) v73);
          // pto: %294
          ;
          int64_t v617 = v616 < v83 ? v83 : v616;
          // pto: %sparse_bias_inline5261__rv_v2_pview
          ;
          __gm__ float* v618 = PTOAS__GLOBAL_TENSOR_DATA(v191);
          // pto: %sparse_bias_inline5261__rv_v2_pview
          ;
          const int64_t v619 = 0;
          // pto: %sparse_bias_inline5261__rv_v2_pview
          ;
          const int64_t v620 = 1024;
          // pto: %sparse_bias_inline5261__rv_v2_pview
          ;
          pto::Shape<1, 1, 1, 1, 512> v621 = pto::Shape<1, 1, 1, 1, 512>();
          // pto: %sparse_bias_inline5261__rv_v2_pview
          ;
          pto::Stride<1024, 1024, 1024, 1024, 1> v622 = pto::Stride<1024, 1024, 1024, 1024, 1>();
          // pto: %sparse_bias_inline5261__rv_v2_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND> v623 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<1024, 1024, 1024, 1024, 1>, pto::Layout::ND>(v618 + (v619 + v615 * v620 + v617), v621, v622);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
          wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
          TLOAD(v613, v623);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          // pto: %t__tmp_v947
          ;
          Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v624 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
          // pto: %t__tmp_v947
          ;
          uint64_t v625 = (uint64_t) v38;
          TASSIGN(v624, v625);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
          TMULS(v624, v273, v97);
          // pto: %sm_masked_inline5366__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v626 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
          // pto: %sm_masked_inline5366__ssa_v0
          ;
          uint64_t v627 = (uint64_t) v38;
          TASSIGN(v626, v627);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
          TCOLEXPANDADD(v626, v624, v613);
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
          // pto: %sm_block_max_inline5410__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v628 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
          // pto: %sm_block_max_inline5410__ssa_v0
          ;
          uint64_t v629 = (uint64_t) v43;
          TASSIGN(v628, v629);
          pipe_barrier(PIPE_V);
          TROWMAX(v628, v626, v335);
          // pto: %sm_old_m_inline5241__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v630 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
          // pto: %sm_old_m_inline5241__ssa_v0
          ;
          uint64_t v631 = (uint64_t) v44;
          TASSIGN(v630, v631);
          // pto: %295
          ;
          int64_t v632 = v589 < v83 ? v83 : v589;
          // pto: %296
          ;
          __gm__ float* v633 = PTOAS__GLOBAL_TENSOR_DATA(v156);
          // pto: %296
          ;
          const int64_t v634 = 0;
          // pto: %296
          ;
          pto::Shape<1, 1, 1, 8, 1> v635 = pto::Shape<1, 1, 1, 8, 1>();
          // pto: %296
          ;
          pto::Stride<8, 8, 8, 1, 1536> v636 = pto::Stride<8, 8, 8, 1, 1536>();
          // pto: %296
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN> v637 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN>(v633 + (v634 + v632), v635, v636);
          wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
          TLOAD(v630, v637);
          set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
          // pto: %sm_old_l_inline5411__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v638 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
          // pto: %sm_old_l_inline5411__ssa_v0
          ;
          uint64_t v639 = (uint64_t) v45;
          TASSIGN(v638, v639);
          // pto: %298
          ;
          __gm__ float* v640 = PTOAS__GLOBAL_TENSOR_DATA(v164);
          // pto: %298
          ;
          const int64_t v641 = 0;
          // pto: %298
          ;
          pto::Shape<1, 1, 1, 8, 1> v642 = pto::Shape<1, 1, 1, 8, 1>();
          // pto: %298
          ;
          pto::Stride<8, 8, 8, 1, 1536> v643 = pto::Stride<8, 8, 8, 1, 1536>();
          // pto: %298
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN> v644 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN>(v640 + (v641 + v632), v642, v643);
          TLOAD(v638, v644);
          // pto: %sm_max_inline5414__rm_a0_tmp_v4
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v645 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %sm_max_inline5414__rm_a0_tmp_v4
          ;
          uint64_t v646 = (uint64_t) v44;
          TASSIGN(v645, v646);
          // pto: %sm_max_inline5414__rm_a1_tmp_v5
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v647 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %sm_max_inline5414__rm_a1_tmp_v5
          ;
          uint64_t v648 = (uint64_t) v43;
          TASSIGN(v647, v648);
          // pto: %sm_max_inline5414__row_major_tmp_v6
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v649 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %sm_max_inline5414__row_major_tmp_v6
          ;
          uint64_t v650 = (uint64_t) v46;
          TASSIGN(v649, v650);
          wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
          pipe_barrier(PIPE_V);
          TMAX(v649, v645, v647);
          // pto: %sm_max_inline5414__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v651 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
          // pto: %sm_max_inline5414__ssa_v0
          ;
          uint64_t v652 = (uint64_t) v46;
          TASSIGN(v651, v652);
          // pto: %t__rm_a0_tmp_v7
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v653 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %t__rm_a0_tmp_v7
          ;
          uint64_t v654 = (uint64_t) v44;
          TASSIGN(v653, v654);
          // pto: %t__rm_a1_tmp_v8
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v655 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %t__rm_a1_tmp_v8
          ;
          uint64_t v656 = (uint64_t) v46;
          TASSIGN(v655, v656);
          // pto: %t__row_major_tmp_v9
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v657 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %t__row_major_tmp_v9
          ;
          uint64_t v658 = (uint64_t) v43;
          TASSIGN(v657, v658);
          pipe_barrier(PIPE_V);
          TSUB(v657, v653, v655);
          // pto: %t__tmp_v948
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v659 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
          // pto: %t__tmp_v948
          ;
          uint64_t v660 = (uint64_t) v43;
          TASSIGN(v659, v660);
          // pto: %sm_alpha_inline5417__rm_a0_tmp_v10
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v661 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %sm_alpha_inline5417__rm_a0_tmp_v10
          ;
          uint64_t v662 = (uint64_t) v43;
          TASSIGN(v661, v662);
          // pto: %sm_alpha_inline5417__row_major_tmp_v11
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v663 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %sm_alpha_inline5417__row_major_tmp_v11
          ;
          uint64_t v664 = (uint64_t) v47;
          TASSIGN(v663, v664);
          pipe_barrier(PIPE_V);
          wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
          TEXP(v663, v661);
          // pto: %sm_alpha_inline5417__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v665 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
          // pto: %sm_alpha_inline5417__ssa_v0
          ;
          uint64_t v666 = (uint64_t) v47;
          TASSIGN(v665, v666);
          // pto: %t__tmp_v949
          ;
          Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v667 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
          // pto: %t__tmp_v949
          ;
          uint64_t v668 = (uint64_t) v38;
          TASSIGN(v667, v668);
          TROWEXPANDSUB(v667, v626, v651);
          // pto: %sm_exp_inline5196__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v669 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
          // pto: %sm_exp_inline5196__ssa_v0
          ;
          uint64_t v670 = (uint64_t) v38;
          TASSIGN(v669, v670);
          pipe_barrier(PIPE_V);
          TEXP(v669, v667);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
          // pto: %299
          ;
          int64_t v671 = (v12)[v327];
          // pto: %sm_key_count_inline5367__phi_v2
          ;
          int64_t v672;
          if (v544) {
            // pto: %304
            ;
            int64_t v673 = (int64_t) ((uint64_t) v671 + (uint64_t) v72);
            // pto: %305
            ;
            v672 = v673 < v81 ? v673 : v81;
          } else {
            // pto: %306, %307
            ;
            int64_t v674 = (int64_t) ((uint64_t) v671 + (uint64_t) v72) / v90;
            // pto: %308
            ;
            v672 = v674 < v73 ? v674 : v73;
          };
          // pto: %309
          ;
          bool v675 = v672 < v78;
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
          if (v675) {
            // pto: %sm_short_inline5250__ssa_v0
            ;
            Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v676 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v672);
            // pto: %sm_short_inline5250__ssa_v0
            ;
            uint64_t v677 = (uint64_t) v38;
            TASSIGN(v676, v677);
            // pto: %slice_view
            ;
            Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v678 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v672);
            // pto: %slice_view
            ;
            uint64_t v679 = (uint64_t) v38;
            TASSIGN(v678, v679);
            // pto: %t__tmp_v951
            ;
            Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v680 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
            // pto: %t__tmp_v951
            ;
            uint64_t v681 = (uint64_t) v43;
            TASSIGN(v680, v681);
            // pto: %sm_block_sum_inline5421__ssa_v0
            ;
            Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v682 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
            // pto: %sm_block_sum_inline5421__ssa_v0
            ;
            uint64_t v683 = (uint64_t) v48;
            TASSIGN(v682, v683);
            pipe_barrier(PIPE_V);
            TROWSUM(v682, v678, v680);
          } else {
            // pto: %310
            ;
            bool v684 = v672 < v73;
            if (v684) {
              // pto: %t__tmp_v952
              ;
              Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v685 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
              // pto: %t__tmp_v952
              ;
              uint64_t v686 = (uint64_t) v43;
              TASSIGN(v685, v686);
              TEXPANDS(v685, v86);
              // pto: %t__ci_tmp_v0
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v687 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v98);
              // pto: %t__ci_tmp_v0
              ;
              uint64_t v688 = (uint64_t) v49;
              TASSIGN(v687, v688);
              // pto: %t__tmp_v953
              ;
              Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v689 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
              // pto: %t__tmp_v953
              ;
              uint64_t v690 = (uint64_t) v50;
              TASSIGN(v689, v690);
              // pto: %ci_tmp_view
              ;
              Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v691;
              TRESHAPE(v691, v687);
              // pto: %ci_dst_view
              ;
              Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v692;
              TRESHAPE(v692, v689);
              TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v692, v99, v691);
              // pto: %t__tmp_v954
              ;
              Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v693 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
              // pto: %t__tmp_v954
              ;
              uint64_t v694 = (uint64_t) v49;
              TASSIGN(v693, v694);
              pipe_barrier(PIPE_V);
              RoundMode v695 = RoundMode::CAST_ROUND;
              SaturationMode v696 = SaturationMode::ON;
              TCVT(v693, v689, v695, v696);
              // pto: %sm_columns_inline5422__ssa_v0
              ;
              Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v697 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
              // pto: %sm_columns_inline5422__ssa_v0
              ;
              uint64_t v698 = (uint64_t) v43;
              TASSIGN(v697, v698);
              pipe_barrier(PIPE_V);
              TCOLEXPANDADD(v697, v685, v693);
              set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
              // pto: %t__tmp_v955
              ;
              Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v699 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
              // pto: %t__tmp_v955
              ;
              uint64_t v700 = (uint64_t) v38;
              TASSIGN(v699, v700);
              // pto: %311
              ;
              Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v701;
              // pto: %311
              ;
              uint64_t v702 = (uint64_t) v38;
              TASSIGN(v701, v702);
              // pto: %softmax_copy64_inline5267__ssa_v0_pview
              ;
              __gm__ float* v703 = PTOAS__GLOBAL_TENSOR_DATA(v199);
              // pto: %softmax_copy64_inline5267__ssa_v0_pview
              ;
              const int64_t v704 = 0;
              // pto: %softmax_copy64_inline5267__ssa_v0_pview
              ;
              const int64_t v705 = 64;
              // pto: %softmax_copy64_inline5267__ssa_v0_pview
              ;
              pto::Shape<1, 1, 1, 8, 64> v706 = pto::Shape<1, 1, 1, 8, 64>();
              // pto: %softmax_copy64_inline5267__ssa_v0_pview
              ;
              pto::Stride<512, 512, 512, 64, 1> v707 = pto::Stride<512, 512, 512, 64, 1>();
              // pto: %softmax_copy64_inline5267__ssa_v0_pview
              ;
              GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v708 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 64>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v703 + (v704 + v632 * v705), v706, v707);
              TSTORE(v708, v701);
              set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
              // pto: %sm_fold64_inline5423__ssa_v0
              ;
              Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v709 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
              // pto: %sm_fold64_inline5423__ssa_v0
              ;
              uint64_t v710 = (uint64_t) v49;
              TASSIGN(v709, v710);
              wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
              wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
              TLOAD(v709, v708);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
              set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
              // pto: %315
              ;
              bool v711 = v672 > v78;
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
              if (v711) {
                // pto: %t__tmp_v956
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v712 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %t__tmp_v956
                ;
                uint64_t v713 = (uint64_t) v51;
                TASSIGN(v712, v713);
                // pto: %316
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v714;
                // pto: %316
                ;
                uint64_t v715 = (uint64_t) v51;
                TASSIGN(v714, v715);
                // pto: %sm_added_inline5325__ssa_v0
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v716 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_added_inline5325__ssa_v0
                ;
                uint64_t v717 = (uint64_t) v52;
                TASSIGN(v716, v717);
                TADD(v716, v709, v714);
                // pto: %317
                ;
                bool v718 = v672 < v81;
                if (v718) {
                  // pto: %318
                  ;
                  uint64_t v719 = (uint64_t) v672;
                  // pto: %318, %319, %320
                  ;
                  float v720 = (float) ((int32_t) (int64_t) (v719 - (uint64_t) v78));
                  // pto: %sm_tail_mask_inline5365__ssa_v0
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v721 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
                  // pto: %sm_tail_mask_inline5365__ssa_v0
                  ;
                  uint64_t v722 = (uint64_t) v53;
                  TASSIGN(v721, v722);
                  CmpMode v723 = CmpMode::LT;
                  TCMPS(v721, v697, v720, v723);
                  // pto: %t__tmp_v957
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v724 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v74);
                  // pto: %t__tmp_v957
                  ;
                  uint64_t v725 = (uint64_t) v54;
                  TASSIGN(v724, v725);
                  // pto: %sm_fold64_inline5423__ssa_v1
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v726 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5423__ssa_v1
                  ;
                  uint64_t v727 = (uint64_t) v52;
                  TASSIGN(v726, v727);
                  pipe_barrier(PIPE_V);
                  TSEL(v726, v721, v716, v709, v724);
                } else {
                  // pto: %sm_fold64_inline5423__ssa_v2
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v728 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5423__ssa_v2
                  ;
                  uint64_t v729 = (uint64_t) v52;
                  TASSIGN(v728, v729);
                };
              } else {
                // pto: %sm_fold64_inline5423__ssa_v0_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v730 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_fold64_inline5423__ssa_v0_mv
                ;
                uint64_t v731 = (uint64_t) v52;
                TASSIGN(v730, v731);
                TMOV(v730, v709);
              };
              // pto: %321
              ;
              bool v732 = v672 > v81;
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
              if (v732) {
                // pto: %t__tmp_v958
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v733 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %t__tmp_v958
                ;
                uint64_t v734 = (uint64_t) v55;
                TASSIGN(v733, v734);
                // pto: %322
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v735;
                // pto: %322
                ;
                uint64_t v736 = (uint64_t) v55;
                TASSIGN(v735, v736);
                // pto: %sm_added_inline5325__ssa_v1
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v737 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_added_inline5325__ssa_v1
                ;
                uint64_t v738 = (uint64_t) v49;
                TASSIGN(v737, v738);
                pipe_barrier(PIPE_V);
                TADD(v737, v279, v735);
                // pto: %323
                ;
                bool v739 = v672 < v98;
                if (v739) {
                  // pto: %324
                  ;
                  uint64_t v740 = (uint64_t) v672;
                  // pto: %324, %325, %326
                  ;
                  float v741 = (float) ((int32_t) (int64_t) (v740 - (uint64_t) v81));
                  // pto: %sm_tail_mask_inline5365__ssa_v1
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v742 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
                  // pto: %sm_tail_mask_inline5365__ssa_v1
                  ;
                  uint64_t v743 = (uint64_t) v53;
                  TASSIGN(v742, v743);
                  CmpMode v744 = CmpMode::LT;
                  TCMPS(v742, v697, v741, v744);
                  // pto: %t__tmp_v959
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v745 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v74);
                  // pto: %t__tmp_v959
                  ;
                  uint64_t v746 = (uint64_t) v54;
                  TASSIGN(v745, v746);
                  // pto: %sm_fold64_inline5423__ssa_v5
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v747 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5423__ssa_v5
                  ;
                  uint64_t v748 = (uint64_t) v49;
                  TASSIGN(v747, v748);
                  pipe_barrier(PIPE_V);
                  TSEL(v747, v742, v737, v279, v745);
                } else {
                  // pto: %sm_fold64_inline5423__ssa_v6
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v749 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5423__ssa_v6
                  ;
                  uint64_t v750 = (uint64_t) v49;
                  TASSIGN(v749, v750);
                };
              } else {
                // pto: %sm_fold64_inline5423__phi_v4_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v751 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_fold64_inline5423__phi_v4_mv
                ;
                uint64_t v752 = (uint64_t) v49;
                TASSIGN(v751, v752);
                pipe_barrier(PIPE_V);
                TMOV(v751, v279);
              };
              // pto: %327
              ;
              bool v753 = v672 > v98;
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
              if (v753) {
                // pto: %t__tmp_v960
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v754 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %t__tmp_v960
                ;
                uint64_t v755 = (uint64_t) v56;
                TASSIGN(v754, v755);
                // pto: %328
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v756;
                // pto: %328
                ;
                uint64_t v757 = (uint64_t) v56;
                TASSIGN(v756, v757);
                // pto: %sm_added_inline5325__ssa_v2
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v758 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_added_inline5325__ssa_v2
                ;
                uint64_t v759 = (uint64_t) v52;
                TASSIGN(v758, v759);
                pipe_barrier(PIPE_V);
                TADD(v758, v283, v756);
                // pto: %329
                ;
                bool v760 = v672 < v88;
                if (v760) {
                  // pto: %330
                  ;
                  uint64_t v761 = (uint64_t) v672;
                  // pto: %330, %331, %332
                  ;
                  float v762 = (float) ((int32_t) (int64_t) (v761 - (uint64_t) v98));
                  // pto: %sm_tail_mask_inline5365__ssa_v2
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v763 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
                  // pto: %sm_tail_mask_inline5365__ssa_v2
                  ;
                  uint64_t v764 = (uint64_t) v53;
                  TASSIGN(v763, v764);
                  CmpMode v765 = CmpMode::LT;
                  TCMPS(v763, v697, v762, v765);
                  // pto: %t__tmp_v961
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v766 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v74);
                  // pto: %t__tmp_v961
                  ;
                  uint64_t v767 = (uint64_t) v54;
                  TASSIGN(v766, v767);
                  // pto: %sm_fold64_inline5423__ssa_v9
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v768 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5423__ssa_v9
                  ;
                  uint64_t v769 = (uint64_t) v52;
                  TASSIGN(v768, v769);
                  pipe_barrier(PIPE_V);
                  TSEL(v768, v763, v758, v283, v766);
                } else {
                  // pto: %sm_fold64_inline5423__ssa_v10
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v770 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5423__ssa_v10
                  ;
                  uint64_t v771 = (uint64_t) v52;
                  TASSIGN(v770, v771);
                };
              } else {
                // pto: %sm_fold64_inline5423__phi_v8_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v772 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_fold64_inline5423__phi_v8_mv
                ;
                uint64_t v773 = (uint64_t) v52;
                TASSIGN(v772, v773);
                pipe_barrier(PIPE_V);
                TMOV(v772, v283);
              };
              // pto: %333
              ;
              bool v774 = v672 > v88;
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
              wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
              if (v774) {
                // pto: %t__tmp_v962
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v775 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %t__tmp_v962
                ;
                uint64_t v776 = (uint64_t) v57;
                TASSIGN(v775, v776);
                // pto: %334
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v777;
                // pto: %334
                ;
                uint64_t v778 = (uint64_t) v57;
                TASSIGN(v777, v778);
                // pto: %sm_added_inline5325__ssa_v3
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v779 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_added_inline5325__ssa_v3
                ;
                uint64_t v780 = (uint64_t) v49;
                TASSIGN(v779, v780);
                pipe_barrier(PIPE_V);
                TADD(v779, v287, v777);
                // pto: %335
                ;
                bool v781 = v672 < v100;
                if (v781) {
                  // pto: %336
                  ;
                  uint64_t v782 = (uint64_t) v672;
                  // pto: %336, %337, %338
                  ;
                  float v783 = (float) ((int32_t) (int64_t) (v782 - (uint64_t) v88));
                  // pto: %sm_tail_mask_inline5365__ssa_v3
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v784 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
                  // pto: %sm_tail_mask_inline5365__ssa_v3
                  ;
                  uint64_t v785 = (uint64_t) v53;
                  TASSIGN(v784, v785);
                  CmpMode v786 = CmpMode::LT;
                  TCMPS(v784, v697, v783, v786);
                  // pto: %t__tmp_v963
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v787 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v74);
                  // pto: %t__tmp_v963
                  ;
                  uint64_t v788 = (uint64_t) v54;
                  TASSIGN(v787, v788);
                  // pto: %sm_fold64_inline5423__ssa_v13
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v789 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5423__ssa_v13
                  ;
                  uint64_t v790 = (uint64_t) v49;
                  TASSIGN(v789, v790);
                  pipe_barrier(PIPE_V);
                  TSEL(v789, v784, v779, v287, v787);
                } else {
                  // pto: %sm_fold64_inline5423__ssa_v14
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v791 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5423__ssa_v14
                  ;
                  uint64_t v792 = (uint64_t) v49;
                  TASSIGN(v791, v792);
                };
              } else {
                // pto: %sm_fold64_inline5423__phi_v12_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v793 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_fold64_inline5423__phi_v12_mv
                ;
                uint64_t v794 = (uint64_t) v49;
                TASSIGN(v793, v794);
                pipe_barrier(PIPE_V);
                TMOV(v793, v287);
              };
              // pto: %339
              ;
              bool v795 = v672 > v100;
              pipe_barrier(PIPE_ALL);
              if (v795) {
                // pto: %t__tmp_v964
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v796 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %t__tmp_v964
                ;
                uint64_t v797 = (uint64_t) v58;
                TASSIGN(v796, v797);
                // pto: %340
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v798;
                // pto: %340
                ;
                uint64_t v799 = (uint64_t) v58;
                TASSIGN(v798, v799);
                // pto: %sm_added_inline5325__ssa_v4
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v800 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_added_inline5325__ssa_v4
                ;
                uint64_t v801 = (uint64_t) v52;
                TASSIGN(v800, v801);
                pipe_barrier(PIPE_V);
                TADD(v800, v291, v798);
                // pto: %341
                ;
                bool v802 = v672 < v96;
                if (v802) {
                  // pto: %342
                  ;
                  uint64_t v803 = (uint64_t) v672;
                  // pto: %342, %343, %344
                  ;
                  float v804 = (float) ((int32_t) (int64_t) (v803 - (uint64_t) v100));
                  // pto: %sm_tail_mask_inline5365__ssa_v4
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v805 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
                  // pto: %sm_tail_mask_inline5365__ssa_v4
                  ;
                  uint64_t v806 = (uint64_t) v53;
                  TASSIGN(v805, v806);
                  CmpMode v807 = CmpMode::LT;
                  TCMPS(v805, v697, v804, v807);
                  // pto: %t__tmp_v965
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v808 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v74);
                  // pto: %t__tmp_v965
                  ;
                  uint64_t v809 = (uint64_t) v54;
                  TASSIGN(v808, v809);
                  // pto: %sm_fold64_inline5423__ssa_v17
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v810 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5423__ssa_v17
                  ;
                  uint64_t v811 = (uint64_t) v52;
                  TASSIGN(v810, v811);
                  pipe_barrier(PIPE_V);
                  TSEL(v810, v805, v800, v291, v808);
                } else {
                  // pto: %sm_fold64_inline5423__ssa_v18
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v812 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5423__ssa_v18
                  ;
                  uint64_t v813 = (uint64_t) v52;
                  TASSIGN(v812, v813);
                };
              } else {
                // pto: %sm_fold64_inline5423__phi_v16_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v814 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_fold64_inline5423__phi_v16_mv
                ;
                uint64_t v815 = (uint64_t) v52;
                TASSIGN(v814, v815);
                pipe_barrier(PIPE_V);
                TMOV(v814, v291);
              };
              // pto: %345
              ;
              bool v816 = v672 > v96;
              pipe_barrier(PIPE_ALL);
              if (v816) {
                // pto: %t__tmp_v966
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v817 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %t__tmp_v966
                ;
                uint64_t v818 = (uint64_t) v59;
                TASSIGN(v817, v818);
                // pto: %346
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v819;
                // pto: %346
                ;
                uint64_t v820 = (uint64_t) v59;
                TASSIGN(v819, v820);
                // pto: %sm_added_inline5325__ssa_v5
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v821 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_added_inline5325__ssa_v5
                ;
                uint64_t v822 = (uint64_t) v49;
                TASSIGN(v821, v822);
                pipe_barrier(PIPE_V);
                TADD(v821, v295, v819);
                // pto: %347
                ;
                bool v823 = v672 < v101;
                if (v823) {
                  // pto: %348
                  ;
                  uint64_t v824 = (uint64_t) v672;
                  // pto: %348, %349, %350
                  ;
                  float v825 = (float) ((int32_t) (int64_t) (v824 - (uint64_t) v96));
                  // pto: %sm_tail_mask_inline5365__ssa_v5
                  ;
                  Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v826 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
                  // pto: %sm_tail_mask_inline5365__ssa_v5
                  ;
                  uint64_t v827 = (uint64_t) v53;
                  TASSIGN(v826, v827);
                  CmpMode v828 = CmpMode::LT;
                  TCMPS(v826, v697, v825, v828);
                  // pto: %t__tmp_v967
                  ;
                  Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v829 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v74);
                  // pto: %t__tmp_v967
                  ;
                  uint64_t v830 = (uint64_t) v54;
                  TASSIGN(v829, v830);
                  // pto: %sm_fold64_inline5423__ssa_v21
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v831 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5423__ssa_v21
                  ;
                  uint64_t v832 = (uint64_t) v49;
                  TASSIGN(v831, v832);
                  pipe_barrier(PIPE_V);
                  TSEL(v831, v826, v821, v295, v829);
                } else {
                  // pto: %sm_fold64_inline5423__ssa_v22
                  ;
                  Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v833 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                  // pto: %sm_fold64_inline5423__ssa_v22
                  ;
                  uint64_t v834 = (uint64_t) v49;
                  TASSIGN(v833, v834);
                };
              } else {
                // pto: %sm_fold64_inline5423__phi_v20_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v835 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_fold64_inline5423__phi_v20_mv
                ;
                uint64_t v836 = (uint64_t) v49;
                TASSIGN(v835, v836);
                pipe_barrier(PIPE_V);
                TMOV(v835, v295);
              };
              // pto: %351
              ;
              bool v837 = v672 > v101;
              pipe_barrier(PIPE_ALL);
              if (v837) {
                // pto: %t__tmp_v968
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v838 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %t__tmp_v968
                ;
                uint64_t v839 = (uint64_t) v60;
                TASSIGN(v838, v839);
                // pto: %352
                ;
                Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, 8, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v840;
                // pto: %352
                ;
                uint64_t v841 = (uint64_t) v60;
                TASSIGN(v840, v841);
                // pto: %sm_added_inline5325__ssa_v6
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v842 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_added_inline5325__ssa_v6
                ;
                uint64_t v843 = (uint64_t) v52;
                TASSIGN(v842, v843);
                pipe_barrier(PIPE_V);
                TADD(v842, v299, v840);
                // pto: %353
                ;
                uint64_t v844 = (uint64_t) v672;
                // pto: %353, %354, %355
                ;
                float v845 = (float) ((int32_t) (int64_t) (v844 - (uint64_t) v101));
                // pto: %sm_tail_mask_inline5365__ssa_v6
                ;
                Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v846 = Tile<TileType::Vec, uint8_t, 8, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
                // pto: %sm_tail_mask_inline5365__ssa_v6
                ;
                uint64_t v847 = (uint64_t) v53;
                TASSIGN(v846, v847);
                CmpMode v848 = CmpMode::LT;
                TCMPS(v846, v697, v845, v848);
                // pto: %t__tmp_v969
                ;
                Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v849 = Tile<TileType::Vec, uint32_t, 1, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v74);
                // pto: %t__tmp_v969
                ;
                uint64_t v850 = (uint64_t) v54;
                TASSIGN(v849, v850);
                // pto: %sm_fold64_inline5423__ssa_v25
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v851 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_fold64_inline5423__ssa_v25
                ;
                uint64_t v852 = (uint64_t) v43;
                TASSIGN(v851, v852);
                pipe_barrier(PIPE_V);
                TSEL(v851, v846, v842, v299, v849);
              } else {
                // pto: %sm_fold64_inline5423__phi_v24_mv
                ;
                Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v853 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
                // pto: %sm_fold64_inline5423__phi_v24_mv
                ;
                uint64_t v854 = (uint64_t) v43;
                TASSIGN(v853, v854);
                pipe_barrier(PIPE_V);
                TMOV(v853, v299);
              };
              // pto: %sm_groups64_inline5425__ssa_v0
              ;
              Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v855 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v85);
              // pto: %sm_groups64_inline5425__ssa_v0
              ;
              uint64_t v856 = (uint64_t) v43;
              TASSIGN(v855, v856);
              // pto: %t__tmp_v970
              ;
              Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v857 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v85);
              // pto: %t__tmp_v970
              ;
              uint64_t v858 = (uint64_t) v49;
              TASSIGN(v857, v858);
              // pto: %sm_sum8_inline5427__ssa_v0
              ;
              Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v859 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v72);
              // pto: %sm_sum8_inline5427__ssa_v0
              ;
              uint64_t v860 = (uint64_t) v52;
              TASSIGN(v859, v860);
              pipe_barrier(PIPE_V);
              pipe_barrier(PIPE_ALL);
              TROWSUM(v859, v855, v857);
              // pto: %sm_final8_inline5375__ssa_v0
              ;
              Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v861 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
              // pto: %sm_final8_inline5375__ssa_v0
              ;
              uint64_t v862 = (uint64_t) v52;
              TASSIGN(v861, v862);
              // pto: %t__tmp_v971
              ;
              Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v863 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
              // pto: %t__tmp_v971
              ;
              uint64_t v864 = (uint64_t) v43;
              TASSIGN(v863, v864);
              // pto: %sm_block_sum_inline5421__ssa_v1
              ;
              Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v865 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
              // pto: %sm_block_sum_inline5421__ssa_v1
              ;
              uint64_t v866 = (uint64_t) v48;
              TASSIGN(v865, v866);
              pipe_barrier(PIPE_V);
              TROWSUM(v865, v861, v863);
            } else {
              // pto: %sm_groups8_inline5429__ssa_v0
              ;
              Tile<TileType::Vec, float, 512, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v867 = Tile<TileType::Vec, float, 512, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v85);
              // pto: %sm_groups8_inline5429__ssa_v0
              ;
              uint64_t v868 = (uint64_t) v38;
              TASSIGN(v867, v868);
              // pto: %t__tmp_v972
              ;
              Tile<TileType::Vec, float, 512, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v869 = Tile<TileType::Vec, float, 512, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v85);
              // pto: %t__tmp_v972
              ;
              uint64_t v870 = (uint64_t) v43;
              TASSIGN(v869, v870);
              // pto: %sm_sum64_inline5430__ssa_v0
              ;
              Tile<TileType::Vec, float, 512, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v871 = Tile<TileType::Vec, float, 512, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v73, v72);
              // pto: %sm_sum64_inline5430__ssa_v0
              ;
              uint64_t v872 = (uint64_t) v61;
              TASSIGN(v871, v872);
              pipe_barrier(PIPE_V);
              TROWSUM(v871, v867, v869);
              // pto: %sm_groups64_inline5425__ssa_v1
              ;
              Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v873 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v85);
              // pto: %sm_groups64_inline5425__ssa_v1
              ;
              uint64_t v874 = (uint64_t) v61;
              TASSIGN(v873, v874);
              // pto: %t__tmp_v973
              ;
              Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v875 = Tile<TileType::Vec, float, 64, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v85);
              // pto: %t__tmp_v973
              ;
              uint64_t v876 = (uint64_t) v43;
              TASSIGN(v875, v876);
              // pto: %sm_sum8_inline5427__ssa_v1
              ;
              Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v877 = Tile<TileType::Vec, float, 64, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v72);
              // pto: %sm_sum8_inline5427__ssa_v1
              ;
              uint64_t v878 = (uint64_t) v49;
              TASSIGN(v877, v878);
              pipe_barrier(PIPE_V);
              TROWSUM(v877, v873, v875);
              // pto: %sm_final8_inline5375__ssa_v1
              ;
              Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v879 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
              // pto: %sm_final8_inline5375__ssa_v1
              ;
              uint64_t v880 = (uint64_t) v49;
              TASSIGN(v879, v880);
              // pto: %t__tmp_v974
              ;
              Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v881 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v85);
              // pto: %t__tmp_v974
              ;
              uint64_t v882 = (uint64_t) v43;
              TASSIGN(v881, v882);
              // pto: %sm_block_sum_inline5421__ssa_v2
              ;
              Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v883 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
              // pto: %sm_block_sum_inline5421__ssa_v2
              ;
              uint64_t v884 = (uint64_t) v62;
              TASSIGN(v883, v884);
              pipe_barrier(PIPE_V);
              TROWSUM(v883, v879, v881);
              // pto: %sm_block_sum_inline5421__ssa_v2_mv
              ;
              Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v885 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
              // pto: %sm_block_sum_inline5421__ssa_v2_mv
              ;
              uint64_t v886 = (uint64_t) v48;
              TASSIGN(v885, v886);
              pipe_barrier(PIPE_V);
              TMOV(v885, v883);
            };
          };
          set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
          // pto: %t__rm_a0_tmp_v12
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v887 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %t__rm_a0_tmp_v12
          ;
          uint64_t v888 = (uint64_t) v45;
          TASSIGN(v887, v888);
          // pto: %t__rm_a1_tmp_v13
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v889 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %t__rm_a1_tmp_v13
          ;
          uint64_t v890 = (uint64_t) v47;
          TASSIGN(v889, v890);
          // pto: %t__row_major_tmp_v14
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v891 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %t__row_major_tmp_v14
          ;
          uint64_t v892 = (uint64_t) v43;
          TASSIGN(v891, v892);
          pipe_barrier(PIPE_V);
          pipe_barrier(PIPE_ALL);
          TMUL(v891, v887, v889);
          // pto: %t__tmp_v975
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v893 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
          // pto: %t__tmp_v975
          ;
          uint64_t v894 = (uint64_t) v43;
          TASSIGN(v893, v894);
          // pto: %sm_sum_inline5326__rm_a0_tmp_v15
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v895 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %sm_sum_inline5326__rm_a0_tmp_v15
          ;
          uint64_t v896 = (uint64_t) v43;
          TASSIGN(v895, v896);
          // pto: %sm_sum_inline5326__rm_a1_tmp_v16
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v897 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %sm_sum_inline5326__rm_a1_tmp_v16
          ;
          uint64_t v898 = (uint64_t) v48;
          TASSIGN(v897, v898);
          // pto: %sm_sum_inline5326__row_major_tmp_v17
          ;
          Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v899 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
          // pto: %sm_sum_inline5326__row_major_tmp_v17
          ;
          uint64_t v900 = (uint64_t) v43;
          TASSIGN(v899, v900);
          pipe_barrier(PIPE_V);
          TADD(v899, v895, v897);
          // pto: %sm_sum_inline5326__ssa_v0
          ;
          Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v901 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
          // pto: %sm_sum_inline5326__ssa_v0
          ;
          uint64_t v902 = (uint64_t) v43;
          TASSIGN(v901, v902);
          // pto: %sm_probability_inline5205__ssa_v0
          ;
          Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v903 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
          // pto: %sm_probability_inline5205__ssa_v0
          ;
          uint64_t v904 = (uint64_t) v38;
          TASSIGN(v903, v904);
          RoundMode v905 = RoundMode::CAST_ROUND;
          SaturationMode v906 = SaturationMode::ON;
          TCVT(v903, v669, v905, v906);
          set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
          // pto: %probability_transfer_inline5407__ssa_v0_pview
          ;
          __gm__ bfloat16_t* v907 = PTOAS__GLOBAL_TENSOR_DATA(v132);
          // pto: %probability_transfer_inline5407__ssa_v0_pview
          ;
          const int64_t v908 = 0;
          // pto: %probability_transfer_inline5407__ssa_v0_pview
          ;
          const int64_t v909 = 512;
          // pto: %probability_transfer_inline5407__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 8, 512> v910 = pto::Shape<1, 1, 1, 8, 512>();
          // pto: %probability_transfer_inline5407__ssa_v0_pview
          ;
          pto::Stride<4096, 4096, 4096, 512, 1> v911 = pto::Stride<4096, 4096, 4096, 512, 1>();
          // pto: %probability_transfer_inline5407__ssa_v0_pview
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND> v912 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 8, 512>, pto::Stride<4096, 4096, 4096, 512, 1>, pto::Layout::ND>(v907 + (v908 + v632 * v909), v910, v911);
          wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
          TSTORE(v912, v903);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
          TSTORE(v637, v651);
          TSTORE(v644, v901);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
          set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
          // pto: %alpha_transfer_inline5171__ssa_v0_pview
          ;
          __gm__ float* v913 = PTOAS__GLOBAL_TENSOR_DATA(v207);
          // pto: %alpha_transfer_inline5171__ssa_v0_pview
          ;
          const int64_t v914 = 0;
          // pto: %alpha_transfer_inline5171__ssa_v0_pview
          ;
          pto::Shape<1, 1, 1, 8, 1> v915 = pto::Shape<1, 1, 1, 8, 1>();
          // pto: %alpha_transfer_inline5171__ssa_v0_pview
          ;
          pto::Stride<8, 8, 8, 1, 1536> v916 = pto::Stride<8, 8, 8, 1, 1536>();
          // pto: %alpha_transfer_inline5171__ssa_v0_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN> v917 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN>(v913 + (v914 + v632), v915, v916);
          TSTORE(v917, v665);
          set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        };
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        uint16_t v918 = getFFTSMsg(FFTS_MODE_VAL, v89);
        ffts_cross_core_sync(PIPE_MTE3, v918);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        if (v380) {
          // pto: %363
          ;
          int64_t v919 = (int64_t) ((uint64_t) v327 + (uint64_t) v82);
          // pto: %365
          ;
          if (v919 < v24) {
            // pto: %367, %366
            ;
            int32_t v920 = (v4)[(int64_t) ((uint64_t) v919 * (uint64_t) v74)];
            // pto: %369, %370
            ;
            if ((int64_t) v920 > v83) {
              // pto: %371
              ;
              int32_t v921 = (v2)[v919];
              // pto: %372
              ;
              int64_t v922 = (int64_t) v921;
              // pto: %373
              ;
              int64_t v923 = v922 < v83 ? v83 : v922;
              // pto: %375, %376
              ;
              int64_t v924 = (int64_t) ((uint64_t) v376 + (uint64_t) v72) % v89;
              // pto: %377, %378, %379
              ;
              int64_t v925 = v924 < v83 ? (int64_t) ((uint64_t) v924 + (uint64_t) v89) : v924;
              set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
              for (int64_t v926 = v83; v926 < v90; v926 += v72) {
                // pto: %383
                ;
                if (v926 == v83) {
                  // pto: %385, %386
                  ;
                  int64_t v927 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v926 * (uint64_t) v81) + (uint64_t) v334);
                  // pto: %prefetch_kv_half_v1_inline5431__ssa_v0
                  ;
                  Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v928 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v78, v73);
                  // pto: %prefetch_kv_half_v1_inline5431__ssa_v0
                  ;
                  uint64_t v929 = (uint64_t) v38;
                  TASSIGN(v928, v929);
                  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
                  pipe_barrier(PIPE_V);
                  TEXPANDS(v928, v91);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
                  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
                  set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
                  // pto: %387
                  ;
                  int64_t v930 = (v12)[v919];
                  // pto: %391
                  ;
                  int64_t v931 = (int64_t) ((uint64_t) v930 + (uint64_t) v72);
                  // pto: %392
                  ;
                  int64_t v932 = v931 < v81 ? v931 : v81;
                  // pto: %393, %394
                  ;
                  int64_t v933 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v930 - (uint64_t) v932) + (uint64_t) v72);
                  // pto: %395
                  ;
                  int64_t v934 = v933 % v84;
                  // pto: %396, %397, %398
                  ;
                  int64_t v935 = v934 < v83 ? (int64_t) ((uint64_t) v934 + (uint64_t) v84) : v934;
                  // pto: %399
                  ;
                  int64_t v936 = (int64_t) ((uint64_t) v932 - (uint64_t) v927);
                  // pto: %400
                  ;
                  int64_t v937 = v936 < v83 ? v83 : v936;
                  // pto: %401
                  ;
                  int64_t v938 = v937 < v78 ? v937 : v78;
                  // pto: %402, %403
                  ;
                  int64_t v939 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v84 - (uint64_t) v935) - (uint64_t) v927);
                  // pto: %404
                  ;
                  int64_t v940 = v939 < v938 ? v939 : v938;
                  // pto: %405
                  ;
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
                  if (v940 > v83) {
                    // pto: %406
                    ;
                    int64_t v941 = (int64_t) ((uint64_t) v933 + (uint64_t) v927);
                    // pto: %409, %410, %408, %prefetch_raw_page_inline5372__tile
                    ;
                    int32_t v942 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v923 * (uint64_t) v29) + (uint64_t) (v941 / v84))];
                    // pto: %411
                    ;
                    int64_t v943 = (int64_t) v942;
                    // pto: %412
                    ;
                    if (v943 >= v83) {
                      // pto: %415
                      ;
                      int64_t v944 = v941 % v84;
                      // pto: %416, %417, %418
                      ;
                      int64_t v945 = v944 < v83 ? (int64_t) ((uint64_t) v944 + (uint64_t) v84) : v944;
                      // pto: %414, %419
                      ;
                      int64_t v946 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v943 * (uint64_t) v84) + (uint64_t) v945);
                      // pto: %421
                      ;
                      Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v947 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v940);
                      // pto: %421
                      ;
                      uint64_t v948 = (uint64_t) v38;
                      TASSIGN(v947, v948);
                      // pto: %422
                      ;
                      int64_t v949 = v946 < v83 ? v83 : v946;
                      // pto: %423
                      ;
                      const int64_t v950 = 0;
                      // pto: %423
                      ;
                      __gm__ bfloat16_t* v951 = PTOAS__GLOBAL_TENSOR_DATA(v173);
                      // pto: %423
                      ;
                      const int64_t v952 = 1;
                      // pto: %423
                      ;
                      const int64_t v953 = 1;
                      // pto: %423
                      ;
                      const int64_t v954 = 1;
                      // pto: %423
                      ;
                      int64_t v955 = v940 * v73;
                      // pto: %423
                      ;
                      int64_t v956 = v954 * v955;
                      // pto: %423
                      ;
                      pto::Shape<1, 1, 1, -1, 512> v957 = pto::Shape<1, 1, 1, -1, 512>(v952, v953, v954, v940, v73);
                      // pto: %423
                      ;
                      pto::Stride<-1, -1, -1, -1, -1> v958 = pto::Stride<-1, -1, -1, -1, -1>(v953 * v956, v956, v955, v73, v72);
                      // pto: %423
                      ;
                      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v959 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v951 + (v950 + v949 * v73 + v83 * v72), v957, v958);
                      TLOAD(v947, v959);
                    };
                  };
                  set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID4);
                  // pto: %426
                  ;
                  int64_t v960 = v939 < v83 ? v83 : v939;
                  // pto: %427, %428
                  ;
                  int64_t v961 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v78 - (uint64_t) v935) - (uint64_t) v927);
                  // pto: %429
                  ;
                  int64_t v962 = v961 < v938 ? v961 : v938;
                  // pto: %430
                  ;
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
                  if (v960 < v962) {
                    // pto: %431, %432
                    ;
                    int64_t v963 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v933 + (uint64_t) v927) + (uint64_t) v960);
                    // pto: %435, %436, %434, %433
                    ;
                    int32_t v964 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v923 * (uint64_t) v29) + (uint64_t) (v963 / v84))];
                    // pto: %437
                    ;
                    int64_t v965 = (int64_t) v964;
                    // pto: %438
                    ;
                    if (v965 >= v83) {
                      // pto: %441
                      ;
                      int64_t v966 = v963 % v84;
                      // pto: %442, %443, %444
                      ;
                      int64_t v967 = v966 < v83 ? (int64_t) ((uint64_t) v966 + (uint64_t) v84) : v966;
                      // pto: %440, %445
                      ;
                      int64_t v968 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v965 * (uint64_t) v84) + (uint64_t) v967);
                      // pto: %446
                      ;
                      int64_t v969 = (int64_t) ((uint64_t) v962 - (uint64_t) v960);
                      // pto: %447
                      ;
                      Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v970 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v969);
                      // pto: %447
                      ;
                      uint64_t v971 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v960 * (uint64_t) v36) + (uint64_t) v38);
                      TASSIGN(v970, v971);
                      // pto: %448
                      ;
                      int64_t v972 = v968 < v83 ? v83 : v968;
                      // pto: %449
                      ;
                      const int64_t v973 = 0;
                      // pto: %449
                      ;
                      __gm__ bfloat16_t* v974 = PTOAS__GLOBAL_TENSOR_DATA(v173);
                      // pto: %449
                      ;
                      const int64_t v975 = 1;
                      // pto: %449
                      ;
                      const int64_t v976 = 1;
                      // pto: %449
                      ;
                      const int64_t v977 = 1;
                      // pto: %449
                      ;
                      int64_t v978 = v969 * v73;
                      // pto: %449
                      ;
                      int64_t v979 = v977 * v978;
                      // pto: %449
                      ;
                      pto::Shape<1, 1, 1, -1, 512> v980 = pto::Shape<1, 1, 1, -1, 512>(v975, v976, v977, v969, v73);
                      // pto: %449
                      ;
                      pto::Stride<-1, -1, -1, -1, -1> v981 = pto::Stride<-1, -1, -1, -1, -1>(v976 * v979, v979, v978, v73, v72);
                      // pto: %449
                      ;
                      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v982 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v974 + (v973 + v972 * v73 + v83 * v72), v980, v981);
                      TLOAD(v970, v982);
                    };
                  };
                  set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
                  // pto: %452
                  ;
                  int64_t v983 = v961 < v83 ? v83 : v961;
                  // pto: %453, %454
                  ;
                  int64_t v984 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v92 - (uint64_t) v935) - (uint64_t) v927);
                  // pto: %455
                  ;
                  int64_t v985 = v984 < v938 ? v984 : v938;
                  // pto: %456
                  ;
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
                  if (v983 < v985) {
                    // pto: %457, %458
                    ;
                    int64_t v986 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v933 + (uint64_t) v927) + (uint64_t) v983);
                    // pto: %461, %462, %460, %459
                    ;
                    int32_t v987 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v923 * (uint64_t) v29) + (uint64_t) (v986 / v84))];
                    // pto: %463
                    ;
                    int64_t v988 = (int64_t) v987;
                    // pto: %464
                    ;
                    if (v988 >= v83) {
                      // pto: %467
                      ;
                      int64_t v989 = v986 % v84;
                      // pto: %468, %469, %470
                      ;
                      int64_t v990 = v989 < v83 ? (int64_t) ((uint64_t) v989 + (uint64_t) v84) : v989;
                      // pto: %466, %471
                      ;
                      int64_t v991 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v988 * (uint64_t) v84) + (uint64_t) v990);
                      // pto: %472
                      ;
                      int64_t v992 = (int64_t) ((uint64_t) v985 - (uint64_t) v983);
                      // pto: %473
                      ;
                      Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v993 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v992);
                      // pto: %473
                      ;
                      uint64_t v994 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v983 * (uint64_t) v36) + (uint64_t) v38);
                      TASSIGN(v993, v994);
                      // pto: %474
                      ;
                      int64_t v995 = v991 < v83 ? v83 : v991;
                      // pto: %475
                      ;
                      const int64_t v996 = 0;
                      // pto: %475
                      ;
                      __gm__ bfloat16_t* v997 = PTOAS__GLOBAL_TENSOR_DATA(v173);
                      // pto: %475
                      ;
                      const int64_t v998 = 1;
                      // pto: %475
                      ;
                      const int64_t v999 = 1;
                      // pto: %475
                      ;
                      const int64_t v1000 = 1;
                      // pto: %475
                      ;
                      int64_t v1001 = v992 * v73;
                      // pto: %475
                      ;
                      int64_t v1002 = v1000 * v1001;
                      // pto: %475
                      ;
                      pto::Shape<1, 1, 1, -1, 512> v1003 = pto::Shape<1, 1, 1, -1, 512>(v998, v999, v1000, v992, v73);
                      // pto: %475
                      ;
                      pto::Stride<-1, -1, -1, -1, -1> v1004 = pto::Stride<-1, -1, -1, -1, -1>(v999 * v1002, v1002, v1001, v73, v72);
                      // pto: %475
                      ;
                      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1005 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v997 + (v996 + v995 * v73 + v83 * v72), v1003, v1004);
                      TLOAD(v993, v1005);
                    };
                  };
                  set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
                  // pto: %478
                  ;
                  int64_t v1006 = v984 < v83 ? v83 : v984;
                  // pto: %479, %480
                  ;
                  int64_t v1007 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v81 - (uint64_t) v935) - (uint64_t) v927);
                  // pto: %481
                  ;
                  int64_t v1008 = v1007 < v938 ? v1007 : v938;
                  // pto: %482
                  ;
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
                  if (v1006 < v1008) {
                    // pto: %483, %484
                    ;
                    int64_t v1009 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v933 + (uint64_t) v927) + (uint64_t) v1006);
                    // pto: %487, %488, %486, %485
                    ;
                    int32_t v1010 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v923 * (uint64_t) v29) + (uint64_t) (v1009 / v84))];
                    // pto: %489
                    ;
                    int64_t v1011 = (int64_t) v1010;
                    // pto: %490
                    ;
                    if (v1011 >= v83) {
                      // pto: %493
                      ;
                      int64_t v1012 = v1009 % v84;
                      // pto: %494, %495, %496
                      ;
                      int64_t v1013 = v1012 < v83 ? (int64_t) ((uint64_t) v1012 + (uint64_t) v84) : v1012;
                      // pto: %492, %497
                      ;
                      int64_t v1014 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v1011 * (uint64_t) v84) + (uint64_t) v1013);
                      // pto: %498
                      ;
                      int64_t v1015 = (int64_t) ((uint64_t) v1008 - (uint64_t) v1006);
                      // pto: %499
                      ;
                      Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1016 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1015);
                      // pto: %499
                      ;
                      uint64_t v1017 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1006 * (uint64_t) v36) + (uint64_t) v38);
                      TASSIGN(v1016, v1017);
                      // pto: %500
                      ;
                      int64_t v1018 = v1014 < v83 ? v83 : v1014;
                      // pto: %501
                      ;
                      const int64_t v1019 = 0;
                      // pto: %501
                      ;
                      __gm__ bfloat16_t* v1020 = PTOAS__GLOBAL_TENSOR_DATA(v173);
                      // pto: %501
                      ;
                      const int64_t v1021 = 1;
                      // pto: %501
                      ;
                      const int64_t v1022 = 1;
                      // pto: %501
                      ;
                      const int64_t v1023 = 1;
                      // pto: %501
                      ;
                      int64_t v1024 = v1015 * v73;
                      // pto: %501
                      ;
                      int64_t v1025 = v1023 * v1024;
                      // pto: %501
                      ;
                      pto::Shape<1, 1, 1, -1, 512> v1026 = pto::Shape<1, 1, 1, -1, 512>(v1021, v1022, v1023, v1015, v73);
                      // pto: %501
                      ;
                      pto::Stride<-1, -1, -1, -1, -1> v1027 = pto::Stride<-1, -1, -1, -1, -1>(v1022 * v1025, v1025, v1024, v73, v72);
                      // pto: %501
                      ;
                      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1028 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1020 + (v1019 + v1018 * v73 + v83 * v72), v1026, v1027);
                      TLOAD(v1016, v1028);
                    };
                  };
                  set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
                  // pto: %504
                  ;
                  int64_t v1029 = v1007 < v83 ? v83 : v1007;
                  // pto: %505, %506
                  ;
                  int64_t v1030 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v93 - (uint64_t) v935) - (uint64_t) v927);
                  // pto: %507
                  ;
                  int64_t v1031 = v1030 < v938 ? v1030 : v938;
                  // pto: %508
                  ;
                  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
                  if (v1029 < v1031) {
                    // pto: %509, %510
                    ;
                    int64_t v1032 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v933 + (uint64_t) v927) + (uint64_t) v1029);
                    // pto: %513, %514, %512, %511
                    ;
                    int32_t v1033 = (v13)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) v923 * (uint64_t) v29) + (uint64_t) (v1032 / v84))];
                    // pto: %515
                    ;
                    int64_t v1034 = (int64_t) v1033;
                    // pto: %516
                    ;
                    if (v1034 >= v83) {
                      // pto: %519
                      ;
                      int64_t v1035 = v1032 % v84;
                      // pto: %520, %521, %522
                      ;
                      int64_t v1036 = v1035 < v83 ? (int64_t) ((uint64_t) v1035 + (uint64_t) v84) : v1035;
                      // pto: %518, %523
                      ;
                      int64_t v1037 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v1034 * (uint64_t) v84) + (uint64_t) v1036);
                      // pto: %524
                      ;
                      int64_t v1038 = (int64_t) ((uint64_t) v1031 - (uint64_t) v1029);
                      // pto: %525
                      ;
                      Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1039 = Tile<TileType::Vec, bfloat16_t, 64, 512, BLayout::RowMajor, -1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1038);
                      // pto: %525
                      ;
                      uint64_t v1040 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1029 * (uint64_t) v36) + (uint64_t) v38);
                      TASSIGN(v1039, v1040);
                      // pto: %526
                      ;
                      int64_t v1041 = v1037 < v83 ? v83 : v1037;
                      // pto: %527
                      ;
                      const int64_t v1042 = 0;
                      // pto: %527
                      ;
                      __gm__ bfloat16_t* v1043 = PTOAS__GLOBAL_TENSOR_DATA(v173);
                      // pto: %527
                      ;
                      const int64_t v1044 = 1;
                      // pto: %527
                      ;
                      const int64_t v1045 = 1;
                      // pto: %527
                      ;
                      const int64_t v1046 = 1;
                      // pto: %527
                      ;
                      int64_t v1047 = v1038 * v73;
                      // pto: %527
                      ;
                      int64_t v1048 = v1046 * v1047;
                      // pto: %527
                      ;
                      pto::Shape<1, 1, 1, -1, 512> v1049 = pto::Shape<1, 1, 1, -1, 512>(v1044, v1045, v1046, v1038, v73);
                      // pto: %527
                      ;
                      pto::Stride<-1, -1, -1, -1, -1> v1050 = pto::Stride<-1, -1, -1, -1, -1>(v1045 * v1048, v1048, v1047, v73, v72);
                      // pto: %527
                      ;
                      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1051 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1043 + (v1042 + v1041 * v73 + v83 * v72), v1049, v1050);
                      TLOAD(v1039, v1051);
                    };
                  };
                  set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
                  // pto: %380, %381, %528
                  ;
                  int64_t v1052 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v377 + (uint64_t) v925) * (uint64_t) v73) + (uint64_t) v927);
                  // pto: %529
                  ;
                  int64_t v1053 = v1052 < v83 ? v83 : v1052;
                  // pto: %530
                  ;
                  __gm__ bfloat16_t* v1054 = PTOAS__GLOBAL_TENSOR_DATA(v116);
                  // pto: %530
                  ;
                  const int64_t v1055 = 0;
                  // pto: %530
                  ;
                  const int64_t v1056 = 512;
                  // pto: %530
                  ;
                  pto::Shape<1, 1, 1, 64, 512> v1057 = pto::Shape<1, 1, 1, 64, 512>();
                  // pto: %530
                  ;
                  pto::Stride<32768, 32768, 32768, 512, 1> v1058 = pto::Stride<32768, 32768, 32768, 512, 1>();
                  // pto: %530
                  ;
                  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND> v1059 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 64, 512>, pto::Stride<32768, 32768, 32768, 512, 1>, pto::Layout::ND>(v1054 + (v1055 + v1053 * v1056), v1057, v1058);
                  wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
                  wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
                  wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
                  wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
                  wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID4);
                  wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
                  TSTORE(v1059, v321);
                  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
                  uint16_t v1060 = getFFTSMsg(FFTS_MODE_VAL, v83);
                  ffts_cross_core_sync(PIPE_MTE3, v1060);
                };
              };
              wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
            };
          };
        };
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        int32_t v1061 = (int32_t) v102;
        wait_flag_dev(v1061);
        // pto: %alpha_inline5258__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1062 = Tile<TileType::Vec, float, 32, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v72);
        // pto: %alpha_inline5258__ssa_v0
        ;
        uint64_t v1063 = (uint64_t) v63;
        TASSIGN(v1062, v1063);
        // pto: %536
        ;
        __gm__ float* v1064 = PTOAS__GLOBAL_TENSOR_DATA(v207);
        // pto: %536
        ;
        const int64_t v1065 = 0;
        // pto: %536
        ;
        pto::Shape<1, 1, 1, 32, 1> v1066 = pto::Shape<1, 1, 1, 32, 1>();
        // pto: %536
        ;
        pto::Stride<32, 32, 32, 1, 1536> v1067 = pto::Stride<32, 32, 32, 1, 1536>();
        // pto: %536
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN> v1068 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 1>, pto::Stride<32, 32, 32, 1, 1536>, pto::Layout::DN>(v1064 + (v1065 + v362), v1066, v1067);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
        TLOAD(v1062, v1068);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %pv_left_inline5316__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1069 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
        // pto: %pv_left_inline5316__ssa_v0
        ;
        uint64_t v1070 = (uint64_t) v38;
        TASSIGN(v1069, v1070);
        // pto: %pv_transfer_inline5166__ssa_v0_pview
        ;
        __gm__ float* v1071 = PTOAS__GLOBAL_TENSOR_DATA(v140);
        // pto: %pv_transfer_inline5166__ssa_v0_pview
        ;
        const int64_t v1072 = 0;
        // pto: %pv_transfer_inline5166__ssa_v0_pview
        ;
        const int64_t v1073 = 512;
        // pto: %pv_transfer_inline5166__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 32, 256> v1074 = pto::Shape<1, 1, 1, 32, 256>();
        // pto: %pv_transfer_inline5166__ssa_v0_pview
        ;
        pto::Stride<16384, 16384, 16384, 512, 1> v1075 = pto::Stride<16384, 16384, 16384, 512, 1>();
        // pto: %pv_transfer_inline5166__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v1076 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v1071 + (v1072 + v362 * v1073), v1074, v1075);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
        TLOAD(v1069, v1076);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        // pto: %t__tmp_v980
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1077 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
        // pto: %t__tmp_v980
        ;
        uint64_t v1078 = (uint64_t) v61;
        TASSIGN(v1077, v1078);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v1077, v357, v1062);
        // pto: %next_left_inline5388__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1079 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
        // pto: %next_left_inline5388__ssa_v0
        ;
        uint64_t v1080 = (uint64_t) v40;
        TASSIGN(v1079, v1080);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
        TADD(v1079, v1077, v1069);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        // pto: %pv_right_inline5402__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1081 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
        // pto: %pv_right_inline5402__ssa_v0
        ;
        uint64_t v1082 = (uint64_t) v38;
        TASSIGN(v1081, v1082);
        // pto: %539
        ;
        __gm__ float* v1083 = PTOAS__GLOBAL_TENSOR_DATA(v140);
        // pto: %539
        ;
        const int64_t v1084 = 256;
        // pto: %539
        ;
        const int64_t v1085 = 512;
        // pto: %539
        ;
        pto::Shape<1, 1, 1, 32, 256> v1086 = pto::Shape<1, 1, 1, 32, 256>();
        // pto: %539
        ;
        pto::Stride<16384, 16384, 16384, 512, 1> v1087 = pto::Stride<16384, 16384, 16384, 512, 1>();
        // pto: %539
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND> v1088 = GlobalTensor<float, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<16384, 16384, 16384, 512, 1>, pto::Layout::ND>(v1083 + (v1084 + v362 * v1085), v1086, v1087);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        TLOAD(v1081, v1088);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %t__tmp_v981
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1089 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
        // pto: %t__tmp_v981
        ;
        uint64_t v1090 = (uint64_t) v61;
        TASSIGN(v1089, v1090);
        pipe_barrier(PIPE_V);
        TROWEXPANDMUL(v1089, v359, v1062);
        // pto: %next_right_inline5355__ssa_v0
        ;
        Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1091 = Tile<TileType::Vec, float, 32, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v84, v88);
        // pto: %next_right_inline5355__ssa_v0
        ;
        uint64_t v1092 = (uint64_t) v41;
        TASSIGN(v1091, v1092);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        TADD(v1091, v1089, v1081);
      };
    };
    // pto: %540
    ;
    int32_t v1093 = (v2)[v327];
    // pto: %541, %542
    ;
    pipe_barrier(PIPE_ALL);
    if ((int64_t) v1093 >= v83) {
      // pto: %cs_ones_inline5161__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1094 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %cs_ones_inline5161__ssa_v0
      ;
      uint64_t v1095 = (uint64_t) v56;
      TASSIGN(v1094, v1095);
      pipe_barrier(PIPE_V);
      TEXPANDS(v1094, v87);
      // pto: %t__ci_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1096 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v98);
      // pto: %t__ci_tmp_v1
      ;
      uint64_t v1097 = (uint64_t) v38;
      TASSIGN(v1096, v1097);
      // pto: %t__tmp_v983
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1098 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %t__tmp_v983
      ;
      uint64_t v1099 = (uint64_t) v57;
      TASSIGN(v1098, v1099);
      // pto: %543
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1100;
      TRESHAPE(v1100, v1096);
      // pto: %544
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1101;
      TRESHAPE(v1101, v1098);
      TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v1101, v99, v1100);
      // pto: %cs_idx_f_inline5160__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1102 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %cs_idx_f_inline5160__ssa_v0
      ;
      uint64_t v1103 = (uint64_t) v38;
      TASSIGN(v1102, v1103);
      pipe_barrier(PIPE_V);
      RoundMode v1104 = RoundMode::CAST_ROUND;
      SaturationMode v1105 = SaturationMode::ON;
      TCVT(v1102, v1098, v1104, v1105);
      // pto: %cs_col_inline5374__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1106 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %cs_col_inline5374__ssa_v0
      ;
      uint64_t v1107 = (uint64_t) v51;
      TASSIGN(v1106, v1107);
      pipe_barrier(PIPE_V);
      TCOLEXPANDMUL(v1106, v1094, v1102);
      // pto: %t__tmp_v984
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1108 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %t__tmp_v984
      ;
      uint64_t v1109 = (uint64_t) v38;
      TASSIGN(v1108, v1109);
      pipe_barrier(PIPE_V);
      TMULS(v1108, v1106, v103);
      // pto: %cs_dup_i32_inline5168__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1110 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %cs_dup_i32_inline5168__ssa_v0
      ;
      uint64_t v1111 = (uint64_t) v38;
      TASSIGN(v1110, v1111);
      pipe_barrier(PIPE_V);
      RoundMode v1112 = RoundMode::CAST_TRUNC;
      SaturationMode v1113 = SaturationMode::ON;
      TCVT(v1110, v1108, v1112, v1113);
      // pto: %cs_dup_f_inline5159__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1114 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %cs_dup_f_inline5159__ssa_v0
      ;
      uint64_t v1115 = (uint64_t) v38;
      TASSIGN(v1114, v1115);
      pipe_barrier(PIPE_V);
      RoundMode v1116 = RoundMode::CAST_ROUND;
      SaturationMode v1117 = SaturationMode::ON;
      TCVT(v1114, v1110, v1116, v1117);
      // pto: %t__tmp_v985
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1118 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %t__tmp_v985
      ;
      uint64_t v1119 = (uint64_t) v38;
      TASSIGN(v1118, v1119);
      pipe_barrier(PIPE_V);
      TMULS(v1118, v1114, v104);
      // pto: %cs_lane_inline5158__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1120 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %cs_lane_inline5158__ssa_v0
      ;
      uint64_t v1121 = (uint64_t) v38;
      TASSIGN(v1120, v1121);
      pipe_barrier(PIPE_V);
      TSUB(v1120, v1106, v1118);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      // pto: %t__tmp_v986
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1122 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %t__tmp_v986
      ;
      uint64_t v1123 = (uint64_t) v38;
      TASSIGN(v1122, v1123);
      pipe_barrier(PIPE_V);
      TMULS(v1122, v1120, v104);
      // pto: %t__tmp_v987
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1124 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %t__tmp_v987
      ;
      uint64_t v1125 = (uint64_t) v38;
      TASSIGN(v1124, v1125);
      pipe_barrier(PIPE_V);
      TSUBS(v1124, v1122, v87);
      // pto: %cs_sign_inline5386__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1126 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %cs_sign_inline5386__ssa_v0
      ;
      uint64_t v1127 = (uint64_t) v38;
      TASSIGN(v1126, v1127);
      pipe_barrier(PIPE_V);
      TNEG(v1126, v1124);
      // pto: %cs_sin_inline5157__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1128 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %cs_sin_inline5157__ssa_v0
      ;
      uint64_t v1129 = (uint64_t) v51;
      TASSIGN(v1128, v1129);
      // pto: %545
      ;
      int64_t v1130 = v327 < v83 ? v83 : v327;
      // pto: %freqs_sin__ssa_v0_pview
      ;
      __gm__ float* v1131 = PTOAS__GLOBAL_TENSOR_DATA(v216);
      // pto: %freqs_sin__ssa_v0_pview
      ;
      const int64_t v1132 = 0;
      // pto: %freqs_sin__ssa_v0_pview
      ;
      const int64_t v1133 = 64;
      // pto: %freqs_sin__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 64> v1134 = pto::Shape<1, 1, 1, 1, 64>();
      // pto: %freqs_sin__ssa_v0_pview
      ;
      pto::Stride<64, 64, 64, 64, 1> v1135 = pto::Stride<64, 64, 64, 64, 1>();
      // pto: %freqs_sin__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v1136 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v1131 + (v1132 + v1130 * v1133), v1134, v1135);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v1128, v1136);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %m_sin_signed_inline5156__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1137 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %m_sin_signed_inline5156__ssa_v0
      ;
      uint64_t v1138 = (uint64_t) v64;
      TASSIGN(v1137, v1138);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      pipe_barrier(PIPE_V);
      TMUL(v1137, v1128, v1126);
      // pto: %m_cos_il_inline5173__ssa_v0
      ;
      Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1139 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %m_cos_il_inline5173__ssa_v0
      ;
      uint64_t v1140 = (uint64_t) v65;
      TASSIGN(v1139, v1140);
      // pto: %freqs_cos__ssa_v0_pview
      ;
      __gm__ float* v1141 = PTOAS__GLOBAL_TENSOR_DATA(v225);
      // pto: %freqs_cos__ssa_v0_pview
      ;
      const int64_t v1142 = 0;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      const int64_t v1143 = 64;
      // pto: %freqs_cos__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 64> v1144 = pto::Shape<1, 1, 1, 1, 64>();
      // pto: %freqs_cos__ssa_v0_pview
      ;
      pto::Stride<64, 64, 64, 64, 1> v1145 = pto::Stride<64, 64, 64, 64, 1>();
      // pto: %freqs_cos__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v1146 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v1141 + (v1142 + v1130 * v1143), v1144, v1145);
      TLOAD(v1139, v1146);
      // pto: %m_idx_inline5426__ci_tmp_v2
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1147 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v98);
      // pto: %m_idx_inline5426__ci_tmp_v2
      ;
      uint64_t v1148 = (uint64_t) v38;
      TASSIGN(v1147, v1148);
      // pto: %m_idx_inline5426__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1149 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %m_idx_inline5426__ssa_v0
      ;
      uint64_t v1150 = (uint64_t) v56;
      TASSIGN(v1149, v1150);
      // pto: %547
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1151;
      TRESHAPE(v1151, v1147);
      // pto: %548
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1152;
      TRESHAPE(v1152, v1149);
      pipe_barrier(PIPE_V);
      TCI<Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v1152, v99, v1151);
      // pto: %m_rem_tmp_inline5392__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1153 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %m_rem_tmp_inline5392__ssa_v0
      ;
      uint64_t v1154 = (uint64_t) v38;
      TASSIGN(v1153, v1154);
      // pto: %m_lane_inline5155__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1155 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %m_lane_inline5155__ssa_v0
      ;
      uint64_t v1156 = (uint64_t) v51;
      TASSIGN(v1155, v1156);
      pipe_barrier(PIPE_V);
      TREMS(v1155, v1149, v105, v1153);
      // pto: %t__tmp_v988
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1157 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %t__tmp_v988
      ;
      uint64_t v1158 = (uint64_t) v38;
      TASSIGN(v1157, v1158);
      pipe_barrier(PIPE_V);
      TMULS(v1157, v1155, v105);
      // pto: %t__tmp_v989
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1159 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %t__tmp_v989
      ;
      uint64_t v1160 = (uint64_t) v38;
      TASSIGN(v1159, v1160);
      pipe_barrier(PIPE_V);
      TSUB(v1159, v1149, v1157);
      // pto: %m_swap_row_inline5347__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1161 = Tile<TileType::Vec, int32_t, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v78);
      // pto: %m_swap_row_inline5347__ssa_v0
      ;
      uint64_t v1162 = (uint64_t) v66;
      TASSIGN(v1161, v1162);
      pipe_barrier(PIPE_V);
      TADDS(v1161, v1159, v106);
      // pto: %m_swap_base_inline5340__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1163 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
      // pto: %m_swap_base_inline5340__ssa_v0
      ;
      uint64_t v1164 = (uint64_t) v38;
      TASSIGN(v1163, v1164);
      // pto: %m_swap_source_inline5154__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1165 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
      // pto: %m_swap_source_inline5154__ssa_v0
      ;
      uint64_t v1166 = (uint64_t) v38;
      TASSIGN(v1165, v1166);
      pipe_barrier(PIPE_V);
      TCOLEXPAND(v1165, v1161);
      // pto: %t__ci_tmp_v3
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1167 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v98);
      // pto: %t__ci_tmp_v3
      ;
      uint64_t v1168 = (uint64_t) v66;
      TASSIGN(v1167, v1168);
      // pto: %t__tmp_v990
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1169 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
      // pto: %t__tmp_v990
      ;
      uint64_t v1170 = (uint64_t) v67;
      TASSIGN(v1169, v1170);
      // pto: %549
      ;
      Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1171;
      TRESHAPE(v1171, v1167);
      // pto: %550
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1172;
      TRESHAPE(v1172, v1169);
      pipe_barrier(PIPE_V);
      TCI<Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v1172, v99, v1171);
      // pto: %m_row_offsets_inline5249__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1173 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v85);
      // pto: %m_row_offsets_inline5249__ssa_v0
      ;
      uint64_t v1174 = (uint64_t) v66;
      TASSIGN(v1173, v1174);
      pipe_barrier(PIPE_V);
      TMULS(v1173, v1169, v107);
      // pto: %t__tmp_v991
      ;
      Tile<TileType::Vec, int32_t, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1175 = Tile<TileType::Vec, int32_t, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
      // pto: %t__tmp_v991
      ;
      uint64_t v1176 = (uint64_t) v66;
      TASSIGN(v1175, v1176);
      // pto: %m_swap_idx_inline5153__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1177 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
      // pto: %m_swap_idx_inline5153__ssa_v0
      ;
      uint64_t v1178 = (uint64_t) v61;
      TASSIGN(v1177, v1178);
      pipe_barrier(PIPE_V);
      TROWEXPANDADD(v1177, v1165, v1175);
      // pto: %m_gather_tmp_inline5151__ssa_v0
      ;
      Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1179 = Tile<TileType::Vec, int32_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
      // pto: %m_gather_tmp_inline5151__ssa_v0
      ;
      uint64_t v1180 = (uint64_t) v45;
      TASSIGN(v1179, v1180);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      for (int64_t v1181 = v83; v1181 < v90; v1181 += v72) {
        // pto: %551
        ;
        int64_t v1182 = (int64_t) ((uint64_t) v1181 * (uint64_t) v85);
        // pto: %m_li_inline5147__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1183 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v72);
        // pto: %m_li_inline5147__ssa_v0
        ;
        uint64_t v1184 = (uint64_t) v68;
        TASSIGN(v1183, v1184);
        // pto: %553
        ;
        int64_t v1185 = (int64_t) ((uint64_t) v361 + (uint64_t) v1182);
        // pto: %554
        ;
        int64_t v1186 = v1185 < v83 ? v83 : v1185;
        // pto: %555
        ;
        __gm__ float* v1187 = PTOAS__GLOBAL_TENSOR_DATA(v164);
        // pto: %555
        ;
        const int64_t v1188 = 0;
        // pto: %555
        ;
        pto::Shape<1, 1, 1, 8, 1> v1189 = pto::Shape<1, 1, 1, 8, 1>();
        // pto: %555
        ;
        pto::Stride<8, 8, 8, 1, 1536> v1190 = pto::Stride<8, 8, 8, 1, 1536>();
        // pto: %555
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN> v1191 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 1>, pto::Stride<8, 8, 8, 1, 1536>, pto::Layout::DN>(v1187 + (v1188 + v1186), v1189, v1190);
        wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        TLOAD(v1183, v1191);
        set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        // pto: %publish_left_inline5353__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1192 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v88);
        // pto: %publish_left_inline5353__ssa_v0
        ;
        uint64_t v1193 = (uint64_t) v43;
        TASSIGN(v1192, v1193);
        pipe_barrier(PIPE_V);
        uint16_t v1194 = static_cast<uint16_t>(v1182);
        uint16_t v1195 = static_cast<uint16_t>(v83);
        TEXTRACT(v1192, v357, v1194, v1195);
        // pto: %publish_right_inline5146__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1196 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v88);
        // pto: %publish_right_inline5146__ssa_v0
        ;
        uint64_t v1197 = (uint64_t) v69;
        TASSIGN(v1196, v1197);
        uint16_t v1198 = static_cast<uint16_t>(v1182);
        uint16_t v1199 = static_cast<uint16_t>(v83);
        TEXTRACT(v1196, v359, v1198, v1199);
        // pto: %m_oi_inline5145__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1200 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
        // pto: %m_oi_inline5145__ssa_v0
        ;
        uint64_t v1201 = (uint64_t) v38;
        TASSIGN(v1200, v1201);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
        TCONCAT(v1200, v1192, v1196);
        // pto: %n_full_inline5287__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1202 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
        // pto: %n_full_inline5287__ssa_v0
        ;
        uint64_t v1203 = (uint64_t) v38;
        TASSIGN(v1202, v1203);
        pipe_barrier(PIPE_V);
        wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
        TROWEXPANDDIV(v1202, v1200, v1183);
        set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
        // pto: %n_bf16_inline5144__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1204 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
        // pto: %n_bf16_inline5144__ssa_v0
        ;
        uint64_t v1205 = (uint64_t) v43;
        TASSIGN(v1204, v1205);
        pipe_barrier(PIPE_V);
        RoundMode v1206 = RoundMode::CAST_RINT;
        SaturationMode v1207 = SaturationMode::ON;
        TCVT(v1204, v1202, v1206, v1207);
        // pto: %n_rounded_inline5148__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1208 = Tile<TileType::Vec, float, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
        // pto: %n_rounded_inline5148__ssa_v0
        ;
        uint64_t v1209 = (uint64_t) v38;
        TASSIGN(v1208, v1209);
        pipe_barrier(PIPE_V);
        RoundMode v1210 = RoundMode::CAST_ROUND;
        SaturationMode v1211 = SaturationMode::ON;
        TCVT(v1208, v1204, v1210, v1211);
        // pto: %m_swapped_inline5143__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1212 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
        // pto: %m_swapped_inline5143__ssa_v0
        ;
        uint64_t v1213 = (uint64_t) v69;
        TASSIGN(v1212, v1213);
        pipe_barrier(PIPE_V);
        TGATHER(v1212, v1208, v1177, v1179);
        // pto: %m_rope_inline5399__ssa_v0_textract
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1214 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
        // pto: %m_rope_inline5399__ssa_v0_textract
        ;
        uint64_t v1215 = (uint64_t) v70;
        TASSIGN(v1214, v1215);
        uint16_t v1216 = static_cast<uint16_t>(v83);
        uint16_t v1217 = static_cast<uint16_t>(v101);
        TEXTRACT(v1214, v1208, v1216, v1217);
        // pto: %t__tmp_v992
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1218 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
        // pto: %t__tmp_v992
        ;
        uint64_t v1219 = (uint64_t) v38;
        TASSIGN(v1218, v1219);
        pipe_barrier(PIPE_V);
        TCOLEXPANDMUL(v1218, v1214, v1139);
        // pto: %t__tmp_v993
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1220 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
        // pto: %t__tmp_v993
        ;
        uint64_t v1221 = (uint64_t) v66;
        TASSIGN(v1220, v1221);
        TCOLEXPANDMUL(v1220, v1212, v1137);
        // pto: %m_rot_inline5276__ssa_v0
        ;
        Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1222 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
        // pto: %m_rot_inline5276__ssa_v0
        ;
        uint64_t v1223 = (uint64_t) v38;
        TASSIGN(v1222, v1223);
        pipe_barrier(PIPE_V);
        TADD(v1222, v1218, v1220);
        // pto: %n_rope_bf16_inline5142__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1224 = Tile<TileType::Vec, bfloat16_t, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v78);
        // pto: %n_rope_bf16_inline5142__ssa_v0
        ;
        uint64_t v1225 = (uint64_t) v71;
        TASSIGN(v1224, v1225);
        pipe_barrier(PIPE_V);
        RoundMode v1226 = RoundMode::CAST_RINT;
        SaturationMode v1227 = SaturationMode::ON;
        TCVT(v1224, v1222, v1226, v1227);
        // pto: %t__tmp_v994
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1228 = Tile<TileType::Vec, bfloat16_t, 8, 448, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v101);
        // pto: %t__tmp_v994
        ;
        uint64_t v1229 = (uint64_t) v43;
        TASSIGN(v1228, v1229);
        // pto: %556
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, 8, 448, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1230;
        // pto: %556
        ;
        uint64_t v1231 = (uint64_t) v43;
        TASSIGN(v1230, v1231);
        // pto: %n_full_bf16_inline5240__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1232 = Tile<TileType::Vec, bfloat16_t, 8, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v85, v73);
        // pto: %n_full_bf16_inline5240__ssa_v0
        ;
        uint64_t v1233 = (uint64_t) v38;
        TASSIGN(v1232, v1233);
        pipe_barrier(PIPE_V);
        TCONCAT(v1232, v1230, v1224);
        set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        // pto: %publish_row_inline5141__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1234 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v108);
        // pto: %publish_row_inline5141__ssa_v0
        ;
        uint64_t v1235 = (uint64_t) v38;
        TASSIGN(v1234, v1235);
        // pto: %558, %559
        ;
        int64_t v1236 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v333 + (uint64_t) v1182) * (uint64_t) v73);
        // pto: %560
        ;
        int64_t v1237 = v1236 < v83 ? v83 : v1236;
        // pto: %heads__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v1238 = PTOAS__GLOBAL_TENSOR_DATA(v234);
        // pto: %heads__ssa_v0_pview
        ;
        const int64_t v1239 = 0;
        // pto: %heads__ssa_v0_pview
        ;
        const int64_t v1240 = 32768;
        // pto: %heads__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1241 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %heads__ssa_v0_pview
        ;
        pto::Stride<32768, 32768, 32768, 32768, 1> v1242 = pto::Stride<32768, 32768, 32768, 32768, 1>();
        // pto: %heads__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<32768, 32768, 32768, 32768, 1>, pto::Layout::ND> v1243 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<32768, 32768, 32768, 32768, 1>, pto::Layout::ND>(v1238 + (v1239 + v1130 * v1240 + v1237), v1241, v1242);
        wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
        TSTORE(v1243, v1234);
        set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      };
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    } else {
      // pto: %publish_zero_inline5203__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1244 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v72, v108);
      // pto: %publish_zero_inline5203__ssa_v0
      ;
      uint64_t v1245 = (uint64_t) v38;
      TASSIGN(v1244, v1245);
      pipe_barrier(PIPE_V);
      TEXPANDS(v1244, v91);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      for (int64_t v1246 = v83; v1246 < v90; v1246 += v72) {
        // pto: %561
        ;
        int64_t v1247 = v327 < v83 ? v83 : v327;
        // pto: %563, %562, %564
        ;
        int64_t v1248 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v333 + (uint64_t) ((int64_t) (uint64_t) v1246 * (uint64_t) v85)) * (uint64_t) v73);
        // pto: %565
        ;
        int64_t v1249 = v1248 < v83 ? v83 : v1248;
        // pto: %566
        ;
        __gm__ bfloat16_t* v1250 = PTOAS__GLOBAL_TENSOR_DATA(v234);
        // pto: %566
        ;
        const int64_t v1251 = 0;
        // pto: %566
        ;
        const int64_t v1252 = 32768;
        // pto: %566
        ;
        pto::Shape<1, 1, 1, 1, 4096> v1253 = pto::Shape<1, 1, 1, 1, 4096>();
        // pto: %566
        ;
        pto::Stride<32768, 32768, 32768, 32768, 1> v1254 = pto::Stride<32768, 32768, 32768, 32768, 1>();
        // pto: %566
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<32768, 32768, 32768, 32768, 1>, pto::Layout::ND> v1255 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<32768, 32768, 32768, 32768, 1>, pto::Layout::ND>(v1250 + (v1251 + v1247 * v1252 + v1249), v1253, v1254);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v1255, v1244);
      };
    };
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}