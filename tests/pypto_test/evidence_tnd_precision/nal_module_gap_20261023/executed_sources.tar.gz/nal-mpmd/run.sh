#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
label=${1:?}; batch=${2:?}; history=${3:?}; mode=${4:?}
[[ "$label" =~ ^[a-z0-9-]+$ && "$batch" =~ ^[0-9]+$ && "$history" =~ ^[0-9]+$ ]]
[[ "$mode" == timing || "$mode" == dfx || "$mode" == dep || "$mode" == both ]]
shift 4
if (( $# )); then
  [[ $# == 2 && "$1" == --device && "$2" == "$TASK_DEVICE" ]] || exit 2
fi
tw_job_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$tw_job_root/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
out="$tw_job_root/results/$label"
test ! -e "$out"
mkdir -p "$tw_job_root/results"
export PREFLIGHT_RECEIPT="$out-preflight.json"
export ASCEND_CACHE_PATH="$out-ascend-cache" ASCEND_PROCESS_LOG_PATH="$out-ascend-log" VLLM_CACHE_ROOT="$out-vllm-cache"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out-opp-env")
lengths=6
for ((i=1;i<batch;i++)); do lengths+=,6; done
ccache -s > "$out-ccache.txt"
printf 'TASK_RUN_START %s\n' "$(date -Iseconds)"
trap 'printf "TASK_RUN_END %s\n" "$(date -Iseconds)"' EXIT
timeout --signal=TERM --kill-after=15s 750s python "$tw_job_root/device.py" --out "$out" --lengths "$lengths" --layer 4 --history "$history" --mode "$mode" > "$out-run.log" 2>&1
