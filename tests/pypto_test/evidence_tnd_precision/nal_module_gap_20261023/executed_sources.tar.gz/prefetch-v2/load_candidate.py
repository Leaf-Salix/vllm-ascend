"""下一块KV独立双缓冲预取单因素与已验收组合版；不修改共享原模块。"""
import importlib,importlib.util,sys,json,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent
C='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_combined'
S='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd'
def load(name,path):
    if name in sys.modules:return sys.modules[name]
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec)
    sys.modules[name]=m;spec.loader.exec_module(m);return m
def entry_for(arm):
    proof=json.loads((HERE/'SOURCE.json').read_text())
    for rel,sha in proof['candidates'].items():assert hashlib.sha256((HERE/rel).read_bytes()).hexdigest()==sha,rel
    if arm=='baseline':return importlib.import_module(C+'.decode_csa').decode_csa_tp1_layer_test
    assert arm=='prefetch'
    load('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.gap_prefetch_sparse',HERE/'prefetch_sparse.py')
    return load(C+'.gap_prefetch_root',HERE/'prefetch_root.py').decode_csa_tp1_layer_test

def operators_for(arm):
    if arm=='baseline':return importlib.import_module(C+'.native_adapter').CSAOperators.register()
    import pypto.torch
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.native_adapter import CSAOperators
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_prepack.native_adapter import PrepackedWorkspace
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_prepack.prefix import prepack_fixed_hc_weight
    op=pypto.torch.register(entry_for(arm),'csa_gap_prefetch::attention')
    prepare=pypto.torch.register(prepack_fixed_hc_weight,'csa_gap_prefetch::prepare')
    return CSAOperators(op,PrepackedWorkspace(prepare))
