"""Compile entire roots and actual native ABI without initializing NPU."""
import hashlib, importlib, json, os, runpy, sys, traceback, types
from pathlib import Path
root=Path(__file__).resolve().parent
arm=sys.argv[1]
assert arm in ('nal8k','nal128k')
runpy.run_path(str(root/'sdk_bind.py'),run_name='__sdk_preflight__')
import torch_npu
assert not torch_npu.npu.is_initialized()
from source_identity import source_identity
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program
from pypto.runtime._kernel_artifact import KernelArtifact
out=root/('cpu-'+arm)
out.mkdir(exist_ok=False)
record={'pass':False,'device_execution':False,'arm':arm,'source':source_identity(),
        'sdk':json.loads(Path(os.environ['PREFLIGHT_RECEIPT']).read_text()),
        'helper_manifest_sha256':hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),
        'nal_compatibility_sha256':hashlib.sha256((root/'NAL_COMPATIBILITY.json').read_bytes()).hexdigest()}
try:
 if arm=='ours':
  entry=importlib.import_module('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.decode_csa').decode_csa_tp1_layer_test
  program=entry.specialize()
 else:
  package=types.ModuleType('nal_isolated');package.__path__=[str(root/'nal-packages')];sys.modules['nal_isolated']=package
  entry=importlib.import_module('nal_isolated.deepseek_v4_flash_csa_spmd_tnd.entry').decode_csa_spmd
  policy=importlib.import_module('nal_isolated.deepseek_v4_flash_csa_spmd_tnd.policy').select_policy
  config=policy(tokens=192 if arm=='nal8k' else 96,requests=32 if arm=='nal8k' else 16,
                max_query_tokens=6,max_seq_len=8198 if arm=='nal8k' else 131078)
  record['policy']=config.constexprs()
  program=entry.specialize(**config.constexprs())
 abi=kernel_abi_for_program(program,platform='a2a3',runtime='tensormap_and_ringbuffer')
 record['root_tensors']=len(abi.parameters)
 _compile_impl(program,output_dir=str(out/'kernel'),platform='a2a3',skip_ptoas=False,_kernel_abi=abi)
 artifact=KernelArtifact(out/'kernel',abi);artifact.load()
 record['artifact_identity']=artifact.identity().hex()
 record['npu_initialized']=torch_npu.npu.is_initialized()
 assert record['npu_initialized'] is False
 record['pass']=True
except BaseException:
 record['error']=traceback.format_exc()
finally:
 (out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record,indent=2),flush=True)
if not record['pass']:raise SystemExit(1)
