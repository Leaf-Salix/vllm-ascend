#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void packed_prefix_indexer_cube(__gm__ float* v1, __gm__ float* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, __gm__ float* v5, __gm__ bfloat16_t* v6, __gm__ bfloat16_t* v7, __gm__ int32_t* v8, __gm__ float* v9, __gm__ int64_t* v10, __gm__ bfloat16_t* v11, __gm__ int32_t* v12, __gm__ float* v13, __gm__ bfloat16_t* v14, __gm__ float* v15, __gm__ float* v16, __gm__ float* v17, __gm__ float* v18, __gm__ float* v19, __gm__ float* v20, __gm__ float* v21, __gm__ float* v22, __gm__ bfloat16_t* v23, __gm__ bfloat16_t* v24, __gm__ bfloat16_t* v25, __gm__ float* v26, __gm__ bfloat16_t* v27, __gm__ float* v28, __gm__ bfloat16_t* v29, __gm__ bfloat16_t* v30, __gm__ half* v31, int64_t v32, int64_t v33, int64_t v34, int64_t v35, int64_t v36, int32_t v37, int32_t v38) {
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %c0_i64
  const int64_t v39 = 0;
  // pto: %c32768_i64
  const int64_t v40 = 32768;
  // pto: %c2048_i64
  const int64_t v41 = 2048;
  // pto: %c16384_index
  const int64_t v42 = 16384;
  // pto: %c1_index
  const int64_t v43 = 1;
  // pto: %c16_index
  const int64_t v44 = 16;
  // pto: %c32768_index
  const int64_t v45 = 32768;
  const int64_t v46 = 32;
  // pto: %c4096_index
  const int64_t v47 = 4096;
  // pto: %c512_index
  const int64_t v48 = 512;
  const int64_t v49 = 64;
  // pto: %c4_index
  const int64_t v50 = 4;
  // pto: %c24_index
  const int64_t v51 = 24;
  // pto: %c22_index
  const int64_t v52 = 22;
  // pto: %c21_index
  const int64_t v53 = 21;
  // pto: %c0_index
  const int64_t v54 = 0;
  // pto: %c768_index
  const int64_t v55 = 768;
  // pto: %c2_index
  const int64_t v56 = 2;
  // pto: %cn1_index
  const int64_t v57 = -1;
  // pto: %c63_index
  const int64_t v58 = 63;
  // pto: %c1536_index
  const int64_t v59 = 1536;
  // pto: %c128_index
  const int64_t v60 = 128;
  // pto: %c15_index
  const int64_t v61 = 15;
  // pto: %c256_index
  const int64_t v62 = 256;
  // pto: %wide__ssa_v0_view
  const int64_t v63 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v64 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v65 = 1;
  // pto: %wide__ssa_v0_view
  int64_t v66 = (int64_t) v32;
  // pto: %wide__ssa_v0_view
  int64_t v67 = v66 * v42;
  // pto: %wide__ssa_v0_view
  int64_t v68 = v65 * v67;
  // pto: %wide__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v69 = pto::Shape<1, 1, 1, -1, -1>(v63, v64, v65, v66, v42);
  // pto: %wide__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v70 = pto::Stride<-1, -1, -1, -1, -1>(v64 * v68, v68, v67, v42, v43);
  // pto: %wide__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v71 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v69, v70);
  // pto: %square__ssa_v0_view
  const int64_t v72 = 1;
  // pto: %square__ssa_v0_view
  const int64_t v73 = 1;
  // pto: %square__ssa_v0_view
  const int64_t v74 = 1;
  // pto: %square__ssa_v0_view
  int64_t v75 = (int64_t) v33;
  // pto: %square__ssa_v0_view
  int64_t v76 = v75 * v44;
  // pto: %square__ssa_v0_view
  int64_t v77 = v74 * v76;
  // pto: %square__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v78 = pto::Shape<1, 1, 1, -1, -1>(v72, v73, v74, v75, v44);
  // pto: %square__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v79 = pto::Stride<-1, -1, -1, -1, -1>(v73 * v77, v77, v76, v44, v43);
  // pto: %square__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v80 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v2, v78, v79);
  // pto: %packed_weight__ssa_v0_view
  const int64_t v81 = 1;
  // pto: %packed_weight__ssa_v0_view
  const int64_t v82 = 1;
  // pto: %packed_weight__ssa_v0_view
  const int64_t v83 = 1;
  // pto: %packed_weight__ssa_v0_view
  int64_t v84 = v45 * v46;
  // pto: %packed_weight__ssa_v0_view
  int64_t v85 = v83 * v84;
  // pto: %packed_weight__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v86 = pto::Shape<1, 1, 1, -1, -1>(v81, v82, v83, v45, v46);
  // pto: %packed_weight__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v87 = pto::Stride<-1, -1, -1, -1, -1>(v82 * v85, v85, v84, v46, v43);
  // pto: %packed_weight__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v88 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v3, v86, v87);
  // pto: %packed_flat__ssa_v0_view
  const int64_t v89 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v90 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v91 = 1;
  // pto: %packed_flat__ssa_v0_view
  int64_t v92 = (int64_t) v34;
  // pto: %packed_flat__ssa_v0_view
  int64_t v93 = v92 * v45;
  // pto: %packed_flat__ssa_v0_view
  int64_t v94 = v91 * v93;
  // pto: %packed_flat__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v95 = pto::Shape<1, 1, 1, -1, -1>(v89, v90, v91, v92, v45);
  // pto: %packed_flat__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v96 = pto::Stride<-1, -1, -1, -1, -1>(v90 * v94, v94, v93, v45, v43);
  // pto: %packed_flat__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v97 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v95, v96);
  // pto: %linear__ssa_v0_view
  const int64_t v98 = 1;
  // pto: %linear__ssa_v0_view
  const int64_t v99 = 1;
  // pto: %linear__ssa_v0_view
  const int64_t v100 = 1;
  // pto: %linear__ssa_v0_view
  int64_t v101 = (int64_t) v33;
  // pto: %linear__ssa_v0_view
  int64_t v102 = v101 * v46;
  // pto: %linear__ssa_v0_view
  int64_t v103 = v100 * v102;
  // pto: %linear__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v104 = pto::Shape<1, 1, 1, -1, -1>(v98, v99, v100, v101, v46);
  // pto: %linear__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v105 = pto::Stride<-1, -1, -1, -1, -1>(v99 * v103, v103, v102, v46, v43);
  // pto: %linear__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v106 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v5, v104, v105);
  // pto: %normalized__ssa_v0_view
  const int64_t v107 = 1;
  // pto: %normalized__ssa_v0_view
  const int64_t v108 = 1;
  // pto: %normalized__ssa_v0_view
  const int64_t v109 = 1;
  // pto: %normalized__ssa_v0_view
  int64_t v110 = (int64_t) v32;
  // pto: %normalized__ssa_v0_view
  int64_t v111 = v110 * v47;
  // pto: %normalized__ssa_v0_view
  int64_t v112 = v109 * v111;
  // pto: %normalized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v113 = pto::Shape<1, 1, 1, -1, -1>(v107, v108, v109, v110, v47);
  // pto: %normalized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v114 = pto::Stride<-1, -1, -1, -1, -1>(v108 * v112, v112, v111, v47, v43);
  // pto: %normalized__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v115 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v113, v114);
  // pto: %weight__ssa_v0_view
  const int64_t v116 = 1;
  // pto: %weight__ssa_v0_view
  const int64_t v117 = 1;
  // pto: %weight__ssa_v0_view
  const int64_t v118 = 1;
  // pto: %weight__ssa_v0_view
  int64_t v119 = v48 * v47;
  // pto: %weight__ssa_v0_view
  int64_t v120 = v118 * v119;
  // pto: %weight__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v121 = pto::Shape<1, 1, 1, -1, -1>(v116, v117, v118, v48, v47);
  // pto: %weight__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v122 = pto::Stride<-1, -1, -1, -1, -1>(v117 * v120, v120, v119, v47, v43);
  // pto: %weight__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v123 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v7, v121, v122);
  // pto: %accum__ssa_v0_view
  const int64_t v124 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v125 = 1;
  // pto: %accum__ssa_v0_view
  const int64_t v126 = 1;
  // pto: %accum__ssa_v0_view
  int64_t v127 = (int64_t) v35;
  // pto: %accum__ssa_v0_view
  int64_t v128 = v127 * v48;
  // pto: %accum__ssa_v0_view
  int64_t v129 = v126 * v128;
  // pto: %accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v130 = pto::Shape<1, 1, 1, -1, -1>(v124, v125, v126, v127, v48);
  // pto: %accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v131 = pto::Stride<-1, -1, -1, -1, -1>(v125 * v129, v129, v128, v48, v43);
  // pto: %accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v132 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v9, v130, v131);
  // pto: %idx_weight__ssa_v0_view
  const int64_t v133 = 1;
  // pto: %idx_weight__ssa_v0_view
  const int64_t v134 = 1;
  // pto: %idx_weight__ssa_v0_view
  const int64_t v135 = 1;
  // pto: %idx_weight__ssa_v0_view
  int64_t v136 = v49 * v47;
  // pto: %idx_weight__ssa_v0_view
  int64_t v137 = v135 * v136;
  // pto: %idx_weight__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v138 = pto::Shape<1, 1, 1, -1, -1>(v133, v134, v135, v49, v47);
  // pto: %idx_weight__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v139 = pto::Stride<-1, -1, -1, -1, -1>(v134 * v137, v137, v136, v47, v43);
  // pto: %idx_weight__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v140 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v11, v138, v139);
  // pto: %idx_accum__ssa_v0_view
  const int64_t v141 = 1;
  // pto: %idx_accum__ssa_v0_view
  const int64_t v142 = 1;
  // pto: %idx_accum__ssa_v0_view
  const int64_t v143 = 1;
  // pto: %idx_accum__ssa_v0_view
  int64_t v144 = (int64_t) v34;
  // pto: %idx_accum__ssa_v0_view
  int64_t v145 = v144 * v49;
  // pto: %idx_accum__ssa_v0_view
  int64_t v146 = v143 * v145;
  // pto: %idx_accum__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v147 = pto::Shape<1, 1, 1, -1, -1>(v141, v142, v143, v144, v49);
  // pto: %idx_accum__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v148 = pto::Stride<-1, -1, -1, -1, -1>(v142 * v146, v146, v145, v49, v43);
  // pto: %idx_accum__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v149 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v13, v147, v148);
  // pto: %native_sq_acc_inline1261__rv_v2
  Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v150 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v44);
  // pto: %native_sq_acc_inline1261__rv_v2
  uint64_t v151 = (uint64_t) v39;
  TASSIGN(v150, v151);
  uint64_t v152 = reinterpret_cast<uint64_t>(v10);
  set_ffts_base_addr(v152);
  // pto: %worker__ssa_v0
  int64_t v153 = (int64_t) v37;
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %17
  int64_t v154 = v33 / v52;
  // pto: %18
  bool v155 = v32 >= v49;
  // pto: %sq_group_inline1264__phi_v2
  int64_t v156 = v155 ? v50 : v43;
  // pto: %19, %20
  int64_t v157 = (int64_t) ((uint64_t) v156 + (uint64_t) v53) / v156;
  // pto: %21, %22
  for (int64_t v158 = v153; v158 < ((int64_t) ((uint64_t) (v154 / v44) * (uint64_t) v157)); v158 += v51) {
    // pto: %23, %24
    ;
    int64_t v159 = (int64_t) ((uint64_t) (v158 / v157) * (uint64_t) v44);
    // pto: %25, %26
    ;
    int64_t v160 = (int64_t) ((uint64_t) (v158 % v157) * (uint64_t) v156);
    // pto: %27
    ;
    int64_t v161 = (int64_t) ((uint64_t) v32 - (uint64_t) v159);
    // pto: %28
    ;
    int64_t v162 = v161 < v44 ? v161 : v44;
    // pto: %29
    ;
    int64_t v163 = (int64_t) ((uint64_t) v52 - (uint64_t) v160);
    // pto: %30
    ;
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    for (int64_t v164 = v54; v164 < (v156 < v163 ? v156 : v163); v164 += v43) {
      // pto: %31
      ;
      int64_t v165 = (int64_t) ((uint64_t) v160 + (uint64_t) v164);
      // pto: %32
      ;
      int64_t v166 = (int64_t) ((uint64_t) v165 * (uint64_t) v55);
      // pto: %33
      ;
      int64_t v167 = (int64_t) ((uint64_t) v42 - (uint64_t) v166);
      // pto: %34
      ;
      int64_t v168 = v167 < v55 ? v167 : v55;
      // pto: %35
      ;
      int64_t v169 = v168 / v46;
      // pto: %native_sq_acc_inline1261__tile
      ;
      Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v170 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v44);
      // pto: %native_sq_acc_inline1261__tile
      ;
      uint64_t v171 = (uint64_t) v39;
      TASSIGN(v170, v171);
      // pto: %36
      ;
      int64_t v172 = v169 / v56;
      // pto: %37
      ;
      int64_t v173 = (int64_t) ((uint64_t) v172 * (uint64_t) v56);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      for (int64_t v174 = v54; v174 < v173; v174 += v56) {
        // pto: %39
        ;
        int64_t v175 = (int64_t) ((uint64_t) v174 * (uint64_t) v46);
        // pto: %40
        ;
        int64_t v176 = (int64_t) ((uint64_t) v166 + (uint64_t) v175);
        // pto: %44, %43
        ;
        int64_t v177 = (int64_t) ((uint64_t) v166 + (uint64_t) ((int64_t) (uint64_t) v175 + (uint64_t) v46));
        // pto: %sq_lhs_inline1254__tile
        ;
        Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v178 = Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v162, v46);
        // pto: %sq_lhs_inline1254__tile
        ;
        uint64_t v179 = (uint64_t) v39;
        TASSIGN(v178, v179);
        // pto: %45
        ;
        int64_t v180 = v159 < v54 ? v54 : v159;
        // pto: %46
        ;
        int64_t v181 = v176 < v54 ? v54 : v176;
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v182 = 0;
        // pto: %wide__ssa_v0_pview
        ;
        __gm__ float* v183 = PTOAS__GLOBAL_TENSOR_DATA(v71);
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v184 = 1;
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v185 = 1;
        // pto: %wide__ssa_v0_pview
        ;
        const int64_t v186 = 1;
        // pto: %wide__ssa_v0_pview
        ;
        int64_t v187 = v162 * v42;
        // pto: %wide__ssa_v0_pview
        ;
        int64_t v188 = v186 * v187;
        // pto: %wide__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 32> v189 = pto::Shape<1, 1, 1, -1, 32>(v184, v185, v186, v162, v46);
        // pto: %wide__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v190 = pto::Stride<-1, -1, -1, -1, -1>(v185 * v188, v188, v187, v42, v43);
        // pto: %wide__ssa_v0_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v191 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v183 + (v182 + v180 * v42 + v181 * v43), v189, v190);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v178, v191);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %0
        ;
        Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v192 = Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v162, v46);
        // pto: %0
        ;
        uint64_t v193 = (uint64_t) v40;
        TASSIGN(v192, v193);
        // pto: %48
        ;
        int64_t v194 = v177 < v54 ? v54 : v177;
        // pto: %49
        ;
        const int64_t v195 = 0;
        // pto: %49
        ;
        __gm__ float* v196 = PTOAS__GLOBAL_TENSOR_DATA(v71);
        // pto: %49
        ;
        const int64_t v197 = 1;
        // pto: %49
        ;
        const int64_t v198 = 1;
        // pto: %49
        ;
        const int64_t v199 = 1;
        // pto: %49
        ;
        int64_t v200 = v162 * v42;
        // pto: %49
        ;
        int64_t v201 = v199 * v200;
        // pto: %49
        ;
        pto::Shape<1, 1, 1, -1, 32> v202 = pto::Shape<1, 1, 1, -1, 32>(v197, v198, v199, v162, v46);
        // pto: %49
        ;
        pto::Stride<-1, -1, -1, -1, -1> v203 = pto::Stride<-1, -1, -1, -1, -1>(v198 * v201, v201, v200, v42, v43);
        // pto: %49
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v204 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v196 + (v195 + v180 * v42 + v194 * v43), v202, v203);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        TLOAD(v192, v204);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %sq_lhs_inline1254__tile_t
        ;
        Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v205 = Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v162);
        // pto: %sq_lhs_inline1254__tile_t
        ;
        uint64_t v206 = (uint64_t) v39;
        TASSIGN(v205, v206);
        // pto: %sq_lhs_inline1254__tile_Left
        ;
        Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v207 = Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v162, v46);
        // pto: %sq_lhs_inline1254__tile_Left
        ;
        uint64_t v208 = (uint64_t) v41;
        TASSIGN(v207, v208);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        TMOV(v207, v178);
        // pto: %sq_lhs_inline1254__tile_t_Right
        ;
        Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v209 = Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v162);
        // pto: %sq_lhs_inline1254__tile_t_Right
        ;
        uint64_t v210 = (uint64_t) v41;
        TASSIGN(v209, v210);
        TMOV(v209, v205);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        // pto: %50
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
        if (v174 == v54) {
          pipe_barrier(PIPE_M);
          TMATMUL(v170, v207, v209);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v170, v170, v207, v209);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        // pto: %2
        ;
        Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v211 = Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v162);
        // pto: %2
        ;
        uint64_t v212 = (uint64_t) v40;
        TASSIGN(v211, v212);
        // pto: %3
        ;
        Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v213 = Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v162, v46);
        // pto: %3
        ;
        uint64_t v214 = (uint64_t) v39;
        TASSIGN(v213, v214);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
        TMOV(v213, v192);
        // pto: %4
        ;
        Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v215 = Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v162);
        // pto: %4
        ;
        uint64_t v216 = (uint64_t) v39;
        TASSIGN(v215, v216);
        TMOV(v215, v211);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        // pto: %51
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID1);
        if (v174 == v57) {
          pipe_barrier(PIPE_M);
          TMATMUL(v170, v213, v215);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v170, v170, v213, v215);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      // pto: %52, %53
      ;
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID3);
      if ((int64_t) ((uint64_t) v169 - (uint64_t) v173) == v43) {
        // pto: %56
        ;
        int64_t v217 = (int64_t) ((uint64_t) v166 + (uint64_t) ((int64_t) (uint64_t) v172 * (uint64_t) v49));
        // pto: %6
        ;
        Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v218 = Tile<TileType::Mat, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v162, v46);
        // pto: %6
        ;
        uint64_t v219 = (uint64_t) v39;
        TASSIGN(v218, v219);
        // pto: %57
        ;
        int64_t v220 = v159 < v54 ? v54 : v159;
        // pto: %58
        ;
        int64_t v221 = v217 < v54 ? v54 : v217;
        // pto: %59
        ;
        const int64_t v222 = 0;
        // pto: %59
        ;
        __gm__ float* v223 = PTOAS__GLOBAL_TENSOR_DATA(v71);
        // pto: %59
        ;
        const int64_t v224 = 1;
        // pto: %59
        ;
        const int64_t v225 = 1;
        // pto: %59
        ;
        const int64_t v226 = 1;
        // pto: %59
        ;
        int64_t v227 = v162 * v42;
        // pto: %59
        ;
        int64_t v228 = v226 * v227;
        // pto: %59
        ;
        pto::Shape<1, 1, 1, -1, 32> v229 = pto::Shape<1, 1, 1, -1, 32>(v224, v225, v226, v162, v46);
        // pto: %59
        ;
        pto::Stride<-1, -1, -1, -1, -1> v230 = pto::Stride<-1, -1, -1, -1, -1>(v225 * v228, v228, v227, v42, v43);
        // pto: %59
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v231 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v223 + (v222 + v220 * v42 + v221 * v43), v229, v230);
        TLOAD(v218, v231);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        // pto: %7
        ;
        Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v232 = Tile<TileType::Mat, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v162);
        // pto: %7
        ;
        uint64_t v233 = (uint64_t) v39;
        TASSIGN(v232, v233);
        // pto: %8
        ;
        Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v234 = Tile<TileType::Left, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v162, v46);
        // pto: %8
        ;
        uint64_t v235 = (uint64_t) v41;
        TASSIGN(v234, v235);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID2);
        TMOV(v234, v218);
        // pto: %9
        ;
        Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v236 = Tile<TileType::Right, float, 32, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v46, v162);
        // pto: %9
        ;
        uint64_t v237 = (uint64_t) v41;
        TASSIGN(v236, v237);
        TMOV(v236, v232);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        // pto: %60
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID2);
        if (v173 == v54) {
          pipe_barrier(PIPE_M);
          TMATMUL(v170, v234, v236);
        } else {
          pipe_barrier(PIPE_M);
          TMATMUL_ACC(v170, v170, v234, v236);
        };
      };
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %61, %62
      ;
      int64_t v238 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v165 * (uint64_t) v154) + (uint64_t) v159);
      // pto: %63
      ;
      int64_t v239 = v238 < v54 ? v54 : v238;
      // pto: %square__iter_v3_pview
      ;
      __gm__ float* v240 = PTOAS__GLOBAL_TENSOR_DATA(v80);
      // pto: %square__iter_v3_pview
      ;
      const int64_t v241 = 0;
      // pto: %square__iter_v3_pview
      ;
      const int64_t v242 = 16;
      // pto: %square__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 16, 16> v243 = pto::Shape<1, 1, 1, 16, 16>();
      // pto: %square__iter_v3_pview
      ;
      pto::Stride<256, 256, 256, 16, 1> v244 = pto::Stride<256, 256, 256, 16, 1>();
      // pto: %square__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<256, 256, 256, 16, 1>, pto::Layout::ND> v245 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<256, 256, 256, 16, 1>, pto::Layout::ND>(v240 + (v241 + v239 * v242), v243, v244);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
      pipe_barrier(PIPE_FIX);
      TSTORE(v245, v150);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    };
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID4);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID1);
  if (v155) {
    // pto: %65, %66
    ;
    int64_t v246 = (int64_t) ((uint64_t) v34 + (uint64_t) v58) / v49;
    // pto: %67
    ;
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    for (int64_t v247 = v153; v247 < ((int64_t) ((uint64_t) v246 * (uint64_t) v52)); v247 += v51) {
      // pto: %70
      ;
      int64_t v248 = v247 / v246;
      // pto: %73, %74
      ;
      int64_t v249 = (int64_t) ((uint64_t) (v247 % v246) * (uint64_t) v49);
      // pto: %75
      ;
      int64_t v250 = (int64_t) ((uint64_t) v34 - (uint64_t) v249);
      // pto: %76
      ;
      int64_t v251 = v250 < v49 ? v250 : v49;
      // pto: %78, %77
      ;
      int64_t v252 = (int64_t) ((uint64_t) v42 - (uint64_t) ((int64_t) (uint64_t) v248 * (uint64_t) v55));
      // pto: %79
      ;
      int64_t v253 = v252 < v55 ? v252 : v55;
      // pto: %80
      ;
      // pto: %81
      ;
      int64_t v254 = (int64_t) ((uint64_t) v248 * (uint64_t) v59);
      // pto: %panel64_wide_first_x_inline1290__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v255 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v251, v60);
      // pto: %panel64_wide_first_x_inline1290__tile
      ;
      uint64_t v256 = (uint64_t) v39;
      TASSIGN(v255, v256);
      // pto: %82
      ;
      int64_t v257 = v249 < v54 ? v54 : v249;
      // pto: %83
      ;
      int64_t v258 = v254 < v54 ? v54 : v254;
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v259 = 0;
      // pto: %packed_flat__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v260 = PTOAS__GLOBAL_TENSOR_DATA(v97);
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v261 = 1;
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v262 = 1;
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v263 = 1;
      // pto: %packed_flat__ssa_v0_pview
      ;
      int64_t v264 = v251 * v45;
      // pto: %packed_flat__ssa_v0_pview
      ;
      int64_t v265 = v263 * v264;
      // pto: %packed_flat__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 128> v266 = pto::Shape<1, 1, 1, -1, 128>(v261, v262, v263, v251, v60);
      // pto: %packed_flat__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v267 = pto::Stride<-1, -1, -1, -1, -1>(v262 * v265, v265, v264, v45, v43);
      // pto: %packed_flat__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v268 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v260 + (v259 + v257 * v45 + v258 * v43), v266, v267);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      TLOAD(v255, v268);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      // pto: %panel64_wide_first_w_inline1292__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v269 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
      // pto: %panel64_wide_first_w_inline1292__tile
      ;
      uint64_t v270 = (uint64_t) v40;
      TASSIGN(v269, v270);
      // pto: %packed_weight__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v271 = PTOAS__GLOBAL_TENSOR_DATA(v88);
      // pto: %packed_weight__ssa_v0_pview
      ;
      const int64_t v272 = 0;
      // pto: %packed_weight__ssa_v0_pview
      ;
      const int64_t v273 = 32;
      // pto: %packed_weight__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 128, 32> v274 = pto::Shape<1, 1, 1, 128, 32>();
      // pto: %packed_weight__ssa_v0_pview
      ;
      pto::Stride<4096, 4096, 4096, 32, 1> v275 = pto::Stride<4096, 4096, 4096, 32, 1>();
      // pto: %packed_weight__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v276 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v271 + (v272 + v258 * v273), v274, v275);
      TLOAD(v269, v276);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      // pto: %panel64_wide_first_x_inline1290__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v277 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v251, v60);
      // pto: %panel64_wide_first_x_inline1290__tile_Left
      ;
      uint64_t v278 = (uint64_t) v41;
      TASSIGN(v277, v278);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID3);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      TMOV(v277, v255);
      // pto: %panel64_wide_first_w_inline1292__tile_Right
      ;
      Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v279 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
      // pto: %panel64_wide_first_w_inline1292__tile_Right
      ;
      uint64_t v280 = (uint64_t) v41;
      TASSIGN(v279, v280);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID4);
      TMOV(v279, v269);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      // pto: %panel64_wide_accumulator_inline1293__tile
      ;
      Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v281 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v251, v46);
      // pto: %panel64_wide_accumulator_inline1293__tile
      ;
      uint64_t v282 = (uint64_t) v39;
      TASSIGN(v281, v282);
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID3);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
      TMATMUL(v281, v277, v279);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID6);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID6);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      for (int64_t v283 = v43; v283 < (v253 / v49); v283 += v43) {
        // pto: %87, %86
        ;
        int64_t v284 = (int64_t) ((uint64_t) v254 + (uint64_t) ((int64_t) (uint64_t) v283 * (uint64_t) v60));
        // pto: %panel64_wide_x_inline1277__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v285 = Tile<TileType::Mat, bfloat16_t, 64, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v251, v60);
        // pto: %panel64_wide_x_inline1277__tile
        ;
        uint64_t v286 = (uint64_t) v39;
        TASSIGN(v285, v286);
        // pto: %89
        ;
        int64_t v287 = v284 < v54 ? v54 : v284;
        // pto: %90
        ;
        const int64_t v288 = 0;
        // pto: %90
        ;
        __gm__ bfloat16_t* v289 = PTOAS__GLOBAL_TENSOR_DATA(v97);
        // pto: %90
        ;
        const int64_t v290 = 1;
        // pto: %90
        ;
        const int64_t v291 = 1;
        // pto: %90
        ;
        const int64_t v292 = 1;
        // pto: %90
        ;
        int64_t v293 = v251 * v45;
        // pto: %90
        ;
        int64_t v294 = v292 * v293;
        // pto: %90
        ;
        pto::Shape<1, 1, 1, -1, 128> v295 = pto::Shape<1, 1, 1, -1, 128>(v290, v291, v292, v251, v60);
        // pto: %90
        ;
        pto::Stride<-1, -1, -1, -1, -1> v296 = pto::Stride<-1, -1, -1, -1, -1>(v291 * v294, v294, v293, v45, v43);
        // pto: %90
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v297 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 128>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v289 + (v288 + v257 * v45 + v287 * v43), v295, v296);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        TLOAD(v285, v297);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        // pto: %panel64_wide_w_inline1283__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v298 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
        // pto: %panel64_wide_w_inline1283__tile
        ;
        uint64_t v299 = (uint64_t) v40;
        TASSIGN(v298, v299);
        // pto: %92
        ;
        __gm__ bfloat16_t* v300 = PTOAS__GLOBAL_TENSOR_DATA(v88);
        // pto: %92
        ;
        const int64_t v301 = 0;
        // pto: %92
        ;
        const int64_t v302 = 32;
        // pto: %92
        ;
        pto::Shape<1, 1, 1, 128, 32> v303 = pto::Shape<1, 1, 1, 128, 32>();
        // pto: %92
        ;
        pto::Stride<4096, 4096, 4096, 32, 1> v304 = pto::Stride<4096, 4096, 4096, 32, 1>();
        // pto: %92
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v305 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v300 + (v301 + v287 * v302), v303, v304);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v298, v305);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        // pto: %panel64_wide_x_inline1277__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Left, bfloat16_t, 64, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v251, v60);
        // pto: %panel64_wide_x_inline1277__tile_Left
        ;
        uint64_t v307 = (uint64_t) v41;
        TASSIGN(v306, v307);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID5);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
        TMOV(v306, v285);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
        // pto: %panel64_wide_w_inline1283__tile_Right
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v308 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
        // pto: %panel64_wide_w_inline1283__tile_Right
        ;
        uint64_t v309 = (uint64_t) v41;
        TASSIGN(v308, v309);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID6);
        TMOV(v308, v298);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID4);
        TMATMUL_ACC(v281, v281, v306, v308);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      };
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID7);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID7);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
      v281.SetValidShape(v251, v46);
      // pto: %93, %94
      ;
      int64_t v310 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v248 * (uint64_t) v34) + (uint64_t) v249);
      // pto: %95
      ;
      int64_t v311 = v310 < v54 ? v54 : v310;
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v312 = 0;
      // pto: %linear__iter_v1_pview
      ;
      __gm__ float* v313 = PTOAS__GLOBAL_TENSOR_DATA(v106);
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v314 = 1;
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v315 = 1;
      // pto: %linear__iter_v1_pview
      ;
      const int64_t v316 = 1;
      // pto: %linear__iter_v1_pview
      ;
      int64_t v317 = v251 * v46;
      // pto: %linear__iter_v1_pview
      ;
      int64_t v318 = v316 * v317;
      // pto: %linear__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, -1, 32> v319 = pto::Shape<1, 1, 1, -1, 32>(v314, v315, v316, v251, v46);
      // pto: %linear__iter_v1_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v320 = pto::Stride<-1, -1, -1, -1, -1>(v315 * v318, v318, v317, v46, v43);
      // pto: %linear__iter_v1_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v321 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v313 + (v312 + v311 * v46 + v54 * v43), v319, v320);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID1);
      TSTORE(v321, v281);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
    };
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID5);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID2);
  } else {
    // pto: %96
    ;
    int64_t v322 = v34 / v44;
    // pto: %97
    ;
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
    for (int64_t v323 = v153; v323 < ((int64_t) ((uint64_t) v322 * (uint64_t) v52)); v323 += v51) {
      // pto: %99
      ;
      int64_t v324 = v323 / v322;
      // pto: %101, %102
      ;
      int64_t v325 = (int64_t) ((uint64_t) (v323 % v322) * (uint64_t) v44);
      // pto: %104, %103
      ;
      int64_t v326 = (int64_t) ((uint64_t) v42 - (uint64_t) ((int64_t) (uint64_t) v324 * (uint64_t) v55));
      // pto: %105
      ;
      int64_t v327 = v326 < v55 ? v326 : v55;
      // pto: %106
      ;
      // pto: %panel64_accumulator_inline1273__tile
      ;
      Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v328 = Tile<TileType::Acc, float, 16, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v46);
      // pto: %panel64_accumulator_inline1273__tile
      ;
      uint64_t v329 = (uint64_t) v39;
      TASSIGN(v328, v329);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v330 = v54; v330 < (v327 / v49); v330 += v43) {
        // pto: %107, %109, %108
        ;
        int64_t v331 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v324 * (uint64_t) v59) + (uint64_t) ((int64_t) (uint64_t) v330 * (uint64_t) v60));
        // pto: %panel64_x16_inline1271__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v332 = Tile<TileType::Mat, bfloat16_t, 16, 128, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v60);
        // pto: %panel64_x16_inline1271__tile
        ;
        uint64_t v333 = (uint64_t) v40;
        TASSIGN(v332, v333);
        // pto: %110
        ;
        int64_t v334 = v325 < v54 ? v54 : v325;
        // pto: %111
        ;
        int64_t v335 = v331 < v54 ? v54 : v331;
        // pto: %112
        ;
        __gm__ bfloat16_t* v336 = PTOAS__GLOBAL_TENSOR_DATA(v97);
        // pto: %112
        ;
        const int64_t v337 = 0;
        // pto: %112
        ;
        const int64_t v338 = 32768;
        // pto: %112
        ;
        pto::Shape<1, 1, 1, 16, 128> v339 = pto::Shape<1, 1, 1, 16, 128>();
        // pto: %112
        ;
        pto::Stride<524288, 524288, 524288, 32768, 1> v340 = pto::Stride<524288, 524288, 524288, 32768, 1>();
        // pto: %112
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND> v341 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 128>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND>(v336 + (v337 + v334 * v338 + v335), v339, v340);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v332, v341);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        // pto: %panel64_w16_inline1278__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v342 = Tile<TileType::Mat, bfloat16_t, 128, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
        // pto: %panel64_w16_inline1278__tile
        ;
        uint64_t v343 = (uint64_t) v39;
        TASSIGN(v342, v343);
        // pto: %114
        ;
        __gm__ bfloat16_t* v344 = PTOAS__GLOBAL_TENSOR_DATA(v88);
        // pto: %114
        ;
        const int64_t v345 = 0;
        // pto: %114
        ;
        const int64_t v346 = 32;
        // pto: %114
        ;
        pto::Shape<1, 1, 1, 128, 32> v347 = pto::Shape<1, 1, 1, 128, 32>();
        // pto: %114
        ;
        pto::Stride<4096, 4096, 4096, 32, 1> v348 = pto::Stride<4096, 4096, 4096, 32, 1>();
        // pto: %114
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND> v349 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 128, 32>, pto::Stride<4096, 4096, 4096, 32, 1>, pto::Layout::ND>(v344 + (v345 + v335 * v346), v347, v348);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v342, v349);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %panel64_x16_inline1271__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v350 = Tile<TileType::Left, bfloat16_t, 16, 128, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v60);
        // pto: %panel64_x16_inline1271__tile_Left
        ;
        uint64_t v351 = (uint64_t) v41;
        TASSIGN(v350, v351);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID7);
        pipe_barrier(PIPE_MTE1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        TMOV(v350, v332);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        // pto: %panel64_w16_inline1278__tile_Right
        ;
        Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v352 = Tile<TileType::Right, bfloat16_t, 128, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v60, v46);
        // pto: %panel64_w16_inline1278__tile_Right
        ;
        uint64_t v353 = (uint64_t) v41;
        TASSIGN(v352, v353);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        TMOV(v352, v342);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        // pto: %115
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID5);
        if (v330 == v54) {
          TMATMUL(v328, v350, v352);
        } else {
          TMATMUL_ACC(v328, v328, v350, v352);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
      // pto: %117, %118
      ;
      int64_t v354 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v324 * (uint64_t) v34) + (uint64_t) v325);
      // pto: %119
      ;
      int64_t v355 = v354 < v54 ? v54 : v354;
      // pto: %linear__iter_v4_pview
      ;
      __gm__ float* v356 = PTOAS__GLOBAL_TENSOR_DATA(v106);
      // pto: %linear__iter_v4_pview
      ;
      const int64_t v357 = 0;
      // pto: %linear__iter_v4_pview
      ;
      const int64_t v358 = 32;
      // pto: %linear__iter_v4_pview
      ;
      pto::Shape<1, 1, 1, 16, 32> v359 = pto::Shape<1, 1, 1, 16, 32>();
      // pto: %linear__iter_v4_pview
      ;
      pto::Stride<512, 512, 512, 32, 1> v360 = pto::Stride<512, 512, 512, 32, 1>();
      // pto: %linear__iter_v4_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v361 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v356 + (v357 + v355 * v358), v359, v360);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID2);
      pipe_barrier(PIPE_FIX);
      TSTORE(v361, v328);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
    };
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID3);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  // pto: %120, %121
  int64_t v362 = (int64_t) ((uint64_t) v32 + (uint64_t) v61) / v44;
  // pto: %124
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID4);
  if (v32 <= v44) {
    // pto: %125
    ;
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
    for (int64_t v363 = v153; v363 < ((int64_t) ((uint64_t) v362 * (uint64_t) v46)); v363 += v51) {
      // pto: %126, %127
      ;
      int64_t v364 = (int64_t) ((uint64_t) (v363 / v46) * (uint64_t) v44);
      // pto: %128, %129
      ;
      int64_t v365 = (int64_t) ((uint64_t) (v363 % v46) * (uint64_t) v44);
      // pto: %130
      ;
      int64_t v366 = (int64_t) ((uint64_t) v32 - (uint64_t) v364);
      // pto: %131
      ;
      int64_t v367 = v366 < v44 ? v366 : v44;
      // pto: %m16_tile_inline1307__tile
      ;
      Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v368 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v44);
      // pto: %m16_tile_inline1307__tile
      ;
      uint64_t v369 = (uint64_t) v39;
      TASSIGN(v368, v369);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      for (int64_t v370 = v54; v370 < v44; v370 += v43) {
        // pto: %flat_offset, %m16_k_block_inline1318__tile
        ;
        int32_t v371 = (v8)[(int64_t) ((uint64_t) v365 + (uint64_t) v370)];
        // pto: %132
        ;
        int64_t v372 = (int64_t) v371;
        // pto: %133
        ;
        int64_t v373 = v372 < v54 ? v54 : v372;
        // pto: %134
        ;
        int64_t v374 = (int64_t) ((uint64_t) v373 * (uint64_t) v62);
        // pto: %m16_a_inline1309__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v375 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v367, v62);
        // pto: %m16_a_inline1309__tile
        ;
        uint64_t v376 = (uint64_t) v39;
        TASSIGN(v375, v376);
        // pto: %135
        ;
        int64_t v377 = v364 < v54 ? v54 : v364;
        // pto: %136
        ;
        int64_t v378 = v374 < v54 ? v54 : v374;
        // pto: %normalized__ssa_v0_pview
        ;
        const int64_t v379 = 0;
        // pto: %normalized__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v380 = PTOAS__GLOBAL_TENSOR_DATA(v115);
        // pto: %normalized__ssa_v0_pview
        ;
        const int64_t v381 = 1;
        // pto: %normalized__ssa_v0_pview
        ;
        const int64_t v382 = 1;
        // pto: %normalized__ssa_v0_pview
        ;
        const int64_t v383 = 1;
        // pto: %normalized__ssa_v0_pview
        ;
        int64_t v384 = v367 * v47;
        // pto: %normalized__ssa_v0_pview
        ;
        int64_t v385 = v383 * v384;
        // pto: %normalized__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v386 = pto::Shape<1, 1, 1, -1, 256>(v381, v382, v383, v367, v62);
        // pto: %normalized__ssa_v0_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v387 = pto::Stride<-1, -1, -1, -1, -1>(v382 * v385, v385, v384, v47, v43);
        // pto: %normalized__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v388 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v380 + (v379 + v377 * v47 + v378 * v43), v386, v387);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        TLOAD(v375, v388);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %m16_b_inline1338__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v389 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v62);
        // pto: %m16_b_inline1338__tile
        ;
        uint64_t v390 = (uint64_t) v40;
        TASSIGN(v389, v390);
        // pto: %137
        ;
        int64_t v391 = v365 < v54 ? v54 : v365;
        // pto: %weight__ssa_v0_pview
        ;
        __gm__ bfloat16_t* v392 = PTOAS__GLOBAL_TENSOR_DATA(v123);
        // pto: %weight__ssa_v0_pview
        ;
        const int64_t v393 = 0;
        // pto: %weight__ssa_v0_pview
        ;
        const int64_t v394 = 4096;
        // pto: %weight__ssa_v0_pview
        ;
        pto::Shape<1, 1, 1, 16, 256> v395 = pto::Shape<1, 1, 1, 16, 256>();
        // pto: %weight__ssa_v0_pview
        ;
        pto::Stride<65536, 65536, 65536, 4096, 1> v396 = pto::Stride<65536, 65536, 65536, 4096, 1>();
        // pto: %weight__ssa_v0_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v397 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v392 + (v393 + v391 * v394 + v378), v395, v396);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        TLOAD(v389, v397);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %m16_b_inline1338__tile_t
        ;
        Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v398 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
        // pto: %m16_b_inline1338__tile_t
        ;
        uint64_t v399 = (uint64_t) v40;
        TASSIGN(v398, v399);
        // pto: %m16_a_inline1309__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v400 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v367, v62);
        // pto: %m16_a_inline1309__tile_Left
        ;
        uint64_t v401 = (uint64_t) v41;
        TASSIGN(v400, v401);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
        TMOV(v400, v375);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
        // pto: %m16_b_inline1338__tile_t_Right
        ;
        Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v402 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
        // pto: %m16_b_inline1338__tile_t_Right
        ;
        uint64_t v403 = (uint64_t) v41;
        TASSIGN(v402, v403);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        TMOV(v402, v398);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        // pto: %139
        ;
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID6);
        if (v370 == v54) {
          TMATMUL(v368, v400, v402);
        } else {
          TMATMUL_ACC(v368, v368, v400, v402);
        };
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      };
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
      // pto: %140
      ;
      int64_t v404 = v364 < v54 ? v54 : v364;
      // pto: %141
      ;
      int64_t v405 = v365 < v54 ? v54 : v365;
      // pto: %accum__iter_v1_pview
      ;
      __gm__ float* v406 = PTOAS__GLOBAL_TENSOR_DATA(v132);
      // pto: %accum__iter_v1_pview
      ;
      const int64_t v407 = 0;
      // pto: %accum__iter_v1_pview
      ;
      const int64_t v408 = 512;
      // pto: %accum__iter_v1_pview
      ;
      pto::Shape<1, 1, 1, 16, 16> v409 = pto::Shape<1, 1, 1, 16, 16>();
      // pto: %accum__iter_v1_pview
      ;
      pto::Stride<8192, 8192, 8192, 512, 1> v410 = pto::Stride<8192, 8192, 8192, 512, 1>();
      // pto: %accum__iter_v1_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND> v411 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<8192, 8192, 8192, 512, 1>, pto::Layout::ND>(v406 + (v407 + v404 * v408 + v405), v409, v410);
      wait_flag(PIPE_M, PIPE_FIX, EVENT_ID3);
      pipe_barrier(PIPE_FIX);
      TSTORE(v411, v368);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
    };
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID5);
  } else {
    // pto: %122, %123, %142
    ;
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    for (int64_t v412 = v153; v412 < ((int64_t) ((uint64_t) ((int64_t) ((uint64_t) v32 + (uint64_t) v58) / v49) * (uint64_t) v44)); v412 += v51) {
      // pto: %143, %144
      ;
      int64_t v413 = (int64_t) ((uint64_t) (v412 / v44) * (uint64_t) v49);
      // pto: %145
      ;
      int64_t v414 = v412 % v44;
      // pto: %146
      ;
      int64_t v415 = (int64_t) ((uint64_t) v414 * (uint64_t) v56);
      int64_t v416 = (int64_t) ((uint64_t) v414 * (uint64_t) v46);
      // pto: %148
      ;
      int64_t v417 = (int64_t) ((uint64_t) v32 - (uint64_t) v413);
      // pto: %149
      ;
      int64_t v418 = v417 < v49 ? v417 : v49;
      // pto: %same_order_inline1334__rv_v2
      ;
      int64_t v419;
      v419 = v43;
      for (int64_t v420 = v54; v420 < v44; v420 += v43) {
        // pto: %151, %t__tile
        ;
        int32_t v421 = (v8)[(int64_t) ((uint64_t) v416 + (uint64_t) v420)];
        // pto: %153, %154, %155, %152
        ;
        int32_t v422 = (v8)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v415 + (uint64_t) v43) * (uint64_t) v44) + (uint64_t) v420)];
        // pto: %156, %same_order_inline1334__phi_v4
        ;
        int64_t v423 = v421 != v422 ? v54 : v419;
        v419 = v423;
      };
      // pto: %157
      ;
      bool v424 = v419 == v43;
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
      if (v424) {
        // pto: %first_block_inline1321__tile
        ;
        int32_t v425 = (v8)[v416];
        // pto: %160
        ;
        int64_t v426 = (int64_t) v425;
        // pto: %161
        ;
        int64_t v427 = v426 < v54 ? v54 : v426;
        // pto: %162
        ;
        int64_t v428 = (int64_t) ((uint64_t) v427 * (uint64_t) v62);
        // pto: %first_a_inline1323__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v429 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v418, v62);
        // pto: %first_a_inline1323__tile
        ;
        uint64_t v430 = (uint64_t) v39;
        TASSIGN(v429, v430);
        // pto: %163
        ;
        int64_t v431 = v413 < v54 ? v54 : v413;
        // pto: %164
        ;
        int64_t v432 = v428 < v54 ? v54 : v428;
        // pto: %165
        ;
        const int64_t v433 = 0;
        // pto: %165
        ;
        __gm__ bfloat16_t* v434 = PTOAS__GLOBAL_TENSOR_DATA(v115);
        // pto: %165
        ;
        const int64_t v435 = 1;
        // pto: %165
        ;
        const int64_t v436 = 1;
        // pto: %165
        ;
        const int64_t v437 = 1;
        // pto: %165
        ;
        int64_t v438 = v418 * v47;
        // pto: %165
        ;
        int64_t v439 = v437 * v438;
        // pto: %165
        ;
        pto::Shape<1, 1, 1, -1, 256> v440 = pto::Shape<1, 1, 1, -1, 256>(v435, v436, v437, v418, v62);
        // pto: %165
        ;
        pto::Stride<-1, -1, -1, -1, -1> v441 = pto::Stride<-1, -1, -1, -1, -1>(v436 * v439, v439, v438, v47, v43);
        // pto: %165
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v442 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v434 + (v433 + v431 * v47 + v432 * v43), v440, v441);
        TLOAD(v429, v442);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        // pto: %first_b_inline1308__tile
        ;
        Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v443 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v62);
        // pto: %first_b_inline1308__tile
        ;
        uint64_t v444 = (uint64_t) v40;
        TASSIGN(v443, v444);
        // pto: %166
        ;
        int64_t v445 = v416 < v54 ? v54 : v416;
        // pto: %168
        ;
        __gm__ bfloat16_t* v446 = PTOAS__GLOBAL_TENSOR_DATA(v123);
        // pto: %168
        ;
        const int64_t v447 = 0;
        // pto: %168
        ;
        const int64_t v448 = 4096;
        // pto: %168
        ;
        pto::Shape<1, 1, 1, 32, 256> v449 = pto::Shape<1, 1, 1, 32, 256>();
        // pto: %168
        ;
        pto::Stride<131072, 131072, 131072, 4096, 1> v450 = pto::Stride<131072, 131072, 131072, 4096, 1>();
        // pto: %168
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v451 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v446 + (v447 + v445 * v448 + v432), v449, v450);
        TLOAD(v443, v451);
        set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        // pto: %first_b_inline1308__tile_t
        ;
        Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v452 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v46);
        // pto: %first_b_inline1308__tile_t
        ;
        uint64_t v453 = (uint64_t) v40;
        TASSIGN(v452, v453);
        // pto: %first_a_inline1323__tile_Left
        ;
        Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v454 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v418, v62);
        // pto: %first_a_inline1323__tile_Left
        ;
        uint64_t v455 = (uint64_t) v41;
        TASSIGN(v454, v455);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
        TMOV(v454, v429);
        // pto: %first_b_inline1308__tile_t_Right
        ;
        Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v456 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v46);
        // pto: %first_b_inline1308__tile_t_Right
        ;
        uint64_t v457 = (uint64_t) v41;
        TASSIGN(v456, v457);
        wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
        TMOV(v456, v452);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        // pto: %wide_tile_inline1337__tile
        ;
        Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v458 = Tile<TileType::Acc, float, 64, 32, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v418, v46);
        // pto: %wide_tile_inline1337__tile
        ;
        uint64_t v459 = (uint64_t) v39;
        TASSIGN(v458, v459);
        wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID7);
        TMATMUL(v458, v454, v456);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        for (int64_t v460 = v43; v460 < v44; v460 += v43) {
          // pto: %170, %k_block_inline1322__tile
          ;
          int32_t v461 = (v8)[(int64_t) ((uint64_t) v416 + (uint64_t) v460)];
          // pto: %171
          ;
          int64_t v462 = (int64_t) v461;
          // pto: %172
          ;
          int64_t v463 = v462 < v54 ? v54 : v462;
          // pto: %173
          ;
          int64_t v464 = (int64_t) ((uint64_t) v463 * (uint64_t) v62);
          // pto: %a_inline1329__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v465 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v418, v62);
          // pto: %a_inline1329__tile
          ;
          uint64_t v466 = (uint64_t) v39;
          TASSIGN(v465, v466);
          // pto: %175
          ;
          int64_t v467 = v464 < v54 ? v54 : v464;
          // pto: %176
          ;
          const int64_t v468 = 0;
          // pto: %176
          ;
          __gm__ bfloat16_t* v469 = PTOAS__GLOBAL_TENSOR_DATA(v115);
          // pto: %176
          ;
          const int64_t v470 = 1;
          // pto: %176
          ;
          const int64_t v471 = 1;
          // pto: %176
          ;
          const int64_t v472 = 1;
          // pto: %176
          ;
          int64_t v473 = v418 * v47;
          // pto: %176
          ;
          int64_t v474 = v472 * v473;
          // pto: %176
          ;
          pto::Shape<1, 1, 1, -1, 256> v475 = pto::Shape<1, 1, 1, -1, 256>(v470, v471, v472, v418, v62);
          // pto: %176
          ;
          pto::Stride<-1, -1, -1, -1, -1> v476 = pto::Stride<-1, -1, -1, -1, -1>(v471 * v474, v474, v473, v47, v43);
          // pto: %176
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v477 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v469 + (v468 + v431 * v47 + v467 * v43), v475, v476);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          TLOAD(v465, v477);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %b_inline1333__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v478 = Tile<TileType::Mat, bfloat16_t, 32, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v46, v62);
          // pto: %b_inline1333__tile
          ;
          uint64_t v479 = (uint64_t) v40;
          TASSIGN(v478, v479);
          // pto: %179
          ;
          __gm__ bfloat16_t* v480 = PTOAS__GLOBAL_TENSOR_DATA(v123);
          // pto: %179
          ;
          const int64_t v481 = 0;
          // pto: %179
          ;
          const int64_t v482 = 4096;
          // pto: %179
          ;
          pto::Shape<1, 1, 1, 32, 256> v483 = pto::Shape<1, 1, 1, 32, 256>();
          // pto: %179
          ;
          pto::Stride<131072, 131072, 131072, 4096, 1> v484 = pto::Stride<131072, 131072, 131072, 4096, 1>();
          // pto: %179
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND> v485 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 32, 256>, pto::Stride<131072, 131072, 131072, 4096, 1>, pto::Layout::ND>(v480 + (v481 + v445 * v482 + v467), v483, v484);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          TLOAD(v478, v485);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %b_inline1333__tile_t
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v486 = Tile<TileType::Mat, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v46);
          // pto: %b_inline1333__tile_t
          ;
          uint64_t v487 = (uint64_t) v40;
          TASSIGN(v486, v487);
          // pto: %a_inline1329__tile_Left
          ;
          Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v488 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v418, v62);
          // pto: %a_inline1329__tile_Left
          ;
          uint64_t v489 = (uint64_t) v41;
          TASSIGN(v488, v489);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          TMOV(v488, v465);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %b_inline1333__tile_t_Right
          ;
          Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v490 = Tile<TileType::Right, bfloat16_t, 256, 32, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v46);
          // pto: %b_inline1333__tile_t_Right
          ;
          uint64_t v491 = (uint64_t) v41;
          TASSIGN(v490, v491);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          TMOV(v490, v486);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          TMATMUL_ACC(v458, v458, v488, v490);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        };
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        // pto: %accum__iter_v4_pview
        ;
        const int64_t v492 = 0;
        // pto: %accum__iter_v4_pview
        ;
        __gm__ float* v493 = PTOAS__GLOBAL_TENSOR_DATA(v132);
        // pto: %accum__iter_v4_pview
        ;
        const int64_t v494 = 1;
        // pto: %accum__iter_v4_pview
        ;
        const int64_t v495 = 1;
        // pto: %accum__iter_v4_pview
        ;
        const int64_t v496 = 1;
        // pto: %accum__iter_v4_pview
        ;
        int64_t v497 = v418 * v48;
        // pto: %accum__iter_v4_pview
        ;
        int64_t v498 = v496 * v497;
        // pto: %accum__iter_v4_pview
        ;
        pto::Shape<1, 1, 1, -1, 32> v499 = pto::Shape<1, 1, 1, -1, 32>(v494, v495, v496, v418, v46);
        // pto: %accum__iter_v4_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v500 = pto::Stride<-1, -1, -1, -1, -1>(v495 * v498, v498, v497, v48, v43);
        // pto: %accum__iter_v4_pview
        ;
        GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v501 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 32>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v493 + (v492 + v431 * v48 + v445 * v43), v499, v500);
        wait_flag(PIPE_M, PIPE_FIX, EVENT_ID4);
        TSTORE(v501, v458);
      } else {
        set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
        set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        set_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        for (int64_t v502 = v54; v502 < v56; v502 += v43) {
          // pto: %183, %184
          ;
          int64_t v503 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v415 + (uint64_t) v502) * (uint64_t) v44);
          // pto: %narrow_first_block_inline1302__tile
          ;
          int32_t v504 = (v8)[v503];
          // pto: %187
          ;
          int64_t v505 = (int64_t) v504;
          // pto: %188
          ;
          int64_t v506 = v505 < v54 ? v54 : v505;
          // pto: %189
          ;
          int64_t v507 = (int64_t) ((uint64_t) v506 * (uint64_t) v62);
          // pto: %narrow_first_a_inline1300__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v508 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v418, v62);
          // pto: %narrow_first_a_inline1300__tile
          ;
          uint64_t v509 = (uint64_t) v39;
          TASSIGN(v508, v509);
          // pto: %190
          ;
          int64_t v510 = v413 < v54 ? v54 : v413;
          // pto: %191
          ;
          int64_t v511 = v507 < v54 ? v54 : v507;
          // pto: %192
          ;
          const int64_t v512 = 0;
          // pto: %192
          ;
          __gm__ bfloat16_t* v513 = PTOAS__GLOBAL_TENSOR_DATA(v115);
          // pto: %192
          ;
          const int64_t v514 = 1;
          // pto: %192
          ;
          const int64_t v515 = 1;
          // pto: %192
          ;
          const int64_t v516 = 1;
          // pto: %192
          ;
          int64_t v517 = v418 * v47;
          // pto: %192
          ;
          int64_t v518 = v516 * v517;
          // pto: %192
          ;
          pto::Shape<1, 1, 1, -1, 256> v519 = pto::Shape<1, 1, 1, -1, 256>(v514, v515, v516, v418, v62);
          // pto: %192
          ;
          pto::Stride<-1, -1, -1, -1, -1> v520 = pto::Stride<-1, -1, -1, -1, -1>(v515 * v518, v518, v517, v47, v43);
          // pto: %192
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v521 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v513 + (v512 + v510 * v47 + v511 * v43), v519, v520);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          TLOAD(v508, v521);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          // pto: %narrow_first_b_inline1299__tile
          ;
          Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v522 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v62);
          // pto: %narrow_first_b_inline1299__tile
          ;
          uint64_t v523 = (uint64_t) v40;
          TASSIGN(v522, v523);
          // pto: %193
          ;
          int64_t v524 = v503 < v54 ? v54 : v503;
          // pto: %195
          ;
          __gm__ bfloat16_t* v525 = PTOAS__GLOBAL_TENSOR_DATA(v123);
          // pto: %195
          ;
          const int64_t v526 = 0;
          // pto: %195
          ;
          const int64_t v527 = 4096;
          // pto: %195
          ;
          pto::Shape<1, 1, 1, 16, 256> v528 = pto::Shape<1, 1, 1, 16, 256>();
          // pto: %195
          ;
          pto::Stride<65536, 65536, 65536, 4096, 1> v529 = pto::Stride<65536, 65536, 65536, 4096, 1>();
          // pto: %195
          ;
          GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v530 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v525 + (v526 + v524 * v527 + v511), v528, v529);
          TLOAD(v522, v530);
          set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          // pto: %narrow_first_b_inline1299__tile_t
          ;
          Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v531 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
          // pto: %narrow_first_b_inline1299__tile_t
          ;
          uint64_t v532 = (uint64_t) v40;
          TASSIGN(v531, v532);
          // pto: %narrow_first_a_inline1300__tile_Left
          ;
          Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v533 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v418, v62);
          // pto: %narrow_first_a_inline1300__tile_Left
          ;
          uint64_t v534 = (uint64_t) v41;
          TASSIGN(v533, v534);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          TMOV(v533, v508);
          // pto: %narrow_first_b_inline1299__tile_t_Right
          ;
          Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v535 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
          // pto: %narrow_first_b_inline1299__tile_t_Right
          ;
          uint64_t v536 = (uint64_t) v41;
          TASSIGN(v535, v536);
          wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
          TMOV(v535, v531);
          set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          // pto: %narrow_tile_inline1298__tile
          ;
          Tile<TileType::Acc, float, 64, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal> v537 = Tile<TileType::Acc, float, 64, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Normal>(v418, v44);
          // pto: %narrow_tile_inline1298__tile
          ;
          uint64_t v538 = (uint64_t) v39;
          TASSIGN(v537, v538);
          wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
          wait_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
          TMATMUL(v537, v533, v535);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          for (int64_t v539 = v43; v539 < v44; v539 += v43) {
            // pto: %197, %narrow_block_inline1297__tile
            ;
            int32_t v540 = (v8)[(int64_t) ((uint64_t) v503 + (uint64_t) v539)];
            // pto: %198
            ;
            int64_t v541 = (int64_t) v540;
            // pto: %199
            ;
            int64_t v542 = v541 < v54 ? v54 : v541;
            // pto: %200
            ;
            int64_t v543 = (int64_t) ((uint64_t) v542 * (uint64_t) v62);
            // pto: %narrow_a_inline1336__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v544 = Tile<TileType::Mat, bfloat16_t, 64, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v418, v62);
            // pto: %narrow_a_inline1336__tile
            ;
            uint64_t v545 = (uint64_t) v39;
            TASSIGN(v544, v545);
            // pto: %202
            ;
            int64_t v546 = v543 < v54 ? v54 : v543;
            // pto: %203
            ;
            const int64_t v547 = 0;
            // pto: %203
            ;
            __gm__ bfloat16_t* v548 = PTOAS__GLOBAL_TENSOR_DATA(v115);
            // pto: %203
            ;
            const int64_t v549 = 1;
            // pto: %203
            ;
            const int64_t v550 = 1;
            // pto: %203
            ;
            const int64_t v551 = 1;
            // pto: %203
            ;
            int64_t v552 = v418 * v47;
            // pto: %203
            ;
            int64_t v553 = v551 * v552;
            // pto: %203
            ;
            pto::Shape<1, 1, 1, -1, 256> v554 = pto::Shape<1, 1, 1, -1, 256>(v549, v550, v551, v418, v62);
            // pto: %203
            ;
            pto::Stride<-1, -1, -1, -1, -1> v555 = pto::Stride<-1, -1, -1, -1, -1>(v550 * v553, v553, v552, v47, v43);
            // pto: %203
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v556 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v548 + (v547 + v510 * v47 + v546 * v43), v554, v555);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            TLOAD(v544, v556);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            // pto: %narrow_b_inline1311__tile
            ;
            Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v557 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v62);
            // pto: %narrow_b_inline1311__tile
            ;
            uint64_t v558 = (uint64_t) v40;
            TASSIGN(v557, v558);
            // pto: %206
            ;
            __gm__ bfloat16_t* v559 = PTOAS__GLOBAL_TENSOR_DATA(v123);
            // pto: %206
            ;
            const int64_t v560 = 0;
            // pto: %206
            ;
            const int64_t v561 = 4096;
            // pto: %206
            ;
            pto::Shape<1, 1, 1, 16, 256> v562 = pto::Shape<1, 1, 1, 16, 256>();
            // pto: %206
            ;
            pto::Stride<65536, 65536, 65536, 4096, 1> v563 = pto::Stride<65536, 65536, 65536, 4096, 1>();
            // pto: %206
            ;
            GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v564 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v559 + (v560 + v524 * v561 + v546), v562, v563);
            wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            TLOAD(v557, v564);
            set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            // pto: %narrow_b_inline1311__tile_t
            ;
            Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v565 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
            // pto: %narrow_b_inline1311__tile_t
            ;
            uint64_t v566 = (uint64_t) v40;
            TASSIGN(v565, v566);
            // pto: %narrow_a_inline1336__tile_Left
            ;
            Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v567 = Tile<TileType::Left, bfloat16_t, 64, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v418, v62);
            // pto: %narrow_a_inline1336__tile_Left
            ;
            uint64_t v568 = (uint64_t) v41;
            TASSIGN(v567, v568);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
            wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
            TMOV(v567, v544);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
            // pto: %narrow_b_inline1311__tile_t_Right
            ;
            Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v569 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
            // pto: %narrow_b_inline1311__tile_t_Right
            ;
            uint64_t v570 = (uint64_t) v41;
            TASSIGN(v569, v570);
            wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
            TMOV(v569, v565);
            set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
            set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
            TMATMUL_ACC(v537, v537, v567, v569);
            set_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          };
          wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID2);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID3);
          wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID2);
          set_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
          set_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
          set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
          // pto: %accum__iter_v7_pview
          ;
          const int64_t v571 = 0;
          // pto: %accum__iter_v7_pview
          ;
          __gm__ float* v572 = PTOAS__GLOBAL_TENSOR_DATA(v132);
          // pto: %accum__iter_v7_pview
          ;
          const int64_t v573 = 1;
          // pto: %accum__iter_v7_pview
          ;
          const int64_t v574 = 1;
          // pto: %accum__iter_v7_pview
          ;
          const int64_t v575 = 1;
          // pto: %accum__iter_v7_pview
          ;
          int64_t v576 = v418 * v48;
          // pto: %accum__iter_v7_pview
          ;
          int64_t v577 = v575 * v576;
          // pto: %accum__iter_v7_pview
          ;
          pto::Shape<1, 1, 1, -1, 16> v578 = pto::Shape<1, 1, 1, -1, 16>(v573, v574, v575, v418, v44);
          // pto: %accum__iter_v7_pview
          ;
          pto::Stride<-1, -1, -1, -1, -1> v579 = pto::Stride<-1, -1, -1, -1, -1>(v574 * v577, v577, v576, v48, v43);
          // pto: %accum__iter_v7_pview
          ;
          GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v580 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v572 + (v571 + v510 * v48 + v524 * v43), v578, v579);
          wait_flag(PIPE_M, PIPE_FIX, EVENT_ID5);
          TSTORE(v580, v537);
          set_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        };
        wait_flag(PIPE_FIX, PIPE_M, EVENT_ID7);
        wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID1);
        wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      };
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      set_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    };
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID6);
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  // pto: %212
  wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  for (int64_t v581 = v153; v581 < ((int64_t) ((uint64_t) v362 * (uint64_t) v50)); v581 += v51) {
    // pto: %213
    ;
    int64_t v582 = v581 / v50;
    // pto: %214
    ;
    int64_t v583 = v581 % v50;
    // pto: %215
    ;
    int64_t v584 = (int64_t) ((uint64_t) v582 * (uint64_t) v44);
    // pto: %216
    ;
    int64_t v585 = (int64_t) ((uint64_t) v583 * (uint64_t) v44);
    // pto: %217
    ;
    int64_t v586 = (int64_t) ((uint64_t) v32 - (uint64_t) v584);
    // pto: %218
    ;
    int64_t v587 = v586 < v44 ? v586 : v44;
    // pto: %tile_inline1352__tile
    ;
    Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v588 = Tile<TileType::Acc, float, 16, 16, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v44, v44);
    // pto: %tile_inline1352__tile
    ;
    uint64_t v589 = (uint64_t) v39;
    TASSIGN(v588, v589);
    wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    for (int64_t v590 = v54; v590 < v44; v590 += v43) {
      // pto: %219, %220, %221, %222, %k_block_inline1353__tile
      ;
      int32_t v591 = (v12)[(int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v582 * (uint64_t) v50) + (uint64_t) v583) * (uint64_t) v44) + (uint64_t) v590)];
      // pto: %223
      ;
      int64_t v592 = (int64_t) v591;
      // pto: %224
      ;
      int64_t v593 = v592 < v54 ? v54 : v592;
      // pto: %225
      ;
      int64_t v594 = (int64_t) ((uint64_t) v593 * (uint64_t) v62);
      // pto: %a_inline1343__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v595 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v587, v62);
      // pto: %a_inline1343__tile
      ;
      uint64_t v596 = (uint64_t) v39;
      TASSIGN(v595, v596);
      // pto: %226
      ;
      int64_t v597 = v584 < v54 ? v54 : v584;
      // pto: %227
      ;
      int64_t v598 = v594 < v54 ? v54 : v594;
      // pto: %228
      ;
      const int64_t v599 = 0;
      // pto: %228
      ;
      __gm__ bfloat16_t* v600 = PTOAS__GLOBAL_TENSOR_DATA(v115);
      // pto: %228
      ;
      const int64_t v601 = 1;
      // pto: %228
      ;
      const int64_t v602 = 1;
      // pto: %228
      ;
      const int64_t v603 = 1;
      // pto: %228
      ;
      int64_t v604 = v587 * v47;
      // pto: %228
      ;
      int64_t v605 = v603 * v604;
      // pto: %228
      ;
      pto::Shape<1, 1, 1, -1, 256> v606 = pto::Shape<1, 1, 1, -1, 256>(v601, v602, v603, v587, v62);
      // pto: %228
      ;
      pto::Stride<-1, -1, -1, -1, -1> v607 = pto::Stride<-1, -1, -1, -1, -1>(v602 * v605, v605, v604, v47, v43);
      // pto: %228
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v608 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v600 + (v599 + v597 * v47 + v598 * v43), v606, v607);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      TLOAD(v595, v608);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      // pto: %b_inline1344__tile
      ;
      Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v609 = Tile<TileType::Mat, bfloat16_t, 16, 256, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v44, v62);
      // pto: %b_inline1344__tile
      ;
      uint64_t v610 = (uint64_t) v40;
      TASSIGN(v609, v610);
      // pto: %229
      ;
      int64_t v611 = v585 < v54 ? v54 : v585;
      // pto: %idx_weight__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v612 = PTOAS__GLOBAL_TENSOR_DATA(v140);
      // pto: %idx_weight__ssa_v0_pview
      ;
      const int64_t v613 = 0;
      // pto: %idx_weight__ssa_v0_pview
      ;
      const int64_t v614 = 4096;
      // pto: %idx_weight__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 256> v615 = pto::Shape<1, 1, 1, 16, 256>();
      // pto: %idx_weight__ssa_v0_pview
      ;
      pto::Stride<65536, 65536, 65536, 4096, 1> v616 = pto::Stride<65536, 65536, 65536, 4096, 1>();
      // pto: %idx_weight__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND> v617 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 256>, pto::Stride<65536, 65536, 65536, 4096, 1>, pto::Layout::ND>(v612 + (v613 + v611 * v614 + v598), v615, v616);
      wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      TLOAD(v609, v617);
      set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      // pto: %b_inline1344__tile_t
      ;
      Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v618 = Tile<TileType::Mat, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
      // pto: %b_inline1344__tile_t
      ;
      uint64_t v619 = (uint64_t) v40;
      TASSIGN(v618, v619);
      // pto: %a_inline1343__tile_Left
      ;
      Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v620 = Tile<TileType::Left, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v587, v62);
      // pto: %a_inline1343__tile_Left
      ;
      uint64_t v621 = (uint64_t) v41;
      TASSIGN(v620, v621);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
      wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
      TMOV(v620, v595);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
      // pto: %b_inline1344__tile_t_Right
      ;
      Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v622 = Tile<TileType::Right, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v62, v44);
      // pto: %b_inline1344__tile_t_Right
      ;
      uint64_t v623 = (uint64_t) v41;
      TASSIGN(v622, v623);
      wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
      TMOV(v622, v618);
      set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      set_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
      // pto: %231
      ;
      wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
      if (v590 == v54) {
        TMATMUL(v588, v620, v622);
      } else {
        TMATMUL_ACC(v588, v588, v620, v622);
      };
      set_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    };
    wait_flag(PIPE_M, PIPE_MTE1, EVENT_ID0);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE1, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_M, PIPE_FIX, EVENT_ID6);
    // pto: %232
    ;
    int64_t v624 = v584 < v54 ? v54 : v584;
    // pto: %233
    ;
    int64_t v625 = v585 < v54 ? v54 : v585;
    // pto: %idx_accum__iter_v1_pview
    ;
    __gm__ float* v626 = PTOAS__GLOBAL_TENSOR_DATA(v149);
    // pto: %idx_accum__iter_v1_pview
    ;
    const int64_t v627 = 0;
    // pto: %idx_accum__iter_v1_pview
    ;
    const int64_t v628 = 64;
    // pto: %idx_accum__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 16> v629 = pto::Shape<1, 1, 1, 16, 16>();
    // pto: %idx_accum__iter_v1_pview
    ;
    pto::Stride<1024, 1024, 1024, 64, 1> v630 = pto::Stride<1024, 1024, 1024, 64, 1>();
    // pto: %idx_accum__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND> v631 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 16>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND>(v626 + (v627 + v624 * v628 + v625), v629, v630);
    wait_flag(PIPE_M, PIPE_FIX, EVENT_ID6);
    pipe_barrier(PIPE_FIX);
    TSTORE(v631, v588);
    set_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  }
  wait_flag(PIPE_FIX, PIPE_M, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_MTE2);
  pipe_barrier(PIPE_MTE3);
  pipe_barrier(PIPE_FIX);
  dsb(DSB_DDR);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}

AICORE void prepacked_prefix_indexer_vector(__gm__ float* v1, __gm__ float* v2, __gm__ bfloat16_t* v3, __gm__ bfloat16_t* v4, __gm__ float* v5, __gm__ bfloat16_t* v6, __gm__ bfloat16_t* v7, __gm__ int32_t* v8, __gm__ float* v9, __gm__ int64_t* v10, __gm__ bfloat16_t* v11, __gm__ int32_t* v12, __gm__ float* v13, __gm__ bfloat16_t* v14, __gm__ float* v15, __gm__ float* v16, __gm__ float* v17, __gm__ float* v18, __gm__ float* v19, __gm__ float* v20, __gm__ float* v21, __gm__ float* v22, __gm__ bfloat16_t* v23, __gm__ bfloat16_t* v24, __gm__ bfloat16_t* v25, __gm__ float* v26, __gm__ bfloat16_t* v27, __gm__ float* v28, __gm__ bfloat16_t* v29, __gm__ bfloat16_t* v30, __gm__ half* v31, int64_t v32, int64_t v33, int64_t v34, int64_t v35, int64_t v36, int32_t v37, int32_t v38, int32_t v39) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  const int64_t v40 = 12544;
  const int64_t v41 = 8448;
  const int64_t v42 = 4352;
  const int64_t v43 = 8388608;
  const int64_t v44 = 20;
  // pto: %c91904_i64
  const int64_t v45 = 91904;
  // pto: %c1792_i64
  const int64_t v46 = 1792;
  // pto: %c42752_i64
  const int64_t v47 = 42752;
  // pto: %c75520_i64
  const int64_t v48 = 75520;
  // pto: %c18176_i64
  const int64_t v49 = 18176;
  // pto: %c26368_i64
  const int64_t v50 = 26368;
  // pto: %c34560_i64
  const int64_t v51 = 34560;
  // pto: %c0_i64
  const int64_t v52 = 0;
  // pto: %c256_i64
  const int64_t v53 = 256;
  // pto: %c9984_i64
  const int64_t v54 = 9984;
  // pto: %c512_i64
  const int64_t v55 = 512;
  // pto: %c768_i64
  const int64_t v56 = 768;
  // pto: %c1024_i64
  const int64_t v57 = 1024;
  // pto: %c1280_i64
  const int64_t v58 = 1280;
  // pto: %c1536_i64
  const int64_t v59 = 1536;
  const int64_t v60 = 32;
  // pto: %c64_i64
  const int64_t v61 = 64;
  // pto: %c96_i64
  const int64_t v62 = 96;
  const int64_t v63 = 83712;
  const int64_t v64 = 79616;
  const int64_t v65 = 77568;
  const int64_t v66 = 76544;
  const int64_t v67 = 76032;
  const int64_t v68 = 75776;
  // pto: %c16384_index
  const int64_t v69 = 16384;
  // pto: %c1_index
  const int64_t v70 = 1;
  const int64_t v71 = 16;
  // pto: %c32768_index
  const int64_t v72 = 32768;
  // pto: %c32_index
  const int64_t v73 = 32;
  // pto: %c4096_index
  const int64_t v74 = 4096;
  const int64_t v75 = 512;
  // pto: %c64_index
  const int64_t v76 = 64;
  // pto: %c4_index
  const int64_t v77 = 4;
  // pto: %c24_index
  const int64_t v78 = 24;
  const int64_t v79 = 8;
  // pto: %c2_index
  const int64_t v80 = 2;
  // pto: %c48_index
  const int64_t v81 = 48;
  // pto: %c0_index
  const int64_t v82 = 0;
  // pto: %c7_index
  const int64_t v83 = 7;
  // pto: %c192_index
  const int64_t v84 = 192;
  // pto: %c0_i32
  const int32_t v85 = 0;
  // pto: %c16_i32
  const int32_t v86 = 16;
  // pto: %c22_index
  const int64_t v87 = 22;
  // pto: %cst_44
  const float v88 = 6.10351563E-5f;
  // pto: %cst_45
  const float v89 = 9.99999997E-7f;
  // pto: %cst_46
  const float v90 = 1.0f;
  // pto: %c256_index
  const int64_t v91 = 256;
  // pto: %cst_49
  const float v92 = 0.0f;
  // pto: %cst_50
  const bfloat16_t v93 = 0.0f;
  // pto: %cst_51
  const float v94 = 2.0f;
  const int64_t v95 = 12;
  // pto: %c18_index
  const int64_t v96 = 18;
  // pto: %c8192_index
  const int64_t v97 = 8192;
  // pto: %c12288_index
  const int64_t v98 = 12288;
  // pto: %c2048_index
  const int64_t v99 = 2048;
  // pto: %c1024_index
  const int64_t v100 = 1024;
  // pto: %c128_index
  const int64_t v101 = 128;
  // pto: %cst_59
  const float v102 = 2.44140625E-4f;
  // pto: %c8388608_index
  const int64_t v103 = 8388608;
  // pto: %c2139095040_i64
  const int64_t v104 = 2139095040;
  // pto: %c2_i64
  const int64_t v105 = 2;
  // pto: %c152_i64
  const int64_t v106 = 152;
  // pto: %c1_i64
  const int64_t v107 = 1;
  // pto: %c15_index
  const int64_t v108 = 15;
  // pto: %cst_66
  const float v109 = 0.0110485433f;
  // pto: %wide__ssa_v0_view
  const int64_t v110 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v111 = 1;
  // pto: %wide__ssa_v0_view
  const int64_t v112 = 1;
  // pto: %wide__ssa_v0_view
  int64_t v113 = (int64_t) v32;
  // pto: %wide__ssa_v0_view
  int64_t v114 = v113 * v69;
  // pto: %wide__ssa_v0_view
  int64_t v115 = v112 * v114;
  // pto: %wide__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v116 = pto::Shape<1, 1, 1, -1, -1>(v110, v111, v112, v113, v69);
  // pto: %wide__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v117 = pto::Stride<-1, -1, -1, -1, -1>(v111 * v115, v115, v114, v69, v70);
  // pto: %wide__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v118 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1, v116, v117);
  // pto: %packed_flat__ssa_v0_view
  const int64_t v119 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v120 = 1;
  // pto: %packed_flat__ssa_v0_view
  const int64_t v121 = 1;
  // pto: %packed_flat__ssa_v0_view
  int64_t v122 = (int64_t) v34;
  // pto: %packed_flat__ssa_v0_view
  int64_t v123 = v122 * v72;
  // pto: %packed_flat__ssa_v0_view
  int64_t v124 = v121 * v123;
  // pto: %packed_flat__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v125 = pto::Shape<1, 1, 1, -1, -1>(v119, v120, v121, v122, v72);
  // pto: %packed_flat__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v126 = pto::Stride<-1, -1, -1, -1, -1>(v120 * v124, v124, v123, v72, v70);
  // pto: %packed_flat__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v127 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v4, v125, v126);
  // pto: %normalized__ssa_v0_view
  const int64_t v128 = 1;
  // pto: %normalized__ssa_v0_view
  const int64_t v129 = 1;
  // pto: %normalized__ssa_v0_view
  const int64_t v130 = 1;
  // pto: %normalized__ssa_v0_view
  int64_t v131 = (int64_t) v32;
  // pto: %normalized__ssa_v0_view
  int64_t v132 = v131 * v74;
  // pto: %normalized__ssa_v0_view
  int64_t v133 = v130 * v132;
  // pto: %normalized__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v134 = pto::Shape<1, 1, 1, -1, -1>(v128, v129, v130, v131, v74);
  // pto: %normalized__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v135 = pto::Stride<-1, -1, -1, -1, -1>(v129 * v133, v133, v132, v74, v70);
  // pto: %normalized__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v136 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v6, v134, v135);
  // pto: %flat__ssa_v0_view
  const int64_t v137 = 1;
  // pto: %flat__ssa_v0_view
  const int64_t v138 = 1;
  // pto: %flat__ssa_v0_view
  const int64_t v139 = 1;
  // pto: %flat__ssa_v0_view
  int64_t v140 = (int64_t) v32;
  // pto: %flat__ssa_v0_view
  int64_t v141 = v140 * v69;
  // pto: %flat__ssa_v0_view
  int64_t v142 = v139 * v141;
  // pto: %flat__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v143 = pto::Shape<1, 1, 1, -1, -1>(v137, v138, v139, v140, v69);
  // pto: %flat__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v144 = pto::Stride<-1, -1, -1, -1, -1>(v138 * v142, v142, v141, v69, v70);
  // pto: %flat__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v145 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v14, v143, v144);
  // pto: %square_read__ssa_v0_view
  const int64_t v146 = 1;
  // pto: %square_read__ssa_v0_view
  const int64_t v147 = 1;
  // pto: %square_read__ssa_v0_view
  const int64_t v148 = 1;
  // pto: %square_read__ssa_v0_view
  int64_t v149 = (int64_t) v33;
  // pto: %square_read__ssa_v0_view
  int64_t v150 = v149 * v71;
  // pto: %square_read__ssa_v0_view
  int64_t v151 = v148 * v150;
  // pto: %square_read__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v152 = pto::Shape<1, 1, 1, -1, -1>(v146, v147, v148, v149, v71);
  // pto: %square_read__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v153 = pto::Stride<-1, -1, -1, -1, -1>(v147 * v151, v151, v150, v71, v70);
  // pto: %square_read__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v154 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v15, v152, v153);
  // pto: %vec_ws__ssa_v0_view
  const int64_t v155 = 1;
  // pto: %vec_ws__ssa_v0_view
  const int64_t v156 = 1;
  // pto: %vec_ws__ssa_v0_view
  const int64_t v157 = 1;
  // pto: %vec_ws__ssa_v0_view
  int64_t v158 = (int64_t) v36;
  // pto: %vec_ws__ssa_v0_view
  int64_t v159 = v158 * v76;
  // pto: %vec_ws__ssa_v0_view
  int64_t v160 = v157 * v159;
  // pto: %vec_ws__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v161 = pto::Shape<1, 1, 1, -1, -1>(v155, v156, v157, v158, v76);
  // pto: %vec_ws__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v162 = pto::Stride<-1, -1, -1, -1, -1>(v156 * v160, v160, v159, v76, v70);
  // pto: %vec_ws__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v163 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v16, v161, v162);
  // pto: %linear_read__ssa_v0_view
  const int64_t v164 = 1;
  // pto: %linear_read__ssa_v0_view
  const int64_t v165 = 1;
  // pto: %linear_read__ssa_v0_view
  const int64_t v166 = 1;
  // pto: %linear_read__ssa_v0_view
  int64_t v167 = (int64_t) v33;
  // pto: %linear_read__ssa_v0_view
  int64_t v168 = v167 * v73;
  // pto: %linear_read__ssa_v0_view
  int64_t v169 = v166 * v168;
  // pto: %linear_read__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v170 = pto::Shape<1, 1, 1, -1, -1>(v164, v165, v166, v167, v73);
  // pto: %linear_read__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v171 = pto::Stride<-1, -1, -1, -1, -1>(v165 * v169, v169, v168, v73, v70);
  // pto: %linear_read__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v172 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v17, v170, v171);
  // pto: %hc_base__ssa_v0_view
  const int64_t v173 = 1;
  // pto: %hc_base__ssa_v0_view
  const int64_t v174 = 1;
  // pto: %hc_base__ssa_v0_view
  const int64_t v175 = 1;
  // pto: %hc_base__ssa_v0_view
  const int64_t v176 = 1;
  // pto: %hc_base__ssa_v0_view
  int64_t v177 = v78 * v70;
  // pto: %hc_base__ssa_v0_view
  int64_t v178 = v176 * v177;
  // pto: %hc_base__ssa_v0_view
  int64_t v179 = v175 * v178;
  // pto: %hc_base__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v180 = pto::Shape<1, 1, 1, 1, -1>(v173, v174, v175, v176, v78);
  // pto: %hc_base__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v181 = pto::Stride<-1, -1, -1, -1, -1>(v174 * v179, v179, v178, v177, v70);
  // pto: %hc_base__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v182 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v19, v180, v181);
  // pto: %hc_base_2d__ssa_v0_view
  const int64_t v183 = 1;
  // pto: %hc_base_2d__ssa_v0_view
  const int64_t v184 = 1;
  // pto: %hc_base_2d__ssa_v0_view
  const int64_t v185 = 1;
  // pto: %hc_base_2d__ssa_v0_view
  int64_t v186 = v70 * v78;
  // pto: %hc_base_2d__ssa_v0_view
  int64_t v187 = v185 * v186;
  // pto: %hc_base_2d__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v188 = pto::Shape<1, 1, 1, -1, -1>(v183, v184, v185, v70, v78);
  // pto: %hc_base_2d__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v189 = pto::Stride<-1, -1, -1, -1, -1>(v184 * v187, v187, v186, v78, v70);
  // pto: %hc_base_2d__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v190 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v20, v188, v189);
  // pto: %post__ssa_v0_view
  const int64_t v191 = 1;
  // pto: %post__ssa_v0_view
  const int64_t v192 = 1;
  // pto: %post__ssa_v0_view
  const int64_t v193 = 1;
  // pto: %post__ssa_v0_view
  int64_t v194 = (int64_t) v32;
  // pto: %post__ssa_v0_view
  int64_t v195 = v194 * v77;
  // pto: %post__ssa_v0_view
  int64_t v196 = v193 * v195;
  // pto: %post__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v197 = pto::Shape<1, 1, 1, -1, -1>(v191, v192, v193, v194, v77);
  // pto: %post__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v198 = pto::Stride<-1, -1, -1, -1, -1>(v192 * v196, v196, v195, v77, v70);
  // pto: %post__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v199 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v21, v197, v198);
  // pto: %comb__ssa_v0_view
  const int64_t v200 = 1;
  // pto: %comb__ssa_v0_view
  const int64_t v201 = 1;
  // pto: %comb__ssa_v0_view
  const int64_t v202 = 1;
  // pto: %comb__ssa_v0_view
  int64_t v203 = (int64_t) v32;
  // pto: %comb__ssa_v0_view
  int64_t v204 = v203 * v71;
  // pto: %comb__ssa_v0_view
  int64_t v205 = v202 * v204;
  // pto: %comb__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v206 = pto::Shape<1, 1, 1, -1, -1>(v200, v201, v202, v203, v71);
  // pto: %comb__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v207 = pto::Stride<-1, -1, -1, -1, -1>(v201 * v205, v205, v204, v71, v70);
  // pto: %comb__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v208 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v22, v206, v207);
  // pto: %mixed__ssa_v0_view
  const int64_t v209 = 1;
  // pto: %mixed__ssa_v0_view
  const int64_t v210 = 1;
  // pto: %mixed__ssa_v0_view
  const int64_t v211 = 1;
  // pto: %mixed__ssa_v0_view
  int64_t v212 = (int64_t) v32;
  // pto: %mixed__ssa_v0_view
  int64_t v213 = v212 * v74;
  // pto: %mixed__ssa_v0_view
  int64_t v214 = v211 * v213;
  // pto: %mixed__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v215 = pto::Shape<1, 1, 1, -1, -1>(v209, v210, v211, v212, v74);
  // pto: %mixed__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v216 = pto::Stride<-1, -1, -1, -1, -1>(v210 * v214, v214, v213, v74, v70);
  // pto: %mixed__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v217 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v23, v215, v216);
  // pto: %mixed_tail__ssa_v0_view
  const int64_t v218 = 1;
  // pto: %mixed_tail__ssa_v0_view
  const int64_t v219 = 1;
  // pto: %mixed_tail__ssa_v0_view
  const int64_t v220 = 1;
  // pto: %mixed_tail__ssa_v0_view
  int64_t v221 = v79 * v74;
  // pto: %mixed_tail__ssa_v0_view
  int64_t v222 = v220 * v221;
  // pto: %mixed_tail__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v223 = pto::Shape<1, 1, 1, -1, -1>(v218, v219, v220, v79, v74);
  // pto: %mixed_tail__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v224 = pto::Stride<-1, -1, -1, -1, -1>(v219 * v222, v222, v221, v74, v70);
  // pto: %mixed_tail__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v225 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v24, v223, v224);
  // pto: %gamma__ssa_v0_view
  const int64_t v226 = 1;
  // pto: %gamma__ssa_v0_view
  const int64_t v227 = 1;
  // pto: %gamma__ssa_v0_view
  const int64_t v228 = 1;
  // pto: %gamma__ssa_v0_view
  const int64_t v229 = 1;
  // pto: %gamma__ssa_v0_view
  int64_t v230 = v74 * v70;
  // pto: %gamma__ssa_v0_view
  int64_t v231 = v229 * v230;
  // pto: %gamma__ssa_v0_view
  int64_t v232 = v228 * v231;
  // pto: %gamma__ssa_v0_view
  pto::Shape<1, 1, 1, 1, -1> v233 = pto::Shape<1, 1, 1, 1, -1>(v226, v227, v228, v229, v74);
  // pto: %gamma__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v234 = pto::Stride<-1, -1, -1, -1, -1>(v227 * v232, v232, v231, v230, v70);
  // pto: %gamma__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v235 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v25, v233, v234);
  // pto: %accum_read__ssa_v0_view
  const int64_t v236 = 1;
  // pto: %accum_read__ssa_v0_view
  const int64_t v237 = 1;
  // pto: %accum_read__ssa_v0_view
  const int64_t v238 = 1;
  // pto: %accum_read__ssa_v0_view
  int64_t v239 = (int64_t) v35;
  // pto: %accum_read__ssa_v0_view
  int64_t v240 = v239 * v75;
  // pto: %accum_read__ssa_v0_view
  int64_t v241 = v238 * v240;
  // pto: %accum_read__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v242 = pto::Shape<1, 1, 1, -1, -1>(v236, v237, v238, v239, v75);
  // pto: %accum_read__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v243 = pto::Stride<-1, -1, -1, -1, -1>(v237 * v241, v241, v240, v75, v70);
  // pto: %accum_read__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v244 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v26, v242, v243);
  // pto: %output__ssa_v0_view
  const int64_t v245 = 1;
  // pto: %output__ssa_v0_view
  const int64_t v246 = 1;
  // pto: %output__ssa_v0_view
  const int64_t v247 = 1;
  // pto: %output__ssa_v0_view
  int64_t v248 = (int64_t) v32;
  // pto: %output__ssa_v0_view
  int64_t v249 = v248 * v75;
  // pto: %output__ssa_v0_view
  int64_t v250 = v247 * v249;
  // pto: %output__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v251 = pto::Shape<1, 1, 1, -1, -1>(v245, v246, v247, v248, v75);
  // pto: %output__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v252 = pto::Stride<-1, -1, -1, -1, -1>(v246 * v250, v250, v249, v75, v70);
  // pto: %output__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v253 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v27, v251, v252);
  // pto: %idx_accum_read__ssa_v0_view
  const int64_t v254 = 1;
  // pto: %idx_accum_read__ssa_v0_view
  const int64_t v255 = 1;
  // pto: %idx_accum_read__ssa_v0_view
  const int64_t v256 = 1;
  // pto: %idx_accum_read__ssa_v0_view
  int64_t v257 = (int64_t) v34;
  // pto: %idx_accum_read__ssa_v0_view
  int64_t v258 = v257 * v76;
  // pto: %idx_accum_read__ssa_v0_view
  int64_t v259 = v256 * v258;
  // pto: %idx_accum_read__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v260 = pto::Shape<1, 1, 1, -1, -1>(v254, v255, v256, v257, v76);
  // pto: %idx_accum_read__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v261 = pto::Stride<-1, -1, -1, -1, -1>(v255 * v259, v259, v258, v76, v70);
  // pto: %idx_accum_read__ssa_v0_view
  GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v262 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v28, v260, v261);
  // pto: %idx_raw__ssa_v0_view
  const int64_t v263 = 1;
  // pto: %idx_raw__ssa_v0_view
  const int64_t v264 = 1;
  // pto: %idx_raw__ssa_v0_view
  const int64_t v265 = 1;
  // pto: %idx_raw__ssa_v0_view
  int64_t v266 = (int64_t) v32;
  // pto: %idx_raw__ssa_v0_view
  int64_t v267 = v266 * v76;
  // pto: %idx_raw__ssa_v0_view
  int64_t v268 = v265 * v267;
  // pto: %idx_raw__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v269 = pto::Shape<1, 1, 1, -1, -1>(v263, v264, v265, v266, v76);
  // pto: %idx_raw__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v270 = pto::Stride<-1, -1, -1, -1, -1>(v264 * v268, v268, v267, v76, v70);
  // pto: %idx_raw__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v271 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v29, v269, v270);
  // pto: %idx_scaled__ssa_v0_view
  const int64_t v272 = 1;
  // pto: %idx_scaled__ssa_v0_view
  const int64_t v273 = 1;
  // pto: %idx_scaled__ssa_v0_view
  const int64_t v274 = 1;
  // pto: %idx_scaled__ssa_v0_view
  int64_t v275 = (int64_t) v32;
  // pto: %idx_scaled__ssa_v0_view
  int64_t v276 = v275 * v76;
  // pto: %idx_scaled__ssa_v0_view
  int64_t v277 = v274 * v276;
  // pto: %idx_scaled__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v278 = pto::Shape<1, 1, 1, -1, -1>(v272, v273, v274, v275, v76);
  // pto: %idx_scaled__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v279 = pto::Stride<-1, -1, -1, -1, -1>(v273 * v277, v277, v276, v76, v70);
  // pto: %idx_scaled__ssa_v0_view
  GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v280 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v30, v278, v279);
  // pto: %idx_output__ssa_v0_view
  const int64_t v281 = 1;
  // pto: %idx_output__ssa_v0_view
  const int64_t v282 = 1;
  // pto: %idx_output__ssa_v0_view
  const int64_t v283 = 1;
  // pto: %idx_output__ssa_v0_view
  int64_t v284 = (int64_t) v32;
  // pto: %idx_output__ssa_v0_view
  int64_t v285 = v284 * v76;
  // pto: %idx_output__ssa_v0_view
  int64_t v286 = v283 * v285;
  // pto: %idx_output__ssa_v0_view
  pto::Shape<1, 1, 1, -1, -1> v287 = pto::Shape<1, 1, 1, -1, -1>(v281, v282, v283, v284, v76);
  // pto: %idx_output__ssa_v0_view
  pto::Stride<-1, -1, -1, -1, -1> v288 = pto::Stride<-1, -1, -1, -1, -1>(v282 * v286, v286, v285, v76, v70);
  // pto: %idx_output__ssa_v0_view
  GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v289 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, -1>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v31, v287, v288);
  uint64_t v290 = reinterpret_cast<uint64_t>(v10);
  set_ffts_base_addr(v290);
  // pto: %t__tmp_v0, %88, %89, %t__tmp_v1
  int64_t v291 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) v37) * (uint64_t) v80) + (uint64_t) ((int64_t) v39));
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  set_flag(PIPE_S, PIPE_V, EVENT_ID4);
  for (int64_t v292 = v291; v292 < v32; v292 += v81) {
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    for (int64_t v293 = v82; v293 < v73; v293 += v80) {
      // pto: %90
      ;
      int64_t v294 = (int64_t) ((uint64_t) v293 * (uint64_t) v75);
      // pto: %92
      ;
      int64_t v295 = (int64_t) ((uint64_t) v294 + (uint64_t) v75);
      // pto: %t__tile
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v296 = Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
      // pto: %t__tile
      ;
      uint64_t v297 = (uint64_t) v45;
      TASSIGN(v296, v297);
      // pto: %93
      ;
      int64_t v298 = v292 < v82 ? v82 : v292;
      // pto: %94
      ;
      int64_t v299 = v294 < v82 ? v82 : v294;
      // pto: %flat__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v300 = PTOAS__GLOBAL_TENSOR_DATA(v145);
      // pto: %flat__ssa_v0_pview
      ;
      const int64_t v301 = 0;
      // pto: %flat__ssa_v0_pview
      ;
      const int64_t v302 = 16384;
      // pto: %flat__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v303 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %flat__ssa_v0_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v304 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %flat__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v305 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v300 + (v301 + v298 * v302 + v299), v303, v304);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      TLOAD(v296, v305);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %0
      ;
      Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v306 = Tile<TileType::Vec, bfloat16_t, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
      // pto: %0
      ;
      uint64_t v307 = (uint64_t) v46;
      TASSIGN(v306, v307);
      // pto: %96
      ;
      int64_t v308 = v295 < v82 ? v82 : v295;
      // pto: %97
      ;
      __gm__ bfloat16_t* v309 = PTOAS__GLOBAL_TENSOR_DATA(v145);
      // pto: %97
      ;
      const int64_t v310 = 0;
      // pto: %97
      ;
      const int64_t v311 = 16384;
      // pto: %97
      ;
      pto::Shape<1, 1, 1, 1, 512> v312 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %97
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v313 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %97
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v314 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v309 + (v310 + v298 * v311 + v308), v312, v313);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      TLOAD(v306, v314);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %value_inline1015__tile
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v315 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
      // pto: %value_inline1015__tile
      ;
      uint64_t v316 = (uint64_t) v47;
      TASSIGN(v315, v316);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      RoundMode v317 = RoundMode::CAST_ROUND;
      SaturationMode v318 = SaturationMode::ON;
      TCVT(v315, v296, v317, v318);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
      // pto: %wide__iter_v3_pview
      ;
      __gm__ float* v319 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %wide__iter_v3_pview
      ;
      const int64_t v320 = 0;
      // pto: %wide__iter_v3_pview
      ;
      const int64_t v321 = 16384;
      // pto: %wide__iter_v3_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v322 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %wide__iter_v3_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v323 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %wide__iter_v3_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v324 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v319 + (v320 + v298 * v321 + v299), v322, v323);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v324, v315);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
      // pto: %1
      ;
      Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v325 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
      // pto: %1
      ;
      uint64_t v326 = (uint64_t) v48;
      TASSIGN(v325, v326);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
      RoundMode v327 = RoundMode::CAST_ROUND;
      SaturationMode v328 = SaturationMode::ON;
      TCVT(v325, v306, v327, v328);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %wide__tile_pview
      ;
      __gm__ float* v329 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %wide__tile_pview
      ;
      const int64_t v330 = 0;
      // pto: %wide__tile_pview
      ;
      const int64_t v331 = 16384;
      // pto: %wide__tile_pview
      ;
      pto::Shape<1, 1, 1, 1, 512> v332 = pto::Shape<1, 1, 1, 1, 512>();
      // pto: %wide__tile_pview
      ;
      pto::Stride<16384, 16384, 16384, 16384, 1> v333 = pto::Stride<16384, 16384, 16384, 16384, 1>();
      // pto: %wide__tile_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND> v334 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 512>, pto::Stride<16384, 16384, 16384, 16384, 1>, pto::Layout::ND>(v329 + (v330 + v298 * v331 + v308), v332, v333);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v334, v325);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %103
  int64_t v335 = (int64_t) ((uint64_t) v36 - (uint64_t) v79);
  // pto: %104, %105
  int64_t v336 = (int64_t) ((uint64_t) v32 + (uint64_t) v83) / v79;
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID2);
  for (int64_t v337 = v291; v337 < v336; v337 += v81) {
    // pto: %106
    ;
    int64_t v338 = (int64_t) ((uint64_t) v337 * (uint64_t) v79);
    // pto: %rms_lanes_inline1028__ci_tmp_v0
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v339 = Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v84);
    // pto: %rms_lanes_inline1028__ci_tmp_v0
    ;
    uint64_t v340 = (uint64_t) v47;
    TASSIGN(v339, v340);
    // pto: %rms_lanes_inline1028__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v341 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_lanes_inline1028__tile
    ;
    uint64_t v342 = (uint64_t) v48;
    TASSIGN(v341, v342);
    // pto: %ci_tmp_view
    ;
    Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v343;
    TRESHAPE(v343, v339);
    // pto: %ci_dst_view
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v344;
    TRESHAPE(v344, v341);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
    TCI<Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, 1, 8, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, Tile<TileType::Vec, float, 1, 192, BLayout::RowMajor, 1, 192, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>, int32_t, 0>(v344, v85, v343);
    // pto: %rms_rows_inline1030__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v345 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_rows_inline1030__tile
    ;
    uint64_t v346 = (uint64_t) v47;
    TASSIGN(v345, v346);
    // pto: %107
    ;
    int32_t v347 = (int32_t) v338;
    pipe_barrier(PIPE_V);
    TADDS(v345, v341, v347);
    // pto: %rms_local_inline1033__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v348 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_local_inline1033__tile
    ;
    uint64_t v349 = (uint64_t) v48;
    TASSIGN(v348, v349);
    // pto: %108, %109
    ;
    int32_t v350 = (int32_t) (v338 % v71);
    pipe_barrier(PIPE_V);
    TADDS(v348, v341, v350);
    // pto: %2
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v351 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %2
    ;
    uint64_t v352 = (uint64_t) v47;
    TASSIGN(v351, v352);
    TMULS(v351, v345, v86);
    // pto: %rms_index_inline1034__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v353 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_index_inline1034__tile
    ;
    uint64_t v354 = (uint64_t) v47;
    TASSIGN(v353, v354);
    pipe_barrier(PIPE_V);
    TADD(v353, v351, v348);
    set_flag(PIPE_V, PIPE_S, EVENT_ID1);
    // pto: %rms_total_inline1026__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v355 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_total_inline1026__tile
    ;
    uint64_t v356 = (uint64_t) v48;
    TASSIGN(v355, v356);
    // pto: %square_read__ssa_v0_pview
    ;
    const int64_t v357 = 0;
    // pto: %square_read__ssa_v0_pview
    ;
    __gm__ float* v358 = PTOAS__GLOBAL_TENSOR_DATA(v154);
    // pto: %square_read__ssa_v0_pview
    ;
    const int64_t v359 = 1;
    // pto: %square_read__ssa_v0_pview
    ;
    const int64_t v360 = 1;
    // pto: %square_read__ssa_v0_pview
    ;
    const int64_t v361 = 1;
    // pto: %square_read__ssa_v0_pview
    ;
    int64_t v362 = (int64_t) v33;
    // pto: %square_read__ssa_v0_pview
    ;
    int64_t v363 = v362 * v71;
    // pto: %square_read__ssa_v0_pview
    ;
    int64_t v364 = v361 * v363;
    // pto: %square_read__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 16> v365 = pto::Shape<1, 1, 1, -1, 16>(v359, v360, v361, v362, v71);
    // pto: %square_read__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v366 = pto::Stride<-1, -1, -1, -1, -1>(v360 * v364, v364, v363, v71, v70);
    // pto: %square_read__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v367 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 16>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v358 + (v357 + v82 * v71 + v82 * v70), v365, v366);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID1);
    MGATHER<pto::Coalesce::Elem>(v355, v367, v353);
    set_flag(PIPE_S, PIPE_V, EVENT_ID2);
    for (int64_t v368 = v70; v368 < v87; v368 += v70) {
      // pto: %rms_part_index_inline1023__tile
      ;
      Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v369 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %rms_part_index_inline1023__tile
      ;
      uint64_t v370 = (uint64_t) v45;
      TASSIGN(v369, v370);
      // pto: %110, %111, %112
      ;
      int32_t v371 = (int32_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v368 * (uint64_t) v335) * (uint64_t) v71);
      pipe_barrier(PIPE_V);
      TADDS(v369, v353, v371);
      set_flag(PIPE_V, PIPE_S, EVENT_ID2);
      // pto: %rms_value_inline1035__tile
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v372 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %rms_value_inline1035__tile
      ;
      uint64_t v373 = (uint64_t) v46;
      TASSIGN(v372, v373);
      wait_flag(PIPE_V, PIPE_S, EVENT_ID2);
      MGATHER<pto::Coalesce::Elem>(v372, v367, v369);
      set_flag(PIPE_S, PIPE_V, EVENT_ID1);
      // pto: %3
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v374 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %3
      ;
      uint64_t v375 = (uint64_t) v48;
      TASSIGN(v374, v375);
      wait_flag(PIPE_S, PIPE_V, EVENT_ID1);
      TADD(v374, v355, v372);
    };
    // pto: %4
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v376 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %4
    ;
    uint64_t v377 = (uint64_t) v47;
    TASSIGN(v376, v377);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID2);
    TMULS(v376, v355, v88);
    // pto: %rms_variance_inline1022__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v378 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_variance_inline1022__tile
    ;
    uint64_t v379 = (uint64_t) v47;
    TASSIGN(v378, v379);
    pipe_barrier(PIPE_V);
    TADDS(v378, v376, v89);
    // pto: %rms_root_inline1021__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v380 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rms_root_inline1021__tile
    ;
    uint64_t v381 = (uint64_t) v47;
    TASSIGN(v380, v381);
    pipe_barrier(PIPE_V);
    TSQRT(v380, v378);
    // pto: %5
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v382 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %5
    ;
    uint64_t v383 = (uint64_t) v48;
    TASSIGN(v382, v383);
    TEXPANDS(v382, v90);
    // pto: %native_inverse_inline1020__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v384 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %native_inverse_inline1020__tile
    ;
    uint64_t v385 = (uint64_t) v47;
    TASSIGN(v384, v385);
    pipe_barrier(PIPE_V);
    TDIV(v384, v382, v380);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
    // pto: %114
    ;
    int64_t v386 = v338 < v82 ? v82 : v338;
    // pto: %vec_ws__iter_v1_pview
    ;
    __gm__ float* v387 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %vec_ws__iter_v1_pview
    ;
    const int64_t v388 = 40;
    // pto: %vec_ws__iter_v1_pview
    ;
    const int64_t v389 = 64;
    // pto: %vec_ws__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v390 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %vec_ws__iter_v1_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v391 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %vec_ws__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v392 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v387 + (v388 + v386 * v389), v390, v391);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
    TSTORE(v392, v384);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  // pto: %115, %panel64_inputs_per_task_inline1044__phi_v2
  int64_t v393 = v32 >= v76 ? v77 : v70;
  // pto: %116, %117, %118
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  for (int64_t v394 = v291; v394 < ((int64_t) ((uint64_t) (v34 / v71) * (uint64_t) v76) / v393); v394 += v81) {
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    for (int64_t v395 = v82; v395 < v393; v395 += v70) {
      // pto: %119, %120
      ;
      int64_t v396 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v394 * (uint64_t) v393) + (uint64_t) v395);
      // pto: %121, %122
      ;
      int64_t v397 = (int64_t) ((uint64_t) (v396 / v76) * (uint64_t) v71);
      // pto: %123
      ;
      int64_t v398 = v396 % v76;
      // pto: %124
      ;
      int64_t v399 = (int64_t) ((uint64_t) v398 * (uint64_t) v91);
      // pto: %125
      ;
      int64_t v400 = (int64_t) ((uint64_t) v32 - (uint64_t) v397);
      // pto: %126
      ;
      int64_t v401 = v400 < v71 ? v400 : v71;
      // pto: %panel64_values_inline1043__ssa_v0
      ;
      Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v402 = Tile<TileType::Vec, float, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v401, v91);
      // pto: %panel64_values_inline1043__ssa_v0
      ;
      uint64_t v403 = (uint64_t) v47;
      TASSIGN(v402, v403);
      // pto: %127
      ;
      int64_t v404 = v397 < v82 ? v82 : v397;
      // pto: %128
      ;
      int64_t v405 = v399 < v82 ? v82 : v399;
      // pto: %wide_v1__ssa_v0_pview
      ;
      const int64_t v406 = 0;
      // pto: %wide_v1__ssa_v0_pview
      ;
      __gm__ float* v407 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %wide_v1__ssa_v0_pview
      ;
      const int64_t v408 = 1;
      // pto: %wide_v1__ssa_v0_pview
      ;
      const int64_t v409 = 1;
      // pto: %wide_v1__ssa_v0_pview
      ;
      const int64_t v410 = 1;
      // pto: %wide_v1__ssa_v0_pview
      ;
      int64_t v411 = v401 * v69;
      // pto: %wide_v1__ssa_v0_pview
      ;
      int64_t v412 = v410 * v411;
      // pto: %wide_v1__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, -1, 256> v413 = pto::Shape<1, 1, 1, -1, 256>(v408, v409, v410, v401, v91);
      // pto: %wide_v1__ssa_v0_pview
      ;
      pto::Stride<-1, -1, -1, -1, -1> v414 = pto::Stride<-1, -1, -1, -1, -1>(v409 * v412, v412, v411, v69, v70);
      // pto: %wide_v1__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v415 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v407 + (v406 + v404 * v69 + v405 * v70), v413, v414);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v402, v415);
      set_flag(PIPE_MTE2, PIPE_S, EVENT_ID1);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      wait_flag(PIPE_MTE2, PIPE_S, EVENT_ID1);
      for (int64_t v416 = v401; v416 < v71; v416 += v70) {
        for (int64_t v417 = v82; v417 < v91; v417 += v70) {
          // pto: %flat_offset_mul, %flat_offset
          ;
          int64_t v418 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v416 * (uint64_t) v91) + (uint64_t) v417);
          v402.SetValue(v418, v92);
        };
      };
      set_flag(PIPE_S, PIPE_V, EVENT_ID3);
      v402.SetValidShape(v71, v91);
      // pto: %panel64_values_v2_inline1053__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v419 = Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v91);
      // pto: %panel64_values_v2_inline1053__ssa_v0
      ;
      uint64_t v420 = (uint64_t) v47;
      TASSIGN(v419, v420);
      wait_flag(PIPE_S, PIPE_V, EVENT_ID3);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      RoundMode v421 = RoundMode::CAST_ROUND;
      SaturationMode v422 = SaturationMode::ON;
      TCVT(v419, v402, v421, v422);
      // pto: %transpose_tmp
      ;
      Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v423 = Tile<TileType::Vec, bfloat16_t, 16, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v91);
      // pto: %transpose_tmp
      ;
      uint64_t v424 = (uint64_t) v48;
      TASSIGN(v423, v424);
      // pto: %panel64_transposed_values_inline1039__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v425 = Tile<TileType::Vec, bfloat16_t, 256, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v91, v71);
      // pto: %panel64_transposed_values_inline1039__ssa_v0
      ;
      uint64_t v426 = (uint64_t) v45;
      TASSIGN(v425, v426);
      pipe_barrier(PIPE_V);
      wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
      TTRANS(v425, v419, v423);
      // pto: %panel64_packed_transposed_inline1038__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v427 = Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v75, v71);
      // pto: %panel64_packed_transposed_inline1038__ssa_v0
      ;
      uint64_t v428 = (uint64_t) v47;
      TASSIGN(v427, v428);
      pipe_barrier(PIPE_V);
      TEXPANDS(v427, v93);
      for (int64_t v429 = v82; v429 < v73; v429 += v70) {
        // pto: %panel64_input8_inline1037__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v430 = Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v71);
        // pto: %panel64_input8_inline1037__ssa_v0
        ;
        uint64_t v431 = (uint64_t) v45;
        TASSIGN(v430, v431);
        // pto: %slice_view
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v432;
        // pto: %133, %slice_view
        ;
        uint64_t v433 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v429 * (uint64_t) v79) * (uint64_t) v60) + (uint64_t) v45);
        TASSIGN(v432, v433);
        // pto: %134
        ;
        int64_t v434 = (int64_t) ((uint64_t) v429 * (uint64_t) v71);
        // pto: %assemble_view
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v435;
        // pto: %assemble_view
        ;
        uint64_t v436 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v434 * (uint64_t) v60) + (uint64_t) v47);
        TASSIGN(v435, v436);
        pipe_barrier(PIPE_V);
        TMOV(v435, v432);
        // pto: %137
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 16, BLayout::RowMajor, 8, 16, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v437;
        // pto: %136, %137
        ;
        uint64_t v438 = (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v434 + (uint64_t) v79) * (uint64_t) v60) + (uint64_t) v47);
        TASSIGN(v437, v438);
        pipe_barrier(PIPE_V);
        TMOV(v437, v432);
      };
      // pto: %6
      ;
      Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v439 = Tile<TileType::Vec, bfloat16_t, 512, 16, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v75, v71);
      // pto: %6
      ;
      uint64_t v440 = (uint64_t) v48;
      TASSIGN(v439, v440);
      // pto: %panel64_packed_values_inline1050__ssa_v0
      ;
      Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v441 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v75);
      // pto: %panel64_packed_values_inline1050__ssa_v0
      ;
      uint64_t v442 = (uint64_t) v45;
      TASSIGN(v441, v442);
      pipe_barrier(PIPE_V);
      TTRANS(v441, v427, v439);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      int64_t v443 = (int64_t) ((uint64_t) v398 * (uint64_t) v75);
      // pto: %140
      ;
      int64_t v444 = v443 < v82 ? v82 : v443;
      // pto: %packed_flat__ssa_v0_pview
      ;
      __gm__ bfloat16_t* v445 = PTOAS__GLOBAL_TENSOR_DATA(v127);
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v446 = 0;
      // pto: %packed_flat__ssa_v0_pview
      ;
      const int64_t v447 = 32768;
      // pto: %packed_flat__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 16, 512> v448 = pto::Shape<1, 1, 1, 16, 512>();
      // pto: %packed_flat__ssa_v0_pview
      ;
      pto::Stride<524288, 524288, 524288, 32768, 1> v449 = pto::Stride<524288, 524288, 524288, 32768, 1>();
      // pto: %packed_flat__ssa_v0_pview
      ;
      GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND> v450 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 16, 512>, pto::Stride<524288, 524288, 524288, 32768, 1>, pto::Layout::ND>(v445 + (v446 + v404 * v447 + v444), v448, v449);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
      TSTORE(v450, v441);
      set_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %142
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  for (int64_t v451 = v291; v451 < (v335 / v71); v451 += v81) {
    // pto: %143
    ;
    int64_t v452 = (int64_t) ((uint64_t) v451 * (uint64_t) v71);
    // pto: %mixes_total_inline1056__tile
    ;
    Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v453 = Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v73);
    // pto: %mixes_total_inline1056__tile
    ;
    uint64_t v454 = (uint64_t) v47;
    TASSIGN(v453, v454);
    // pto: %144
    ;
    int64_t v455 = v452 < v82 ? v82 : v452;
    // pto: %linear_read__ssa_v0_pview
    ;
    __gm__ float* v456 = PTOAS__GLOBAL_TENSOR_DATA(v172);
    // pto: %linear_read__ssa_v0_pview
    ;
    const int64_t v457 = 0;
    // pto: %linear_read__ssa_v0_pview
    ;
    const int64_t v458 = 32;
    // pto: %linear_read__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v459 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %linear_read__ssa_v0_pview
    ;
    pto::Stride<512, 512, 512, 32, 1> v460 = pto::Stride<512, 512, 512, 32, 1>();
    // pto: %linear_read__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v461 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v456 + (v457 + v455 * v458), v459, v460);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    TLOAD(v453, v461);
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    for (int64_t v462 = v70; v462 < v87; v462 += v70) {
      // pto: %145, %146
      ;
      int64_t v463 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) v462 * (uint64_t) v335) + (uint64_t) v452);
      // pto: %partial_tile_inline1058__tile
      ;
      Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v464 = Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v73);
      // pto: %partial_tile_inline1058__tile
      ;
      uint64_t v465 = (uint64_t) v48;
      TASSIGN(v464, v465);
      // pto: %147
      ;
      int64_t v466 = v463 < v82 ? v82 : v463;
      // pto: %148
      ;
      __gm__ float* v467 = PTOAS__GLOBAL_TENSOR_DATA(v172);
      // pto: %148
      ;
      const int64_t v468 = 0;
      // pto: %148
      ;
      const int64_t v469 = 32;
      // pto: %148
      ;
      pto::Shape<1, 1, 1, 16, 32> v470 = pto::Shape<1, 1, 1, 16, 32>();
      // pto: %148
      ;
      pto::Stride<512, 512, 512, 32, 1> v471 = pto::Stride<512, 512, 512, 32, 1>();
      // pto: %148
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND> v472 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<512, 512, 512, 32, 1>, pto::Layout::ND>(v467 + (v468 + v466 * v469), v470, v471);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
      TLOAD(v464, v472);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %7
      ;
      Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v473 = Tile<TileType::Vec, float, 16, 32, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v71, v73);
      // pto: %7
      ;
      uint64_t v474 = (uint64_t) v47;
      TASSIGN(v473, v474);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      TADD(v473, v453, v464);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    __gm__ float* v475 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    const int64_t v476 = 0;
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    const int64_t v477 = 64;
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 16, 32> v478 = pto::Shape<1, 1, 1, 16, 32>();
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    pto::Stride<1024, 1024, 1024, 64, 1> v479 = pto::Stride<1024, 1024, 1024, 64, 1>();
    // pto: %vec_ws_v1__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND> v480 = GlobalTensor<float, pto::Shape<1, 1, 1, 16, 32>, pto::Stride<1024, 1024, 1024, 64, 1>, pto::Layout::ND>(v475 + (v476 + v455 * v477), v478, v479);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    TSTORE(v480, v453);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %scale0_inline1065__tile
  float v481 = (v18)[v82];
  // pto: %scale1_inline1067__tile
  float v482 = (v18)[v70];
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  for (int64_t v483 = v291; v483 < v336; v483 += v81) {
    // pto: %152
    ;
    int64_t v484 = (int64_t) ((uint64_t) v483 * (uint64_t) v79);
    // pto: %153
    ;
    int64_t v485 = (int64_t) ((uint64_t) v32 - (uint64_t) v484);
    // pto: %154
    ;
    int64_t v486 = v485 < v79 ? v485 : v79;
    // pto: %t__tmp_v8
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v487 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %t__tmp_v8
    ;
    uint64_t v488 = (uint64_t) v45;
    TASSIGN(v487, v488);
    // pto: %155
    ;
    int64_t v489 = v484 < v82 ? v82 : v484;
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    __gm__ float* v490 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    const int64_t v491 = 40;
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    const int64_t v492 = 64;
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v493 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v494 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %vec_ws_v2__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v495 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v490 + (v491 + v489 * v492), v493, v494);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    TLOAD(v487, v495);
    // pto: %inv_col_inline1073__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v496 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %inv_col_inline1073__ssa_v0
    ;
    uint64_t v497 = (uint64_t) v45;
    TASSIGN(v496, v497);
    // pto: %t__tmp_v9
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v498 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %t__tmp_v9
    ;
    uint64_t v499 = (uint64_t) v46;
    TASSIGN(v498, v499);
    // pto: %hc_base__ssa_v0_pview
    ;
    __gm__ float* v500 = PTOAS__GLOBAL_TENSOR_DATA(v182);
    // pto: %hc_base__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v501 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %hc_base__ssa_v0_pview
    ;
    pto::Stride<8, 8, 8, 8, 1> v502 = pto::Stride<8, 8, 8, 8, 1>();
    // pto: %hc_base__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v503 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v500, v501, v502);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    TLOAD(v498, v503);
    // pto: %pre_base_inline1074__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v504 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %pre_base_inline1074__ssa_v0
    ;
    uint64_t v505 = (uint64_t) v46;
    TASSIGN(v504, v505);
    // pto: %t__tmp_v10
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v506 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v10
    ;
    uint64_t v507 = (uint64_t) v47;
    TASSIGN(v506, v507);
    // pto: %157
    ;
    __gm__ float* v508 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %157
    ;
    const int64_t v509 = 0;
    // pto: %157
    ;
    const int64_t v510 = 64;
    // pto: %157
    ;
    pto::Shape<1, 1, 1, 8, 8> v511 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %157
    ;
    pto::Stride<512, 512, 512, 64, 1> v512 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %157
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v513 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v508 + (v509 + v489 * v510), v511, v512);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    TLOAD(v506, v513);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    // pto: %t__tmp_v11
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v514 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v11
    ;
    uint64_t v515 = (uint64_t) v47;
    TASSIGN(v514, v515);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
    TROWEXPANDMUL(v514, v506, v496);
    // pto: %pre_scaled_inline1076__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v516 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_scaled_inline1076__ssa_v0
    ;
    uint64_t v517 = (uint64_t) v47;
    TASSIGN(v516, v517);
    pipe_barrier(PIPE_V);
    TMULS(v516, v514, v481);
    // pto: %t__tmp_v12
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v518 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v12
    ;
    uint64_t v519 = (uint64_t) v48;
    TASSIGN(v518, v519);
    TCOLEXPAND(v518, v504);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %pre_logits_inline1078__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v520 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_logits_inline1078__ssa_v0
    ;
    uint64_t v521 = (uint64_t) v47;
    TASSIGN(v520, v521);
    pipe_barrier(PIPE_V);
    TADD(v520, v516, v518);
    // pto: %t__tmp_v13
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v522 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v13
    ;
    uint64_t v523 = (uint64_t) v48;
    TASSIGN(v522, v523);
    pipe_barrier(PIPE_V);
    TEXPANDS(v522, v90);
    // pto: %t__tmp_v14
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v524 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v14
    ;
    uint64_t v525 = (uint64_t) v47;
    TASSIGN(v524, v525);
    TNEG(v524, v520);
    // pto: %t__tmp_v15
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v526 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v15
    ;
    uint64_t v527 = (uint64_t) v47;
    TASSIGN(v526, v527);
    pipe_barrier(PIPE_V);
    TEXP(v526, v524);
    // pto: %t__tmp_v16
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v528 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v16
    ;
    uint64_t v529 = (uint64_t) v47;
    TASSIGN(v528, v529);
    pipe_barrier(PIPE_V);
    TADDS(v528, v526, v90);
    // pto: %pre_sig_inline1079__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v530 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_sig_inline1079__ssa_v0
    ;
    uint64_t v531 = (uint64_t) v47;
    TASSIGN(v530, v531);
    pipe_barrier(PIPE_V);
    TDIV(v530, v522, v528);
    // pto: %pre_val_inline1077__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v532 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_val_inline1077__ssa_v0
    ;
    uint64_t v533 = (uint64_t) v47;
    TASSIGN(v532, v533);
    pipe_barrier(PIPE_V);
    TADDS(v532, v530, v89);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
    // pto: %159
    ;
    __gm__ float* v534 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %159
    ;
    const int64_t v535 = 32;
    // pto: %159
    ;
    const int64_t v536 = 64;
    // pto: %159
    ;
    pto::Shape<1, 1, 1, 8, 8> v537 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %159
    ;
    pto::Stride<512, 512, 512, 64, 1> v538 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %159
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v539 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v534 + (v535 + v489 * v536), v537, v538);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
    TSTORE(v539, v532);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
    // pto: %t__tmp_v17
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v540 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %t__tmp_v17
    ;
    uint64_t v541 = (uint64_t) v46;
    TASSIGN(v540, v541);
    // pto: %160
    ;
    __gm__ float* v542 = PTOAS__GLOBAL_TENSOR_DATA(v182);
    // pto: %160
    ;
    unsigned v543 = 4;
    // pto: %160
    ;
    pto::Shape<1, 1, 1, 1, 8> v544 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %160
    ;
    pto::Stride<8, 8, 8, 8, 1> v545 = pto::Stride<8, 8, 8, 8, 1>();
    // pto: %160
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND> v546 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<8, 8, 8, 8, 1>, pto::Layout::ND>(v542 + v543, v544, v545);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v540, v546);
    // pto: %post_base_inline1068__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v547 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %post_base_inline1068__ssa_v0
    ;
    uint64_t v548 = (uint64_t) v46;
    TASSIGN(v547, v548);
    // pto: %t__tmp_v18
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v549 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v18
    ;
    uint64_t v550 = (uint64_t) v47;
    TASSIGN(v549, v550);
    // pto: %162
    ;
    __gm__ float* v551 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %162
    ;
    const int64_t v552 = 4;
    // pto: %162
    ;
    const int64_t v553 = 64;
    // pto: %162
    ;
    pto::Shape<1, 1, 1, 8, 8> v554 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %162
    ;
    pto::Stride<512, 512, 512, 64, 1> v555 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %162
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v556 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v551 + (v552 + v489 * v553), v554, v555);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
    TLOAD(v549, v556);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    // pto: %t__tmp_v19
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v557 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v19
    ;
    uint64_t v558 = (uint64_t) v47;
    TASSIGN(v557, v558);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
    TROWEXPANDMUL(v557, v549, v496);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
    // pto: %post_scaled_inline1075__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v559 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %post_scaled_inline1075__ssa_v0
    ;
    uint64_t v560 = (uint64_t) v47;
    TASSIGN(v559, v560);
    pipe_barrier(PIPE_V);
    TMULS(v559, v557, v482);
    // pto: %t__tmp_v20
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v561 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v20
    ;
    uint64_t v562 = (uint64_t) v48;
    TASSIGN(v561, v562);
    TCOLEXPAND(v561, v547);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
    // pto: %post_logits_inline1063__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v563 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %post_logits_inline1063__ssa_v0
    ;
    uint64_t v564 = (uint64_t) v47;
    TASSIGN(v563, v564);
    pipe_barrier(PIPE_V);
    TADD(v563, v559, v561);
    // pto: %t__tmp_v21
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v565 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v21
    ;
    uint64_t v566 = (uint64_t) v48;
    TASSIGN(v565, v566);
    pipe_barrier(PIPE_V);
    TEXPANDS(v565, v90);
    // pto: %t__tmp_v22
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v567 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v22
    ;
    uint64_t v568 = (uint64_t) v47;
    TASSIGN(v567, v568);
    TNEG(v567, v563);
    // pto: %t__tmp_v23
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v569 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v23
    ;
    uint64_t v570 = (uint64_t) v47;
    TASSIGN(v569, v570);
    pipe_barrier(PIPE_V);
    TEXP(v569, v567);
    // pto: %t__tmp_v24
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v571 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v24
    ;
    uint64_t v572 = (uint64_t) v47;
    TASSIGN(v571, v572);
    pipe_barrier(PIPE_V);
    TADDS(v571, v569, v90);
    // pto: %post_sig_inline1062__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v573 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %post_sig_inline1062__ssa_v0
    ;
    uint64_t v574 = (uint64_t) v47;
    TASSIGN(v573, v574);
    pipe_barrier(PIPE_V);
    TDIV(v573, v565, v571);
    // pto: %post_pad_inline1061__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v575 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %post_pad_inline1061__ssa_v0
    ;
    uint64_t v576 = (uint64_t) v47;
    TASSIGN(v575, v576);
    pipe_barrier(PIPE_V);
    TMULS(v575, v573, v94);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    // pto: %163
    ;
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    if (v486 == v79) {
      // pto: %t__tmp_v25
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v577 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v77);
      // pto: %t__tmp_v25
      ;
      uint64_t v578 = (uint64_t) v47;
      TASSIGN(v577, v578);
      // pto: %164
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, 8, 4, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v579;
      // pto: %164
      ;
      uint64_t v580 = (uint64_t) v47;
      TASSIGN(v579, v580);
      // pto: %post__ssa_v0_pview
      ;
      __gm__ float* v581 = PTOAS__GLOBAL_TENSOR_DATA(v199);
      // pto: %post__ssa_v0_pview
      ;
      const int64_t v582 = 0;
      // pto: %post__ssa_v0_pview
      ;
      const int64_t v583 = 4;
      // pto: %post__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 4> v584 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %post__ssa_v0_pview
      ;
      pto::Stride<32, 32, 32, 4, 1> v585 = pto::Stride<32, 32, 32, 4, 1>();
      // pto: %post__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<32, 32, 32, 4, 1>, pto::Layout::ND> v586 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<32, 32, 32, 4, 1>, pto::Layout::ND>(v581 + (v582 + v489 * v583), v584, v585);
      TSTORE(v586, v579);
    } else {
      // pto: %167
      ;
      int64_t v587 = v335 < v82 ? v82 : v335;
      // pto: %168
      ;
      __gm__ float* v588 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %168
      ;
      const int64_t v589 = 0;
      // pto: %168
      ;
      const int64_t v590 = 64;
      // pto: %168
      ;
      pto::Shape<1, 1, 1, 8, 8> v591 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %168
      ;
      pto::Stride<512, 512, 512, 64, 1> v592 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %168
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v593 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v588 + (v589 + v587 * v590), v591, v592);
      TSTORE(v593, v575);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      // pto: %post_tile_inline1066__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v594 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v486, v77);
      // pto: %post_tile_inline1066__ssa_v0
      ;
      uint64_t v595 = (uint64_t) v47;
      TASSIGN(v594, v595);
      // pto: %171
      ;
      const int64_t v596 = 0;
      // pto: %171
      ;
      __gm__ float* v597 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %171
      ;
      const int64_t v598 = 1;
      // pto: %171
      ;
      const int64_t v599 = 1;
      // pto: %171
      ;
      const int64_t v600 = 1;
      // pto: %171
      ;
      int64_t v601 = v486 * v76;
      // pto: %171
      ;
      int64_t v602 = v600 * v601;
      // pto: %171
      ;
      pto::Shape<1, 1, 1, -1, 4> v603 = pto::Shape<1, 1, 1, -1, 4>(v598, v599, v600, v486, v77);
      // pto: %171
      ;
      pto::Stride<-1, -1, -1, -1, -1> v604 = pto::Stride<-1, -1, -1, -1, -1>(v599 * v602, v602, v601, v76, v70);
      // pto: %171
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v605 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v597 + (v596 + v587 * v76 + v82 * v70), v603, v604);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
      TLOAD(v594, v605);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
      // pto: %173
      ;
      const int64_t v606 = 0;
      // pto: %173
      ;
      __gm__ float* v607 = PTOAS__GLOBAL_TENSOR_DATA(v199);
      // pto: %173
      ;
      const int64_t v608 = 1;
      // pto: %173
      ;
      const int64_t v609 = 1;
      // pto: %173
      ;
      const int64_t v610 = 1;
      // pto: %173
      ;
      int64_t v611 = v486 * v77;
      // pto: %173
      ;
      int64_t v612 = v610 * v611;
      // pto: %173
      ;
      pto::Shape<1, 1, 1, -1, 4> v613 = pto::Shape<1, 1, 1, -1, 4>(v608, v609, v610, v486, v77);
      // pto: %173
      ;
      pto::Stride<-1, -1, -1, -1, -1> v614 = pto::Stride<-1, -1, -1, -1, -1>(v609 * v612, v612, v611, v77, v70);
      // pto: %173
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v615 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v607 + (v606 + v489 * v77 + v82 * v70), v613, v614);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
      TSTORE(v615, v594);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  for (int64_t v616 = v291; v616 < v336; v616 += v81) {
    // pto: %scale2_inline1124__tile
    ;
    float v617 = (v18)[v80];
    // pto: %176
    ;
    int64_t v618 = (int64_t) ((uint64_t) v616 * (uint64_t) v79);
    // pto: %177
    ;
    int64_t v619 = (int64_t) ((uint64_t) v32 - (uint64_t) v618);
    // pto: %178
    ;
    int64_t v620 = v619 < v79 ? v619 : v79;
    // pto: %t__tmp_v28
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v621 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %t__tmp_v28
    ;
    uint64_t v622 = (uint64_t) v49;
    TASSIGN(v621, v622);
    // pto: %179
    ;
    int64_t v623 = v618 < v82 ? v82 : v618;
    // pto: %180
    ;
    __gm__ float* v624 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %180
    ;
    const int64_t v625 = 40;
    // pto: %180
    ;
    const int64_t v626 = 64;
    // pto: %180
    ;
    pto::Shape<1, 1, 1, 1, 8> v627 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %180
    ;
    pto::Stride<64, 64, 64, 64, 1> v628 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %180
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v629 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v624 + (v625 + v623 * v626), v627, v628);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v621, v629);
    // pto: %t__tmp_v29
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v630 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %t__tmp_v29
    ;
    uint64_t v631 = (uint64_t) v49;
    TASSIGN(v630, v631);
    v630.SetValidShape(v620, v70);
    // pto: %mix_g0_inline1131__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v632 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %mix_g0_inline1131__ssa_v0
    ;
    uint64_t v633 = (uint64_t) v47;
    TASSIGN(v632, v633);
    // pto: %183
    ;
    const int64_t v634 = 0;
    // pto: %183
    ;
    __gm__ float* v635 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %183
    ;
    const int64_t v636 = 1;
    // pto: %183
    ;
    const int64_t v637 = 1;
    // pto: %183
    ;
    const int64_t v638 = 1;
    // pto: %183
    ;
    int64_t v639 = v620 * v76;
    // pto: %183
    ;
    int64_t v640 = v638 * v639;
    // pto: %183
    ;
    pto::Shape<1, 1, 1, -1, 4> v641 = pto::Shape<1, 1, 1, -1, 4>(v636, v637, v638, v620, v77);
    // pto: %183
    ;
    pto::Stride<-1, -1, -1, -1, -1> v642 = pto::Stride<-1, -1, -1, -1, -1>(v637 * v640, v640, v639, v76, v70);
    // pto: %183
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v643 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v635 + (v634 + v623 * v76 + v79 * v70), v641, v642);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    TLOAD(v632, v643);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    // pto: %mix_g1_inline1129__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v644 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %mix_g1_inline1129__ssa_v0
    ;
    uint64_t v645 = (uint64_t) v48;
    TASSIGN(v644, v645);
    // pto: %187
    ;
    const int64_t v646 = 0;
    // pto: %187
    ;
    __gm__ float* v647 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %187
    ;
    const int64_t v648 = 1;
    // pto: %187
    ;
    const int64_t v649 = 1;
    // pto: %187
    ;
    const int64_t v650 = 1;
    // pto: %187
    ;
    int64_t v651 = v620 * v76;
    // pto: %187
    ;
    int64_t v652 = v650 * v651;
    // pto: %187
    ;
    pto::Shape<1, 1, 1, -1, 4> v653 = pto::Shape<1, 1, 1, -1, 4>(v648, v649, v650, v620, v77);
    // pto: %187
    ;
    pto::Stride<-1, -1, -1, -1, -1> v654 = pto::Stride<-1, -1, -1, -1, -1>(v649 * v652, v652, v651, v76, v70);
    // pto: %187
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v655 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v647 + (v646 + v623 * v76 + v95 * v70), v653, v654);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    TLOAD(v644, v655);
    // pto: %mix_g2_inline1122__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v656 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %mix_g2_inline1122__ssa_v0
    ;
    uint64_t v657 = (uint64_t) v45;
    TASSIGN(v656, v657);
    // pto: %191
    ;
    const int64_t v658 = 0;
    // pto: %191
    ;
    __gm__ float* v659 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %191
    ;
    const int64_t v660 = 1;
    // pto: %191
    ;
    const int64_t v661 = 1;
    // pto: %191
    ;
    const int64_t v662 = 1;
    // pto: %191
    ;
    int64_t v663 = v620 * v76;
    // pto: %191
    ;
    int64_t v664 = v662 * v663;
    // pto: %191
    ;
    pto::Shape<1, 1, 1, -1, 4> v665 = pto::Shape<1, 1, 1, -1, 4>(v660, v661, v662, v620, v77);
    // pto: %191
    ;
    pto::Stride<-1, -1, -1, -1, -1> v666 = pto::Stride<-1, -1, -1, -1, -1>(v661 * v664, v664, v663, v76, v70);
    // pto: %191
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v667 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v659 + (v658 + v623 * v76 + v71 * v70), v665, v666);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    TLOAD(v656, v667);
    // pto: %mix_g3_inline1130__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v668 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %mix_g3_inline1130__ssa_v0
    ;
    uint64_t v669 = (uint64_t) v46;
    TASSIGN(v668, v669);
    // pto: %195
    ;
    const int64_t v670 = 0;
    // pto: %195
    ;
    __gm__ float* v671 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %195
    ;
    const int64_t v672 = 1;
    // pto: %195
    ;
    const int64_t v673 = 1;
    // pto: %195
    ;
    const int64_t v674 = 1;
    // pto: %195
    ;
    int64_t v675 = v620 * v76;
    // pto: %195
    ;
    int64_t v676 = v674 * v675;
    // pto: %195
    ;
    pto::Shape<1, 1, 1, -1, 4> v677 = pto::Shape<1, 1, 1, -1, 4>(v672, v673, v674, v620, v77);
    // pto: %195
    ;
    pto::Stride<-1, -1, -1, -1, -1> v678 = pto::Stride<-1, -1, -1, -1, -1>(v673 * v676, v676, v675, v76, v70);
    // pto: %195
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v679 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v671 + (v670 + v623 * v76 + v44 * v70), v677, v678);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    TLOAD(v668, v679);
    // pto: %cb0_inline1134__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v680 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v77);
    // pto: %cb0_inline1134__ssa_v0
    ;
    uint64_t v681 = (uint64_t) v50;
    TASSIGN(v680, v681);
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    __gm__ float* v682 = PTOAS__GLOBAL_TENSOR_DATA(v190);
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    unsigned v683 = 8;
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 4> v684 = pto::Shape<1, 1, 1, 1, 4>();
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    pto::Stride<24, 24, 24, 24, 1> v685 = pto::Stride<24, 24, 24, 24, 1>();
    // pto: %hc_base_2d__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND> v686 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND>(v682 + v683, v684, v685);
    TLOAD(v680, v686);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    // pto: %cb1_inline1133__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v687 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v77);
    // pto: %cb1_inline1133__ssa_v0
    ;
    uint64_t v688 = (uint64_t) v51;
    TASSIGN(v687, v688);
    // pto: %199
    ;
    __gm__ float* v689 = PTOAS__GLOBAL_TENSOR_DATA(v190);
    // pto: %199
    ;
    unsigned v690 = 12;
    // pto: %199
    ;
    pto::Shape<1, 1, 1, 1, 4> v691 = pto::Shape<1, 1, 1, 1, 4>();
    // pto: %199
    ;
    pto::Stride<24, 24, 24, 24, 1> v692 = pto::Stride<24, 24, 24, 24, 1>();
    // pto: %199
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND> v693 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND>(v689 + v690, v691, v692);
    TLOAD(v687, v693);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %cb2_inline1097__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v694 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v77);
    // pto: %cb2_inline1097__ssa_v0
    ;
    uint64_t v695 = (uint64_t) v52;
    TASSIGN(v694, v695);
    // pto: %202
    ;
    __gm__ float* v696 = PTOAS__GLOBAL_TENSOR_DATA(v190);
    // pto: %202
    ;
    unsigned v697 = 16;
    // pto: %202
    ;
    pto::Shape<1, 1, 1, 1, 4> v698 = pto::Shape<1, 1, 1, 1, 4>();
    // pto: %202
    ;
    pto::Stride<24, 24, 24, 24, 1> v699 = pto::Stride<24, 24, 24, 24, 1>();
    // pto: %202
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND> v700 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND>(v696 + v697, v698, v699);
    TLOAD(v694, v700);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    // pto: %cb3_inline1109__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v701 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v77);
    // pto: %cb3_inline1109__ssa_v0
    ;
    uint64_t v702 = (uint64_t) v53;
    TASSIGN(v701, v702);
    // pto: %205
    ;
    __gm__ float* v703 = PTOAS__GLOBAL_TENSOR_DATA(v190);
    // pto: %205
    ;
    unsigned v704 = 20;
    // pto: %205
    ;
    pto::Shape<1, 1, 1, 1, 4> v705 = pto::Shape<1, 1, 1, 1, 4>();
    // pto: %205
    ;
    pto::Stride<24, 24, 24, 24, 1> v706 = pto::Stride<24, 24, 24, 24, 1>();
    // pto: %205
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND> v707 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4>, pto::Stride<24, 24, 24, 24, 1>, pto::Layout::ND>(v703 + v704, v705, v706);
    TLOAD(v701, v707);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    // pto: %t__tmp_v30
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v708 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %t__tmp_v30
    ;
    uint64_t v709 = (uint64_t) v54;
    TASSIGN(v708, v709);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v708, v632, v630);
    // pto: %t__tmp_v31
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v710 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %t__tmp_v31
    ;
    uint64_t v711 = (uint64_t) v54;
    TASSIGN(v710, v711);
    pipe_barrier(PIPE_V);
    TMULS(v710, v708, v617);
    // pto: %t__tmp_v32
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v712 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %t__tmp_v32
    ;
    uint64_t v713 = (uint64_t) v47;
    TASSIGN(v712, v713);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
    TCOLEXPAND(v712, v680);
    // pto: %row0_inline1100__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v714 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %row0_inline1100__ssa_v0
    ;
    uint64_t v715 = (uint64_t) v47;
    TASSIGN(v714, v715);
    pipe_barrier(PIPE_V);
    TADD(v714, v710, v712);
    // pto: %t__tmp_v33
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v716 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %t__tmp_v33
    ;
    uint64_t v717 = (uint64_t) v54;
    TASSIGN(v716, v717);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v716, v644, v630);
    // pto: %t__tmp_v34
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v718 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %t__tmp_v34
    ;
    uint64_t v719 = (uint64_t) v54;
    TASSIGN(v718, v719);
    pipe_barrier(PIPE_V);
    TMULS(v718, v716, v617);
    // pto: %t__tmp_v35
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v720 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %t__tmp_v35
    ;
    uint64_t v721 = (uint64_t) v48;
    TASSIGN(v720, v721);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TCOLEXPAND(v720, v687);
    // pto: %row1_inline1107__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v722 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %row1_inline1107__ssa_v0
    ;
    uint64_t v723 = (uint64_t) v48;
    TASSIGN(v722, v723);
    pipe_barrier(PIPE_V);
    TADD(v722, v718, v720);
    // pto: %t__tmp_v36
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v724 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %t__tmp_v36
    ;
    uint64_t v725 = (uint64_t) v54;
    TASSIGN(v724, v725);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v724, v656, v630);
    // pto: %t__tmp_v37
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v726 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %t__tmp_v37
    ;
    uint64_t v727 = (uint64_t) v54;
    TASSIGN(v726, v727);
    pipe_barrier(PIPE_V);
    TMULS(v726, v724, v617);
    // pto: %t__tmp_v38
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v728 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %t__tmp_v38
    ;
    uint64_t v729 = (uint64_t) v45;
    TASSIGN(v728, v729);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
    TCOLEXPAND(v728, v694);
    // pto: %row2_inline1108__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v730 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %row2_inline1108__ssa_v0
    ;
    uint64_t v731 = (uint64_t) v45;
    TASSIGN(v730, v731);
    pipe_barrier(PIPE_V);
    TADD(v730, v726, v728);
    // pto: %t__tmp_v39
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v732 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %t__tmp_v39
    ;
    uint64_t v733 = (uint64_t) v54;
    TASSIGN(v732, v733);
    pipe_barrier(PIPE_V);
    TROWEXPANDMUL(v732, v668, v630);
    // pto: %t__tmp_v40
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v734 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %t__tmp_v40
    ;
    uint64_t v735 = (uint64_t) v54;
    TASSIGN(v734, v735);
    pipe_barrier(PIPE_V);
    TMULS(v734, v732, v617);
    // pto: %t__tmp_v41
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v736 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %t__tmp_v41
    ;
    uint64_t v737 = (uint64_t) v46;
    TASSIGN(v736, v737);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
    TCOLEXPAND(v736, v701);
    // pto: %row3_inline1117__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v738 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
    // pto: %row3_inline1117__ssa_v0
    ;
    uint64_t v739 = (uint64_t) v46;
    TASSIGN(v738, v739);
    pipe_barrier(PIPE_V);
    TADD(v738, v734, v736);
    // pto: %row0_p_inline1118__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v740 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row0_p_inline1118__ssa_v0
    ;
    uint64_t v741 = (uint64_t) v47;
    TASSIGN(v740, v741);
    TFILLPAD<pto::TFillPadMode::InPlace>(v740, v714);
    // pto: %row1_p_inline1096__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v742 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row1_p_inline1096__ssa_v0
    ;
    uint64_t v743 = (uint64_t) v48;
    TASSIGN(v742, v743);
    TFILLPAD<pto::TFillPadMode::InPlace>(v742, v722);
    // pto: %row2_p_inline1095__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v744 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row2_p_inline1095__ssa_v0
    ;
    uint64_t v745 = (uint64_t) v45;
    TASSIGN(v744, v745);
    TFILLPAD<pto::TFillPadMode::InPlace>(v744, v730);
    // pto: %row3_p_inline1113__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v746 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row3_p_inline1113__ssa_v0
    ;
    uint64_t v747 = (uint64_t) v46;
    TASSIGN(v746, v747);
    pipe_barrier(PIPE_V);
    TFILLPAD<pto::TFillPadMode::InPlace>(v746, v738);
    // pto: %row_max_tmp_inline1093__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v748 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %row_max_tmp_inline1093__ssa_v0
    ;
    uint64_t v749 = (uint64_t) v54;
    TASSIGN(v748, v749);
    // pto: %row_sum_tmp_inline1156__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v750 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %row_sum_tmp_inline1156__ssa_v0
    ;
    uint64_t v751 = (uint64_t) v49;
    TASSIGN(v750, v751);
    // pto: %row0_max_inline1104__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v752 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row0_max_inline1104__ssa_v0
    ;
    uint64_t v753 = (uint64_t) v50;
    TASSIGN(v752, v753);
    TROWMAX(v752, v740, v748);
    // pto: %row1_max_inline1120__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v754 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row1_max_inline1120__ssa_v0
    ;
    uint64_t v755 = (uint64_t) v51;
    TASSIGN(v754, v755);
    pipe_barrier(PIPE_V);
    TROWMAX(v754, v742, v748);
    // pto: %row2_max_inline1099__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v756 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row2_max_inline1099__ssa_v0
    ;
    uint64_t v757 = (uint64_t) v52;
    TASSIGN(v756, v757);
    pipe_barrier(PIPE_V);
    TROWMAX(v756, v744, v748);
    // pto: %row3_max_inline1143__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v758 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row3_max_inline1143__ssa_v0
    ;
    uint64_t v759 = (uint64_t) v53;
    TASSIGN(v758, v759);
    pipe_barrier(PIPE_V);
    TROWMAX(v758, v746, v748);
    // pto: %t__tmp_v42
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v760 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v42
    ;
    uint64_t v761 = (uint64_t) v47;
    TASSIGN(v760, v761);
    TROWEXPANDSUB(v760, v740, v752);
    // pto: %row0_exp_inline1138__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v762 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row0_exp_inline1138__ssa_v0
    ;
    uint64_t v763 = (uint64_t) v47;
    TASSIGN(v762, v763);
    pipe_barrier(PIPE_V);
    TEXP(v762, v760);
    // pto: %t__tmp_v43
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v764 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v43
    ;
    uint64_t v765 = (uint64_t) v48;
    TASSIGN(v764, v765);
    TROWEXPANDSUB(v764, v742, v754);
    // pto: %row1_exp_inline1111__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v766 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row1_exp_inline1111__ssa_v0
    ;
    uint64_t v767 = (uint64_t) v48;
    TASSIGN(v766, v767);
    pipe_barrier(PIPE_V);
    TEXP(v766, v764);
    // pto: %t__tmp_v44
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v768 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v44
    ;
    uint64_t v769 = (uint64_t) v45;
    TASSIGN(v768, v769);
    TROWEXPANDSUB(v768, v744, v756);
    // pto: %row2_exp_inline1139__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v770 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row2_exp_inline1139__ssa_v0
    ;
    uint64_t v771 = (uint64_t) v45;
    TASSIGN(v770, v771);
    pipe_barrier(PIPE_V);
    TEXP(v770, v768);
    // pto: %t__tmp_v45
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v772 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v45
    ;
    uint64_t v773 = (uint64_t) v46;
    TASSIGN(v772, v773);
    TROWEXPANDSUB(v772, v746, v758);
    // pto: %row3_exp_inline1126__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v774 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row3_exp_inline1126__ssa_v0
    ;
    uint64_t v775 = (uint64_t) v46;
    TASSIGN(v774, v775);
    pipe_barrier(PIPE_V);
    TEXP(v774, v772);
    // pto: %row0_sum_inline1140__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v776 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row0_sum_inline1140__ssa_v0
    ;
    uint64_t v777 = (uint64_t) v54;
    TASSIGN(v776, v777);
    TROWSUM(v776, v762, v750);
    // pto: %row1_sum_inline1141__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v778 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row1_sum_inline1141__ssa_v0
    ;
    uint64_t v779 = (uint64_t) v50;
    TASSIGN(v778, v779);
    pipe_barrier(PIPE_V);
    TROWSUM(v778, v766, v750);
    // pto: %row2_sum_inline1144__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v780 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row2_sum_inline1144__ssa_v0
    ;
    uint64_t v781 = (uint64_t) v51;
    TASSIGN(v780, v781);
    pipe_barrier(PIPE_V);
    TROWSUM(v780, v770, v750);
    // pto: %row3_sum_inline1145__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v782 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %row3_sum_inline1145__ssa_v0
    ;
    uint64_t v783 = (uint64_t) v52;
    TASSIGN(v782, v783);
    pipe_barrier(PIPE_V);
    TROWSUM(v782, v774, v750);
    // pto: %t__tmp_v46
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v784 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v46
    ;
    uint64_t v785 = (uint64_t) v47;
    TASSIGN(v784, v785);
    TROWEXPANDDIV(v784, v762, v776);
    // pto: %row0_soft_inline1142__ssa_v1
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v786 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row0_soft_inline1142__ssa_v1
    ;
    uint64_t v787 = (uint64_t) v47;
    TASSIGN(v786, v787);
    pipe_barrier(PIPE_V);
    TADDS(v786, v784, v89);
    // pto: %t__tmp_v47
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v788 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v47
    ;
    uint64_t v789 = (uint64_t) v48;
    TASSIGN(v788, v789);
    TROWEXPANDDIV(v788, v766, v778);
    // pto: %row1_soft_inline1147__ssa_v1
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v790 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row1_soft_inline1147__ssa_v1
    ;
    uint64_t v791 = (uint64_t) v48;
    TASSIGN(v790, v791);
    pipe_barrier(PIPE_V);
    TADDS(v790, v788, v89);
    // pto: %t__tmp_v48
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v792 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v48
    ;
    uint64_t v793 = (uint64_t) v45;
    TASSIGN(v792, v793);
    TROWEXPANDDIV(v792, v770, v780);
    // pto: %row2_soft_inline1103__ssa_v1
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v794 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row2_soft_inline1103__ssa_v1
    ;
    uint64_t v795 = (uint64_t) v45;
    TASSIGN(v794, v795);
    pipe_barrier(PIPE_V);
    TADDS(v794, v792, v89);
    // pto: %t__tmp_v49
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v796 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v49
    ;
    uint64_t v797 = (uint64_t) v46;
    TASSIGN(v796, v797);
    TROWEXPANDDIV(v796, v774, v782);
    // pto: %row3_soft_inline1155__ssa_v1
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null> v798 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Min, CompactMode::Null>(v79, v79);
    // pto: %row3_soft_inline1155__ssa_v1
    ;
    uint64_t v799 = (uint64_t) v46;
    TASSIGN(v798, v799);
    pipe_barrier(PIPE_V);
    TADDS(v798, v796, v89);
    v786.SetValidShape(v79, v77);
    v790.SetValidShape(v79, v77);
    v794.SetValidShape(v79, v77);
    v798.SetValidShape(v79, v77);
    // pto: %row0_eff_inline1161__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v800 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row0_eff_inline1161__ssa_v0
    ;
    uint64_t v801 = (uint64_t) v47;
    TASSIGN(v800, v801);
    TFILLPAD<pto::TFillPadMode::InPlace>(v800, v786);
    // pto: %row1_eff_inline1136__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v802 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row1_eff_inline1136__ssa_v0
    ;
    uint64_t v803 = (uint64_t) v48;
    TASSIGN(v802, v803);
    TFILLPAD<pto::TFillPadMode::InPlace>(v802, v790);
    // pto: %row2_eff_inline1121__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v804 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row2_eff_inline1121__ssa_v0
    ;
    uint64_t v805 = (uint64_t) v45;
    TASSIGN(v804, v805);
    TFILLPAD<pto::TFillPadMode::InPlace>(v804, v794);
    // pto: %row3_eff_inline1112__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v806 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row3_eff_inline1112__ssa_v0
    ;
    uint64_t v807 = (uint64_t) v46;
    TASSIGN(v806, v807);
    pipe_barrier(PIPE_V);
    TFILLPAD<pto::TFillPadMode::InPlace>(v806, v798);
    // pto: %row_sum_tmp_iter_inline1094__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v808 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %row_sum_tmp_iter_inline1094__ssa_v0
    ;
    uint64_t v809 = (uint64_t) v54;
    TASSIGN(v808, v809);
    // pto: %t__tmp_v50
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v810 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v50
    ;
    uint64_t v811 = (uint64_t) v49;
    TASSIGN(v810, v811);
    TADD(v810, v800, v802);
    // pto: %t__tmp_v51
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v812 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %t__tmp_v51
    ;
    uint64_t v813 = (uint64_t) v49;
    TASSIGN(v812, v813);
    pipe_barrier(PIPE_V);
    TADD(v812, v810, v804);
    // pto: %col_sum_inline1127__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v814 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %col_sum_inline1127__ssa_v0
    ;
    uint64_t v815 = (uint64_t) v49;
    TASSIGN(v814, v815);
    pipe_barrier(PIPE_V);
    TADD(v814, v812, v806);
    // pto: %col_sum_v1_inline1154__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v816 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %col_sum_v1_inline1154__ssa_v0
    ;
    uint64_t v817 = (uint64_t) v49;
    TASSIGN(v816, v817);
    pipe_barrier(PIPE_V);
    TADDS(v816, v814, v89);
    // pto: %row0_cur_inline1092__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v818 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row0_cur_inline1092__ssa_v0
    ;
    uint64_t v819 = (uint64_t) v47;
    TASSIGN(v818, v819);
    pipe_barrier(PIPE_V);
    TDIV(v818, v800, v816);
    // pto: %row1_cur_inline1106__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v820 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row1_cur_inline1106__ssa_v0
    ;
    uint64_t v821 = (uint64_t) v48;
    TASSIGN(v820, v821);
    TDIV(v820, v802, v816);
    // pto: %row2_cur_inline1101__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v822 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row2_cur_inline1101__ssa_v0
    ;
    uint64_t v823 = (uint64_t) v45;
    TASSIGN(v822, v823);
    TDIV(v822, v804, v816);
    // pto: %row3_cur_inline1091__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v824 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row3_cur_inline1091__ssa_v0
    ;
    uint64_t v825 = (uint64_t) v46;
    TASSIGN(v824, v825);
    TDIV(v824, v806, v816);
    for (int64_t v826 = v82; v826 < v96; v826 += v80) {
      // pto: %t__tmp_v52
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v827 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %t__tmp_v52
      ;
      uint64_t v828 = (uint64_t) v49;
      TASSIGN(v827, v828);
      pipe_barrier(PIPE_V);
      TROWSUM(v827, v818, v808);
      // pto: %row0_rowsum_inline1089__rm_a0_tmp_v0
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v829 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row0_rowsum_inline1089__rm_a0_tmp_v0
      ;
      uint64_t v830 = (uint64_t) v49;
      TASSIGN(v829, v830);
      // pto: %row0_rowsum_inline1089__row_major_tmp_v1
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v831 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row0_rowsum_inline1089__row_major_tmp_v1
      ;
      uint64_t v832 = (uint64_t) v50;
      TASSIGN(v831, v832);
      pipe_barrier(PIPE_V);
      TADDS(v831, v829, v89);
      // pto: %row0_rowsum_inline1089__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v833 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %row0_rowsum_inline1089__ssa_v0
      ;
      uint64_t v834 = (uint64_t) v50;
      TASSIGN(v833, v834);
      // pto: %t__tmp_v53
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v835 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %t__tmp_v53
      ;
      uint64_t v836 = (uint64_t) v49;
      TASSIGN(v835, v836);
      pipe_barrier(PIPE_V);
      TROWSUM(v835, v820, v808);
      // pto: %row1_rowsum_inline1135__rm_a0_tmp_v2
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v837 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row1_rowsum_inline1135__rm_a0_tmp_v2
      ;
      uint64_t v838 = (uint64_t) v49;
      TASSIGN(v837, v838);
      // pto: %row1_rowsum_inline1135__row_major_tmp_v3
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v839 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row1_rowsum_inline1135__row_major_tmp_v3
      ;
      uint64_t v840 = (uint64_t) v51;
      TASSIGN(v839, v840);
      pipe_barrier(PIPE_V);
      TADDS(v839, v837, v89);
      // pto: %row1_rowsum_inline1135__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v841 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %row1_rowsum_inline1135__ssa_v0
      ;
      uint64_t v842 = (uint64_t) v51;
      TASSIGN(v841, v842);
      // pto: %t__tmp_v54
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v843 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %t__tmp_v54
      ;
      uint64_t v844 = (uint64_t) v49;
      TASSIGN(v843, v844);
      pipe_barrier(PIPE_V);
      TROWSUM(v843, v822, v808);
      // pto: %row2_rowsum_inline1088__rm_a0_tmp_v4
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v845 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row2_rowsum_inline1088__rm_a0_tmp_v4
      ;
      uint64_t v846 = (uint64_t) v49;
      TASSIGN(v845, v846);
      // pto: %row2_rowsum_inline1088__row_major_tmp_v5
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v847 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row2_rowsum_inline1088__row_major_tmp_v5
      ;
      uint64_t v848 = (uint64_t) v52;
      TASSIGN(v847, v848);
      pipe_barrier(PIPE_V);
      TADDS(v847, v845, v89);
      // pto: %row2_rowsum_inline1088__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v849 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %row2_rowsum_inline1088__ssa_v0
      ;
      uint64_t v850 = (uint64_t) v52;
      TASSIGN(v849, v850);
      // pto: %t__tmp_v55
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v851 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %t__tmp_v55
      ;
      uint64_t v852 = (uint64_t) v49;
      TASSIGN(v851, v852);
      pipe_barrier(PIPE_V);
      TROWSUM(v851, v824, v808);
      // pto: %row3_rowsum_inline1153__rm_a0_tmp_v6
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v853 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row3_rowsum_inline1153__rm_a0_tmp_v6
      ;
      uint64_t v854 = (uint64_t) v49;
      TASSIGN(v853, v854);
      // pto: %row3_rowsum_inline1153__row_major_tmp_v7
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v855 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %row3_rowsum_inline1153__row_major_tmp_v7
      ;
      uint64_t v856 = (uint64_t) v53;
      TASSIGN(v855, v856);
      pipe_barrier(PIPE_V);
      TADDS(v855, v853, v89);
      // pto: %row3_rowsum_inline1153__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v857 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %row3_rowsum_inline1153__ssa_v0
      ;
      uint64_t v858 = (uint64_t) v53;
      TASSIGN(v857, v858);
      // pto: %row0_norm_inline1087__ssa_v1
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v859 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row0_norm_inline1087__ssa_v1
      ;
      uint64_t v860 = (uint64_t) v49;
      TASSIGN(v859, v860);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v859, v818, v833);
      // pto: %row1_norm_inline1146__ssa_v1
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v861 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row1_norm_inline1146__ssa_v1
      ;
      uint64_t v862 = (uint64_t) v50;
      TASSIGN(v861, v862);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v861, v820, v841);
      // pto: %row2_norm_inline1086__ssa_v1
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v863 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row2_norm_inline1086__ssa_v1
      ;
      uint64_t v864 = (uint64_t) v51;
      TASSIGN(v863, v864);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v863, v822, v849);
      // pto: %row3_norm_inline1132__ssa_v1
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v865 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row3_norm_inline1132__ssa_v1
      ;
      uint64_t v866 = (uint64_t) v52;
      TASSIGN(v865, v866);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v865, v824, v857);
      // pto: %t__tmp_v56
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v867 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %t__tmp_v56
      ;
      uint64_t v868 = (uint64_t) v53;
      TASSIGN(v867, v868);
      pipe_barrier(PIPE_V);
      TADD(v867, v859, v861);
      // pto: %t__tmp_v57
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v869 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %t__tmp_v57
      ;
      uint64_t v870 = (uint64_t) v53;
      TASSIGN(v869, v870);
      pipe_barrier(PIPE_V);
      TADD(v869, v867, v863);
      // pto: %col_sum_v1_inline1154__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v871 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %col_sum_v1_inline1154__ssa_v3
      ;
      uint64_t v872 = (uint64_t) v53;
      TASSIGN(v871, v872);
      pipe_barrier(PIPE_V);
      TADD(v871, v869, v865);
      // pto: %col_sum_v1_inline1154__ssa_v4
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v873 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %col_sum_v1_inline1154__ssa_v4
      ;
      uint64_t v874 = (uint64_t) v53;
      TASSIGN(v873, v874);
      pipe_barrier(PIPE_V);
      TADDS(v873, v871, v89);
      // pto: %row0_cur_inline1092__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v875 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row0_cur_inline1092__ssa_v3
      ;
      uint64_t v876 = (uint64_t) v49;
      TASSIGN(v875, v876);
      pipe_barrier(PIPE_V);
      TDIV(v875, v859, v873);
      // pto: %row1_cur_inline1106__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v877 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row1_cur_inline1106__ssa_v3
      ;
      uint64_t v878 = (uint64_t) v50;
      TASSIGN(v877, v878);
      TDIV(v877, v861, v873);
      // pto: %row2_cur_inline1101__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v879 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row2_cur_inline1101__ssa_v3
      ;
      uint64_t v880 = (uint64_t) v51;
      TASSIGN(v879, v880);
      TDIV(v879, v863, v873);
      // pto: %row3_cur_inline1091__ssa_v3
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v881 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %row3_cur_inline1091__ssa_v3
      ;
      uint64_t v882 = (uint64_t) v52;
      TASSIGN(v881, v882);
      TDIV(v881, v865, v873);
      // pto: %8
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v883 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %8
      ;
      uint64_t v884 = (uint64_t) v55;
      TASSIGN(v883, v884);
      pipe_barrier(PIPE_V);
      TROWSUM(v883, v875, v808);
      // pto: %9
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v885 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %9
      ;
      uint64_t v886 = (uint64_t) v55;
      TASSIGN(v885, v886);
      // pto: %10
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v887 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %10
      ;
      uint64_t v888 = (uint64_t) v56;
      TASSIGN(v887, v888);
      pipe_barrier(PIPE_V);
      TADDS(v887, v885, v89);
      // pto: %11
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v889 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %11
      ;
      uint64_t v890 = (uint64_t) v56;
      TASSIGN(v889, v890);
      // pto: %12
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v891 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %12
      ;
      uint64_t v892 = (uint64_t) v55;
      TASSIGN(v891, v892);
      pipe_barrier(PIPE_V);
      TROWSUM(v891, v877, v808);
      // pto: %13
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v893 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %13
      ;
      uint64_t v894 = (uint64_t) v55;
      TASSIGN(v893, v894);
      // pto: %14
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v895 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %14
      ;
      uint64_t v896 = (uint64_t) v57;
      TASSIGN(v895, v896);
      pipe_barrier(PIPE_V);
      TADDS(v895, v893, v89);
      // pto: %15
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v897 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %15
      ;
      uint64_t v898 = (uint64_t) v57;
      TASSIGN(v897, v898);
      // pto: %16
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v899 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %16
      ;
      uint64_t v900 = (uint64_t) v55;
      TASSIGN(v899, v900);
      pipe_barrier(PIPE_V);
      TROWSUM(v899, v879, v808);
      // pto: %17
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v901 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %17
      ;
      uint64_t v902 = (uint64_t) v55;
      TASSIGN(v901, v902);
      // pto: %18
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v903 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %18
      ;
      uint64_t v904 = (uint64_t) v58;
      TASSIGN(v903, v904);
      pipe_barrier(PIPE_V);
      TADDS(v903, v901, v89);
      // pto: %19
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v905 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %19
      ;
      uint64_t v906 = (uint64_t) v58;
      TASSIGN(v905, v906);
      // pto: %20
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v907 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %20
      ;
      uint64_t v908 = (uint64_t) v55;
      TASSIGN(v907, v908);
      pipe_barrier(PIPE_V);
      TROWSUM(v907, v881, v808);
      // pto: %21
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v909 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %21
      ;
      uint64_t v910 = (uint64_t) v55;
      TASSIGN(v909, v910);
      // pto: %22
      ;
      Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v911 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
      // pto: %22
      ;
      uint64_t v912 = (uint64_t) v59;
      TASSIGN(v911, v912);
      pipe_barrier(PIPE_V);
      TADDS(v911, v909, v89);
      // pto: %23
      ;
      Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v913 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
      // pto: %23
      ;
      uint64_t v914 = (uint64_t) v59;
      TASSIGN(v913, v914);
      // pto: %24
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v915 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %24
      ;
      uint64_t v916 = (uint64_t) v55;
      TASSIGN(v915, v916);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v915, v875, v889);
      // pto: %25
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v917 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %25
      ;
      uint64_t v918 = (uint64_t) v56;
      TASSIGN(v917, v918);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v917, v877, v897);
      // pto: %26
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v919 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %26
      ;
      uint64_t v920 = (uint64_t) v57;
      TASSIGN(v919, v920);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v919, v879, v905);
      // pto: %27
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v921 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %27
      ;
      uint64_t v922 = (uint64_t) v58;
      TASSIGN(v921, v922);
      pipe_barrier(PIPE_V);
      TROWEXPANDDIV(v921, v881, v913);
      // pto: %28
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v923 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %28
      ;
      uint64_t v924 = (uint64_t) v59;
      TASSIGN(v923, v924);
      pipe_barrier(PIPE_V);
      TADD(v923, v915, v917);
      // pto: %29
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v925 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %29
      ;
      uint64_t v926 = (uint64_t) v59;
      TASSIGN(v925, v926);
      pipe_barrier(PIPE_V);
      TADD(v925, v923, v919);
      // pto: %30
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v927 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %30
      ;
      uint64_t v928 = (uint64_t) v59;
      TASSIGN(v927, v928);
      pipe_barrier(PIPE_V);
      TADD(v927, v925, v921);
      // pto: %31
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v929 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %31
      ;
      uint64_t v930 = (uint64_t) v59;
      TASSIGN(v929, v930);
      pipe_barrier(PIPE_V);
      TADDS(v929, v927, v89);
      // pto: %32
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v931 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %32
      ;
      uint64_t v932 = (uint64_t) v47;
      TASSIGN(v931, v932);
      pipe_barrier(PIPE_V);
      TDIV(v931, v915, v929);
      // pto: %33
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v933 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %33
      ;
      uint64_t v934 = (uint64_t) v48;
      TASSIGN(v933, v934);
      TDIV(v933, v917, v929);
      // pto: %34
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v935 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %34
      ;
      uint64_t v936 = (uint64_t) v45;
      TASSIGN(v935, v936);
      TDIV(v935, v919, v929);
      // pto: %35
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v937 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
      // pto: %35
      ;
      uint64_t v938 = (uint64_t) v46;
      TASSIGN(v937, v938);
      TDIV(v937, v921, v929);
    };
    // pto: %36
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v939 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %36
    ;
    uint64_t v940 = (uint64_t) v49;
    TASSIGN(v939, v940);
    pipe_barrier(PIPE_V);
    TROWSUM(v939, v818, v808);
    // pto: %37
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v941 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %37
    ;
    uint64_t v942 = (uint64_t) v49;
    TASSIGN(v941, v942);
    // pto: %38
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v943 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %38
    ;
    uint64_t v944 = (uint64_t) v49;
    TASSIGN(v943, v944);
    pipe_barrier(PIPE_V);
    TADDS(v943, v941, v89);
    // pto: %39
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v945 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %39
    ;
    uint64_t v946 = (uint64_t) v49;
    TASSIGN(v945, v946);
    // pto: %40
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v947 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %40
    ;
    uint64_t v948 = (uint64_t) v50;
    TASSIGN(v947, v948);
    TROWSUM(v947, v820, v808);
    // pto: %41
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v949 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %41
    ;
    uint64_t v950 = (uint64_t) v50;
    TASSIGN(v949, v950);
    // pto: %42
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v951 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %42
    ;
    uint64_t v952 = (uint64_t) v50;
    TASSIGN(v951, v952);
    pipe_barrier(PIPE_V);
    TADDS(v951, v949, v89);
    // pto: %43
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v953 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %43
    ;
    uint64_t v954 = (uint64_t) v50;
    TASSIGN(v953, v954);
    // pto: %44
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v955 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %44
    ;
    uint64_t v956 = (uint64_t) v51;
    TASSIGN(v955, v956);
    TROWSUM(v955, v822, v808);
    // pto: %45
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v957 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %45
    ;
    uint64_t v958 = (uint64_t) v51;
    TASSIGN(v957, v958);
    // pto: %46
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v959 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %46
    ;
    uint64_t v960 = (uint64_t) v51;
    TASSIGN(v959, v960);
    pipe_barrier(PIPE_V);
    TADDS(v959, v957, v89);
    // pto: %47
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v961 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %47
    ;
    uint64_t v962 = (uint64_t) v51;
    TASSIGN(v961, v962);
    // pto: %48
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v963 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %48
    ;
    uint64_t v964 = (uint64_t) v52;
    TASSIGN(v963, v964);
    TROWSUM(v963, v824, v808);
    // pto: %49
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v965 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %49
    ;
    uint64_t v966 = (uint64_t) v52;
    TASSIGN(v965, v966);
    // pto: %50
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v967 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %50
    ;
    uint64_t v968 = (uint64_t) v54;
    TASSIGN(v967, v968);
    pipe_barrier(PIPE_V);
    TADDS(v967, v965, v89);
    // pto: %51
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v969 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %51
    ;
    uint64_t v970 = (uint64_t) v54;
    TASSIGN(v969, v970);
    // pto: %52
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v971 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %52
    ;
    uint64_t v972 = (uint64_t) v47;
    TASSIGN(v971, v972);
    TROWEXPANDDIV(v971, v818, v945);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %53
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v973 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %53
    ;
    uint64_t v974 = (uint64_t) v48;
    TASSIGN(v973, v974);
    TROWEXPANDDIV(v973, v820, v953);
    // pto: %54
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v975 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %54
    ;
    uint64_t v976 = (uint64_t) v45;
    TASSIGN(v975, v976);
    TROWEXPANDDIV(v975, v822, v961);
    // pto: %55
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v977 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %55
    ;
    uint64_t v978 = (uint64_t) v46;
    TASSIGN(v977, v978);
    pipe_barrier(PIPE_V);
    TROWEXPANDDIV(v977, v824, v969);
    // pto: %56
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v979 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %56
    ;
    uint64_t v980 = (uint64_t) v54;
    TASSIGN(v979, v980);
    pipe_barrier(PIPE_V);
    TADD(v979, v971, v973);
    // pto: %57
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v981 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %57
    ;
    uint64_t v982 = (uint64_t) v54;
    TASSIGN(v981, v982);
    pipe_barrier(PIPE_V);
    TADD(v981, v979, v975);
    // pto: %58
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v983 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %58
    ;
    uint64_t v984 = (uint64_t) v54;
    TASSIGN(v983, v984);
    pipe_barrier(PIPE_V);
    TADD(v983, v981, v977);
    // pto: %59
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v985 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %59
    ;
    uint64_t v986 = (uint64_t) v54;
    TASSIGN(v985, v986);
    pipe_barrier(PIPE_V);
    TADDS(v985, v983, v89);
    // pto: %60
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v987 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %60
    ;
    uint64_t v988 = (uint64_t) v47;
    TASSIGN(v987, v988);
    pipe_barrier(PIPE_V);
    TDIV(v987, v971, v985);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %61
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v989 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %61
    ;
    uint64_t v990 = (uint64_t) v48;
    TASSIGN(v989, v990);
    TDIV(v989, v973, v985);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    // pto: %62
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v991 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %62
    ;
    uint64_t v992 = (uint64_t) v45;
    TASSIGN(v991, v992);
    TDIV(v991, v975, v985);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
    // pto: %63
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v993 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %63
    ;
    uint64_t v994 = (uint64_t) v46;
    TASSIGN(v993, v994);
    TDIV(v993, v977, v985);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    // pto: %row0_cur_inline1092__rv_v2
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v995 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row0_cur_inline1092__rv_v2
    ;
    uint64_t v996 = (uint64_t) v47;
    TASSIGN(v995, v996);
    // pto: %row1_cur_inline1106__rv_v2
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v997 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row1_cur_inline1106__rv_v2
    ;
    uint64_t v998 = (uint64_t) v48;
    TASSIGN(v997, v998);
    // pto: %row2_cur_inline1101__rv_v2
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v999 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row2_cur_inline1101__rv_v2
    ;
    uint64_t v1000 = (uint64_t) v45;
    TASSIGN(v999, v1000);
    // pto: %row3_cur_inline1091__rv_v2
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null> v1001 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Zero, CompactMode::Null>(v79, v79);
    // pto: %row3_cur_inline1091__rv_v2
    ;
    uint64_t v1002 = (uint64_t) v46;
    TASSIGN(v1001, v1002);
    // pto: %206
    ;
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID2);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID3);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID4);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID5);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID6);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID7);
    if (v620 == v79) {
      v995.SetValidShape(v79, v77);
      v997.SetValidShape(v79, v77);
      v999.SetValidShape(v79, v77);
      v1001.SetValidShape(v79, v77);
      // pto: %comb__ssa_v0_pview
      ;
      __gm__ float* v1003 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %comb__ssa_v0_pview
      ;
      const int64_t v1004 = 0;
      // pto: %comb__ssa_v0_pview
      ;
      const int64_t v1005 = 16;
      // pto: %comb__ssa_v0_pview
      ;
      pto::Shape<1, 1, 1, 8, 4> v1006 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %comb__ssa_v0_pview
      ;
      pto::Stride<128, 128, 128, 16, 1> v1007 = pto::Stride<128, 128, 128, 16, 1>();
      // pto: %comb__ssa_v0_pview
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND> v1008 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND>(v1003 + (v1004 + v623 * v1005), v1006, v1007);
      TSTORE(v1008, v995);
      // pto: %209
      ;
      __gm__ float* v1009 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %209
      ;
      const int64_t v1010 = 4;
      // pto: %209
      ;
      const int64_t v1011 = 16;
      // pto: %209
      ;
      pto::Shape<1, 1, 1, 8, 4> v1012 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %209
      ;
      pto::Stride<128, 128, 128, 16, 1> v1013 = pto::Stride<128, 128, 128, 16, 1>();
      // pto: %209
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND> v1014 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND>(v1009 + (v1010 + v623 * v1011), v1012, v1013);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1014, v997);
      // pto: %211
      ;
      __gm__ float* v1015 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %211
      ;
      const int64_t v1016 = 8;
      // pto: %211
      ;
      const int64_t v1017 = 16;
      // pto: %211
      ;
      pto::Shape<1, 1, 1, 8, 4> v1018 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %211
      ;
      pto::Stride<128, 128, 128, 16, 1> v1019 = pto::Stride<128, 128, 128, 16, 1>();
      // pto: %211
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND> v1020 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND>(v1015 + (v1016 + v623 * v1017), v1018, v1019);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1020, v999);
      // pto: %213
      ;
      __gm__ float* v1021 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %213
      ;
      const int64_t v1022 = 12;
      // pto: %213
      ;
      const int64_t v1023 = 16;
      // pto: %213
      ;
      pto::Shape<1, 1, 1, 8, 4> v1024 = pto::Shape<1, 1, 1, 8, 4>();
      // pto: %213
      ;
      pto::Stride<128, 128, 128, 16, 1> v1025 = pto::Stride<128, 128, 128, 16, 1>();
      // pto: %213
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND> v1026 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 4>, pto::Stride<128, 128, 128, 16, 1>, pto::Layout::ND>(v1021 + (v1022 + v623 * v1023), v1024, v1025);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1026, v1001);
    } else {
      // pto: %215
      ;
      int64_t v1027 = v335 < v82 ? v82 : v335;
      // pto: %216
      ;
      __gm__ float* v1028 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %216
      ;
      const int64_t v1029 = 8;
      // pto: %216
      ;
      const int64_t v1030 = 64;
      // pto: %216
      ;
      pto::Shape<1, 1, 1, 8, 8> v1031 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %216
      ;
      pto::Stride<512, 512, 512, 64, 1> v1032 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %216
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v1033 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v1028 + (v1029 + v1027 * v1030), v1031, v1032);
      TSTORE(v1033, v995);
      // pto: %219
      ;
      __gm__ float* v1034 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %219
      ;
      const int64_t v1035 = 16;
      // pto: %219
      ;
      const int64_t v1036 = 64;
      // pto: %219
      ;
      pto::Shape<1, 1, 1, 8, 8> v1037 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %219
      ;
      pto::Stride<512, 512, 512, 64, 1> v1038 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %219
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v1039 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v1034 + (v1035 + v1027 * v1036), v1037, v1038);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1039, v997);
      // pto: %222
      ;
      __gm__ float* v1040 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %222
      ;
      const int64_t v1041 = 24;
      // pto: %222
      ;
      const int64_t v1042 = 64;
      // pto: %222
      ;
      pto::Shape<1, 1, 1, 8, 8> v1043 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %222
      ;
      pto::Stride<512, 512, 512, 64, 1> v1044 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %222
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v1045 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v1040 + (v1041 + v1027 * v1042), v1043, v1044);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1045, v999);
      // pto: %225
      ;
      __gm__ float* v1046 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %225
      ;
      const int64_t v1047 = 32;
      // pto: %225
      ;
      const int64_t v1048 = 64;
      // pto: %225
      ;
      pto::Shape<1, 1, 1, 8, 8> v1049 = pto::Shape<1, 1, 1, 8, 8>();
      // pto: %225
      ;
      pto::Stride<512, 512, 512, 64, 1> v1050 = pto::Stride<512, 512, 512, 64, 1>();
      // pto: %225
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v1051 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v1046 + (v1047 + v1027 * v1048), v1049, v1050);
      pipe_barrier(PIPE_MTE3);
      TSTORE(v1051, v1001);
      // pto: %row0_tail_inline1149__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1052 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
      // pto: %row0_tail_inline1149__ssa_v0
      ;
      uint64_t v1053 = (uint64_t) v47;
      TASSIGN(v1052, v1053);
      // pto: %228
      ;
      const int64_t v1054 = 0;
      // pto: %228
      ;
      __gm__ float* v1055 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %228
      ;
      const int64_t v1056 = 1;
      // pto: %228
      ;
      const int64_t v1057 = 1;
      // pto: %228
      ;
      const int64_t v1058 = 1;
      // pto: %228
      ;
      int64_t v1059 = v620 * v76;
      // pto: %228
      ;
      int64_t v1060 = v1058 * v1059;
      // pto: %228
      ;
      pto::Shape<1, 1, 1, -1, 4> v1061 = pto::Shape<1, 1, 1, -1, 4>(v1056, v1057, v1058, v620, v77);
      // pto: %228
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1062 = pto::Stride<-1, -1, -1, -1, -1>(v1057 * v1060, v1060, v1059, v76, v70);
      // pto: %228
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1063 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1055 + (v1054 + v1027 * v76 + v79 * v70), v1061, v1062);
      pipe_barrier(PIPE_ALL);
      TLOAD(v1052, v1063);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
      // pto: %row1_tail_inline1125__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1064 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
      // pto: %row1_tail_inline1125__ssa_v0
      ;
      uint64_t v1065 = (uint64_t) v48;
      TASSIGN(v1064, v1065);
      // pto: %231
      ;
      const int64_t v1066 = 0;
      // pto: %231
      ;
      __gm__ float* v1067 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %231
      ;
      const int64_t v1068 = 1;
      // pto: %231
      ;
      const int64_t v1069 = 1;
      // pto: %231
      ;
      const int64_t v1070 = 1;
      // pto: %231
      ;
      int64_t v1071 = v620 * v76;
      // pto: %231
      ;
      int64_t v1072 = v1070 * v1071;
      // pto: %231
      ;
      pto::Shape<1, 1, 1, -1, 4> v1073 = pto::Shape<1, 1, 1, -1, 4>(v1068, v1069, v1070, v620, v77);
      // pto: %231
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1074 = pto::Stride<-1, -1, -1, -1, -1>(v1069 * v1072, v1072, v1071, v76, v70);
      // pto: %231
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1075 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1067 + (v1066 + v1027 * v76 + v71 * v70), v1073, v1074);
      TLOAD(v1064, v1075);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
      // pto: %row2_tail_inline1081__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1076 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
      // pto: %row2_tail_inline1081__ssa_v0
      ;
      uint64_t v1077 = (uint64_t) v45;
      TASSIGN(v1076, v1077);
      // pto: %234
      ;
      const int64_t v1078 = 0;
      // pto: %234
      ;
      __gm__ float* v1079 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %234
      ;
      const int64_t v1080 = 1;
      // pto: %234
      ;
      const int64_t v1081 = 1;
      // pto: %234
      ;
      const int64_t v1082 = 1;
      // pto: %234
      ;
      int64_t v1083 = v620 * v76;
      // pto: %234
      ;
      int64_t v1084 = v1082 * v1083;
      // pto: %234
      ;
      pto::Shape<1, 1, 1, -1, 4> v1085 = pto::Shape<1, 1, 1, -1, 4>(v1080, v1081, v1082, v620, v77);
      // pto: %234
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1086 = pto::Stride<-1, -1, -1, -1, -1>(v1081 * v1084, v1084, v1083, v76, v70);
      // pto: %234
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1087 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1079 + (v1078 + v1027 * v76 + v78 * v70), v1085, v1086);
      TLOAD(v1076, v1087);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID4);
      // pto: %row3_tail_inline1080__ssa_v0
      ;
      Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1088 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v620, v77);
      // pto: %row3_tail_inline1080__ssa_v0
      ;
      uint64_t v1089 = (uint64_t) v46;
      TASSIGN(v1088, v1089);
      // pto: %237
      ;
      const int64_t v1090 = 0;
      // pto: %237
      ;
      __gm__ float* v1091 = PTOAS__GLOBAL_TENSOR_DATA(v163);
      // pto: %237
      ;
      const int64_t v1092 = 1;
      // pto: %237
      ;
      const int64_t v1093 = 1;
      // pto: %237
      ;
      const int64_t v1094 = 1;
      // pto: %237
      ;
      int64_t v1095 = v620 * v76;
      // pto: %237
      ;
      int64_t v1096 = v1094 * v1095;
      // pto: %237
      ;
      pto::Shape<1, 1, 1, -1, 4> v1097 = pto::Shape<1, 1, 1, -1, 4>(v1092, v1093, v1094, v620, v77);
      // pto: %237
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1098 = pto::Stride<-1, -1, -1, -1, -1>(v1093 * v1096, v1096, v1095, v76, v70);
      // pto: %237
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1099 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1091 + (v1090 + v1027 * v76 + v73 * v70), v1097, v1098);
      TLOAD(v1088, v1099);
      set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID5);
      // pto: %239
      ;
      const int64_t v1100 = 0;
      // pto: %239
      ;
      __gm__ float* v1101 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %239
      ;
      const int64_t v1102 = 1;
      // pto: %239
      ;
      const int64_t v1103 = 1;
      // pto: %239
      ;
      const int64_t v1104 = 1;
      // pto: %239
      ;
      int64_t v1105 = v620 * v71;
      // pto: %239
      ;
      int64_t v1106 = v1104 * v1105;
      // pto: %239
      ;
      pto::Shape<1, 1, 1, -1, 4> v1107 = pto::Shape<1, 1, 1, -1, 4>(v1102, v1103, v1104, v620, v77);
      // pto: %239
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1108 = pto::Stride<-1, -1, -1, -1, -1>(v1103 * v1106, v1106, v1105, v71, v70);
      // pto: %239
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1109 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1101 + (v1100 + v623 * v71 + v82 * v70), v1107, v1108);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID2);
      TSTORE(v1109, v1052);
      // pto: %241
      ;
      const int64_t v1110 = 0;
      // pto: %241
      ;
      __gm__ float* v1111 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %241
      ;
      const int64_t v1112 = 1;
      // pto: %241
      ;
      const int64_t v1113 = 1;
      // pto: %241
      ;
      const int64_t v1114 = 1;
      // pto: %241
      ;
      int64_t v1115 = v620 * v71;
      // pto: %241
      ;
      int64_t v1116 = v1114 * v1115;
      // pto: %241
      ;
      pto::Shape<1, 1, 1, -1, 4> v1117 = pto::Shape<1, 1, 1, -1, 4>(v1112, v1113, v1114, v620, v77);
      // pto: %241
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1118 = pto::Stride<-1, -1, -1, -1, -1>(v1113 * v1116, v1116, v1115, v71, v70);
      // pto: %241
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1119 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1111 + (v1110 + v623 * v71 + v77 * v70), v1117, v1118);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID3);
      TSTORE(v1119, v1064);
      // pto: %243
      ;
      const int64_t v1120 = 0;
      // pto: %243
      ;
      __gm__ float* v1121 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %243
      ;
      const int64_t v1122 = 1;
      // pto: %243
      ;
      const int64_t v1123 = 1;
      // pto: %243
      ;
      const int64_t v1124 = 1;
      // pto: %243
      ;
      int64_t v1125 = v620 * v71;
      // pto: %243
      ;
      int64_t v1126 = v1124 * v1125;
      // pto: %243
      ;
      pto::Shape<1, 1, 1, -1, 4> v1127 = pto::Shape<1, 1, 1, -1, 4>(v1122, v1123, v1124, v620, v77);
      // pto: %243
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1128 = pto::Stride<-1, -1, -1, -1, -1>(v1123 * v1126, v1126, v1125, v71, v70);
      // pto: %243
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1129 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1121 + (v1120 + v623 * v71 + v79 * v70), v1127, v1128);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID4);
      TSTORE(v1129, v1076);
      // pto: %245
      ;
      const int64_t v1130 = 0;
      // pto: %245
      ;
      __gm__ float* v1131 = PTOAS__GLOBAL_TENSOR_DATA(v208);
      // pto: %245
      ;
      const int64_t v1132 = 1;
      // pto: %245
      ;
      const int64_t v1133 = 1;
      // pto: %245
      ;
      const int64_t v1134 = 1;
      // pto: %245
      ;
      int64_t v1135 = v620 * v71;
      // pto: %245
      ;
      int64_t v1136 = v1134 * v1135;
      // pto: %245
      ;
      pto::Shape<1, 1, 1, -1, 4> v1137 = pto::Shape<1, 1, 1, -1, 4>(v1132, v1133, v1134, v620, v77);
      // pto: %245
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1138 = pto::Stride<-1, -1, -1, -1, -1>(v1133 * v1136, v1136, v1135, v71, v70);
      // pto: %245
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1139 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 4>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1131 + (v1130 + v623 * v71 + v95 * v70), v1137, v1138);
      pipe_barrier(PIPE_MTE3);
      wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID5);
      TSTORE(v1139, v1088);
    };
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID7);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v1140 = v291; v1140 < v336; v1140 += v81) {
    // pto: %248
    ;
    int64_t v1141 = (int64_t) ((uint64_t) v1140 * (uint64_t) v79);
    // pto: %249
    ;
    int64_t v1142 = (int64_t) ((uint64_t) v32 - (uint64_t) v1141);
    // pto: %250
    ;
    int64_t v1143 = v1142 < v79 ? v1142 : v79;
    // pto: %64
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1144 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %64
    ;
    uint64_t v1145 = (uint64_t) v47;
    TASSIGN(v1144, v1145);
    // pto: %251
    ;
    int64_t v1146 = v1141 < v82 ? v82 : v1141;
    // pto: %252
    ;
    __gm__ float* v1147 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %252
    ;
    const int64_t v1148 = 32;
    // pto: %252
    ;
    const int64_t v1149 = 64;
    // pto: %252
    ;
    pto::Shape<1, 1, 1, 8, 8> v1150 = pto::Shape<1, 1, 1, 8, 8>();
    // pto: %252
    ;
    pto::Stride<512, 512, 512, 64, 1> v1151 = pto::Stride<512, 512, 512, 64, 1>();
    // pto: %252
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND> v1152 = GlobalTensor<float, pto::Shape<1, 1, 1, 8, 8>, pto::Stride<512, 512, 512, 64, 1>, pto::Layout::ND>(v1147 + (v1148 + v1146 * v1149), v1150, v1151);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v1144, v1152);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %65
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1153 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %65
    ;
    uint64_t v1154 = (uint64_t) v48;
    TASSIGN(v1153, v1154);
    // pto: %pre_tile_t_inline1170__tile
    ;
    Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1155 = Tile<TileType::Vec, float, 8, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v79);
    // pto: %pre_tile_t_inline1170__tile
    ;
    uint64_t v1156 = (uint64_t) v52;
    TASSIGN(v1155, v1156);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    TTRANS(v1155, v1144, v1153);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    // pto: %66
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1157 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %66
    ;
    uint64_t v1158 = (uint64_t) v52;
    TASSIGN(v1157, v1158);
    // pto: %pre0_inline1179__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1159 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %pre0_inline1179__tile
    ;
    uint64_t v1160 = (uint64_t) v52;
    TASSIGN(v1159, v1160);
    // pto: %67
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1161 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %67
    ;
    uint64_t v1162 = (uint64_t) v60;
    TASSIGN(v1161, v1162);
    // pto: %pre1_inline1182__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1163 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %pre1_inline1182__tile
    ;
    uint64_t v1164 = (uint64_t) v60;
    TASSIGN(v1163, v1164);
    // pto: %68
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1165 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %68
    ;
    uint64_t v1166 = (uint64_t) v61;
    TASSIGN(v1165, v1166);
    // pto: %pre2_inline1183__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1167 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %pre2_inline1183__tile
    ;
    uint64_t v1168 = (uint64_t) v61;
    TASSIGN(v1167, v1168);
    // pto: %69
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1169 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %69
    ;
    uint64_t v1170 = (uint64_t) v62;
    TASSIGN(v1169, v1170);
    // pto: %pre3_inline1184__tile
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1171 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %pre3_inline1184__tile
    ;
    uint64_t v1172 = (uint64_t) v62;
    TASSIGN(v1171, v1172);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    for (int64_t v1173 = v82; v1173 < v71; v1173 += v80) {
      // pto: %257
      ;
      int64_t v1174 = (int64_t) ((uint64_t) v1173 * (uint64_t) v91);
      // pto: %260
      ;
      int64_t v1175 = (int64_t) ((uint64_t) v1174 + (uint64_t) v91);
      // pto: %x0_inline1178__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1176 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %x0_inline1178__tile
      ;
      uint64_t v1177 = (uint64_t) v47;
      TASSIGN(v1176, v1177);
      // pto: %263
      ;
      int64_t v1178 = v1174 < v82 ? v82 : v1174;
      // pto: %264
      ;
      const int64_t v1179 = 0;
      // pto: %264
      ;
      __gm__ float* v1180 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %264
      ;
      const int64_t v1181 = 1;
      // pto: %264
      ;
      const int64_t v1182 = 1;
      // pto: %264
      ;
      const int64_t v1183 = 1;
      // pto: %264
      ;
      int64_t v1184 = v1143 * v69;
      // pto: %264
      ;
      int64_t v1185 = v1183 * v1184;
      // pto: %264
      ;
      pto::Shape<1, 1, 1, -1, 256> v1186 = pto::Shape<1, 1, 1, -1, 256>(v1181, v1182, v1183, v1143, v91);
      // pto: %264
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1187 = pto::Stride<-1, -1, -1, -1, -1>(v1182 * v1185, v1185, v1184, v69, v70);
      // pto: %264
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1188 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1180 + (v1179 + v1146 * v69 + v1178 * v70), v1186, v1187);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      TLOAD(v1176, v1188);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      // pto: %x1_inline1167__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1189 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %x1_inline1167__tile
      ;
      uint64_t v1190 = (uint64_t) v48;
      TASSIGN(v1189, v1190);
      // pto: %266
      ;
      int64_t v1191 = (int64_t) ((uint64_t) v1174 + (uint64_t) v74);
      // pto: %267
      ;
      int64_t v1192 = v1191 < v82 ? v82 : v1191;
      // pto: %268
      ;
      const int64_t v1193 = 0;
      // pto: %268
      ;
      __gm__ float* v1194 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %268
      ;
      const int64_t v1195 = 1;
      // pto: %268
      ;
      const int64_t v1196 = 1;
      // pto: %268
      ;
      const int64_t v1197 = 1;
      // pto: %268
      ;
      int64_t v1198 = v1143 * v69;
      // pto: %268
      ;
      int64_t v1199 = v1197 * v1198;
      // pto: %268
      ;
      pto::Shape<1, 1, 1, -1, 256> v1200 = pto::Shape<1, 1, 1, -1, 256>(v1195, v1196, v1197, v1143, v91);
      // pto: %268
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1201 = pto::Stride<-1, -1, -1, -1, -1>(v1196 * v1199, v1199, v1198, v69, v70);
      // pto: %268
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1202 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1194 + (v1193 + v1146 * v69 + v1192 * v70), v1200, v1201);
      TLOAD(v1189, v1202);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      // pto: %x2_inline1175__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1203 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %x2_inline1175__tile
      ;
      uint64_t v1204 = (uint64_t) v45;
      TASSIGN(v1203, v1204);
      // pto: %270
      ;
      int64_t v1205 = (int64_t) ((uint64_t) v1174 + (uint64_t) v97);
      // pto: %271
      ;
      int64_t v1206 = v1205 < v82 ? v82 : v1205;
      // pto: %272
      ;
      const int64_t v1207 = 0;
      // pto: %272
      ;
      __gm__ float* v1208 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %272
      ;
      const int64_t v1209 = 1;
      // pto: %272
      ;
      const int64_t v1210 = 1;
      // pto: %272
      ;
      const int64_t v1211 = 1;
      // pto: %272
      ;
      int64_t v1212 = v1143 * v69;
      // pto: %272
      ;
      int64_t v1213 = v1211 * v1212;
      // pto: %272
      ;
      pto::Shape<1, 1, 1, -1, 256> v1214 = pto::Shape<1, 1, 1, -1, 256>(v1209, v1210, v1211, v1143, v91);
      // pto: %272
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1215 = pto::Stride<-1, -1, -1, -1, -1>(v1210 * v1213, v1213, v1212, v69, v70);
      // pto: %272
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1216 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1208 + (v1207 + v1146 * v69 + v1206 * v70), v1214, v1215);
      TLOAD(v1203, v1216);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      // pto: %x3_inline1166__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1217 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %x3_inline1166__tile
      ;
      uint64_t v1218 = (uint64_t) v46;
      TASSIGN(v1217, v1218);
      // pto: %274
      ;
      int64_t v1219 = (int64_t) ((uint64_t) v1174 + (uint64_t) v98);
      // pto: %275
      ;
      int64_t v1220 = v1219 < v82 ? v82 : v1219;
      // pto: %276
      ;
      const int64_t v1221 = 0;
      // pto: %276
      ;
      __gm__ float* v1222 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %276
      ;
      const int64_t v1223 = 1;
      // pto: %276
      ;
      const int64_t v1224 = 1;
      // pto: %276
      ;
      const int64_t v1225 = 1;
      // pto: %276
      ;
      int64_t v1226 = v1143 * v69;
      // pto: %276
      ;
      int64_t v1227 = v1225 * v1226;
      // pto: %276
      ;
      pto::Shape<1, 1, 1, -1, 256> v1228 = pto::Shape<1, 1, 1, -1, 256>(v1223, v1224, v1225, v1143, v91);
      // pto: %276
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1229 = pto::Stride<-1, -1, -1, -1, -1>(v1224 * v1227, v1227, v1226, v69, v70);
      // pto: %276
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1230 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1222 + (v1221 + v1146 * v69 + v1220 * v70), v1228, v1229);
      TLOAD(v1217, v1230);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      // pto: %70
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1231 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %70
      ;
      uint64_t v1232 = (uint64_t) v54;
      TASSIGN(v1231, v1232);
      // pto: %278
      ;
      int64_t v1233 = v1175 < v82 ? v82 : v1175;
      // pto: %279
      ;
      const int64_t v1234 = 0;
      // pto: %279
      ;
      __gm__ float* v1235 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %279
      ;
      const int64_t v1236 = 1;
      // pto: %279
      ;
      const int64_t v1237 = 1;
      // pto: %279
      ;
      const int64_t v1238 = 1;
      // pto: %279
      ;
      int64_t v1239 = v1143 * v69;
      // pto: %279
      ;
      int64_t v1240 = v1238 * v1239;
      // pto: %279
      ;
      pto::Shape<1, 1, 1, -1, 256> v1241 = pto::Shape<1, 1, 1, -1, 256>(v1236, v1237, v1238, v1143, v91);
      // pto: %279
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1242 = pto::Stride<-1, -1, -1, -1, -1>(v1237 * v1240, v1240, v1239, v69, v70);
      // pto: %279
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1243 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1235 + (v1234 + v1146 * v69 + v1233 * v70), v1241, v1242);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
      wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      TLOAD(v1231, v1243);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      // pto: %71
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1244 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %71
      ;
      uint64_t v1245 = (uint64_t) v49;
      TASSIGN(v1244, v1245);
      int64_t v1246 = (int64_t) ((uint64_t) v1174 + (uint64_t) v42);
      // pto: %282
      ;
      int64_t v1247 = v1246 < v82 ? v82 : v1246;
      // pto: %283
      ;
      const int64_t v1248 = 0;
      // pto: %283
      ;
      __gm__ float* v1249 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %283
      ;
      const int64_t v1250 = 1;
      // pto: %283
      ;
      const int64_t v1251 = 1;
      // pto: %283
      ;
      const int64_t v1252 = 1;
      // pto: %283
      ;
      int64_t v1253 = v1143 * v69;
      // pto: %283
      ;
      int64_t v1254 = v1252 * v1253;
      // pto: %283
      ;
      pto::Shape<1, 1, 1, -1, 256> v1255 = pto::Shape<1, 1, 1, -1, 256>(v1250, v1251, v1252, v1143, v91);
      // pto: %283
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1256 = pto::Stride<-1, -1, -1, -1, -1>(v1251 * v1254, v1254, v1253, v69, v70);
      // pto: %283
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1257 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1249 + (v1248 + v1146 * v69 + v1247 * v70), v1255, v1256);
      TLOAD(v1244, v1257);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      // pto: %72
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1258 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %72
      ;
      uint64_t v1259 = (uint64_t) v50;
      TASSIGN(v1258, v1259);
      int64_t v1260 = (int64_t) ((uint64_t) v1174 + (uint64_t) v41);
      // pto: %286
      ;
      int64_t v1261 = v1260 < v82 ? v82 : v1260;
      // pto: %287
      ;
      const int64_t v1262 = 0;
      // pto: %287
      ;
      __gm__ float* v1263 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %287
      ;
      const int64_t v1264 = 1;
      // pto: %287
      ;
      const int64_t v1265 = 1;
      // pto: %287
      ;
      const int64_t v1266 = 1;
      // pto: %287
      ;
      int64_t v1267 = v1143 * v69;
      // pto: %287
      ;
      int64_t v1268 = v1266 * v1267;
      // pto: %287
      ;
      pto::Shape<1, 1, 1, -1, 256> v1269 = pto::Shape<1, 1, 1, -1, 256>(v1264, v1265, v1266, v1143, v91);
      // pto: %287
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1270 = pto::Stride<-1, -1, -1, -1, -1>(v1265 * v1268, v1268, v1267, v69, v70);
      // pto: %287
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1271 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1263 + (v1262 + v1146 * v69 + v1261 * v70), v1269, v1270);
      TLOAD(v1258, v1271);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      // pto: %73
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1272 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %73
      ;
      uint64_t v1273 = (uint64_t) v51;
      TASSIGN(v1272, v1273);
      int64_t v1274 = (int64_t) ((uint64_t) v1174 + (uint64_t) v40);
      // pto: %290
      ;
      int64_t v1275 = v1274 < v82 ? v82 : v1274;
      // pto: %291
      ;
      const int64_t v1276 = 0;
      // pto: %291
      ;
      __gm__ float* v1277 = PTOAS__GLOBAL_TENSOR_DATA(v118);
      // pto: %291
      ;
      const int64_t v1278 = 1;
      // pto: %291
      ;
      const int64_t v1279 = 1;
      // pto: %291
      ;
      const int64_t v1280 = 1;
      // pto: %291
      ;
      int64_t v1281 = v1143 * v69;
      // pto: %291
      ;
      int64_t v1282 = v1280 * v1281;
      // pto: %291
      ;
      pto::Shape<1, 1, 1, -1, 256> v1283 = pto::Shape<1, 1, 1, -1, 256>(v1278, v1279, v1280, v1143, v91);
      // pto: %291
      ;
      pto::Stride<-1, -1, -1, -1, -1> v1284 = pto::Stride<-1, -1, -1, -1, -1>(v1279 * v1282, v1282, v1281, v69, v70);
      // pto: %291
      ;
      GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1285 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1277 + (v1276 + v1146 * v69 + v1275 * v70), v1283, v1284);
      TLOAD(v1272, v1285);
      set_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      // pto: %y0_inline1165__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1286 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %y0_inline1165__tile
      ;
      uint64_t v1287 = (uint64_t) v47;
      TASSIGN(v1286, v1287);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
      TROWEXPANDMUL(v1286, v1176, v1159);
      // pto: %y1_inline1164__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1288 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %y1_inline1164__tile
      ;
      uint64_t v1289 = (uint64_t) v48;
      TASSIGN(v1288, v1289);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID1);
      TROWEXPANDMUL(v1288, v1189, v1163);
      // pto: %y2_inline1163__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1290 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %y2_inline1163__tile
      ;
      uint64_t v1291 = (uint64_t) v45;
      TASSIGN(v1290, v1291);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID2);
      TROWEXPANDMUL(v1290, v1203, v1167);
      // pto: %y3_inline1174__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1292 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %y3_inline1174__tile
      ;
      uint64_t v1293 = (uint64_t) v46;
      TASSIGN(v1292, v1293);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID3);
      TROWEXPANDMUL(v1292, v1217, v1171);
      // pto: %74
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1294 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %74
      ;
      uint64_t v1295 = (uint64_t) v47;
      TASSIGN(v1294, v1295);
      pipe_barrier(PIPE_V);
      TADD(v1294, v1286, v1288);
      // pto: %75
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1296 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %75
      ;
      uint64_t v1297 = (uint64_t) v47;
      TASSIGN(v1296, v1297);
      pipe_barrier(PIPE_V);
      TADD(v1296, v1294, v1290);
      // pto: %y_tile_inline1172__tile
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1298 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %y_tile_inline1172__tile
      ;
      uint64_t v1299 = (uint64_t) v47;
      TASSIGN(v1298, v1299);
      pipe_barrier(PIPE_V);
      TADD(v1298, v1296, v1292);
      // pto: %y_bf16_inline1162__tile
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1300 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %y_bf16_inline1162__tile
      ;
      uint64_t v1301 = (uint64_t) v47;
      TASSIGN(v1300, v1301);
      pipe_barrier(PIPE_V);
      RoundMode v1302 = RoundMode::CAST_RINT;
      SaturationMode v1303 = SaturationMode::ON;
      TCVT(v1300, v1298, v1302, v1303);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
      // pto: %292
      ;
      bool v1304 = v1143 == v79;
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      if (v1304) {
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v1305 = 0;
        // pto: %mixed__iter_v3_pview
        ;
        __gm__ bfloat16_t* v1306 = PTOAS__GLOBAL_TENSOR_DATA(v217);
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v1307 = 1;
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v1308 = 1;
        // pto: %mixed__iter_v3_pview
        ;
        const int64_t v1309 = 1;
        // pto: %mixed__iter_v3_pview
        ;
        int64_t v1310 = v1143 * v74;
        // pto: %mixed__iter_v3_pview
        ;
        int64_t v1311 = v1309 * v1310;
        // pto: %mixed__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v1312 = pto::Shape<1, 1, 1, -1, 256>(v1307, v1308, v1309, v1143, v91);
        // pto: %mixed__iter_v3_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1313 = pto::Stride<-1, -1, -1, -1, -1>(v1308 * v1311, v1311, v1310, v74, v70);
        // pto: %mixed__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1314 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1306 + (v1305 + v1146 * v74 + v1178 * v70), v1312, v1313);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v1314, v1300);
      } else {
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v1315 = 0;
        // pto: %mixed_tail__iter_v3_pview
        ;
        __gm__ bfloat16_t* v1316 = PTOAS__GLOBAL_TENSOR_DATA(v225);
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v1317 = 1;
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v1318 = 1;
        // pto: %mixed_tail__iter_v3_pview
        ;
        const int64_t v1319 = 1;
        // pto: %mixed_tail__iter_v3_pview
        ;
        int64_t v1320 = v1143 * v74;
        // pto: %mixed_tail__iter_v3_pview
        ;
        int64_t v1321 = v1319 * v1320;
        // pto: %mixed_tail__iter_v3_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v1322 = pto::Shape<1, 1, 1, -1, 256>(v1317, v1318, v1319, v1143, v91);
        // pto: %mixed_tail__iter_v3_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1323 = pto::Stride<-1, -1, -1, -1, -1>(v1318 * v1321, v1321, v1320, v74, v70);
        // pto: %mixed_tail__iter_v3_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1324 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1316 + (v1315 + v82 * v74 + v1178 * v70), v1322, v1323);
        TSTORE(v1324, v1300);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        // pto: %y_out_inline1180__ssa_v0
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1325 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
        // pto: %y_out_inline1180__ssa_v0
        ;
        uint64_t v1326 = (uint64_t) v47;
        TASSIGN(v1325, v1326);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        TLOAD(v1325, v1324);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID6);
        // pto: %299
        ;
        const int64_t v1327 = 0;
        // pto: %299
        ;
        __gm__ bfloat16_t* v1328 = PTOAS__GLOBAL_TENSOR_DATA(v217);
        // pto: %299
        ;
        const int64_t v1329 = 1;
        // pto: %299
        ;
        const int64_t v1330 = 1;
        // pto: %299
        ;
        const int64_t v1331 = 1;
        // pto: %299
        ;
        int64_t v1332 = v1143 * v74;
        // pto: %299
        ;
        int64_t v1333 = v1331 * v1332;
        // pto: %299
        ;
        pto::Shape<1, 1, 1, -1, 256> v1334 = pto::Shape<1, 1, 1, -1, 256>(v1329, v1330, v1331, v1143, v91);
        // pto: %299
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1335 = pto::Stride<-1, -1, -1, -1, -1>(v1330 * v1333, v1333, v1332, v74, v70);
        // pto: %299
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1336 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1328 + (v1327 + v1146 * v74 + v1178 * v70), v1334, v1335);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID6);
        TSTORE(v1336, v1325);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
      // pto: %76
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1337 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %76
      ;
      uint64_t v1338 = (uint64_t) v54;
      TASSIGN(v1337, v1338);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID4);
      TROWEXPANDMUL(v1337, v1231, v1159);
      // pto: %77
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1339 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %77
      ;
      uint64_t v1340 = (uint64_t) v49;
      TASSIGN(v1339, v1340);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID5);
      TROWEXPANDMUL(v1339, v1244, v1163);
      // pto: %78
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1341 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %78
      ;
      uint64_t v1342 = (uint64_t) v50;
      TASSIGN(v1341, v1342);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID6);
      TROWEXPANDMUL(v1341, v1258, v1167);
      // pto: %79
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1343 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %79
      ;
      uint64_t v1344 = (uint64_t) v51;
      TASSIGN(v1343, v1344);
      wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID7);
      TROWEXPANDMUL(v1343, v1272, v1171);
      // pto: %80
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1345 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %80
      ;
      uint64_t v1346 = (uint64_t) v54;
      TASSIGN(v1345, v1346);
      pipe_barrier(PIPE_V);
      TADD(v1345, v1337, v1339);
      // pto: %81
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1347 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %81
      ;
      uint64_t v1348 = (uint64_t) v54;
      TASSIGN(v1347, v1348);
      pipe_barrier(PIPE_V);
      TADD(v1347, v1345, v1341);
      // pto: %82
      ;
      Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1349 = Tile<TileType::Vec, float, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %82
      ;
      uint64_t v1350 = (uint64_t) v54;
      TASSIGN(v1349, v1350);
      pipe_barrier(PIPE_V);
      TADD(v1349, v1347, v1343);
      // pto: %83
      ;
      Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1351 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
      // pto: %83
      ;
      uint64_t v1352 = (uint64_t) v54;
      TASSIGN(v1351, v1352);
      pipe_barrier(PIPE_V);
      RoundMode v1353 = RoundMode::CAST_RINT;
      SaturationMode v1354 = SaturationMode::ON;
      TCVT(v1351, v1349, v1353, v1354);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      set_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      set_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
      wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID1);
      if (v1304) {
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v1355 = 0;
        // pto: %mixed__phi_v6_pview
        ;
        __gm__ bfloat16_t* v1356 = PTOAS__GLOBAL_TENSOR_DATA(v217);
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v1357 = 1;
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v1358 = 1;
        // pto: %mixed__phi_v6_pview
        ;
        const int64_t v1359 = 1;
        // pto: %mixed__phi_v6_pview
        ;
        int64_t v1360 = v1143 * v74;
        // pto: %mixed__phi_v6_pview
        ;
        int64_t v1361 = v1359 * v1360;
        // pto: %mixed__phi_v6_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v1362 = pto::Shape<1, 1, 1, -1, 256>(v1357, v1358, v1359, v1143, v91);
        // pto: %mixed__phi_v6_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1363 = pto::Stride<-1, -1, -1, -1, -1>(v1358 * v1361, v1361, v1360, v74, v70);
        // pto: %mixed__phi_v6_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1364 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1356 + (v1355 + v1146 * v74 + v1233 * v70), v1362, v1363);
        pipe_barrier(PIPE_MTE3);
        TSTORE(v1364, v1351);
      } else {
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v1365 = 0;
        // pto: %mixed_tail__phi_v6_pview
        ;
        __gm__ bfloat16_t* v1366 = PTOAS__GLOBAL_TENSOR_DATA(v225);
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v1367 = 1;
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v1368 = 1;
        // pto: %mixed_tail__phi_v6_pview
        ;
        const int64_t v1369 = 1;
        // pto: %mixed_tail__phi_v6_pview
        ;
        int64_t v1370 = v1143 * v74;
        // pto: %mixed_tail__phi_v6_pview
        ;
        int64_t v1371 = v1369 * v1370;
        // pto: %mixed_tail__phi_v6_pview
        ;
        pto::Shape<1, 1, 1, -1, 256> v1372 = pto::Shape<1, 1, 1, -1, 256>(v1367, v1368, v1369, v1143, v91);
        // pto: %mixed_tail__phi_v6_pview
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1373 = pto::Stride<-1, -1, -1, -1, -1>(v1368 * v1371, v1371, v1370, v74, v70);
        // pto: %mixed_tail__phi_v6_pview
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1374 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1366 + (v1365 + v82 * v74 + v1233 * v70), v1372, v1373);
        TSTORE(v1374, v1351);
        set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        // pto: %84
        ;
        Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1375 = Tile<TileType::Vec, bfloat16_t, 8, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1143, v91);
        // pto: %84
        ;
        uint64_t v1376 = (uint64_t) v54;
        TASSIGN(v1375, v1376);
        wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID6);
        TLOAD(v1375, v1374);
        set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID7);
        // pto: %310
        ;
        const int64_t v1377 = 0;
        // pto: %310
        ;
        __gm__ bfloat16_t* v1378 = PTOAS__GLOBAL_TENSOR_DATA(v217);
        // pto: %310
        ;
        const int64_t v1379 = 1;
        // pto: %310
        ;
        const int64_t v1380 = 1;
        // pto: %310
        ;
        const int64_t v1381 = 1;
        // pto: %310
        ;
        int64_t v1382 = v1143 * v74;
        // pto: %310
        ;
        int64_t v1383 = v1381 * v1382;
        // pto: %310
        ;
        pto::Shape<1, 1, 1, -1, 256> v1384 = pto::Shape<1, 1, 1, -1, 256>(v1379, v1380, v1381, v1143, v91);
        // pto: %310
        ;
        pto::Stride<-1, -1, -1, -1, -1> v1385 = pto::Stride<-1, -1, -1, -1, -1>(v1380 * v1383, v1383, v1382, v74, v70);
        // pto: %310
        ;
        GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1386 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 256>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1378 + (v1377 + v1146 * v74 + v1233 * v70), v1384, v1385);
        wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID7);
        TSTORE(v1386, v1375);
      };
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
      set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    };
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID2);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID5);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID4);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID3);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID3);
  set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  for (int64_t v1387 = v291; v1387 < v32; v1387 += v81) {
    // pto: %raw_inline1229__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1388 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %raw_inline1229__ssa_v0
    ;
    uint64_t v1389 = (uint64_t) v48;
    TASSIGN(v1388, v1389);
    // pto: %311
    ;
    int64_t v1390 = v1387 < v82 ? v82 : v1387;
    // pto: %mixed__ssa_v7_pview
    ;
    __gm__ bfloat16_t* v1391 = PTOAS__GLOBAL_TENSOR_DATA(v217);
    // pto: %mixed__ssa_v7_pview
    ;
    const int64_t v1392 = 0;
    // pto: %mixed__ssa_v7_pview
    ;
    const int64_t v1393 = 4096;
    // pto: %mixed__ssa_v7_pview
    ;
    pto::Shape<1, 1, 1, 1, 4096> v1394 = pto::Shape<1, 1, 1, 1, 4096>();
    // pto: %mixed__ssa_v7_pview
    ;
    pto::Stride<4096, 4096, 4096, 4096, 1> v1395 = pto::Stride<4096, 4096, 4096, 4096, 1>();
    // pto: %mixed__ssa_v7_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v1396 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v1391 + (v1392 + v1390 * v1393), v1394, v1395);
    wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    TLOAD(v1388, v1396);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %wide_inline1209__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1397 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %wide_inline1209__ssa_v0
    ;
    uint64_t v1398 = (uint64_t) v47;
    TASSIGN(v1397, v1398);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
    RoundMode v1399 = RoundMode::CAST_ROUND;
    SaturationMode v1400 = SaturationMode::ON;
    TCVT(v1397, v1388, v1399, v1400);
    // pto: %square_inline1220__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1401 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %square_inline1220__ssa_v0
    ;
    uint64_t v1402 = (uint64_t) v48;
    TASSIGN(v1401, v1402);
    pipe_barrier(PIPE_V);
    TMUL(v1401, v1397, v1397);
    // pto: %t__tmp_v73
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1403 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v99);
    // pto: %t__tmp_v73
    ;
    uint64_t v1404 = (uint64_t) v48;
    TASSIGN(v1403, v1404);
    // pto: %312
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1405;
    // pto: %312
    ;
    uint64_t v1406 = (uint64_t) v48;
    TASSIGN(v1405, v1406);
    // pto: %t__tmp_v74
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1407 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v99);
    // pto: %t__tmp_v74
    ;
    uint64_t v1408 = (uint64_t) v63;
    TASSIGN(v1407, v1408);
    // pto: %313
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, 1, 2048, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1409;
    // pto: %313
    ;
    uint64_t v1410 = (uint64_t) v63;
    TASSIGN(v1409, v1410);
    // pto: %fold2048_inline1223__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1411 = Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v99);
    // pto: %fold2048_inline1223__ssa_v0
    ;
    uint64_t v1412 = (uint64_t) v48;
    TASSIGN(v1411, v1412);
    pipe_barrier(PIPE_V);
    TADD(v1411, v1405, v1409);
    // pto: %t__tmp_v75
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1413 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v100);
    // pto: %t__tmp_v75
    ;
    uint64_t v1414 = (uint64_t) v48;
    TASSIGN(v1413, v1414);
    // pto: %314
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1415;
    // pto: %314
    ;
    uint64_t v1416 = (uint64_t) v48;
    TASSIGN(v1415, v1416);
    // pto: %t__tmp_v76
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1417 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v100);
    // pto: %t__tmp_v76
    ;
    uint64_t v1418 = (uint64_t) v64;
    TASSIGN(v1417, v1418);
    // pto: %315
    ;
    Tile<TileType::Vec, float, 1, 2048, BLayout::RowMajor, 1, 1024, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1419;
    // pto: %315
    ;
    uint64_t v1420 = (uint64_t) v64;
    TASSIGN(v1419, v1420);
    // pto: %fold1024_inline1226__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1421 = Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v100);
    // pto: %fold1024_inline1226__ssa_v0
    ;
    uint64_t v1422 = (uint64_t) v48;
    TASSIGN(v1421, v1422);
    pipe_barrier(PIPE_V);
    TADD(v1421, v1415, v1419);
    // pto: %t__tmp_v77
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1423 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
    // pto: %t__tmp_v77
    ;
    uint64_t v1424 = (uint64_t) v48;
    TASSIGN(v1423, v1424);
    // pto: %316
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1425;
    // pto: %316
    ;
    uint64_t v1426 = (uint64_t) v48;
    TASSIGN(v1425, v1426);
    // pto: %t__tmp_v78
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1427 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
    // pto: %t__tmp_v78
    ;
    uint64_t v1428 = (uint64_t) v65;
    TASSIGN(v1427, v1428);
    // pto: %317
    ;
    Tile<TileType::Vec, float, 1, 1024, BLayout::RowMajor, 1, 512, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1429;
    // pto: %317
    ;
    uint64_t v1430 = (uint64_t) v65;
    TASSIGN(v1429, v1430);
    // pto: %fold512_inline1204__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1431 = Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v75);
    // pto: %fold512_inline1204__ssa_v0
    ;
    uint64_t v1432 = (uint64_t) v48;
    TASSIGN(v1431, v1432);
    pipe_barrier(PIPE_V);
    TADD(v1431, v1425, v1429);
    // pto: %t__tmp_v79
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1433 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v91);
    // pto: %t__tmp_v79
    ;
    uint64_t v1434 = (uint64_t) v48;
    TASSIGN(v1433, v1434);
    // pto: %318
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1435;
    // pto: %318
    ;
    uint64_t v1436 = (uint64_t) v48;
    TASSIGN(v1435, v1436);
    // pto: %t__tmp_v80
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1437 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v91);
    // pto: %t__tmp_v80
    ;
    uint64_t v1438 = (uint64_t) v66;
    TASSIGN(v1437, v1438);
    // pto: %319
    ;
    Tile<TileType::Vec, float, 1, 512, BLayout::RowMajor, 1, 256, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1439;
    // pto: %319
    ;
    uint64_t v1440 = (uint64_t) v66;
    TASSIGN(v1439, v1440);
    // pto: %fold256_inline1202__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1441 = Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v91);
    // pto: %fold256_inline1202__ssa_v0
    ;
    uint64_t v1442 = (uint64_t) v48;
    TASSIGN(v1441, v1442);
    pipe_barrier(PIPE_V);
    TADD(v1441, v1435, v1439);
    // pto: %t__tmp_v81
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1443 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v101);
    // pto: %t__tmp_v81
    ;
    uint64_t v1444 = (uint64_t) v48;
    TASSIGN(v1443, v1444);
    // pto: %320
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1445;
    // pto: %320
    ;
    uint64_t v1446 = (uint64_t) v48;
    TASSIGN(v1445, v1446);
    // pto: %t__tmp_v82
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1447 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v101);
    // pto: %t__tmp_v82
    ;
    uint64_t v1448 = (uint64_t) v67;
    TASSIGN(v1447, v1448);
    // pto: %321
    ;
    Tile<TileType::Vec, float, 1, 256, BLayout::RowMajor, 1, 128, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1449;
    // pto: %321
    ;
    uint64_t v1450 = (uint64_t) v67;
    TASSIGN(v1449, v1450);
    // pto: %fold128_inline1214__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1451 = Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v101);
    // pto: %fold128_inline1214__ssa_v0
    ;
    uint64_t v1452 = (uint64_t) v48;
    TASSIGN(v1451, v1452);
    pipe_barrier(PIPE_V);
    TADD(v1451, v1445, v1449);
    // pto: %t__tmp_v83
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1453 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
    // pto: %t__tmp_v83
    ;
    uint64_t v1454 = (uint64_t) v48;
    TASSIGN(v1453, v1454);
    // pto: %322
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1455;
    // pto: %322
    ;
    uint64_t v1456 = (uint64_t) v48;
    TASSIGN(v1455, v1456);
    // pto: %t__tmp_v84
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1457 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
    // pto: %t__tmp_v84
    ;
    uint64_t v1458 = (uint64_t) v68;
    TASSIGN(v1457, v1458);
    // pto: %323
    ;
    Tile<TileType::Vec, float, 1, 128, BLayout::RowMajor, 1, 64, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1459;
    // pto: %323
    ;
    uint64_t v1460 = (uint64_t) v68;
    TASSIGN(v1459, v1460);
    // pto: %fold64_inline1205__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1461 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v76);
    // pto: %fold64_inline1205__ssa_v0
    ;
    uint64_t v1462 = (uint64_t) v45;
    TASSIGN(v1461, v1462);
    pipe_barrier(PIPE_V);
    TADD(v1461, v1455, v1459);
    // pto: %t__tmp_v85
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1463 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v76);
    // pto: %t__tmp_v85
    ;
    uint64_t v1464 = (uint64_t) v48;
    TASSIGN(v1463, v1464);
    // pto: %repeated_inline1203__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1465 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v76);
    // pto: %repeated_inline1203__ssa_v0
    ;
    uint64_t v1466 = (uint64_t) v48;
    TASSIGN(v1465, v1466);
    pipe_barrier(PIPE_V);
    TCOLEXPAND(v1465, v1461);
    // pto: %t__tmp_v86
    ;
    Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1467 = Tile<TileType::Vec, float, 8, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v76);
    // pto: %t__tmp_v86
    ;
    uint64_t v1468 = (uint64_t) v45;
    TASSIGN(v1467, v1468);
    // pto: %total_inline1206__ssa_v0
    ;
    Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1469 = Tile<TileType::Vec, float, 8, 1, BLayout::ColMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v79, v70);
    // pto: %total_inline1206__ssa_v0
    ;
    uint64_t v1470 = (uint64_t) v46;
    TASSIGN(v1469, v1470);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID4);
    TROWSUM(v1469, v1465, v1467);
    set_flag(PIPE_V, PIPE_S, EVENT_ID3);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID3);
    // pto: %total_scalar_inline1215__ssa_v0
    ;
    float v1471 = v1469.GetValue(v82);
    // pto: %85
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1472 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %85
    ;
    uint64_t v1473 = (uint64_t) v48;
    TASSIGN(v1472, v1473);
    pipe_barrier(PIPE_V);
    TEXPANDS(v1472, v90);
    // pto: %total_vector_inline1217__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1474 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %total_vector_inline1217__tile
    ;
    uint64_t v1475 = (uint64_t) v48;
    TASSIGN(v1474, v1475);
    pipe_barrier(PIPE_V);
    TMULS(v1474, v1472, v1471);
    // pto: %86
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1476 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %86
    ;
    uint64_t v1477 = (uint64_t) v48;
    TASSIGN(v1476, v1477);
    pipe_barrier(PIPE_V);
    TMULS(v1476, v1474, v102);
    // pto: %variance_inline1219__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1478 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %variance_inline1219__tile
    ;
    uint64_t v1479 = (uint64_t) v48;
    TASSIGN(v1478, v1479);
    pipe_barrier(PIPE_V);
    TADDS(v1478, v1476, v89);
    set_flag(PIPE_V, PIPE_S, EVENT_ID4);
    // pto: %root_value_inline1224__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1480 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %root_value_inline1224__tile
    ;
    uint64_t v1481 = (uint64_t) v45;
    TASSIGN(v1480, v1481);
    pipe_barrier(PIPE_V);
    TSQRT(v1480, v1478);
    set_flag(PIPE_V, PIPE_S, EVENT_ID5);
    // pto: %variance_bits_inline1225__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1482 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %variance_bits_inline1225__tile
    ;
    uint64_t v1483 = (uint64_t) v48;
    TASSIGN(v1482, v1483);
    // pto: %approx_bits_inline1227__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1484 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %approx_bits_inline1227__tile
    ;
    uint64_t v1485 = (uint64_t) v45;
    TASSIGN(v1484, v1485);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID4);
    // pto: %324
    ;
    int32_t v1486 = v1482.GetValue(v82);
    set_flag(PIPE_S, PIPE_V, EVENT_ID5);
    // pto: %325
    ;
    int64_t v1487 = (int64_t) v1486;
    wait_flag(PIPE_V, PIPE_S, EVENT_ID5);
    // pto: %326
    ;
    int32_t v1488 = v1484.GetValue(v82);
    set_flag(PIPE_S, PIPE_MTE2, EVENT_ID1);
    // pto: %327
    ;
    int64_t v1489 = (int64_t) v1488;
    // pto: %329, %330, %331
    ;
    // pto: %y_bits_inline1231__phi_v7
    ;
    int64_t v1490;
    if ((int64_t) v1486 >= v103 & v1487 < v104) {
      // pto: %333
      ;
      int64_t v1491 = v1487 / v43;
      // pto: %335, %337
      ;
      int64_t v1492 = (int64_t) ((uint64_t) (v1487 % v43) + (uint64_t) v43);
      // pto: %y_bits_inline1231__rv_v2
      ;
      int64_t v1493;
      v1493 = v1489;
      for (int64_t v1494 = v82; v1494 < v80; v1494 += v70) {
        // pto: %339
        ;
        int64_t v1495 = v1493 / v43;
        // pto: %341
        ;
        int64_t v1496 = v1493 % v43;
        // pto: %343, %344, %346
        ;
        int64_t v1497 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1496 + (uint64_t) v43) * (uint64_t) v105) + (uint64_t) v70);
        // pto: %347
        ;
        int64_t v1498 = (int64_t) ((uint64_t) v1497 * (uint64_t) v1497);
        // pto: %351, %349, %348, %350
        ;
        int64_t v1499 = (int64_t) ((uint64_t) v1492 << (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1491 - (uint64_t) ((int64_t) (uint64_t) v1495 * (uint64_t) v105)) + (uint64_t) v106));
        // pto: %352
        ;
        uint64_t v1500 = (uint64_t) v1493;
        // pto: %352
        ;
        int64_t v1501 = (int64_t) (v1500 - (uint64_t) v107);
        // pto: %356, %358, %359, %361
        ;
        int64_t v1502 = (int64_t) ((uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) (v1501 % v43) + (uint64_t) v43) * (uint64_t) v105) + (uint64_t) v70);
        // pto: %362
        ;
        int64_t v1503 = (int64_t) ((uint64_t) v1502 * (uint64_t) v1502);
        // pto: %366, %364, %354, %363, %365
        ;
        int64_t v1504 = (int64_t) ((uint64_t) v1492 << (uint64_t) ((int64_t) (uint64_t) ((int64_t) (uint64_t) v1491 - (uint64_t) ((int64_t) (uint64_t) (v1501 / v43) * (uint64_t) v105)) + (uint64_t) v106));
        // pto: %371
        ;
        int64_t v1505 = v1493 % v105;
        // pto: %372
        ;
        bool v1506 = v1505 == v107;
        // pto: %368, %370, %373, %374
        ;
        // pto: %y_bits_inline1231__phi_v6
        ;
        int64_t v1507;
        if (v1498 < v1499 | v1499 == v1498 & v1506) {
          // pto: %375
          ;
          uint64_t v1508 = (uint64_t) v1493;
          // pto: %375
          ;
          v1507 = (int64_t) (v1508 + (uint64_t) v107);
        } else {
          // pto: %377, %379, %382, %383, %y_bits_inline1231__phi_v5
          ;
          int64_t v1509 = v1504 < v1503 | v1504 == v1503 & v1506 ? v1501 : v1493;
          v1507 = v1509;
        };
        v1493 = v1507;
      };
      v1490 = v1493;
    } else {
      v1490 = v1489;
    };
    // pto: %rounded_bits_inline1195__tile
    ;
    Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1510 = Tile<TileType::Vec, int32_t, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rounded_bits_inline1195__tile
    ;
    uint64_t v1511 = (uint64_t) v48;
    TASSIGN(v1510, v1511);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID5);
    pipe_barrier(PIPE_V);
    TEXPANDS(v1510, v85);
    set_flag(PIPE_V, PIPE_S, EVENT_ID6);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID6);
    for (int64_t v1512 = v82; v1512 < v79; v1512 += v70) {
      // pto: %385
      ;
      int32_t v1513 = (int32_t) v1490;
      v1510.SetValue(v1512, v1513);
    };
    // pto: %rounded_root_inline1193__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1514 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %rounded_root_inline1193__tile
    ;
    uint64_t v1515 = (uint64_t) v48;
    TASSIGN(v1514, v1515);
    // pto: %scalar_root_value_inline1213__tile
    ;
    float v1516 = v1514.GetValue(v82);
    set_flag(PIPE_S, PIPE_V, EVENT_ID6);
    // pto: %388
    ;
    float v1517 = v90 / v1516;
    // pto: %87
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1518 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %87
    ;
    uint64_t v1519 = (uint64_t) v48;
    TASSIGN(v1518, v1519);
    wait_flag(PIPE_S, PIPE_V, EVENT_ID6);
    TEXPANDS(v1518, v90);
    // pto: %inverse_inline1191__tile
    ;
    Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1520 = Tile<TileType::Vec, float, 1, 8, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v79);
    // pto: %inverse_inline1191__tile
    ;
    uint64_t v1521 = (uint64_t) v46;
    TASSIGN(v1520, v1521);
    pipe_barrier(PIPE_V);
    TMULS(v1520, v1518, v1517);
    set_flag(PIPE_V, PIPE_S, EVENT_ID0);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    __gm__ float* v1522 = PTOAS__GLOBAL_TENSOR_DATA(v163);
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    const int64_t v1523 = 48;
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    const int64_t v1524 = 64;
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    pto::Shape<1, 1, 1, 1, 8> v1525 = pto::Shape<1, 1, 1, 1, 8>();
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    pto::Stride<64, 64, 64, 64, 1> v1526 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %vec_ws_v2__iter_v1_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v1527 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 8>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v1522 + (v1523 + v1390 * v1524), v1525, v1526);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1527, v1520);
    // pto: %apply_value_inline1212__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1528 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %apply_value_inline1212__ssa_v0
    ;
    uint64_t v1529 = (uint64_t) v47;
    TASSIGN(v1528, v1529);
    // pto: %t__tmp_v92
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1530 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %t__tmp_v92
    ;
    uint64_t v1531 = (uint64_t) v45;
    TASSIGN(v1530, v1531);
    // pto: %gamma__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1532 = PTOAS__GLOBAL_TENSOR_DATA(v235);
    // pto: %gamma__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 4096> v1533 = pto::Shape<1, 1, 1, 1, 4096>();
    // pto: %gamma__ssa_v0_pview
    ;
    pto::Stride<4096, 4096, 4096, 4096, 1> v1534 = pto::Stride<4096, 4096, 4096, 4096, 1>();
    // pto: %gamma__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v1535 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v1532, v1533, v1534);
    wait_flag(PIPE_S, PIPE_MTE2, EVENT_ID1);
    TLOAD(v1530, v1535);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %w_raw_inline1190__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1536 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %w_raw_inline1190__ssa_v0
    ;
    uint64_t v1537 = (uint64_t) v45;
    TASSIGN(v1536, v1537);
    // pto: %w_inline1189__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1538 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %w_inline1189__ssa_v0
    ;
    uint64_t v1539 = (uint64_t) v48;
    TASSIGN(v1538, v1539);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    pipe_barrier(PIPE_V);
    RoundMode v1540 = RoundMode::CAST_ROUND;
    SaturationMode v1541 = SaturationMode::ON;
    TCVT(v1538, v1536, v1540, v1541);
    wait_flag(PIPE_V, PIPE_S, EVENT_ID0);
    // pto: %inv_inline1188__tile
    ;
    float v1542 = v1520.GetValue(v82);
    set_flag(PIPE_S, PIPE_V, EVENT_ID4);
    // pto: %scaled_inline1187__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1543 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %scaled_inline1187__ssa_v0
    ;
    uint64_t v1544 = (uint64_t) v47;
    TASSIGN(v1543, v1544);
    TMULS(v1543, v1528, v1542);
    // pto: %result_inline1186__ssa_v0
    ;
    Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1545 = Tile<TileType::Vec, float, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %result_inline1186__ssa_v0
    ;
    uint64_t v1546 = (uint64_t) v47;
    TASSIGN(v1545, v1546);
    pipe_barrier(PIPE_V);
    TCOLEXPANDMUL(v1545, v1543, v1538);
    set_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
    // pto: %t__tmp_v93
    ;
    Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1547 = Tile<TileType::Vec, bfloat16_t, 1, 4096, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v70, v74);
    // pto: %t__tmp_v93
    ;
    uint64_t v1548 = (uint64_t) v47;
    TASSIGN(v1547, v1548);
    pipe_barrier(PIPE_V);
    RoundMode v1549 = RoundMode::CAST_RINT;
    SaturationMode v1550 = SaturationMode::ON;
    TCVT(v1547, v1545, v1549, v1550);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %normalized__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1551 = PTOAS__GLOBAL_TENSOR_DATA(v136);
    // pto: %normalized__ssa_v0_pview
    ;
    const int64_t v1552 = 0;
    // pto: %normalized__ssa_v0_pview
    ;
    const int64_t v1553 = 4096;
    // pto: %normalized__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, 1, 4096> v1554 = pto::Shape<1, 1, 1, 1, 4096>();
    // pto: %normalized__ssa_v0_pview
    ;
    pto::Stride<4096, 4096, 4096, 4096, 1> v1555 = pto::Stride<4096, 4096, 4096, 4096, 1>();
    // pto: %normalized__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v1556 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v1551 + (v1552 + v1390 * v1553), v1554, v1555);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1556, v1547);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  }
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  // pto: %391, %392
  int64_t v1557 = (int64_t) ((uint64_t) v32 + (uint64_t) v108) / v71;
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_V, PIPE_MTE2, EVENT_ID1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v1558 = v291; v1558 < v1557; v1558 += v81) {
    // pto: %393
    ;
    int64_t v1559 = (int64_t) ((uint64_t) v1558 * (uint64_t) v71);
    // pto: %394
    ;
    int64_t v1560 = (int64_t) ((uint64_t) v32 - (uint64_t) v1559);
    // pto: %395
    ;
    int64_t v1561 = v1560 < v71 ? v1560 : v71;
    // pto: %projected_inline1235__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1562 = Tile<TileType::Vec, float, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1561, v75);
    // pto: %projected_inline1235__ssa_v0
    ;
    uint64_t v1563 = (uint64_t) v47;
    TASSIGN(v1562, v1563);
    // pto: %396
    ;
    int64_t v1564 = v1559 < v82 ? v82 : v1559;
    // pto: %accum_read__ssa_v0_pview
    ;
    const int64_t v1565 = 0;
    // pto: %accum_read__ssa_v0_pview
    ;
    __gm__ float* v1566 = PTOAS__GLOBAL_TENSOR_DATA(v244);
    // pto: %accum_read__ssa_v0_pview
    ;
    const int64_t v1567 = 1;
    // pto: %accum_read__ssa_v0_pview
    ;
    const int64_t v1568 = 1;
    // pto: %accum_read__ssa_v0_pview
    ;
    const int64_t v1569 = 1;
    // pto: %accum_read__ssa_v0_pview
    ;
    int64_t v1570 = v1561 * v75;
    // pto: %accum_read__ssa_v0_pview
    ;
    int64_t v1571 = v1569 * v1570;
    // pto: %accum_read__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v1572 = pto::Shape<1, 1, 1, -1, 512>(v1567, v1568, v1569, v1561, v75);
    // pto: %accum_read__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1573 = pto::Stride<-1, -1, -1, -1, -1>(v1568 * v1571, v1571, v1570, v75, v70);
    // pto: %accum_read__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1574 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1566 + (v1565 + v1564 * v75 + v82 * v70), v1572, v1573);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v1562, v1574);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %rounded_inline1234__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1575 = Tile<TileType::Vec, bfloat16_t, 16, 512, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1561, v75);
    // pto: %rounded_inline1234__ssa_v0
    ;
    uint64_t v1576 = (uint64_t) v47;
    TASSIGN(v1575, v1576);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v1577 = RoundMode::CAST_RINT;
    SaturationMode v1578 = SaturationMode::ON;
    TCVT(v1575, v1562, v1577, v1578);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %output__ssa_v0_pview
    ;
    const int64_t v1579 = 0;
    // pto: %output__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1580 = PTOAS__GLOBAL_TENSOR_DATA(v253);
    // pto: %output__ssa_v0_pview
    ;
    const int64_t v1581 = 1;
    // pto: %output__ssa_v0_pview
    ;
    const int64_t v1582 = 1;
    // pto: %output__ssa_v0_pview
    ;
    const int64_t v1583 = 1;
    // pto: %output__ssa_v0_pview
    ;
    int64_t v1584 = v1561 * v75;
    // pto: %output__ssa_v0_pview
    ;
    int64_t v1585 = v1583 * v1584;
    // pto: %output__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 512> v1586 = pto::Shape<1, 1, 1, -1, 512>(v1581, v1582, v1583, v1561, v75);
    // pto: %output__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1587 = pto::Stride<-1, -1, -1, -1, -1>(v1582 * v1585, v1585, v1584, v75, v70);
    // pto: %output__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1588 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 512>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1580 + (v1579 + v1564 * v75 + v82 * v70), v1586, v1587);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1588, v1575);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  for (int64_t v1589 = v291; v1589 < v1557; v1589 += v81) {
    // pto: %400
    ;
    int64_t v1590 = (int64_t) ((uint64_t) v1589 * (uint64_t) v71);
    // pto: %401
    ;
    int64_t v1591 = (int64_t) ((uint64_t) v32 - (uint64_t) v1590);
    // pto: %402
    ;
    int64_t v1592 = v1591 < v71 ? v1591 : v71;
    // pto: %value_inline1245__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1593 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1592, v76);
    // pto: %value_inline1245__ssa_v0
    ;
    uint64_t v1594 = (uint64_t) v47;
    TASSIGN(v1593, v1594);
    // pto: %403
    ;
    int64_t v1595 = v1590 < v82 ? v82 : v1590;
    // pto: %idx_accum_read__ssa_v0_pview
    ;
    const int64_t v1596 = 0;
    // pto: %idx_accum_read__ssa_v0_pview
    ;
    __gm__ float* v1597 = PTOAS__GLOBAL_TENSOR_DATA(v262);
    // pto: %idx_accum_read__ssa_v0_pview
    ;
    const int64_t v1598 = 1;
    // pto: %idx_accum_read__ssa_v0_pview
    ;
    const int64_t v1599 = 1;
    // pto: %idx_accum_read__ssa_v0_pview
    ;
    const int64_t v1600 = 1;
    // pto: %idx_accum_read__ssa_v0_pview
    ;
    int64_t v1601 = v1592 * v76;
    // pto: %idx_accum_read__ssa_v0_pview
    ;
    int64_t v1602 = v1600 * v1601;
    // pto: %idx_accum_read__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v1603 = pto::Shape<1, 1, 1, -1, 64>(v1598, v1599, v1600, v1592, v76);
    // pto: %idx_accum_read__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1604 = pto::Stride<-1, -1, -1, -1, -1>(v1599 * v1602, v1602, v1601, v76, v70);
    // pto: %idx_accum_read__ssa_v0_pview
    ;
    GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1605 = GlobalTensor<float, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1597 + (v1596 + v1595 * v76 + v82 * v70), v1603, v1604);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v1593, v1605);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    // pto: %projected_inline1248__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1606 = Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1592, v76);
    // pto: %projected_inline1248__ssa_v0
    ;
    uint64_t v1607 = (uint64_t) v48;
    TASSIGN(v1606, v1607);
    wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
    RoundMode v1608 = RoundMode::CAST_RINT;
    SaturationMode v1609 = SaturationMode::ON;
    TCVT(v1606, v1593, v1608, v1609);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %idx_raw__ssa_v0_pview
    ;
    const int64_t v1610 = 0;
    // pto: %idx_raw__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1611 = PTOAS__GLOBAL_TENSOR_DATA(v271);
    // pto: %idx_raw__ssa_v0_pview
    ;
    const int64_t v1612 = 1;
    // pto: %idx_raw__ssa_v0_pview
    ;
    const int64_t v1613 = 1;
    // pto: %idx_raw__ssa_v0_pview
    ;
    const int64_t v1614 = 1;
    // pto: %idx_raw__ssa_v0_pview
    ;
    int64_t v1615 = v1592 * v76;
    // pto: %idx_raw__ssa_v0_pview
    ;
    int64_t v1616 = v1614 * v1615;
    // pto: %idx_raw__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v1617 = pto::Shape<1, 1, 1, -1, 64>(v1612, v1613, v1614, v1592, v76);
    // pto: %idx_raw__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1618 = pto::Stride<-1, -1, -1, -1, -1>(v1613 * v1616, v1616, v1615, v76, v70);
    // pto: %idx_raw__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1619 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1611 + (v1610 + v1595 * v76 + v82 * v70), v1617, v1618);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1619, v1606);
    set_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    // pto: %value_v1_inline1244__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1620 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1592, v76);
    // pto: %value_v1_inline1244__ssa_v0
    ;
    uint64_t v1621 = (uint64_t) v47;
    TASSIGN(v1620, v1621);
    pipe_barrier(PIPE_V);
    RoundMode v1622 = RoundMode::CAST_ROUND;
    SaturationMode v1623 = SaturationMode::ON;
    TCVT(v1620, v1606, v1622, v1623);
    // pto: %value_v2_inline1243__ssa_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1624 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1592, v76);
    // pto: %value_v2_inline1243__ssa_v0
    ;
    uint64_t v1625 = (uint64_t) v47;
    TASSIGN(v1624, v1625);
    pipe_barrier(PIPE_V);
    TMULS(v1624, v1620, v109);
    // pto: %weighted_inline1242__ssa_v0
    ;
    Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1626 = Tile<TileType::Vec, bfloat16_t, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1592, v76);
    // pto: %weighted_inline1242__ssa_v0
    ;
    uint64_t v1627 = (uint64_t) v48;
    TASSIGN(v1626, v1627);
    pipe_barrier(PIPE_V);
    wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID6);
    RoundMode v1628 = RoundMode::CAST_RINT;
    SaturationMode v1629 = SaturationMode::ON;
    TCVT(v1626, v1624, v1628, v1629);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %idx_scaled__ssa_v0_pview
    ;
    const int64_t v1630 = 0;
    // pto: %idx_scaled__ssa_v0_pview
    ;
    __gm__ bfloat16_t* v1631 = PTOAS__GLOBAL_TENSOR_DATA(v280);
    // pto: %idx_scaled__ssa_v0_pview
    ;
    const int64_t v1632 = 1;
    // pto: %idx_scaled__ssa_v0_pview
    ;
    const int64_t v1633 = 1;
    // pto: %idx_scaled__ssa_v0_pview
    ;
    const int64_t v1634 = 1;
    // pto: %idx_scaled__ssa_v0_pview
    ;
    int64_t v1635 = v1592 * v76;
    // pto: %idx_scaled__ssa_v0_pview
    ;
    int64_t v1636 = v1634 * v1635;
    // pto: %idx_scaled__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v1637 = pto::Shape<1, 1, 1, -1, 64>(v1632, v1633, v1634, v1592, v76);
    // pto: %idx_scaled__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1638 = pto::Stride<-1, -1, -1, -1, -1>(v1633 * v1636, v1636, v1635, v76, v70);
    // pto: %idx_scaled__ssa_v0_pview
    ;
    GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1639 = GlobalTensor<bfloat16_t, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1631 + (v1630 + v1595 * v76 + v82 * v70), v1637, v1638);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1639, v1626);
    // pto: %result_inline1241__cast_fp32_tmp_v0
    ;
    Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1640 = Tile<TileType::Vec, float, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1592, v76);
    // pto: %result_inline1241__cast_fp32_tmp_v0
    ;
    uint64_t v1641 = (uint64_t) v47;
    TASSIGN(v1640, v1641);
    pipe_barrier(PIPE_V);
    RoundMode v1642 = RoundMode::CAST_RINT;
    SaturationMode v1643 = SaturationMode::ON;
    TCVT(v1640, v1626, v1642, v1643);
    // pto: %result_inline1241__ssa_v0
    ;
    Tile<TileType::Vec, half, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v1644 = Tile<TileType::Vec, half, 16, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v1592, v76);
    // pto: %result_inline1241__ssa_v0
    ;
    uint64_t v1645 = (uint64_t) v47;
    TASSIGN(v1644, v1645);
    pipe_barrier(PIPE_V);
    RoundMode v1646 = RoundMode::CAST_RINT;
    SaturationMode v1647 = SaturationMode::ON;
    TCVT(v1644, v1640, v1646, v1647);
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    // pto: %idx_output__ssa_v0_pview
    ;
    const int64_t v1648 = 0;
    // pto: %idx_output__ssa_v0_pview
    ;
    __gm__ half* v1649 = PTOAS__GLOBAL_TENSOR_DATA(v289);
    // pto: %idx_output__ssa_v0_pview
    ;
    const int64_t v1650 = 1;
    // pto: %idx_output__ssa_v0_pview
    ;
    const int64_t v1651 = 1;
    // pto: %idx_output__ssa_v0_pview
    ;
    const int64_t v1652 = 1;
    // pto: %idx_output__ssa_v0_pview
    ;
    int64_t v1653 = v1592 * v76;
    // pto: %idx_output__ssa_v0_pview
    ;
    int64_t v1654 = v1652 * v1653;
    // pto: %idx_output__ssa_v0_pview
    ;
    pto::Shape<1, 1, 1, -1, 64> v1655 = pto::Shape<1, 1, 1, -1, 64>(v1650, v1651, v1652, v1592, v76);
    // pto: %idx_output__ssa_v0_pview
    ;
    pto::Stride<-1, -1, -1, -1, -1> v1656 = pto::Stride<-1, -1, -1, -1, -1>(v1651 * v1654, v1654, v1653, v76, v70);
    // pto: %idx_output__ssa_v0_pview
    ;
    GlobalTensor<half, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND> v1657 = GlobalTensor<half, pto::Shape<1, 1, 1, -1, 64>, pto::Stride<-1, -1, -1, -1, -1>, pto::Layout::ND>(v1649 + (v1648 + v1595 * v76 + v82 * v70), v1655, v1656);
    wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(v1657, v1644);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID3);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID4);
  wait_flag(PIPE_MTE3, PIPE_V, EVENT_ID5);
  wait_flag(PIPE_S, PIPE_V, EVENT_ID4);
  pipe_barrier(PIPE_ALL);
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  SYNCALL<SyncCoreType::Mix>();
  dcci((__gm__ void*)0, cache_line_t::ENTIRE_DATA_CACHE);
  pipe_barrier(PIPE_ALL);
  dsb(DSB_DDR);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}