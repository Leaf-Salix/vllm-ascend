"""No-device gates for layout-only prefix candidate; use the existing SDK."""
import hashlib,json,os,sys
from pathlib import Path
import pypto,simpler
import vllm_ascend.ops.pypto as namespace
from pypto.runtime import RunConfig
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program

exp=Path(os.environ['SPMD_EXPERIMENT']);namespace.__path__.insert(0,str(exp/'src/vllm_ascend/ops/pypto'));sys.path.insert(0,str(exp))
from prepack_candidate import prepacked_precision_hc_prefix_indexer as control,prepack_fixed_hc_weight
from bf16_input_pack_candidate import prepacked_precision_hc_prefix_indexer as candidate
assert os.environ['ASCEND_RT_VISIBLE_DEVICES']==''
assert 'low-acceptance-20261010/runtime-package/pypto' in pypto.__file__
assert 'pypto-reference/runtime/python/simpler' in simpler.__file__
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
record={'hardware_executed':False,'scope':'single factor cast before layout copies; no arithmetic or barrier change','control_sha256':sha(exp/'prepack_candidate.py'),'candidate_sha256':sha(exp/'bf16_input_pack_candidate.py'),'programs':{}}
for name,entry in [('control',control),('candidate',candidate),('prepare',prepack_fixed_hc_weight)]:
 artifact=exp/f'bf16-input-pack-{name}-artifact'
 compiled=entry.compile(config=RunConfig(platform='a2a3',dump_passes=True,save_kernels=True,save_kernels_dir=str(artifact)))
 abi=kernel_abi_for_program(entry.specialize(),platform='a2a3',runtime='tensormap_and_ringbuffer')
 kernel=exp/f'bf16-input-pack-{name}-kernel-artifact'
 _compile_impl(entry.specialize(),output_dir=str(kernel),platform='a2a3',dump_passes=True,_kernel_abi=abi)
 record['programs'][name]={'compiled':True,'kernel_mode_abi_pass':True,'kernel_artifact_dir':str(kernel),'generated':{str(p.relative_to(kernel)):sha(p) for p in kernel.rglob('*') if p.is_file() and p.suffix in ('.py','.json','.cpp')}}
(exp/'compile-bf16-input-pack.json').write_text(json.dumps(record,indent=2)+'\n')
print('BF16_INPUT_PACK_COMPILED',flush=True)
