"""Build a diagnostic moving only an existing cast before pure layout copies."""
import ast
import copy
import hashlib
import json
from pathlib import Path

workspace=Path('/Users/jiayetcs/Desktop/Project/PyPTO')
r=workspace/'reports/dsv4-tnd-precision-spmd-20261019'
repo=workspace/'vllm-ascend-nalinaly-tnd-20261008-codex'
parent=repo/'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision_spmd/hc_prefix_stages.py'
module=ast.parse(parent.read_text())
old=next(n for n in module.body if isinstance(n,ast.FunctionDef) and n.name=='hc_pack_input')
new=copy.deepcopy(old);new.name='hc_pack_input_bf16'
casts_moved=0;zero_types=0
for node in ast.walk(new):
 if isinstance(node,ast.For):
  for index,statement in list(enumerate(node.body)):
   if isinstance(statement,ast.Assign) and ast.unparse(statement.targets[0])=='panel64_transposed_values':
    node.body.insert(index,ast.parse('panel64_values = pl.tile.cast(panel64_values, pl.BF16)').body[0]);casts_moved+=1
 if isinstance(node,ast.Call) and ast.unparse(node.func)=='pl.tile.full':
  for key in node.keywords:
   if key.arg=='dtype':
    assert ast.unparse(key.value)=='pl.FP32';key.value=ast.parse('pl.BF16',mode='eval').body;zero_types+=1
 if isinstance(node,ast.Call) and ast.unparse(node.func)=='pl.store':
  assert ast.unparse(node.args[0])=='pl.tile.cast(panel64_packed_values, pl.BF16)';node.args[0]=ast.Name(id='panel64_packed_values',ctx=ast.Load())
assert casts_moved==zero_types==1
ast.fix_missing_locations(new)
control=r/'prepack_candidate.py';tree=ast.parse(control.read_text())
# Reuse every prefix stage, ownership loop and barrier from the tested control.
imports=ast.parse('from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.hc_prefix_stages import HC_DIM').body
index=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.FunctionDef))
tree.body[index:index]=[*imports,new]
rewrites=0
for node in ast.walk(tree):
 if isinstance(node,ast.Call) and ast.unparse(node.func)=='hc_pack_input':node.func.id='hc_pack_input_bf16';rewrites+=1
assert rewrites==1
ast.fix_missing_locations(tree)
p=r/'bf16_input_pack_candidate.py';p.write_text(ast.unparse(tree)+'\n')
(r/'BF16_INPUT_PACK_BUILD.json').write_text(json.dumps({'control_sha256':hashlib.sha256(control.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'parent_stage_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),'single_factor':'one cast moved before transpose/duplicate/transpose; all other math, ownership and ten barriers unchanged','hardware_executed':False},indent=2)+'\n')
print('BF16_PACK_CANDIDATE_BUILT',casts_moved,zero_types,rewrites)
