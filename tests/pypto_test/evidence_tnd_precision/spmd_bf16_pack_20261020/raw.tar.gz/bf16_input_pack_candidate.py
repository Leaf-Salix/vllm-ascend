"""Single-SPMD HC/Norm/WKV/Indexer-weight prefix with a 32-tensor MIX ABI."""
import pypto.language as pl
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.hc_prefix_indexer import packed_prefix_indexer_cube
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.hc_prefix_indexer_stages import VEC_ROWS, indexer_projection_matmul, indexer_projection_round, packed_hc_comb, packed_hc_linear_reduce, packed_hc_mix, packed_hc_pre_post, packed_hc_rms, packed_norm_rows
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.hc_prefix_stages import P16, PARTIAL_ROWS, hc_linear, hc_pack_input, hc_pack_weight, hc_square, hc_widen
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.norm_wkv_stages import ACC_ROWS, T, wkv_matmul, wkv_round
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.rendezvous import GROUPS, handoff
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.hc_prefix_stages import HC_DIM

@pl.jit.inline(auto_scope=False)
def hc_pack_input_bf16(x_flat: pl.Tensor[[T, HC_DIM], pl.FP32], panel64_packed_flat: pl.InOut[pl.Tensor[[P16, HC_DIM * 2], pl.BF16]], worker: pl.Scalar[pl.INDEX]):
    t_dim = pl.tensor.dim(x_flat, 0)
    t_linear = pl.tensor.dim(panel64_packed_flat, 0)
    panel64_inputs_per_task = 1
    if t_dim >= 64:
        panel64_inputs_per_task = 4
    for panel64_input_group in pl.range(worker, t_linear // 16 * (HC_DIM // 256) // panel64_inputs_per_task, 48):
        for panel64_input_local in pl.range(panel64_inputs_per_task):
            panel64_transpose_unit = panel64_input_group * panel64_inputs_per_task + panel64_input_local
            panel64_t0 = panel64_transpose_unit // (HC_DIM // 256) * 16
            panel64_k0 = panel64_transpose_unit % (HC_DIM // 256) * 256
            panel64_values = pl.load(x_flat, [panel64_t0, panel64_k0], [16, 256], valid_shape=[pl.min(16, t_dim - panel64_t0), 256])
            for panel64_invalid_row in pl.range(pl.min(16, t_dim - panel64_t0), 16):
                for panel64_invalid_col in pl.range(256):
                    pl.write(panel64_values, [panel64_invalid_row, panel64_invalid_col], 0.0)
            panel64_values = pl.set_validshape(panel64_values, 16, 256)
            panel64_values = pl.tile.cast(panel64_values, pl.BF16)
            panel64_transposed_values = pl.tile.transpose(panel64_values, axis1=0, axis2=1)
            panel64_packed_transposed = pl.tile.full([512, 16], dtype=pl.BF16, value=0.0)
            for panel64_chunk in pl.range(32):
                panel64_input8 = pl.tile.slice(panel64_transposed_values, [8, 16], [panel64_chunk * 8, 0])
                panel64_packed_transposed = pl.tile.assemble(panel64_packed_transposed, panel64_input8, [panel64_chunk * 16, 0])
                panel64_packed_transposed = pl.tile.assemble(panel64_packed_transposed, panel64_input8, [panel64_chunk * 16 + 8, 0])
            panel64_packed_values = pl.tile.transpose(panel64_packed_transposed, axis1=0, axis2=1)
            pl.store(panel64_packed_values, [panel64_t0, panel64_k0 * 2], panel64_packed_flat)
    return panel64_packed_flat

@pl.jit.incore
def prepacked_prefix_indexer_vector(flat: pl.Tensor[[T, 16384], pl.BF16], wide: pl.InOut[pl.Tensor[[T, 16384], pl.FP32]], square_read: pl.Tensor[[PARTIAL_ROWS, 16], pl.FP32], vec_ws: pl.InOut[pl.Tensor[[VEC_ROWS, 64], pl.FP32]], packed_flat: pl.InOut[pl.Tensor[[P16, 32768], pl.BF16]], linear_read: pl.Tensor[[PARTIAL_ROWS, 32], pl.FP32], hc_scale: pl.Tensor[[3], pl.FP32], hc_base: pl.Tensor[[24], pl.FP32], hc_base_2d: pl.Tensor[[1, 24], pl.FP32], post: pl.InOut[pl.Tensor[[T, 4], pl.FP32]], comb: pl.InOut[pl.Tensor[[T, 16], pl.FP32]], mixed: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], mixed_tail: pl.InOut[pl.Tensor[[8, 4096], pl.BF16]], gamma: pl.Tensor[[4096], pl.BF16], normalized: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], accum_read: pl.Tensor[[ACC_ROWS, 512], pl.FP32], output: pl.InOut[pl.Tensor[[T, 512], pl.BF16]], ffts: pl.Tensor[[256], pl.INT64], idx_accum_read: pl.Tensor[[P16, 64], pl.FP32], idx_raw: pl.InOut[pl.Tensor[[T, 64], pl.BF16]], idx_scaled: pl.InOut[pl.Tensor[[T, 64], pl.BF16]], idx_output: pl.InOut[pl.Tensor[[T, 64], pl.FP16]]):
    pl.func_attr({'split_aiv': True})
    pl.system.set_ffts(ffts)
    worker = pl.tile.get_block_idx() * 2 + pl.tile.get_subblock_idx()
    wide = hc_widen(flat, wide, worker)
    handoff()
    handoff()
    vec_ws = packed_hc_rms(square_read, vec_ws, wide, worker)
    packed_flat = hc_pack_input_bf16(wide, packed_flat, worker)
    handoff()
    handoff()
    vec_ws = packed_hc_linear_reduce(linear_read, vec_ws, worker)
    handoff()
    vec_ws, post = packed_hc_pre_post(vec_ws, hc_scale, hc_base, post, worker)
    vec_ws, comb = packed_hc_comb(vec_ws, hc_scale, hc_base_2d, comb, False, worker)
    handoff()
    mixed, mixed_tail = packed_hc_mix(wide, vec_ws, mixed, mixed_tail, worker)
    handoff()
    normalized, vec_ws = packed_norm_rows(mixed, gamma, normalized, vec_ws, worker)
    handoff()
    handoff()
    output = wkv_round(accum_read, output, worker)
    idx_raw, idx_scaled, idx_output = indexer_projection_round(idx_accum_read, idx_raw, idx_scaled, idx_output, worker)
    handoff()
    return (wide, vec_ws, packed_flat, post, comb, mixed, mixed_tail, normalized, output, idx_raw, idx_scaled, idx_output)

@pl.jit.inline(auto_scope=False)
def prepacked_prefix_indexer_group(hc_scale: pl.Tensor[[3], pl.FP32], hc_base: pl.Tensor[[24], pl.FP32], gamma: pl.Tensor[[4096], pl.BF16], weight: pl.Tensor[[512, 4096], pl.BF16], order: pl.Tensor[[32, 16], pl.INT32], wide: pl.InOut[pl.Tensor[[T, 16384], pl.FP32]], square: pl.InOut[pl.Tensor[[PARTIAL_ROWS, 16], pl.FP32]], square_read: pl.Tensor[[PARTIAL_ROWS, 16], pl.FP32], vec_ws: pl.InOut[pl.Tensor[[VEC_ROWS, 64], pl.FP32]], packed_weight: pl.Tensor[[32768, 32], pl.BF16], packed_flat: pl.InOut[pl.Tensor[[P16, 32768], pl.BF16]], linear: pl.InOut[pl.Tensor[[PARTIAL_ROWS, 32], pl.FP32]], linear_read: pl.Tensor[[PARTIAL_ROWS, 32], pl.FP32], post: pl.InOut[pl.Tensor[[T, 4], pl.FP32]], comb: pl.InOut[pl.Tensor[[T, 16], pl.FP32]], mixed: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], mixed_tail: pl.InOut[pl.Tensor[[8, 4096], pl.BF16]], normalized: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], accum: pl.InOut[pl.Tensor[[ACC_ROWS, 512], pl.FP32]], accum_read: pl.Tensor[[ACC_ROWS, 512], pl.FP32], output: pl.InOut[pl.Tensor[[T, 512], pl.BF16]], ffts: pl.Tensor[[256], pl.INT64], flat: pl.Tensor[[T, 16384], pl.BF16], hc_base_2d: pl.Tensor[[1, 24], pl.FP32], idx_weight: pl.Tensor[[64, 4096], pl.BF16], idx_order: pl.Tensor[[16, 4, 16], pl.INT32], idx_accum: pl.InOut[pl.Tensor[[P16, 64], pl.FP32]], idx_accum_read: pl.Tensor[[P16, 64], pl.FP32], idx_raw: pl.InOut[pl.Tensor[[T, 64], pl.BF16]], idx_scaled: pl.InOut[pl.Tensor[[T, 64], pl.BF16]], idx_output: pl.InOut[pl.Tensor[[T, 64], pl.FP16]]):
    with pl.cluster(name_hint='precision_hc_prefix'):
        square, linear, accum, idx_accum = packed_prefix_indexer_cube(wide, square, packed_weight, packed_flat, linear, normalized, weight, order, accum, ffts, idx_weight, idx_order, idx_accum)
        wide, vec_ws, packed_flat, post, comb, mixed, mixed_tail, normalized, output, idx_raw, idx_scaled, idx_output = prepacked_prefix_indexer_vector(flat, wide, square_read, vec_ws, packed_flat, linear_read, hc_scale, hc_base, hc_base_2d, post, comb, mixed, mixed_tail, gamma, normalized, accum_read, output, ffts, idx_accum_read, idx_raw, idx_scaled, idx_output)
    return (mixed, post, comb, normalized, vec_ws, accum, output, idx_raw, idx_scaled, idx_output)

@pl.jit
def prepacked_precision_hc_prefix_indexer(x: pl.Tensor[[T, 4, 4096], pl.BF16], hc_scale: pl.Tensor[[3], pl.FP32], hc_base: pl.Tensor[[24], pl.FP32], gamma: pl.Tensor[[4096], pl.BF16], weight: pl.Tensor[[512, 4096], pl.BF16], order: pl.Tensor[[32, 16], pl.INT32], wide: pl.InOut[pl.Tensor[[T, 16384], pl.FP32]], square: pl.InOut[pl.Tensor[[PARTIAL_ROWS, 16], pl.FP32]], square_read: pl.Tensor[[PARTIAL_ROWS, 16], pl.FP32], vec_ws: pl.InOut[pl.Tensor[[VEC_ROWS, 64], pl.FP32]], packed_weight: pl.Tensor[[32768, 32], pl.BF16], packed_flat: pl.InOut[pl.Tensor[[P16, 32768], pl.BF16]], linear: pl.InOut[pl.Tensor[[PARTIAL_ROWS, 32], pl.FP32]], linear_read: pl.Tensor[[PARTIAL_ROWS, 32], pl.FP32], post: pl.InOut[pl.Tensor[[T, 4], pl.FP32]], comb: pl.InOut[pl.Tensor[[T, 16], pl.FP32]], mixed: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], mixed_tail: pl.InOut[pl.Tensor[[8, 4096], pl.BF16]], normalized: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]], accum: pl.InOut[pl.Tensor[[ACC_ROWS, 512], pl.FP32]], accum_read: pl.Tensor[[ACC_ROWS, 512], pl.FP32], output: pl.InOut[pl.Tensor[[T, 512], pl.BF16]], ffts: pl.Tensor[[256], pl.INT64], idx_weight: pl.Tensor[[64, 4096], pl.BF16], idx_order: pl.Tensor[[16, 4, 16], pl.INT32], idx_accum: pl.InOut[pl.Tensor[[P16, 64], pl.FP32]], idx_accum_read: pl.Tensor[[P16, 64], pl.FP32], idx_raw: pl.InOut[pl.Tensor[[T, 64], pl.BF16]], idx_scaled: pl.InOut[pl.Tensor[[T, 64], pl.BF16]], idx_output: pl.InOut[pl.Tensor[[T, 64], pl.FP16]]):
    vec_ws.bind_dynamic(0, VEC_ROWS)
    idx_output.bind_dynamic(0, T)
    idx_scaled.bind_dynamic(0, T)
    idx_raw.bind_dynamic(0, T)
    idx_accum_read.bind_dynamic(0, P16)
    idx_accum.bind_dynamic(0, P16)
    x.bind_dynamic(0, T)
    wide.bind_dynamic(0, T)
    square.bind_dynamic(0, PARTIAL_ROWS)
    square_read.bind_dynamic(0, PARTIAL_ROWS)
    packed_flat.bind_dynamic(0, P16)
    linear.bind_dynamic(0, PARTIAL_ROWS)
    linear_read.bind_dynamic(0, PARTIAL_ROWS)
    post.bind_dynamic(0, T)
    comb.bind_dynamic(0, T)
    mixed.bind_dynamic(0, T)
    normalized.bind_dynamic(0, T)
    accum.bind_dynamic(0, ACC_ROWS)
    accum_read.bind_dynamic(0, ACC_ROWS)
    output.bind_dynamic(0, T)
    tokens = pl.tensor.dim(x, 0)
    flat = pl.reshape(x, [tokens, 16384])
    hc_base_2d = pl.reshape(hc_base, [1, 24])
    with pl.spmd(GROUPS, sync_start=True):
        mixed, post, comb, normalized, vec_ws, accum, output, idx_raw, idx_scaled, idx_output = prepacked_prefix_indexer_group(hc_scale, hc_base, gamma, weight, order, wide, square, square_read, vec_ws, packed_weight, packed_flat, linear, linear_read, post, comb, mixed, mixed_tail, normalized, accum, accum_read, output, ffts, flat, hc_base_2d, idx_weight, idx_order, idx_accum, idx_accum_read, idx_raw, idx_scaled, idx_output)
    return (mixed, post, comb, normalized, vec_ws, accum, output, idx_raw, idx_scaled, idx_output)

@pl.jit.incore
def _prepack_fixed_hc_weight(hc_fn: pl.Tensor[[24, 16384], pl.FP32], packed: pl.InOut[pl.Tensor[[32768, 32], pl.BF16]]):
    pl.func_attr({'split_aiv': True})
    worker = pl.tile.get_block_idx() * 2 + pl.tile.get_subblock_idx()
    packed = hc_pack_weight(hc_fn, packed, worker)
    return packed

@pl.jit
def prepack_fixed_hc_weight(hc_fn: pl.Tensor[[24, 16384], pl.FP32], packed: pl.InOut[pl.Tensor[[32768, 32], pl.BF16]]):
    with pl.spmd(GROUPS):
        with pl.cluster(name_hint='fixed_hc_weight'):
            packed = _prepack_fixed_hc_weight(hc_fn, packed)
    return packed
