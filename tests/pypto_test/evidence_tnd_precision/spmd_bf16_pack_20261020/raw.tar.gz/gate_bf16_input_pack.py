"""Complete actual Torch registration and argument-order checks without a device."""
from pathlib import Path
import hashlib,json,os,sys
import pypto.torch
import vllm_ascend.ops.pypto as namespace
exp=Path(os.environ['SPMD_EXPERIMENT']);namespace.__path__.insert(0,str(exp/'src/vllm_ascend/ops/pypto'));sys.path.insert(0,str(exp))
from prepack_candidate import prepacked_precision_hc_prefix_indexer as control
from bf16_input_pack_candidate import prepacked_precision_hc_prefix_indexer as candidate
assert os.environ['ASCEND_RT_VISIBLE_DEVICES']==''
p=exp/'compile-bf16-input-pack.json';record=json.loads(p.read_text())
for name,field in [('prepack_candidate.py','control_sha256'),('bf16_input_pack_candidate.py','candidate_sha256')]:assert hashlib.sha256((exp/name).read_bytes()).hexdigest()==record[field]
ops=[pypto.torch.register(entry,'bf16_input_pack_gate::'+name) for name,entry in [('control',control),('candidate',candidate)]]
names=[[a.name for a in op._schema.arguments] for op in ops]
assert names[0]==names[1] and len(names[0])==30 and 'hc_fn' not in names[0]
assert names[0][:6]==['x','hc_scale','hc_base','gamma','weight','order']
record['torch_dispatcher_registration_pass']=True;record['argument_names']=names[0];record['schemas']=[str(op._schema) for op in ops]
p.write_text(json.dumps(record,indent=2)+'\n')
print('BF16_INPUT_PACK_TORCH_GATE_OK',len(names[0]),flush=True)
