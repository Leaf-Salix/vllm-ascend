"""真实C4权重的Norm→WKV切片对拍；非完整CSA或整模型验收。"""
import argparse
import hashlib
import json
import os
import sys
from pathlib import Path
import statistics

import torch
import torch_npu
import pypto.torch
import simpler
from vllm.engine.arg_utils import EngineArgs
from vllm.platforms import current_platform
import vllm_ascend.ops.pypto as namespace
from dsv4_csa_native_case import native_session
from dsv4_csa_single_layer import make_layer

experiment = Path(os.environ['SPMD_EXPERIMENT'])
namespace.__path__.insert(0, str(experiment / 'src/vllm_ascend/ops/pypto'))
sys.path.insert(0, str(experiment))
from prepack_candidate import prepacked_precision_hc_prefix_indexer as precision_hc_prefix
from bf16_input_pack_candidate import prepacked_precision_hc_prefix_indexer
from prepack_candidate import prepack_fixed_hc_weight
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.hc_pre import hc_pre_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.hc_pre_contract import qualify_hc_pre_weight
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.input_norm import input_norm_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv import wkv_test
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.wkv_order_data import (
    WKV_COLUMN_ORDERS, WKV_K_ORDERS, WKV_TOKEN_MODES,
)

from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_projection import indexer_projection
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_order_data import INDEXER_K_ORDERS,INDEXER_TILE_ORDERS,INDEXER_TOKEN_MODES
from vllm_ascend.device.device_op import DeviceOperator

parser = argparse.ArgumentParser()
parser.add_argument('--tokens', type=int, required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
assert 1 <= args.tokens <= 256 and args.tokens != 6, 'T6 needs separate static-profile qualification'
args.out.mkdir(parents=True, exist_ok=False)
report = {'complete': False, 'pass': False, 'tokens': args.tokens,
          'scope': 'real C4 weights, synthetic HC input, HC-pre/Norm/WKV/Indexer-weight prefix; direct ACLGraph, not vLLM FULL or complete CSA',
          'comparisons': {}, 'cann': os.environ['ASCEND_HOME_PATH'], 'ptoas': os.environ['PTOAS_ROOT'],
          'pypto': pypto.__file__, 'simpler': simpler.__file__}
assert 'low-acceptance-20261010/runtime-package/pypto' in pypto.__file__
assert 'pypto-reference/runtime/python/simpler' in simpler.__file__
package = experiment / 'src/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision_spmd'
identity = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in package.glob('*.py')}
compiled_identity = json.loads((experiment / 'compile-full-csa-packaged.json').read_text())['sources']
assert identity == compiled_identity, 'source differs from successful no-device compilation'
report['candidate_sources'] = identity
compiled_receipt = json.loads((experiment/'compile-full-csa-packaged.json').read_text())
assert compiled_receipt['kernel_mode_abi_pass'] and compiled_receipt['torch_dispatcher_registration_pass']
prepack_receipt=json.loads((experiment/'compile-bf16-input-pack.json').read_text())
assert hashlib.sha256((experiment/'prepack_candidate.py').read_bytes()).hexdigest()==prepack_receipt['control_sha256']
assert hashlib.sha256((experiment/'bf16_input_pack_candidate.py').read_bytes()).hexdigest()==prepack_receipt['candidate_sha256']
assert all(v['compiled'] and v['kernel_mode_abi_pass'] for v in prepack_receipt['programs'].values())
assert prepack_receipt['torch_dispatcher_registration_pass']
report['prepack_receipt_sha256']=hashlib.sha256((experiment/'compile-bf16-input-pack.json').read_bytes()).hexdigest()
report['diagnostic_sources']={n:hashlib.sha256((experiment/n).read_bytes()).hexdigest() for n in ('prepack_candidate.py','bf16_input_pack_candidate.py')}
report['helper_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
control_package = Path(os.environ['SOURCE_ROOT']) / 'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision'
report['control_sources'] = {name: hashlib.sha256((control_package/name).read_bytes()).hexdigest()
                             for name in ('hc_pre.py','hc_pre_contract.py','input_norm.py','wkv.py','wkv_order_data.py','indexer_projection.py','indexer_order_data.py')}
assert all(compiled_receipt['baseline_sources']['vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision/'+n]==h for n,h in report['control_sources'].items())


def save():
    (args.out / 'result.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')

def require_exact(name, actual, expected):
    a, b = actual.contiguous().cpu(), expected.contiguous().cpu()
    if a.is_floating_point():
        assert bool(torch.isfinite(a).all()) and bool(torch.isfinite(b).all()), name+' nonfinite'
    equal = a.shape == b.shape and a.dtype == b.dtype and torch.equal(a.view(torch.uint8), b.view(torch.uint8))
    report['comparisons'][name] = {'bit_equal': equal, 'different_elements': int((a != b).sum()),
                                  'max_abs': float((a.float() - b.float()).abs().max())}
    save()
    if not equal:
        torch.save({'actual': a, 'expected': b}, args.out / 'first-difference.pt')
        raise RuntimeError('First bit difference at ' + name)

current_platform.pre_register_and_update()
torch.npu.set_device(0)
torch.npu.config.allow_internal_format = True
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
from vllm_ascend.utils import enable_custom_op
assert enable_custom_op()
checkpoint = Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config = EngineArgs(model=str(checkpoint), tokenizer_mode='deepseek_v4', trust_remote_code=True,
    tensor_parallel_size=1, dtype='bfloat16', quantization='ascend', hf_overrides={'sliding_window':128},
    max_model_len=16384, max_num_seqs=40, max_num_batched_tokens=256, enable_prefix_caching=False,
    enforce_eager=False, block_size=32,
    speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},
    compilation_config={'cudagraph_mode':'FULL_DECODE_ONLY','cudagraph_capture_sizes':[args.tokens],
                        'cache_dir':str(args.out/'vllm-cache')},
    additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,
        'fuse_norm_quant':True,'align_decode_capture_sizes':False},'enable_cpu_binding':False,
        'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,
        'enable_dsa_cp':False}).create_engine_config()
save()
with native_session(config, 0), torch.inference_mode():
    layer, details = make_layer(config, checkpoint, torch.device('npu:0'), 4)
    report['weights'] = details
    pypto.torch.init()
    norm_op = pypto.torch.register(input_norm_test, 'precision_spmd_control::norm')
    wkv_op = pypto.torch.register(wkv_test, 'precision_spmd_control::wkv')
    hc_op = pypto.torch.register(hc_pre_test, 'precision_spmd_prefix_control::hc')
    candidate = pypto.torch.register(precision_hc_prefix, 'precision_spmd_input_pack_ab::control')
    prepared=pypto.torch.register(prepacked_precision_hc_prefix_indexer,'precision_spmd_input_pack_ab::prepared')
    prepacker=pypto.torch.register(prepack_fixed_hc_weight,'precision_spmd_input_pack_ab::prepare')
    indexer_op=pypto.torch.register(indexer_projection,'precision_spmd_prefix_control::indexer_projection')
    t = args.tokens
    p16 = (t+15)//16*16
    report['hc_weight_qualification'] = qualify_hc_pre_weight(layer.hc_attn_fn, 'layer4')
    weight = layer.self_attn.wkv.weight.detach()
    if torch_npu.get_npu_format(weight) not in (0,2): weight = torch_npu.npu_format_cast(weight,2)
    weight = weight.contiguous()
    require_exact('weight-layout-values', weight, layer.self_attn.wkv.weight.detach())
    gamma = layer.input_layernorm.weight.detach().contiguous()
    assert weight.shape == (512,4096) and weight.dtype == torch.bfloat16 and layer.self_attn.wkv.bias is None
    order = torch.tensor([WKV_K_ORDERS[i] for i in WKV_COLUMN_ORDERS[WKV_TOKEN_MODES[t-1]]],
                         dtype=torch.int32, device='npu:0')
    impl=layer.self_attn.dsa_attn.dsa_attn.impl
    projection=impl.weights_proj
    assert projection.bias is None and projection.weight.dtype==torch.bfloat16
    assert tuple(projection.weight.shape)==(64,4096) and not projection.return_bias
    idx_weight=projection.weight.detach()
    if torch_npu.get_npu_format(idx_weight) not in (0,2): idx_weight=torch_npu.npu_format_cast(idx_weight,2)
    idx_weight=idx_weight.contiguous()
    require_exact('indexer-weight-layout-values',idx_weight,projection.weight.detach())
    idx_order=torch.tensor([[INDEXER_K_ORDERS[i] for i in row] for row in INDEXER_TILE_ORDERS[INDEXER_TOKEN_MODES[t-1]]],dtype=torch.int32,device='npu:0')
    assert impl.indexer_softmax_scale*impl.indexer_heads**-0.5==0.011048543456039806
    torch.manual_seed(1024)
    x_a = torch.randn(t,4,4096,device='npu:0',dtype=torch.bfloat16)
    x_b = (x_a.float()*1.125+0.03125).to(torch.bfloat16)
    x = x_a.clone()
    allocations=[]
    def guarded(rows,cols,dtype):
        width = torch.empty((),dtype=dtype).element_size()*cols
        front = max(1,(32+width-1)//width)
        storage = torch.full((rows+2*front,cols),37,dtype=dtype,device='npu:0')
        allocations.append((storage,front))
        return storage[front:front+rows]
    specs = {
        'wide':(t,16384,torch.float32),'square':(22*p16,16,torch.float32),
        'vec_ws':(p16+8,64,torch.float32),'packed_weight':(32768,32,torch.bfloat16),
        'packed_flat':(p16,32768,torch.bfloat16),'linear':(22*p16,32,torch.float32),
        'post':(t,4,torch.float32),
        'comb':(t,16,torch.float32),
        'mixed':(t,4096,torch.bfloat16),'mixed_tail':(8,4096,torch.bfloat16),
        'normalized':(t,4096,torch.bfloat16),
        'accum':(t+63,512,torch.float32),'output':(t,512,torch.bfloat16),
        'idx_accum':(p16,64,torch.float32),'idx_raw':(t,64,torch.bfloat16),
        'idx_scaled':(t,64,torch.bfloat16),'idx_output':(t,64,torch.float16),
    }
    buffers={name:guarded(*spec) for name,spec in specs.items()}
    ffts=torch.zeros(256,dtype=torch.int64,device='npu:0')
    # Four exact permitted aliases; all other root objects have separate storage.
    values=dict(buffers, x=x, hc_fn=layer.hc_attn_fn, hc_scale=layer.hc_attn_scale,
                hc_base=layer.hc_attn_base, gamma=gamma,weight=weight,order=order,ffts=ffts,idx_weight=idx_weight,idx_order=idx_order)
    aliases={'square_read':'square','linear_read':'linear','accum_read':'accum','idx_accum_read':'idx_accum'}
    for target,source in aliases.items(): values[target]=values[source]
    names=['x','hc_fn','hc_scale','hc_base','gamma','weight','order','wide','square','square_read','vec_ws',
           'packed_weight','packed_flat','linear','linear_read','post','comb',
           'mixed','mixed_tail','normalized','accum','accum_read','output','ffts','idx_weight','idx_order','idx_accum','idx_accum_read','idx_raw','idx_scaled','idx_output']
    names=[n for n in names if n!='hc_fn']
    assert len(names)==30 and set(names)==set(values)-{'hc_fn'}
    observed=dict(buffers,rstd=buffers['vec_ws'][:t,48:56])
    report['packed_vector_workspace']={'shape':[p16+8,64],'raw_columns':[0,32],'pre_columns':[32,40],'inverse_octet_anchor_stride':8,'inverse_columns':[40,48],'rstd_columns':[48,56],'tail_rows':[p16,p16+8]}
    arguments=[values[n] for n in names]
    assert p16==(t+15)//16*16 and buffers['square'].shape==(22*p16,16)
    assert buffers['linear'].shape==(22*p16,32) and buffers['packed_flat'].shape==(p16,32768)
    assert buffers['accum'].shape[0]>=(t+63)//64*64
    for alias,source in aliases.items(): assert values[alias] is values[source]
    unique=[v for n,v in values.items() if n not in aliases]
    assert len({v.untyped_storage().data_ptr() for v in unique})==len(unique)
    fixed={name:values[name].clone() for name in ('hc_fn','hc_scale','hc_base','gamma','weight','order','idx_weight','idx_order')}
    def check_guards():
        for storage,front in allocations:
            assert bool((storage[:front]==37).all() and (storage[-front:]==37).all()), 'guard overwritten'
    def reference(label,data):
        x.copy_(data)
        cm=torch.empty_like(buffers['mixed']);cp=torch.empty_like(buffers['post']);cc=torch.empty_like(buffers['comb'])
        hc_op(x,layer.hc_attn_fn,layer.hc_attn_scale,layer.hc_attn_base,cm,cp,cc)
        nm,np,nc=layer.hc_pre(x,layer.hc_attn_fn,layer.hc_attn_scale,layer.hc_attn_base)
        np,nc=np.reshape(t,4),nc.reshape(t,16)
        torch.npu.synchronize()
        for name,a,b in [('mixed',cm,nm),('post',cp,np),('comb',cc,nc)]:
            require_exact(label+'/control-hc-vs-native/'+name,a,b)
        cn=torch.empty_like(buffers['normalized']);cr=torch.empty_like(observed['rstd'])
        norm_op(cm,gamma,cn,cr)
        co=torch.empty_like(buffers['output']);wkv_op(cn,weight,order,co)
        nn=layer.input_layernorm(nm);no=layer.self_attn.wkv(nn)
        if isinstance(no,tuple):no=no[0]
        torch.npu.synchronize()
        require_exact(label+'/control-norm-vs-native',cn,nn)
        require_exact(label+'/control-wkv-vs-native',co,no)
        ir=torch.empty_like(buffers['idx_raw']);isc=torch.empty_like(buffers['idx_scaled']);io=torch.empty_like(buffers['idx_output'])
        indexer_op(cn,idx_weight,idx_order,ir,isc,io)
        nr=projection(nn)
        assert isinstance(nr,torch.Tensor) and nr.dtype==torch.bfloat16
        ns=nr*(impl.indexer_softmax_scale*impl.indexer_heads**-0.5)
        ni=DeviceOperator.prepare_dsa_indexer_weights(ns)
        assert ni.dtype==torch.float16
        ni=ni.reshape(t,64)
        torch.npu.synchronize()
        for name,a,b in [('raw',ir,nr),('scaled',isc,ns),('output',io,ni)]:
            require_exact(label+'/control-indexer-vs-native/'+name,a,b)
        return {'idx_raw':nr.clone(),'idx_scaled':ns.clone(),'idx_output':ni.clone(),
                'mixed':nm.clone(),'post':np.clone(),'comb':nc.clone(),
                'normalized':nn.clone(),'rstd':cr.clone(),'output':no.clone()}
    # Keep independent same-sized allocations and raw graphs for both arms.
    next_buffers={name:guarded(*spec) for name,spec in specs.items()}
    next_values=dict(values,**next_buffers)
    next_values['ffts']=torch.zeros_like(ffts)
    for alias,source in aliases.items():next_values[alias]=next_values[source]
    prepared_names=[n for n in names if n!='hc_fn']
    prepared_arguments=[next_values[n] for n in prepared_names]
    assert len(prepared_names)==30
    report['scope']='real C4 weights, synthetic HC input; FP32-layout vs BF16-layout identical-SPMD prefix direct ACLGraph, not full CSA or vLLM FULL'
    prepacker(layer.hc_attn_fn,buffers['packed_weight'])
    prepacker(layer.hc_attn_fn,next_buffers['packed_weight']);torch.npu.synchronize()
    packed_snapshot=next_buffers['packed_weight'].clone()
    gold=reference('initial',x_a)
    candidate(*arguments);torch.npu.synchronize()
    require_exact('both-load-time-full-2MiB-pack-equal',next_buffers['packed_weight'],buffers['packed_weight'])
    prepared(*prepared_arguments);torch.npu.synchronize()
    control_graph,prepared_graph=torch.npu.NPUGraph(),torch.npu.NPUGraph()
    with torch.npu.graph(control_graph):candidate(*arguments)
    with torch.npu.graph(prepared_graph):prepared(*prepared_arguments)
    torch.npu.synchronize()
    observed_new=dict(next_buffers,rstd=next_buffers['vec_ws'][:t,48:56])
    rows={'control':(control_graph,buffers,observed), 'prepared':(prepared_graph,next_buffers,observed_new)}
    for label,data in [('A',x_a),('B',x_b),('A-restored',x_a)]:
        gold=reference(label,data)
        for repeat in range(3):
            for arm,(graph,scratch,outputs) in rows.items():
                for name,value in scratch.items():
                    if name=='packed_weight':continue
                    value.fill_(float('nan'))
                graph.replay();torch.npu.synchronize()
                for name,expected in gold.items():require_exact(f'{label}/{repeat}/{arm}/'+name,outputs[name],expected)
                require_exact(f'{label}/{repeat}/{arm}/input',x,data)
                require_exact(f'{label}/{repeat}/{arm}/immutable-pack',next_buffers['packed_weight'],packed_snapshot)
                check_guards()
            require_exact(f'{label}/{repeat}/full-pack-equality',next_buffers['packed_weight'],buffers['packed_weight'])
            require_exact(f'{label}/{repeat}/full-input-layout-equality',next_buffers['packed_flat'],buffers['packed_flat'])
    samples={arm:[] for arm in rows}
    for graph,_,_ in rows.values():
        for _ in range(5):graph.replay()
    torch.npu.synchronize()
    for window in range(12):
        order=list(rows) if window%2==0 else list(reversed(rows))
        for arm in order:
            graph,scratch,outputs=rows[arm]
            begin,end=torch.npu.Event(enable_timing=True),torch.npu.Event(enable_timing=True)
            begin.record()
            for _ in range(25):graph.replay()
            end.record();end.synchronize();samples[arm].append(begin.elapsed_time(end)*1000/25)
            for name,expected in gold.items():require_exact(f'timing/{window}/{arm}/'+name,outputs[name],expected)
            require_exact(f'timing/{window}/{arm}/immutable-pack',next_buffers['packed_weight'],packed_snapshot)
            require_exact(f'timing/{window}/{arm}/control-immutable-pack',buffers['packed_weight'],packed_snapshot)
            check_guards()
        require_exact(f'timing/{window}/full-input-layout-equality',next_buffers['packed_flat'],buffers['packed_flat'])
    for name,expected in fixed.items():require_exact('readonly/'+name,values[name],expected)
    require_exact('readonly/prepared-input',x,x_a)
    medians={arm:statistics.median(v) for arm,v in samples.items()}
    reductions=[(1-b/a)*100 for a,b in zip(samples['control'],samples['prepared'])]
    report['graph_replay_us']={'samples':samples,'medians':medians,'paired_reduction_percent':reductions,
        'median_reduction_percent':(1-medians['prepared']/medians['control'])*100,
        'all_paired_windows_faster':all(v>0 for v in reductions),'outliers_removed':False,'workspace_lifetime_same':True}
    report['fixed_pack_bytes']=next_buffers['packed_weight'].numel()*next_buffers['packed_weight'].element_size()
    report.update(complete=True,**{'pass':True});save()
    print('PREPACK_PREFIX_AB_PASS',json.dumps(report['graph_replay_us']),flush=True)
