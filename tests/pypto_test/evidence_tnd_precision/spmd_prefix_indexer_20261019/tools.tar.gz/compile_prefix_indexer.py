"""No-device compilation of the separate precision-SPMD slice."""

import hashlib
import json
import os
import sys
from pathlib import Path

import pypto
import simpler
from pypto.runtime import RunConfig

import vllm_ascend.ops.pypto as namespace

experiment = Path(os.environ["SPMD_EXPERIMENT"])
source = experiment / "src/vllm_ascend/ops/pypto"
namespace.__path__.insert(0, str(source))

sys.path.insert(0, str(experiment))
from prefix_indexer_root_draft import precision_hc_prefix_indexer as precision_hc_prefix

assert "low-acceptance-20261010/runtime-package/pypto" in pypto.__file__
assert "pypto-reference/runtime/python/simpler" in simpler.__file__
assert os.environ["ASCEND_RT_VISIBLE_DEVICES"] == ""
assert os.environ.get("PTOAS_ROOT") and os.environ.get("ASCEND_HOME_PATH")
package = source / "deepseek_v4_flash_csa_tnd_precision_spmd"
record = {
    "scope": "HC-pre/Norm/WKV/Indexer-weight prefix draft only; no hardware or complete CSA qualification",
    "hardware_executed": False,
    "pypto": pypto.__file__,
    "simpler": simpler.__file__,
    "sources": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in package.glob("*.py")},
}
record["draft_sources"] = {name:hashlib.sha256((experiment/name).read_bytes()).hexdigest()
                           for name in ("prefix_indexer_root_draft.py", "indexer_projection_stages_draft.py")}
print(json.dumps(record), flush=True)
compiled = precision_hc_prefix.compile(
    config=RunConfig(platform="a2a3", dump_passes=True, save_kernels=True, save_kernels_dir=str(experiment / "hc-prefix-indexer-v1-artifact"))
)
# Exercise the exact kernel-mode ABI gate used by torch.register as well.
# This is a diagnostic call into the installed SDK, not a framework change.
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program

program = precision_hc_prefix.specialize()
abi = kernel_abi_for_program(program, platform="a2a3", runtime="tensormap_and_ringbuffer")
_kernel = _compile_impl(program, output_dir=str(experiment / "hc-prefix-indexer-v1-kernel-artifact"),
                        platform="a2a3", dump_passes=True, _kernel_abi=abi)
record["kernel_mode_abi_pass"] = True
record["kernel_artifact_dir"] = str(experiment / "hc-prefix-indexer-v1-kernel-artifact")
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.hc_pre import hc_pre_test
control = hc_pre_test.specialize()
control_abi = kernel_abi_for_program(control, platform="a2a3", runtime="tensormap_and_ringbuffer")
_compile_impl(control, output_dir=str(experiment / "hc-control-kernel-artifact"),
              platform="a2a3", dump_passes=True, _kernel_abi=control_abi)
record["control_hc_kernel_mode_abi_pass"] = True
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_projection import indexer_projection
indexer_program=indexer_projection.specialize()
indexer_abi=kernel_abi_for_program(indexer_program,platform="a2a3",runtime="tensormap_and_ringbuffer")
_compile_impl(indexer_program,output_dir=str(experiment/"indexer-control-kernel-artifact"),platform="a2a3",dump_passes=True,_kernel_abi=indexer_abi)
record["control_indexer_kernel_mode_abi_pass"] = True

control_package = Path(os.environ["SOURCE_ROOT"]) / "vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision"
record["control_sources"] = {n:hashlib.sha256((control_package/n).read_bytes()).hexdigest()
                             for n in ("hc_pre.py","hc_pre_contract.py","input_norm.py","wkv.py","wkv_order_data.py","indexer_projection.py","indexer_order_data.py")}
record.update(
    compiled=True,
    output_dir=str(compiled.output_dir),
    runtime=compiled.runtime_name,
    generated={
        str(p.relative_to(compiled.output_dir)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in Path(compiled.output_dir).rglob("*")
        if p.is_file() and p.suffix in (".cpp", ".py", ".json")
    },
)
(experiment / "compile-prefix-indexer.json").write_text(json.dumps(record, indent=2) + "\n")
print("PRECISION_SPMD_PREFIX_COMPILED", record["output_dir"], flush=True)
