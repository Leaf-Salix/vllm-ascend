"""Coalesce six AIV-only FP32 workspaces; keep floating-point AST unchanged."""
import ast
import copy
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]/'vllm-ascend-nalinaly-tnd-20261008-codex'
PACKAGE=REPO/'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision_spmd'
# Tail rows are excluded from the original P16 split stride.
ARENA={'inv_rms':(0,40),'mixes_raw':(0,0),'pre_val_store':(0,32),'rstd':(0,48),
       'post_tail_store':('P16',0),'comb_tail_store':('P16',8)}
ROOT_NAMES={'inverse','raw','pre','rstd','post_tail','comb_tail'}


def expr(s): return ast.parse(s,mode='eval').body

def bump(n,offset):
    if offset==0:return n
    add=expr('pl.tensor.dim(vec_ws, 0) - 8') if offset=='P16' else ast.Constant(offset)
    return ast.BinOp(left=n,op=ast.Add(),right=add)

def dedup(names):
    result=[]
    for n in names:
        if isinstance(n,ast.Name) and n.id=='vec_ws' and any(isinstance(v,ast.Name) and v.id=='vec_ws' for v in result):continue
        result.append(n)
    return result


class Readdress(ast.NodeTransformer):
    def __init__(self,mapping):self.mapping=mapping
    def visit_Subscript(self,node):
        if isinstance(node.value,ast.Name) and node.value.id in self.mapping:
            rowoff,coloff=self.mapping[node.value.id]
            assert isinstance(node.slice,ast.Tuple) and len(node.slice.elts)==2
            for i,offset in enumerate((rowoff,coloff)):
                sub=node.slice.elts[i]
                if isinstance(sub,ast.Slice):
                    assert sub.lower is not None and sub.upper is not None
                    sub.lower=bump(sub.lower,offset);sub.upper=bump(sub.upper,offset)
                else:node.slice.elts[i]=bump(sub,offset)
            node.value.id='vec_ws'
            return node
        return self.generic_visit(node)
    def visit_Call(self,node):
        name=ast.unparse(node.func)
        if name=='pl.tensor.dim' and isinstance(node.args[0],ast.Name) and node.args[0].id in self.mapping:
            assert ast.literal_eval(node.args[1])==0
            return expr('pl.tensor.dim(vec_ws,0)-8')
        if name in ('pl.load','pl.read') and isinstance(node.args[0],ast.Name) and node.args[0].id in self.mapping:
            row,col=self.mapping[node.args[0].id]
            node.args[0].id='vec_ws';assert isinstance(node.args[1],ast.List)
            node.args[1].elts=[bump(n,v) for n,v in zip(node.args[1].elts,(row,col))]
            return node
        if name=='pl.store' and isinstance(node.args[2],ast.Name) and node.args[2].id in self.mapping:
            row,col=self.mapping[node.args[2].id]
            node.args[2].id='vec_ws';assert isinstance(node.args[1],ast.List)
            node.args[1].elts=[bump(n,v) for n,v in zip(node.args[1].elts,(row,col))]
            return self.generic_visit(node)
        return self.generic_visit(node)
    def visit_Name(self,node):
        if node.id in self.mapping:node.id='vec_ws'
        return node

stages=[]
for path,names in [('hc_prefix_stages.py',['hc_rms','hc_linear_reduce','hc_pre_post','hc_comb','hc_mix']),
                   ('norm_wkv_stages.py',['norm_rows'])]:
    tree=ast.parse((PACKAGE/path).read_text())
    for f in [n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]:
        f=copy.deepcopy(f);mapping={a.arg:ARENA[a.arg] for a in f.args.args if a.arg in ARENA}
        before=copy.deepcopy(f)
        mut=any('pl.InOut' in ast.unparse(a.annotation) or 'pl.Out' in ast.unparse(a.annotation) for a in f.args.args if a.arg in mapping)
        seen=False;args=[]
        for a in f.args.args:
            if a.arg in mapping:
                if seen:continue
                a.arg='vec_ws';a.annotation=expr(('pl.InOut[' if mut else '')+'pl.Tensor[[VEC_ROWS,64],pl.FP32]'+(']' if mut else ''));seen=True
            args.append(a)
        f.args.args=args
        f.body=[Readdress(mapping).visit(n) for n in f.body]
        for n in ast.walk(f):
            if isinstance(n,ast.Return) and isinstance(n.value,ast.Tuple):n.value.elts=dedup(n.value.elts)
        # Keep inverse values contiguous in GM: one [1,8] row per token octet.
        # A strided [8,1] ND GM load cannot feed the original ColMajor Vec tile.
        for n in ast.walk(f):
            if f.name=='hc_rms' and isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Subscript) and isinstance(n.targets[0].value,ast.Name) and n.targets[0].value.id=='vec_ws':
                n.targets[0]=expr('vec_ws[rms_t0:rms_t0+1,40:48]');n.targets[0].ctx=ast.Store()
                n.value=expr('native_inverse')
            if f.name=='hc_pre_post' and isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='inv_col':
                n.value=expr('pl.reshape(pl.load(vec_ws,[t0,40],[1,T_TILE],target_memory=pl.MemorySpace.Vec),[T_TILE,1])')
            if f.name=='hc_comb' and isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='inv_col_t':
                n.value=expr('pl.set_validshape(pl.reshape(pl.load(vec_ws,[t0,40],[1,COMB_T_TILE],target_memory=pl.MemorySpace.Vec),[COMB_T_TILE,1]),valid_rows,1)')
        if f.name=='hc_pre_post':
            for n in ast.walk(f):
                if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name):
                    target=n.targets[0].id
                    if target=='pre_base':n.value=expr('pl.reshape(pl.load(hc_base,[0],[HC_PAD],target_memory=pl.MemorySpace.Vec),[1,HC_PAD])')
                    if target=='post_base':n.value=expr('pl.reshape(pl.load(hc_base,[HC_MULT],[HC_PAD],target_memory=pl.MemorySpace.Vec),[1,HC_PAD])')
                    if target in ('pre_scaled','post_scaled'):
                        for operand in ast.walk(n.value):
                            if isinstance(operand,ast.Call) and ast.unparse(operand.func)=='pl.row_expand_mul':
                                operand.args[0]=expr('pl.load(vec_ws,[t0,0],[T_TILE,HC_PAD],target_memory=pl.MemorySpace.Vec)' if target=='pre_scaled' else 'pl.load(vec_ws,[t0,HC_MULT],[T_TILE,HC_PAD],target_memory=pl.MemorySpace.Vec)')
        if f.name=='hc_pre_post':
            for n in ast.walk(f):
                if isinstance(n,ast.Call) and ast.unparse(n.func)=='pl.full':n.func=expr('pl.tile.full')
        if f.name=='hc_pre_post':
            def tile_stores(nodes):
                result=[]
                for n in nodes:
                    if isinstance(n,ast.If):n.body=tile_stores(n.body);n.orelse=tile_stores(n.orelse)
                    if isinstance(n,ast.For):n.body=tile_stores(n.body)
                    if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Subscript):
                        dst=n.targets[0]
                        assert isinstance(dst.slice,ast.Tuple)
                        start=[x.lower for x in dst.slice.elts]
                        call=ast.Call(func=expr('pl.store'),args=[n.value,ast.List(elts=start,ctx=ast.Load()),ast.Name(id=dst.value.id,ctx=ast.Load())],keywords=[])
                        n=ast.Expr(value=call)
                    result.append(n)
                return result
            f.body=tile_stores(f.body)
        if f.name=='hc_comb':
            f.body[-1].value.elts.reverse()
        f.name='packed_'+f.name
        stages.append(f)
header=ast.parse('''import pypto.language as pl
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.hc_prefix_stages import *
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.norm_wkv_stages import FRACTION_UNIT,SQRT_COMPARE_SHIFT,SQRT_CORRECTION_STEPS,FP32_INFINITY_BITS
VEC_ROWS=pl.dynamic("PRECISION_SPMD_VEC_ROWS")
''')
header.body.extend(stages)
(HERE/'packed_prefix_stages_draft.py').write_text(ast.unparse(ast.fix_missing_locations(header))+'\n')
root=ast.parse((HERE/'prefix_indexer_root_draft.py').read_text())
root.body.insert(0,ast.ImportFrom(module='packed_prefix_stages_draft',names=[ast.alias(n.name) for n in stages]+[ast.alias('VEC_ROWS')],level=0))
helpers={f.name.removeprefix('packed_') for f in stages}
rootfunctions={f.name for f in root.body if isinstance(f,ast.FunctionDef)}
for f in [n for n in root.body if isinstance(n,ast.FunctionDef)]:
    seen=False;args=[]
    for a in f.args.args:
        if a.arg in ROOT_NAMES:
            if seen:continue
            a.arg='vec_ws';a.annotation=expr('pl.InOut[pl.Tensor[[VEC_ROWS,64],pl.FP32]]');seen=True
        args.append(a)
    f.args.args=args
    newbody=[]
    for n in f.body:
        # Only the public root binds workspace shape; do not bind it repeatedly to T/P16.
        if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and n.value.func.attr=='bind_dynamic' and isinstance(n.value.func.value,ast.Name) and n.value.func.value.id in ROOT_NAMES:continue
        for x in ast.walk(n):
            if isinstance(x,ast.Name) and x.id in ROOT_NAMES:x.id='vec_ws'
        newbody.append(n)
    f.body=newbody
    for n in ast.walk(f):
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in helpers|rootfunctions:
            n.args=dedup(n.args)
            if n.func.id in helpers:n.func.id='packed_'+n.func.id
            elif n.func.id in rootfunctions:n.func.id='packed_'+n.func.id
        if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Tuple):
            n.targets[0].elts=dedup(n.targets[0].elts)
            if isinstance(n.value,ast.Call) and ast.unparse(n.value.func) in ('hc_comb','packed_hc_comb'):n.targets[0].elts.reverse()
        if isinstance(n,ast.Return) and isinstance(n.value,ast.Tuple):n.value.elts=dedup(n.value.elts)
    if f.name=='precision_hc_prefix_indexer':f.body.insert(0,ast.parse('vec_ws.bind_dynamic(0,VEC_ROWS)').body[0])
    f.name='packed_'+f.name
(HERE/'packed_prefix_indexer_root_draft.py').write_text(ast.unparse(ast.fix_missing_locations(root))+'\n')
print(json.dumps({'root_args':len(next(n for n in root.body if isinstance(n,ast.FunctionDef) and n.name=='packed_precision_hc_prefix_indexer').args.args),'packed_stages':len(stages),'layout':ARENA}))
