import os
from pathlib import Path
import pypto.language as pl
import vllm_ascend.ops.pypto as namespace
exp=Path(os.environ['SPMD_EXPERIMENT'])
namespace.__path__.insert(0,str(exp/'src/vllm_ascend/ops/pypto'))
from packed_prefix_stages_draft import packed_hc_mix,VEC_ROWS
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.norm_wkv_stages import T

@pl.jit
def isolate_mix(wide:pl.Tensor[[T,16384],pl.FP32], vec_ws:pl.Tensor[[VEC_ROWS,64],pl.FP32], mixed:pl.InOut[pl.Tensor[[T,4096],pl.BF16]], tail:pl.InOut[pl.Tensor[[8,4096],pl.BF16]]):
    wide.bind_dynamic(0,T)
    mixed.bind_dynamic(0,T)
    vec_ws.bind_dynamic(0,VEC_ROWS)
    for worker in pl.spmd(48):
        mixed,tail=packed_hc_mix(wide,vec_ws,mixed,tail,worker)
    return mixed,tail

print(isolate_mix.specialize())
print('ISOLATE_MIX_FRONTEND_PASS',flush=True)
