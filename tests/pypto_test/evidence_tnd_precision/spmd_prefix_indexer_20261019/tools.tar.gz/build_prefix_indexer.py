"""Extract unchanged Indexer projection bodies into the existing SPMD prefix."""
import ast
import copy
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]/'vllm-ascend-nalinaly-tnd-20261008-codex'
PACKAGE=REPO/'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision_spmd'
OLD=REPO/'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision/indexer_projection.py'
old=next(n for n in ast.parse(OLD.read_text()).body if isinstance(n,ast.FunctionDef))
loops=[n for n in old.body if isinstance(n,ast.For)]
header='''import pypto.language as pl
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.norm_wkv_stages import T
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.hc_prefix_stages import P16

@pl.jit.inline(auto_scope=False)
def indexer_projection_matmul(x:pl.Tensor[[T,4096],pl.BF16], weight:pl.Tensor[[64,4096],pl.BF16], order:pl.Tensor[[16,4,16],pl.INT32], accum:pl.InOut[pl.Tensor[[P16,64],pl.FP32]], physical_worker:pl.Scalar[pl.INDEX]):
    rows=pl.tensor.dim(x,0)
    row_tiles=(rows+15)//16
    return accum

@pl.jit.inline(auto_scope=False)
def indexer_projection_round(accum:pl.Tensor[[P16,64],pl.FP32], raw:pl.InOut[pl.Tensor[[T,64],pl.BF16]], scaled:pl.InOut[pl.Tensor[[T,64],pl.BF16]], output:pl.InOut[pl.Tensor[[T,64],pl.FP16]], physical_worker:pl.Scalar[pl.INDEX]):
    rows=pl.tensor.dim(output,0)
    row_tiles=(rows+15)//16
    return raw,scaled,output
'''
stages=ast.parse(header)
for f,loop,workers in zip([n for n in stages.body if isinstance(n,ast.FunctionDef)],loops,(24,48)):
    n=copy.deepcopy(loop)
    units=n.iter.args[0]
    n.iter=ast.Call(func=ast.Attribute(value=ast.Name(id='pl',ctx=ast.Load()),attr='range',ctx=ast.Load()),args=[ast.Name(id='physical_worker',ctx=ast.Load()),units,ast.Constant(workers)],keywords=[])
    f.body.insert(-1,n)
(HERE/'indexer_projection_stages_draft.py').write_text(ast.unparse(ast.fix_missing_locations(stages))+'\n')
root=ast.parse((PACKAGE/'hc_prefix.py').read_text())
root.body=[n for n in root.body if not isinstance(n,ast.Expr)]
root.body.insert(0,ast.ImportFrom(module='indexer_projection_stages_draft',names=[ast.alias('indexer_projection_matmul'),ast.alias('indexer_projection_round')],level=0))
for n in root.body:
    if isinstance(n,ast.ImportFrom) and n.level==1:
        n.level=0;n.module='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.'+n.module
args={
 'idx_weight':'pl.Tensor[[64,4096],pl.BF16]',
 'idx_order':'pl.Tensor[[16,4,16],pl.INT32]',
 'idx_accum':'pl.InOut[pl.Tensor[[P16,64],pl.FP32]]',
 'idx_accum_read':'pl.Tensor[[P16,64],pl.FP32]',
 'idx_raw':'pl.InOut[pl.Tensor[[T,64],pl.BF16]]',
 'idx_scaled':'pl.InOut[pl.Tensor[[T,64],pl.BF16]]',
 'idx_output':'pl.InOut[pl.Tensor[[T,64],pl.FP16]]',
}
extra={ 'prefix_cube':['idx_weight','idx_order','idx_accum'], 'prefix_vector':['idx_accum_read','idx_raw','idx_scaled','idx_output'], 'prefix_group':list(args), 'precision_hc_prefix':list(args) }
returns={ 'prefix_cube':['idx_accum'], 'prefix_vector':['idx_raw','idx_scaled','idx_output'], 'prefix_group':['idx_raw','idx_scaled','idx_output'], 'precision_hc_prefix':['idx_raw','idx_scaled','idx_output'] }
rename={name:name.replace('prefix','prefix_indexer') for name in extra}
for f in [n for n in root.body if isinstance(n,ast.FunctionDef)]:
    name=f.name
    f.args.args.extend(ast.arg(arg=a,annotation=ast.parse(args[a],mode='eval').body) for a in extra[name])
    if name=='prefix_cube':
        pos=next(i for i,n in enumerate(f.body) if isinstance(n,ast.Assign) and isinstance(n.value,ast.Call) and ast.unparse(n.value.func)=='wkv_matmul')
        f.body.insert(pos+1,ast.parse('idx_accum=indexer_projection_matmul(normalized,idx_weight,idx_order,idx_accum,worker)').body[0])
    elif name=='prefix_vector':
        pos=next(i for i,n in enumerate(f.body) if isinstance(n,ast.Assign) and isinstance(n.value,ast.Call) and ast.unparse(n.value.func)=='wkv_round')
        f.body.insert(pos+1,ast.parse('idx_raw,idx_scaled,idx_output=indexer_projection_round(idx_accum_read,idx_raw,idx_scaled,idx_output,worker)').body[0])
    elif name=='precision_hc_prefix':
        for a,dim in [('idx_accum','P16'),('idx_accum_read','P16'),('idx_raw','T'),('idx_scaled','T'),('idx_output','T')]:
            f.body.insert(0,ast.parse(f'{a}.bind_dynamic(0,{dim})').body[0])
    for n in ast.walk(f):
        if isinstance(n,ast.Assign) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id in extra:
            target=n.value.func.id
            n.value.args.extend(ast.Name(id=a,ctx=ast.Load()) for a in extra[target])
            assert isinstance(n.targets[0],ast.Tuple)
            n.targets[0].elts.extend(ast.Name(id=a,ctx=ast.Store()) for a in returns[target])
            n.value.func.id=rename[target]
    final=f.body[-1];assert isinstance(final,ast.Return) and isinstance(final.value,ast.Tuple)
    final.value.elts.extend(ast.Name(id=a,ctx=ast.Load()) for a in returns[name])
    f.name=rename[name]
(HERE/'prefix_indexer_root_draft.py').write_text(ast.unparse(ast.fix_missing_locations(root))+'\n')
print(json.dumps({'entry_args':len(next(n for n in root.body if isinstance(n,ast.FunctionDef) and n.name=='precision_hc_prefix_indexer').args.args),'old_functions':len(extra),'new_stages':2}))
