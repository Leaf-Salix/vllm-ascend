from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'compile_prefix.py').read_text().replace('from prefix_root_draft import precision_hc_prefix','from prefix_indexer_root_draft import precision_hc_prefix_indexer as precision_hc_prefix').replace('prefix_root_draft.py','prefix_indexer_root_draft.py').replace('prefix_stages_draft.py','indexer_projection_stages_draft.py').replace('hc-prefix-v5-clean','hc-prefix-indexer-v1').replace('compile-prefix.json','compile-prefix-indexer.json')
s=s.replace('"wkv_order_data.py")','"wkv_order_data.py","indexer_projection.py","indexer_order_data.py")')
marker='record["control_hc_kernel_mode_abi_pass"] = True'
s=s.replace(marker,marker+'''
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_projection import indexer_projection
indexer_program=indexer_projection.specialize()
indexer_abi=kernel_abi_for_program(indexer_program,platform="a2a3",runtime="tensormap_and_ringbuffer")
_compile_impl(indexer_program,output_dir=str(experiment/"indexer-control-kernel-artifact"),platform="a2a3",dump_passes=True,_kernel_abi=indexer_abi)
record["control_indexer_kernel_mode_abi_pass"] = True
''')
(p/'compile_prefix_indexer.py').write_text(s)
s=(p/'probe_prefix.py').read_text().replace('from prefix_root_draft import precision_hc_prefix','from prefix_indexer_root_draft import precision_hc_prefix_indexer as precision_hc_prefix').replace('prefix_root_draft.py','prefix_indexer_root_draft.py').replace('prefix_stages_draft.py','indexer_projection_stages_draft.py').replace('compile-prefix.json','compile-prefix-indexer.json')
s=s.replace("'wkv_order_data.py')", "'wkv_order_data.py','indexer_projection.py','indexer_order_data.py')")
s=s.replace("assert compiled_receipt['kernel_mode_abi_pass'] and compiled_receipt['control_hc_kernel_mode_abi_pass']", "assert compiled_receipt['kernel_mode_abi_pass'] and compiled_receipt['control_hc_kernel_mode_abi_pass'] and compiled_receipt['control_indexer_kernel_mode_abi_pass']")
s=s.replace('parser = argparse.ArgumentParser()', '''from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_projection import indexer_projection
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.indexer_order_data import INDEXER_K_ORDERS,INDEXER_TILE_ORDERS,INDEXER_TOKEN_MODES
from vllm_ascend.device.device_op import DeviceOperator

parser = argparse.ArgumentParser()''')
s=s.replace("    t = args.tokens", "    indexer_op=pypto.torch.register(indexer_projection,'precision_spmd_prefix_control::indexer_projection')\n    t = args.tokens")
marker="    torch.manual_seed(1024)"
s=s.replace(marker,'''    impl=layer.self_attn.dsa_attn.dsa_attn.impl
    projection=impl.weights_proj
    assert projection.bias is None and projection.weight.dtype==torch.bfloat16
    assert tuple(projection.weight.shape)==(64,4096) and not projection.return_bias
    idx_weight=projection.weight.detach()
    if torch_npu.get_npu_format(idx_weight) not in (0,2): idx_weight=torch_npu.npu_format_cast(idx_weight,2)
    idx_weight=idx_weight.contiguous()
    require_exact('indexer-weight-layout-values',idx_weight,projection.weight.detach())
    idx_order=torch.tensor([[INDEXER_K_ORDERS[i] for i in row] for row in INDEXER_TILE_ORDERS[INDEXER_TOKEN_MODES[t-1]]],dtype=torch.int32,device='npu:0')
    assert impl.indexer_softmax_scale*impl.indexer_heads**-0.5==0.011048543456039806
'''+marker)
s=s.replace("        'accum':(t+63,512,torch.float32),'output':(t,512,torch.bfloat16),", "        'accum':(t+63,512,torch.float32),'output':(t,512,torch.bfloat16),\n        'idx_accum':(p16,64,torch.float32),'idx_raw':(t,64,torch.bfloat16),\n        'idx_scaled':(t,64,torch.bfloat16),'idx_output':(t,64,torch.float16),")
s=s.replace('gamma=gamma,weight=weight,order=order,ffts=ffts)', 'gamma=gamma,weight=weight,order=order,ffts=ffts,idx_weight=idx_weight,idx_order=idx_order)')
s=s.replace("'accum_read':'accum'}", "'accum_read':'accum','idx_accum_read':'idx_accum'}")
s=s.replace("'output','ffts']", "'output','ffts','idx_weight','idx_order','idx_accum','idx_accum_read','idx_raw','idx_scaled','idx_output']")
s=s.replace('len(names)==29','len(names)==36').replace("('hc_fn','hc_scale','hc_base','gamma','weight','order')", "('hc_fn','hc_scale','hc_base','gamma','weight','order','idx_weight','idx_order')")
marker="        return {'mixed':nm.clone(),'post':np.clone(),'comb':nc.clone(),"
s=s.replace(marker,'''        ir=torch.empty_like(buffers['idx_raw']);isc=torch.empty_like(buffers['idx_scaled']);io=torch.empty_like(buffers['idx_output'])
        indexer_op(cn,idx_weight,idx_order,ir,isc,io)
        nr=projection(nn)
        assert isinstance(nr,torch.Tensor) and nr.dtype==torch.bfloat16
        ns=nr*(impl.indexer_softmax_scale*impl.indexer_heads**-0.5)
        ni=DeviceOperator.prepare_dsa_indexer_weights(ns)
        assert ni.dtype==torch.float16
        ni=ni.reshape(t,64)
        torch.npu.synchronize()
        for name,a,b in [('raw',ir,nr),('scaled',isc,ns),('output',io,ni)]:
            require_exact(label+'/control-indexer-vs-native/'+name,a,b)
        return {'idx_raw':nr.clone(),'idx_scaled':ns.clone(),'idx_output':ni.clone(),
                'mixed':nm.clone(),'post':np.clone(),'comb':nc.clone(),''')
s=s.replace('HC-pre/Norm/WKV prefix; direct ACLGraph','HC-pre/Norm/WKV/Indexer-weight prefix; direct ACLGraph')
s=s.replace('Three exact permitted aliases','Four exact permitted aliases')
(p/'probe_prefix_indexer.py').write_text(s)
(p/'compile-prefix-indexer.sh').write_text((p/'compile-prefix.sh').read_text().replace('compile_prefix.py','compile_prefix_indexer.py'))
(p/'run-prefix-indexer.sh').write_text((p/'run-prefix.sh').read_text().replace('probe_prefix.py','probe_prefix_indexer.py'))
