# 单SPMD前缀继续纳入Indexer权重投影

当前正式分支仍为dev/pypto-dsv4-csa-nalinaly-tnd-20261008-codex，ab8c81c10已推送。
正式精度43源、首SPMD切片四源、已验收前缀两源未改。本阶段新增两源已迁入正式SPMD包；T1/T240直接绑定正式八源，T21草稿与正式实现函数AST一致。

## 数学与边界

Indexer保持原16次K256的标定顺序、FP32累加、BF16 raw发布、0.011048543456039806乘法、
BF16 scaled发布、FP16输出。Cube在H8后执行WKV及Indexer matmul，AIV在H9后两路round，H10出口。
完整前缀依旧单24组SPMD、两角色各十handoff；不是完整CSA，也没有新增整模型token结果。

## 无设备检查历史

1. 直接追加7tensor后，MIX共享参数并集37，CCEC生成后make_callable拒绝超过32限制。没有提交硬件。
2. 按六块纯AIV FP32工作区合一方案减少5描述符，公开31参数、MIX预计32。原4个跨角色读别名保留。
3. packed v1/v2：comb合并后InOut声明序vec_ws/comb与返回/调用序不一致，inline元信息把vec_ws推成16列。
   单独mix.specialize通过。v2生成器遗漏caller更新；v3已同时修正helper及caller为vec_ws/comb。
4. v3：前端通过，CCEC指出strided ND GM的8×1 inverse不能读到ColMajor Vec。改成每8token连续1×8存储。
5. v4：inverse load已Tile，prepost raw仍Tensor；不能混合Tensor/Tile。统一对应raw/base显式Tile加载。
6. v5：div的1.0 full仍Tensor；只将两常量改为Tile FP32 1.0。
7. v6：Tile结果不能用Tensor subscript-write；改成等价pl.store的相同目的起点。
8. v7：上述修正齐备，无设备program/kernel/CCEC全部通过。独立生成物审查确认单MIX24/sync_start、两lane各32tensor/10无条件屏障、四组读alias、WKV→Indexer L0C前FIX wait、H9后Vector idx读取；inverse连续TLOAD1×8与同UB reshape8×1。T21草稿、正式T240和正式T1设备对拍均已通过。

以上均保留门禁，不修改SDK、不绕过检查，不将编译失败计作精度失败或设备通过。
失败v1/v3/v4/v5/v6源码快照分别留在failed-packed-*；v1 SHA已与日志绑定。

## Arena

FP32 vec_ws[P16+8,64]，P16=16ceil(T/16)。每行256B。

- 原raw：主区列0:32。
- pre：主区列32:40。
- inverse：每个octet的anchor行8b，列40:48，消费端恢复8×1；41:48不是另存其他字段。
- rstd：主区列48:56。观测只在host创建[:T,48:56]view，不作为另一个kernel实参。
- post tail：末8行，列0:8。
- comb tail：末8行，列8:40。

所有原P16 stride都以dim(vec_ws,0)-8恢复。独立审查确认T1至256区间、lane置换、尾有效域与32B对齐。
只作地址与类型等价变换；真正逐bit仍须Native同输入设备对拍，不能用AST代替。

## 设备结果

- T21草稿：task_20261019_231824_53995123760，151项全部逐bit一致，候选median249.019微秒。
- T240正式八源：task_20261019_232447_8471313079，151项全部逐bit一致，median390.982微秒。
- T1正式八源：task_20261019_232658_97272023097，151项全部逐bit一致，median245.019微秒。

均exit0，max780秒/内部750秒，均已结束，无本轮排队/运行任务。
此前task_20261019_231150_25725419143在候选启动前因harness遗漏一层dsa_attn包装失败；
更正观测路径后才取得上述T21结果，该失败记录不算精度失败或通过。

同输入Native对比mixed/post/comb/Norm/WKV和Indexer raw/scaled/FP16输出共八类；rstd仅对冻结control。
各组包含A/B/A各三次replay、poison、外侧guard、输入和权重只读及计时后复核。
采用真实C4权重及合成HC输入、direct ACLGraph，不是完整CSA、vLLM FULL或整模型token验收。
这里只有候选计时，不能把249与旧257微秒当受控收益。

下一门禁是单PTO完整根接入和跨根工作区复用验证，再按8K/B40、128K/B24顺序验收冻结Native token。
