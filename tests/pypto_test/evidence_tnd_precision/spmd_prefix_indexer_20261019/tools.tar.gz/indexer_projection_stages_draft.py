import pypto.language as pl
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.norm_wkv_stages import T
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.hc_prefix_stages import P16

@pl.jit.inline(auto_scope=False)
def indexer_projection_matmul(x: pl.Tensor[[T, 4096], pl.BF16], weight: pl.Tensor[[64, 4096], pl.BF16], order: pl.Tensor[[16, 4, 16], pl.INT32], accum: pl.InOut[pl.Tensor[[P16, 64], pl.FP32]], physical_worker: pl.Scalar[pl.INDEX]):
    rows = pl.tensor.dim(x, 0)
    row_tiles = (rows + 15) // 16
    for worker in pl.range(physical_worker, row_tiles * 4, 24):
        rb = worker // 4
        group = worker % 4
        row = rb * 16
        col = group * 16
        valid = pl.min(16, rows - row)
        tile = pl.create_tensor([16, 16], dtype=pl.FP32)
        for step in pl.range(16):
            k_block = pl.read(order, [rb, group, step])
            offset = pl.max(k_block, 0) * 256
            a = pl.slice(x, [16, 256], [row, offset], valid_shape=[valid, 256])
            b = weight[col:col + 16, offset:offset + 256]
            tile = pl.matmul_acc(tile, a, b, b_trans=True, init_cond=step == 0)
        accum[row:row + 16, col:col + 16] = tile
    return accum

@pl.jit.inline(auto_scope=False)
def indexer_projection_round(accum: pl.Tensor[[P16, 64], pl.FP32], raw: pl.InOut[pl.Tensor[[T, 64], pl.BF16]], scaled: pl.InOut[pl.Tensor[[T, 64], pl.BF16]], output: pl.InOut[pl.Tensor[[T, 64], pl.FP16]], physical_worker: pl.Scalar[pl.INDEX]):
    rows = pl.tensor.dim(output, 0)
    row_tiles = (rows + 15) // 16
    for block in pl.range(physical_worker, row_tiles, 48):
        row = block * 16
        valid = pl.min(16, rows - row)
        value = pl.load(accum, [row, 0], [16, 64], valid_shape=[valid, 64])
        projected = pl.cast(value, pl.BF16, mode='rint')
        pl.store(projected, [row, 0], raw)
        value = pl.cast(projected, pl.FP32)
        value = pl.mul(value, 0.011048543456039806)
        weighted = pl.cast(value, pl.BF16, mode='rint')
        pl.store(weighted, [row, 0], scaled)
        result = pl.cast(weighted, pl.FP16, mode='rint')
        pl.store(result, [row, 0], output)
    return (raw, scaled, output)
