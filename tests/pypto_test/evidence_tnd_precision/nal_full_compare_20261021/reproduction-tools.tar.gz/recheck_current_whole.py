"""只读既有整模型归档，复核保存的token、事件和计时；不导入NPU。"""
import hashlib
import json
import statistics
import sys
import tarfile
from pathlib import Path

repo = Path(sys.argv[1])
root = repo / 'tests/pypto_test/evidence_tnd_precision'
result = {'scope': 'Existing October 20 whole-model archives, CPU recheck only', 'cases': {}}
for case, batch in (('8k', 40), ('128k', 24)):
    archive = root / 'spmd_sinkhorn_overlap_20261020' / f'whole-overlap-v1-{case}-evidence.tar.gz'
    with tarfile.open(archive) as tar:
        files = [m for m in tar if m.isfile()]
        assert len({m.name for m in files}) == len(files)
        data = {m.name: tar.extractfile(m).read() for m in files}
    load = lambda name: json.loads(data[name])
    counts = {'tokens': 0, 'events': 0}
    for rank in range(16):
        candidate = load(f'candidate/rank{rank}.real_perf.json')
        gold = {r['key']: r['output_token_ids'] for r in load(f'native-gold/rank{rank}.mixed.json')['requests']}
        events = {r['key']: r['events'] for r in map(json.loads, data[f'native-gold/request_stats_rank{rank}.jsonl'].splitlines())}
        for window in [candidate['warmup'], *candidate['rounds']]:
            assert len(window['requests']) == batch
            assert {r['key'] for r in window['requests']} == set(gold) == set(events)
            for request in window['requests']:
                assert request['output_token_ids'] == gold[request['key']]
                assert request['events'] == events[request['key']]
                assert request['preemptions'] == 0
                counts['tokens'] += len(request['output_token_ids'])
                counts['events'] += len(request['events'])
    assert counts['tokens'] == 16 * batch * 192 * 4
    metrics = {}
    for arm in ('candidate', 'native-historical', 'serial-parent'):
        ranks = [load(f'{arm}/rank{rank}.real_perf.json') for rank in range(16)]
        metrics[arm] = {}
        for kind in ('forward', 'cycle'):
            samples = [max(values) / 1000 for iteration in range(len(ranks[0]['rounds']))
                       for values in zip(*[r['rounds'][iteration]['timing'][0][kind]['samples_us'] for r in ranks], strict=True)]
            metrics[arm][kind] = {'mean_ms': statistics.mean(samples), 'samples': len(samples)}
    old = json.loads((root / 'spmd_sinkhorn_overlap_20261020' / f'WHOLE_{case.upper()}_INDEPENDENT_RECHECK.json').read_text())
    assert counts['tokens'] == old['tokens'] and counts['events'] == old['events']
    for arm, values in metrics.items():
        for kind, value in values.items():
            assert value['mean_ms'] == old['metrics'][arm][kind]['mean_ms']
            assert value['samples'] == old['metrics'][arm][kind]['samples']
    sha = hashlib.sha256(archive.read_bytes()).hexdigest()
    assert sha == old['archive_sha256']
    result['cases'][case] = {'archive_sha256': sha, **counts, 'token_mismatches': 0, 'event_mismatches': 0,
                             'zero_preemptions': True, 'metrics': metrics}
result['pass'] = True
print(json.dumps(result, ensure_ascii=False, indent=2))
