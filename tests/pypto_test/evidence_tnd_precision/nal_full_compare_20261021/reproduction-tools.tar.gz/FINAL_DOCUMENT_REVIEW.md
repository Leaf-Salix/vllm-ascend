# 完整CSA差距报告：最终独立审查

## 结论

最终更新版本PASS。原两处证据强度措辞已修正；新增整模型及截图参照章节与原始证据/来源限定一致。未审查本轮SDK新变化，未执行NPU或修改正式文档/源。文档审查SHA见同名JSON。

## 已修正的两处措辞

1. 主报告“**Nal两版相互同值**”原先缺少直接跨实现exact证据，当前正文已正确改为误差指标相同、未做跨版逐位验收。runner分别将NalMulti、NalSPMD与Native计算metric，没有两者相互逐位比较；即便different_elements、max_abs和relative_l2相同也不能证明所有元素相同。无需重跑，改成“二者对Native的已记录误差指标相同，未直接进行跨版本逐位验收”。
2. README“**每个raw JSON包含实际PyPTO/Simpler导入、DSO**”与raw字段不符。raw保存source/helper/compile及根身份，但这些SDK import/DSO收据来自device预检日志/SDK记录。当前README已经明确预检日志/SDK记录与raw字段的分别来源，问题已解决。

建议再补一句L1阶段表来自独立v5范围的DFX，不是新common-metadata计时任务；该表是PTO任务/角色覆盖跨度，不能解释成已补齐producer后的整图端到端时间。现有段落已经正确区分event与L1、等待与计算，不构成数值阻断。

## 独立重算

最终common raw complete/pass均真，Native950.1528168、我方1298.0009460、NalMulti782.9336166、NalSPMD1034.6110153µs；我方与NalMulti差515.0673294µs，较Native慢36.6097035%，较NalMulti慢65.7868456%。报告四舍五入准确。

Nal两臂capture producer均2次、eager compact与fixture逐位相同有实际记录；我方A/B各8个外部边界均bit_equal，Nal known delta不作为gold。新共同范围与旧v5结果已明确分列，不从跨任务差推导producer成本，处理合理。

A首轮1314.5140→1313.0627µs（-0.1104%，7/12）；复测冻结1309.7930、A1308.4517（-0.1024%，7/12）、B1338.3669（+2.1816%，0/12领先冻结）。A/B输入的全部8个外部边界、恢复、guard均为门禁范围；这些结果不支持保留优化，报告拒绝两版且不扩整模型，结论正确。B同轮已含A，未沿用早期Native/Frozen/B三臂做增量归因。

独立L1 raw的首末incore median为我方1203.68、NalMulti671.38、NalSPMD852.28µs。函数单核最大值与跨函数时间线来自每窗中位数，报告已声明不是单次trace重建、不相加，合理。QK/PV大段值得继续研究，但没有证明内部唯一瓶颈，后续三条路线均标未实现/待bit门禁，没有给未测收益承诺。

PMU Scalar占比是整个Simpler外壳，报告没有把它当纯polling或DDR字节，也保留flow关联缺失限制。没有把用户截图的SPMD L1与本轮raw event混比。

## 任务与复现

RUNS_FINAL共13项：7 exit0、5 exit1、1主动停止exit130，全部终态。独立从归档START/END重算成功任务耗时依次320、144、144、170、182、166、182秒，均小于780秒；144～320秒表述准确。

复现工具包根为CHECKLIST/tools/reference等直接相对路径，与README解包后rsync目标匹配；固定v5 receipt/只读artifact/source pin/独立SDK前置依赖已明确，不声称是无需既有环境的通用安装包。源档末次重封与SHA256.json尚待主线程完成，本review不提前宣称最终封包校验已经PASS。

正式精度数学未因本轮A/B改变，也没有新整模型token资格；本报告关于本轮冻结控制精度与候选失败的限定适当。

## 新增整模型及用户截图章节复核

独立验证两档whole归档SHA为原RECHECK中的d9bb1f8e…和8a8f5bbf…；从candidate/native-historical/serial-parent所有16rank逐步重算forward/cycle，候选8K为106.46689949035644/122.04716732627467ms，128K为90.71290766398111/103.07979824668483ms，与正文精确吻合。候选均60/57测量点；历史Native8K60/57、128K40/38点。正文的18.981%/13.775%仅相对历史Native，并明确跨任务、旧SDK、显式variant及EPLB关闭，未说新SDKwhole已经通过。

原configuration确认8K提交/活跃40，128K提交24/活跃21，decode192、repeats3、EPLB=false；preflight确有75模型分片记录。两档491520/105152与294912/61568的token/events、960同phase CPU几何行及零抢占由原严格audit/独立recheck保存。正文保留fixed bank/入场及CPU0/-1观测限制，没有扩成内部tensor或GPU输入全逐位，也没有声称固定接受率3.8或EPLB开启。

八档BSH/TND数字按父线程提供的用户截图转录复核计算，等权几何均值为0.9933462114，各行百分比四舍五入正确。来源声明为截图而非新硬件，BSH pin a241fa61，TND commit/完整工具配置未知。正文只在8K/B16填我方既有1203.68并明确不同输入/SDK/统计没有受控关系，其余未测，不报告89.8%受控差距或八档通过。新计划先受控8K/B16、首差停、保留ragged门禁、稳定完整层收益后才whole，措辞合理。

最终未发现额外文档阻断。最终source归档重封与SHA清单由主线程完成，不提前代替其校验。

## 最后文档冻结确认

已核正文新增L1节首句：本节为v5独立DFX/dep的PTO incore覆盖跨度，不是补齐producer后的common整图计时；先前建议已落实，无文档阻断。最终两文档SHA已刷新。

reviewer另独立执行新增`recheck_current_whole.py <repo>`，不导入NPU，重新逐项比较原归档16rank、warmup+三轮全部请求的token/接受事件与Native gold，检查零抢占，并重算三臂逐step maxrank timing。CPU退出0，两档PASS；8K491520 token/105152 events，128K294912/61568均零差异，数值与CURRENT_WHOLE_MODEL_RECHECK及原RECHECK精确一致。脚本与实际结果SHA已加review JSON。无需新增硬件或扩大结论。
