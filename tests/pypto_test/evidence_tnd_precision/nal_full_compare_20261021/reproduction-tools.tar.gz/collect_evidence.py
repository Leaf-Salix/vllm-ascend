"""仅收集本轮自有实验的现有结果和日志，不执行NPU。"""
from pathlib import Path
import json,subprocess,tarfile
sdk=Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
root=sdk/'nal-full-compare-20261021'
out=root/'evidence-final';out.mkdir(exist_ok=False)
runs=json.loads((root/'RUNS.json').read_text())
for row in runs:
 case=row['case'];task=row['task'];dest=out/case;dest.mkdir()
 status=subprocess.run(['task-submit','--status',task],capture_output=True,text=True,timeout=30,check=True).stdout.strip()
 assert status.startswith('completed'),(task,status)
 row['actual_final_status']=status
 log=subprocess.run(['task-submit','--log',task],capture_output=True,text=True,timeout=30,check=True)
 (dest/'task.log').write_text(log.stdout+log.stderr)
 for src,name in [(sdk/'results'/case/'result.json','result.json'),(sdk/'results'/(case+'-run.log'),'run.log')]:
  if src.exists():(dest/name).write_bytes(src.read_bytes())
for case in ('nal-full-compare-cpu-v1','nal-full-physical-a-cpu-v1','nal-full-physical-a-cpu-v2','nal-full-physical-b-cpu-v1'):
 src=sdk/'results'/case/'result.json'
 if src.exists():(out/(case+'.json')).write_bytes(src.read_bytes())
for name in ('nal-full-compare-cpu-v1.log','nal-full-compare-reuse-cpu-v1.log','nal-full-physical-a-cpu-v1.log','nal-full-physical-a-cpu-v2.log','nal-full-physical-b-cpu-v1.log'):
 src=sdk/'logs'/name
 if src.exists():(out/name).write_bytes(src.read_bytes())
(out/'RUNS_FINAL.json').write_text(json.dumps(runs,indent=2,ensure_ascii=False)+'\n')
with tarfile.open(root/'final-result-logs.tar.gz','w:gz') as archive:
 for file in sorted(out.rglob('*')):
  if file.is_file():archive.add(file,arcname=str(file.relative_to(out)))
print(json.dumps({'all_tasks_completed':True,'task_count':len(runs),'archive':str(root/'final-result-logs.tar.gz')},indent=2))
