"""Nal固定源码的完整无设备ABI/编译门禁，不替换生成C++。"""
from pathlib import Path
import json,os,sys,types,runpy,traceback,hashlib
sdk=Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
sys.argv=[str(sdk/'sdk-preflight.py')];runpy.run_path(sys.argv[0],run_name='__main__')
sys.path.insert(0,os.environ['SOURCE_ROOT'])
os.environ['VLLM_ASCEND_ENABLE_NZ']='2';os.environ['VLLM_ASCEND_PTO_CSA_ATOMIC_ADD']='0'
root=sdk/'nal-full-compare-20261021';reference=root/'reference/vllm_ascend/ops/pypto'
proof=json.loads((root/'REFERENCE_SOURCE_PROOF.json').read_text())
assert all(hashlib.sha256((root/'reference'/k).read_bytes()).hexdigest()==v for k,v in proof['files'].items())
private=types.ModuleType('nal_isolated');private.__path__=[str(reference)];sys.modules[private.__name__]=private
from nal_isolated.deepseek_v4_flash_csa.decode_csa import decode_csa_tp1_layer_test
from nal_isolated.deepseek_v4_flash_csa_spmd.entry import decode_csa_spmd
from nal_isolated.deepseek_v4_flash_csa_spmd.policy import select_policy
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program
from pypto.runtime._kernel_artifact import KernelArtifact
import pypto.torch,torch_npu

prior=sdk/'results/nal-full-four-arm-8k-b16-v5'
receipt=json.loads((prior/'result.json').read_text());assert receipt['pass']
policy=select_policy(tokens=96,requests=16,max_query_tokens=6,max_seq_len=8197)
for name,program in [('nal_multi',decode_csa_tp1_layer_test.specialize()),('nal_spmd',decode_csa_spmd.specialize(**policy.constexprs()))]:
 abi=kernel_abi_for_program(program,platform='a2a3',runtime='tensormap_and_ringbuffer')
 directory=prior/(name+'-kernel')
 before={str(p.relative_to(directory)):hashlib.sha256(p.read_bytes()).hexdigest() for p in directory.rglob('*') if p.is_file()}
 artifact=KernelArtifact(directory,abi)
 from pypto.runtime._prebuilt import load_prebuilt
 from pypto.jit._artifact_manifest import BuildKind
 artifact._loaded=load_prebuilt(directory,abi.platform,BuildKind.SINGLE_CHIP,kernel_abi=abi)['.']
 after={str(p.relative_to(directory)):hashlib.sha256(p.read_bytes()).hexdigest() for p in directory.rglob('*') if p.is_file()}
 assert before==after
 print(name,artifact.identity().hex(),len(abi.parameters),flush=True)
assert not torch_npu.npu.is_initialized()
print('PREBUILT_REUSE_CPU_PASS',flush=True)
