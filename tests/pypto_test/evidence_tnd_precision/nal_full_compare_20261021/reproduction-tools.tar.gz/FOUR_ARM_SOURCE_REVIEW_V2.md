# 更新助手快速复核

## 设备前结论

静态PASS，未发现阻断首轮8K/B16 uniform S6的错误。源码SHA及manifest见同名JSON。此次只读审查，没有运行编译、NPU或更改助手。

已逐项确认：全S6在创建fixture前断言；跨臂readonly快照和compact cos/sin/slot逐位比较；A恢复与warmup后立即检查guard；Nal runner按default参数固定本臂prepared/coreargs/config；SPMD signal与当前源`PHASE_COUNT=60`一致，reshape为60×72×128，padding全零及phase0全部72核同代际；每timing窗严格+100、每DFX窗+1，检查位于事件区间外。初次信号zero_来自当前PreparedDynamicCSA，故padding零检查有来源。外部工作区仍保留，未新增错误的signal重置。

确认CPU ABI的56/130是本次实际编译记录口径；建议最终result也附CPU收据SHA，不能仅在文字写参数数。默认CLI lengths仍非S6，但run.sh已显式提供S6且现在提前拒绝不支持输入，不阻断规定入口。

此静态结论不替代首轮实际graph/eager比对、原生stream依赖和代际硬件检查。未证明SK1，也没有Nal模块时间。

## 后续纯DSL分模块对拍的最小方法

1. **先用完整四方结果判断是否仍有同环境整体差距。** event与L1独立；核查实际task数、24AIC/48AIV、所有输出/cache合法写区和我方Native逐位门禁。不要先按历史后缀收益决定整个CSA瓶颈。
2. **选共同数学边界，不按两边函数名硬配。** 可将HC-pre+inputNorm、Q/KV及compressor、Indexer(score/topk)、Sparse QK/softmax/PV+inverseRoPE、O-proj+HC-post列为候选大段。具体切点应以完整依赖图和真实输入张量可取得为准；跨段重叠必须在报告明确。
3. **先复用Nal multi现有独立task入口和我方已存在DSL入口，做相同stage输入的孤立FULL graph。** 双方从同一canonical输入bank绑定，Native提供阶段gold；保留真实权重、布局、query bounds、TopK/cache及相同起始状态。输出/临时状态毒化并复验，guard/readonly/A-B-A不变。我方第一bit差立即停；Nal误差记录但自重复/finite/合法写入仍须通过。此测量只叫isolated stage，不能充当完整常驻内部贡献。
4. **Nal SPMD若要保持其内联布局/调度，则抽取原数学AST形成独立DSL微根。** 同步删除仅限已被独立输入就绪取代的跨阶段通知；阶段内环槽复用/ACK/搬运fence保留。数学AST逆归一化、实际PTO地址/事件与worker覆盖必须审查，先对完整根在同输入下的该阶段输出。若没有可靠观测输出，不应给它性能归因资格。不要加C++时间戳/等待helper，不改SDK。
5. **只在一个因素上试验。** 保持Native K序、累加分组、BF16/INT8边界、全8192统一量化；布局复用、合法预取或owner依赖每次只变一个。双方isolated时间、完整根时间及L1跨度分别列，不能加总或相减叫纯等待。

单MIX现有L1只见完整角色跨度；若想回答“完整程序内部哪个阶段最长”，当前无已注册DSL计时接口时应明确暂不可见。上述孤立微根能检验某一模块是否有可实现收益，但不能证明它就是完整层的关键路径。最终保留必须回到完整CSA逐位与同轮配对event，并在稳定后再做真实模型token验收。
