"""Nal固定源码的完整无设备ABI/编译门禁，不替换生成C++。"""
from pathlib import Path
import json,os,sys,types,runpy,traceback,hashlib
sdk=Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
sys.argv=[str(sdk/'sdk-preflight.py')];runpy.run_path(sys.argv[0],run_name='__main__')
sys.path.insert(0,os.environ['SOURCE_ROOT'])
os.environ['VLLM_ASCEND_ENABLE_NZ']='2';os.environ['VLLM_ASCEND_PTO_CSA_ATOMIC_ADD']='0'
root=sdk/'nal-full-compare-20261021';reference=root/'reference/vllm_ascend/ops/pypto'
proof=json.loads((root/'REFERENCE_SOURCE_PROOF.json').read_text())
assert all(hashlib.sha256((root/'reference'/k).read_bytes()).hexdigest()==v for k,v in proof['files'].items())
private=types.ModuleType('nal_isolated');private.__path__=[str(reference)];sys.modules[private.__name__]=private
from nal_isolated.deepseek_v4_flash_csa.decode_csa import decode_csa_tp1_layer_test
from nal_isolated.deepseek_v4_flash_csa_spmd.entry import decode_csa_spmd
from nal_isolated.deepseek_v4_flash_csa_spmd.policy import select_policy
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program
from pypto.runtime._kernel_artifact import KernelArtifact
import pypto.torch,torch_npu
out=sdk/'results/nal-full-compare-cpu-v1';out.mkdir(exist_ok=False)
r={'pass':False,'device_execution':False,'source_pin':proof['pin'],'entries':{}}
try:
 op=pypto.torch.register(decode_csa_tp1_layer_test,'nal_full_compare_cpu::multi')
 r['multi_schema']=str(op._schema)
 policy=select_policy(tokens=96,requests=16,max_query_tokens=6,max_seq_len=8197)
 r['policy']=policy.constexprs()
 for name,program in [('multi',decode_csa_tp1_layer_test.specialize()),('spmd',decode_csa_spmd.specialize(**policy.constexprs()))]:
  try:
   abi=kernel_abi_for_program(program,platform='a2a3',runtime='tensormap_and_ringbuffer')
   _compile_impl(program,output_dir=str(out/name),platform='a2a3',skip_ptoas=False,_kernel_abi=abi)
   artifact=KernelArtifact(out/name,abi);artifact.load()
   r['entries'][name]={'pass':True,'args':len(abi.parameters),'artifact_identity':artifact.identity().hex()}
  except BaseException:r['entries'][name]={'pass':False,'error':traceback.format_exc()}
 assert not torch_npu.npu.is_initialized()
 r['pass']=all(v['pass'] for v in r['entries'].values())
except BaseException:r['error']=traceback.format_exc()
finally:(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if not r['pass']:raise SystemExit(1)
