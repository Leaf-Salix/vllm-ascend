# DFX/依赖图复用已执行DSL二进制审查

## 结论

当前修正版静态PASS；无设备复用检查实际PASS后才交设备。此review没有编译、初始化NPU、修改SDK或任务操作。源码及SDK参考SHA见同名JSON。

原两个执行阻断已经修复：binding模块没有全局decode_csa_spmd属性（仅__call__局部import），现在从entry显式获取；不存在的runtime._types已改为实际BuildKind定义模块。

另已修复会反复CCEC的问题：本SDK的首次`KernelArtifact.load()`会调用`prepare_prebuilt`，以save_prebuilt=True/force_rebuild=True重新编译；不能用它声称只读复用。当前先以KernelArtifact构造验证compiled_meta与ABI，再`load_prebuilt(...,kernel_abi=abi)`恢复manifest中的既有bytes，把返回三元组赋给此诊断进程的artifact._loaded缓存。该过程不改SDK文件、不改生成代码、不新增数学；后续identity/load命中缓存，invoke使用原共享Worker。

## 已核验证链

- v5 result必须pass/complete，B16/T96/L4/history8191/S6、Nal source proof与SPMD policy逐项一致；复用范围不泛化为其它形状/策略。
- 当前源重新specialize只建立ABI，不执行_compile_impl；compiled_meta要求ABI兼容。binary_manifest中每个核与orchestration size/SHA逐项读取验证，metadata/config/manifest/binaries在恢复前后SHA相同，并记录v5结果SHA。
- SDK load_prebuilt再次验证manifest完整性、各binary SHA、Simpler revision、runtime/platform、签名与ABI binary_tag，随后从现成bytes创建CoreCallable/ChipCallable。它不调用compiler、不加build锁、不写盘。
- describe_eager_call按ABI重新检查Tensor/设备/current stream；eager invoke先ensure_callable注册，capture invoke必须已有require_callable，同一pypto.torch.init进程Worker承载三个PTO根。
- 保留artifact、参数tuple、target、call/prepared/工作区的对象所有权，未见异步生命期问题。graph eager/capture/A-B-A/精度首差、workspace guard、metadata readonly及signal代际原门禁均保留。
- DFX与dep模式分开：DFX level1/depgenFalse，依赖图level0/depgenTrue；它们不是性能event结果，不引用v5时间作为本次采集时间。

## 解释限定

v5结果说明源码/输入/策略曾在该输出目录执行，本次读取的二进制SHA提供现在的明确身份，不能追溯伪造一个v5当时未写出的binary receipt。若目录有任何人为数学变更，应拒绝复用，不能仅靠相同ABI放行；当前已绑定同source proof与policy、保持目录前后不变，后续硬件仍需重新通过相同输出/cache/guard及代际门禁。

artifact._loaded赋值是仅诊断进程的已验证二进制恢复适配；正式ArtifactStore READY handle恢复也可行，但v5私有输出没有该现成handle，不能伪造READY凭证。本轮无需为此更改SDK。

Nal单MIX依然只提供一个task的角色span；复用二进制不会凭空新增内部stage时钟。映射须来自这些实际artifact config/orchestration，不沿用其它kernel的token表。DFX阶段跨度不可相加，依赖图与timing分采。
