"""匹配独立L1与依赖图；跨度保留内部等待，不作纯计算归因。"""
import collections
import json
from pathlib import Path
import statistics
import tarfile

ROOT=Path(__file__).resolve().parent
with tarfile.open(ROOT/'nal-full-four-arm-8k-b16-dep-v2-evidence.tar.gz') as dep_archive, tarfile.open(ROOT/'nal-full-four-arm-8k-b16-dfx-v2-evidence.tar.gz') as trace_archive:
    dep_report=json.load(dep_archive.extractfile('result.json'))
    trace_report=json.load(trace_archive.extractfile('result.json'))
    assert dep_report['pass'] and trace_report['pass']
    assert dep_report['DFX']['level']==0 and dep_report['DFX']['enable_dep_gen']
    assert trace_report['DFX']['level']==1 and not trace_report['DFX']['enable_dep_gen']
    def path(index,leaf):
        return 'dfx/'+('' if index==0 else f'window_{index}/')+leaf
    mappings={}
    for index,window in enumerate(dep_report['DFX']['windows']):
        dep=json.load(dep_archive.extractfile(path(index,'deps.json')))
        mapping={int(row['task_id']):row['kernel_ids'] for row in dep['tasks']}
        if window['arm'] in mappings:assert mappings[window['arm']]==mapping
        mappings[window['arm']]=mapping
    output=[]
    for index,window in enumerate(trace_report['DFX']['windows']):
        arm=window['arm']
        d=json.load(trace_archive.extractfile(path(index,'chip_swimlane_records.json')))
        rows=d['aicore_tasks'];freq=d['metadata']['clock_freq_hz']
        assert d['chip_swimlane_level']==1 and {row[0] for row in rows}==set(range(72))
        functions=collections.defaultdict(list)
        for core,token,registration,start,end,_ in rows:
            assert 0<start<=end
            if arm=='nal_spmd':name='single_MIX_AIC' if core<24 else 'single_MIX_AIV'
            else:
                kernels=mappings[arm][token]
                assert len(set(k for k in kernels[1:] if k>=0))<=1
                fid=kernels[0] if core<24 else next(k for k in kernels[1:] if k>=0)
                name=dep_report['kernel_maps'][arm]['names'][str(fid)]
            functions[name].append((start,end))
        lo=min(r[3] for r in rows)
        us=lambda ticks:ticks*1e6/freq
        output.append({'arm':arm,'repeat':window['repeat'],'span_us':us(max(r[4] for r in rows)-lo),
          'functions':{name:{'max_core_us':us(max(b-a for a,b in intervals)),
            'inclusive_span_us':us(max(b for a,b in intervals)-min(a for a,b in intervals)),
            'start_us':us(min(a for a,b in intervals)-lo),'end_us':us(max(b for a,b in intervals)-lo),
            'records':len(intervals)} for name,intervals in functions.items()}})
    medians={}
    for arm in ('candidate','nal_multi','nal_spmd'):
        samples=[row for row in output if row['arm']==arm]
        medians[arm]={name:{field:statistics.median(row['functions'][name][field] for row in samples)
                           for field in ('max_core_us','inclusive_span_us','start_us','end_us')}
                      for name in samples[0]['functions']}
    result={'pass':True,'method':'separate L1/dep_gen; inclusive overlaps not additive; max-core time includes synchronization and Scalar work',
        'functions':medians,'windows':output}
    (ROOT/'STAGE_ANALYSIS.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    for arm,functions in medians.items():
        print('\n'+arm)
        for name,r in sorted(functions.items(),key=lambda kv:-kv[1]['max_core_us']):
            print(f"{name:45} maxcore={r['max_core_us']:7.2f} span={r['inclusive_span_us']:7.2f} [{r['start_us']:7.2f},{r['end_us']:7.2f}]")
