# Sparse压缩候选寻址：最小纯DSL单因素审查

## 结论

有一个不需要改变Native数学的具体方向：**压缩TopK完成Native pair重排后，一次生成物理cache行号；消费者按该顺序搬运原样BF16行**。先测地址预解码，再单独测64行索引批量加载/mgather。不要移植Nal的K128 softmax/在线归并树或三槽调度来证明这个点有效；它们会混入已知数值边界差异。

这是可测候选，不是已证瓶颈或收益。源码SHA见同名JSON。本轮没有改源或提交任务。

## 一、源码差异与不可改的数学

| 部分 | 我方冻结精度路径 | Nal动态SPMD路径 |
| --- | --- | --- |
| 候选检查 | `checked_compressed_index:164`按请求、position、页表验证逻辑index | plan按Q/L/causal/page验证逻辑候选 |
| 候选次序 | `native_compressed_pair_swap:183`复现Native低物理地址成对读取及stride/末项fallback | 独立plan逻辑，不能替代我方Native pair顺序 |
| 地址重复 | `csa_checked_indices:246`每候选查页；pair helper可能重查两页；AIV消费者`:469–476`又读逻辑index并查页 | `attention_plan_stages:360–399`一次页表tile加载与Vector gather，发布INT32物理行 |
| 消费者 | 每AIV按64行循环Scalar读取候选、查页，再1行`gather_row` | `attention_stream_stages:302–317`DMA加载64项物理行，`mgather(coalesce='row',gather_oob='zero')` |
| Cube/softmax | K512语义、4个K128 Cube子段；SWA仅第一K128；Native actual-K归约及probability `mode='round'` BF16边界 | K128、三槽交错与另一套在线统计/归并 |

我方`:503–582`根据actual K选择小于64、64至511、完整512的不同归约树；概率cast、sink初值、PV FP32累计/alpha合并和inverse RoPE都必须逐AST保留。物理行方向只改变内存地址表示，不得改变这些算术节点、QK/PV K顺序、候选lane顺序或FFTS事件对数。

我方现有L1保留末两个K128 KV子段已是独立验收优化；本因素不动该carrier、slot、MTE事件或PV重载策略。

## 二、两个依次测的单因素

### A：地址预解码，消费者仍逐行搬运

优先在`csa_checked_indices`中复用候选有效性校验已经读到的page，在Native pair swap以后输出对应物理行。消费者仍使用原64次Scalar物理行读取和原`gather_row([1,512])`，只移除重复的`index//32、查表、page*32+index%32`。

- 对合法candidate，映射为`page*32+(logical_index%32)`；非法仍为INT32 -1。
- pair的逻辑上界`first+1<limit`、末项fallback、重复项、stride字节阈值保持原判据；不能先把physical当logical再算limit，也不能重新全排序。
- 为减少改动风险，首版可另建`physical_rows[T,512]`，原logical scratch及sparse bias完全不变。最大T256多512KiB GM，必须检查scope/ring峰值。
- 如果复用原`cmp_sparse_indices`承载物理行，先完成所有需要逻辑值的检查和pair swap。其后bias仅使用“负sentinel/非负”时数学可保持，但这是新的表示合同，须有CPU证明及producer/consumer共同资格谓词，不能凭变量名仍相同而混读。
- 要真正少查页，checked helper应返回已验证page/physical row，pair helper复用它们；若只是把原消费者Scalar分页循环移进另一个task而保留所有查表，未必减少工作。

全有效512候选时，旧路径最多约三轮页表Scalar读：有效性、pair、消费；新路径可复用第一轮。这里只是源级访问上界，不是带宽或延迟预测。

### B：在A已验收后，消费者64项DMA+mgather

保持相同物理索引GM布局，单因素将64次Scalar读取/逐行`gather_row`替换为：`pl.load([1,64] INT32 physical rows)`，再`pl.tile.mgather`得到同一`[64,512] BF16`，store回原kv_transfer位置。其余所有Cube/softmax/事件保持。

Nal源码明确指出MGATHER仍可能lower成逐行DMA；不能称“单硬件指令并行采64行”。这一因子主要检验Scalar控制与索引读取开销，不承诺减少业务KV字节量。重复物理行也不能去重后改序；可以重复读取同一行，输出槽位必须与原逻辑槽位一致。

## 三、范围和正确性风险

1. **地址位宽。** 物理地址保持INT32/INDEX整数，不经FP32。`page*32+offset`必须不溢出INT32；可保守复用Nal的pages≤2^24与table columns≤2048范围，否则整次调用退回旧逻辑表示。若用Vector FP32谓词，logical candidate/upper也要受≤2^24精确范围限制，不能只检查page数。
2. **非法页合同。** 原精度消费者仅检查page非负，合法输入来自Native已分配cache。新增page上界保护不能冒称修复已定义Native语义；越界正页应在资格/fixture验证中拒绝或完整回退，不以zero silently掩盖。负page与-1候选应保持原+0 KV行。
3. **零与位精度。** `mgather(gather_oob='zero')`必须实际完整写出64行，非法行是原`full(+0)`的位模式；不能保留旧workspace/NaN。signed-zero、subnormal及重复cache值需要位比较，不能只比较最终allclose。
4. **TND/尾部。** 请求owner使用现有token_request/Q/L，不从T除S6重建。按真实T逐行处理，inactive/负owner不读页表。T1..256与混合1～6行都应CPU覆盖，不因新索引padding改变Native actual K。
5. **依赖。** 保留checked→plan→qk的真实Out/Input DAG及cache producer依赖。Scalar写索引在task exit的flush不能被同task普通fence替代。物理索引必须在本代plan全部写完并可见后消费，不能读取上次调用残留。
6. **UB/生成码。** 64×512 BF16结果为64KiB，新增索引tile256B、页表tile至多8KiB；旧running stats/softmax scratch仍存活。必须实际CCEC核UB峰值、load valid shape、mgather OOB实现和输出owner，无alias覆盖，不能只用总字节估算放行。
7. **实际收益。** 预解码可能使checked/plan更长，尚未证明它能被其它工作覆盖；mgather仍逐行DMA。需同时比较plan、QK/PV可见span及完整根event，不能只看消费者Scalar代码减少。

## 四、最小门禁

- CPU对相同metadata/TopK验证旧逻辑读取的每一行与新physical行逐项相同。覆盖pair互换/不换、duplicate、final valid index、负sentinel、页边界31/32、反向/碎片页、inactive、真实TND边界，以及资格边界内外回退。
- 实际生成码检查新索引producer/consumer的地址与依赖；比较除地址块以外数学AST、K512归约树、round BF16、PV和FFTS事件序列不变。
- 短任务同输入Native/原PTO/候选FULL A/B/A。额外比较`kv_transfer`有效行的BF16 bytes（可在独立诊断根导出，不改正式接口），原始QK scores、probabilities/PV若已有观察器则逐位。第一差异立即定位。
- 通过后完整CSA同任务交错12窗，独立重复；最终还要真实模型8K、128K token不回退。某一stage快不能代替完整层快，不以Nal已知数值误差作为我方gold。
