# 四方助手设备前独立审查

## 状态

已实际审查`tools/probe_csa.py`、fixture、source_identity、reference内Native适配器及SPMD绑定，并核对check/device/run脚本。Python AST、helpers manifest、63个reference文件SHA及12窗四臂顺序平衡检查通过；未初始化设备、执行编译或提交任务。实际源码SHA固定在`FOUR_ARM_SOURCE_REVIEW.json`。

没有发现闭包对象被提前释放、四张根NZ权重来源不同或将Nal输出作为我方金值的静态问题。以下门禁补齐后再给设备资格；CPU编译可以继续。

## 需落实

1. **Nal SPMD信号合同尚未观测。** 当前检查了工作区外侧guard，但没有读回`prepared.buffers['signal']`，也没有核对各核phase0共同代际、每窗严格+100/DFX+1和保留隔离区。A/B/A与最终cache相同不能代替信号合同。应捕获后记录基准代际，每次A/B/A、warmup和计时/DFX按实际调用次数推进，不重置信号；读取前后snapshot在窗口外。phase padding应按本源实际初始化合同验证，不沿用其它候选的-91假设。
2. **当前四方适配器只支持uniform S6。** `reference/.../deepseek_v4_flash_csa/native_adapter.py::NativeCSACall`明确要求`tokens==batch*6`，且实际token数可整除6。虽SPMD内核支持device TND边界，本工具通过旧multi adapter共同绑定，所以默认`1,1,1,1`会拒绝。`run.sh`当前生成S6可用；建议脚本一开始明确断言`lengths==[6]*batch`。不能把本轮四方PASS称为ragged资格。
3. **补两处立即guard。** B后有检查；A恢复比较后及3次warmup后没有立即检查guard/readonly，后续`restore_readonly`可能修复该阶段的metadata写坏。每个计时/DFX窗口之后已有guard，不需要重写整套流程，只补A恢复与warmup后的检查。
4. **同输入身份需覆盖metadata。** 当前逐臂断言hidden/positions和初始cache等值，但没有跨臂逐项核对Q/L、block table、slot、start_pos及compact RoPE。fixture同seed/同构造使预期相同，建议把这些现成readonly字段及compact cos/sin也逐位断言并保存SHA；不要仅用同shape或`cross_bucket_scope`文字替代。记录Nal实际multi schema和SPMD runtime Tensor数，而不猜130/132。

## 已核实的正确点

- `source_identity`绑定3365/43正式snapshot；overlap根及四个相邻包另受compile receipt源码SHA约束。reference63文件逐一验证，pin91c；SPMD tree与bea相同由主线程proof提供，未将91c新multi当bea执行。
- Native先捕获；candidate初始化仅clone同值HC权重并将旧Native storage留在`keepalive`。Nal四张根NZ权重以`data_ptr`验证为当前Native已加载对象；其余权重由同层对象准备，拷贝/转置发生捕获外。对转换后数值差异只记录，不回写模型。
- Nal的`NativeCSACall`、prepared、runner、CompileOptions、guard owners均被保存；所有graph存储在rows/keepalive。Python late-bound runner不在后续raw replay时重新解析，未见闭包生命周期问题。
- Native/我方使用原npugraph_ex静态SK0捕获；Nal先直接JIT warmup，再raw NPUGraph。报告明确两种捕获方式及Native SK0，没有冒认SK1。共同测量边界是raw graph事件，JIT/adapter准备不在100次回放窗口。
- Native→我方A与B逐边界bit比较首差停。Nal delta独立记录，仍要求compiled/raw一致、A/B/A和cache合法写区；没有以Nal误差阻断我方门禁。
- timing与DFX分进程/模式，DFX明确dep-gen=False，不启用wait/phase-clock生成C++变换。12窗4臂按4窗块反转，每臂每个位置恰3次，顺序平衡成立。

## 解释限制

事件测量代表本runner共同raw replay设备边界，不是Python端到端服务延迟。Nal捕获在独立stream后使用当前stream replay；设备前应保留实际graph stream关联/完成语义记录，并用graph输出门禁与记录事件后同步确认回放已完整完成。不能仅从全卡同步的正确结果推导事件覆盖了所有内部流。

DFX只给实际task/角色记录；单Nal MIX没有内部阶段时间戳。报告正确标明该限制。旧`DFX_STAGE_ANALYSIS`或孤立后缀span不能与四方event直接相减，也不能加总重叠阶段。source pin、SDK、调用入口和policy差异需随结果保留。
