"""仅在诊断命名空间绑定物理行候选，不改变正式模块或SDK。"""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

PRECISION = 'vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision'
OVERLAP = 'vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap'
ROOT = Path(__file__).resolve().parent


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def load_candidate(formal_root):
    import importlib

    baseline = importlib.import_module(PRECISION + '.decode_sparse_attn_csa')
    proof = json.loads((ROOT / 'SOURCE.json').read_text())
    assert hashlib.sha256(Path(baseline.__file__).read_bytes()).hexdigest() == proof['baseline']
    assert hashlib.sha256((ROOT / 'sparse_physical_a.py').read_bytes()).hexdigest() == proof['A']
    load_module(PRECISION + '.sparse_physical_a', ROOT / 'sparse_physical_a.py')
    old = 'from ' + PRECISION + '.decode_sparse_attn_csa import sparse_attn_csa_tp1'
    new = 'from ' + PRECISION + '.sparse_physical_a import sparse_attn_csa_tp1'
    expected = Path(formal_root.__file__).read_text()
    assert expected.count(old) == 1
    clone = ROOT / 'decode_csa_physical_a.py'
    assert clone.read_text() == expected.replace(old, new)
    module = load_module(OVERLAP + '.decode_csa_physical_a', clone)
    return module.decode_csa_tp1_layer_test
