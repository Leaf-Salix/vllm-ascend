# 候选B（64行MGATHER）独立审查

## 结论

相对当前显式INT32-cast候选A，B源码与固定SDK API匹配，未发现阻断完整CPU编译的地址/数学错误。仍须完整根GCC/PTOAS/CCEC、actual UB/SSA审查；A硬件逐位通过后才可提交B。此报告没有执行编译、NPU或修改候选/SDK。

候选、loader、probe/check与SOURCE的实际SHA绑定在同名JSON。A→B仅一个`sparse_attn_csa`函数改变：SWA分支内保留原full(+0)初始化；压缩分支的64次Scalar read/gather_row替换为一次1×64 INT32 tile load和fresh Vec row MGATHER；之后同址store与原FFTS保持。其余helper及最终发布wrapper AST相同。

## 地址与位精度

固定配置CMP_TOPK512、ATTN_K_TILE512、Cube子段128、双AIV lane64。压缩块sb1时起点为0、64、128、192、256、320、384、448，长度均64，覆盖0..511且无重叠/越行；独立Python枚举已验证。原逐行判断`qk_cmp_k<512`在此范围恒真，移除不改变合法访问。

A已按Native pair_swap发布physical索引，B保持原序读取，不排序、去重或改变候选lane。有效行的BF16数据由GM原样读取，不发生cast/计算。无效索引-1使用MGATHER的zero模式，固定SDK现有测试将INT32位按UINT32地址解释，-1为0xffffffff越界，从而完整写零行；等价于A原full(+0)后跳过该行。次正规、±0有效cache值应逐位保留，但该结论仍要actual ISA及硬件bit门禁，不能只以API文档代替。

a2a3后端Vec row MGATHER要求ND源、索引[1,R]、行大小32B倍数；本候选cmp_flat是ND连续[pages×32,512] BF16，index[1,64]，每行1024B，符合约束。现成Nal固定参考也采用相同形式，但Nal通过不等于本根资源已经通过。

## UB/SSA及依赖

新结果64×512 BF16占64KiB，索引tile256B。压缩分支不再先分配同大小zero tile，因此源码不要求同时保留两个64KiB结果；SWA与compressed互斥，两臂均在store前定义同shape/type的qk_kv_half。仍可能受编译器phi/liveness影响，必须检查实际Vec地址区间及store/索引scratch无覆盖。原running左右统计、reduce scratch仍存活，不能仅估算64KiB就放行。

未添加GM tensor或新task/信号；继承A的physical scratch与checked→plan→qk DAG，原KV_READY、SCORE_READY、PROB_READY、PV_READY事件对数及位置不变。MGATHER所有行必须在原store和READY之前完成，actual生成码需确认TLOAD/MTE2→MTE3顺序及零填充分支，无未初始化workspace/NaN进入softmax。

不改变K512的actual-K归约树、概率round BF16、PV四个K128累计顺序、SWA仅首子段、末两个KV子段L1复用、sink与inverse RoPE。不能将B扩展成Nal128树或三槽实验。

## Harness与可解释性

loader将B模块放独立诊断命名空间，仅替换完整root的Sparse import；根clone必须逐字等于冻结root唯一import替换，baseline SHA与B SHA均受SOURCE验证。check_b注册64参数根并编译整个程序，范围正确。源码check docstring仍叫A属于标签遗留，不影响编译，发布前应纠正。

当前probe_b实际为Native/Frozen/B：Native数值首差门禁、A/B/A、guard/readonly等保留，可以验证复合B的完整效果，**不能同轮隔离MGATHER相对A的单因素收益**。建议用Native/A/B三臂（或另加A第四臂），实际加载/namespace/报告均对应真实A，而不是只换标签；按真实arm数平衡轮转。即使A在上一任务测过，跨任务B/Frozen比例也不能当作B/A增量。

下一步先看A实际bit门禁与本B完整CPU生成物。B首个小任务同时核有效KV transfer bytes、最终cache/output逐位及poison回放；发现首差停。MGATHER可能仍lower为逐行DMA，所以“64项tile加载”不能称为单条硬件并行采64行，更不能预设节省KV字节。
