"""只编译独立物理行候选A；不初始化NPU。"""
from pathlib import Path
import hashlib,json,os,runpy,sys,traceback
sdk=Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
sys.argv=[str(sdk/'sdk-preflight.py')];runpy.run_path(sys.argv[0],run_name='__main__')
sys.path.insert(0,os.environ['SOURCE_ROOT'])
experiment=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overlap-20261020')
import vllm_ascend.ops.pypto as namespace
namespace.__path__.insert(0,str(experiment/'src/vllm_ascend/ops/pypto'))
import vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.decode_csa as formal_root
root=sdk/'nal-full-compare-20261021/physical-plan'
sys.path.insert(0,str(root))
from load_candidate import load_candidate
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program
from pypto.runtime._kernel_artifact import KernelArtifact
import pypto.torch,torch_npu
out=sdk/'results/nal-full-physical-a-cpu-v2';out.mkdir(exist_ok=False)
r={'pass':False,'device_execution':False,'source':json.loads((root/'SOURCE.json').read_text())}
try:
 entry=load_candidate(formal_root)
 registered=pypto.torch.register(entry,'physical_a_cpu::attention')
 assert len(registered._schema.arguments)==64
 program=entry.specialize()
 abi=kernel_abi_for_program(program,platform='a2a3',runtime='tensormap_and_ringbuffer')
 _compile_impl(program,output_dir=str(out/'kernel'),platform='a2a3',skip_ptoas=False,_kernel_abi=abi)
 artifact=KernelArtifact(out/'kernel',abi);artifact.load()
 assert not torch_npu.npu.is_initialized()
 r.update(pass_=True,artifact_identity=artifact.identity().hex(),args=len(abi.parameters))
 r['pass']=True
except BaseException:r['error']=traceback.format_exc()
finally:(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2),flush=True)
if not r['pass']:raise SystemExit(1)
