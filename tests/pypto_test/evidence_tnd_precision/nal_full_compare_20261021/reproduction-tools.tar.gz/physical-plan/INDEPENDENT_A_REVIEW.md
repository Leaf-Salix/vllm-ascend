# 物理行候选A：独立设备前源码审查

## 结论

限定当前probe中页容量/非负页号均小于2^24、真实T<=256的测试域，源码静态PASS，可以进入完整无设备编译和实际生成码审查；尚无编译、硬件或性能资格。没有修改候选、正式仓库或SDK，也没有提交任务。审查绑定当前SHA见同名JSON。

`probe_a`当前已采用3臂按len(arms)轮转/块反转，12窗每臂每位置恰4次；page范围限定已在fixture后实际断言，`g['pages']`由allocate_native_cache提供。该限定使`page*32+offset <2^29`，新INT32物理行不会溢出。此限制只存在诊断harness，不能把候选函数直接作为所有输入的正式接口。

## 一、数学及寻址证明

与`sparse_baseline.py`的完整diff只有三个位置：新增`[T,512] INT32`内部scratch；checked task中增加两项物理地址计算及按原swap写回；消费者从scratch读取物理行，仍原逐行gather_row。

独立AST检查仅`sparse_attn_csa`变化；`checked_compressed_index`、`native_compressed_pair_swap`和最终merge/接口wrapper逐AST完全相同。原logical scratch、sparse_bias、valid_block_mask、K512 softmax及actual-K归约、概率round BF16、QK/PV子段顺序、SWA、L1末两段复用和FFTS代码未改。当前MATH_AST_AUDIT实际为53个选中浮点/FFTS call节点相同；这项局部审计不能单独证明地址正确，完整diff检查提供额外约束。

对于任意通过原checked的candidate，page非负且logical列合法，新地址等于旧消费者的`page*32+logical%32`。原swap先由未改变的逻辑index/页表计算，新physical的第一/第二项按同一swap写回，因此所有重复、最后候选、stride fallback次序保留。对于未通过checked的candidate，新scratch写-1，消费者保留full(+0)行；旧消费者同样跳过负逻辑index。inactive owner不读页表。每个真实T的256对全部覆盖512列，没有未初始化洞。

## 二、依赖及资源

- 每checked worker按48步长拥有完整query行；physical scratch一行2048B，写入者唯一，行间无Scalar cacheline共享。
- 保留checked→plan显式依赖以及plan→qk依赖，故physical写入与logical写入在同一checked task完成后可见。不得因新scratch另加提前消费或把task exit flush替换为普通fence。
- 新内部scratch最大256×512×4=512KiB GM，没有改变外部64 Tensor根ABI；是否与父scope其它暂存形成更高峰值仍须实际编排/allocator检查。
- 本因素没有增加64×512 UB carrier，也未引入mgather或三槽，原K512 pipeline不变。

## 三、A实际检验的问题

目前没有复用checked或pair helper已经读到的page，而是额外读取一次page生成scratch，同时删去原消费者同一次查页。因此A主要检验“将控制/分页放到先行checked任务”及多512KiB scratch成本；**尚不是减少总页表读取次数**的实现。A即使慢也不能否定复用page或批量mgather，A即使快也不能归因于减少KV业务字节或改变计算树。

应先观察完整根及checked/plan/QK_PV实际跨度，等待主线程DFX/依赖图证据后选择是否上卡；不会仅凭源级循环减少推断收益。

## 四、harness与剩余门禁

实际3臂为Native、原冻结PTO、physical_a；两PTO都保留A/B严格Native bit门禁、A/B/A、合法cache写区、readonly和根namespace/64ABI检查。新CSAOperators通过构造创建含新attention与原workspace的冻结对象，没有修改原实例attention字段；baseline图仍保持原root。

**产出前需清理标签**：report仍保留四方/Nal-delta/单NalMIX等复制文字，与实际3臂不符。它不会改变执行，但不能发布为四方候选性能结论。候选源码独立SHA已记录，helper manifest仍是原tools的身份，不能用该manifest代替probe_a自身runner_sha。

下一门禁是完整根specialize、GCC/PTOAS/CCEC和实际生成物，而非仅sparse函数局部编译。重点核新Scalar INT32写回、所有512列/真实T覆盖、physical消费者地址、checked至qk真实DAG、内部scratch生命周期，以及QK/PV/softmax事件与数学未变。通过后小任务先精度，第一差异立即停止，再同轮12窗比较。暂不引入mgather、Nal K128归约或新的prefetch。
