"""新SDK冻结CSA精度回归：保持诊断进程的显式包绑定。"""
from pathlib import Path
import runpy, sys
sdk=Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
args=sys.argv[1:]
sys.argv=[str(sdk/'sdk-preflight.py')]
runpy.run_path(sys.argv[0],run_name='__main__')
root=sdk/'nal-full-compare-20261021/physical-plan'
sys.path.insert(0,str(sdk/'nal-full-compare-20261021/tools'))
sys.path.insert(0,str(root))
sys.argv=[str(root/'probe_b.py'),*args]
runpy.run_path(sys.argv[0],run_name='__main__')
