"""8K真实权重、Native/TND完整CSA FULL图验收；首差停止。"""
import argparse
import contextlib
import hashlib
import importlib
import json
import os
import importlib.util
from pathlib import Path
import statistics
import sys
import types

import torch
import torch_npu
import pypto.torch
from vllm.config import CUDAGraphMode
from vllm.engine.arg_utils import EngineArgs
from vllm.forward_context import get_forward_context
from vllm.platforms import current_platform
from vllm_ascend.ascend_forward_context import set_ascend_forward_context
import vllm_ascend.ops.dsv4_csa
from dsv4_csa_native_case import native_session
from dsv4_csa_single_layer import make_layer, restore, collect_state, guard_checks
from ragged_fixture import make_ragged_fixture
from npugraph_ex._acl_concrete_graph.acl_graph import AclGraph

ROOT = (Path(__file__).resolve().parent/'../tools').resolve()
BASE = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
META_SHA = '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--lengths', default='1,1,1,1')
parser.add_argument('--layer', type=int, default=4)
parser.add_argument('--history', type=int, default=8191)
parser.add_argument('--mode', choices=('timing','dfx','dep'), default='timing')
args = parser.parse_args()
lengths = list(map(int,args.lengths.split(',')))
tokens, batch = sum(lengths), len(lengths)
assert all(1<=q<=6 for q in lengths) and batch<=40 and tokens<=256
assert all(q==6 for q in lengths), 'four-arm comparison uses uniform S6: Nal NativeCSACall adapter requires it'
assert not (args.out/'result.json').exists()
args.out.mkdir(parents=True,exist_ok=True)
expected_helpers=json.loads((ROOT/'manifest.json').read_text())
helper_sha={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in expected_helpers}
assert helper_sha==expected_helpers,'helper source identity mismatch'
report_runner_sha=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
manifest_sha=hashlib.sha256((ROOT/'manifest.json').read_bytes()).hexdigest()
report = {'runner_sha256':report_runner_sha,'helper_sha':helper_sha,'manifest_sha256':manifest_sha,'complete':False,'pass':False,'scope':'real layer weights, synthetic hidden/history, Native/TND complete CSA half-layer FULL graph; not whole model',
          'lengths':lengths,'true_tokens':tokens,'physical_graph_tokens':tokens,'per_request_padding':0,
          'hypothetical_s6_tokens':batch*6,'hypothetical_s6_extra_rows':batch*6-tokens,
          'baseline_experiment':'Native direct HC-pre through HC-post', 'candidate_experiment':'Native-SK0/frozen-precision/physical-row-predecode-A-same-SDK',
          'candidate_variant':'three complete CSA arms; address representation only; no wait helper rewriting',
          'layer':args.layer,'history':args.history,'graphs':{},'comparisons':{},'static':{}}
def save():
    (args.out/'result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
def exact(x,y):
    return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def metric(x,y):
    if x.shape!=y.shape or x.dtype!=y.dtype:
        return {'bit_equal':False,'shapes':[list(x.shape),list(y.shape)],'dtypes':[str(x.dtype),str(y.dtype)]}
    if x.is_floating_point():
        assert bool(torch.isfinite(x).all()) and bool(torch.isfinite(y).all()), 'nonfinite external float boundary'
    equal=exact(x,y)
    delta=x.float()-y.float()
    return {'bit_equal':equal,'different_elements':int((x!=y).sum()),'max_abs':float(delta.abs().max()),
            'relative_l2':float(torch.linalg.vector_norm(delta)/torch.linalg.vector_norm(y.float()).clamp_min(1e-30)),
            'first_coordinates':(x!=y).nonzero()[:6].tolist()}

import vllm_ascend.ops.pypto as spmd_namespace
experiment=Path(os.environ['SPMD_EXPERIMENT'])
spmd_namespace.__path__.insert(0,str(experiment/'src/vllm_ascend/ops/pypto'))
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.native_adapter import CSAOperators
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.service import CSAServiceRuntime
from source_identity import source_identity
source_record=source_identity()
report.update(source_record)
import vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.decode_csa as formal_root
assert Path(formal_root.__file__).resolve().is_relative_to(experiment/'src')
package=Path(formal_root.__file__).resolve().parent
candidate_sources={q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in package.glob('*.py')}
receipt=json.loads((experiment/'compile-full-csa-bf16layout.json').read_text())
assert receipt['compiled'] and receipt['kernel_mode_abi_pass'] and receipt['torch_dispatcher_registration_pass']
assert receipt['formal_prepare_program_compiled'] and receipt['formal_prepare_kernel_mode_abi_pass'] and receipt['formal_operators_registered']
assert receipt['sources']==candidate_sources
assert receipt['baseline_sources']==source_record['tested_sources']
parent=package.with_name('deepseek_v4_flash_csa_tnd_precision_spmd')
assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in parent.glob('*.py')}==receipt['parent_spmd_sources']
report['parent_spmd_sources']=receipt['parent_spmd_sources']
parent_prepack=package.with_name('deepseek_v4_flash_csa_tnd_precision_spmd_prepack')
assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in parent_prepack.glob('*.py')}==receipt['parent_prepack_sources']
report['parent_prepack_sources']=receipt['parent_prepack_sources']
accepted=package.with_name('deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout')
assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in accepted.glob('*.py')}==receipt['accepted_bf16_sources']
report['accepted_bf16_sources']=receipt['accepted_bf16_sources']
report['candidate_sources']=candidate_sources
report['candidate_package']=str(package)
report['compile_receipt_sha256']=hashlib.sha256((experiment/'compile-full-csa-bf16layout.json').read_bytes()).hexdigest()
report['formal_root_file']=formal_root.__file__

class NativeHalf(torch.nn.Module):
    def __init__(self,layer):
        super().__init__();self.layer=layer
    def forward(self,hidden,positions,output):
        l=self.layer
        mixed,post,comb=l.hc_pre(hidden,l.hc_attn_fn,l.hc_attn_scale,l.hc_attn_base)
        normed=l.input_layernorm(mixed)
        attended=l.self_attn(positions=positions,hidden_states=normed,llama_4_scaling=None)
        output.copy_(l.hc_post(attended,hidden,post,comb))
        return output

class PTOHalf(torch.nn.Module):
    def __init__(self,prefix):
        super().__init__();self.prefix=prefix
    def forward(self,hidden,positions,output):
        torch.ops.vllm.dsv4_csa_forward(hidden,positions,output,self.prefix)
        return output

class RequirePTO:
    def __init__(self,delegate):
        self.delegate,self.calls=delegate,0
    def eligible(self,*values):
        if not self.delegate.eligible(*values):
            raise RuntimeError('Unexpected PTO fallback')
        return True
    def __call__(self,*values,**kwargs):
        self.calls+=1
        return self.delegate(*values,**kwargs)

os.environ['VLLM_ASCEND_ENABLE_NZ']='2'
os.environ['VLLM_ASCEND_PTO_CSA_ATOMIC_ADD']='0'
reference=ROOT.parent/'reference/vllm_ascend/ops/pypto'
private=types.ModuleType('nal_isolated');private.__path__=[str(reference)];sys.modules[private.__name__]=private
nal_adapter=importlib.import_module('nal_isolated.deepseek_v4_flash_csa.native_adapter')
nal_root=importlib.import_module('nal_isolated.deepseek_v4_flash_csa.decode_csa')
nal_binding=importlib.import_module('nal_isolated.deepseek_v4_flash_csa_spmd.binding')
assert nal_root.__file__.startswith(str(reference))
reference_proof=json.loads((ROOT.parent/'REFERENCE_SOURCE_PROOF.json').read_text())
assert all(hashlib.sha256((ROOT.parent/'reference'/name).read_bytes()).hexdigest()==sha for name,sha in reference_proof['files'].items())
report['nal_source_proof']=reference_proof

current_platform.pre_register_and_update()
torch.npu.set_device(0)
torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
from vllm_ascend.utils import enable_custom_op
assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,
 tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},
 max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,
 enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},
 compilation_config={'cudagraph_mode':'FULL_DECODE_ONLY','cudagraph_capture_sizes':[tokens],'cache_dir':str(args.out/'vllm-cache')},
 additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},
 'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False,'multistream_dsv4_dsa_overlap':True}).create_engine_config()

states, fixtures, rows, keepalive, b_states = {}, {}, {}, [], {}
nal_workspaces={}
nal_signals={}
def check_guards(arm, fixture):
    checks=guard_checks(fixture)
    assert all(value['status']=='PASS' for value in checks.values()),(arm,'external guards',checks)
    if arm in nal_workspaces:
        assert all(torch.all(v[:g].cpu()==37) and torch.all(v[-g:].cpu()==37)
                   for v,g in nal_workspaces[arm].values()),(arm,'workspace guards')
def signal_generation(arm):
    if arm not in nal_signals:return None
    values=nal_signals[arm].cpu().reshape(60,72,128)
    assert torch.all(values[:,:,1:]==0),(arm,'signal isolation padding changed')
    generation=values[0,:,0]
    assert torch.all(generation==generation[0]) and int(generation[0])>0,(arm,'generation disagreement')
    return int(generation[0])
save()
try:
 with native_session(config,0),torch.inference_mode():
    layer,details=make_layer(config,checkpoint,torch.device('npu:0'),args.layer)
    report['weight_details']=details
    report['native_DSA_multistream_config']=bool(layer.self_attn.dsa_attn.dsa_attn.impl.multistream_dsv4_dsa_overlap)
    assert report['native_DSA_multistream_config']
    pypto.torch.init(enable_chip_swimlane=1 if args.mode=='dfx' else 0, enable_dep_gen=args.mode=='dep', output_dir=args.out/'dfx' if args.mode!='timing' else None)
    nal_dispatch=pypto.torch.register(nal_root.decode_csa_tp1_layer_test,'nal_full_compare::multi')
    report['nal_multitask_schema']=str(nal_dispatch._schema)
    impl=layer.self_attn.dsa_attn.dsa_attn.impl
    observed={}
    original_qli=torch.ops._C_ascend.npu_vllm_quant_lightning_indexer
    def observe_qli(*values,**kwargs):
        result=original_qli(*values,**kwargs);observed['topk']=result[0];return result
    torch.ops._C_ascend.npu_vllm_quant_lightning_indexer=observe_qli
    # 保留原13包校验桥；只在首次真实reselect后复用选择，禁止捕获之后变更选择。
    selection=[]
    original_reselect=torch_npu.npu._aclnn_reselect_static_kernel
    def qualified_reselect(*values,**kwargs):
        assert hashlib.sha256((Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE'])/'metadata.json').read_bytes()).hexdigest()==META_SHA
        assert not values and not kwargs
        if not selection:
            selection.append(original_reselect())
            report['static']['actual_reselect_count']=1
        else:
            report['static']['validated_reuses']=report['static'].get('validated_reuses',0)+1
        report['static']['metadata_sha256']=META_SHA
        return selection[0]
    # 框架可能已from-import compile_static_kernel；在实际API边界观测，避免漏掉别名调用。
    torch_npu.npu._aclnn_reselect_static_kernel=qualified_reselect

    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.native_adapter import CSAOperators as SerialOperators
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.service import CSAServiceRuntime as SerialRuntime
    for arm in ('native','candidate','physical_a'):
        assert torch.are_deterministic_algorithms_enabled()
        assert torch_npu._C._npu_get_deterministic_level()==1
        report.setdefault('determinism',{})[arm]={'torch_enabled':True,'npu_level':1,'HCCL_DETERMINISTIC':os.environ.get('HCCL_DETERMINISTIC')}
        print('ARM_START',arm,flush=True)
        torch._dynamo.reset()
        f=make_ragged_fixture(config,layer.self_attn,batch,args.history,1024,torch.device('npu:0'),lengths)
        fixtures[arm]=f
        if arm!='native':
            for field in ('hidden','positions'):
                assert exact(f[field],fixtures['native'][field]),(arm,field)
            for name,g in f['groups'].items():
                assert exact(g['initial'],fixtures['native']['groups'][name]['initial']),(arm,name)
            assert f['readonly'].keys()==fixtures['native']['readonly'].keys()
            for name,(_,snapshot) in f['readonly'].items():
                assert exact(snapshot,fixtures['native']['readonly'][name][1]),(arm,name,'metadata input differs')
            for name,parts in f['compact'].items():
                assert all(exact(x,y) for x,y in zip(parts,fixtures['native']['compact'][name])),(arm,name,'compact metadata differs')
        for name,g in f['groups'].items():
            table=f['metadata'][g['prefix']].decode.block_table.cpu()
            assert g['pages']<(1<<24) and bool(torch.all(table[table>=0]<(1<<24)))
        runtime=None
        if arm in ('candidate','physical_a'):
            operators=(SerialOperators if arm=='serial' else CSAOperators).register()
            if arm=='physical_a':
                sys.path.insert(0,str(ROOT.parent/'physical-plan'))
                from load_candidate import load_candidate
                root=load_candidate(formal_root)
                operators=CSAOperators(pypto.torch.register(root,'csa_physical_a::attention'),operators.workspace)
                report['physical_a_source_proof']=json.loads((ROOT.parent/'physical-plan/SOURCE.json').read_text())

            with torch.inference_mode(False), torch.enable_grad():
                keepalive.append(layer.hc_attn_fn)  # Retain captured Native weight storage.
                layer.hc_attn_fn=torch.nn.Parameter(layer.hc_attn_fn.detach().clone(),requires_grad=True)
                runtime=(SerialRuntime if arm=='serial' else CSAServiceRuntime)(layer.self_attn,operators,40,layer)
                report['model_loading_prepare_context']={'grad_enabled_after_constructor':torch.is_grad_enabled(),'source_requires_grad':layer.hc_attn_fn.requires_grad,'source_inference':torch.is_inference(layer.hc_attn_fn),'packed_requires_grad':runtime.weights['hc_packed_weight'].requires_grad}
                assert torch.is_grad_enabled() and layer.hc_attn_fn.requires_grad
                assert not runtime.weights['hc_packed_weight'].requires_grad

            from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.workspace import NORM_PARAMETERS
            norm_offset=0
            norm_packet_checks={}
            for name,size in NORM_PARAMETERS:
                norm_packet_checks[name]=exact(runtime.norm_packet[norm_offset:norm_offset+size].cpu(),runtime.weights[name].cpu())
                norm_offset+=size
            assert norm_offset==6272 and all(norm_packet_checks.values())
            order_checks={}
            for (w,i,o),packet in operators.workspace.order_packets.items():
                cpu=packet.cpu()
                order_checks[str((w,i,o))]=all((exact(cpu[:512],runtime.wkv_orders[w].cpu().reshape(-1)),
                    exact(cpu[512:1536],runtime.indexer_orders[i].cpu().reshape(-1)),
                    exact(cpu[1536:],runtime.oproj_starts[o].cpu().reshape(-1))))
            assert len(order_checks)==33 and all(order_checks.values())
            report['packet_checks']={'norm_byte_equal':norm_packet_checks,'order_byte_equal':order_checks,
                'norm_bytes_per_layer':runtime.norm_packet.numel()*runtime.norm_packet.element_size(),
                'order_bytes_per_model':sum(t.numel()*t.element_size() for t in operators.workspace.order_packets.values())}
            readonly_packets={'norm':runtime.norm_packet,'hc_packed':runtime.weights['hc_packed_weight'],**{str(k):v for k,v in operators.workspace.order_packets.items()}}
            packet_snapshots={k:v.cpu() for k,v in readonly_packets.items()}
            report['hc_weight_qualification']=dict(runtime.hc_weight_qualification)
            assert report['hc_weight_qualification']['version']==1
            assert selection,'Native graph did not install and select static packages'
            runtime.qualify_static_wkv(metadata_sha256=META_SHA,reselected=True)
        @contextlib.contextmanager
        def context():
            with set_ascend_forward_context(f['metadata'],config,num_tokens=tokens,num_actual_tokens=tokens,
                                            aclgraph_runtime_mode=CUDAGraphMode.FULL):
                assert get_forward_context().cudagraph_runtime_mode is CUDAGraphMode.FULL
                yield
        if runtime is not None:
            with context():
                eligible=runtime.eligible(get_forward_context(),f['hidden'],f['positions'])
            report.setdefault('entry',{})[arm]={'eligible':eligible,'route':'PTO' if eligible else 'Native fallback','metadata':{
                name:{'bounds':f['metadata'][g['prefix']].decode.query_start_loc.cpu().tolist(),
                      'max_q':f['metadata'][g['prefix']].decode.max_seqlen_q,
                      'num_decodes':f['metadata'][g['prefix']].num_decodes,
                      'actual_tokens':f['metadata'][g['prefix']].num_actual_tokens} for name,g in f['groups'].items()}}
            save()
            assert eligible, 'TND precision fallback is forbidden'
            guarded=RequirePTO(runtime)
            layer.self_attn.dsa_attn._pto_csa_runtime=guarded
        else:
            layer.self_attn.dsa_attn._pto_csa_runtime=None
        output=torch.empty_like(f['hidden'])
        nal_call=None
        if arm.startswith('nal_'):
            groups={name:(f['metadata'][g['prefix']],g['views']) for name,g in f['groups'].items()}
            weights=nal_adapter.prepare_weights(layer.self_attn,groups['indexer'][0].hadamard,layer)
            topk_buffer=torch.empty((tokens,512),dtype=torch.int32,device='npu')
            score_buffer=torch.empty((tokens,512),dtype=torch.float32,device='npu')
            nal_call=nal_adapter.NativeCSACall(types.SimpleNamespace(attention=nal_dispatch),weights,
                f['hidden'],f['positions'],groups,layer_name=layer.self_attn.dsa_attn.dsa_attn.layer_name,
                compact_metadata=f['compact'],buffers={'idx_topk_scores':score_buffer,'idx_topk':topk_buffer,'x_out':output})
            from pypto.runtime import CompileOptions
            nal_config=CompileOptions(platform='a2a3',output_dir=str(args.out/(arm+'-kernel')))
            allocations={}
            def nal_allocate(name,shape,dtype,device):
                count=1
                for size in shape:count*=size
                guard=512//torch.empty((),dtype=dtype).element_size()
                owner=torch.full((count+2*guard,),37,dtype=dtype,device=device)
                allocations[name]=(owner,guard)
                return owner[guard:-guard].view(shape)
            if arm=='nal_spmd':
                prepared=nal_binding.PreparedDynamicCSA(nal_call.args,max_query_tokens=6,max_seq_len=args.history+6,allocator=nal_allocate)
                report['nal_spmd_policy']=prepared.policy.constexprs()
                report['nal_spmd_shapes']={name:list(v.shape) for name,v in prepared.buffers.items()}
                nal_signals[arm]=prepared.buffers['signal']
                runner=lambda p=prepared,c=nal_config:p(config=c)
            else:
                runner=lambda a=nal_call.core_args,c=nal_config:nal_root.decode_csa_tp1_layer_test(*a,config=c)
            if args.mode!='timing':
                # Reuse the exact successfully executed unmodified DSL binary;
                # the direct JIT calls these same launch APIs after compilation.
                from pypto.ir._kernel_compile import kernel_abi_for_program
                from pypto.runtime._kernel_artifact import KernelArtifact
                from pypto.runtime.kernel.context import get_process_kernel_state
                from pypto.torch.launch import describe_eager_call, invoke
                root_program=(importlib.import_module('nal_isolated.deepseek_v4_flash_csa_spmd.entry').decode_csa_spmd.specialize(**prepared.policy.constexprs())
                              if arm=='nal_spmd' else nal_root.decode_csa_tp1_layer_test.specialize())
                abi=kernel_abi_for_program(root_program,platform='a2a3',runtime='tensormap_and_ringbuffer')
                binary_root=Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020/results/nal-full-four-arm-8k-b16-v5')/(arm+'-kernel')
                prior_path=binary_root.parent/'result.json'
                prior=json.loads(prior_path.read_text())
                assert prior['pass'] and prior['complete']
                assert (args.layer,args.history,batch,tokens)==(4,8191,16,96)
                assert prior['lengths']==lengths and prior['nal_source_proof']==reference_proof
                if arm=='nal_spmd':assert prior['nal_spmd_policy']==prepared.policy.constexprs()
                binary_manifest=json.loads((binary_root/'binary_manifest.json').read_text())
                binary_files=[entry['binary'] for entry in binary_manifest['kernels']]
                binary_files.append(binary_manifest['orchestration']['binary'])
                for entry in binary_files:
                    blob=(binary_root/entry['path']).read_bytes()
                    assert len(blob)==entry['size'] and hashlib.sha256(blob).hexdigest()==entry['sha256']
                sealed_files={name:hashlib.sha256((binary_root/name).read_bytes()).hexdigest()
                              for name in ['compiled_meta.json','kernel_config.py','binary_manifest.json']+[x['path'] for x in binary_files]}
                artifact=KernelArtifact(binary_root,abi)
                from pypto.runtime._prebuilt import load_prebuilt
                from pypto.jit._artifact_manifest import BuildKind
                artifact._loaded=load_prebuilt(binary_root,abi.platform,BuildKind.SINGLE_CHIP,kernel_abi=abi)['.']
                assert all(hashlib.sha256((binary_root/name).read_bytes()).hexdigest()==sha for name,sha in sealed_files.items())

                values=tuple(prepared.buffers[param.name] for param in abi.parameters) if arm=='nal_spmd' else nal_call.core_args
                target=get_process_kernel_state().require_config()
                runner=lambda a=artifact,v=values,t=target:invoke(a,describe_eager_call(a.kernel_abi,v,t),t)
                report.setdefault('reused_DSL_artifacts',{})[arm]={'path':str(binary_root),'identity':artifact.identity().hex(),'tensor_args':len(abi.parameters),'source_result_sha256':hashlib.sha256(prior_path.read_bytes()).hexdigest(),'files':sealed_files}
                keepalive.append((artifact,values,target))
            for weight_name in ('wq_a','wq_b','wo_a','wo_b'):
                assert weights[weight_name].data_ptr()==getattr(layer.self_attn,weight_name).weight.data_ptr(),(arm,weight_name,'root weight not zero-copy native NZ')
            report.setdefault('nal_weights',{})[arm]={name:{'shape':list(v.shape),'dtype':str(v.dtype),'format':int(torch_npu.get_npu_format(v))} for name,v in weights.items()}
            restore(f);runner();torch.npu.synchronize()
            compiled_state=collect_state(f,output,topk_buffer)
            stream=torch.npu.Stream();stream.wait_stream(torch.npu.current_stream())
            with torch.npu.stream(stream):
                graph=torch.npu.NPUGraph()
                with torch.npu.graph(graph,stream=stream):runner()
            torch.npu.synchronize()
            topk=topk_buffer
            compiled=runner;module=None;owner=graph
            keepalive.append((nal_call,prepared if arm=='nal_spmd' else None,runner,nal_config,allocations))
            report.setdefault('nal_guards',{})[arm]={'checked':False}
        else:
            module=NativeHalf(layer) if arm=='native' else PTOHalf(layer.self_attn.dsa_attn.prefix)
            restore(f)
            with context():module(f['hidden'],f['positions'],output)
            torch.npu.synchronize()
        instances={}
        if not arm.startswith('nal_'):
            old_run=AclGraph.run
            def record(owner,key,*values,**kwargs):
                instances[(id(owner),key)]=owner
                return old_run(owner,key,*values,**kwargs)
            AclGraph.run=record
            options={'force_eager':False,'inplace_pass':True,'clone_input':False,'clone_output':False,
                     'static_kernel_compile':True,'super_kernel_optimize':False}
            torch.npu.set_compile_mode(jit_compile=False)
            try:
                compiled=torch.compile(module,backend='npugraph_ex',fullgraph=True,dynamic=False,options=options)
                restore(f)
                with context():compiled(f['hidden'],f['positions'],output)
                torch.npu.synchronize()
                assert len(instances)==1,(arm,'not exactly one actual graph',len(instances))
                (_,key),owner=next(iter(instances.items()))
                assert not owner._updated_node_infos,'Host updated nodes invalidate raw replay test'
                graph=owner.graph[key]
            finally:
                AclGraph.run=old_run
            topk=runtime.topk[:tokens] if runtime is not None and report['entry'][arm]['eligible'] else observed['topk']
        compiled_state=collect_state(f,output,topk)
        restore(f);output.fill_(float('nan'));topk.fill_(-12345);graph.replay();torch.npu.synchronize()
        actual=collect_state(f,output,topk)
        assert all(exact(value,compiled_state[name]) for name,value in actual.items()),(arm,'compiled/raw mismatch')
        assert torch.isfinite(output).all()
        if arm.startswith('nal_'):
            assert all(torch.all(v[:g].cpu()==37) and torch.all(v[-g:].cpu()==37) for v,g in allocations.values()),(arm,'private workspace guard')
            report['nal_guards'][arm]['checked']=True
        guards=guard_checks(f)
        assert all(value['status']=='PASS' for value in guards.values()),(arm,'guard',guards)
        states[arm]=actual
        rows[arm]=(graph,f,output,topk)
        if arm.startswith('nal_'):nal_workspaces[arm]=allocations
        keepalive.append((compiled,module,owner,runtime))
        report['graphs'][arm]={'actual_acl_graph':True,'fullgraph':True,'options':options if not arm.startswith('nal_') else {'capture':'direct warmed native JIT raw FULL NPUGraph'},
                                'true_tokens':tokens,'graph_tokens':tokens,'guards':guards,'compiled_raw_equal':True,
                                'topk_poison_replay_restored':True,'native_super_kernel_optimize':False}
        if arm!='native':
            checks={name:metric(value,states['native'][name]) for name,value in actual.items()}
            report['comparisons'][arm]=checks
            save()
            if arm in ('candidate','physical_a') and not all(check['bit_equal'] for check in checks.values()):
                report['first_failed_arm']=arm
                report['failed_boundaries']=[name for name,m in checks.items() if not m['bit_equal']]
                raise RuntimeError(arm+': first bit difference; stop matrix and timing')
        before=f['hidden'].clone()
        restore(f);f['hidden'].add_(0.125);graph.replay();torch.npu.synchronize()
        assert not exact(output.cpu(),actual['x_out']),(arm,'stale input graph')
        b_states[arm]=collect_state(f,output,topk)
        if arm!='native':
            b_checks={name:metric(value,b_states['native'][name]) for name,value in b_states[arm].items()}
            report.setdefault('B_comparisons',{})[arm]=b_checks;save()
            if arm in ('candidate','physical_a') and not all(check['bit_equal'] for check in b_checks.values()):
                torch.save(b_states,args.out/'first-B-difference.pt')
                raise RuntimeError('TND input B first bit difference; stop')
        assert all(value['status']=='PASS' for value in guard_checks(f).values()),(arm,'B guards')
        f['hidden'].copy_(before);restore(f);graph.replay();torch.npu.synchronize()
        restored=collect_state(f,output,topk)
        assert all(exact(value,actual[name]) for name,value in restored.items()),(arm,'A restore')
        check_guards(arm,f)
        report['graphs'][arm]['live_input_ABA']=True
        if runtime is not None:
            assert guarded.calls>0,'PTO runtime was never invoked'
            report['graphs'][arm]['pto_dispatch_calls']=guarded.calls
            schema=str(runtime.operators.attention._schema)
            expected_namespace=('dsv4_csa_tnd_precision_spmd_bf16layout::attention' if arm=='serial' else 'dsv4_csa_tnd_precision_spmd_overlap::attention')
            if arm=='physical_a':expected_namespace='csa_physical_a::attention'
            assert schema.startswith(expected_namespace+'('),(arm,schema)
            assert schema.split(' -> ')[0].count('Tensor')==64,(arm,schema)
            report['graphs'][arm]['root_schema']=schema
            report['workspace_bytes']=sum(v.numel()*v.element_size() for v in operators.workspace.buffers.values())
            report['hc_packed_weight_bytes']=runtime.weights['hc_packed_weight'].numel()*runtime.weights['hc_packed_weight'].element_size()
            report['workspace_capture_stream']=operators.workspace.capture_stream
        save()
        print('ARM_PASS',arm,flush=True)
    def restore_readonly(fixture):
        for live,expected in fixture['readonly'].values():live.copy_(expected)
    report['cross_bucket_scope']='same L4/hidden/history/metadata/cache start, complete CSA; frozen and physical-A both require Native bit equality'
    report['timing_boundary_note']='all arms raw FULL graph CUDA/NPU events; Native and our graph captured by npugraph_ex, Nal direct JIT warmed before raw capture; no C++ source transform'
    for arm,allocs in nal_workspaces.items():
        assert all(torch.all(v[:g].cpu()==37) and torch.all(v[-g:].cpu()==37) for v,g in allocs.values())
    samples={arm:[] for arm in rows}
    arms=list(rows)
    for arm in arms:
        graph,f,output,topk=rows[arm]
        restore(f)
        for warm in range(3):graph.replay()
    torch.npu.synchronize()
    for arm in arms:check_guards(arm,rows[arm][1])
    report['signal_checks']=[]
    if args.mode in ('dfx','dep'):
        windows=[]
        for arm in arms:
            if arm=='native':continue
            graph,f,output,topk=rows[arm]
            for repeat in range(3):
                restore(f);restore_readonly(f);torch.npu.synchronize()
                before_generation=signal_generation(arm)
                pypto.torch.begin_dfx();graph.replay();pypto.torch.end_dfx()
                after_generation=signal_generation(arm)
                if before_generation is not None:
                    assert after_generation==before_generation+1
                    report['signal_checks'].append({'arm':arm,'mode':'dfx','before':before_generation,'after':after_generation})
                actual=collect_state(f,output,topk)
                assert all(exact(value,states[arm][name]) for name,value in actual.items()),(arm,'DFX state drift')
                assert all(g['status']=='PASS' for g in guard_checks(f).values()),(arm,'DFX guards')
                check_guards(arm,f)
                windows.append({'arm':arm,'repeat':repeat})
        report['DFX']={'level':1 if args.mode=='dfx' else 0,'enable_dep_gen':args.mode=='dep','windows':windows,'scope':'three-arm per-task envelopes; single Nal MIX does not expose internal stage clocks'}
    else:
        for round_id in range(12):
            order=arms[round_id%len(arms):]+arms[:round_id%len(arms)]
            if (round_id//len(arms))%2:order=list(reversed(order))
            for arm in order:
                graph,f,output,topk=rows[arm]
                restore(f);restore_readonly(f)
                assert all(c['status']=='PASS' for c in guard_checks(f).values())
                torch.npu.synchronize()
                before_generation=signal_generation(arm)
                start,end=torch.npu.Event(enable_timing=True),torch.npu.Event(enable_timing=True)
                start.record()
                for iteration in range(100):graph.replay()
                end.record();end.synchronize()
                after_generation=signal_generation(arm)
                if before_generation is not None:
                    assert after_generation==before_generation+100
                    report['signal_checks'].append({'arm':arm,'mode':'timing','before':before_generation,'after':after_generation})
                samples[arm].append(start.elapsed_time(end)*1000/100)
                actual=collect_state(f,output,topk)
                assert all(exact(value,states[arm][name]) for name,value in actual.items()),(arm,'timing state drift')
                assert all(g['status']=='PASS' for g in guard_checks(f).values()),(arm,'timing guards')
                if arm in nal_workspaces:
                    assert all(torch.all(v[:g].cpu()==37) and torch.all(v[-g:].cpu()==37) for v,g in nal_workspaces[arm].values()),(arm,'private timing guard')
        report['timings']={'windows':12,'replays_per_window':100,'outliers_removed':False,'unit':'us/complete HC-pre through HC-post raw graph replay; Native SK0; determinism1; no DFX',
            'samples':samples,'summary':{arm:{'min':min(v),'mean':statistics.mean(v),'median':statistics.median(v),'max':max(v)} for arm,v in samples.items()}}
    assert all(exact(v.cpu(),packet_snapshots[k]) for k,v in readonly_packets.items()), 'readonly packet changed'
    report['packet_checks']['readonly_after_replay']=True
    report['timing_executed']=args.mode=='timing'
    if False:
        for arm in arms:
            graph,f,output,topk=rows[arm]
            restore(f);restore_readonly(f);torch.npu.synchronize()
            with torch_npu.profiler.profile(activities=[torch_npu.profiler.ProfilerActivity.CPU,torch_npu.profiler.ProfilerActivity.NPU],record_shapes=True) as prof:
                for _ in range(3):graph.replay()
                torch.npu.synchronize()
            prof.export_chrome_trace(str(args.out/(arm+'-trace.json')))
            actual=collect_state(f,output,topk)
            assert all(exact(value,states[arm][name]) for name,value in actual.items()),(arm,'posttrace state drift')
        assert all(g['status']=='PASS' for g in guard_checks(f).values()), 'trace guards'
        assert all(exact(v.cpu(),packet_snapshots[k]) for k,v in readonly_packets.items()), 'trace packets'
        report['trace_separate_from_timing']=True
    def tensor_identity(v):
        c=v.detach().contiguous().cpu()
        return {'shape':list(c.shape),'dtype':str(c.dtype),'sha256':hashlib.sha256(c.view(torch.uint8).numpy().tobytes()).hexdigest()}
    report['saved_native_identity']={n:tensor_identity(v) for n,v in states['native'].items()}
    report['saved_native_inputs']={n:tensor_identity(fixtures['native'][n]) for n in ('hidden','positions')}
    report['saved_native_initial_cache']={n:tensor_identity(v['initial']) for n,v in fixtures['native']['groups'].items()}
    report['complete']=report['pass']=True
    save()
except Exception as exc:
    report['error']=repr(exc)
    save()
    torch.save({'states':states,'inputs':{arm:{'hidden':f['hidden'].cpu(),'positions':f['positions'].cpu(),
                    'initial':{name:g['initial'] for name,g in f['groups'].items()}} for arm,f in fixtures.items()}},args.out/'first-difference.pt')
    raise
print('COMPLETE',report['pass'],lengths,flush=True)
