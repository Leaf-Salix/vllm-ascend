# 共同CompressorMetadata范围：独立审查

## 结论

当前`--nal-metadata-producer`版本静态无已知执行阻断，可在保留原v5/DFX材料前提下做独立common范围测试。review没有执行设备、编译或修改源。当前probe/run SHA及helper验证见同名JSON。

## 已核对

- flag进入timing时也使用已审read-only Artifact恢复分支，artifact/target在定义wrapper前存在；没有再次JIT编译或修改已验收DSL。
- runner默认参数绑定本臂nal_call/prepared/groups/impl，不在raw replay时读取下一臂的Python变量。`prepared if arm=='nal_spmd' else None`对Multi不会访问未绑定prepared。
- 每次调用先对当前compressed/indexer metadata的decode对象各调用一次Native `_compute_compressor_metadata`，同一实现消费full RoPE/query bounds/start_pos/block table等真实Native输入。
- Multi覆盖`cmp_freqs_cos/sin`、`inner_freqs_cos/sin`、`cmp_slot_mapping`、`idx_slot_mapping`，与NativeCSACall ABI字段一致。
- SPMD覆盖`main_cos/sin/slots`及`idx_cos/sin/slots`，与PreparedDynamicCSA映射/entry签名一致；原state_slots等独立语义未被覆盖。
- 输出cos/sin通过view(-1,64)绑定同storage，slots直接绑定；只复制Python参数字典，不新增Tensor拷贝，不改weight/cache或PTO数学。然后严格按artifact ABI参数名取新值，避免prepared旧参数tuple仍引用旧compact输出。
- 在raw NPUGraph capture内调用两个Nativeproducer并随后invoke，新输出的依赖经原Torch队列/stream进入PTO，Tensor所有权由既有native.prepare/capture路径持有。原fixture/cache/metadata比对、A/B/A、guard、Nal信号代际仍保留。

## 必须限定的证据

建议记录capture路径每组1次、总2次producer观测及新输出shape/dtype与旧fixture.compact的逐位一致；实际图/trace确认两个CompressorMetadata节点。当前`nal_metadata_producer_in_graph=True`仅源级flag，不能单独作为硬件节点已经捕获的证据。执行时若producer在内部流，应保留实际依赖/join证据。

本轮metadata固定，hidden A/B变化不会改变这些metadata；即使本测试通过也只能证明该固定几何下共同producer范围，不代表动态metadata更新/跨桶/整模型资格。

原v5应保留原数值并注明我方raw图含两个Nativeproducer，而Nal direct roots消费捕获前compact，所以旧事件不是完全共同producer范围；新测试另列common-metadata后结果，不能覆盖或重新标记原v5。

旧L1仅观察PTO核内记录，首末跨度仍可作为相同fixture下各自PTO任务覆盖范围，但包括内部wait和task间隙，也可能受外部调度影响，不能称纯计算时间；不能简单从旧事件差中减掉新producer开销来推导精确优化空间。
