# 完整CSA同口径比较：独立方案审查

## 结论与范围

当前CHECKLIST的顺序合理：先固定实际源码/环境并测完整边界，再用可观察证据选单因素。现有Nal脚本不能直接作为本轮三方计时器；需要修正下列口径后再做设备前审查。本报告没有新的硬件结论，也没有判定某个模块已经是最大差距来源。

本次独立读取了本目录上一层的Nal执行脚本、L1助手、SDK记录及归档源码；文件SHA见`INDEPENDENT_PLAN_REVIEW_INPUTS.json`。我方正式分支为主线程报告的`ac80d0e3b`，冻结数学为`48c58ce7c`。Nal已归档控制是`beaefa6f6788a9448d49293238f6818c246f24f5`；主线程刚获取的`91c4400e19ec10bd96e8de6314376f29229f6e0e`尚不在本报告源码审查范围，不能把旧控制的资格转给新提交。

## 一、现有助手的具体限制

| 文件/位置 | 实际行为 | 本轮处理 |
| --- | --- | --- |
| `nal-run-device.py:134` | `set_deterministic_level(0)` | 三方显式统一level1及所需确定性环境，并记录实际值；不可沿用默认0 |
| 同文件`:102–104,356–366` | `native_attention_run=False`，金值来自旧`decode_csa_tp1_layer_test`动态PTO | 不能称Native对拍。Native独立生成我方严格金值；Nal数值差异单独报告 |
| 同文件`:263–266` | L1时同时开启dependency generation | 计时DFX必须关闭dep-gen；依赖图单独运行 |
| 同文件路径常量/辅助导入 | `HERE/BASE_D/REPO`按原测试位置解析，依赖多个同目录工具 | 搬到R20后的文件不是可直接执行的发行包；显式绑定工具根、源码根、helper SHA |
| 同文件`:266–335` | 独立外部分配工作区，准备policy/weights，signal初次清零 | 这些是否在捕获外、是否计入服务入口成本要明示，不能只给“完整CSA”标签 |
| `nal-l1-compare.py:20,71` | 六列记录idx3/4形成首incore至末incore跨度 | 这是incore envelope，不是AICPU包含在内的端到端执行时间 |
| 同文件`:130–145` | 独立begin/end DFX；只在最后窗口复验状态 | 新助手各窗口保留数值/协议检查，恢复及检查在计时窗口外 |

归档bea的`entry.py`已明确使用device Q/L和真实请求边界，不要求固定S6；`binding.py`按动态T/B容量准备缓冲。因此本轮应叫“Nal动态完整SPMD”，不能沿用旧a919分支的BSH固定S6标签。uniform S6适合作为共同输入子集；真实不等长TND资格另测，不为速度强制padding。

## 二、共同输入与完整边界

建议首个受控点为8K/B16、T96、均匀S6，真实第4层权重和同一份合成hidden/history。`history=8191`等具体值必须以实际fixture记录为准；“8K”标签不能替代positions、seq_lens与有效历史容量。默认脚本history=131072不能直接使用。

必须固定并写出：

1. 三方权重的来源层、shape/dtype/NZ2、逻辑值与实际布局SHA；一次性转置/打包在捕获外。禁止借dtype转换改变我方Native计算边界。
2. hidden/positions、五组Q/L、compact RoPE、slot mapping、block table、cache/state初值及索引scale的非均匀内容。每臂独立可写cache和工作区，不能让上一臂写入成为下一臂初值。
3. 相同页布局、有效长度与dummy/sentinel；两份metadata形状相同不代表语义相同。以同一canonical fixture分别绑定，记录允许的零拷贝alias和物理stride。
4. 相同输入Norm/HC-pre开始，到O-proj/HC-post写完最终残差输出结束；原生外围metadata准备、权重准备、cache恢复是否在外要逐项列出。不可把attention-only、半层或仅后缀与完整根相比较。
5. 捕获外A/B/A、NaN/整数互补毒化、保护区、只读SHA、各根实际路由与根ABI、信号代际。我方对Native首差即停；Nal已知差异可记录并继续计时，但仍须finite、自重复、A/B/A、cache/保护区/信号合同通过，且不能悄悄Native回退。

重复回放会改cache/state。每个窗口恢复初始fixture应在事件外，并检查连续回放是否仍是相同合法写入语义；不能因最终输出未变便省略state及信号检查。signal按各自合同保留代际，不能每次把别人的持久协议误清零。

## 三、环境、根入口与流

`CAPABILITIES.json`记录的是旧SDK，signal API缺失仅为历史事实。新SDK固定PyPTO`2dfa7f12`、Simpler`57e49923`、ISA`327cd586`，实际PTOAS是0.66 wheel；PTOAS源码checkout `e5c1c43`不能冒充实际wheel源码身份。三方要绑定实际import、DSO、PTOAS二进制、CANN/Torch/NPU版本和编译策略。若Nal新提交必须使用不同工具链，报告实现与编译器共同差异，不能把总差全归给调度。

130参数Torch schema在当前PyTorch有64参数限制；历史132参数direct-JIT路径可用于执行，但要记录真实入口。不能把一边Torch adapter、另一边不同程序调用方式的主机耗时直接称算子差。共同FULL graph设备事件边界可以提供受控设备比较；端到端主机提交耗时另列。不得通过修改框架/SDK或生成C++绕过限制。

计时建议独立无DFX任务，足够warmup后12窗×100次，臂顺序平衡，先逐位门禁，再计时、计时后复验。一个共同NPU stream，事件包围真实完整回放。若Native/包装器使用内部流，必须检查graph捕获了join/stream dependency；只在默认流记事件、外部全卡同步后取数不能补救缺失的计时依赖。AICPU提交/调度发生在事件区间且影响设备完成的部分包含于事件延迟，但这不是AICPU逐项时间证据。Python准备/编译/捕获/事件外恢复均不计入，须明确。

Native SK0与SK1资格分别记录；历史SK0缓存桥不能贴SK1标签。实际静态包及reselect/trace证明不足时，标未证明，不删除assert继续跑。

## 四、Simpler DFX能比较什么

| 观测 | 可以回答 | 不能回答 |
| --- | --- | --- |
| 同窗口完整根event时间 | 相同输入/边界下的设备回放延迟差 | 单一模块或CPU/AICPU原因 |
| L1首末incore envelope | 每臂核内整体覆盖跨度、AIC/AIV角色范围 | 提交前后开销，纯计算或纯等待 |
| 我方多task的阶段token envelope | 对应数学任务集合的覆盖范围/重叠关系 | 各span加总得到整层，或span相减得到纯stall |
| Nal单MIX的72角色记录 | 完整常驻AIC/AIV执行跨度及各核偏斜 | 内联HC/QKV/Indexer/QKPV/O-proj的内部阶段边界 |
| 独立阶段root/PMU | 指定固定阶段及输入的孤立成本、利用率/流水事件 | 完整常驻程序的因果贡献或DDR字节数 |

归档`nal-l1-compare.py`对单SPMD要求72行且唯一task token。这恰好说明：不能只按内联函数名从现有L1记录重建Nal内部模块时间。纯DSL约束下不要启用`phase-clock`或`wait_codegen`的生成C++替换。若SDK没有已注册且可用的DSL时间戳接口，应明确该内部切点暂不可观测；优先共同外边界DFX、实际生成码/同步DAG，再对选定模块作双方同输入孤立DSL root测量。孤立结果须标“isolated”，不得冒认full层模块占比。

我方现有`DFX_STAGE_ANALYSIS.json`是历史我方单边、不同task结构的覆盖跨度，不能与新Nal event统计做百分比归因；例如Sparse约755µs envelope不是已证明的纯Sparse计算时间。阶段彼此重叠，跨度总和可大于整层。

新DFX采集应单独任务、dep-gen关闭、各臂每窗口相同回放次数；验证实际freq、24AIC/48AIV、无dropped boundaries、记录合法、真实根launch数。`run_boundaries`是root launch标记，不是固定两条起止对。映射必须绑定当次kernel_config/orchestration SHA；不复用旧root token表。先归档raw，再生成有来源的token/phase表。

## 五、最小可执行次序与选择优化的门槛

1. 固定91c实际源及SDK能力；bea保留控制，不复用其PASS标签。只读/CPU完整编译及ABI身份门禁通过后，送实际新runner独立审查。
2. 第一短任务只做8K/B16完整共同边界三方门禁与无DFX计时。先证明我方与Native精度仍成立，Nal独立数值差异明确记录，确认没有fallback/漏算范围。
3. 第二短任务采相同输入DFX，首先比较完整跨度、每核偏斜、task数量和根外间隙。若内部Nal阶段不可见，不编造阶段排名。
4. 结合生成码/owner依赖，选择一个可验证模块；必要时两边同输入、同数学阶段孤立DSL测量。保持Native K顺序、累加/量化全域与BF16边界，不以数学近似或S6 padding换性能。
5. 单因素必须同时满足逐位/guard/代际、同任务配对窗口稳定收益及独立重复。短T或中T不快于冻结版本时不可把高T优势扩大为全范围收益。完整CSA通过后才进入真实模型8K，再128K token验证。

最终结果表需分开同轮配对、跨任务历史、用户截图和不同SDK结果。本方案不承诺尚未测量的收益，也不把“少task”“少wait”或理论带宽减半当作实际瓶颈结论。
