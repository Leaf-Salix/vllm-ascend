"""无设备核验整模型fusion助手、既有Native gold及固定bank身份。"""
from pathlib import Path
import hashlib
import json
import os
import runpy
import sys

HERE=Path(__file__).resolve().parent
case,bank_path,gold_path,out_path=sys.argv[1:]
bank,gold,out=map(Path,(bank_path,gold_path,out_path))
out.mkdir(parents=True,exist_ok=True)
expected=json.loads((HERE/'manifest.json').read_text())
assert expected=={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in expected}
os.environ['PREFLIGHT_RECEIPT']=str(out/'cpu-sdk.json')
runpy.run_path(str(HERE.parent/'sdk_bind.py'),run_name='__whole_preflight_sdk__')
import torch_npu
assert not torch_npu.npu.is_initialized()
from source_identity import source_identity
from load_candidate import entry_for
source=source_identity()
entry_for('combined')
receipt=json.loads((HERE.parent/'cpu-combined/receipt.json').read_text())
assert receipt['postload_reduction_metadata']['equal_original']
assert receipt['pass'] and receipt['device_execution'] is False and receipt['npu_initialized'] is False
assert receipt['source']==source and receipt['root_tensors']==64
sdk=json.loads((out/'cpu-sdk.json').read_text())
for key in ('source_heads','binary_sha256','ptoas_binary_sha256'):assert sdk[key]==receipt['sdk'][key],key
assert receipt['candidate_source_sha256']==hashlib.sha256((HERE.parent/'SOURCE.json').read_bytes()).hexdigest()
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
plan=json.loads((bank/'plan.json').read_text())
configuration=json.loads((gold/'configuration.json').read_text())
batch=40 if case=='8k' else 24
assert configuration['backend']=='native' and configuration['decode_tokens']==192
assert configuration['batch']==batch
assert sha(bank/'plan.json')==configuration['bank_plan_sha256']
assert configuration.get('official_static_cache_sha256',configuration.get('static_metadata_sha256'))=='863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
keys=[c['key'] for c in plan['cases'][:batch]]
assert len(keys)==len(set(keys))==batch
from safetensors import safe_open
bank_rows=[]
for c in plan['cases'][:batch]:
 token_file=bank/c['tokens'];tokens=json.loads(token_file.read_text())
 assert len(tokens)==c['history']+1 and c['decode_suffix_tokens']==1
 folder=bank/c['key']/'tp0';mf=folder/'manifest.json';cache=folder/'cache.safetensors'
 manifest=json.loads(mf.read_text())
 assert manifest['history']==c['history'] and manifest['p_tp_rank']==0
 with safe_open(cache,framework='pt',device='cpu') as payload:
  assert set(payload.keys())==set(manifest['entries'])
  for name,v in manifest['entries'].items():assert payload.get_slice(name).get_shape()==[len(v['logical_blocks']),*v['shape']]
 bank_rows.append({'key':c['key'],'token_sha256':sha(token_file),'manifest_sha256':sha(mf),'cache_bytes':cache.stat().st_size,'cache_mtime_ns':cache.stat().st_mtime_ns})
gold_rows=[]
for rank in range(16):
 f=gold/f'rank{rank}.mixed.json';raw=json.loads(f.read_text())
 assert raw['backend']=='native' and [q['key'] for q in raw['requests']]==keys
 assert all(len(q['output_token_ids'])==192 for q in raw['requests'])
 stats=gold/f'request_stats_rank{rank}.jsonl';events=[json.loads(s) for s in stats.read_text().splitlines()]
 assert len(events)==batch and {v['key'] for v in events}==set(keys)
 assert all(v['output_tokens']==192 and v['preemptions']==0 for v in events)
 gold_rows.append({'rank':rank,'tokens_sha256':sha(f),'events_sha256':sha(stats)})
# Ensure the actual Native numerical implementation still matches the reused gold.
native_files=('vllm_ascend/models/deepseek_v4.py','vllm_ascend/models/deepseek_v4_dspark.py','vllm_ascend/models/deepseek_v4_mtp.py','vllm_ascend/attention/dsa_v1.py','vllm_ascend/quantization/methods/w8a8_dynamic.py')
old_source=Path(configuration['snapshot']);new_source=Path(source['source_root'])
native_identity={f:{'gold':sha(old_source/f),'current':sha(new_source/f)} for f in native_files}
record={'pass':False,'case':case,'batch':batch,'decode_tokens':192,'source':source,'sdk':sdk,'candidate':json.loads((HERE.parent/'SOURCE.json').read_text()),'helper_sha256':expected,'bank_plan_sha256':sha(bank/'plan.json'),'bank_rows':bank_rows,'gold':str(gold),'gold_rows':gold_rows,'native_source_identity':native_identity,'native_source_equal':all(v['gold']==v['current'] for v in native_identity.values()),'whole_model_hardware_validated':False,'npu_initialized':torch_npu.npu.is_initialized()}
(out/'configuration.json').write_text(json.dumps(record,indent=2)+'\n')
assert record['native_source_equal'],'Native files differ from reused gold: inspect before hardware'
assert not record['npu_initialized']
from vllm_ascend.ops.pypto.variant import variant_package,ring_sizing_kwargs
assert variant_package().endswith('.deepseek_v4_flash_csa_tnd_precision_spmd_combined')
requested={} if case=='8k' else {'ring_heap':tuple(m*1024**2 for m in (56,96,176,1)),'ring_task_window':2048}
assert ring_sizing_kwargs()==requested
record['runtime_init_kwargs']=requested
record['formal_variant']='tnd_precision_combined'
record['pass']=True
(out/'configuration.json').write_text(json.dumps(record,indent=2)+'\n')
print('WHOLE_CPU_PREFLIGHT_PASS',case,'16 Native ranks verified; NPU false',flush=True)
