#!/usr/bin/env bash
fusion_whole_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$fusion_whole_dir/../env.sh"
export PYTHONPATH="$fusion_whole_dir:$fusion_whole_dir/..:$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
export PTO_CSA_VARIANT=tnd_precision_combined
export FUSION_WHOLE_ACTIVE=0 PYTHONNOUSERSITE=1
unset LOW_ACCEPTANCE_RUNTIME_PACKAGE LOW_ACCEPTANCE_STATIC_MANIFEST LOCAL_WORLD_SIZE
unset B28_ACTIVE TW_WHOLE_ACTIVE ADMISSION_REFERENCE ADMISSION_TRACE_DIR FULL_PROBE_DIR FULL_PROBE_MODE
export OMP_NUM_THREADS=10 OMP_PROC_BIND=false

unset PTO_CSA_RING_HEAP_MB PTO_CSA_RING_TASK_WINDOW
