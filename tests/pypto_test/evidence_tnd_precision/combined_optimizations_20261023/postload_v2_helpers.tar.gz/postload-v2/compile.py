"""Compile entire roots and actual native ABI without initializing NPU."""
import hashlib, importlib, json, os, runpy, sys, traceback, types
from pathlib import Path
root=Path(__file__).resolve().parent
arm=sys.argv[1]
assert arm == 'combined'
runpy.run_path(str(root/'sdk_bind.py'),run_name='__sdk_preflight__')
import torch_npu
assert not torch_npu.npu.is_initialized()
from source_identity import source_identity
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program
from pypto.runtime._kernel_artifact import KernelArtifact
out=root/('cpu-'+arm)
out.mkdir(exist_ok=False)
record={'pass':False,'device_execution':False,'arm':arm,'source':source_identity(),
        'sdk':json.loads(Path(os.environ['PREFLIGHT_RECEIPT']).read_text()),
        'helper_manifest_sha256':hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),
        'candidate_source_sha256':hashlib.sha256((root/'SOURCE.json').read_bytes()).hexdigest()}
try:
 from load_candidate import entry_for
 program=entry_for(arm).specialize()
 abi=kernel_abi_for_program(program,platform='a2a3',runtime='tensormap_and_ringbuffer')
 record['root_tensors']=len(abi.parameters)
 assert record['root_tensors']==64
 _compile_impl(program,output_dir=str(out/'kernel'),platform='a2a3',skip_ptoas=False,_kernel_abi=abi)
 artifact=KernelArtifact(out/'kernel',abi);artifact.load()
 record['artifact_identity']=artifact.identity().hex()
 record['npu_initialized']=torch_npu.npu.is_initialized()
 assert record['npu_initialized'] is False
 from vllm_ascend.ops.pypto.deepseek_v4_flash_dspark.nz_mode import root_weight_layouts
 record['combined_layouts']=root_weight_layouts(importlib.import_module('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_combined.decode_csa')._decode_csa_tp1_layer)
 baseline_layouts=root_weight_layouts(importlib.import_module('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.decode_csa')._decode_csa_tp1_layer)
 assert record['combined_layouts']==baseline_layouts
 from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_combined.native_adapter import CSAOperators
 ops=CSAOperators.register()
 record['schema']=str(ops.attention._schema)
 record['small_schema']=str(ops.attention.small._schema)
 assert ops.attention._schema.arguments[0].name=='x_hc' and ops.attention._schema.arguments[53].name=='x_out'
 assert all(ops.attention.for_tokens(t) is (ops.attention.small if t<=16 else ops.attention.combined) for t in range(1,257))
 assert torch_npu.npu.is_initialized() is False
 record['selector_1_to_256_pass']=True
 reduction=importlib.import_module('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_combined.qkv_proj_rope')
 original_reduction=importlib.import_module('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.qkv_proj_rope')
 assert (reduction.QR_OK,reduction.KV_OK)==(original_reduction.QR_OK,original_reduction.KV_OK)
 record['postload_reduction_metadata']={'QR_OK':reduction.QR_OK,'KV_OK':reduction.KV_OK,'equal_original':True}
 record['pass']=True
except BaseException:
 record['error']=traceback.format_exc()
finally:
 (out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record,indent=2),flush=True)
if not record['pass']:raise SystemExit(1)
