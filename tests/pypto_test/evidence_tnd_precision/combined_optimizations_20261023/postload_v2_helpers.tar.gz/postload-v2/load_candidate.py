"""Four isolated PTO arms: accepted source controls and formal combined package."""
import hashlib
import importlib
import importlib.util
import json
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
F='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision'
S='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap'
C='vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_combined'


def load(name,path):
    if name in sys.modules:
        assert Path(sys.modules[name].__file__).resolve()==path.resolve()
        return sys.modules[name]
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module


def entry_for(arm):
    proof=json.loads((HERE/'SOURCE.json').read_text())
    for key,suffix in (('root',S+'.decode_csa'),('prefix',S+'.prefix'),('oproj',F+'.o_proj')):
        module=importlib.import_module(suffix)
        assert hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()==proof['baseline'][key]['sha256']
    for rel,expected in proof['candidates'].items():assert hashlib.sha256((HERE/rel).read_bytes()).hexdigest()==expected
    if arm=='frozen':return importlib.import_module(S+'.decode_csa').decode_csa_tp1_layer_test
    if arm=='fused':
        load(F+'.nal_fused_oproj',HERE/'nal_fused_oproj.py')
        return load(S+'.nal_fused_root',HERE/'nal_fused_root.py').decode_csa_tp1_layer_test
    if arm=='early':
        load(S+'.early_pack_prefix',HERE/'early_pack_prefix.py')
        return load(S+'.early_pack_root',HERE/'early_pack_root.py').decode_csa_tp1_layer_test
    assert arm=='combined'
    return importlib.import_module(C+'.decode_csa').decode_csa_tp1_layer_test


def operators_for(arm):
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.native_adapter import CSAOperators
    if arm=='frozen':return CSAOperators.register()
    if arm=='combined':
        from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_combined.native_adapter import CSAOperators as CombinedOperators
        return CombinedOperators.register()
    import pypto.torch
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_prepack.native_adapter import PrepackedWorkspace
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_prepack.prefix import prepack_fixed_hc_weight
    namespace={'fused':'nal_fused_perf','early':'early_pack_perf'}[arm]
    attention=pypto.torch.register(entry_for(arm),namespace+'::attention')
    prepare=pypto.torch.register(prepack_fixed_hc_weight,namespace+'::prepare_hc_weight')
    assert len(attention._schema.arguments)==64
    return CSAOperators(attention,PrepackedWorkspace(prepare))
