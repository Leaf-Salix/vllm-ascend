"""Verify the exact post-load reduction import finishes without NPU initialization."""
from pathlib import Path
import hashlib
import importlib
import json
import os
import runpy
import sys

root=Path(__file__).resolve().parent
v2=root/'postload-v2'
sys.path.insert(0,str(v2))
os.environ['PREFLIGHT_RECEIPT']=str(root/'postload-import-sdk.json')
runpy.run_path(str(v2/'sdk_bind.py'),run_name='__postload_sdk_preflight__')
import torch_npu
assert not torch_npu.npu.is_initialized()
module=importlib.import_module('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_combined.qkv_proj_rope')
old=importlib.import_module('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.qkv_proj_rope')
assert (module.QR_OK,module.KV_OK)==(old.QR_OK,old.KV_OK)==(1,1)
initialized=torch_npu.npu.is_initialized()
assert initialized is False
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
record={'pass':True,'scope':'actual post-load metadata import only; no hardware or new math test','QR_OK':module.QR_OK,'KV_OK':module.KV_OK,'equal_original':True,'npu_initialized_after_import':initialized,'module_file':module.__file__,'module_sha256':sha(module.__file__),'v2_manifest_sha256':sha(v2/'manifest.json'),'script_sha256':sha(__file__)}
(root/'POSTLOAD_IMPORT_RECEIPT.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
