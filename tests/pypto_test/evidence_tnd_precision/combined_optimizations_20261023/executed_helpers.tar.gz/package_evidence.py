"""Seal exact executed helpers and accepted evidence without runtime build data."""
import hashlib
import io
import json
from pathlib import Path
import tarfile
import shutil

root=Path(__file__).resolve().parent
repo=root.parent.parent/'vllm-ascend-nalinaly-tnd-20261008-codex'
dest=repo/'tests/pypto_test/evidence_tnd_precision/combined_optimizations_20261023'
dest.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ('SOURCE.json','FORMAL_SOURCE_PROOF.json','SINGLE_SUMMARY.json','cpu-receipt-final.json','LAUNCH_ARGUMENT_CHECK.json'):
 shutil.copyfile(root/name,dest/name)
single=dest/'single_layer';single.mkdir(exist_ok=True)
for p in sorted(root.glob('evidence-*/result.json')):shutil.copyfile(p,single/(p.parent.name+'.json'))
files=set(json.loads((root/'manifest.json').read_text()))|{'manifest.json','FORMAL_SOURCE_PROOF.json','summarize_single.py','LAUNCH_ARGUMENT_CHECK.json'}
files.update('whole/'+name for name in json.loads((root/'whole/manifest.json').read_text()))
files.add('whole/manifest.json')
files.update(str(p.relative_to(root)) for p in (root/'formal-ut').rglob('*.py') if '__pycache__' not in p.parts)
files.update({'summarize_whole.py','seal_whole.py','package_evidence.py'})
archive=dest/'executed_helpers.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for name in sorted(files):
  p=root/name
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
  tf.addfile(info,io.BytesIO(data))
record={'archive_sha256':sha(archive),'files':{name:sha(root/name) for name in sorted(files)}}
(dest/'EXECUTED_FILES.json').write_text(json.dumps(record,indent=2)+'\n')
print(dest,len(files),archive.stat().st_size)
