"""Recompute four-arm timing and enforce complete Native A/B/ABA receipts."""
import hashlib
import json
from pathlib import Path
import statistics
import sys

ROOT = Path(sys.argv[1])
ARMS = ('frozen', 'fused', 'early', 'combined')
rows = []
for path in sorted(ROOT.glob('evidence-*/result.json')):
    raw = json.loads(path.read_text())
    assert raw['complete'] and raw['pass'] and raw['accuracy_executed']
    assert raw['accuracy_skipped_for'] == []
    assert raw['actual_capture_order'] == raw['planned_capture_order']
    assert len(raw['execution_checks']) == 84 and all(v['pass'] for v in raw['execution_checks'])
    assert raw['per_request_padding'] == 0 and raw['true_tokens'] == sum(raw['lengths'])
    assert raw['physical_graph_tokens'] == raw['true_tokens']
    for field, count, metric in (('event_windows', 12, 'event_median_us'), ('l1_windows', 8, 'l1_median_us')):
        windows = raw['performance'][field]
        assert len(windows) == 4 * count
        for repeat in range(count):
            expected = list(ARMS[repeat % 4:] + ARMS[:repeat % 4])
            group = [v for v in windows if v['repeat'] == repeat]
            assert [v['arm'] for v in group] == expected and all(v['order'] == expected for v in group)
        for arm in ARMS:
            values = [v['us'] for v in windows if v['arm'] == arm]
            assert statistics.median(values) == raw['performance']['summary'][arm][metric]
    for arm in ARMS:
        for phase in ('comparisons', 'B_comparisons'):
            checks = raw[phase][arm]
            assert len(checks) == 8 and all(v['bit_equal'] for v in checks.values())
        assert raw['graphs'][arm]['live_input_ABA']
    assert raw['graphs']['native']['live_input_ABA']
    expected_ns = 'dsv4_csa_tnd_precision_spmd_combined::attention'
    if raw['true_tokens'] <= 16:
        expected_ns += '_small'
    assert raw['graphs']['combined']['root_schema'].startswith(expected_ns + '(')
    summary = raw['performance']['summary']
    medians = {a: summary[a]['event_median_us'] for a in ARMS}
    best = min(medians[a] for a in ('fused', 'early'))
    row = {'case': path.parent.name, 'history': raw['history'], 'lengths': raw['lengths'],
           'tokens': raw['true_tokens'], 'event_median_us': medians,
           'gain_vs_frozen': 1 - medians['combined'] / medians['frozen'],
           'gain_vs_best_single': 1 - medians['combined'] / best,
           'four_way_performance_qualified': raw['performance']['winners'] == ['combined'],
           'direct_comparisons': raw['performance']['combined_vs_each_control'],
           'capture_order': raw['actual_capture_order'], 'native_A_B_8_and_ABA_exact': True,
           'actual_combined_root': expected_ns, 'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
           'scope': 'single real layer weights, synthetic hidden/history; not whole-model token qualification'}
    rows.append(row)
assert rows
(ROOT / 'SINGLE_SUMMARY.json').write_text(json.dumps(rows, indent=2) + '\n')
for row in rows:
    print(row['case'], row['event_median_us'], 'gain', row['gain_vs_frozen'], row['gain_vs_best_single'],
          'qualified', row['four_way_performance_qualified'], 'Native exact')
