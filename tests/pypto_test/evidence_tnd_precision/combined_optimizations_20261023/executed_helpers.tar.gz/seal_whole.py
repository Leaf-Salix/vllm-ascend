"""Archive raw whole-model data and publish a reversible SHA-key-only summary."""
import copy
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

root=Path(__file__).resolve().parent
case=sys.argv[1]
assert case in ('8k','128k')
rawdir=root/f'evidence-whole{case}-v1'
public=root.parent.parent/'vllm-ascend-nalinaly-tnd-20261008-codex/tests/pypto_test/evidence_tnd_precision/combined_optimizations_20261023'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=json.loads((rawdir/'SUMMARY.json').read_text())
assert original['pass'] and original['native_tokens_events_equal'] and original['preemptions']==0
published=copy.deepcopy(original)
rename={'warm_tokens_events_sha256':'warm_payload_sha256','measured_tokens_events_sha256':'measured_payload_sha256'}
for rank in published['ranks']:
 for old,new in rename.items():rank[new]=rank.pop(old)
reverse=copy.deepcopy(published)
for rank in reverse['ranks']:
 for old,new in rename.items():rank[old]=rank.pop(new)
assert reverse==original
summary=public/f'whole{case}_summary.json'
summary.write_text(json.dumps(published,indent=2,ensure_ascii=False)+'\n')
files=sorted(p for p in rawdir.iterdir() if p.is_file())
required={'configuration.json','audit.json','SUMMARY.json'}|{f'rank{r}.real_perf.json' for r in range(16)}|{f'rank{r}.capacity.json' for r in range(16)}
assert required.issubset({p.name for p in files})
archive=public/f'whole{case}_raw.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:
  data=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(data);info.mode=0o644
  tf.addfile(info,io.BytesIO(data))
index={'archive_sha256':sha(archive),'files':{p.name:sha(p) for p in files}}
(public/f'WHOLE{case.upper()}_RAW_FILES.json').write_text(json.dumps(index,indent=2)+'\n')
derivation_path=public/'PUBLIC_SUMMARY_DERIVATION.json'
derivation=json.loads(derivation_path.read_text()) if derivation_path.exists() else {}
derivation[case]={'original_sha256':sha(rawdir/'SUMMARY.json'),'public_sha256':sha(summary),'key_mapping':rename,'reverse_mapping_equal':True,'payload_digests_recomputed_from_all_16_raw_ranks':True}
derivation_path.write_text(json.dumps(derivation,indent=2)+'\n')
print(case,len(files),'raw files',archive.stat().st_size,'bytes')
