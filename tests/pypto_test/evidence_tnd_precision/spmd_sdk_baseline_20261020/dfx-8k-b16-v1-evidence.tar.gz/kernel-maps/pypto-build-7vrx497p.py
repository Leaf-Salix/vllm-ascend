from pathlib import Path
from simpler.task_interface import ArgDirection as _D
_ROOT_DIR = Path(__file__).parent
KERNELS = [{'func_id': 0, 'name': '_prepack_fixed_hc_weight', 'source': 'kernels/aiv/_prepack_fixed_hc_weight.cpp', 'core_type': 'aiv', 'signature': ['IN', 'INOUT']}]
ORCHESTRATION = {'source': 'orchestration/prepack_fixed_hc_weight.cpp', 'function_name': 'aicpu_orchestration_entry', 'signature': ['IN', 'INOUT']}
RUNTIME_CONFIG = {'runtime': 'tensormap_and_ringbuffer', 'aicpu_thread_num': 0}
for _entry in [*KERNELS, ORCHESTRATION]:
    _entry['source'] = str(_ROOT_DIR / _entry['source'])
    _entry['signature'] = [getattr(_D, s) for s in _entry['signature']]
    if 'extra_include_dirs' in _entry:
        _entry['extra_include_dirs'] = [
            str(_ROOT_DIR / p) for p in _entry['extra_include_dirs']]
