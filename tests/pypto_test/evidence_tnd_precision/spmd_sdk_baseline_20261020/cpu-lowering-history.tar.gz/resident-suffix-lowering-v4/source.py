# SPDX-License-Identifier: Apache-2.0
"""独立O-proj/HC-post常驻候选；只换worker/grid/同步，未获设备资格。"""
import pypto.language as pl
T = pl.dynamic("RESIDENT_SUFFIX_T")
ACC_ROWS = pl.dynamic("RESIDENT_SUFFIX_ACC_ROWS")
INT_ROWS = pl.dynamic("RESIDENT_SUFFIX_INT_ROWS")
WO_A_WEIGHT_LAYOUT = pl.NZ
QUANT_WEIGHT_LAYOUT = pl.NZ
D = 4096
HC_MULT = 4
T_TILE = 4
STRIDE = 128
CORES = 72
WORDS = 6 * CORES * STRIDE

@pl.jit.inline(auto_scope=False)
def begin(signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]], core: pl.Scalar[pl.INDEX]):
    offset = core * STRIDE
    pl.system.cacheinvalid(signals, [1], [offset])
    pl.system.fence()
    generation = pl.read(signals, [offset]) + pl.cast(1, pl.INT32)
    pl.system.bar_all()
    pl.system.signal_notify(signals, [offset], generation)
    return signals, generation

@pl.jit.inline(auto_scope=False)
def publish(signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]], phase: pl.Scalar[pl.INDEX], core: pl.Scalar[pl.INDEX], generation: pl.Scalar[pl.INT32]):
    pl.system.bar_all()
    pl.system.fence()
    pl.system.cacheinvalid()
    pl.system.fence()
    pl.system.signal_notify(signals, [(phase * CORES + core) * STRIDE], generation)
    return signals

@pl.jit.inline(auto_scope=False)
def wait_group(signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]], phase: pl.Scalar[pl.INDEX], first: pl.Scalar[pl.INDEX], last: pl.Scalar[pl.INDEX], generation: pl.Scalar[pl.INT32]):
    for owner in pl.range(first, last):
        pl.system.signal_wait(signals, [(phase * CORES + owner) * STRIDE], generation)
    pl.system.fence()
    pl.system.cacheinvalid()
    pl.system.fence()
    return signals


@pl.jit.incore
def cube(heads: pl.Tensor[[T, 32768], pl.BF16],
wo_a: pl.Tensor[[8, 4096, 1024], pl.BF16, WO_A_WEIGHT_LAYOUT],
wo_b: pl.Tensor[[8192, 4096], pl.INT8, QUANT_WEIGHT_LAYOUT],
wo_b_scale: pl.Tensor[[4096], pl.FP32],
start: pl.Tensor[[16, 8, 8], pl.INT32],
projected: pl.InOut[pl.Tensor[[T, 8192], pl.BF16]],
quantized: pl.InOut[pl.Tensor[[T, 8192], pl.INT8]],
token_scale: pl.InOut[pl.Tensor[[T, 1], pl.FP32]],
attended: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]],
residual: pl.Tensor[[T, 4, 4096], pl.BF16],
post: pl.Tensor[[T, 4], pl.FP32],
comb: pl.Tensor[[T, 16], pl.FP32],
output: pl.InOut[pl.Tensor[[T, 4, 4096], pl.BF16]],
accum: pl.InOut[pl.Tensor[[ACC_ROWS, 8192], pl.FP32]],
integer_accum: pl.InOut[pl.Tensor[[INT_ROWS, 4096], pl.INT32]],
signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]],):
    worker = pl.tile.get_block_idx()
    signals, generation = begin(signals, worker)
    rows = pl.tensor.dim(heads, 0)
    row_tiles = (rows + 15) // 16
    if rows >= 192:
        for logical in pl.range(worker, 64, 24):
            seed_group = logical // 8
            seed_block = logical % 8
            seed_col = seed_block * 128
            for seed_panel in pl.range((row_tiles + 7) // 8):
                seed_first_rb = seed_panel * 8
                seed_first_start = pl.max(pl.read(start, [seed_first_rb, seed_group, seed_block]), 0)
                seed_same_start = 1
                if seed_first_rb + 1 < row_tiles:
                    if pl.max(pl.read(start, [seed_first_rb + 1, seed_group, seed_block]), 0) != seed_first_start:
                        seed_same_start = 0
                if seed_first_rb + 2 < row_tiles:
                    if pl.max(pl.read(start, [seed_first_rb + 2, seed_group, seed_block]), 0) != seed_first_start:
                        seed_same_start = 0
                if seed_first_rb + 3 < row_tiles:
                    if pl.max(pl.read(start, [seed_first_rb + 3, seed_group, seed_block]), 0) != seed_first_start:
                        seed_same_start = 0
                if seed_first_rb + 4 < row_tiles:
                    if pl.max(pl.read(start, [seed_first_rb + 4, seed_group, seed_block]), 0) != seed_first_start:
                        seed_same_start = 0
                if seed_first_rb + 5 < row_tiles:
                    if pl.max(pl.read(start, [seed_first_rb + 5, seed_group, seed_block]), 0) != seed_first_start:
                        seed_same_start = 0
                if seed_first_rb + 6 < row_tiles:
                    if pl.max(pl.read(start, [seed_first_rb + 6, seed_group, seed_block]), 0) != seed_first_start:
                        seed_same_start = 0
                if seed_first_rb + 7 < row_tiles:
                    if pl.max(pl.read(start, [seed_first_rb + 7, seed_group, seed_block]), 0) != seed_first_start:
                        seed_same_start = 0
                if rows <= 16:
                    seed_same_start = 0
                if seed_first_start > 240:
                    seed_same_start = 0
                if seed_same_start == 1:
                    seed_fast_row = seed_first_rb * 16
                    seed_fast_valid = pl.min(128, rows - seed_fast_row)
                    seed_fast_seed_k = seed_first_start * 16
                    seed_fast_seed_x = pl.slice(heads, [128, 256], [seed_fast_row, seed_group * 4096 + seed_fast_seed_k], valid_shape=[seed_fast_valid, 256])
                    seed_fast_seed_w = wo_a[seed_group:seed_group + 1, seed_fast_seed_k:seed_fast_seed_k + 256, seed_col:seed_col + 128]
                    seed_fast_acc = pl.matmul(seed_fast_seed_x, seed_fast_seed_w, out_dtype=pl.FP32)
                    for seed_fast_packet in pl.pipeline(1, 16, stage=2):
                        seed_fast_packet_kb = (seed_first_start + seed_fast_packet * 16) % 256
                        if seed_fast_packet_kb <= 240:
                            seed_fast_packet_k = seed_fast_packet_kb * 16
                            seed_fast_packet_x = pl.slice(heads, [128, 256], [seed_fast_row, seed_group * 4096 + seed_fast_packet_k], valid_shape=[seed_fast_valid, 256])
                            seed_fast_packet_w = wo_a[seed_group:seed_group + 1, seed_fast_packet_k:seed_fast_packet_k + 256, seed_col:seed_col + 128]
                            seed_fast_acc = pl.matmul_acc(seed_fast_acc, seed_fast_packet_x, seed_fast_packet_w, init_cond=False)
                        else:
                            for seed_fast_inner in pl.range(16):
                                seed_fast_wrap_k = (seed_fast_packet_kb + seed_fast_inner) % 256 * 16
                                seed_fast_wrap_x = pl.slice(heads, [128, 16], [seed_fast_row, seed_group * 4096 + seed_fast_wrap_k], valid_shape=[seed_fast_valid, 16])
                                seed_fast_wrap_w = wo_a[seed_group:seed_group + 1, seed_fast_wrap_k:seed_fast_wrap_k + 16, seed_col:seed_col + 128]
                                seed_fast_acc = pl.matmul_acc(seed_fast_acc, seed_fast_wrap_x, seed_fast_wrap_w, init_cond=False)
                    accum = pl.assemble(accum, seed_fast_acc, [seed_fast_row, seed_group * 1024 + seed_col])
                else:
                    for seed_local_rb in pl.range(8):
                        seed_narrow_rb = seed_first_rb + seed_local_rb
                        if seed_narrow_rb < row_tiles:
                            seed_narrow_row = seed_narrow_rb * 16
                            seed_narrow_valid = pl.min(16, rows - seed_narrow_row)
                            seed_narrow_first_block = pl.max(pl.read(start, [seed_narrow_rb, seed_group, seed_block]), 0)
                            seed_narrow_acc = pl.create_tensor([1, 16, 128], dtype=pl.FP32)
                            for seed_narrow_packet in pl.range(16):
                                seed_narrow_packet_kb = (seed_narrow_first_block + seed_narrow_packet * 16) % 256
                                if seed_narrow_packet_kb <= 240:
                                    seed_narrow_packet_k = seed_narrow_packet_kb * 16
                                    seed_narrow_packet_x = pl.slice(heads, [16, 256], [seed_narrow_row, seed_group * 4096 + seed_narrow_packet_k], valid_shape=[seed_narrow_valid, 256])
                                    seed_narrow_packet_w = wo_a[seed_group:seed_group + 1, seed_narrow_packet_k:seed_narrow_packet_k + 256, seed_col:seed_col + 128]
                                    seed_narrow_acc = pl.matmul_acc(seed_narrow_acc, seed_narrow_packet_x, seed_narrow_packet_w, init_cond=seed_narrow_packet == 0)
                                else:
                                    for seed_narrow_inner in pl.range(16):
                                        seed_narrow_wrap_k = (seed_narrow_packet_kb + seed_narrow_inner) % 256 * 16
                                        seed_narrow_wrap_x = pl.slice(heads, [16, 16], [seed_narrow_row, seed_group * 4096 + seed_narrow_wrap_k], valid_shape=[seed_narrow_valid, 16])
                                        seed_narrow_wrap_w = wo_a[seed_group:seed_group + 1, seed_narrow_wrap_k:seed_narrow_wrap_k + 16, seed_col:seed_col + 128]
                                        seed_narrow_acc = pl.matmul_acc(seed_narrow_acc, seed_narrow_wrap_x, seed_narrow_wrap_w, init_cond=seed_narrow_packet * 16 + seed_narrow_inner == 0)
                            accum = pl.assemble(accum, seed_narrow_acc, [seed_narrow_row, seed_group * 1024 + seed_col])
    else:
        for logical in pl.range(worker, 64, 24):
            v4_group = logical // 8
            v4_block = logical % 8
            v4_col = v4_block * 128
            for v4_panel in pl.range((row_tiles + 7) // 8):
                v4_first_rb = v4_panel * 8
                v4_first_start = pl.max(pl.read(start, [v4_first_rb, v4_group, v4_block]), 0)
                v4_same_start = 1
                if v4_first_rb + 1 < row_tiles:
                    if pl.max(pl.read(start, [v4_first_rb + 1, v4_group, v4_block]), 0) != v4_first_start:
                        v4_same_start = 0
                if v4_first_rb + 2 < row_tiles:
                    if pl.max(pl.read(start, [v4_first_rb + 2, v4_group, v4_block]), 0) != v4_first_start:
                        v4_same_start = 0
                if v4_first_rb + 3 < row_tiles:
                    if pl.max(pl.read(start, [v4_first_rb + 3, v4_group, v4_block]), 0) != v4_first_start:
                        v4_same_start = 0
                if v4_first_rb + 4 < row_tiles:
                    if pl.max(pl.read(start, [v4_first_rb + 4, v4_group, v4_block]), 0) != v4_first_start:
                        v4_same_start = 0
                if v4_first_rb + 5 < row_tiles:
                    if pl.max(pl.read(start, [v4_first_rb + 5, v4_group, v4_block]), 0) != v4_first_start:
                        v4_same_start = 0
                if v4_first_rb + 6 < row_tiles:
                    if pl.max(pl.read(start, [v4_first_rb + 6, v4_group, v4_block]), 0) != v4_first_start:
                        v4_same_start = 0
                if v4_first_rb + 7 < row_tiles:
                    if pl.max(pl.read(start, [v4_first_rb + 7, v4_group, v4_block]), 0) != v4_first_start:
                        v4_same_start = 0
                if rows <= 16:
                    v4_same_start = 0
                if v4_same_start == 1:
                    v4_wide_row = v4_first_rb * 16
                    v4_wide_valid = pl.min(128, rows - v4_wide_row)
                    v4_wide_first_block = v4_first_start
                    v4_wide_seed_k = v4_wide_first_block % 256 * 16
                    v4_wide_seed_x = pl.slice(heads, [128, 16], [v4_wide_row, v4_group * 4096 + v4_wide_seed_k], valid_shape=[v4_wide_valid, 16])
                    v4_wide_seed_w = wo_a[v4_group:v4_group + 1, v4_wide_seed_k:v4_wide_seed_k + 16, v4_col:v4_col + 128]
                    v4_wide_acc = pl.matmul(v4_wide_seed_x, v4_wide_seed_w, out_dtype=pl.FP32)
                    for v4_wide_packet in pl.pipeline(15, stage=2):
                        v4_wide_packet_kb = (v4_wide_first_block + 1 + v4_wide_packet * 16) % 256
                        if v4_wide_packet_kb <= 240:
                            v4_wide_packet_k = v4_wide_packet_kb * 16
                            v4_wide_packet_x = pl.slice(heads, [128, 256], [v4_wide_row, v4_group * 4096 + v4_wide_packet_k], valid_shape=[v4_wide_valid, 256])
                            v4_wide_packet_w = wo_a[v4_group:v4_group + 1, v4_wide_packet_k:v4_wide_packet_k + 256, v4_col:v4_col + 128]
                            v4_wide_acc = pl.matmul_acc(v4_wide_acc, v4_wide_packet_x, v4_wide_packet_w, init_cond=False)
                        else:
                            for v4_wide_inner in pl.range(16):
                                v4_wide_wrap_k = (v4_wide_packet_kb + v4_wide_inner) % 256 * 16
                                v4_wide_wrap_x = pl.slice(heads, [128, 16], [v4_wide_row, v4_group * 4096 + v4_wide_wrap_k], valid_shape=[v4_wide_valid, 16])
                                v4_wide_wrap_w = wo_a[v4_group:v4_group + 1, v4_wide_wrap_k:v4_wide_wrap_k + 16, v4_col:v4_col + 128]
                                v4_wide_acc = pl.matmul_acc(v4_wide_acc, v4_wide_wrap_x, v4_wide_wrap_w, init_cond=False)
                    for v4_wide_tail in pl.range(241, 256):
                        v4_wide_tail_k = (v4_wide_first_block + v4_wide_tail) % 256 * 16
                        v4_wide_tail_x = pl.slice(heads, [128, 16], [v4_wide_row, v4_group * 4096 + v4_wide_tail_k], valid_shape=[v4_wide_valid, 16])
                        v4_wide_tail_w = wo_a[v4_group:v4_group + 1, v4_wide_tail_k:v4_wide_tail_k + 16, v4_col:v4_col + 128]
                        v4_wide_acc = pl.matmul_acc(v4_wide_acc, v4_wide_tail_x, v4_wide_tail_w, init_cond=False)
                    accum = pl.assemble(accum, v4_wide_acc, [v4_wide_row, v4_group * 1024 + v4_col])
                else:
                    for v4_local_rb in pl.range(8):
                        v4_narrow_rb = v4_first_rb + v4_local_rb
                        if v4_narrow_rb < row_tiles:
                            v4_narrow_row = v4_narrow_rb * 16
                            v4_narrow_valid = pl.min(16, rows - v4_narrow_row)
                            v4_narrow_first_block = pl.max(pl.read(start, [v4_narrow_rb, v4_group, v4_block]), 0)
                            v4_narrow_acc = pl.create_tensor([1, 16, 128], dtype=pl.FP32)
                            for v4_narrow_packet in pl.range(16):
                                v4_narrow_packet_kb = (v4_narrow_first_block + v4_narrow_packet * 16) % 256
                                if v4_narrow_packet_kb <= 240:
                                    v4_narrow_packet_k = v4_narrow_packet_kb * 16
                                    v4_narrow_packet_x = pl.slice(heads, [16, 256], [v4_narrow_row, v4_group * 4096 + v4_narrow_packet_k], valid_shape=[v4_narrow_valid, 256])
                                    v4_narrow_packet_w = wo_a[v4_group:v4_group + 1, v4_narrow_packet_k:v4_narrow_packet_k + 256, v4_col:v4_col + 128]
                                    v4_narrow_acc = pl.matmul_acc(v4_narrow_acc, v4_narrow_packet_x, v4_narrow_packet_w, init_cond=v4_narrow_packet == 0)
                                else:
                                    for v4_narrow_inner in pl.range(16):
                                        v4_narrow_wrap_k = (v4_narrow_packet_kb + v4_narrow_inner) % 256 * 16
                                        v4_narrow_wrap_x = pl.slice(heads, [16, 16], [v4_narrow_row, v4_group * 4096 + v4_narrow_wrap_k], valid_shape=[v4_narrow_valid, 16])
                                        v4_narrow_wrap_w = wo_a[v4_group:v4_group + 1, v4_narrow_wrap_k:v4_narrow_wrap_k + 16, v4_col:v4_col + 128]
                                        v4_narrow_acc = pl.matmul_acc(v4_narrow_acc, v4_narrow_wrap_x, v4_narrow_wrap_w, init_cond=v4_narrow_packet * 16 + v4_narrow_inner == 0)
                            accum = pl.assemble(accum, v4_narrow_acc, [v4_narrow_row, v4_group * 1024 + v4_col])
    signals = publish(signals, 1, worker, generation)
    signals = wait_group(signals, 3, 24, 72, generation)
    if rows <= 16:
        for block in pl.range(worker, row_tiles * 32, 24):
            row = block // 32 * 16
            col = pl.max(block % 32, 0) * 128
            valid = pl.min(16, rows - row)
            b_acc = pl.create_tensor([16, 128], dtype=pl.INT32)
            for step in pl.range(16):
                k = step * 512
                b_input = pl.slice(quantized, [16, 512], [row, k], valid_shape=[valid, 512])
                b_weight = wo_b[k:k + 512, col:col + 128]
                b_acc = pl.matmul_acc(b_acc, b_input, b_weight, init_cond=step == 0)
            integer_accum[row:row + 16, col:col + 128] = b_acc
    else:
        for wide_block in pl.range(worker, (rows + 63) // 64 * 32, 24):
            wide_row = wide_block // 32 * 64
            wide_col = pl.max(wide_block % 32, 0) * 128
            wide_valid = pl.min(64, rows - wide_row)
            wide_first_input = pl.slice(quantized, [64, 512], [wide_row, 0], valid_shape=[wide_valid, 512])
            wide_first_weight = wo_b[0:512, wide_col:wide_col + 128]
            wide_b_acc = pl.matmul(wide_first_input, wide_first_weight, out_dtype=pl.INT32)
            for wide_step in pl.range(1, 16):
                wide_k = wide_step * 512
                wide_b_input = pl.slice(quantized, [64, 512], [wide_row, wide_k], valid_shape=[wide_valid, 512])
                wide_b_weight = wo_b[wide_k:wide_k + 512, wide_col:wide_col + 128]
                wide_b_acc = pl.matmul_acc(wide_b_acc, wide_b_input, wide_b_weight, init_cond=False)
            integer_accum = pl.assemble(integer_accum, wide_b_acc, [wide_row, wide_col])
    signals = publish(signals, 4, worker, generation)
    return projected, quantized, token_scale, attended, output, accum, integer_accum, signals

@pl.jit.incore
def vector(heads: pl.Tensor[[T, 32768], pl.BF16],
wo_a: pl.Tensor[[8, 4096, 1024], pl.BF16, WO_A_WEIGHT_LAYOUT],
wo_b: pl.Tensor[[8192, 4096], pl.INT8, QUANT_WEIGHT_LAYOUT],
wo_b_scale: pl.Tensor[[4096], pl.FP32],
start: pl.Tensor[[16, 8, 8], pl.INT32],
projected: pl.InOut[pl.Tensor[[T, 8192], pl.BF16]],
quantized: pl.InOut[pl.Tensor[[T, 8192], pl.INT8]],
token_scale: pl.InOut[pl.Tensor[[T, 1], pl.FP32]],
attended: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]],
residual: pl.Tensor[[T, 4, 4096], pl.BF16],
post: pl.Tensor[[T, 4], pl.FP32],
comb: pl.Tensor[[T, 16], pl.FP32],
output: pl.InOut[pl.Tensor[[T, 4, 4096], pl.BF16]],
accum: pl.InOut[pl.Tensor[[ACC_ROWS, 8192], pl.FP32]],
integer_accum: pl.InOut[pl.Tensor[[INT_ROWS, 4096], pl.INT32]],
signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]],):
    pl.func_attr({"split_aiv": True})
    worker = pl.tile.get_block_idx() * 2 + pl.tile.get_subblock_idx()
    core = 24 + worker
    signals, generation = begin(signals, core)
    rows = pl.tensor.dim(heads, 0)
    row_tiles = (rows + 15) // 16
    signals = wait_group(signals, 1, 0, 24, generation)
    for block in pl.range(worker, row_tiles * 8, 48):
        row = block // 8 * 16
        col = block % 8 * 1024
        valid = pl.min(16, rows - row)
        oa_value = pl.load(accum, [row, col], [16, 1024], valid_shape=[valid, 1024])
        pl.store(pl.cast(oa_value, pl.BF16, mode='rint'), [row, col], projected)
    signals = publish(signals, 2, core, generation)
    signals = wait_group(signals, 2, 24, 72, generation)
    quant_rows = (rows + 7) // 8
    for block in pl.range(worker, quant_rows, 48):
        row = block * 8
        valid = pl.min(8, rows - row)
        first_quant = pl.load(projected, [row, 0], [8, 1024], valid_shape=[valid, 1024])
        first_abs = pl.abs(pl.cast(first_quant, pl.FP32))
        amax = pl.row_max(first_abs, pl.create_tile([8, 1024], dtype=pl.FP32))
        for group in pl.range(1, 8):
            q_bf16 = pl.load(projected, [row, group * 1024], [8, 1024], valid_shape=[valid, 1024])
            q_fp32 = pl.cast(q_bf16, pl.FP32)
            amax = pl.maximum(amax, pl.row_max(pl.abs(q_fp32), pl.create_tile([8, 1024], dtype=pl.FP32)))
        dequant = pl.mul(amax, 1.0 / 127.0)
        denominator = pl.add(amax, 0.0)
        for lane in pl.range(valid):
            magnitude = pl.read(denominator, [lane, 0])
            if magnitude == 0.0:
                pl.write(denominator, [lane, 0], 1.0)
        multiplier = pl.div(pl.add(pl.mul(amax, 0.0), 127.0), denominator)
        pl.store(pl.set_validshape(dequant, valid, 1), [row, 0], token_scale)
        for group in pl.range(8):
            col = group * 1024
            quant_bf16 = pl.load(projected, [row, col], [8, 1024], valid_shape=[valid, 1024])
            quant_scaled = pl.row_expand_mul(pl.cast(quant_bf16, pl.FP32), multiplier)
            integer = pl.cast(quant_scaled, pl.INT32, mode='rint')
            half = pl.cast(integer, pl.FP16, mode='round')
            result = pl.cast(half, pl.INT8, mode='trunc')
            pl.store(pl.set_validshape(result, valid, 1024), [row, col], quantized)
    signals = publish(signals, 3, core, generation)
    signals = wait_group(signals, 4, 0, 24, generation)
    for block in pl.range(worker, row_tiles * 8, 48):
        row = block // 8 * 16
        col = block % 8 * 512
        valid = pl.min(16, rows - row)
        ob_integer = pl.load(integer_accum, [row, col], [16, 512], valid_shape=[valid, 512])
        channel = pl.reshape(pl.load(wo_b_scale, [col], [512]), [1, 512])
        scale = pl.load(token_scale, [row, 0], [16, 1], valid_shape=[valid, 1])
        coefficient_one = pl.tile.full([16, 512], dtype=pl.FP32, value=1.0)
        coefficient_channel = pl.col_expand_mul(coefficient_one, channel)
        coefficient = pl.row_expand_mul(coefficient_channel, scale)
        ob_scaled = pl.mul(pl.cast(ob_integer, pl.FP32), coefficient)
        pl.store(pl.cast(ob_scaled, pl.BF16, mode='rint'), [row, col], attended)
    signals = publish(signals, 5, core, generation)
    signals = wait_group(signals, 5, 24, 72, generation)
    t_dim = rows
    residual_flat = pl.reshape(residual, [t_dim, 16384])
    y_flat = pl.reshape(output, [t_dim, 16384])
    x = attended
    token_tiles = (t_dim + T_TILE - 1) // T_TILE
    for token_block in pl.range(worker, token_tiles, 48):
        t0 = token_block * T_TILE
        for t in pl.pipeline(t0, t0 + T_TILE, stage=2):
            if t < t_dim:
                x_block = pl.slice(x, [1, D], [t, 0])
                x_f32 = pl.cast(x_block, pl.FP32)
                res_0 = pl.cast(pl.slice(residual_flat, [1, D], [t, 0], valid_shape=[1, D], clamp=True), pl.FP32)
                res_1 = pl.cast(pl.slice(residual_flat, [1, D], [t, D + 0], valid_shape=[1, D], clamp=True), pl.FP32)
                res_2 = pl.cast(pl.slice(residual_flat, [1, D], [t, 2 * D + 0], valid_shape=[1, D], clamp=True), pl.FP32)
                res_3 = pl.cast(pl.slice(residual_flat, [1, D], [t, 3 * D + 0], valid_shape=[1, D], clamp=True), pl.FP32)
                for out_h in pl.unroll(HC_MULT):
                    post_scalar = pl.read(post, [t, out_h])
                    single_y = pl.mul(x_f32, post_scalar)
                    comb_scalar_0 = pl.read(comb, [t, out_h])
                    single_weighted_0 = pl.mul(res_0, comb_scalar_0)
                    single_y = pl.add(single_y, single_weighted_0)
                    comb_scalar_1 = pl.read(comb, [t, HC_MULT + out_h])
                    single_weighted_1 = pl.mul(res_1, comb_scalar_1)
                    single_y = pl.add(single_y, single_weighted_1)
                    comb_scalar_2 = pl.read(comb, [t, 2 * HC_MULT + out_h])
                    single_weighted_2 = pl.mul(res_2, comb_scalar_2)
                    single_y = pl.add(single_y, single_weighted_2)
                    comb_scalar_3 = pl.read(comb, [t, 3 * HC_MULT + out_h])
                    single_weighted_3 = pl.mul(res_3, comb_scalar_3)
                    single_y = pl.add(single_y, single_weighted_3)
                    single_result = pl.cast(single_y, pl.BF16, mode='rint')
                    y_flat[t:t + 1, out_h * D + 0:out_h * D + 0 + D] = pl.set_validshape(single_result, 1, D)
    pl.system.bar_all()
    return projected, quantized, token_scale, attended, output, accum, integer_accum, signals

@pl.jit.inline(auto_scope=False)
def group(heads: pl.Tensor[[T, 32768], pl.BF16],
wo_a: pl.Tensor[[8, 4096, 1024], pl.BF16, WO_A_WEIGHT_LAYOUT],
wo_b: pl.Tensor[[8192, 4096], pl.INT8, QUANT_WEIGHT_LAYOUT],
wo_b_scale: pl.Tensor[[4096], pl.FP32],
start: pl.Tensor[[16, 8, 8], pl.INT32],
projected: pl.InOut[pl.Tensor[[T, 8192], pl.BF16]],
quantized: pl.InOut[pl.Tensor[[T, 8192], pl.INT8]],
token_scale: pl.InOut[pl.Tensor[[T, 1], pl.FP32]],
attended: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]],
residual: pl.Tensor[[T, 4, 4096], pl.BF16],
post: pl.Tensor[[T, 4], pl.FP32],
comb: pl.Tensor[[T, 16], pl.FP32],
output: pl.InOut[pl.Tensor[[T, 4, 4096], pl.BF16]],
accum: pl.InOut[pl.Tensor[[ACC_ROWS, 8192], pl.FP32]],
integer_accum: pl.InOut[pl.Tensor[[INT_ROWS, 4096], pl.INT32]],
signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]],):
    with pl.cluster(name_hint="resident_precision_suffix"):
        projected, quantized, token_scale, attended, output, accum, integer_accum, signals = cube(heads, wo_a, wo_b, wo_b_scale, start, projected, quantized, token_scale, attended, residual, post, comb, output, accum, integer_accum, signals)
        projected, quantized, token_scale, attended, output, accum, integer_accum, signals = vector(heads, wo_a, wo_b, wo_b_scale, start, projected, quantized, token_scale, attended, residual, post, comb, output, accum, integer_accum, signals)
    return projected, quantized, token_scale, attended, output, accum, integer_accum, signals

@pl.jit
def resident_suffix(heads: pl.Tensor[[T, 32768], pl.BF16],
wo_a: pl.Tensor[[8, 4096, 1024], pl.BF16, WO_A_WEIGHT_LAYOUT],
wo_b: pl.Tensor[[8192, 4096], pl.INT8, QUANT_WEIGHT_LAYOUT],
wo_b_scale: pl.Tensor[[4096], pl.FP32],
start: pl.Tensor[[16, 8, 8], pl.INT32],
projected: pl.InOut[pl.Tensor[[T, 8192], pl.BF16]],
quantized: pl.InOut[pl.Tensor[[T, 8192], pl.INT8]],
token_scale: pl.InOut[pl.Tensor[[T, 1], pl.FP32]],
attended: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]],
residual: pl.Tensor[[T, 4, 4096], pl.BF16],
post: pl.Tensor[[T, 4], pl.FP32],
comb: pl.Tensor[[T, 16], pl.FP32],
output: pl.InOut[pl.Tensor[[T, 4, 4096], pl.BF16]],
accum: pl.InOut[pl.Tensor[[ACC_ROWS, 8192], pl.FP32]],
integer_accum: pl.InOut[pl.Tensor[[INT_ROWS, 4096], pl.INT32]],
signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]],):
    with pl.spmd(24, sync_start=True):
        projected, quantized, token_scale, attended, output, accum, integer_accum, signals = group(heads, wo_a, wo_b, wo_b_scale, start, projected, quantized, token_scale, attended, residual, post, comb, output, accum, integer_accum, signals)
    return projected, quantized, token_scale, attended, output, accum, integer_accum, signals
