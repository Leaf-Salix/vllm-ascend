#!/usr/bin/env bash
# 独立构建入口；不安装到既有验收环境。
set -euo pipefail
sdk=/data/pyptouser/yejia/csa-spmd-sdk-20261020
base_python=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/env/bin/python
base_bin=$(dirname "$base_python")
component=${1:?component required}
case "$component" in pypto|simpler|llvm|ptoas) ;; *) exit 2;; esac
export PYTHONNOUSERSITE=1
export TORCH_DEVICE_BACKEND_AUTOLOAD=0
export ASCEND_RT_VISIBLE_DEVICES=""
unset PYTHONPATH
set +u
source /data/pyptouser/yejia/vllm-cann92-main/env/Ascend/cann-9.2.0-beta.2/set_env.sh
set -u
export ASCEND_HOME_PATH=/data/pyptouser/yejia/vllm-cann92-main/env/Ascend/cann-9.2.0-beta.2
export CMAKE_BUILD_PARALLEL_LEVEL=2
export MAKEFLAGS=-j2
export MAX_JOBS=2
export PATH="$sdk/build-tools:$base_bin:$PATH"
export CC=/usr/bin/gcc CXX=/usr/bin/g++
export CCACHE_DIR="$sdk/sources/$component/.ccache"
mkdir -p "$CCACHE_DIR"
ccache -s
if [[ "$component" == pypto || "$component" == simpler ]]; then
  cd "$sdk/sources/$component"
  test -x .venv/bin/python || "$base_python" -m venv --system-site-packages .venv
  export PATH="$PWD/.venv/bin:$PATH"
  export VIRTUAL_ENV="$PWD/.venv"
  if [[ "$component" == pypto ]]; then
    source .claude/skills/testing/load-env.sh
    test "$PYPTO_BUILD_JOBS" -le 2
    cmake -G Ninja -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo \
      -DPYPTO_DEBUG_INFO_LEVEL=1 -DCMAKE_BUILD_PARALLEL_LEVEL=2 \
      -DBUILD_TESTING=OFF -DPython_EXECUTABLE="$VIRTUAL_ENV/bin/python" \
      -Dnanobind_DIR="$(python -m nanobind --cmake_dir)" \
      -DPYPTO_BUILD_TORCH_NPU=ON
    cmake --build build --parallel "$PYPTO_BUILD_JOBS"
  else
    python -m pip install --no-build-isolation --no-deps -v -e . \
      --config-settings=build.targets=_task_interface \
      --config-settings=cmake.define.CMAKE_C_COMPILER_LAUNCHER=ccache \
      --config-settings=cmake.define.CMAKE_CXX_COMPILER_LAUNCHER=ccache
  fi
elif [[ "$component" == llvm ]]; then
  cmake -G Ninja -S "$sdk/sources/llvm-project/llvm" -B "$sdk/llvm-build" \
    -DCMAKE_BUILD_TYPE=Release -DLLVM_ENABLE_PROJECTS=mlir \
    -DLLVM_TARGETS_TO_BUILD=AArch64 -DBUILD_SHARED_LIBS=ON \
    -DLLVM_ENABLE_ASSERTIONS=ON -DMLIR_ENABLE_BINDINGS_PYTHON=OFF \
    -DLLVM_INCLUDE_TESTS=OFF -DLLVM_INCLUDE_EXAMPLES=OFF -DLLVM_BUILD_TOOLS=OFF \
    -DMLIR_INCLUDE_TESTS=OFF -DMLIR_INCLUDE_EXAMPLES=OFF \
    -DCMAKE_C_COMPILER_LAUNCHER=ccache -DCMAKE_CXX_COMPILER_LAUNCHER=ccache
  "$base_python" "$sdk/llvm-build-targets.py"
else
  export LLVM_BUILD_DIR="$sdk/llvm-build"
  cmake -G Ninja -S "$sdk/sources/ptoas" -B "$sdk/sources/ptoas/build" \
    -DCMAKE_BUILD_TYPE=Release -DLLVM_DIR="$LLVM_BUILD_DIR/lib/cmake/llvm" \
    -DMLIR_DIR="$LLVM_BUILD_DIR/lib/cmake/mlir" -DPTO_ENABLE_PYTHON_BINDING=OFF \
    -DCANN_3RD_LIB_PATH="$sdk/sources" -DBUILD_TESTING=OFF \
    -DCMAKE_C_COMPILER_LAUNCHER=ccache -DCMAKE_CXX_COMPILER_LAUNCHER=ccache
  cmake --build "$sdk/sources/ptoas/build" --target ptoas-native --parallel 2
fi
ccache -s
