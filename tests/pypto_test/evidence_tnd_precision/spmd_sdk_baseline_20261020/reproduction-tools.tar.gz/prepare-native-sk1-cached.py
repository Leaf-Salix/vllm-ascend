"""从保留的 Native-only fresh runner 生成只使用完整 SK1 缓存的独立副本。"""
import ast
import hashlib
import json
from pathlib import Path
import shutil

r = Path(__file__).resolve().parent
source = r / 'native-sk1-tools'
out = r / 'native-sk1-cached-tools'
out.mkdir(exist_ok=False)
for name in ('binding.json', 'source_identity.py', 'ragged_fixture.py'):
    shutil.copy2(source / name, out / name)
s = (source / 'probe_csa.py').read_text()
s = s.replace('assert all(1<=q<=6 for q in lengths)',
              "assert lengths==[6]*16 and args.history==8191 and args.layer==4\nassert all(1<=q<=6 for q in lengths)")
a = s.index('    static_module._compute_opc_compile_jobs=')
b = s.index('    original_reselect=', a)
s = s[:a] + '''    cache=Path('/data/pyptouser/yejia/sk1b16-1020/cache-ready')
    cache_metadata=cache/'qualification.json'
    qualified=json.loads(cache_metadata.read_text())
    assert qualified['pass_'] and qualified['super_kernel'] is True
    assert qualified['soc']=='Ascend910_9392' and qualified['deterministic']=='1'
    assert qualified['cann']=='9.2.0.beta2'
    assert {str(p.relative_to(cache)) for p in cache.rglob('*.run')}==set(qualified['packages'])
    assert len(qualified['packages'])==1 and len(qualified['inputs'])==39
    assert {p.name for p in (cache.parent/'in').glob('*.json')}==set(qualified['inputs'])
    assert hashlib.sha256(Path(static_module.__file__).read_bytes()).hexdigest()==qualified['static_module_sha256']
    for relative,digest in qualified['packages'].items():
        assert hashlib.sha256((cache/relative).read_bytes()).hexdigest()==digest, relative
    for name,digest in qualified['inputs'].items():
        assert hashlib.sha256((cache.parent/'in'/name).read_bytes()).hexdigest()==digest, name
    report['offline_sk1_qualification']=qualified
    report['cache_metadata_sha256']=hashlib.sha256(cache_metadata.read_bytes()).hexdigest()
    original_static=static_module.compile_static_kernel
    assert original_static.__name__=='compile_static_kernel' and original_static.__module__.endswith('.static_kernel')
    assert static_module.static_compile.__name__=='static_compile'
    def refuse_fresh_compile(*values,**kwargs):
        raise RuntimeError('Qualified SK1 cache missed: device-task recompilation forbidden')
    static_module.static_compile=refuse_fresh_compile
''' + s[b:]
a = s.index("        build_root=args.out/'native-static-build'")
b = s.index('        opp=Path(', a)
s = s[:a] + '''        kwargs.update(use_cache_compile='1', compile_cache_dir=str(cache),
                      cached_cann_version=qualified['cann'], cached_deterministic=qualified['deterministic'])
        report.setdefault('official_compile',[]).append({'super_kernel':True,'cache':str(cache),'function_module':original_static.__module__})
        save()
        before_reselections=len(selection)
        value=original_static(fx_func,*values,**kwargs)
        assert len(selection)>before_reselections,'SK1 cache did not really reselect any package'
        packages=list(cache.rglob('*.run'))
        assert packages
''' + s[b:]
s = s.replace('Native-only fresh SK1 compile', 'Native-only qualified offline SK1 cache installation')
s = s.replace("'candidate_experiment':'accepted-Native-SK0-vs-frozen-precision-overlap'", "'candidate_experiment':'Native-SK1-only-compared-to-SK0-gold'")
s = s.replace('one SPMD prefix, original PTO suffix; full HC-pre through HC-post',
              'Native-only HC-pre through HC-post; no candidate execution')
s = s.replace('real layer weights, synthetic hidden/history, Native/TND complete CSA half-layer FULL graph; not whole model',
              'real layer weights, synthetic hidden/history, Native-only SK1 FULL graph; not whole model')
ast.parse(s)
(out / 'probe_csa.py').write_text(s)
(out / 'manifest.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest()
    for p in out.iterdir() if p.name != 'manifest.json'}, indent=2) + '\n')
runner=(r / 'run-native-sk1.sh').read_text().replace('/native-sk1-tools/', '/native-sk1-cached-tools/')
runner=runner.replace('lengths=$(python', 'export ASCEND_CUSTOM_OPP_PATH=/data/pyptouser/yejia/sk1b16-1020/custom-const/vendors/custom_transformer\nlengths=$(python')
(r / 'run-native-sk1-cached.sh').write_text(runner)
