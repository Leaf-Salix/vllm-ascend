"""待验resident后缀的无设备结构/资源检查，不授予数值资格。"""
import hashlib
import importlib.util
import json
from pathlib import Path
import runpy
import sys
import traceback

sdk = Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
sys.argv = [str(sdk / 'sdk-preflight.py')]
runpy.run_path(sys.argv[0], run_name='__main__')
import pypto.torch
from pypto import ir, passes
from pypto.ir._kernel_compile import kernel_abi_for_program
import torch_npu

out = sdk / 'results/frozen-overlap-lowering-v1'
out.mkdir(exist_ok=False)
report = {'pass': False, 'device_execution': False, 'scope': 'candidate symbolic lowering only; not numerical qualification', 'skip_ptoas': True}
try:
    import os
    experiment = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overlap-20261020')
    source_root = Path(os.environ['SOURCE_ROOT'])
    sys.path.insert(0, str(source_root))
    import vllm_ascend.ops.pypto as namespace
    namespace.__path__.insert(0, str(experiment / 'src/vllm_ascend/ops/pypto'))
    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.decode_csa import decode_csa_tp1_layer_test as entry
    receipt = json.loads((experiment / 'compile-full-csa-bf16layout.json').read_text())
    package = Path(entry.__wrapped__.__code__.co_filename).parent if hasattr(entry, '__wrapped__') else experiment / 'src/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision_spmd_overlap'
    package = experiment / 'src/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision_spmd_overlap'
    assert receipt['sources'] == {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in package.glob('*.py')}
    assert all(hashlib.sha256((source_root / name).read_bytes()).hexdigest() == sha for name, sha in receipt['baseline_sources'].items())
    report['frozen_sources'] = receipt['sources']
    report['baseline_sources'] = receipt['baseline_sources']
    program = entry.specialize()
    abi = kernel_abi_for_program(program, platform='a2a3', runtime='tensormap_and_ringbuffer')
    report['root_tensor_args'] = len(abi.parameters)
    assert len(abi.parameters) == 64
    op = pypto.torch.register(entry, 'frozen_overlap_new_sdk_probe::candidate')
    report['torch_schema'] = str(op._schema)
    ir.compile(program, output_dir=str(out / 'kernel'), skip_ptoas=True,
               platform='a2a3', memory_planner=passes.MemoryPlanner.PYPTO, dump_passes=True)
    report['lowering_completed'] = True
    assert not torch_npu.npu.is_initialized()
    report['pass'] = True
except BaseException:
    report['traceback'] = traceback.format_exc()
finally:
    (out / 'result.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps(report, indent=2, ensure_ascii=False), flush=True)
if not report['pass']:
    raise SystemExit(1)
