"""仅无设备 lowering/codegen：不将跳过 PTOAS 当成完整编译通过。"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import runpy
import sys
import traceback
import types

sdk = Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
sys.argv = [str(sdk / 'sdk-preflight.py')]
runpy.run_path(str(sdk / 'sdk-preflight.py'), run_name='__main__')
import pypto
from pypto import ir, passes
from pypto.ir.printer import python_print
import torch_npu

exp = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/spmd-baseline-20261020')
source = exp / 'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_spmd'
out = sdk / 'results/nal-resident-wheel-full-compile-v1'
out.mkdir(exist_ok=False)
report = dict(pass_=False, device_execution=False, skip_ptoas=False,
              scope='Pinned nalinaly source, device-free full PTOAS/CCEC binary compile; no hardware qualification')
try:
    os.environ['VLLM_ASCEND_ENABLE_NZ'] = '2'
    os.environ['VLLM_ASCEND_PTO_CSA_ATOMIC_ADD'] = '0'
    report['weight_nz_mode'] = 2
    report['atomic_add'] = 0
    assert 'vllm_ascend' not in sys.modules
    ascend = types.ModuleType('vllm_ascend')
    ascend.__path__ = [str(exp / 'vllm_ascend')]
    sys.modules[ascend.__name__] = ascend
    parent = types.ModuleType('nal_cpu_ops')
    parent.__path__ = [str(source.parent)]
    sys.modules[parent.__name__] = parent
    spec = importlib.util.spec_from_file_location('nal_cpu_ops.resident', source / '__init__.py',
                                                submodule_search_locations=[str(source)])
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    from nal_cpu_ops.resident.entry import decode_csa_spmd
    controls = json.loads((sdk / 'cpu_long_controls.json').read_text())
    report['controls'] = controls
    report['source_sha256'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in sorted(source.glob('*.py'))}
    report['dependency_sha256'] = {str(p.relative_to(exp)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in [exp / 'vllm_ascend/envs.py', *sorted((source.parent / 'deepseek_v4_flash_csa').glob('*.py'))]}
    program = decode_csa_spmd.specialize(**controls)
    symbolic = python_print(program)
    (out / 'symbolic.py').write_text(symbolic)
    report['symbolic_dynamic_axes'] = sorted(set(re.findall(r'pl.dynamic\("([^"]+)"\)', symbolic)))
    assert report['symbolic_dynamic_axes']
    from pypto.ir._kernel_compile import kernel_abi_for_program
    abi = kernel_abi_for_program(program, platform='a2a3', runtime='tensormap_and_ringbuffer')
    report['root_parameter_count'] = len(abi.parameters)
    report['route'] = 'native kernel artifact; no 130-argument Torch schema'
    assert not torch_npu.npu.is_initialized()
    from pypto.ir.compile import _compile_impl
    from pypto.runtime._kernel_artifact import KernelArtifact
    artifact = _compile_impl(program, _kernel_abi=abi, output_dir=str(out / 'kernel'), skip_ptoas=False,
                          platform='a2a3', memory_planner=passes.MemoryPlanner.PYPTO,
                          dump_passes=True)
    orchestration = '\n'.join(p.read_text() for p in (out / 'kernel/orchestration').glob('*.cpp'))
    report['submissions'] = re.findall(r'\brt_submit_\w+\s*\(', orchestration)
    assert len(report['submissions']) == 1 and 'MixedKernels' in orchestration
    report['sync_start'] = 'set_require_sync_start(true)' in orchestration
    assert report['sync_start']
    mlir = list((out / 'kernel').rglob('*.pto'))
    assert mlir
    text = '\n'.join(p.read_text() for p in mlir)
    report['mlir_files'] = [str(p.relative_to(out)) for p in mlir]
    report['signal_op_lines'] = [s.strip() for s in text.splitlines() if 'signal_' in s]
    assert report['signal_op_lines']
    report['ptoas_completed'] = True
    native = KernelArtifact(out / 'kernel', abi)
    native.load()
    report['kernel_callable_identity'] = native.identity().hex()
    report['ccec_and_orchestration_completed'] = True
    assert not torch_npu.npu.is_initialized()
    report['pass_'] = True
except BaseException:
    report['traceback'] = traceback.format_exc()
finally:
    (out / 'result.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps(report, indent=2, ensure_ascii=False), flush=True)
if not report['pass_']:
    raise SystemExit(1)
