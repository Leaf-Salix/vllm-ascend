"""为Native SK1离线编译创建私有OPP副本；仅修正只读tiling指针的const资格。"""
from pathlib import Path
import hashlib
import json
import shutil

work = Path("/data/pyptouser/yejia/sk1b16-1020")
origin = Path("/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/vllm-ascend/vllm_ascend/_cann_ops_custom")
target = work / "custom-const"
assert not target.exists()
shutil.copytree(origin, target, symlinks=True)
relative = Path("vendors/custom_transformer/op_impl/ai_core/tbe/custom_transformer_impl/ascendc/compressor_metadata/compressor_metadata.h")
header = target / relative
assert target in header.resolve().parents
old = (origin / relative).read_bytes()
before = b"Init(CompressorMetadataTilingData* tilingData, TPipe* pipe)"
after = b"Init(const CompressorMetadataTilingData* tilingData, TPipe* pipe)"
assert old.count(before) == 1
new = old.replace(before, after)
header.write_bytes(new)
assert new.replace(after, before) == old
assert hashlib.sha256((origin / relative).read_bytes()).hexdigest() == hashlib.sha256(old).hexdigest()
changes = []
for path in origin.rglob("*"):
    if path.is_file() and not path.is_symlink():
        rel = path.relative_to(origin)
        other = target / rel
        if path.read_bytes() != other.read_bytes():
            changes.append(str(rel))
assert changes == [str(relative)], changes
(work / "const-source-proof.json").write_text(json.dumps({
    "origin": str(origin), "private_copy": str(target), "changed_files": changes,
    "old_sha256": hashlib.sha256(old).hexdigest(), "new_sha256": hashlib.sha256(new).hexdigest(),
    "change": "read-only Init parameter CompressorMetadataTilingData* -> const CompressorMetadataTilingData*",
    "arithmetic_body_unchanged": True, "original_source_unchanged": True,
    "device_executed": False, "scope": "Native static compiler compatibility, not a PTO numerical fix",
}, indent=2) + "\n")
