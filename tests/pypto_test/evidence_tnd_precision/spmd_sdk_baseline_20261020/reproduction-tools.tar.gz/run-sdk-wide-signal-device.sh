#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
sdk=/data/pyptouser/yejia/csa-spmd-sdk-20261020
export PYTHONNOUSERSITE=1 TORCH_DEVICE_BACKEND_AUTOLOAD=0 ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
unset PYTHONPATH
set +u
source /data/pyptouser/yejia/vllm-cann92-main/env/Ascend/cann-9.2.0-beta.2/set_env.sh
set -u
export ASCEND_HOME_PATH=/data/pyptouser/yejia/vllm-cann92-main/env/Ascend/cann-9.2.0-beta.2
export PATH="$sdk/sources/pypto/.venv/bin:/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/env/bin:$PATH"
export PYTHONPATH="$sdk/sources/pypto/python:$sdk/sources/simpler/python:$sdk/sources/simpler:$sdk/sources/simpler/.venv/lib/python3.12/site-packages${PYTHONPATH:+:$PYTHONPATH}"
cd "$sdk/sources/pypto"
source .claude/skills/testing/load-env.sh
export CCACHE_DIR="$PWD/.ccache"
ccache -s
export PTOAS_ROOT="$sdk/toolchain-wheel"
export PATH="$PTOAS_ROOT/bin:$PATH"
export PYPTO_PROG_BUILD_DIR="$sdk/device-build" PYPTO_CACHE_DIR="$sdk/device-cache"
export ASCEND_CACHE_PATH="$sdk/results/signal-device-ascend-cache" ASCEND_PROCESS_LOG_PATH="$sdk/results/signal-device-ascend-log"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
test -s "$sdk/results/toolchain-wheel.json"
timeout 750s python "$sdk/sdk-wide-signal-gate.py" --device > "$sdk/logs/wide-signal-device.log" 2>&1
