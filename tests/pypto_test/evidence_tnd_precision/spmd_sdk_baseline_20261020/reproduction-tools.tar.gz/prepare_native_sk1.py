"""独立官方SK1新编译；不带入冻结PTO资格或SK0缓存桥。"""
import ast,hashlib,json,shutil
from pathlib import Path
r=Path(__file__).resolve().parent;o=r/'native-sk1-tools';o.mkdir(exist_ok=True)
for n in ('binding.json','source_identity.py','ragged_fixture.py'):shutil.copy2(r/'tools'/n,o/n)
s=(r/'sk0-tools/probe_csa.py').read_text()
a=s.index('import vllm_ascend.ops.pypto as spmd_namespace');b=s.index('class NativeHalf',a)
s=s[:a]+"from source_identity import source_identity\nreport.update(source_identity())\n"+s[b:]
s=s.replace("for arm in ('native','candidate'):","for arm in ('native',):")
s=s.replace('    pypto.torch.init()','    # Native-only process does not initialize a PTO worker.')
a=s.index('    # 保留原13包校验桥');b=s.index("    from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.native_adapter",a)
s=s[:a]+'''    assert not os.environ.get('LOW_ACCEPTANCE_OFFICIAL_CACHE')
    assert not os.environ.get('LOW_ACCEPTANCE_STATIC_MANIFEST')
    import npugraph_ex._acl_concrete_graph.static_kernel as static_module
    import npugraph_ex._acl_concrete_graph.acl_graph as acl_module
    static_module._compute_opc_compile_jobs=lambda: '4'
    report['native_static_compile_jobs']=4
    original_static=static_module.compile_static_kernel
    assert original_static.__name__=='compile_static_kernel' and original_static.__module__.endswith('.static_kernel')
    assert static_module.static_compile.__name__=='static_compile'
    original_reselect=torch_npu.npu._aclnn_reselect_static_kernel
    selection=[]
    def actual_reselect(*values,**kwargs):
        result=original_reselect(*values,**kwargs)
        selection.append(True)
        report['actual_static_reselections']=len(selection)
        return result
    torch_npu.npu._aclnn_reselect_static_kernel=actual_reselect
    def tracked_compile(fx_func,*values,**kwargs):
        actual_sk1=kwargs.get('super_kernel_optimize')
        report['actual_backend_super_kernel']={'value':actual_sk1,'type':type(actual_sk1).__name__}
        assert actual_sk1 is True or actual_sk1=='1'
        build_root=args.out/'native-static-build'
        build_root.mkdir(parents=True,exist_ok=True)
        kwargs.update(use_cache_compile=None, build_dir=str(build_root))
        report.setdefault('official_compile',[]).append({'super_kernel':True,'build_dir':kwargs['build_dir'],'function_module':original_static.__module__})
        save()
        before_reselections=len(selection)
        value=original_static(fx_func,*values,**kwargs)
        assert len(selection)>before_reselections,'SK1 compile did not really reselect any package'
        packages=list((args.out/'native-static-build').rglob('*.run'))
        assert packages,'SK1 compiler produced no static packages'
        opp=Path(os.environ['ASCEND_OPP_PATH'])
        assert str(opp.resolve()).startswith(str(args.out)+'-opp-env/')
        assert not (opp/'static_kernel').is_symlink()
        installed=list((opp/'static_kernel').rglob('*.json'))
        assert installed,'No independently installed static package metadata'
        report['official_packages']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in packages}
        report['installed_static_files']=len(list((opp/'static_kernel').rglob('*')))
        save()
        return value
    static_module.compile_static_kernel=tracked_compile
    acl_module.compile_static_kernel=tracked_compile
''' +s[b:]
s=s.replace("'super_kernel_optimize':False}","'super_kernel_optimize':True}").replace("'native_super_kernel_optimize':False}","'native_super_kernel_optimize':True}")
a=s.index("    assert all(exact(v.cpu(),packet_snapshots[k])");b=s.index('    if args.trace:',a)
s=s[:a]+"    report['timing_executed']=True\n"+s[b:]
s=s.replace("        assert all(exact(v.cpu(),packet_snapshots[k]) for k,v in readonly_packets.items()), 'trace packets'\n",'')
gate="""        def native_tensor_identity(v):
            c=v.detach().contiguous().cpu()
            return {'shape':list(c.shape),'dtype':str(c.dtype),'sha256':hashlib.sha256(c.view(torch.uint8).numpy().tobytes()).hexdigest()}
        golden=json.loads((Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/spmd-baseline-20261020/results/sk0-8k-b16-v1')/'result.json').read_text())
        assert golden['pass'] and golden['history']==args.history and golden['lengths']==lengths and golden['layer']==args.layer
        checked={
            'saved_native_identity':{n:native_tensor_identity(v) for n,v in states['native'].items()},
            'saved_native_inputs':{n:native_tensor_identity(f[n]) for n in ('hidden','positions')},
            'saved_native_initial_cache':{n:native_tensor_identity(g['initial']) for n,g in f['groups'].items()},
        }
        for field,identity in checked.items():
            report[field+'_equal_SK0_before_timing']=identity==golden[field]
            save()
            assert identity==golden[field], 'Native SK1 first bit mismatch vs SK0 at '+field
        assert details==golden['weight_details'], 'different checkpoint/loading contract'
"""
s=s.replace("        if arm!='native':\n            checks=",gate+"        if arm!='native':\n            checks=",1)
a=s.index("    report['complete']=report['pass']=True")
s=s[:a]+'''    golden=json.loads((Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/spmd-baseline-20261020/results/sk0-8k-b16-v1')/'result.json').read_text())
    assert golden['pass'] and golden['history']==args.history and golden['lengths']==lengths and golden['layer']==args.layer
    for field in ('saved_native_identity','saved_native_inputs','saved_native_initial_cache'):
        report[field+'_equal_SK0']=report[field]==golden[field]
        save()
        assert report[field+'_equal_SK0'],'Native SK1 first bit mismatch vs SK0 at '+field
    report['scope']='Native-only fresh SK1 compile, independent OPP, compared with frozen same-input SK0; no PTO runtime qualified here'
    report['complete']=report['pass']=True
''' +s[a+len("    report['complete']=report['pass']=True\n"):]
s=s.replace('Native SK0; determinism1','Native SK1; determinism1')
s='\n'.join(line for line in s.split('\n') if not ('from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.' in line and ('SerialOperators' in line or 'SerialRuntime' in line)))
ast.parse(s);(o/'probe_csa.py').write_text(s)
(o/'manifest.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in o.iterdir() if p.is_file() and p.name!='manifest.json'},indent=2)+'\n')
s=(r/'run-measurement.sh').read_text().replace('"$exp/tools/probe_csa.py"','"$exp/native-sk1-tools/probe_csa.py"')
s=s.replace('test ! -e "$out"','test ! -e "$out"\ntest ! -e "$out-opp-env"')
s=s.replace('ccache -s >', 'unset LOW_ACCEPTANCE_OFFICIAL_CACHE LOW_ACCEPTANCE_STATIC_MANIFEST\nccache -s >')
(r/'run-native-sk1.sh').write_text(s)
