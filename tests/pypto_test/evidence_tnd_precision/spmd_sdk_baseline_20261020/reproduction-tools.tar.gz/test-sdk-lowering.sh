#!/usr/bin/env bash
set -euo pipefail
sdk=/data/pyptouser/yejia/csa-spmd-sdk-20261020
export PYTHONNOUSERSITE=1 TORCH_DEVICE_BACKEND_AUTOLOAD=0 ASCEND_RT_VISIBLE_DEVICES=""
unset PYTHONPATH
set +u
source /data/pyptouser/yejia/vllm-cann92-main/env/Ascend/cann-9.2.0-beta.2/set_env.sh
set -u
export ASCEND_HOME_PATH=/data/pyptouser/yejia/vllm-cann92-main/env/Ascend/cann-9.2.0-beta.2
export PATH="$sdk/sources/pypto/.venv/bin:/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/env/bin:$PATH"
export PYTHONPATH="$sdk/sources/pypto/python:$sdk/sources/simpler/python:$sdk/sources/simpler:$sdk/sources/simpler/.venv/lib/python3.12/site-packages${PYTHONPATH:+:$PYTHONPATH}"
cd "$sdk/sources/pypto"
source .claude/skills/testing/load-env.sh
export CCACHE_DIR="$PWD/.ccache"
ccache -s
timeout 180s python "$sdk/sdk-lower-resident.py" > "$sdk/logs/resident-lowering.log" 2>&1
