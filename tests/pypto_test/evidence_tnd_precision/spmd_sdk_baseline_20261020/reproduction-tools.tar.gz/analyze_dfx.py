"""分离采集的L1时戳与依赖图匹配；阶段跨度包含内部等待，不能求和当总耗时。"""
import ast,collections,json,statistics,tarfile
from pathlib import Path
r=Path(__file__).resolve().parent
with tarfile.open(r/'dep-8k-b16-v1-evidence.tar.gz') as t:
 dep=json.load(t.extractfile('dfx/deps.json'));assert json.load(t.extractfile('result.json'))['pass']
tasks={int(x['task_id']):x for x in dep['tasks']};assert len(tasks)==len(dep['tasks'])
with tarfile.open(r/'dfx-8k-b16-v1-evidence.tar.gz') as t:
 report=json.load(t.extractfile('result.json'));assert report['pass'] and not report['timing_executed']
 assert report['DFX']['level']==1 and report['DFX']['enable_dep_gen'] is False
 maps=[]
 for member in t:
  if member.name.startswith('kernel-maps/'):
   tree=ast.parse(t.extractfile(member).read())
   for n in tree.body:
    if isinstance(n,ast.Assign) and any(isinstance(v,ast.Name) and v.id=='KERNELS' for v in n.targets):
     ks=ast.literal_eval(n.value)
     if len(ks)>2:maps.append({k['func_id']:k['name'] for k in ks})
 assert maps and all(m==maps[0] for m in maps)
 names=maps[0]
 windows={m.name:json.load(t.extractfile(m)) for m in t if m.name.endswith('chip_swimlane_records.json')}
def stage(fid):
 if fid<=1:return 'HC+Norm+WKV+Indexer权重前缀'
 if fid in (2,3):return 'Metadata/RoPE符号'
 if 4<=fid<=14:return '主Q/KV后处理'
 if 15<=fid<=18:return '主Compressor'
 if 19<=fid<=26:return 'Indexer Compressor'
 if 27<=fid<=30:return 'Indexer Query/Hadamard'
 if 31<=fid<=48:return 'Indexer Score/TopK'
 if 49<=fid<=56:return 'Sparse attention/逆RoPE'
 if 57<=fid<=63:return 'O-proj'
 if fid==64:return 'HC-post'
 raise AssertionError(fid)
outputs={}
for label,d in sorted(windows.items()):
 assert d['chip_swimlane_level']==1 and d['metadata']['clock_freq_hz']==50_000_000
 rows=d['aicore_tasks'];assert {x[0] for x in rows}==set(range(72))
 grouped=collections.defaultdict(list);funcs=collections.defaultdict(list);freq=d['metadata']['clock_freq_hz']
 for core,token,reg,start,end,r2s in rows:
  assert token in tasks and 0<start<=end and 0<=r2s<=start
  ks=tasks[token]['kernel_ids'];fid=ks[0] if core<24 else next((k for k in ks[1:] if k>=0),-1)
  assert fid>=0 and fid in names
  grouped[stage(fid)].append((start,end));funcs[names[fid]].append((start,end))
 lo=min(x[3] for x in rows);hi=max(x[4] for x in rows)
 intervals=sorted((x[3],x[4]) for x in rows);merged=[]
 for a,b in intervals:
  if not merged or a>merged[-1][1]:merged.append([a,b])
  else:merged[-1][1]=max(merged[-1][1],b)
 us=lambda c:c*1e6/freq
 def summarize(v):return {'inclusive_span_us':us(max(b for a,b in v)-min(a for a,b in v)),
  'max_single_core_task_us':us(max(b-a for a,b in v)),'records':len(v),
  'start_relative_us':us(min(a for a,b in v)-lo),'end_relative_us':us(max(b for a,b in v)-lo)}
 outputs[label]={'complete_incore_span_us':us(hi-lo),'no_incore_active_us':us(hi-lo-sum(b-a for a,b in merged)),
 'records':len(rows),'unique_runtime_tasks':len({x[1] for x in rows}),'all_records_named':True,
 'stages':{k:summarize(v) for k,v in grouped.items()},'functions':{k:summarize(v) for k,v in funcs.items()}}
summary={k:statistics.median(v['inclusive_span_us'] for d in outputs.values() for kk,v in d['stages'].items() if kk==k) for k in next(iter(outputs.values()))['stages']}
out={'pass':True,'method':'L1-only windows; separately collected dep_gen mapping; all task tokens and AIC/AIV slots resolved; stages overlap and include internal waits',
 'complete_incore_median_us':statistics.median(d['complete_incore_span_us'] for d in outputs.values()),
 'no_incore_active_median_us':statistics.median(d['no_incore_active_us'] for d in outputs.values()),
 'stage_inclusive_medians_us':summary,'windows':outputs}
(r/'DFX_STAGE_ANALYSIS.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print('complete',out['complete_incore_median_us'],'no-incore-active',out['no_incore_active_median_us'])
for k,v in sorted(summary.items(),key=lambda kv:-kv[1]):print(k,round(v,2))
