"""独立DFX任务：不把插桩时间混成正式延迟。"""
import ast,hashlib,json,shutil
from pathlib import Path
r=Path(__file__).resolve().parent;o=r/'dfx-tools';o.mkdir(exist_ok=True)
for n in ('binding.json','source_identity.py','ragged_fixture.py'):shutil.copy2(r/'tools'/n,o/n)
s=(r/'sk0-tools/probe_csa.py').read_text()
s=s.replace('pypto.torch.init()',"pypto.torch.init(enable_chip_swimlane=1,enable_dep_gen=False,output_dir=args.out/'dfx')")
a=s.index('    samples={arm:[] for arm in rows}');b=s.index("    assert all(exact(v.cpu(),packet_snapshots[k])",a)
s=s[:a]+'''    graph,f,output,topk=rows['candidate']
    windows=[]
    for repeat in range(3):
        restore(f);restore_readonly(f);torch.npu.synchronize()
        pypto.torch.begin_dfx()
        graph.replay()
        pypto.torch.end_dfx()
        actual=collect_state(f,output,topk)
        assert all(exact(value,states['candidate'][name]) for name,value in actual.items()),'DFX state drift'
        assert all(g['status']=='PASS' for g in guard_checks(f).values()),'DFX guards'
        windows.append(repeat)
    report['DFX']={'level':1,'enable_dep_gen':False,'windows':windows,'replays_per_window':1,'scope':'stage diagnosis only, separate task from uninstrumented performance'}
'''+s[b:]
s=s.replace("    if args.trace:\n", "    if False:\n")
s=s.replace("report['timing_executed']=True","report['timing_executed']=False")
ast.parse(s);(o/'probe_csa.py').write_text(s)
(o/'manifest.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in o.iterdir() if p.is_file() and p.name!='manifest.json'},indent=2)+'\n')
s=(r/'run-measurement.sh').read_text().replace('"$exp/tools/probe_csa.py"','"$exp/dfx-tools/probe_csa.py"').replace(' --trace >',' >')
(r/'run-dfx.sh').write_text(s)
