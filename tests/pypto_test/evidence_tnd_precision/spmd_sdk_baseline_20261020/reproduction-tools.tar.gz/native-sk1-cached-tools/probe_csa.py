"""8K真实权重、Native/TND完整CSA FULL图验收；首差停止。"""
import argparse
import contextlib
import hashlib
import importlib
import json
import os
from pathlib import Path
import statistics
import sys
import types

import torch
import torch_npu
import pypto.torch
from vllm.config import CUDAGraphMode
from vllm.engine.arg_utils import EngineArgs
from vllm.forward_context import get_forward_context
from vllm.platforms import current_platform
from vllm_ascend.ascend_forward_context import set_ascend_forward_context
import vllm_ascend.ops.dsv4_csa
from dsv4_csa_native_case import native_session
from dsv4_csa_single_layer import make_layer, restore, collect_state, guard_checks
from ragged_fixture import make_ragged_fixture
from npugraph_ex._acl_concrete_graph.acl_graph import AclGraph

ROOT = Path(__file__).resolve().parent
BASE = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
META_SHA = '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--lengths', default='1,1,1,1')
parser.add_argument('--layer', type=int, default=4)
parser.add_argument('--history', type=int, default=8191)
parser.add_argument('--trace', action='store_true')
args = parser.parse_args()
lengths = list(map(int,args.lengths.split(',')))
tokens, batch = sum(lengths), len(lengths)
assert lengths==[6]*16 and args.history==8191 and args.layer==4
assert all(1<=q<=6 for q in lengths) and batch<=40 and tokens<=256
assert not (args.out/'result.json').exists()
args.out.mkdir(parents=True,exist_ok=True)
expected_helpers=json.loads((ROOT/'manifest.json').read_text())
helper_sha={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in expected_helpers}
assert helper_sha==expected_helpers,'helper source identity mismatch'
manifest_sha=hashlib.sha256((ROOT/'manifest.json').read_bytes()).hexdigest()
report = {'helper_sha':helper_sha,'manifest_sha256':manifest_sha,'complete':False,'pass':False,'scope':'real layer weights, synthetic hidden/history, Native-only SK1 FULL graph; not whole model',
          'lengths':lengths,'true_tokens':tokens,'physical_graph_tokens':tokens,'per_request_padding':0,
          'hypothetical_s6_tokens':batch*6,'hypothetical_s6_extra_rows':batch*6-tokens,
          'baseline_experiment':'Native direct HC-pre through HC-post', 'candidate_experiment':'Native-SK1-only-compared-to-SK0-gold',
          'candidate_variant':'Native-only HC-pre through HC-post; no candidate execution',
          'layer':args.layer,'history':args.history,'graphs':{},'comparisons':{},'static':{}}
def save():
    (args.out/'result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
def exact(x,y):
    return x.shape==y.shape and x.dtype==y.dtype and torch.equal(x.contiguous().view(torch.uint8),y.contiguous().view(torch.uint8))
def metric(x,y):
    if x.shape!=y.shape or x.dtype!=y.dtype:
        return {'bit_equal':False,'shapes':[list(x.shape),list(y.shape)],'dtypes':[str(x.dtype),str(y.dtype)]}
    if x.is_floating_point():
        assert bool(torch.isfinite(x).all()) and bool(torch.isfinite(y).all()), 'nonfinite external float boundary'
    equal=exact(x,y)
    delta=x.float()-y.float()
    return {'bit_equal':equal,'different_elements':int((x!=y).sum()),'max_abs':float(delta.abs().max()),
            'relative_l2':float(torch.linalg.vector_norm(delta)/torch.linalg.vector_norm(y.float()).clamp_min(1e-30)),
            'first_coordinates':(x!=y).nonzero()[:6].tolist()}

from source_identity import source_identity
report.update(source_identity())
class NativeHalf(torch.nn.Module):
    def __init__(self,layer):
        super().__init__();self.layer=layer
    def forward(self,hidden,positions,output):
        l=self.layer
        mixed,post,comb=l.hc_pre(hidden,l.hc_attn_fn,l.hc_attn_scale,l.hc_attn_base)
        normed=l.input_layernorm(mixed)
        attended=l.self_attn(positions=positions,hidden_states=normed,llama_4_scaling=None)
        output.copy_(l.hc_post(attended,hidden,post,comb))
        return output

class PTOHalf(torch.nn.Module):
    def __init__(self,prefix):
        super().__init__();self.prefix=prefix
    def forward(self,hidden,positions,output):
        torch.ops.vllm.dsv4_csa_forward(hidden,positions,output,self.prefix)
        return output

class RequirePTO:
    def __init__(self,delegate):
        self.delegate,self.calls=delegate,0
    def eligible(self,*values):
        if not self.delegate.eligible(*values):
            raise RuntimeError('Unexpected PTO fallback')
        return True
    def __call__(self,*values,**kwargs):
        self.calls+=1
        return self.delegate(*values,**kwargs)

current_platform.pre_register_and_update()
torch.npu.set_device(0)
torch.npu.config.allow_internal_format=True
torch.use_deterministic_algorithms(True)
torch_npu.npu.set_deterministic_level(1)
torch.set_num_threads(4)
from vllm_ascend.utils import enable_custom_op
assert enable_custom_op()
checkpoint=Path('/data/model/DeepSeek-V4-Flash-0731-w8a8')
config=EngineArgs(model=str(checkpoint),tokenizer_mode='deepseek_v4',trust_remote_code=True,
 tensor_parallel_size=1,dtype='bfloat16',quantization='ascend',hf_overrides={'sliding_window':128},
 max_model_len=16384,max_num_seqs=40,max_num_batched_tokens=256,enable_prefix_caching=False,
 enforce_eager=False,block_size=32,speculative_config={'method':'dspark','num_speculative_tokens':5,'enforce_eager':True},
 compilation_config={'cudagraph_mode':'FULL_DECODE_ONLY','cudagraph_capture_sizes':[tokens],'cache_dir':str(args.out/'vllm-cache')},
 additional_config={'ascend_compilation_config':{'enable_npugraph_ex':True,'enable_static_kernel':True,'fuse_norm_quant':True,'align_decode_capture_sizes':False},
 'enable_cpu_binding':False,'multistream_overlap_shared_expert':True,'weight_nz_mode':2,'enable_kv_nz':False,'enable_dsa_cp':False,'multistream_dsv4_dsa_overlap':True}).create_engine_config()

states, fixtures, rows, keepalive, b_states = {}, {}, {}, [], {}
save()
try:
 with native_session(config,0),torch.inference_mode():
    layer,details=make_layer(config,checkpoint,torch.device('npu:0'),args.layer)
    report['weight_details']=details
    report['native_DSA_multistream_config']=bool(layer.self_attn.dsa_attn.dsa_attn.impl.multistream_dsv4_dsa_overlap)
    assert report['native_DSA_multistream_config']
    # Native-only process does not initialize a PTO worker.
    impl=layer.self_attn.dsa_attn.dsa_attn.impl
    observed={}
    original_qli=torch.ops._C_ascend.npu_vllm_quant_lightning_indexer
    def observe_qli(*values,**kwargs):
        result=original_qli(*values,**kwargs);observed['topk']=result[0];return result
    torch.ops._C_ascend.npu_vllm_quant_lightning_indexer=observe_qli
    assert not os.environ.get('LOW_ACCEPTANCE_OFFICIAL_CACHE')
    assert not os.environ.get('LOW_ACCEPTANCE_STATIC_MANIFEST')
    import npugraph_ex._acl_concrete_graph.static_kernel as static_module
    import npugraph_ex._acl_concrete_graph.acl_graph as acl_module
    cache=Path('/data/pyptouser/yejia/sk1b16-1020/cache-ready')
    cache_metadata=cache/'qualification.json'
    qualified=json.loads(cache_metadata.read_text())
    assert qualified['pass_'] and qualified['super_kernel'] is True
    assert qualified['soc']=='Ascend910_9392' and qualified['deterministic']=='1'
    assert qualified['cann']=='9.2.0.beta2'
    assert {str(p.relative_to(cache)) for p in cache.rglob('*.run')}==set(qualified['packages'])
    assert len(qualified['packages'])==1 and len(qualified['inputs'])==39
    assert {p.name for p in (cache.parent/'in').glob('*.json')}==set(qualified['inputs'])
    assert hashlib.sha256(Path(static_module.__file__).read_bytes()).hexdigest()==qualified['static_module_sha256']
    for relative,digest in qualified['packages'].items():
        assert hashlib.sha256((cache/relative).read_bytes()).hexdigest()==digest, relative
    for name,digest in qualified['inputs'].items():
        assert hashlib.sha256((cache.parent/'in'/name).read_bytes()).hexdigest()==digest, name
    report['offline_sk1_qualification']=qualified
    report['cache_metadata_sha256']=hashlib.sha256(cache_metadata.read_bytes()).hexdigest()
    original_static=static_module.compile_static_kernel
    assert original_static.__name__=='compile_static_kernel' and original_static.__module__.endswith('.static_kernel')
    assert static_module.static_compile.__name__=='static_compile'
    def refuse_fresh_compile(*values,**kwargs):
        raise RuntimeError('Qualified SK1 cache missed: device-task recompilation forbidden')
    static_module.static_compile=refuse_fresh_compile
    original_reselect=torch_npu.npu._aclnn_reselect_static_kernel
    selection=[]
    def actual_reselect(*values,**kwargs):
        result=original_reselect(*values,**kwargs)
        selection.append(True)
        report['actual_static_reselections']=len(selection)
        return result
    torch_npu.npu._aclnn_reselect_static_kernel=actual_reselect
    def tracked_compile(fx_func,*values,**kwargs):
        actual_sk1=kwargs.get('super_kernel_optimize')
        report['actual_backend_super_kernel']={'value':actual_sk1,'type':type(actual_sk1).__name__}
        assert actual_sk1 is True or actual_sk1=='1'
        kwargs.update(use_cache_compile='1', compile_cache_dir=str(cache),
                      cached_cann_version=qualified['cann'], cached_deterministic=qualified['deterministic'])
        report.setdefault('official_compile',[]).append({'super_kernel':True,'cache':str(cache),'function_module':original_static.__module__})
        save()
        before_reselections=len(selection)
        value=original_static(fx_func,*values,**kwargs)
        assert len(selection)>before_reselections,'SK1 cache did not really reselect any package'
        packages=list(cache.rglob('*.run'))
        assert packages
        opp=Path(os.environ['ASCEND_OPP_PATH'])
        assert str(opp.resolve()).startswith(str(args.out)+'-opp-env/')
        assert not (opp/'static_kernel').is_symlink()
        installed=list((opp/'static_kernel').rglob('*.json'))
        assert installed,'No independently installed static package metadata'
        report['official_packages']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in packages}
        report['installed_static_files']=len(list((opp/'static_kernel').rglob('*')))
        save()
        return value
    static_module.compile_static_kernel=tracked_compile
    acl_module.compile_static_kernel=tracked_compile
    for arm in ('native',):
        print('ARM_START',arm,flush=True)
        torch._dynamo.reset()
        f=make_ragged_fixture(config,layer.self_attn,batch,args.history,1024,torch.device('npu:0'),lengths)
        fixtures[arm]=f
        if arm!='native':
            for field in ('hidden','positions'):
                assert exact(f[field],fixtures['native'][field]),(arm,field)
            for name,g in f['groups'].items():
                assert exact(g['initial'],fixtures['native']['groups'][name]['initial']),(arm,name)
        runtime=None
        if arm!='native':
            operators=(SerialOperators if arm=='serial' else CSAOperators).register()
            with torch.inference_mode(False), torch.enable_grad():
                keepalive.append(layer.hc_attn_fn)  # Retain captured Native weight storage.
                layer.hc_attn_fn=torch.nn.Parameter(layer.hc_attn_fn.detach().clone(),requires_grad=True)
                runtime=(SerialRuntime if arm=='serial' else CSAServiceRuntime)(layer.self_attn,operators,40,layer)
                report['model_loading_prepare_context']={'grad_enabled_after_constructor':torch.is_grad_enabled(),'source_requires_grad':layer.hc_attn_fn.requires_grad,'source_inference':torch.is_inference(layer.hc_attn_fn),'packed_requires_grad':runtime.weights['hc_packed_weight'].requires_grad}
                assert torch.is_grad_enabled() and layer.hc_attn_fn.requires_grad
                assert not runtime.weights['hc_packed_weight'].requires_grad

            from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.workspace import NORM_PARAMETERS
            norm_offset=0
            norm_packet_checks={}
            for name,size in NORM_PARAMETERS:
                norm_packet_checks[name]=exact(runtime.norm_packet[norm_offset:norm_offset+size].cpu(),runtime.weights[name].cpu())
                norm_offset+=size
            assert norm_offset==6272 and all(norm_packet_checks.values())
            order_checks={}
            for (w,i,o),packet in operators.workspace.order_packets.items():
                cpu=packet.cpu()
                order_checks[str((w,i,o))]=all((exact(cpu[:512],runtime.wkv_orders[w].cpu().reshape(-1)),
                    exact(cpu[512:1536],runtime.indexer_orders[i].cpu().reshape(-1)),
                    exact(cpu[1536:],runtime.oproj_starts[o].cpu().reshape(-1))))
            assert len(order_checks)==33 and all(order_checks.values())
            report['packet_checks']={'norm_byte_equal':norm_packet_checks,'order_byte_equal':order_checks,
                'norm_bytes_per_layer':runtime.norm_packet.numel()*runtime.norm_packet.element_size(),
                'order_bytes_per_model':sum(t.numel()*t.element_size() for t in operators.workspace.order_packets.values())}
            readonly_packets={'norm':runtime.norm_packet,'hc_packed':runtime.weights['hc_packed_weight'],**{str(k):v for k,v in operators.workspace.order_packets.items()}}
            packet_snapshots={k:v.cpu() for k,v in readonly_packets.items()}
            report['hc_weight_qualification']=dict(runtime.hc_weight_qualification)
            assert report['hc_weight_qualification']['version']==1
            assert selection,'Native graph did not install and select static packages'
            runtime.qualify_static_wkv(metadata_sha256=META_SHA,reselected=True)
        @contextlib.contextmanager
        def context():
            with set_ascend_forward_context(f['metadata'],config,num_tokens=tokens,num_actual_tokens=tokens,
                                            aclgraph_runtime_mode=CUDAGraphMode.FULL):
                assert get_forward_context().cudagraph_runtime_mode is CUDAGraphMode.FULL
                yield
        if runtime is not None:
            with context():
                eligible=runtime.eligible(get_forward_context(),f['hidden'],f['positions'])
            report.setdefault('entry',{})[arm]={'eligible':eligible,'route':'PTO' if eligible else 'Native fallback','metadata':{
                name:{'bounds':f['metadata'][g['prefix']].decode.query_start_loc.cpu().tolist(),
                      'max_q':f['metadata'][g['prefix']].decode.max_seqlen_q,
                      'num_decodes':f['metadata'][g['prefix']].num_decodes,
                      'actual_tokens':f['metadata'][g['prefix']].num_actual_tokens} for name,g in f['groups'].items()}}
            save()
            assert eligible, 'TND precision fallback is forbidden'
            guarded=RequirePTO(runtime)
            layer.self_attn.dsa_attn._pto_csa_runtime=guarded
        else:
            layer.self_attn.dsa_attn._pto_csa_runtime=None
        output=torch.empty_like(f['hidden'])
        module=NativeHalf(layer) if arm=='native' else PTOHalf(layer.self_attn.dsa_attn.prefix)
        restore(f)
        with context():module(f['hidden'],f['positions'],output)
        torch.npu.synchronize()
        instances={}
        old_run=AclGraph.run
        def record(owner,key,*values,**kwargs):
            instances[(id(owner),key)]=owner
            return old_run(owner,key,*values,**kwargs)
        AclGraph.run=record
        options={'force_eager':False,'inplace_pass':True,'clone_input':False,'clone_output':False,
                 'static_kernel_compile':True,'super_kernel_optimize':True}
        torch.npu.set_compile_mode(jit_compile=False)
        try:
            compiled=torch.compile(module,backend='npugraph_ex',fullgraph=True,dynamic=False,options=options)
            restore(f)
            with context():compiled(f['hidden'],f['positions'],output)
            torch.npu.synchronize()
            assert len(instances)==1,(arm,'not exactly one actual graph',len(instances))
            (_,key),owner=next(iter(instances.items()))
            assert not owner._updated_node_infos,'Host updated nodes invalidate raw replay test'
            graph=owner.graph[key]
        finally:
            AclGraph.run=old_run
        topk=runtime.topk[:tokens] if runtime is not None and report['entry'][arm]['eligible'] else observed['topk']
        compiled_state=collect_state(f,output,topk)
        restore(f);output.fill_(float('nan'));topk.fill_(-12345);graph.replay();torch.npu.synchronize()
        actual=collect_state(f,output,topk)
        assert all(exact(value,compiled_state[name]) for name,value in actual.items()),(arm,'compiled/raw mismatch')
        assert torch.isfinite(output).all()
        guards=guard_checks(f)
        assert all(value['status']=='PASS' for value in guards.values()),(arm,'guard',guards)
        states[arm]=actual
        rows[arm]=(graph,f,output,topk)
        keepalive.append((compiled,module,owner,runtime))
        report['graphs'][arm]={'actual_acl_graph':True,'fullgraph':True,'options':options,
                                'true_tokens':tokens,'graph_tokens':tokens,'guards':guards,'compiled_raw_equal':True,
                                'topk_poison_replay_restored':True,'native_super_kernel_optimize':True}
        def native_tensor_identity(v):
            c=v.detach().contiguous().cpu()
            return {'shape':list(c.shape),'dtype':str(c.dtype),'sha256':hashlib.sha256(c.view(torch.uint8).numpy().tobytes()).hexdigest()}
        golden=json.loads((Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/spmd-baseline-20261020/results/sk0-8k-b16-v1')/'result.json').read_text())
        assert golden['pass'] and golden['history']==args.history and golden['lengths']==lengths and golden['layer']==args.layer
        checked={
            'saved_native_identity':{n:native_tensor_identity(v) for n,v in states['native'].items()},
            'saved_native_inputs':{n:native_tensor_identity(f[n]) for n in ('hidden','positions')},
            'saved_native_initial_cache':{n:native_tensor_identity(g['initial']) for n,g in f['groups'].items()},
        }
        for field,identity in checked.items():
            report[field+'_equal_SK0_before_timing']=identity==golden[field]
            save()
            assert identity==golden[field], 'Native SK1 first bit mismatch vs SK0 at '+field
        assert details==golden['weight_details'], 'different checkpoint/loading contract'
        if arm!='native':
            checks={name:metric(value,states['native'][name]) for name,value in actual.items()}
            report['comparisons'][arm]=checks
            save()
            if not all(check['bit_equal'] for check in checks.values()):
                report['first_failed_arm']=arm
                report['failed_boundaries']=[name for name,m in checks.items() if not m['bit_equal']]
                raise RuntimeError(arm+': first bit difference; stop matrix and timing')
        before=f['hidden'].clone()
        restore(f);f['hidden'].add_(0.125);graph.replay();torch.npu.synchronize()
        assert not exact(output.cpu(),actual['x_out']),(arm,'stale input graph')
        b_states[arm]=collect_state(f,output,topk)
        if arm!='native':
            b_checks={name:metric(value,b_states['native'][name]) for name,value in b_states[arm].items()}
            report.setdefault('B_comparisons',{})[arm]=b_checks;save()
            if not all(check['bit_equal'] for check in b_checks.values()):
                torch.save(b_states,args.out/'first-B-difference.pt')
                raise RuntimeError('TND input B first bit difference; stop')
        assert all(value['status']=='PASS' for value in guard_checks(f).values()),(arm,'B guards')
        f['hidden'].copy_(before);restore(f);graph.replay();torch.npu.synchronize()
        restored=collect_state(f,output,topk)
        assert all(exact(value,actual[name]) for name,value in restored.items()),(arm,'A restore')
        report['graphs'][arm]['live_input_ABA']=True
        if runtime is not None:
            assert guarded.calls>0,'PTO runtime was never invoked'
            report['graphs'][arm]['pto_dispatch_calls']=guarded.calls
            schema=str(runtime.operators.attention._schema)
            expected_namespace=('dsv4_csa_tnd_precision_spmd_bf16layout::attention' if arm=='serial' else 'dsv4_csa_tnd_precision_spmd_overlap::attention')
            assert schema.startswith(expected_namespace+'('),(arm,schema)
            assert schema.split(' -> ')[0].count('Tensor')==64,(arm,schema)
            report['graphs'][arm]['root_schema']=schema
            report['workspace_bytes']=sum(v.numel()*v.element_size() for v in operators.workspace.buffers.values())
            report['hc_packed_weight_bytes']=runtime.weights['hc_packed_weight'].numel()*runtime.weights['hc_packed_weight'].element_size()
            report['workspace_capture_stream']=operators.workspace.capture_stream
        save()
        print('ARM_PASS',arm,flush=True)
    def restore_readonly(fixture):
        for live,expected in fixture['readonly'].values():live.copy_(expected)
    report['cross_bucket_scope']='not re-run: frozen candidate had passed earlier; this task rechecks SK1 comparator and timing only'
    samples={arm:[] for arm in rows}
    arms=list(rows)
    for arm in arms:
        graph,f,output,topk=rows[arm]
        restore(f)
        for warm in range(3):graph.replay()
    torch.npu.synchronize()
    for round_id in range(12):
        for arm in arms if round_id%2==0 else list(reversed(arms)):
            graph,f,output,topk=rows[arm]
            restore(f);restore_readonly(f)
            assert all(c['status']=='PASS' for c in guard_checks(f).values())
            torch.npu.synchronize()
            start,end=torch.npu.Event(enable_timing=True),torch.npu.Event(enable_timing=True)
            start.record()
            for iteration in range(100):graph.replay()
            end.record();end.synchronize()
            samples[arm].append(start.elapsed_time(end)*1000/100)
            actual=collect_state(f,output,topk)
            assert all(exact(value,states[arm][name]) for name,value in actual.items()),(arm,'timing state drift')
            assert all(g['status']=='PASS' for g in guard_checks(f).values()),(arm,'timing guards')
    report['timings']={'windows':12,'replays_per_window':100,'outliers_removed':False,'unit':'us/complete HC-pre through HC-post raw graph replay; Native SK1; determinism1; no DFX',
        'samples':samples,'summary':{arm:{'min':min(v),'mean':statistics.mean(v),'median':statistics.median(v),'max':max(v)} for arm,v in samples.items()}}
    report['timing_executed']=True
    if args.trace:
        for arm in arms:
            graph,f,output,topk=rows[arm]
            restore(f);restore_readonly(f);torch.npu.synchronize()
            with torch_npu.profiler.profile(activities=[torch_npu.profiler.ProfilerActivity.CPU,torch_npu.profiler.ProfilerActivity.NPU],record_shapes=True) as prof:
                for _ in range(3):graph.replay()
                torch.npu.synchronize()
            prof.export_chrome_trace(str(args.out/(arm+'-trace.json')))
            actual=collect_state(f,output,topk)
            assert all(exact(value,states[arm][name]) for name,value in actual.items()),(arm,'posttrace state drift')
        assert all(g['status']=='PASS' for g in guard_checks(f).values()), 'trace guards'
        report['trace_separate_from_timing']=True
    def tensor_identity(v):
        c=v.detach().contiguous().cpu()
        return {'shape':list(c.shape),'dtype':str(c.dtype),'sha256':hashlib.sha256(c.view(torch.uint8).numpy().tobytes()).hexdigest()}
    report['saved_native_identity']={n:tensor_identity(v) for n,v in states['native'].items()}
    report['saved_native_inputs']={n:tensor_identity(fixtures['native'][n]) for n in ('hidden','positions')}
    report['saved_native_initial_cache']={n:tensor_identity(v['initial']) for n,v in fixtures['native']['groups'].items()}
    golden=json.loads((Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/spmd-baseline-20261020/results/sk0-8k-b16-v1')/'result.json').read_text())
    assert golden['pass'] and golden['history']==args.history and golden['lengths']==lengths and golden['layer']==args.layer
    for field in ('saved_native_identity','saved_native_inputs','saved_native_initial_cache'):
        report[field+'_equal_SK0']=report[field]==golden[field]
        save()
        assert report[field+'_equal_SK0'],'Native SK1 first bit mismatch vs SK0 at '+field
    report['scope']='Native-only qualified offline SK1 cache installation, independent OPP, compared with frozen same-input SK0; no PTO runtime qualified here'
    report['complete']=report['pass']=True
    save()
except Exception as exc:
    report['error']=repr(exc)
    save()
    torch.save({'states':states,'inputs':{arm:{'hidden':f['hidden'].cpu(),'positions':f['positions'].cpu(),
                    'initial':{name:g['initial'] for name,g in f['groups'].items()}} for arm,f in fixtures.items()}},args.out/'first-difference.pt')
    raise
print('COMPLETE',report['pass'],lengths,flush=True)
