"""仅生成独立调度候选：数学AST取自冻结精度源，暂不接入服务。"""
import ast
import copy
import hashlib
import json
from pathlib import Path

here = Path(__file__).resolve().parent
repo = here.parents[1] / 'vllm-ascend-nalinaly-tnd-20261008-codex'
base = repo / 'vllm_ascend/ops/pypto'
oproj = base / 'deepseek_v4_flash_csa_tnd_full_precision/o_proj.py'
post = base / 'deepseek_v4_flash_csa_tnd_precision/hc_post.py'
original = ast.parse(oproj.read_text())
f = next(n for n in original.body if isinstance(n, ast.FunctionDef) and n.name == '_o_proj_test')
assert len(f.body) == 16 and f.body[8].lineno == 30
post_tree = ast.parse(post.read_text())
hc = next(n for n in post_tree.body if isinstance(n, ast.FunctionDef) and n.name == '_hc_post')
hc_block = next(n for n in post_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'hc_post_block')
proof = {'sources': {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest() for p in (oproj, post)},
         'scope': 'AST-generated private candidate only; not installed or device qualified', 'math_ast': {}}


def code(nodes):
    return '\n'.join(ast.unparse(ast.fix_missing_locations(n)) for n in nodes)


def stride_loop(loop, workers):
    assert isinstance(loop, ast.For) and ast.unparse(loop.iter.func) == 'pl.spmd'
    result = copy.deepcopy(loop)
    result.iter = ast.parse(f'pl.range(worker, {ast.unparse(loop.iter.args[0])}, {workers})', mode='eval').body
    return result


def cube_a(branch):
    outer = branch[0]
    inner = outer.body[0]
    assert ast.unparse(outer.iter.func) == 'pl.parallel' and ast.unparse(inner.iter.func) == 'pl.spmd'
    assert ast.unparse(outer.iter.args[0]) == ast.unparse(inner.iter.args[0]) == '8'
    assignments = ast.parse(f'{outer.target.id} = logical // 8\n{inner.target.id} = logical % 8').body
    loop = ast.For(target=ast.Name(id='logical', ctx=ast.Store()),
                   iter=ast.parse('pl.range(worker, 64, 24)', mode='eval').body,
                   body=[*assignments, *copy.deepcopy(inner.body)], orelse=[])
    return loop


a_stage = copy.deepcopy(f.body[8])
a_stage.body = [cube_a(f.body[8].body)]
a_stage.orelse = [cube_a(f.body[8].orelse)]
b_stage = copy.deepcopy(f.body[13])
b_stage.body = [stride_loop(f.body[13].body[0], 24)]
b_stage.orelse = [stride_loop(f.body[13].orelse[0], 24)]
bf16 = stride_loop(f.body[9], 48)
quant = stride_loop(f.body[11], 48)
dequant = stride_loop(f.body[14], 48)
post_loop = next(n for n in hc.body if isinstance(n, ast.For))
hc_loop = stride_loop(post_loop, 48)
for name, before, after in (
    ('woa_large', f.body[8].body[0].body[0].body, a_stage.body[0].body[2:]),
    ('woa_small', f.body[8].orelse[0].body[0].body, a_stage.orelse[0].body[2:]),
    ('wob_narrow', f.body[13].body[0].body, b_stage.body[0].body),
    ('wob_wide', f.body[13].orelse[0].body, b_stage.orelse[0].body),
):
    assert ast.dump(ast.Module(body=before, type_ignores=[]), include_attributes=False) == ast.dump(ast.Module(body=after, type_ignores=[]), include_attributes=False)
    proof['math_ast'][name] = 'identical per logical worker'
# 固定每个逻辑worker输出的数学，只有grid领取方式改变。
for name, before, after in (
    ('bf16', f.body[9].body, bf16.body), ('quant', f.body[11].body, quant.body),
    ('dequant', f.body[14].body, dequant.body), ('hc_post', post_loop.body, hc_loop.body),
):
    assert ast.dump(ast.Module(body=before, type_ignores=[]), include_attributes=False) == ast.dump(ast.Module(body=after, type_ignores=[]), include_attributes=False)
    proof['math_ast'][name] = 'identical per logical worker'

# 展开原 inline helper，避免新 specializer 丢失 reshape 后的动态 Tensor 元数据。
# 只替换形参引用，逐条保留数学 AST 和运算顺序。
class ExpandHC(ast.NodeTransformer):
    def visit_Assign(self, node):
        if not isinstance(node.value, ast.Call) or not isinstance(node.value.func, ast.Name) or node.value.func.id != 'hc_post_block':
            return self.generic_visit(node)
        bindings = dict(zip([a.arg for a in hc_block.args.args], node.value.args, strict=True))
        class Bind(ast.NodeTransformer):
            def visit_Name(self, n):
                return copy.deepcopy(bindings[n.id]) if n.id in bindings else n
        expanded = [Bind().visit(copy.deepcopy(n)) for n in hc_block.body if not isinstance(n, ast.Return)]
        proof['math_ast']['hc_post_block'] = 'original body expanded by exact argument substitution; no arithmetic changes'
        return expanded
hc_loop = ExpandHC().visit(hc_loop)

# 使用assemble的原位副作用写回，保持参数身份；不让条件/循环的assemble SSA
# 结果跨MIX角色传递。生成IR必须证明所有GM写回保留，禁止仅凭编译通过验收。
class ExplicitWorkspaceStore(ast.NodeTransformer):
    def visit_Assign(self, node):
        call = node.value
        if isinstance(call, ast.Call) and ast.unparse(call.func) == 'pl.assemble' and ast.unparse(call.args[0]) in ('accum', 'integer_accum'):
            target, value, offsets = call.args
            proof.setdefault('workspace_stores', []).append(ast.unparse(node))
            return ast.Expr(value=copy.deepcopy(call))
        if len(node.targets) == 1 and isinstance(node.targets[0], ast.Subscript) and ast.unparse(node.targets[0].value) == 'integer_accum':
            target = node.targets[0]
            offsets = ast.List(elts=[x.lower for x in target.slice.elts], ctx=ast.Load())
            proof.setdefault('workspace_stores', []).append(ast.unparse(node))
            return ast.Expr(value=ast.Call(func=ast.parse('pl.assemble', mode='eval').body, args=[target.value, node.value, offsets], keywords=[]))
        return self.generic_visit(node)
class PreserveAccumulatorOrder(ast.NodeTransformer):
    def visit_For(self, node):
        self.generic_visit(node)
        if isinstance(node.target, ast.Name) and node.target.id == 'v4_wide_packet':
            assert ast.unparse(node.iter.func) == 'pl.pipeline'
            assert ast.unparse(node.iter.args[0]) == '15'
            node.iter.func = ast.parse('pl.range', mode='eval').body
            node.iter.keywords = []
            proof['pipeline_adjustment'] = 'v4_wide_packet only: pipeline(15,stage=2) to range(15); same sequential MMA/K order'
        return node

a_stage = PreserveAccumulatorOrder().visit(a_stage)
a_stage = ExplicitWorkspaceStore().visit(a_stage)
b_stage = ExplicitWorkspaceStore().visit(b_stage)

header = '''# SPDX-License-Identifier: Apache-2.0
"""独立O-proj/HC-post常驻候选；只换worker/grid/同步，未获设备资格。"""
import pypto.language as pl
T = pl.dynamic("RESIDENT_SUFFIX_T")
ACC_ROWS = pl.dynamic("RESIDENT_SUFFIX_ACC_ROWS")
INT_ROWS = pl.dynamic("RESIDENT_SUFFIX_INT_ROWS")
WO_A_WEIGHT_LAYOUT = pl.NZ
QUANT_WEIGHT_LAYOUT = pl.NZ
D = 4096
HC_MULT = 4
T_TILE = 4
STRIDE = 128
CORES = 72
WORDS = 6 * CORES * STRIDE

@pl.jit.inline(auto_scope=False)
def begin(signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]], core: pl.Scalar[pl.INDEX]):
    offset = core * STRIDE
    pl.system.cacheinvalid(signals, [1], [offset])
    pl.system.fence()
    generation = pl.read(signals, [offset]) + pl.cast(1, pl.INT32)
    pl.system.bar_all()
    pl.system.signal_notify(signals, [offset], generation)
    return signals, generation

@pl.jit.inline(auto_scope=False)
def publish(signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]], phase: pl.Scalar[pl.INDEX], core: pl.Scalar[pl.INDEX], generation: pl.Scalar[pl.INT32]):
    pl.system.bar_all()
    pl.system.fence()
    pl.system.cacheinvalid()
    pl.system.fence()
    pl.system.signal_notify(signals, [(phase * CORES + core) * STRIDE], generation)
    return signals

@pl.jit.inline(auto_scope=False)
def wait_group(signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]], phase: pl.Scalar[pl.INDEX], first: pl.Scalar[pl.INDEX], last: pl.Scalar[pl.INDEX], generation: pl.Scalar[pl.INT32]):
    for owner in pl.range(first, last):
        pl.system.signal_wait(signals, [(phase * CORES + owner) * STRIDE], generation)
    pl.system.fence()
    pl.system.cacheinvalid()
    pl.system.fence()
    return signals
'''
args = '''heads: pl.Tensor[[T, 32768], pl.BF16],
wo_a: pl.Tensor[[8, 4096, 1024], pl.BF16, WO_A_WEIGHT_LAYOUT],
wo_b: pl.Tensor[[8192, 4096], pl.INT8, QUANT_WEIGHT_LAYOUT],
wo_b_scale: pl.Tensor[[4096], pl.FP32],
start: pl.Tensor[[16, 8, 8], pl.INT32],
projected: pl.InOut[pl.Tensor[[T, 8192], pl.BF16]],
quantized: pl.InOut[pl.Tensor[[T, 8192], pl.INT8]],
token_scale: pl.InOut[pl.Tensor[[T, 1], pl.FP32]],
attended: pl.InOut[pl.Tensor[[T, 4096], pl.BF16]],
residual: pl.Tensor[[T, 16384], pl.BF16],
post: pl.Tensor[[T, 4], pl.FP32],
comb: pl.Tensor[[T, 16], pl.FP32],
output: pl.InOut[pl.Tensor[[T, 16384], pl.BF16]],
accum: pl.InOut[pl.Tensor[[ACC_ROWS, 8192], pl.FP32]],
integer_accum: pl.InOut[pl.Tensor[[INT_ROWS, 4096], pl.INT32]],
signals: pl.InOut[pl.Tensor[[WORDS], pl.INT32]],'''
names = [arg.arg for arg in ast.parse('def temp(' + args + '): pass').body[0].args.args]
calls = ', '.join(names)


def function(name, decorator, body):
    body_text = body if isinstance(body, str) else code(body)
    return f'\n@{decorator}\ndef {name}({args}):\n' + '\n'.join('    ' + line for line in body_text.splitlines()) + '\n'


cube = '''worker = pl.tile.get_block_idx()
signals, generation = begin(signals, worker)
rows = pl.tensor.dim(heads, 0)
row_tiles = (rows + 15) // 16
''' + code([a_stage]) + '''
signals = publish(signals, 1, worker, generation)
signals = wait_group(signals, 3, 24, 72, generation)
''' + code([b_stage]) + '''
signals = publish(signals, 4, worker, generation)
return projected, quantized, token_scale, attended, output, accum, integer_accum, signals
'''
vector = '''pl.func_attr({"split_aiv": True})
worker = pl.tile.get_block_idx() * 2 + pl.tile.get_subblock_idx()
core = 24 + worker
signals, generation = begin(signals, core)
rows = pl.tensor.dim(heads, 0)
row_tiles = (rows + 15) // 16
signals = wait_group(signals, 1, 0, 24, generation)
''' + code([bf16]) + '''
signals = publish(signals, 2, core, generation)
signals = wait_group(signals, 2, 24, 72, generation)
quant_rows = (rows + 7) // 8
''' + code([quant]) + '''
signals = publish(signals, 3, core, generation)
signals = wait_group(signals, 4, 0, 24, generation)
''' + code([dequant]).replace(', output)', ', attended)') + '''
signals = publish(signals, 5, core, generation)
signals = wait_group(signals, 5, 24, 72, generation)
t_dim = rows
residual_flat = residual
y_flat = output
x = attended
token_tiles = (t_dim + T_TILE - 1) // T_TILE
''' + code([hc_loop]) + '''
pl.system.bar_all()
return projected, quantized, token_scale, attended, output, accum, integer_accum, signals
'''
group = f'''with pl.cluster(name_hint="resident_precision_suffix"):
    projected, quantized, token_scale, attended, output, accum, integer_accum, signals = cube({calls})
    projected, quantized, token_scale, attended, output, accum, integer_accum, signals = vector({calls})
return projected, quantized, token_scale, attended, output, accum, integer_accum, signals
'''
entry = f'''with pl.spmd(24, sync_start=True):
    projected, quantized, token_scale, attended, output, accum, integer_accum, signals = group({calls})
return projected, quantized, token_scale, attended, output, accum, integer_accum, signals
'''
typed_hc = copy.deepcopy(hc_block)
types = {
    'x_block': 'pl.Tensor[[1, 4096], pl.BF16]',
    'residual_flat': 'pl.Tensor[[T, 16384], pl.BF16]',
    'post': 'pl.Tensor[[T, 4], pl.FP32]',
    'comb': 'pl.Tensor[[T, 16], pl.FP32]',
    'y_flat': 'pl.Out[pl.Tensor[[T, 16384], pl.BF16]]',
}
for arg in typed_hc.args.args:
    if arg.arg in types:
        arg.annotation = ast.parse(types[arg.arg], mode='eval').body
assert ast.dump(ast.Module(body=typed_hc.body, type_ignores=[]), include_attributes=False) == ast.dump(ast.Module(body=hc_block.body, type_ignores=[]), include_attributes=False)
# hc_post_block has been expanded above; retain the exact substitution proof.
source = header + '\n'
source += function('cube', 'pl.jit.incore', cube)
source += function('vector', 'pl.jit.incore', vector)
source += function('group', 'pl.jit.inline(auto_scope=False)', group)
source += function('resident_suffix', 'pl.jit', entry)
ast.parse(source)
destination = here / 'resident-suffix-candidate.py'
destination.write_text(source)
proof['candidate_sha256'] = hashlib.sha256(destination.read_bytes()).hexdigest()
proof['root_tensors'] = len(names)
proof['source_changes'] = ['external GM workspace', '24/48 strided logical worker grids', 'single MIX with per-phase GM signals', 'residual/output root uses zero-copy [T,16384] descriptors instead of in-core dynamic reshape']
(here / 'RESIDENT_SUFFIX_SOURCE_PROOF.json').write_text(json.dumps(proof, indent=2, ensure_ascii=False) + '\n')
