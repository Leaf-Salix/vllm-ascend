"""从本次PTOAS CMake链接声明选出实际存在的LLVM/MLIR依赖目标。"""
from pathlib import Path
import json
import re
import subprocess

sdk = Path("/data/pyptouser/yejia/csa-spmd-sdk-20261020")
build = sdk / "llvm-build"
referenced = {"llvm-tblgen", "mlir-tblgen"}
for path in (sdk / "sources/ptoas").rglob("CMakeLists.txt"):
    referenced.update(re.findall(r"\b(?:MLIR|LLVM)[A-Z][A-Za-z0-9_]*\b", path.read_text()))
available = {
    line.partition(": ")[0]
    for line in subprocess.check_output(["ninja", "-C", str(build), "-t", "targets", "all"], text=True).splitlines()
}
targets = sorted(referenced & available)
assert {"MLIRIR", "MLIRParser", "MLIRTransforms", "LLVMSupport", "mlir-tblgen", "llvm-tblgen"} <= set(targets)
(sdk / "results/llvm-targets.json").write_text(json.dumps({
    "selection": "PTOAS CMake declared LLVM/MLIR targets plus tablegen; no source changes",
    "targets": targets,
    "not_cmake_targets": sorted(referenced - available),
}, indent=2) + "\n")
subprocess.run(["cmake", "--build", str(build), "--target", *targets, "--parallel", "2"], check=True)
