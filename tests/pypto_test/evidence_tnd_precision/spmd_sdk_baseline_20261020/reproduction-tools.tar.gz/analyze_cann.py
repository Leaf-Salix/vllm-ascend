"""重读CANN trace：设备跨度与跨流事实；不把重叠阶段时间相加。"""
import collections,json,statistics
from pathlib import Path
from decimal import Decimal as D
root=Path(__file__).resolve().parent/'results/sk0-8k-b16-v1';out={}
for arm in ('native','candidate'):
 d=json.loads((root/(arm+'-trace.json')).read_text());ev=d['traceEvents'] if isinstance(d,dict) else d
 xs=[x for x in ev if x.get('ph')=='X' and 'Task Type' in x.get('args',{})]
 starts=sorted(D(str(x['ts'])) for x in xs if x['name']=='MODEL_EXECUTE')
 windows=[]
 for i,start in enumerate(starts):
  stop=starts[i+1] if i+1<len(starts) else D('Infinity')
  rows=[x for x in xs if start<=D(str(x['ts']))<stop]
  work=[x for x in rows if x['args']['Task Type'].startswith('KERNEL') or 'AICPU' in x['args']['Task Type'] or x['args']['Task Type']=='MEMCPY_ASYNC']
  assert work
  span=max(D(str(x['ts']))+D(str(x['dur'])) for x in work)-min(D(str(x['ts'])) for x in work)
  allspan=max(D(str(x['ts']))+D(str(x['dur'])) for x in rows)-min(D(str(x['ts'])) for x in rows)
  windows.append({'device_work_span_us':float(span),'all_model_task_span_us':float(allspan),'streams':sorted({x['tid'] for x in work}),
    'tasks':[{'name':x['name'],'type':x['args']['Task Type'],'stream':x['tid'],'relative_start_us':float(D(str(x['ts']))-start),'duration_us':x['dur']} for x in work]})
 out[arm]={'windows':windows,'median_device_work_span_us':statistics.median(w['device_work_span_us'] for w in windows),
  'has_multiple_device_work_streams':all(len(w['streams'])>1 for w in windows),
  'has_superkernel_named_task':any('super' in x['name'].lower() for x in xs)}
out['scope']='separate 3-replay profiler diagnostic; not the uninstrumented 12x100 metric; stream work includes kernels/AICPU/memcpy and all_model includes event/model tasks'
(root/'CANN_TRACE_ANALYSIS.json').write_text(json.dumps(out,indent=2)+'\n')
for k in ('native','candidate'):print(k,{n:v for n,v in out[k].items() if n!='windows'})
