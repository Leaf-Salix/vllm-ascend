"""只做PTOAS/CCEC与kernel ABI二进制组装；不初始化或执行NPU。"""
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import runpy
import sys
import traceback

case = sys.argv[1]
assert case in ('signal', 'suffix', 'frozen')
sdk = Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
sys.argv = [str(sdk / 'sdk-preflight.py')]
runpy.run_path(sys.argv[0], run_name='__main__')
import torch_npu
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program
from pypto.runtime._kernel_artifact import KernelArtifact

out = sdk / f'results/{case}-wheel-full-compile-v1'
out.mkdir(exist_ok=False)
report = {'pass': False, 'device_execution': False, 'case': case,
          'PTOAS_ROOT': os.environ['PTOAS_ROOT'], 'skip_ptoas': False}
try:
    source = sdk / ('sdk-wide-signal-gate.py' if case == 'signal' else 'resident-suffix-candidate.py')
    report['source_sha256'] = hashlib.sha256(source.read_bytes()).hexdigest()
    (out / 'source.py').write_bytes(source.read_bytes())
    spec = importlib.util.spec_from_file_location(f'private_{case}_full_compile', source)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    if case == 'frozen':
        experiment = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overlap-20261020')
        sys.path.insert(0, os.environ['SOURCE_ROOT'])
        import vllm_ascend.ops.pypto as namespace
        namespace.__path__.insert(0, str(experiment / 'src/vllm_ascend/ops/pypto'))
        from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.decode_csa import decode_csa_tp1_layer_test as entry
        receipt = json.loads((experiment / 'compile-full-csa-bf16layout.json').read_text())
        root = experiment / 'src/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision_spmd_overlap'
        assert receipt['sources'] == {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*.py')}
        assert all(hashlib.sha256((Path(os.environ['SOURCE_ROOT']) / n).read_bytes()).hexdigest() == h for n,h in receipt['baseline_sources'].items())
        report['frozen_sources'] = receipt['sources']
        report['baseline_sources'] = receipt['baseline_sources']
        report.pop('source_sha256')
        (out / 'source.py').unlink()
    elif case == 'signal':
        tree = ast.parse(source.read_text())
        stop = next(i for i, n in enumerate(tree.body) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'out' for t in n.targets))
        # 原函数定义逐字保留；只不执行该脚本末尾CPU/设备runner。
        exec(compile(ast.Module(body=tree.body[:stop], type_ignores=[]), str(source), 'exec'), module.__dict__)
        entry = module.signal_gate
    else:
        spec.loader.exec_module(module)
        entry = module.resident_suffix
    program = entry.specialize()
    abi = kernel_abi_for_program(program, platform='a2a3', runtime='tensormap_and_ringbuffer')
    report['root_tensor_args'] = len(abi.parameters)
    assert len(abi.parameters) == (132 if case == 'signal' else 64 if case == 'frozen' else 16)
    _compile_impl(program, output_dir=str(out / 'kernel'), platform='a2a3', dump_passes=True,
                  skip_ptoas=False, _kernel_abi=abi)
    report['ptoas_completed'] = True
    artifact = KernelArtifact(out / 'kernel', abi)
    artifact.load()
    report['kernel_callable_identity'] = artifact.identity().hex()
    report['ccec_and_orchestration_completed'] = True
    report['artifacts'] = {str(p.relative_to(out)): hashlib.sha256(p.read_bytes()).hexdigest() for p in (out / 'kernel').rglob('*') if p.is_file() and p.suffix in ('.cpp', '.pto', '.so', '.elf', '.bin', '.json')}
    assert not torch_npu.npu.is_initialized()
    report['npu_initialized'] = False
    report['pass'] = True
except BaseException:
    report['traceback'] = traceback.format_exc()
finally:
    (out / 'result.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)
if not report['pass']:
    raise SystemExit(1)
