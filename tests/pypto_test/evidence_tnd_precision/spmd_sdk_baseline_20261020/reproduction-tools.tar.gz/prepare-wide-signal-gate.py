"""从最小信号门禁生成132Tensor native-JIT版本；不走已知受限的Torch schema。"""
import ast
from pathlib import Path

root = Path(__file__).resolve().parent
tree = ast.parse((root / 'sdk-signal-gate.py').read_text())
count = 128
names = [f'extra_{i:03d}' for i in range(count)]
annotation = ast.parse('pl.Tensor[[1], pl.FP32]', mode='eval').body


class Wide(ast.NodeTransformer):
    def visit_FunctionDef(self, node):
        if node.name in ('producer', 'mixed_group', 'signal_gate'):
            node.args.args.extend(ast.arg(arg=name, annotation=annotation) for name in names)
        if node.name == 'producer':
            math = node.body[2:6]
            assert len(math) == 4 and ast.unparse(math[-1]).startswith('pl.store(c,')
            parts = [f'pl.read({name}, [0]) * {i + 1}.0' for i, name in enumerate(names)]
            checksum = ast.parse('checksum = ' + ' + '.join(parts)).body[0]
            expected = sum(i * i for i in range(1, count + 1))
            # 均走同一FIX写回路径。坏参数令第一矩阵读邻居，形成可检测数值差异；
            # 不将Scalar写与FIX写混入同一个GM Tensor，也不省略notify造成死锁。
            owner = ast.parse(f'''source_owner = worker
if checksum != {expected}.0:
    source_owner = (worker + 1) % GROUPS
''').body
            math[0] = ast.parse('a = pl.load(matrix, [source_owner * 16, 0], [16, 16])').body[0]
            node.body[2:6] = [checksum, *owner, *math]
        return self.generic_visit(node)

    def visit_Call(self, node):
        if isinstance(node.func, ast.Name) and node.func.id in ('producer', 'mixed_group'):
            node.args.extend(ast.Name(id=name, ctx=ast.Load()) for name in names)
        if isinstance(node.func, ast.Name) and node.func.id == 'op':
            node.args.append(ast.Starred(value=ast.Name(id='extras', ctx=ast.Load()), ctx=ast.Load()))
        return self.generic_visit(node)


tree = ast.fix_missing_locations(Wide().visit(tree))
text = ast.unparse(tree) + '\n'
text = text.replace('results/signal-device-v1', 'results/wide-signal-device-v1')
text = text.replace('results/signal-lowering-v4', 'results/wide-signal-lowering-v2')
old = "op = pypto.torch.register(signal_gate, 'sdk_signal_gate::run', config=config)"
assert old in text
text = text.replace(old, 'op = lambda *values: signal_gate(*values, config=config)')
text = text.replace('generations = [check(1.0)]', 'generations = [check(1.0)]')
needle = 'op(signal, matrix, payload, output, *extras)'
assert text.count(needle) == 2
first = text.index(needle)
text = text[:first] + "extras = [torch.full((1,), float(i + 1), device='npu') for i in range(128)]\n        " + text[first:]
text = text.replace("report = {'pass': False,", "report = {'root_tensor_args': 132, 'route': 'native JIT prepare/enqueue; no 132-arg Torch schema', 'pass': False,")
ast.parse(text)
(root / 'sdk-wide-signal-gate.py').write_text(text)
runner = (root / 'test-sdk-signal-lowering.sh').read_text().replace('sdk-signal-gate.py', 'sdk-wide-signal-gate.py').replace('signal-lowering.log', 'wide-signal-lowering.log')
(root / 'test-sdk-wide-signal-lowering.sh').write_text(runner)
