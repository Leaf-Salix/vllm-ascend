"""不初始化设备，确认冻结DSL及SPMD ABI依赖。"""
import ast,hashlib,json,os
from pathlib import Path
import pypto,pypto.language as pl,simpler
exp=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/spmd-baseline-20261020')
assert os.environ['ASCEND_RT_VISIBLE_DEVICES']=='' and os.environ['TORCH_DEVICE_BACKEND_AUTOLOAD']=='0'
entry=exp/'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_spmd/entry.py'
t=ast.parse(entry.read_text())
signatures={}
for f in t.body:
 if isinstance(f,ast.FunctionDef):
  args=[a for a in f.args.args if a.annotation is not None]
  signatures[f.name]={'tensor_arguments':sum('Tensor' in ast.unparse(a.annotation) for a in args),'constexpr':sum('constexpr' in ast.unparse(a.annotation) for a in args)}
d={'device_initialized':False,'pypto':pypto.__file__,'simpler':simpler.__file__,'PTOAS_ROOT':os.environ['PTOAS_ROOT'],'ASCEND_HOME_PATH':os.environ['ASCEND_HOME_PATH'],
 'source_sha256':hashlib.sha256(entry.read_bytes()).hexdigest(),'nalinaly_commit':'beaefa6f6788a9448d49293238f6818c246f24f5','signatures':signatures,
 'DSL_system':{n:hasattr(pl.system,n) for n in ('signal_notify','signal_wait','bar_all','syncall','cacheinvalid','fence')},
 'scope':'read-only API availability; not a device compile or numerical validation'}
(exp/'CAPABILITIES.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2))
