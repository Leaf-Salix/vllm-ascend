#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
case_name=${1:?}; batch=${2:?}; history=${3:?}
[[ "$case_name" =~ ^[a-z0-9-]+$ && "$batch" =~ ^[0-9]+$ && "$history" =~ ^[0-9]+$ ]]
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/vector-mte2-20261019-codex/full-csa-live-staging-v2/env.sh"
export SPMD_EXPERIMENT="$base/precision-overlap-20261020"
exp="$base/spmd-baseline-20261020"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE" PYTHONNOUSERSITE=1 HCCL_DETERMINISTIC=true
export PYPTO_PROG_BUILD_DIR="$exp/build" PYPTO_CACHE_DIR="$exp/cache"
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache CMAKE_BUILD_PARALLEL_LEVEL=4
out="$exp/results/$case_name"
test ! -e "$out"
test ! -e "$out-opp-env"
mkdir -p "$exp/results"
export ASCEND_CACHE_PATH="$out-ascend-cache" ASCEND_PROCESS_LOG_PATH="$out-ascend-log" VLLM_CACHE_ROOT="$out-vllm-cache"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out-opp-env")
lengths=$(python -c 'import sys;print(",".join(["6"]*int(sys.argv[1])))' "$batch")
unset LOW_ACCEPTANCE_OFFICIAL_CACHE LOW_ACCEPTANCE_STATIC_MANIFEST
ccache -s > "$out-ccache.log"
timeout 750s python "$exp/native-sk1-tools/probe_csa.py" --out "$out" --lengths "$lengths" --layer 4 --history "$history" --trace > "$out-run.log" 2>&1
