"""待验resident后缀的无设备结构/资源检查，不授予数值资格。"""
import hashlib
import importlib.util
import json
from pathlib import Path
import runpy
import sys
import traceback

sdk = Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
sys.argv = [str(sdk / 'sdk-preflight.py')]
runpy.run_path(sys.argv[0], run_name='__main__')
import pypto.torch
from pypto import ir, passes
from pypto.ir._kernel_compile import kernel_abi_for_program
import torch_npu

out = sdk / 'results/resident-suffix-lowering-v8'
out.mkdir(exist_ok=False)
report = {'pass': False, 'device_execution': False, 'scope': 'candidate symbolic lowering only; not numerical qualification', 'skip_ptoas': True}
try:
    source = sdk / 'resident-suffix-candidate.py'
    proof = json.loads((sdk / 'RESIDENT_SUFFIX_SOURCE_PROOF.json').read_text())
    assert hashlib.sha256(source.read_bytes()).hexdigest() == proof['candidate_sha256']
    (out / 'source.py').write_bytes(source.read_bytes())
    report['source_proof'] = proof
    spec = importlib.util.spec_from_file_location('resident_precision_suffix_cpu', source)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    entry = module.resident_suffix
    program = entry.specialize()
    abi = kernel_abi_for_program(program, platform='a2a3', runtime='tensormap_and_ringbuffer')
    report['root_tensor_args'] = len(abi.parameters)
    assert len(abi.parameters) == 16
    op = pypto.torch.register(entry, 'resident_suffix_probe::candidate')
    report['torch_schema'] = str(op._schema)
    ir.compile(program, output_dir=str(out / 'kernel'), skip_ptoas=True,
               platform='a2a3', memory_planner=passes.MemoryPlanner.PYPTO, dump_passes=True)
    orch = '\n'.join(p.read_text() for p in (out / 'kernel/orchestration').glob('*.cpp'))
    assert orch.count('rt_submit_task(') == 1 and 'MixedKernels' in orch
    assert 'set_require_sync_start(true)' in orch
    assert 'rt_alloc' not in orch
    report.update(single_mix=True, sync_start=True, orchestration_allocates=False)
    assert not torch_npu.npu.is_initialized()
    report['pass'] = True
except BaseException:
    report['traceback'] = traceback.format_exc()
finally:
    (out / 'result.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps(report, indent=2, ensure_ascii=False), flush=True)
if not report['pass']:
    raise SystemExit(1)
