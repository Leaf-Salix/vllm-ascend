"""独立SDK最小MIX：AIC FIX写回→GM信号→双AIV读取，顺序代际回放。"""
import argparse
import json
import os
from pathlib import Path
import runpy
import sys
parser = argparse.ArgumentParser()
parser.add_argument('--device', action='store_true')
args = parser.parse_args()
sdk = Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
sys.argv = [str(sdk / 'sdk-preflight.py')]
runpy.run_path(sys.argv[0], run_name='__main__')
import pypto.language as pl
from pypto import ir, passes
import torch
import torch_npu
GROUPS = 24
PARTICIPANTS = 72
STRIDE = 128
WORDS = 3 * PARTICIPANTS * STRIDE

@pl.jit.inline(auto_scope=False)
def begin(signal: pl.InOut[pl.Tensor[[WORDS], pl.INT32]], core: pl.Scalar[pl.INDEX]):
    offset = core * STRIDE
    pl.system.cacheinvalid(signal, [1], [offset])
    pl.system.fence()
    generation = pl.read(signal, [offset]) + pl.cast(1, pl.INT32)
    pl.system.bar_all()
    pl.system.signal_notify(signal, [offset], generation)
    return (signal, generation)

@pl.jit.incore
def producer(signal: pl.InOut[pl.Tensor[[WORDS], pl.INT32]], matrix: pl.Tensor[[384, 16], pl.BF16], payload: pl.InOut[pl.Tensor[[400, 16], pl.FP32]], extra_000: pl.Tensor[[1], pl.FP32], extra_001: pl.Tensor[[1], pl.FP32], extra_002: pl.Tensor[[1], pl.FP32], extra_003: pl.Tensor[[1], pl.FP32], extra_004: pl.Tensor[[1], pl.FP32], extra_005: pl.Tensor[[1], pl.FP32], extra_006: pl.Tensor[[1], pl.FP32], extra_007: pl.Tensor[[1], pl.FP32], extra_008: pl.Tensor[[1], pl.FP32], extra_009: pl.Tensor[[1], pl.FP32], extra_010: pl.Tensor[[1], pl.FP32], extra_011: pl.Tensor[[1], pl.FP32], extra_012: pl.Tensor[[1], pl.FP32], extra_013: pl.Tensor[[1], pl.FP32], extra_014: pl.Tensor[[1], pl.FP32], extra_015: pl.Tensor[[1], pl.FP32], extra_016: pl.Tensor[[1], pl.FP32], extra_017: pl.Tensor[[1], pl.FP32], extra_018: pl.Tensor[[1], pl.FP32], extra_019: pl.Tensor[[1], pl.FP32], extra_020: pl.Tensor[[1], pl.FP32], extra_021: pl.Tensor[[1], pl.FP32], extra_022: pl.Tensor[[1], pl.FP32], extra_023: pl.Tensor[[1], pl.FP32], extra_024: pl.Tensor[[1], pl.FP32], extra_025: pl.Tensor[[1], pl.FP32], extra_026: pl.Tensor[[1], pl.FP32], extra_027: pl.Tensor[[1], pl.FP32], extra_028: pl.Tensor[[1], pl.FP32], extra_029: pl.Tensor[[1], pl.FP32], extra_030: pl.Tensor[[1], pl.FP32], extra_031: pl.Tensor[[1], pl.FP32], extra_032: pl.Tensor[[1], pl.FP32], extra_033: pl.Tensor[[1], pl.FP32], extra_034: pl.Tensor[[1], pl.FP32], extra_035: pl.Tensor[[1], pl.FP32], extra_036: pl.Tensor[[1], pl.FP32], extra_037: pl.Tensor[[1], pl.FP32], extra_038: pl.Tensor[[1], pl.FP32], extra_039: pl.Tensor[[1], pl.FP32], extra_040: pl.Tensor[[1], pl.FP32], extra_041: pl.Tensor[[1], pl.FP32], extra_042: pl.Tensor[[1], pl.FP32], extra_043: pl.Tensor[[1], pl.FP32], extra_044: pl.Tensor[[1], pl.FP32], extra_045: pl.Tensor[[1], pl.FP32], extra_046: pl.Tensor[[1], pl.FP32], extra_047: pl.Tensor[[1], pl.FP32], extra_048: pl.Tensor[[1], pl.FP32], extra_049: pl.Tensor[[1], pl.FP32], extra_050: pl.Tensor[[1], pl.FP32], extra_051: pl.Tensor[[1], pl.FP32], extra_052: pl.Tensor[[1], pl.FP32], extra_053: pl.Tensor[[1], pl.FP32], extra_054: pl.Tensor[[1], pl.FP32], extra_055: pl.Tensor[[1], pl.FP32], extra_056: pl.Tensor[[1], pl.FP32], extra_057: pl.Tensor[[1], pl.FP32], extra_058: pl.Tensor[[1], pl.FP32], extra_059: pl.Tensor[[1], pl.FP32], extra_060: pl.Tensor[[1], pl.FP32], extra_061: pl.Tensor[[1], pl.FP32], extra_062: pl.Tensor[[1], pl.FP32], extra_063: pl.Tensor[[1], pl.FP32], extra_064: pl.Tensor[[1], pl.FP32], extra_065: pl.Tensor[[1], pl.FP32], extra_066: pl.Tensor[[1], pl.FP32], extra_067: pl.Tensor[[1], pl.FP32], extra_068: pl.Tensor[[1], pl.FP32], extra_069: pl.Tensor[[1], pl.FP32], extra_070: pl.Tensor[[1], pl.FP32], extra_071: pl.Tensor[[1], pl.FP32], extra_072: pl.Tensor[[1], pl.FP32], extra_073: pl.Tensor[[1], pl.FP32], extra_074: pl.Tensor[[1], pl.FP32], extra_075: pl.Tensor[[1], pl.FP32], extra_076: pl.Tensor[[1], pl.FP32], extra_077: pl.Tensor[[1], pl.FP32], extra_078: pl.Tensor[[1], pl.FP32], extra_079: pl.Tensor[[1], pl.FP32], extra_080: pl.Tensor[[1], pl.FP32], extra_081: pl.Tensor[[1], pl.FP32], extra_082: pl.Tensor[[1], pl.FP32], extra_083: pl.Tensor[[1], pl.FP32], extra_084: pl.Tensor[[1], pl.FP32], extra_085: pl.Tensor[[1], pl.FP32], extra_086: pl.Tensor[[1], pl.FP32], extra_087: pl.Tensor[[1], pl.FP32], extra_088: pl.Tensor[[1], pl.FP32], extra_089: pl.Tensor[[1], pl.FP32], extra_090: pl.Tensor[[1], pl.FP32], extra_091: pl.Tensor[[1], pl.FP32], extra_092: pl.Tensor[[1], pl.FP32], extra_093: pl.Tensor[[1], pl.FP32], extra_094: pl.Tensor[[1], pl.FP32], extra_095: pl.Tensor[[1], pl.FP32], extra_096: pl.Tensor[[1], pl.FP32], extra_097: pl.Tensor[[1], pl.FP32], extra_098: pl.Tensor[[1], pl.FP32], extra_099: pl.Tensor[[1], pl.FP32], extra_100: pl.Tensor[[1], pl.FP32], extra_101: pl.Tensor[[1], pl.FP32], extra_102: pl.Tensor[[1], pl.FP32], extra_103: pl.Tensor[[1], pl.FP32], extra_104: pl.Tensor[[1], pl.FP32], extra_105: pl.Tensor[[1], pl.FP32], extra_106: pl.Tensor[[1], pl.FP32], extra_107: pl.Tensor[[1], pl.FP32], extra_108: pl.Tensor[[1], pl.FP32], extra_109: pl.Tensor[[1], pl.FP32], extra_110: pl.Tensor[[1], pl.FP32], extra_111: pl.Tensor[[1], pl.FP32], extra_112: pl.Tensor[[1], pl.FP32], extra_113: pl.Tensor[[1], pl.FP32], extra_114: pl.Tensor[[1], pl.FP32], extra_115: pl.Tensor[[1], pl.FP32], extra_116: pl.Tensor[[1], pl.FP32], extra_117: pl.Tensor[[1], pl.FP32], extra_118: pl.Tensor[[1], pl.FP32], extra_119: pl.Tensor[[1], pl.FP32], extra_120: pl.Tensor[[1], pl.FP32], extra_121: pl.Tensor[[1], pl.FP32], extra_122: pl.Tensor[[1], pl.FP32], extra_123: pl.Tensor[[1], pl.FP32], extra_124: pl.Tensor[[1], pl.FP32], extra_125: pl.Tensor[[1], pl.FP32], extra_126: pl.Tensor[[1], pl.FP32], extra_127: pl.Tensor[[1], pl.FP32]):
    worker = pl.tile.get_block_idx()
    signal, generation = begin(signal, worker)
    checksum = pl.read(extra_000, [0]) * 1.0 + pl.read(extra_001, [0]) * 2.0 + pl.read(extra_002, [0]) * 3.0 + pl.read(extra_003, [0]) * 4.0 + pl.read(extra_004, [0]) * 5.0 + pl.read(extra_005, [0]) * 6.0 + pl.read(extra_006, [0]) * 7.0 + pl.read(extra_007, [0]) * 8.0 + pl.read(extra_008, [0]) * 9.0 + pl.read(extra_009, [0]) * 10.0 + pl.read(extra_010, [0]) * 11.0 + pl.read(extra_011, [0]) * 12.0 + pl.read(extra_012, [0]) * 13.0 + pl.read(extra_013, [0]) * 14.0 + pl.read(extra_014, [0]) * 15.0 + pl.read(extra_015, [0]) * 16.0 + pl.read(extra_016, [0]) * 17.0 + pl.read(extra_017, [0]) * 18.0 + pl.read(extra_018, [0]) * 19.0 + pl.read(extra_019, [0]) * 20.0 + pl.read(extra_020, [0]) * 21.0 + pl.read(extra_021, [0]) * 22.0 + pl.read(extra_022, [0]) * 23.0 + pl.read(extra_023, [0]) * 24.0 + pl.read(extra_024, [0]) * 25.0 + pl.read(extra_025, [0]) * 26.0 + pl.read(extra_026, [0]) * 27.0 + pl.read(extra_027, [0]) * 28.0 + pl.read(extra_028, [0]) * 29.0 + pl.read(extra_029, [0]) * 30.0 + pl.read(extra_030, [0]) * 31.0 + pl.read(extra_031, [0]) * 32.0 + pl.read(extra_032, [0]) * 33.0 + pl.read(extra_033, [0]) * 34.0 + pl.read(extra_034, [0]) * 35.0 + pl.read(extra_035, [0]) * 36.0 + pl.read(extra_036, [0]) * 37.0 + pl.read(extra_037, [0]) * 38.0 + pl.read(extra_038, [0]) * 39.0 + pl.read(extra_039, [0]) * 40.0 + pl.read(extra_040, [0]) * 41.0 + pl.read(extra_041, [0]) * 42.0 + pl.read(extra_042, [0]) * 43.0 + pl.read(extra_043, [0]) * 44.0 + pl.read(extra_044, [0]) * 45.0 + pl.read(extra_045, [0]) * 46.0 + pl.read(extra_046, [0]) * 47.0 + pl.read(extra_047, [0]) * 48.0 + pl.read(extra_048, [0]) * 49.0 + pl.read(extra_049, [0]) * 50.0 + pl.read(extra_050, [0]) * 51.0 + pl.read(extra_051, [0]) * 52.0 + pl.read(extra_052, [0]) * 53.0 + pl.read(extra_053, [0]) * 54.0 + pl.read(extra_054, [0]) * 55.0 + pl.read(extra_055, [0]) * 56.0 + pl.read(extra_056, [0]) * 57.0 + pl.read(extra_057, [0]) * 58.0 + pl.read(extra_058, [0]) * 59.0 + pl.read(extra_059, [0]) * 60.0 + pl.read(extra_060, [0]) * 61.0 + pl.read(extra_061, [0]) * 62.0 + pl.read(extra_062, [0]) * 63.0 + pl.read(extra_063, [0]) * 64.0 + pl.read(extra_064, [0]) * 65.0 + pl.read(extra_065, [0]) * 66.0 + pl.read(extra_066, [0]) * 67.0 + pl.read(extra_067, [0]) * 68.0 + pl.read(extra_068, [0]) * 69.0 + pl.read(extra_069, [0]) * 70.0 + pl.read(extra_070, [0]) * 71.0 + pl.read(extra_071, [0]) * 72.0 + pl.read(extra_072, [0]) * 73.0 + pl.read(extra_073, [0]) * 74.0 + pl.read(extra_074, [0]) * 75.0 + pl.read(extra_075, [0]) * 76.0 + pl.read(extra_076, [0]) * 77.0 + pl.read(extra_077, [0]) * 78.0 + pl.read(extra_078, [0]) * 79.0 + pl.read(extra_079, [0]) * 80.0 + pl.read(extra_080, [0]) * 81.0 + pl.read(extra_081, [0]) * 82.0 + pl.read(extra_082, [0]) * 83.0 + pl.read(extra_083, [0]) * 84.0 + pl.read(extra_084, [0]) * 85.0 + pl.read(extra_085, [0]) * 86.0 + pl.read(extra_086, [0]) * 87.0 + pl.read(extra_087, [0]) * 88.0 + pl.read(extra_088, [0]) * 89.0 + pl.read(extra_089, [0]) * 90.0 + pl.read(extra_090, [0]) * 91.0 + pl.read(extra_091, [0]) * 92.0 + pl.read(extra_092, [0]) * 93.0 + pl.read(extra_093, [0]) * 94.0 + pl.read(extra_094, [0]) * 95.0 + pl.read(extra_095, [0]) * 96.0 + pl.read(extra_096, [0]) * 97.0 + pl.read(extra_097, [0]) * 98.0 + pl.read(extra_098, [0]) * 99.0 + pl.read(extra_099, [0]) * 100.0 + pl.read(extra_100, [0]) * 101.0 + pl.read(extra_101, [0]) * 102.0 + pl.read(extra_102, [0]) * 103.0 + pl.read(extra_103, [0]) * 104.0 + pl.read(extra_104, [0]) * 105.0 + pl.read(extra_105, [0]) * 106.0 + pl.read(extra_106, [0]) * 107.0 + pl.read(extra_107, [0]) * 108.0 + pl.read(extra_108, [0]) * 109.0 + pl.read(extra_109, [0]) * 110.0 + pl.read(extra_110, [0]) * 111.0 + pl.read(extra_111, [0]) * 112.0 + pl.read(extra_112, [0]) * 113.0 + pl.read(extra_113, [0]) * 114.0 + pl.read(extra_114, [0]) * 115.0 + pl.read(extra_115, [0]) * 116.0 + pl.read(extra_116, [0]) * 117.0 + pl.read(extra_117, [0]) * 118.0 + pl.read(extra_118, [0]) * 119.0 + pl.read(extra_119, [0]) * 120.0 + pl.read(extra_120, [0]) * 121.0 + pl.read(extra_121, [0]) * 122.0 + pl.read(extra_122, [0]) * 123.0 + pl.read(extra_123, [0]) * 124.0 + pl.read(extra_124, [0]) * 125.0 + pl.read(extra_125, [0]) * 126.0 + pl.read(extra_126, [0]) * 127.0 + pl.read(extra_127, [0]) * 128.0
    source_owner = worker
    if checksum != 707264.0:
        source_owner = (worker + 1) % GROUPS
    a = pl.load(matrix, [source_owner * 16, 0], [16, 16])
    b = pl.load(matrix, [worker * 16, 0], [16, 16])
    c = pl.matmul(a, b)
    pl.store(c, [worker * 16, 0], payload)
    pl.system.bar_all()
    pl.system.cacheinvalid()
    pl.system.fence()
    pl.system.signal_notify(signal, [(PARTICIPANTS + worker) * STRIDE], generation)
    return (signal, payload)

@pl.jit.incore
def consumer(signal: pl.InOut[pl.Tensor[[WORDS], pl.INT32]], payload: pl.Tensor[[400, 16], pl.FP32], output: pl.InOut[pl.Tensor[[784, 16], pl.FP32]]):
    pl.func_attr({'split_aiv': True})
    worker = pl.tile.get_block_idx() * 2 + pl.tile.get_subblock_idx()
    core = GROUPS + worker
    signal, generation = begin(signal, core)
    owner = (worker // 2 + 1) % GROUPS
    pl.system.signal_wait(signal, [(PARTICIPANTS + owner) * STRIDE], generation)
    pl.system.fence()
    pl.system.cacheinvalid()
    pl.system.fence()
    x = pl.load(payload, [owner * 16, 0], [16, 16])
    pl.store(pl.mul(x, 2.0), [worker * 16, 0], output)
    pl.system.bar_all()
    pl.system.signal_notify(signal, [(2 * PARTICIPANTS + core) * STRIDE], generation)
    return (signal, output)

@pl.jit.inline(auto_scope=False)
def mixed_group(signal: pl.InOut[pl.Tensor[[WORDS], pl.INT32]], matrix: pl.Tensor[[384, 16], pl.BF16], payload: pl.InOut[pl.Tensor[[400, 16], pl.FP32]], output: pl.InOut[pl.Tensor[[784, 16], pl.FP32]], extra_000: pl.Tensor[[1], pl.FP32], extra_001: pl.Tensor[[1], pl.FP32], extra_002: pl.Tensor[[1], pl.FP32], extra_003: pl.Tensor[[1], pl.FP32], extra_004: pl.Tensor[[1], pl.FP32], extra_005: pl.Tensor[[1], pl.FP32], extra_006: pl.Tensor[[1], pl.FP32], extra_007: pl.Tensor[[1], pl.FP32], extra_008: pl.Tensor[[1], pl.FP32], extra_009: pl.Tensor[[1], pl.FP32], extra_010: pl.Tensor[[1], pl.FP32], extra_011: pl.Tensor[[1], pl.FP32], extra_012: pl.Tensor[[1], pl.FP32], extra_013: pl.Tensor[[1], pl.FP32], extra_014: pl.Tensor[[1], pl.FP32], extra_015: pl.Tensor[[1], pl.FP32], extra_016: pl.Tensor[[1], pl.FP32], extra_017: pl.Tensor[[1], pl.FP32], extra_018: pl.Tensor[[1], pl.FP32], extra_019: pl.Tensor[[1], pl.FP32], extra_020: pl.Tensor[[1], pl.FP32], extra_021: pl.Tensor[[1], pl.FP32], extra_022: pl.Tensor[[1], pl.FP32], extra_023: pl.Tensor[[1], pl.FP32], extra_024: pl.Tensor[[1], pl.FP32], extra_025: pl.Tensor[[1], pl.FP32], extra_026: pl.Tensor[[1], pl.FP32], extra_027: pl.Tensor[[1], pl.FP32], extra_028: pl.Tensor[[1], pl.FP32], extra_029: pl.Tensor[[1], pl.FP32], extra_030: pl.Tensor[[1], pl.FP32], extra_031: pl.Tensor[[1], pl.FP32], extra_032: pl.Tensor[[1], pl.FP32], extra_033: pl.Tensor[[1], pl.FP32], extra_034: pl.Tensor[[1], pl.FP32], extra_035: pl.Tensor[[1], pl.FP32], extra_036: pl.Tensor[[1], pl.FP32], extra_037: pl.Tensor[[1], pl.FP32], extra_038: pl.Tensor[[1], pl.FP32], extra_039: pl.Tensor[[1], pl.FP32], extra_040: pl.Tensor[[1], pl.FP32], extra_041: pl.Tensor[[1], pl.FP32], extra_042: pl.Tensor[[1], pl.FP32], extra_043: pl.Tensor[[1], pl.FP32], extra_044: pl.Tensor[[1], pl.FP32], extra_045: pl.Tensor[[1], pl.FP32], extra_046: pl.Tensor[[1], pl.FP32], extra_047: pl.Tensor[[1], pl.FP32], extra_048: pl.Tensor[[1], pl.FP32], extra_049: pl.Tensor[[1], pl.FP32], extra_050: pl.Tensor[[1], pl.FP32], extra_051: pl.Tensor[[1], pl.FP32], extra_052: pl.Tensor[[1], pl.FP32], extra_053: pl.Tensor[[1], pl.FP32], extra_054: pl.Tensor[[1], pl.FP32], extra_055: pl.Tensor[[1], pl.FP32], extra_056: pl.Tensor[[1], pl.FP32], extra_057: pl.Tensor[[1], pl.FP32], extra_058: pl.Tensor[[1], pl.FP32], extra_059: pl.Tensor[[1], pl.FP32], extra_060: pl.Tensor[[1], pl.FP32], extra_061: pl.Tensor[[1], pl.FP32], extra_062: pl.Tensor[[1], pl.FP32], extra_063: pl.Tensor[[1], pl.FP32], extra_064: pl.Tensor[[1], pl.FP32], extra_065: pl.Tensor[[1], pl.FP32], extra_066: pl.Tensor[[1], pl.FP32], extra_067: pl.Tensor[[1], pl.FP32], extra_068: pl.Tensor[[1], pl.FP32], extra_069: pl.Tensor[[1], pl.FP32], extra_070: pl.Tensor[[1], pl.FP32], extra_071: pl.Tensor[[1], pl.FP32], extra_072: pl.Tensor[[1], pl.FP32], extra_073: pl.Tensor[[1], pl.FP32], extra_074: pl.Tensor[[1], pl.FP32], extra_075: pl.Tensor[[1], pl.FP32], extra_076: pl.Tensor[[1], pl.FP32], extra_077: pl.Tensor[[1], pl.FP32], extra_078: pl.Tensor[[1], pl.FP32], extra_079: pl.Tensor[[1], pl.FP32], extra_080: pl.Tensor[[1], pl.FP32], extra_081: pl.Tensor[[1], pl.FP32], extra_082: pl.Tensor[[1], pl.FP32], extra_083: pl.Tensor[[1], pl.FP32], extra_084: pl.Tensor[[1], pl.FP32], extra_085: pl.Tensor[[1], pl.FP32], extra_086: pl.Tensor[[1], pl.FP32], extra_087: pl.Tensor[[1], pl.FP32], extra_088: pl.Tensor[[1], pl.FP32], extra_089: pl.Tensor[[1], pl.FP32], extra_090: pl.Tensor[[1], pl.FP32], extra_091: pl.Tensor[[1], pl.FP32], extra_092: pl.Tensor[[1], pl.FP32], extra_093: pl.Tensor[[1], pl.FP32], extra_094: pl.Tensor[[1], pl.FP32], extra_095: pl.Tensor[[1], pl.FP32], extra_096: pl.Tensor[[1], pl.FP32], extra_097: pl.Tensor[[1], pl.FP32], extra_098: pl.Tensor[[1], pl.FP32], extra_099: pl.Tensor[[1], pl.FP32], extra_100: pl.Tensor[[1], pl.FP32], extra_101: pl.Tensor[[1], pl.FP32], extra_102: pl.Tensor[[1], pl.FP32], extra_103: pl.Tensor[[1], pl.FP32], extra_104: pl.Tensor[[1], pl.FP32], extra_105: pl.Tensor[[1], pl.FP32], extra_106: pl.Tensor[[1], pl.FP32], extra_107: pl.Tensor[[1], pl.FP32], extra_108: pl.Tensor[[1], pl.FP32], extra_109: pl.Tensor[[1], pl.FP32], extra_110: pl.Tensor[[1], pl.FP32], extra_111: pl.Tensor[[1], pl.FP32], extra_112: pl.Tensor[[1], pl.FP32], extra_113: pl.Tensor[[1], pl.FP32], extra_114: pl.Tensor[[1], pl.FP32], extra_115: pl.Tensor[[1], pl.FP32], extra_116: pl.Tensor[[1], pl.FP32], extra_117: pl.Tensor[[1], pl.FP32], extra_118: pl.Tensor[[1], pl.FP32], extra_119: pl.Tensor[[1], pl.FP32], extra_120: pl.Tensor[[1], pl.FP32], extra_121: pl.Tensor[[1], pl.FP32], extra_122: pl.Tensor[[1], pl.FP32], extra_123: pl.Tensor[[1], pl.FP32], extra_124: pl.Tensor[[1], pl.FP32], extra_125: pl.Tensor[[1], pl.FP32], extra_126: pl.Tensor[[1], pl.FP32], extra_127: pl.Tensor[[1], pl.FP32]):
    with pl.cluster(name_hint='sdk_signal_gate'):
        signal, payload = producer(signal, matrix, payload, extra_000, extra_001, extra_002, extra_003, extra_004, extra_005, extra_006, extra_007, extra_008, extra_009, extra_010, extra_011, extra_012, extra_013, extra_014, extra_015, extra_016, extra_017, extra_018, extra_019, extra_020, extra_021, extra_022, extra_023, extra_024, extra_025, extra_026, extra_027, extra_028, extra_029, extra_030, extra_031, extra_032, extra_033, extra_034, extra_035, extra_036, extra_037, extra_038, extra_039, extra_040, extra_041, extra_042, extra_043, extra_044, extra_045, extra_046, extra_047, extra_048, extra_049, extra_050, extra_051, extra_052, extra_053, extra_054, extra_055, extra_056, extra_057, extra_058, extra_059, extra_060, extra_061, extra_062, extra_063, extra_064, extra_065, extra_066, extra_067, extra_068, extra_069, extra_070, extra_071, extra_072, extra_073, extra_074, extra_075, extra_076, extra_077, extra_078, extra_079, extra_080, extra_081, extra_082, extra_083, extra_084, extra_085, extra_086, extra_087, extra_088, extra_089, extra_090, extra_091, extra_092, extra_093, extra_094, extra_095, extra_096, extra_097, extra_098, extra_099, extra_100, extra_101, extra_102, extra_103, extra_104, extra_105, extra_106, extra_107, extra_108, extra_109, extra_110, extra_111, extra_112, extra_113, extra_114, extra_115, extra_116, extra_117, extra_118, extra_119, extra_120, extra_121, extra_122, extra_123, extra_124, extra_125, extra_126, extra_127)
        signal, output = consumer(signal, payload, output)
    return (signal, payload, output)

@pl.jit
def signal_gate(signal: pl.InOut[pl.Tensor[[WORDS], pl.INT32]], matrix: pl.Tensor[[384, 16], pl.BF16], payload: pl.InOut[pl.Tensor[[400, 16], pl.FP32]], output: pl.InOut[pl.Tensor[[784, 16], pl.FP32]], extra_000: pl.Tensor[[1], pl.FP32], extra_001: pl.Tensor[[1], pl.FP32], extra_002: pl.Tensor[[1], pl.FP32], extra_003: pl.Tensor[[1], pl.FP32], extra_004: pl.Tensor[[1], pl.FP32], extra_005: pl.Tensor[[1], pl.FP32], extra_006: pl.Tensor[[1], pl.FP32], extra_007: pl.Tensor[[1], pl.FP32], extra_008: pl.Tensor[[1], pl.FP32], extra_009: pl.Tensor[[1], pl.FP32], extra_010: pl.Tensor[[1], pl.FP32], extra_011: pl.Tensor[[1], pl.FP32], extra_012: pl.Tensor[[1], pl.FP32], extra_013: pl.Tensor[[1], pl.FP32], extra_014: pl.Tensor[[1], pl.FP32], extra_015: pl.Tensor[[1], pl.FP32], extra_016: pl.Tensor[[1], pl.FP32], extra_017: pl.Tensor[[1], pl.FP32], extra_018: pl.Tensor[[1], pl.FP32], extra_019: pl.Tensor[[1], pl.FP32], extra_020: pl.Tensor[[1], pl.FP32], extra_021: pl.Tensor[[1], pl.FP32], extra_022: pl.Tensor[[1], pl.FP32], extra_023: pl.Tensor[[1], pl.FP32], extra_024: pl.Tensor[[1], pl.FP32], extra_025: pl.Tensor[[1], pl.FP32], extra_026: pl.Tensor[[1], pl.FP32], extra_027: pl.Tensor[[1], pl.FP32], extra_028: pl.Tensor[[1], pl.FP32], extra_029: pl.Tensor[[1], pl.FP32], extra_030: pl.Tensor[[1], pl.FP32], extra_031: pl.Tensor[[1], pl.FP32], extra_032: pl.Tensor[[1], pl.FP32], extra_033: pl.Tensor[[1], pl.FP32], extra_034: pl.Tensor[[1], pl.FP32], extra_035: pl.Tensor[[1], pl.FP32], extra_036: pl.Tensor[[1], pl.FP32], extra_037: pl.Tensor[[1], pl.FP32], extra_038: pl.Tensor[[1], pl.FP32], extra_039: pl.Tensor[[1], pl.FP32], extra_040: pl.Tensor[[1], pl.FP32], extra_041: pl.Tensor[[1], pl.FP32], extra_042: pl.Tensor[[1], pl.FP32], extra_043: pl.Tensor[[1], pl.FP32], extra_044: pl.Tensor[[1], pl.FP32], extra_045: pl.Tensor[[1], pl.FP32], extra_046: pl.Tensor[[1], pl.FP32], extra_047: pl.Tensor[[1], pl.FP32], extra_048: pl.Tensor[[1], pl.FP32], extra_049: pl.Tensor[[1], pl.FP32], extra_050: pl.Tensor[[1], pl.FP32], extra_051: pl.Tensor[[1], pl.FP32], extra_052: pl.Tensor[[1], pl.FP32], extra_053: pl.Tensor[[1], pl.FP32], extra_054: pl.Tensor[[1], pl.FP32], extra_055: pl.Tensor[[1], pl.FP32], extra_056: pl.Tensor[[1], pl.FP32], extra_057: pl.Tensor[[1], pl.FP32], extra_058: pl.Tensor[[1], pl.FP32], extra_059: pl.Tensor[[1], pl.FP32], extra_060: pl.Tensor[[1], pl.FP32], extra_061: pl.Tensor[[1], pl.FP32], extra_062: pl.Tensor[[1], pl.FP32], extra_063: pl.Tensor[[1], pl.FP32], extra_064: pl.Tensor[[1], pl.FP32], extra_065: pl.Tensor[[1], pl.FP32], extra_066: pl.Tensor[[1], pl.FP32], extra_067: pl.Tensor[[1], pl.FP32], extra_068: pl.Tensor[[1], pl.FP32], extra_069: pl.Tensor[[1], pl.FP32], extra_070: pl.Tensor[[1], pl.FP32], extra_071: pl.Tensor[[1], pl.FP32], extra_072: pl.Tensor[[1], pl.FP32], extra_073: pl.Tensor[[1], pl.FP32], extra_074: pl.Tensor[[1], pl.FP32], extra_075: pl.Tensor[[1], pl.FP32], extra_076: pl.Tensor[[1], pl.FP32], extra_077: pl.Tensor[[1], pl.FP32], extra_078: pl.Tensor[[1], pl.FP32], extra_079: pl.Tensor[[1], pl.FP32], extra_080: pl.Tensor[[1], pl.FP32], extra_081: pl.Tensor[[1], pl.FP32], extra_082: pl.Tensor[[1], pl.FP32], extra_083: pl.Tensor[[1], pl.FP32], extra_084: pl.Tensor[[1], pl.FP32], extra_085: pl.Tensor[[1], pl.FP32], extra_086: pl.Tensor[[1], pl.FP32], extra_087: pl.Tensor[[1], pl.FP32], extra_088: pl.Tensor[[1], pl.FP32], extra_089: pl.Tensor[[1], pl.FP32], extra_090: pl.Tensor[[1], pl.FP32], extra_091: pl.Tensor[[1], pl.FP32], extra_092: pl.Tensor[[1], pl.FP32], extra_093: pl.Tensor[[1], pl.FP32], extra_094: pl.Tensor[[1], pl.FP32], extra_095: pl.Tensor[[1], pl.FP32], extra_096: pl.Tensor[[1], pl.FP32], extra_097: pl.Tensor[[1], pl.FP32], extra_098: pl.Tensor[[1], pl.FP32], extra_099: pl.Tensor[[1], pl.FP32], extra_100: pl.Tensor[[1], pl.FP32], extra_101: pl.Tensor[[1], pl.FP32], extra_102: pl.Tensor[[1], pl.FP32], extra_103: pl.Tensor[[1], pl.FP32], extra_104: pl.Tensor[[1], pl.FP32], extra_105: pl.Tensor[[1], pl.FP32], extra_106: pl.Tensor[[1], pl.FP32], extra_107: pl.Tensor[[1], pl.FP32], extra_108: pl.Tensor[[1], pl.FP32], extra_109: pl.Tensor[[1], pl.FP32], extra_110: pl.Tensor[[1], pl.FP32], extra_111: pl.Tensor[[1], pl.FP32], extra_112: pl.Tensor[[1], pl.FP32], extra_113: pl.Tensor[[1], pl.FP32], extra_114: pl.Tensor[[1], pl.FP32], extra_115: pl.Tensor[[1], pl.FP32], extra_116: pl.Tensor[[1], pl.FP32], extra_117: pl.Tensor[[1], pl.FP32], extra_118: pl.Tensor[[1], pl.FP32], extra_119: pl.Tensor[[1], pl.FP32], extra_120: pl.Tensor[[1], pl.FP32], extra_121: pl.Tensor[[1], pl.FP32], extra_122: pl.Tensor[[1], pl.FP32], extra_123: pl.Tensor[[1], pl.FP32], extra_124: pl.Tensor[[1], pl.FP32], extra_125: pl.Tensor[[1], pl.FP32], extra_126: pl.Tensor[[1], pl.FP32], extra_127: pl.Tensor[[1], pl.FP32]):
    with pl.spmd(GROUPS, sync_start=True):
        signal, payload, output = mixed_group(signal, matrix, payload, output, extra_000, extra_001, extra_002, extra_003, extra_004, extra_005, extra_006, extra_007, extra_008, extra_009, extra_010, extra_011, extra_012, extra_013, extra_014, extra_015, extra_016, extra_017, extra_018, extra_019, extra_020, extra_021, extra_022, extra_023, extra_024, extra_025, extra_026, extra_027, extra_028, extra_029, extra_030, extra_031, extra_032, extra_033, extra_034, extra_035, extra_036, extra_037, extra_038, extra_039, extra_040, extra_041, extra_042, extra_043, extra_044, extra_045, extra_046, extra_047, extra_048, extra_049, extra_050, extra_051, extra_052, extra_053, extra_054, extra_055, extra_056, extra_057, extra_058, extra_059, extra_060, extra_061, extra_062, extra_063, extra_064, extra_065, extra_066, extra_067, extra_068, extra_069, extra_070, extra_071, extra_072, extra_073, extra_074, extra_075, extra_076, extra_077, extra_078, extra_079, extra_080, extra_081, extra_082, extra_083, extra_084, extra_085, extra_086, extra_087, extra_088, extra_089, extra_090, extra_091, extra_092, extra_093, extra_094, extra_095, extra_096, extra_097, extra_098, extra_099, extra_100, extra_101, extra_102, extra_103, extra_104, extra_105, extra_106, extra_107, extra_108, extra_109, extra_110, extra_111, extra_112, extra_113, extra_114, extra_115, extra_116, extra_117, extra_118, extra_119, extra_120, extra_121, extra_122, extra_123, extra_124, extra_125, extra_126, extra_127)
    return (signal, payload, output)
out = sdk / ('results/wide-signal-device-v1' if args.device else 'results/wide-signal-lowering-v2')
out.mkdir(exist_ok=False)
(out / 'source.py').write_bytes(Path(__file__).read_bytes())
report = {'root_tensor_args': 132, 'route': 'native JIT prepare/enqueue; no 132-arg Torch schema', 'pass': False, 'device_execution': args.device, 'math_scope': 'minimal handshake, not CSA'}
try:
    if not args.device:
        program = signal_gate.specialize()
        from pypto.ir._kernel_compile import kernel_abi_for_program
        abi = kernel_abi_for_program(program, platform='a2a3', runtime='tensormap_and_ringbuffer')
        report['actual_root_tensor_args'] = len(abi.parameters)
        assert len(abi.parameters) == report.get('root_tensor_args', 4)
        ir.compile(program, output_dir=str(out / 'kernel'), skip_ptoas=True, platform='a2a3', memory_planner=passes.MemoryPlanner.PYPTO, dump_passes=True)
        mlir = list((out / 'kernel/kernels').glob('*.pto'))
        generated = '\n'.join((p.read_text() for p in mlir))
        assert mlir and 'pto.comm.tnotify' in generated and ('pto.comm.twait' in generated)
        orch = '\n'.join((p.read_text() for p in (out / 'kernel/orchestration').glob('*.cpp')))
        assert 'MixedKernels' in orch and orch.count('rt_submit_task(') == 1
        report['single_mix'] = True
        report['skip_ptoas'] = True
        assert not torch_npu.npu.is_initialized()
    else:
        assert os.environ.get('TASK_DEVICE'), 'task-submit required'
        assert os.environ['ASCEND_RT_VISIBLE_DEVICES'] == os.environ['TASK_DEVICE']
        assert Path(os.environ['PTOAS_ROOT']).resolve().is_relative_to(sdk)
        import pypto.torch
        from pypto.runtime import CompileOptions
        torch.npu.set_device(0)
        pypto.torch.init()
        config = CompileOptions(platform='a2a3', output_dir=str(out / 'kernel'), dump_passes=True)
        op = lambda *values: signal_gate(*values, config=config)
        signal = torch.zeros(WORDS, device='npu', dtype=torch.int32)
        matrix = torch.empty((384, 16), device='npu', dtype=torch.bfloat16)

        def set_input(scale):
            for owner in range(GROUPS):
                matrix[owner * 16:(owner + 1) * 16].fill_(scale + owner)
        set_input(1.0)
        payload = torch.full((400, 16), -777.0, device='npu')
        output = torch.full((784, 16), -777.0, device='npu')

        def check(scale):
            torch.npu.synchronize()
            actual = output[:768].cpu()
            for worker in range(48):
                owner = (worker // 2 + 1) % GROUPS
                expected = 32 * (scale + owner) ** 2
                assert torch.equal(actual[worker * 16:(worker + 1) * 16], torch.full((16, 16), expected))
            assert torch.equal(output[768:].cpu(), torch.full((16, 16), -777.0))
            assert torch.equal(payload[384:].cpu(), torch.full((16, 16), -777.0))
            slots = signal.cpu().reshape(3, PARTICIPANTS, STRIDE)
            assert torch.count_nonzero(slots[:, :, 1:]) == 0
            assert torch.all(slots[0, :, 0] == slots[0, 0, 0])
            assert torch.all(slots[1, :GROUPS, 0] == slots[0, 0, 0])
            assert torch.all(slots[2, GROUPS:, 0] == slots[0, 0, 0])
            assert torch.count_nonzero(slots[1, GROUPS:, 0]) == 0
            assert torch.count_nonzero(slots[2, :GROUPS, 0]) == 0
            return int(slots[0, 0, 0])
        extras = [torch.full((1,), float(i + 1), device='npu') for i in range(128)]
        op(signal, matrix, payload, output, *extras)
        generations = [check(1.0)]
        stream = torch.npu.Stream()
        stream.wait_stream(torch.npu.current_stream())
        graph = torch.npu.NPUGraph()
        with torch.npu.stream(stream):
            with torch.npu.graph(graph, stream=stream):
                op(signal, matrix, payload, output, *extras)
        torch.npu.current_stream().wait_stream(stream)
        generations.append(check(1.0))
        with torch.npu.stream(stream):
            graph.replay()
            generations.append(check(1.0))
            assert generations[-1] == generations[-2] + 1
            for scale in (2.0, 3.0, 1.0):
                set_input(scale)
                output[:768].fill_(float('nan'))
                for _ in range(10):
                    graph.replay()
                generations.append(check(scale))
                assert generations[-1] == generations[-2] + 10
        report.update(generations=generations, actual_acl_graph=True, guarded=True, replays=31)
    report['pass'] = True
finally:
    (out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report), flush=True)
