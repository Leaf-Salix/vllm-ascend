"""封存独立SDK二进制来源；不授予设备或CSA精度资格。"""
import hashlib
import json
from pathlib import Path
import re
import subprocess

sdk = Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
binary = sdk / 'sources/ptoas/build/bin/ptoas'
assert binary.is_file()
root = sdk / 'toolchain'
(root / 'bin').mkdir(parents=True, exist_ok=True)
launcher = root / 'bin/ptoas'
if not launcher.exists():
    launcher.symlink_to(binary)
assert launcher.resolve() == binary.resolve()
version = subprocess.check_output([str(launcher), '--version'], text=True, stderr=subprocess.STDOUT)
assert '0.66' in version
linked = subprocess.check_output(['ldd', str(binary)], text=True)
assert 'not found' not in linked
llvm = re.findall(r'(?:libLLVM|libMLIR)\S*\s+=>\s+(\S+)', linked)
assert llvm and all(Path(p).resolve().is_relative_to(sdk) for p in llvm)
preflight = json.loads((sdk / 'results/pypto-import-preflight.json').read_text())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
for name, digest in preflight['binary_sha256'].items():
    assert sha(Path(preflight['imports'][name])) == digest, name
heads = {}
for name in ('pypto', 'simpler', 'ptoas', 'llvm-project', 'cann-cmake'):
    heads[name] = subprocess.check_output(['git', '-C', str(sdk / 'sources' / name), 'rev-parse', 'HEAD'], text=True).strip()
record = dict(
    pass_=True, scope='Build and CPU interface provenance only; hardware/CSA precision not yet qualified',
    source_heads=heads, ptoas=str(binary), PTOAS_ROOT=str(root), ptoas_version=version,
    ptoas_sha256=sha(binary), ldd=linked, llvm_library_sha256={p:sha(Path(p)) for p in llvm},
    pypto_simpler_preflight=preflight,
)
(sdk / 'results/toolchain-build.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
