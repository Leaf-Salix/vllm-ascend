"""封存实际wheel来源，不声称其未证实的Git提交身份。"""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import subprocess
import ptoas
sdk=Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
root=Path(ptoas.__file__).resolve().parent
assert root.is_relative_to(sdk/'ptoas-wheel-env')
wheel=next((sdk/'wheels').glob('ptoas-0.66-*.whl'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(wheel)=='d121b5b5db9a23a98eb3c0acc74d0abaef8aaa90e4df0385e79feb67636ef997'
version=subprocess.check_output([str(sdk/'toolchain-wheel/bin/ptoas'),'--version'],text=True).strip()
assert version=='ptoas 0.66'
libs={str(p):sha(p) for p in root.rglob('*.so')}
linked={str(p):subprocess.check_output(['ldd',str(p)],text=True) for p in (root/'_core.cpython-312-aarch64-linux-gnu.so',root/'mlir/_mlir_libs/libPTOASCompiler.so')}
assert all('not found' not in s for s in linked.values())
gate=json.loads((sdk/'results/signal-wheel-full-compile-v1/result.json').read_text())
assert gate['pass'] and gate['ptoas_completed'] and gate['ccec_and_orchestration_completed'] and not gate['npu_initialized']
record=dict(pass_=True,scope='Independent wheel isolation and CPU full compile only; hardware pending',
 PTOAS_ROOT=str(sdk/'toolchain-wheel'),version=version,wheel=str(wheel),wheel_sha256=sha(wheel),
 package_root=str(root),binary_sha256=libs,ldd=linked,
 ptoas_source_commit='not established for this wheel; do not infer from version',
 source_checkout_commit='e5c1c432af8249bac2f905c7648ebafefec3c20a (separate source build, not active wheel identity)',
 sdk_preflight=json.loads((sdk/'results/pypto-import-preflight.json').read_text()),
 full_compile_receipt=gate)
(sdk/'results/toolchain-wheel.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ('pass_','version','wheel_sha256','package_root','scope')},indent=2))
