"""独立SDK最小MIX：AIC FIX写回→GM信号→双AIV读取，顺序代际回放。"""
import argparse
import json
import os
from pathlib import Path
import runpy
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--device', action='store_true')
args = parser.parse_args()
sdk = Path('/data/pyptouser/yejia/csa-spmd-sdk-20261020')
sys.argv = [str(sdk / 'sdk-preflight.py')]
runpy.run_path(sys.argv[0], run_name='__main__')
import pypto.language as pl
from pypto import ir, passes
import torch
import torch_npu

GROUPS = 24
PARTICIPANTS = 72
STRIDE = 128
WORDS = 3 * PARTICIPANTS * STRIDE


@pl.jit.inline(auto_scope=False)
def begin(signal: pl.InOut[pl.Tensor[[WORDS], pl.INT32]], core: pl.Scalar[pl.INDEX]):
    offset = core * STRIDE
    pl.system.cacheinvalid(signal, [1], [offset])
    pl.system.fence()
    generation = pl.read(signal, [offset]) + pl.cast(1, pl.INT32)
    pl.system.bar_all()
    pl.system.signal_notify(signal, [offset], generation)
    return signal, generation


@pl.jit.incore
def producer(signal: pl.InOut[pl.Tensor[[WORDS], pl.INT32]],
             matrix: pl.Tensor[[384, 16], pl.BF16],
             payload: pl.InOut[pl.Tensor[[400, 16], pl.FP32]]):
    worker = pl.tile.get_block_idx()
    signal, generation = begin(signal, worker)
    a = pl.load(matrix, [worker * 16, 0], [16, 16])
    b = pl.load(matrix, [worker * 16, 0], [16, 16])
    c = pl.matmul(a, b)
    pl.store(c, [worker * 16, 0], payload)
    pl.system.bar_all()
    pl.system.cacheinvalid()
    pl.system.fence()
    pl.system.signal_notify(signal, [(PARTICIPANTS + worker) * STRIDE], generation)
    return signal, payload


@pl.jit.incore
def consumer(signal: pl.InOut[pl.Tensor[[WORDS], pl.INT32]],
             payload: pl.Tensor[[400, 16], pl.FP32],
             output: pl.InOut[pl.Tensor[[784, 16], pl.FP32]]):
    pl.func_attr({'split_aiv': True})
    worker = pl.tile.get_block_idx() * 2 + pl.tile.get_subblock_idx()
    core = GROUPS + worker
    signal, generation = begin(signal, core)
    owner = (worker // 2 + 1) % GROUPS
    pl.system.signal_wait(signal, [(PARTICIPANTS + owner) * STRIDE], generation)
    pl.system.fence()
    pl.system.cacheinvalid()
    pl.system.fence()
    x = pl.load(payload, [owner * 16, 0], [16, 16])
    pl.store(pl.mul(x, 2.0), [worker * 16, 0], output)
    pl.system.bar_all()
    pl.system.signal_notify(signal, [(2 * PARTICIPANTS + core) * STRIDE], generation)
    return signal, output


@pl.jit.inline(auto_scope=False)
def mixed_group(signal: pl.InOut[pl.Tensor[[WORDS], pl.INT32]],
                matrix: pl.Tensor[[384, 16], pl.BF16],
                payload: pl.InOut[pl.Tensor[[400, 16], pl.FP32]],
                output: pl.InOut[pl.Tensor[[784, 16], pl.FP32]]):
    with pl.cluster(name_hint='sdk_signal_gate'):
        signal, payload = producer(signal, matrix, payload)
        signal, output = consumer(signal, payload, output)
    return signal, payload, output


@pl.jit
def signal_gate(signal: pl.InOut[pl.Tensor[[WORDS], pl.INT32]],
                matrix: pl.Tensor[[384, 16], pl.BF16],
                payload: pl.InOut[pl.Tensor[[400, 16], pl.FP32]],
                output: pl.InOut[pl.Tensor[[784, 16], pl.FP32]]):
    with pl.spmd(GROUPS, sync_start=True):
        signal, payload, output = mixed_group(signal, matrix, payload, output)
    return signal, payload, output


out = sdk / ('results/signal-device-v1' if args.device else 'results/signal-lowering-v4')
out.mkdir(exist_ok=False)
(out / 'source.py').write_bytes(Path(__file__).read_bytes())
report = {'pass': False, 'device_execution': args.device, 'math_scope': 'minimal handshake, not CSA'}
try:
    if not args.device:
        program = signal_gate.specialize()
        from pypto.ir._kernel_compile import kernel_abi_for_program
        abi = kernel_abi_for_program(program, platform='a2a3', runtime='tensormap_and_ringbuffer')
        report['actual_root_tensor_args'] = len(abi.parameters)
        assert len(abi.parameters) == report.get('root_tensor_args', 4)
        ir.compile(program, output_dir=str(out / 'kernel'), skip_ptoas=True,
                   platform='a2a3', memory_planner=passes.MemoryPlanner.PYPTO, dump_passes=True)
        mlir = list((out / 'kernel/kernels').glob('*.pto'))
        generated = '\n'.join(p.read_text() for p in mlir)
        assert mlir and 'pto.comm.tnotify' in generated and 'pto.comm.twait' in generated
        orch = '\n'.join(p.read_text() for p in (out / 'kernel/orchestration').glob('*.cpp'))
        assert 'MixedKernels' in orch and orch.count('rt_submit_task(') == 1
        report['single_mix'] = True
        report['skip_ptoas'] = True
        assert not torch_npu.npu.is_initialized()
    else:
        assert os.environ.get('TASK_DEVICE'), 'task-submit required'
        assert os.environ['ASCEND_RT_VISIBLE_DEVICES'] == os.environ['TASK_DEVICE']
        assert Path(os.environ['PTOAS_ROOT']).resolve().is_relative_to(sdk)
        import pypto.torch
        from pypto.runtime import CompileOptions
        torch.npu.set_device(0)
        pypto.torch.init()
        config = CompileOptions(platform='a2a3', output_dir=str(out / 'kernel'), dump_passes=True)
        op = pypto.torch.register(signal_gate, 'sdk_signal_gate::run', config=config)
        signal = torch.zeros(WORDS, device='npu', dtype=torch.int32)
        matrix = torch.empty((384, 16), device='npu', dtype=torch.bfloat16)
        def set_input(scale):
            for owner in range(GROUPS):
                matrix[owner * 16:(owner + 1) * 16].fill_(scale + owner)
        set_input(1.0)
        payload = torch.full((400, 16), -777.0, device='npu')
        output = torch.full((784, 16), -777.0, device='npu')
        def check(scale):
            torch.npu.synchronize()
            actual = output[:768].cpu()
            for worker in range(48):
                owner = (worker // 2 + 1) % GROUPS
                expected = 32 * (scale + owner) ** 2
                assert torch.equal(actual[worker * 16:(worker + 1) * 16], torch.full((16, 16), expected))
            assert torch.equal(output[768:].cpu(), torch.full((16, 16), -777.0))
            assert torch.equal(payload[384:].cpu(), torch.full((16, 16), -777.0))
            slots = signal.cpu().reshape(3, PARTICIPANTS, STRIDE)
            assert torch.count_nonzero(slots[:, :, 1:]) == 0
            assert torch.all(slots[0, :, 0] == slots[0, 0, 0])
            assert torch.all(slots[1, :GROUPS, 0] == slots[0, 0, 0])
            assert torch.all(slots[2, GROUPS:, 0] == slots[0, 0, 0])
            assert torch.count_nonzero(slots[1, GROUPS:, 0]) == 0
            assert torch.count_nonzero(slots[2, :GROUPS, 0]) == 0
            return int(slots[0, 0, 0])
        op(signal, matrix, payload, output)
        generations = [check(1.0)]
        stream = torch.npu.Stream()
        stream.wait_stream(torch.npu.current_stream())
        graph = torch.npu.NPUGraph()
        with torch.npu.stream(stream):
            with torch.npu.graph(graph, stream=stream):
                op(signal, matrix, payload, output)
        torch.npu.current_stream().wait_stream(stream)
        generations.append(check(1.0))
        with torch.npu.stream(stream):
            graph.replay()
            generations.append(check(1.0))
            assert generations[-1] == generations[-2] + 1
            for scale in (2.0, 3.0, 1.0):
                set_input(scale)
                output[:768].fill_(float('nan'))
                for _ in range(10):
                    graph.replay()
                generations.append(check(scale))
                assert generations[-1] == generations[-2] + 10
        report.update(generations=generations, actual_acl_graph=True, guarded=True, replays=31)
    report['pass'] = True
finally:
    (out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report), flush=True)
