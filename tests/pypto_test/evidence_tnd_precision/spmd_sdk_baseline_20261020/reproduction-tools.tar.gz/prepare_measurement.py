"""只派生诊断工具，不改冻结候选或正式源码。"""
import ast,json,hashlib,shutil
from pathlib import Path
root=Path(__file__).resolve().parent
old=root.parent/'dsv4-tnd-precision-perf-20261020/full-tools'
out=root/'tools';out.mkdir(exist_ok=True)
for n in ('binding.json','ragged_fixture.py','source_identity.py'):shutil.copy2(old/n,out/n)
s=(old/'probe_csa.py').read_text()
s=s.replace("parser.add_argument('--history', type=int, default=8191)","parser.add_argument('--history', type=int, default=8191)\nparser.add_argument('--trace', action='store_true')")
s=s.replace("'precision-spmd-overlap-three-arm-v1'","'optimized-Native-SK1-vs-frozen-precision-overlap'")
s=s.replace("for arm in ('native','serial','candidate'):","for arm in ('native','candidate'):")
s=s.replace("'super_kernel_optimize':False}","'super_kernel_optimize':arm=='native'}")
s=s.replace("'native_super_kernel_optimize':False}","'native_super_kernel_optimize':arm=='native'}")
s=s.replace("'enable_dsa_cp':False}).create_engine_config()", "'enable_dsa_cp':False,'multistream_dsv4_dsa_overlap':True}).create_engine_config()")
s=s.replace("report['weight_details']=details", "report['weight_details']=details\n    report['native_DSA_multistream_config']=bool(layer.self_attn.dsa_attn.dsa_attn.impl.multistream_dsv4_dsa_overlap)\n    assert report['native_DSA_multistream_config']")
begin=s.index('    # Reproduce vLLM:');end=s.index('    samples={arm:[] for arm in rows}',begin)
s=s[:begin]+'''    def restore_readonly(fixture):
        for live,expected in fixture['readonly'].values():live.copy_(expected)
    report['cross_bucket_scope']='not re-run: frozen candidate had passed earlier; this task rechecks SK1 comparator and timing only'
'''+s[end:]
s=s.replace("'us/complete HC-pre through HC-post raw graph replay, SK0'", "'us/complete HC-pre through HC-post raw graph replay; Native SK1; determinism1; no DFX'")
s=s.replace("'mean':statistics.mean(v),'max':max(v)","'mean':statistics.mean(v),'median':statistics.median(v),'max':max(v)")
s=s.replace("    report['complete']=report['pass']=True",'''    if args.trace:
        for arm in arms:
            graph,f,output,topk=rows[arm]
            restore(f);restore_readonly(f);torch.npu.synchronize()
            with torch_npu.profiler.profile(activities=[torch_npu.profiler.ProfilerActivity.CPU,torch_npu.profiler.ProfilerActivity.NPU],record_shapes=True) as prof:
                for _ in range(3):graph.replay()
                torch.npu.synchronize()
            prof.export_chrome_trace(str(args.out/(arm+'-trace.json')))
            actual=collect_state(f,output,topk)
            assert all(exact(value,states[arm][name]) for name,value in actual.items()),(arm,'posttrace state drift')
        report['trace_separate_from_timing']=True
    report['complete']=report['pass']=True''')
ast.parse(s);(out/'probe_csa.py').write_text(s)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(out/'manifest.json').write_text(json.dumps({p.name:sha(p) for p in out.iterdir() if p.is_file() and p.name!='manifest.json'},indent=2)+'\n')
