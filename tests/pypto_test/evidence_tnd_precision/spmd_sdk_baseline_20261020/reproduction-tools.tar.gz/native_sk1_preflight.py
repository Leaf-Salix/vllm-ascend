"""占卡前检查官方编译入口、配置规范化和输出目录；不初始化设备。"""
from pathlib import Path
import os
import torch
import torch_npu
import npugraph_ex._acl_concrete_graph.static_kernel as m
from npugraph_ex.configs._option_base import OptionValue
assert os.environ['ASCEND_RT_VISIBLE_DEVICES']=='' and os.environ['TORCH_DEVICE_BACKEND_AUTOLOAD']=='0'
assert not os.environ.get('LOW_ACCEPTANCE_OFFICIAL_CACHE')
assert not os.environ.get('LOW_ACCEPTANCE_STATIC_MANIFEST')
assert m.compile_static_kernel.__name__=='compile_static_kernel' and m.static_compile.__name__=='static_compile'
v=OptionValue(False,[True,False]);v.value=True;assert v.value=='1'
p=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/spmd-baseline-20261020/native-sk1-preflight-output')
p.mkdir(exist_ok=True);q=m.safe_resolve_output_dir(str(p));assert q.is_relative_to(p)
assert not torch_npu.npu.is_initialized()
print('NO_DEVICE_NATIVE_SK1_COMPILER_PREFLIGHT_PASS',repr(v.value),q)
