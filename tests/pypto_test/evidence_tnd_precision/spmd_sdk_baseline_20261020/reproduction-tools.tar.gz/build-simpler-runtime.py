"""仅构建本实验 a2a3/tensormap runtime，不运行设备程序。"""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

sdk = Path("/data/pyptouser/yejia/csa-spmd-sdk-20261020")
root = sdk / "sources/simpler"
assert Path(sys.prefix).resolve() == (root / ".venv").resolve()
import simpler
import simpler_setup
import _task_interface
from simpler_setup.runtime_builder import RuntimeBuilder

for module in (simpler, simpler_setup, _task_interface):
    assert root in Path(module.__file__).resolve().parents, module.__file__
assert subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"], text=True).strip() == "57e499238fd4ee3548947ad860be456aaeeb16b5"
RuntimeBuilder(platform="a2a3").get_binaries("tensormap_and_ringbuffer", build=True)
files = {
    str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
    for p in (root / "build/lib").rglob("*")
    if p.is_file()
}
assert files
(sdk / "results/simpler-runtime-build.json").write_text(json.dumps({
    "platform": "a2a3", "runtime": "tensormap_and_ringbuffer", "device_executed": False,
    "python": sys.executable,
    "imports": {m.__name__: m.__file__ for m in (simpler, simpler_setup, _task_interface)},
    "files_sha256": files,
}, indent=2) + "\n")
