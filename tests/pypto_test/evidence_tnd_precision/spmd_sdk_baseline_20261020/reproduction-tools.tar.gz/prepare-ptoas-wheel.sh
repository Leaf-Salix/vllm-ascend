#!/usr/bin/env bash
set -euo pipefail
sdk=/data/pyptouser/yejia/csa-spmd-sdk-20261020
base=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1
wheel="$base/experiments/nalinaly-71153bb3/toolchain/ptoas-0.66-cp312-cp312-manylinux_2_34_aarch64.whl"
export PYTHONNOUSERSITE=1 TORCH_DEVICE_BACKEND_AUTOLOAD=0 ASCEND_RT_VISIBLE_DEVICES=""
mkdir -p "$sdk/wheels"
"$base/env/bin/python" - "$wheel" "$sdk" <<'PY'
from pathlib import Path
import hashlib, shutil, sys
p=Path(sys.argv[1]);sdk=Path(sys.argv[2])
expected='d121b5b5db9a23a98eb3c0acc74d0abaef8aaa90e4df0385e79feb67636ef997'
assert hashlib.sha256(p.read_bytes()).hexdigest()==expected
q=sdk/'wheels'/p.name
if not q.exists(): shutil.copyfile(p,q)
assert hashlib.sha256(q.read_bytes()).hexdigest()==expected
PY
test -x "$sdk/ptoas-wheel-env/bin/python" || "$base/env/bin/python" -m venv --system-site-packages "$sdk/ptoas-wheel-env"
"$sdk/ptoas-wheel-env/bin/python" -m pip install --no-index --no-deps "$sdk/wheels/$(basename "$wheel")"
mkdir -p "$sdk/toolchain-wheel/bin"
ln -s "$sdk/ptoas-wheel-env/bin/ptoas" "$sdk/toolchain-wheel/bin/ptoas"
"$sdk/toolchain-wheel/bin/ptoas" --version
