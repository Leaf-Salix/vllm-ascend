"""仅封存本轮自有目录官方 SK1 离线缓存，不安装静态包。"""
import hashlib
import json
from pathlib import Path

root = Path('/data/pyptouser/yejia/sk1b16-1020')
out = root / 'cache-ready'
metadata = out / 'qualification.json'
assert not metadata.exists()
log = root / 'compile-ready.log'
text = log.read_text()
assert '39/39 JSON files compiled successfully' in text
assert 'static kernel compile success' in text
files = list(out.rglob('*.run'))
assert len(files) == 1
inputs = sorted((root / 'in').glob('*.json'))
assert len(inputs) == 39
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
cann = Path('/data/pyptouser/yejia/vllm-cann92-main/env/Ascend/cann-9.2.0-beta.2')
static = Path('/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/env/lib/python3.12/site-packages/torch_npu/dynamo/npugraph_ex/_acl_concrete_graph/static_kernel.py')
record = dict(
    pass_=True, scope='Offline official compiler/package only; device qualification pending',
    cache=str(out), super_kernel=True, follow_op_params_jit=True,
    soc='Ascend910_9392', cann='9.2.0.beta2', deterministic='1',
    compile_command='op_compiler -p in -v Ascend910_9392 -j 2 -o cache-ready/static_kernel_compile_outputs/ts_sk1_outputs/ --enable_super_kernel -f true -l INFO',
    packages={str(p.relative_to(out)): sha(p) for p in files},
    inputs={p.name: sha(p) for p in inputs}, compile_log_sha256=sha(log),
    private_const_proof=json.loads((root / 'const-source-proof.json').read_text()),
    compiler_module_sha256=sha(cann / 'python/site-packages/op_compile_tool/op_compiler_tool.py'),
    static_module_sha256=sha(static),
    writable_compile_opp=str(root / 'compile-opp/opp'),
)
metadata.write_text(json.dumps(record, indent=2, ensure_ascii=False) + '\n')
print(metadata)
