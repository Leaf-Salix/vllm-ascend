# 双桶生命周期 v2 与整模型 v2 助手复核

## 结论

已读取 v2 实际设备结果及对应助手，没有发现阻止再次进行 8K/B40 的问题。旧初始化失败、旧 fixture 输入覆盖失败应保留；本次只是限定单卡双桶生命周期通过，不是整模型已通过。

## 实际输入与数值证据

`results/bucket-lifecycle-21-6-v2/result.json` 为 complete/pass true，其 helper_sha 与 `bucket-lifecycle-tools-v2` 实际文件全部匹配，14 候选源与 whole-v2 绑定相同。

- 建立 T6 后，T21 readonly 只有 current RoPE cos/sin 变化，分别 314/320 元素。两对 view 的 data_ptr 完全相同，形状为 `[21,1,1,64]` 与 `[6,1,1,64]`，并明确同 storage。
- 助手恢复的是原 CPU 快照到原 Tensor，不重拍快照或改变 graph 地址。每次交替前恢复活跃 fixture readonly，并进行 pre-guard；之后保留 poison、实际 replay、Native 八边界及执行后 guard。
- 跨 stream T6 暖身八边界全部 bit_equal；两个不同 T 的实际 FULL 图存在，capture stream 身份没有被非捕获借用改写。
- T21→T6→T21 三次循环共 72 个边界全部 bit_equal 且 different_elements=0；计时前也恢复 readonly 并执行 guard，计时后状态复核通过。

这与此前只读源码指出的全局 current RoPE 前缀共享路径吻合，支持将旧双桶首差归为 fixture 没有恢复图输入。它不扩大为多 stream 并发安全：实际 replay 保持同 compute stream 顺序并完成同步，报告也标记未测试并发。

## 整模型 v2 身份

whole-spmd-tools-v2 的 source manifest 为 `c86c7b9cc90e710ce5a87006ef2ba69809aa95839e1d9a64692f25d78604e06c`，3379 文件；14 新源与当前正式包一致，43 原源保持原字节。FINAL_SOURCE_BOUND 明确绑定此次 lifecycle 结果 SHA。

实际下载到本地的当前 helper SHA 均匹配；manifest 中三个 `qualification-audit-original` 尚未下载，沿用已知远端历史副本归档状态，不把本地未拉取误报为远端内容损坏。新增助手两个 CPU 文件独立运行 **11 passed**。

## 128K 严格 phase 门禁

新 auditor 对所选对应窗按固定 iteration 比较：C1→N1，C2/C3→N2。比较所有 CPU metadata 字段，只排除 call，包含 input_ids_cpu；并要求匹配计数等于 `16 * repeats * 20`。原跨 phase 的 0↔-1 记录及范围检查、其他 geometry、token/events、cache/source 门禁保留。

独立提取并执行**实际新脚本 AST 中的选择/断言分支**，检查三个 phase 对的正负例：

| 对应窗 | 相同输入 | 同窗将一个 input ID 从 0 改为 -1 |
|---|---|---|
| C1→N1 | 通过，计数+1 | 拒绝，计数不增加 |
| C2→N2 | 通过，计数+1 | 拒绝，计数不增加 |
| C3→N2 | 通过，计数+1 | 拒绝，计数不增加 |

这六项是 CPU 控制流检查，不冒充新的 NPU 或整模型结果。此前指出的后轮只检查 0/-1 范围而不严格对应的问题已经补齐。

本审查仅写 reports，未改正式源、运行助手或提交任务。下一步只应重跑 8K，Native2 不增加；若首差出现仍先停止定位，8K 通过后再考虑 128K。
