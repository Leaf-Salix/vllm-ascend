# 不同桶暖身借用共享池的同步修正审查

## 结论

在当前限定的单线程、同模型设备顺序执行合同下，新增同步是完整的借还保护，没有发现阻止先进行单卡双桶验证的问题。该修正尚未经过本审查读取的新硬件结果；原整模型任务初始化失败不能记为 token 精度失败或精度通过。

## 保护链条

当前 `workspace.arguments` 在已绑定 capture stream 后：

1. 同 capture stream 路径不增加同步；捕获时不增加分配。
2. 其他 stream 若正在 capture，仍直接拒绝，不执行同步，也不改变 capture stream。
3. 其他 stream 若为非 capture 暖身，先 `torch.npu.synchronize(self.device)`，等待先前任何 stream 对池的访问结束，再返回同一套已分配视图。
4. 现有 service 在非 capture 完整根提交之后执行当前 stream synchronize，保证暖身返回前完成，随后原 capture stream 再借用不会与该暖身重叠。

因此本次不是单纯取消原 guard，而是把“禁止任何跨流访问”收窄为“允许带入场和归还 fence 的非 capture 借用”。首次 capture 前的非 capture 服务调用也已有结束同步；模型构造时常量和 FFTS 初始化均有相应完成同步。

静态选择、常量包、十个 workspace 参数、大小、别名与 DSL 数学没有改变。捕获身份仍只记录原 stream，不能趁一次非 capture 借用重新绑定到另一捕获流。

## 必须保留的并发边界

graph replay 绕过 Python，`arguments` 无法检查 replay 的 stream，也无法自动插入跨图事件。文档中的“串行 replay”必须指**设备执行有序或前一个已经完成**：同一 compute stream 顺序提交自然满足；不同 stream 仅 host 依次调用 replay 并不满足。当前实现不提供多线程或多 stream 并发服务安全，也不能宣称支持它。

前置全设备同步只保护调用开始之前已提交的工作，不能防止另一线程随后继续提交碰撞任务。因此应继续保留串行调用者合同，不把全设备 fence 描述为通用锁。

## CPU 与下一硬件门禁

独立运行 `test_precision_spmd_full_root_cpu.py`：**17 passed**。新测试验证异流 capture 拒绝、异流非 capture 增加一次设备同步、原 capture stream 身份保持，以及同 capture stream 再次捕获不新增同步。它是控制流合同测试，不代表 NPU 调度已验证。

下一单卡测试应实际复现整模型的顺序：固定 capture 侧流捕获 T6；在 compute stream 做另一个 T 的 NONE 暖身；回到原侧流捕获第二图；随后两个不同 T 图在正常 compute stream 顺序 replay，并在每次 poison/A/B/A 后复核 Native 八边界、所有 guard、只读输入和常量包。这样同时检查旧桶仍可重放及新桶暖身没有破坏共用池。通过后再重试 8K；不应直接扩展 128K。

本审查只读取两处 diff 与现有 service，同步修改未由本审查实施，未提交设备任务。
