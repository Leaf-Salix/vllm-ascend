# 双桶输入 RoPE 别名问题：只读设计审查

## 结论

现有代码存在明确的共享输入覆盖路径，足以解释为何建立 T6 fixture 后，旧 T21 graph 可能消费不再等于其 Native 金值输入的 RoPE 行。当前应先修复输入观测/恢复助手，不应据此修改正式数学。尚须实际保存的旧输入变动记录和恢复后 replay 结果确认本次失败完全由它导致。

## 直接源码证据

- `vllm_ascend/attention/dsa_v1.py` 的 decode metadata 路径在 954、1350 行调用 `get_cos_and_sin_dsa(..., use_cache=True)`。
- `ops/rope_dsv4.py` 119～126 行从全局 `_ROPE_STATE.runtime_buffer` 取得同一 cos/sin 缓冲，向 `[:num_tokens]` 执行 `copy_`，返回同一前缀的 view。后续 fixture 不会给旧 fixture 分配独立 current RoPE 存储。
- 本实验 `ragged_fixture.py` 把 current cos/sin 的 view 与当时 CPU 值放入 readonly 字典，没有 clone NPU view。
- 复用的 `dsv4_csa_single_layer.restore` 214 行仅恢复各 cache allocation，完全不恢复 readonly 元数据。

T21 的前几行位置为 `[8191,8191,8192,8191,8192,8193,...]`；新 T6 的位置为 `[8191,8192,8193,8194,8195,8196]`。建立第二 fixture 会改写共用前六行，即使各自 positions Tensor 本身保持正确。旧 graph 捕获的是相同 RoPE 地址，不能从 Python fixture 对象恢复旧值。

原先同形状/同 positions 的双根测试没有触发这一覆盖，不能作为不同桶输入独立性的证明。

## 助手修正必须满足

1. 建立 T6 fixture 后，先记录旧 T21 readonly 各字段与原 CPU 快照的逐 byte 差异；记录 cos/sin 两 view 的 storage base、data_ptr、storage_offset、shape/stride，直接证明重叠。错误范围不能只由最终 KV 的 RoPE 通道推断。
2. 每次执行某 fixture 前，只从该 fixture **原始** CPU 快照 `copy_` 回其现有 readonly Tensor；不能重拍快照覆盖旧金值，也不能重新分配地址。
3. 两套元数据共享区域内容不同，不能同时恢复后假设二者均正确。恢复即将执行的那一套，完成相同 stream 的拷贝顺序，并在 replay 前确认 metadata guard。
4. cache 恢复、输出/TopK/工作区 poison、真实 graph replay、执行后 guard、Native 金值八边界仍保留。
5. 原 T21→T6→T21 交替每一步以及后续计时前都应恢复相应 readonly。否则交替通过后，计时仍可能用到最后一套错误内容。

这是为静态图地址重新喂入既定 fixture 的正确输入，与真实框架每步填充 current RoPE 的职责一致，不是降低精度阈值。助手修复前的失败应继续保留；修复后的结果应另用新 helper SHA 和新输出目录，不能覆盖旧失败。

本次审查只确认源码路径及设计约束，尚未读取新 NPU 原始 witness，也未审查完成后的助手 diff。未改源码或提交任务。
