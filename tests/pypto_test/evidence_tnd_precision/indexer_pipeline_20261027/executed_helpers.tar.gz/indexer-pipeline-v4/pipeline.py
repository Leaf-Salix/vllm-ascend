"""Whole IndexQuery-to-TopK MIX; immutable Native arithmetic, independent probe."""
import pypto.language as pl
from ..deepseek_v4_flash_csa_tnd_precision.decode_indexer import *
from .indexer import indexer as original_indexer
from .rendezvous import handoff
from .gap_pipeline_math import idx_cube, idx_vector, had_cube, had_vector
PIPELINE_COEFF_ROWS = pl.dynamic("PIPELINE_COEFF_ROWS")
PIPELINE_COEFF_COLS = pl.dynamic("PIPELINE_COEFF_COLS")
@pl.jit.inline(auto_scope=False)
def pipeline_weights(native_indexer_weights: pl.Tensor[[T_DYN, IDX_N_HEADS], pl.FP16], weights: pl.InOut[pl.Tensor[[T_PAD, IDX_N_HEADS], pl.FP32]], worker: pl.Scalar[pl.INDEX]):
    tokens = pl.tensor.dim(native_indexer_weights, 0)
    row = worker * MM_ROW_TILE
    if row < tokens:
        rows = pl.min(MM_ROW_TILE, tokens - row)
        values = pl.load(native_indexer_weights, [row, 0], [MM_ROW_TILE, IDX_N_HEADS], valid_shape=[rows, IDX_N_HEADS], clamp=True)
        pl.store(pl.cast(values, pl.FP32), [row, 0], weights)

@pl.jit.inline(auto_scope=False)
def pipeline_coefficients(coefficient_scales: pl.Tensor[[T_PAD, IDX_N_HEADS], pl.FP32], weights: pl.Tensor[[T_PAD, IDX_N_HEADS], pl.FP32], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], group_row: pl.Tensor[[T_PAD], pl.INT32], group_rows: pl.Tensor[[T_PAD], pl.INT32], group_count_t: pl.Tensor[[1], pl.INT32], query_group_size: pl.constexpr, coefficients: pl.InOut[pl.Tensor[[PIPELINE_COEFF_ROWS, PIPELINE_COEFF_COLS], pl.FP16]], worker: pl.Scalar[pl.INDEX]):
    coefficient_worker = worker
    coefficient_count = pl.cast(pl.read(group_count_t, [0]), pl.INDEX)
    for coefficient_pair in pl.range(coefficient_worker, coefficient_count, TOPK_QUERY_WORKERS):
        coefficient_rows = pl.tile.full([NATIVE_QLI_WEIGHT_ROWS * query_group_size, IDX_N_HEADS], dtype=pl.FP16, value=0.0)
        coefficient_begin = pl.cast(pl.read(group_row, [coefficient_pair]), pl.INDEX)
        query_scales = pl.load(coefficient_scales, [coefficient_begin, 0], [query_group_size, IDX_N_HEADS])
        query_weights = pl.load(weights, [coefficient_begin, 0], [query_group_size, IDX_N_HEADS])
        query_scale_half = pl.cast(query_scales, pl.FP16, mode='rint')
        query_weight_half = pl.cast(query_weights, pl.FP16, mode='rint')
        head_coefficients = pl.mul(query_scale_half, query_weight_half)
        for coefficient_lane in pl.unroll(query_group_size):
            if coefficient_lane < pl.read(group_rows, [coefficient_pair]):
                head_coefficient = pl.tile.extract(head_coefficients, coefficient_lane, 0, [1, IDX_N_HEADS], target_memory=pl.MemorySpace.Vec)
                coefficient_rows = pl.tile.assemble(coefficient_rows, head_coefficient, [coefficient_lane * (query_group_size + 1), 0])
        coefficient_matrix = pl.tile.reshape(coefficient_rows, [NATIVE_QLI_WEIGHT_ROWS, query_group_size * IDX_N_HEADS])
        pl.store(coefficient_matrix, [coefficient_pair * NATIVE_QLI_WEIGHT_ROWS, 0], coefficients)

@pl.jit.inline(auto_scope=False)
def pipeline_publish(position_ids: pl.Tensor[[T_DYN], pl.INT64], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], score_arena: pl.Tensor[[SCORE_ARENA_ROWS, TOPK_CANDIDATES_PER_LEAF], pl.FP32], topk_scores: pl.Tensor[[T_DYN, IDX_TOPK], pl.FP32], topk_indices: pl.Tensor[[T_DYN, IDX_TOPK], pl.INT32], worker: pl.Scalar[pl.INDEX]):
    """Sort a single leaf and publish each query's Top-512 directly."""
    query_count = pl.tensor.dim(position_ids, 0)
    for query in pl.range(worker, query_count, TOPK_QUERY_WORKERS):
        position = pl.read(position_ids, [query])
        query_request = pl.cast(pl.read(token_request, [query]), pl.INDEX)
        cache_len = pl.read(kv_seq_lens, [pl.max(query_request, 0)]) // COMPRESS_RATIO
        if query_request < 0:
            cache_len = 0
        visible_count = pl.max(pl.min(cache_len, (position + 1) // COMPRESS_RATIO), 0)
        if visible_count > 0:
            indexer_topk_leaf_publish(score_arena, query, visible_count, topk_scores, topk_indices)
        else:
            pl.store(pl.tile.full([1, IDX_TOPK], dtype=pl.FP32, value=FP32_NEG_INF), [query, 0], topk_scores)
            pl.store(pl.tile.full([1, IDX_TOPK], dtype=pl.INT32, value=-1), [query, 0], topk_indices)

@pl.jit.inline(auto_scope=False)
def pipeline_native_cube(qr_hadamard_i8: pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.INT8], qr_hadamard_scale_dq: pl.Tensor[[T_PAD * IDX_N_HEADS, 1], pl.FP32], weights: pl.Tensor[[T_PAD, IDX_N_HEADS], pl.FP32], idx_native_kv_cache: pl.Tensor[[IDX_NATIVE_CACHE_BLOCK_NUM_DYN, INDEXER_PAGE_BYTES_DYN], pl.INT8], idx_block_table: pl.Tensor[[B_DYN, INDEXER_TABLE_COLUMNS_DYN], pl.INT32], position_ids: pl.Tensor[[T_DYN], pl.INT64], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], group_row: pl.Tensor[[T_PAD], pl.INT32], group_rows: pl.Tensor[[T_PAD], pl.INT32], group_count_t: pl.Tensor[[1], pl.INT32], groups_tid: pl.Scalar[pl.TASK_ID], score_arena: pl.Tensor[[SCORE_ARENA_ROWS, TOPK_CANDIDATES_PER_LEAF], pl.FP32], pair_arena: pl.Tensor[[TOPK_ARENA_ROWS, TOPK_PAIR_WIDTH], pl.FP32], qh_quant_tid: pl.Scalar[pl.TASK_ID], weights_tid: pl.Scalar[pl.TASK_ID], cache_write_tid: pl.Scalar[pl.TASK_ID], query_group_size: pl.constexpr, qk_panel_cols: pl.constexpr, score_tile: pl.constexpr, score_sync_start: pl.constexpr, score_early_resolve: pl.constexpr, key_prefetch_panels: pl.constexpr, key_prefetch_to_l0: pl.constexpr, balance_leaves: pl.constexpr, x: pl.Tensor[[T_DYN, D], pl.BF16], qr: pl.Tensor[[T_DYN, Q_LORA], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], wq_b: pl.Tensor[[Q_LORA, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT8], wq_b_scale: pl.Tensor[[IDX_N_HEADS * IDX_HEAD_DIM], pl.FP32], native_indexer_weights: pl.Tensor[[T_DYN, IDX_N_HEADS], pl.FP16], cos: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], sin: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], hadamard: pl.Tensor[[IDX_HEAD_DIM, IDX_HEAD_DIM], pl.BF16], topk_scores: pl.Out[pl.Tensor[[T_DYN, IDX_TOPK], pl.FP32]], topk_idxs: pl.Out[pl.Tensor[[T_DYN, IDX_TOPK], pl.INT32]]):
    """同组query共用Key：双query/M128/N128或S6/M384/N64，保持FP16/Cube策略。"""
    native_page_bytes = pl.tensor.dim(idx_native_kv_cache, 1)
    cache_bytes = pl.tensor.dim(idx_native_kv_cache, 0) * native_page_bytes
    cache_flat = pl.reshape(idx_native_kv_cache, [cache_bytes])
    key_rows = cache_bytes // IDX_HEAD_DIM
    shifted_rows = (cache_bytes - 64) // IDX_HEAD_DIM
    idx_kv_cache = pl.reshape(cache_flat[0:key_rows * IDX_HEAD_DIM], [key_rows, IDX_HEAD_DIM])
    idx_kv_cache_shift64 = pl.reshape(cache_flat[64:64 + shifted_rows * IDX_HEAD_DIM], [shifted_rows, IDX_HEAD_DIM])
    buf_score_transfer = pl.create_tensor([TOPK_SCORE_WORKERS * 2 * query_group_size, score_tile], dtype=pl.FP32)
    buf_score_ffts = pl.create_tensor([256], dtype=pl.INT64)
    coefficient_scales = pl.reshape(qr_hadamard_scale_dq, [T_PAD, IDX_N_HEADS])
    coefficients = pl.create_tensor([T_PAD // query_group_size * NATIVE_QLI_WEIGHT_ROWS, query_group_size * IDX_N_HEADS], dtype=pl.FP16)
    idx_acc = pl.create_tensor([QR_MM_T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], dtype=pl.INT32)
    idx_bf = pl.create_tensor([T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], dtype=pl.BF16)
    idx_bf_rows = pl.reshape(idx_bf, [T_PAD * IDX_N_HEADS, IDX_HEAD_DIM])
    had_acc = pl.create_tensor([pl.tensor.dim(x, 0) * IDX_N_HEADS, IDX_HEAD_DIM], dtype=pl.FP32)
    with pl.spmd(TOPK_SCORE_WORKERS, name_hint='complete_indexer_pipeline', deps=[groups_tid, cache_write_tid], sync_start=True, allow_early_resolve=False) as buffered_leaf_tid:
        pl.system.set_ffts(buf_score_ffts)
        pipeline_worker = pl.tile.get_block_idx()
        idx_acc = idx_cube(x, qr, wq_b, idx_acc, pipeline_worker)
        handoff()
        for query_lane in pl.split_aiv(2, mode=pl.SplitMode.NONE):
            vector_worker = pipeline_worker * 2 + query_lane
            idx_bf = idx_vector(x, qr_scale, wq_b_scale, cos, sin, idx_acc, idx_bf, vector_worker)
            pipeline_weights(native_indexer_weights, weights, vector_worker)
        handoff()
        had_acc = had_cube(x, idx_bf_rows, hadamard, had_acc, pipeline_worker, TOPK_SCORE_WORKERS)
        handoff()
        for quant_lane in pl.split_aiv(2, mode=pl.SplitMode.NONE):
            quant_worker = pipeline_worker * 2 + quant_lane
            qr_hadamard_i8, qr_hadamard_scale_dq = had_vector(x, had_acc, qr_hadamard_i8, qr_hadamard_scale_dq, quant_worker)
        handoff()
        for coefficient_lane_id in pl.split_aiv(2, mode=pl.SplitMode.NONE):
            pipeline_coefficients(coefficient_scales, weights, kv_seq_lens, group_row, group_rows, group_count_t, query_group_size, coefficients, pipeline_worker * 2 + coefficient_lane_id)
        handoff()
        buf_worker = pl.tile.get_block_idx()
        buf_max_cache_len = 0
        for buf_batch in pl.range(pl.tensor.dim(kv_seq_lens, 0)):
            buf_max_cache_len = pl.max(buf_max_cache_len, pl.read(kv_seq_lens, [buf_batch]) // COMPRESS_RATIO)
        buf_capped_history = pl.min(buf_max_cache_len, TOPK_MAX_CANDIDATES)
        buf_max_leaves = pl.max((buf_capped_history + TOPK_CANDIDATES_PER_LEAF - 1) // TOPK_CANDIDATES_PER_LEAF, 1)
        buf_leaf_tiles = TOPK_CANDIDATES_PER_LEAF // BUFFERED_LONG_SCORE_TILE
        buf_extra_leaves = 0
        buf_group_count = pl.cast(pl.read(group_count_t, [0]), pl.INDEX)
        if balance_leaves:
            buf_max_leaves, buf_leaf_tiles, buf_extra_leaves = indexer_long_leaf_plan(buf_capped_history, buf_group_count)
        pl.system.set_ffts(buf_score_ffts)
        for buf_item in pl.range(buf_worker, buf_group_count * buf_max_leaves, TOPK_SCORE_WORKERS):
            if buf_group_count < TOPK_SCORE_WORKERS:
                buf_group = buf_item % buf_group_count
                buf_leaf = buf_item // buf_group_count
            else:
                buf_group = buf_item // buf_max_leaves
                buf_leaf = buf_item % buf_max_leaves
            buf_query = pl.cast(pl.read(group_row, [buf_group]), pl.INDEX)
            buf_group_rows = pl.cast(pl.read(group_rows, [buf_group]), pl.INDEX)
            buf_batch_idx = pl.cast(pl.read(token_request, [buf_query]), pl.INDEX)
            buf_last_position = pl.read(position_ids, [buf_query + buf_group_rows - 1])
            buf_cache_len = pl.read(kv_seq_lens, [buf_batch_idx]) // COMPRESS_RATIO
            buf_visible_count = pl.max(pl.min(pl.min(buf_cache_len, (buf_last_position + 1) // COMPRESS_RATIO), TOPK_MAX_CANDIDATES), 0)
            buf_logical_begin = buf_leaf * TOPK_CANDIDATES_PER_LEAF
            buf_leaf_capacity = TOPK_CANDIDATES_PER_LEAF
            if balance_leaves:
                buf_logical_begin = (buf_leaf * buf_leaf_tiles + pl.min(buf_leaf, buf_extra_leaves)) * BUFFERED_LONG_SCORE_TILE
                buf_leaf_capacity = (buf_leaf_tiles + pl.cast(buf_leaf < buf_extra_leaves, pl.INDEX)) * BUFFERED_LONG_SCORE_TILE
            if buf_logical_begin < buf_visible_count:
                buf_valid_count = pl.min(buf_leaf_capacity, buf_visible_count - buf_logical_begin)
                buf_tile_count = (buf_valid_count + score_tile - 1) // score_tile
                buf_lane_span = pl.min(buf_tile_count * (score_tile // 2), TOPK_CANDIDATES_PER_LEAF // 2)
                buf_score_iters = (buf_lane_span + score_tile // 2 - 1) // (score_tile // 2)
                buf_query_vector = pl.load(qr_hadamard_i8, [buf_query * IDX_N_HEADS, 0], [query_group_size * IDX_N_HEADS, IDX_HEAD_DIM], target_memory=pl.MemorySpace.Mat)
                buf_coefficients_l1 = pl.load(coefficients, [buf_group * NATIVE_QLI_WEIGHT_ROWS, 0], [NATIVE_QLI_WEIGHT_ROWS, query_group_size * IDX_N_HEADS], target_memory=pl.MemorySpace.Mat)
                buf_query_left = pl.tile.move(buf_query_vector, target_memory=pl.MemorySpace.Left)
                buf_coefficient_pair = pl.tile.move(buf_coefficients_l1, target_memory=pl.MemorySpace.Left)
                for buf_score_step in pl.range(buf_score_iters):
                    if buf_score_step >= 2:
                        pl.system.sync_wait(SCORE_CONSUMED_EVENT, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIC)
                    buf_score_begin = buf_score_step * (score_tile // 2)
                    if balance_leaves:
                        buf_score_begin = buf_score_step * score_tile
                    buf_transfer_row = buf_worker * 2 * query_group_size + buf_score_step % 2 * query_group_size
                    buf_previous_l1 = pl.tile.create([query_group_size * IDX_N_HEADS, qk_panel_cols], dtype=pl.FP16, target_memory=pl.MemorySpace.Mat)
                    buf_current_key = pl.tile.create([IDX_HEAD_DIM, qk_panel_cols], dtype=pl.INT8, target_memory=pl.MemorySpace.Right)
                    buf_prefetched_key = pl.tile.create([IDX_HEAD_DIM, qk_panel_cols], dtype=pl.INT8, target_memory=pl.MemorySpace.Right)
                    buf_key_l1_pool = pl.tile.create([2 * qk_panel_cols, IDX_HEAD_DIM], dtype=pl.INT8, target_memory=pl.MemorySpace.Mat)
                    if key_prefetch_panels > 0:
                        buf_prime_col = 0
                        for buf_prime_key_page in pl.unroll(qk_panel_cols // BLOCK_SIZE):
                            buf_prime_key_row = buf_logical_begin + buf_score_begin + buf_prime_col // (score_tile // 2) * buf_lane_span + buf_prime_col % (score_tile // 2) + buf_prime_key_page * BLOCK_SIZE
                            if balance_leaves:
                                buf_prime_key_row = buf_logical_begin + buf_score_begin + buf_prime_col + buf_prime_key_page * BLOCK_SIZE
                            buf_prime_safe_page = pl.min(buf_prime_key_row // BLOCK_SIZE, pl.max((buf_cache_len - 1) // BLOCK_SIZE, 0))
                            buf_prime_physical_page = pl.max(pl.cast(pl.read(idx_block_table, [buf_batch_idx, buf_prime_safe_page]), pl.INDEX), 0)
                            buf_prime_native_byte = buf_prime_physical_page * native_page_bytes
                            if buf_prime_native_byte % IDX_HEAD_DIM == 0:
                                buf_key_l1_pool = pl.gather_row(buf_key_l1_pool, idx_kv_cache, [buf_prime_key_page * BLOCK_SIZE, 0], [buf_prime_native_byte // IDX_HEAD_DIM, 0], [BLOCK_SIZE, IDX_HEAD_DIM])
                            else:
                                buf_key_l1_pool = pl.gather_row(buf_key_l1_pool, idx_kv_cache_shift64, [buf_prime_key_page * BLOCK_SIZE, 0], [buf_prime_native_byte // IDX_HEAD_DIM, 0], [BLOCK_SIZE, IDX_HEAD_DIM])
                        if key_prefetch_to_l0:
                            buf_current_key = pl.tile.extract(pl.tile.transpose_view(buf_key_l1_pool), 0, 0, [IDX_HEAD_DIM, qk_panel_cols], target_memory=pl.MemorySpace.Right)
                    for buf_qk_panel in pl.unroll(score_tile // qk_panel_cols):
                        buf_panel_col = buf_qk_panel * qk_panel_cols
                        buf_load_col = (buf_qk_panel + key_prefetch_panels) * qk_panel_cols
                        buf_load_slot = (buf_qk_panel + key_prefetch_panels) % 2 * qk_panel_cols
                        if key_prefetch_panels > 0:
                            if not key_prefetch_to_l0:
                                buf_current_key = pl.tile.extract(pl.tile.transpose_view(buf_key_l1_pool), 0, buf_qk_panel % 2 * qk_panel_cols, [IDX_HEAD_DIM, qk_panel_cols], target_memory=pl.MemorySpace.Right)
                        if buf_qk_panel + key_prefetch_panels < score_tile // qk_panel_cols:
                            buf_panel_keys = pl.tile.create([qk_panel_cols, IDX_HEAD_DIM], dtype=pl.INT8, target_memory=pl.MemorySpace.Mat)
                            for buf_key_page in pl.unroll(qk_panel_cols // BLOCK_SIZE):
                                buf_key_row = buf_logical_begin + buf_score_begin + buf_load_col // (score_tile // 2) * buf_lane_span + buf_load_col % (score_tile // 2) + buf_key_page * BLOCK_SIZE
                                if balance_leaves:
                                    buf_key_row = buf_logical_begin + buf_score_begin + buf_load_col + buf_key_page * BLOCK_SIZE
                                buf_safe_page = pl.min(buf_key_row // BLOCK_SIZE, pl.max((buf_cache_len - 1) // BLOCK_SIZE, 0))
                                buf_physical_page = pl.max(pl.cast(pl.read(idx_block_table, [buf_batch_idx, buf_safe_page]), pl.INDEX), 0)
                                buf_native_byte = buf_physical_page * native_page_bytes
                                if buf_native_byte % IDX_HEAD_DIM == 0:
                                    if key_prefetch_panels > 0:
                                        buf_key_l1_pool = pl.gather_row(buf_key_l1_pool, idx_kv_cache, [buf_load_slot + buf_key_page * BLOCK_SIZE, 0], [buf_native_byte // IDX_HEAD_DIM, 0], [BLOCK_SIZE, IDX_HEAD_DIM])
                                    else:
                                        buf_panel_keys = pl.gather_row(buf_panel_keys, idx_kv_cache, [buf_key_page * BLOCK_SIZE, 0], [buf_native_byte // IDX_HEAD_DIM, 0], [BLOCK_SIZE, IDX_HEAD_DIM])
                                elif key_prefetch_panels > 0:
                                    buf_key_l1_pool = pl.gather_row(buf_key_l1_pool, idx_kv_cache_shift64, [buf_load_slot + buf_key_page * BLOCK_SIZE, 0], [buf_native_byte // IDX_HEAD_DIM, 0], [BLOCK_SIZE, IDX_HEAD_DIM])
                                else:
                                    buf_panel_keys = pl.gather_row(buf_panel_keys, idx_kv_cache_shift64, [buf_key_page * BLOCK_SIZE, 0], [buf_native_byte // IDX_HEAD_DIM, 0], [BLOCK_SIZE, IDX_HEAD_DIM])
                            if key_prefetch_panels > 0:
                                if key_prefetch_to_l0:
                                    buf_prefetched_key = pl.tile.extract(pl.tile.transpose_view(buf_key_l1_pool), 0, buf_load_slot, [IDX_HEAD_DIM, qk_panel_cols], target_memory=pl.MemorySpace.Right)
                            else:
                                buf_prefetched_key = pl.tile.move(pl.tile.transpose_view(buf_panel_keys), target_memory=pl.MemorySpace.Right)
                        if key_prefetch_panels > 0:
                            buf_key_panel = buf_current_key
                        else:
                            buf_key_panel = buf_prefetched_key
                        buf_scores_l1 = pl.tile.create([query_group_size * IDX_N_HEADS, qk_panel_cols], dtype=pl.FP16, target_memory=pl.MemorySpace.Mat)
                        if buf_qk_panel > 0:
                            buf_previous_pair = pl.tile.extract(buf_previous_l1, 0, 0, [query_group_size * IDX_N_HEADS, qk_panel_cols], target_memory=pl.MemorySpace.Right)
                            buf_scores = pl.tile.matmul(buf_query_left, buf_key_panel)
                            buf_reduced_pair = pl.tile.matmul(buf_coefficient_pair, buf_previous_pair)
                            buf_scores_l1 = pl.tile.assemble(buf_scores_l1, buf_scores, [0, 0], pre_quant=1.0 / BUFFERED_SCORE_SCALE, pre_relu=True)
                            pl.store(pl.set_validshape(buf_reduced_pair, query_group_size, qk_panel_cols), [buf_transfer_row, buf_panel_col - qk_panel_cols], buf_score_transfer)
                        else:
                            buf_scores = pl.tile.matmul(buf_query_left, buf_key_panel)
                            buf_scores_l1 = pl.tile.assemble(buf_scores_l1, buf_scores, [0, 0], pre_quant=1.0 / BUFFERED_SCORE_SCALE, pre_relu=True)
                        buf_previous_l1 = buf_scores_l1
                        if key_prefetch_panels > 0:
                            if key_prefetch_to_l0:
                                if buf_qk_panel + 1 < score_tile // qk_panel_cols:
                                    buf_current_key = buf_prefetched_key
                    buf_last_pair = pl.tile.extract(buf_previous_l1, 0, 0, [query_group_size * IDX_N_HEADS, qk_panel_cols], target_memory=pl.MemorySpace.Right)
                    buf_last_scores = pl.tile.matmul(buf_coefficient_pair, buf_last_pair)
                    pl.store(pl.set_validshape(buf_last_scores, query_group_size, qk_panel_cols), [buf_transfer_row, score_tile - qk_panel_cols], buf_score_transfer)
                    pl.system.sync_set(SCORE_READY_EVENT, pipe=pl.PipeType.FIX, ffts_mode=2, core_type=pl.KernelType.AIC)
                for buf_score_drain in pl.range(pl.min(buf_score_iters, 2)):
                    pl.system.sync_wait(SCORE_CONSUMED_EVENT, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIC)
        for buf_score_lane in pl.split_aiv(2, mode=pl.SplitMode.NONE):
            if balance_leaves:
                for single_item in pl.range(buf_worker, buf_group_count * buf_max_leaves, TOPK_SCORE_WORKERS):
                    if buf_group_count < TOPK_SCORE_WORKERS:
                        single_group = single_item % buf_group_count
                        single_leaf = single_item // buf_group_count
                    else:
                        single_group = single_item // buf_max_leaves
                        single_leaf = single_item % buf_max_leaves
                    single_query = pl.cast(pl.read(group_row, [single_group]), pl.INDEX)
                    single_group_rows = pl.cast(pl.read(group_rows, [single_group]), pl.INDEX)
                    single_batch = pl.cast(pl.read(token_request, [single_query]), pl.INDEX)
                    single_cache_len = pl.read(kv_seq_lens, [single_batch]) // COMPRESS_RATIO
                    single_last_position = pl.read(position_ids, [single_query + single_group_rows - 1])
                    single_visible = pl.max(pl.min(pl.min(single_cache_len, (single_last_position + 1) // COMPRESS_RATIO), TOPK_MAX_CANDIDATES), 0)
                    single_begin = (single_leaf * buf_leaf_tiles + pl.min(single_leaf, buf_extra_leaves)) * score_tile
                    single_capacity = (buf_leaf_tiles + pl.cast(single_leaf < buf_extra_leaves, pl.INDEX)) * score_tile
                    if single_begin < single_visible:
                        single_valid = pl.min(single_capacity, single_visible - single_begin)
                        single_steps = (single_valid + score_tile - 1) // score_tile
                        single_roots = pl.tile.full([query_group_size // 2, TOPK_PAIR_WIDTH], dtype=pl.FP32, value=FP32_NEG_INF)
                        single_segments = pl.tile.full([query_group_size, BUFFERED_LONG_SCORE_TILE], dtype=pl.FP32, value=FP32_NEG_INF)
                        for single_step in pl.range(single_steps):
                            single_score_begin = single_begin + single_step * score_tile
                            single_transfer_row = buf_worker * 2 * query_group_size + single_step % 2 * query_group_size + buf_score_lane * (query_group_size // 2)
                            single_scale_bytes = pl.tile.create([1, score_tile * 2], dtype=pl.INT8)
                            for single_scale_page in pl.range(score_tile // BLOCK_SIZE):
                                single_scale_logical = pl.min(single_score_begin // BLOCK_SIZE + single_scale_page, pl.max((single_cache_len - 1) // BLOCK_SIZE, 0))
                                single_scale_physical = pl.max(pl.cast(pl.read(idx_block_table, [single_batch, single_scale_logical]), pl.INDEX), 0)
                                single_scale_bytes = pl.gather_row(single_scale_bytes, idx_native_kv_cache, [0, single_scale_page * BLOCK_SIZE * 2], [single_scale_physical, INDEXER_KEY_BYTES], [1, BLOCK_SIZE * 2])
                            single_scale_half = pl.tile.reinterpret_view(single_scale_bytes, pl.FP16)
                            single_kv_scale = pl.cast(single_scale_half, pl.FP32)
                            pl.system.sync_wait(SCORE_READY_EVENT, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIV)
                            single_scores = pl.load(buf_score_transfer, [single_transfer_row, 0], [query_group_size // 2, score_tile])
                            pl.system.sync_set(SCORE_CONSUMED_EVENT, pipe=pl.PipeType.MTE2, ffts_mode=2, core_type=pl.KernelType.AIV)
                            for single_local in pl.unroll(query_group_size // 2):
                                single_score_row = pl.tile.extract(single_scores, single_local, 0, [1, score_tile], target_memory=pl.MemorySpace.Vec)
                                single_scaled = pl.mul(single_score_row, single_kv_scale)
                                single_segments = pl.tile.assemble(single_segments, single_scaled, [single_local * 2 + single_step % 2, 0])
                            if single_step % 2 == 1 or single_step + 1 == single_steps:
                                single_segment_begin = single_begin + single_step // 2 * (2 * score_tile)
                                single_segment_span = (single_step % 2 + 1) * score_tile
                                single_segment_rows = pl.tile.reshape(single_segments, [query_group_size // 2, 2 * BUFFERED_LONG_SCORE_TILE])
                                for single_local in pl.unroll(query_group_size // 2):
                                    single_query_lane = buf_score_lane * (query_group_size // 2) + single_local
                                    single_lane_live = single_query_lane < single_group_rows
                                    single_position = pl.read(position_ids, [single_query + pl.min(single_query_lane, single_group_rows - 1)])
                                    single_query_visible = pl.max(pl.min(pl.min(single_cache_len, (single_position + 1) // COMPRESS_RATIO), TOPK_MAX_CANDIDATES), 0)
                                    single_segment_valid = pl.max(pl.min(single_query_visible - single_segment_begin, single_segment_span), 0)
                                    if single_segment_valid > 0 and single_lane_live:
                                        single_segment_data = pl.tile.extract(single_segment_rows, single_local, 0, [1, 2 * BUFFERED_LONG_SCORE_TILE], target_memory=pl.MemorySpace.Vec)
                                        logical_i32 = pl.cast(single_segment_begin, pl.INT32)
                                        if single_segment_valid <= 512:
                                            tiny_indices = pl.add(pl.tile.arange(0, [1, 512], dtype=pl.INT32), logical_i32)
                                            tiny_tile = pl.tile.extract(single_segment_data, 0, 0, [1, 512], target_memory=pl.MemorySpace.Vec)
                                            tiny_raw = pl.set_validshape(tiny_tile, 1, single_segment_valid)
                                            tiny_scores = pl.maximum(pl.tile.fillpad(tiny_raw, pad_value=pl.PadValue.min), FP32_NEG_INF)
                                            tiny_pairs = pl.sort32(tiny_scores, pl.reinterpret_view(tiny_indices, pl.UINT32))
                                            tiny_pairs = pl.mrgsort(tiny_pairs, block_len=64)
                                            tiny_pairs = pl.mrgsort(tiny_pairs, block_len=256)
                                            single_new_root = pl.tile.extract(tiny_pairs, 0, 0, [1, TOPK_PAIR_WIDTH], target_memory=pl.MemorySpace.Vec)
                                        elif single_segment_valid <= 1024:
                                            small_indices = pl.add(pl.tile.arange(0, [1, 1024], dtype=pl.INT32), logical_i32)
                                            small_tile = pl.tile.extract(single_segment_data, 0, 0, [1, 1024], target_memory=pl.MemorySpace.Vec)
                                            small_raw = pl.set_validshape(small_tile, 1, single_segment_valid)
                                            small_scores = pl.maximum(pl.tile.fillpad(small_raw, pad_value=pl.PadValue.min), FP32_NEG_INF)
                                            small_pairs = pl.sort32(small_scores, pl.reinterpret_view(small_indices, pl.UINT32))
                                            small_pairs = pl.mrgsort(small_pairs, block_len=64)
                                            small_pairs = pl.mrgsort(small_pairs, block_len=256)
                                            small_left = pl.tile.slice(small_pairs, [1, TOPK_PAIR_WIDTH], [0, 0])
                                            small_right = pl.tile.slice(small_pairs, [1, TOPK_PAIR_WIDTH], [0, 1024])
                                            small_tmp = pl.tile.create([1, 2 * TOPK_PAIR_WIDTH], dtype=pl.FP32)
                                            small_merged = pl.tile.mrgsort(small_left, small_right, tmp=small_tmp)
                                            single_new_root = pl.tile.extract(small_merged, 0, 0, [1, TOPK_PAIR_WIDTH], target_memory=pl.MemorySpace.Vec)
                                        else:
                                            large_indices = pl.add(pl.tile.arange(0, [1, 2048], dtype=pl.INT32), logical_i32)
                                            large_tile = pl.tile.extract(single_segment_data, 0, 0, [1, 2048], target_memory=pl.MemorySpace.Vec)
                                            large_raw = pl.set_validshape(large_tile, 1, single_segment_valid)
                                            large_scores = pl.maximum(pl.tile.fillpad(large_raw, pad_value=pl.PadValue.min), FP32_NEG_INF)
                                            large_pairs = pl.sort32(large_scores, pl.reinterpret_view(large_indices, pl.UINT32))
                                            large_pairs = pl.mrgsort(large_pairs, block_len=64)
                                            large_pairs = pl.mrgsort(large_pairs, block_len=256)
                                            large_pairs = pl.mrgsort(large_pairs, block_len=1024)
                                            single_new_root = pl.tile.extract(large_pairs, 0, 0, [1, TOPK_PAIR_WIDTH], target_memory=pl.MemorySpace.Vec)
                                        if single_step < 2:
                                            single_roots = pl.tile.assemble(single_roots, single_new_root, [single_local, 0])
                                        else:
                                            single_old_root = pl.tile.extract(single_roots, single_local, 0, [1, TOPK_PAIR_WIDTH], target_memory=pl.MemorySpace.Vec)
                                            single_merge_tmp = pl.tile.create([1, 2 * TOPK_PAIR_WIDTH], dtype=pl.FP32)
                                            single_merged = pl.tile.mrgsort(single_new_root, single_old_root, tmp=single_merge_tmp)
                                            single_next_root = pl.tile.extract(single_merged, 0, 0, [1, TOPK_PAIR_WIDTH], target_memory=pl.MemorySpace.Vec)
                                            single_roots = pl.tile.assemble(single_roots, single_next_root, [single_local, 0])
                        for single_local in pl.unroll(query_group_size // 2):
                            single_query_lane = buf_score_lane * (query_group_size // 2) + single_local
                            if single_query_lane < single_group_rows:
                                single_root = pl.tile.extract(single_roots, single_local, 0, [1, TOPK_PAIR_WIDTH], target_memory=pl.MemorySpace.Vec)
                                pl.store(single_root, [(single_query + single_query_lane) * TOPK_ROWS_PER_QUERY + single_leaf, 0], pair_arena)
            else:
                for buf_item in pl.range(buf_worker, buf_group_count * buf_max_leaves, TOPK_SCORE_WORKERS):
                    if buf_group_count < TOPK_SCORE_WORKERS:
                        buf_group = buf_item % buf_group_count
                        buf_leaf = buf_item // buf_group_count
                    else:
                        buf_group = buf_item // buf_max_leaves
                        buf_leaf = buf_item % buf_max_leaves
                    buf_query = pl.cast(pl.read(group_row, [buf_group]), pl.INDEX)
                    buf_group_rows = pl.cast(pl.read(group_rows, [buf_group]), pl.INDEX)
                    buf_batch_idx = pl.cast(pl.read(token_request, [buf_query]), pl.INDEX)
                    buf_last_position = pl.read(position_ids, [buf_query + buf_group_rows - 1])
                    buf_cache_len = pl.read(kv_seq_lens, [buf_batch_idx]) // COMPRESS_RATIO
                    buf_visible_count = pl.max(pl.min(pl.min(buf_cache_len, (buf_last_position + 1) // COMPRESS_RATIO), TOPK_MAX_CANDIDATES), 0)
                    buf_logical_begin = buf_leaf * TOPK_CANDIDATES_PER_LEAF
                    buf_leaf_capacity = TOPK_CANDIDATES_PER_LEAF
                    if balance_leaves:
                        buf_logical_begin = (buf_leaf * buf_leaf_tiles + pl.min(buf_leaf, buf_extra_leaves)) * BUFFERED_LONG_SCORE_TILE
                        buf_leaf_capacity = (buf_leaf_tiles + pl.cast(buf_leaf < buf_extra_leaves, pl.INDEX)) * BUFFERED_LONG_SCORE_TILE
                    if buf_logical_begin < buf_visible_count:
                        buf_valid_count = pl.min(buf_leaf_capacity, buf_visible_count - buf_logical_begin)
                        buf_tile_count = (buf_valid_count + score_tile - 1) // score_tile
                        buf_lane_span = pl.min(buf_tile_count * (score_tile // 2), TOPK_CANDIDATES_PER_LEAF // 2)
                        buf_score_iters = (buf_lane_span + score_tile // 2 - 1) // (score_tile // 2)
                        buf_lane_begin = buf_score_lane * buf_lane_span
                        prefix_roots = pl.tile.full([query_group_size, TOPK_PAIR_WIDTH], dtype=pl.FP32, value=FP32_NEG_INF)
                        for buf_score_step in pl.range(buf_score_iters):
                            buf_score_begin = buf_score_step * (score_tile // 2)
                            buf_transfer_row = buf_worker * 2 * query_group_size + buf_score_step % 2 * query_group_size
                            buf_scale_bytes = pl.tile.create([1, score_tile], dtype=pl.INT8)
                            for buf_scale_page in pl.range(score_tile // 2 // BLOCK_SIZE):
                                buf_scale_row = buf_logical_begin + buf_score_begin + buf_lane_begin + buf_scale_page * BLOCK_SIZE
                                buf_scale_safe_page = pl.min(buf_scale_row // BLOCK_SIZE, pl.max((buf_cache_len - 1) // BLOCK_SIZE, 0))
                                buf_scale_physical_page = pl.max(pl.cast(pl.read(idx_block_table, [buf_batch_idx, buf_scale_safe_page]), pl.INDEX), 0)
                                buf_scale_bytes = pl.gather_row(buf_scale_bytes, idx_native_kv_cache, [0, buf_scale_page * BLOCK_SIZE * 2], [buf_scale_physical_page, INDEXER_KEY_BYTES], [1, BLOCK_SIZE * 2])
                            buf_scale_half = pl.tile.reinterpret_view(buf_scale_bytes, pl.FP16)
                            buf_kv_scale = pl.cast(buf_scale_half, target_type=pl.FP32)
                            pl.system.sync_wait(SCORE_READY_EVENT, pipe=pl.PipeType.MTE2, core_type=pl.KernelType.AIV)
                            buf_score_sums = pl.load(buf_score_transfer, [buf_transfer_row, buf_score_lane * (score_tile // 2)], [query_group_size, score_tile // 2])
                            pl.system.sync_set(SCORE_CONSUMED_EVENT, pipe=pl.PipeType.MTE2, ffts_mode=2, core_type=pl.KernelType.AIV)
                            for buf_query_lane in pl.unroll(query_group_size):
                                buf_lane_live = buf_query_lane < buf_group_rows
                                buf_position = pl.read(position_ids, [buf_query + pl.min(buf_query_lane, buf_group_rows - 1)])
                                buf_query_visible = pl.max(pl.min(pl.min(buf_cache_len, (buf_position + 1) // COMPRESS_RATIO), TOPK_MAX_CANDIDATES), 0)
                                buf_lane_valid_rows = pl.max(pl.min(buf_query_visible - buf_logical_begin - buf_score_begin - buf_lane_begin, score_tile // 2), 0)
                                buf_lane_valid_rows = pl.min(buf_lane_valid_rows, pl.max(buf_lane_span - buf_score_begin, 0))
                                buf_score_sum = pl.tile.slice(buf_score_sums, [1, score_tile // 2], [buf_query_lane, 0])
                                buf_score_row = pl.mul(buf_score_sum, buf_kv_scale)
                                buf_store_row = buf_query + buf_query_lane
                                buf_store_column = buf_score_begin + buf_lane_begin
                                if buf_max_leaves > 1:
                                    buf_store_row = buf_worker * 2 * query_group_size + buf_query_lane * 2 + buf_score_lane
                                    buf_store_column = buf_score_begin
                                if buf_lane_valid_rows > 0 and buf_lane_live:
                                    pl.store(pl.set_validshape(buf_score_row, 1, buf_lane_valid_rows), [buf_store_row, buf_store_column], score_arena)
                            if balance_leaves:
                                if buf_score_step == 3 and buf_score_iters > 4:
                                    for stream_lane in pl.unroll(query_group_size):
                                        stream_position = pl.read(position_ids, [buf_query + pl.min(stream_lane, buf_group_rows - 1)])
                                        stream_visible = pl.max(pl.min(pl.min(buf_cache_len, (stream_position + 1) // COMPRESS_RATIO), TOPK_MAX_CANDIDATES), 0)
                                        stream_begin = buf_logical_begin + buf_lane_begin
                                        stream_valid = pl.max(pl.min(stream_visible - stream_begin, 2048), 0)
                                        if stream_valid > 0 and stream_lane < buf_group_rows:
                                            stream_root = indexer_topk_segment_pairs(score_arena, buf_worker * 2 * query_group_size + stream_lane * 2 + buf_score_lane, stream_begin, stream_valid, 0)
                                            prefix_roots = pl.tile.assemble(prefix_roots, stream_root, [stream_lane, 0])
                        if buf_max_leaves > 1:
                            for buf_query_lane in pl.unroll(query_group_size):
                                if buf_query_lane < buf_group_rows:
                                    buf_position = pl.read(position_ids, [buf_query + buf_query_lane])
                                    buf_query_visible = pl.max(pl.min(pl.min(buf_cache_len, (buf_position + 1) // COMPRESS_RATIO), TOPK_MAX_CANDIDATES), 0)
                                    buf_half_begin = buf_logical_begin + buf_lane_begin
                                    buf_half_valid = pl.max(pl.min(buf_query_visible - buf_half_begin, buf_lane_span), 0)
                                    buf_half_slot = (buf_query + buf_query_lane) * TOPK_ROWS_PER_QUERY + buf_leaf * 2 + buf_score_lane
                                    if buf_half_valid > 0:
                                        indexer_topk_half_leaf(score_arena, pair_arena, buf_worker * 2 * query_group_size + buf_query_lane * 2 + buf_score_lane, buf_half_begin, buf_half_valid, buf_half_slot)
                                    else:
                                        pl.store(pl.tile.full([1, TOPK_PAIR_WIDTH], dtype=pl.FP32, value=FP32_NEG_INF), [buf_half_slot, 0], pair_arena)
        handoff()
        for publish_lane in pl.split_aiv(2, mode=pl.SplitMode.NONE):
            pipeline_publish(position_ids, kv_seq_lens, token_request, score_arena, topk_scores, topk_idxs, pipeline_worker * 2 + publish_lane)
        handoff()
    return buffered_leaf_tid

@pl.jit.inline(auto_scope=False)
def pipeline_forest(qr_hadamard_i8: pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.INT8], qr_hadamard_scale_dq: pl.Tensor[[T_PAD * IDX_N_HEADS, 1], pl.FP32], weights: pl.Tensor[[T_PAD, IDX_N_HEADS], pl.FP32], idx_native_kv_cache: pl.Tensor[[IDX_NATIVE_CACHE_BLOCK_NUM_DYN, INDEXER_PAGE_BYTES_DYN], pl.INT8], idx_block_table: pl.Tensor[[B_DYN, INDEXER_TABLE_COLUMNS_DYN], pl.INT32], position_ids: pl.Tensor[[T_DYN], pl.INT64], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], topk_scores: pl.Out[pl.Tensor[[T_DYN, IDX_TOPK], pl.FP32]], topk_idxs: pl.Out[pl.Tensor[[T_DYN, IDX_TOPK], pl.INT32]], qh_quant_tid: pl.Scalar[pl.TASK_ID], weights_tid: pl.Scalar[pl.TASK_ID], cache_write_tid: pl.Scalar[pl.TASK_ID], host_max_seq_len: pl.Scalar[pl.INT32], x: pl.Tensor[[T_DYN, D], pl.BF16], qr: pl.Tensor[[T_DYN, Q_LORA], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], wq_b: pl.Tensor[[Q_LORA, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT8], wq_b_scale: pl.Tensor[[IDX_N_HEADS * IDX_HEAD_DIM], pl.FP32], native_indexer_weights: pl.Tensor[[T_DYN, IDX_N_HEADS], pl.FP16], cos: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], sin: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], hadamard: pl.Tensor[[IDX_HEAD_DIM, IDX_HEAD_DIM], pl.BF16]):
    """Score leaves and merge Top-K roots; long S6 publishes one root per leaf."""
    rgroup_row = pl.create_tensor([T_PAD], dtype=pl.INT32)
    rgroup_rows = pl.create_tensor([T_PAD], dtype=pl.INT32)
    rgroup_count = pl.create_tensor([1], dtype=pl.INT32)
    pgroup_row = pl.create_tensor([T_PAD], dtype=pl.INT32)
    pgroup_rows = pl.create_tensor([T_PAD], dtype=pl.INT32)
    pgroup_count = pl.create_tensor([1], dtype=pl.INT32)
    with pl.at(level=pl.Level.CORE_GROUP, name_hint='indexer_query_groups') as groups_tid:
        for token in pl.range(pl.tensor.dim(position_ids, 0)):
            if pl.read(token_request, [token]) < 0:
                pl.store(pl.tile.full([1, IDX_TOPK], dtype=pl.FP32, value=FP32_NEG_INF), [token, 0], topk_scores)
                pl.store(pl.tile.full([1, IDX_TOPK], dtype=pl.INT32, value=-1), [token, 0], topk_idxs)
        indexer_build_query_groups(query_start_loc, kv_seq_lens, rgroup_row, rgroup_rows, rgroup_count, S)
        indexer_build_query_groups(query_start_loc, kv_seq_lens, pgroup_row, pgroup_rows, pgroup_count, 2)
    native_page_bytes = pl.tensor.dim(idx_native_kv_cache, 1)
    cache_bytes = pl.tensor.dim(idx_native_kv_cache, 0) * native_page_bytes
    cache_flat = pl.reshape(idx_native_kv_cache, [cache_bytes])
    key_rows = cache_bytes // IDX_HEAD_DIM
    shifted_rows = (cache_bytes - 64) // IDX_HEAD_DIM
    idx_kv_cache = pl.reshape(cache_flat[0:key_rows * IDX_HEAD_DIM], [key_rows, IDX_HEAD_DIM])
    idx_kv_cache_shift64 = pl.reshape(cache_flat[64:64 + shifted_rows * IDX_HEAD_DIM], [shifted_rows, IDX_HEAD_DIM])
    pair_arena = pl.create_tensor([TOPK_ARENA_ROWS, TOPK_PAIR_WIDTH], dtype=pl.FP32)
    score_arena = pl.create_tensor([SCORE_ARENA_ROWS, TOPK_CANDIDATES_PER_LEAF], dtype=pl.FP32)
    max_topk_cache_len = host_max_seq_len // COMPRESS_RATIO
    if max_topk_cache_len > TOPK_CANDIDATES_PER_LEAF:
        long_request_groups = indexer_query_group_count(query_start_loc, kv_seq_lens, S)
        if long_request_groups >= LONG_S6_MIN_REQUEST_GROUPS:
            score_tid = pipeline_native_cube(qr_hadamard_i8, qr_hadamard_scale_dq, weights, idx_native_kv_cache, idx_block_table, position_ids, kv_seq_lens, token_request, rgroup_row, rgroup_rows, rgroup_count, groups_tid, score_arena, pair_arena, qh_quant_tid, weights_tid, cache_write_tid, S, 64, BUFFERED_LONG_SCORE_TILE, True, False, 1, True, True, x, qr, qr_scale, wq_b, wq_b_scale, native_indexer_weights, cos, sin, hadamard, topk_scores, topk_idxs)
        else:
            score_tid = pipeline_native_cube(qr_hadamard_i8, qr_hadamard_scale_dq, weights, idx_native_kv_cache, idx_block_table, position_ids, kv_seq_lens, token_request, pgroup_row, pgroup_rows, pgroup_count, groups_tid, score_arena, pair_arena, qh_quant_tid, weights_tid, cache_write_tid, 2, NATIVE_QLI_QK_COLS, BUFFERED_LONG_SCORE_TILE, True, False, 1, True, False, x, qr, qr_scale, wq_b, wq_b_scale, native_indexer_weights, cos, sin, hadamard, topk_scores, topk_idxs)
    else:
        short_pair_groups = indexer_query_group_count(query_start_loc, kv_seq_lens, 2)
        short_request_groups = indexer_query_group_count(query_start_loc, kv_seq_lens, S)
        short_pair_waves = (short_pair_groups + TOPK_SCORE_WORKERS - 1) // TOPK_SCORE_WORKERS
        short_request_waves = (short_request_groups + TOPK_SCORE_WORKERS - 1) // TOPK_SCORE_WORKERS
        short_use_request = pl.cast(0, pl.INT32)
        if short_request_groups >= TOPK_SCORE_WORKERS:
            if 4 * S * short_request_waves <= 5 * 2 * short_pair_waves:
                short_use_request = pl.cast(1, pl.INT32)
        if short_use_request == 1:
            score_tid = pipeline_native_cube(qr_hadamard_i8, qr_hadamard_scale_dq, weights, idx_native_kv_cache, idx_block_table, position_ids, kv_seq_lens, token_request, rgroup_row, rgroup_rows, rgroup_count, groups_tid, score_arena, pair_arena, qh_quant_tid, weights_tid, cache_write_tid, S, 64, BUFFERED_SCORE_TILE, False, True, 0, True, False, x, qr, qr_scale, wq_b, wq_b_scale, native_indexer_weights, cos, sin, hadamard, topk_scores, topk_idxs)
        else:
            score_tid = pipeline_native_cube(qr_hadamard_i8, qr_hadamard_scale_dq, weights, idx_native_kv_cache, idx_block_table, position_ids, kv_seq_lens, token_request, pgroup_row, pgroup_rows, pgroup_count, groups_tid, score_arena, pair_arena, qh_quant_tid, weights_tid, cache_write_tid, 2, NATIVE_QLI_QK_COLS, BUFFERED_SCORE_TILE, False, True, 0, True, False, x, qr, qr_scale, wq_b, wq_b_scale, native_indexer_weights, cos, sin, hadamard, topk_scores, topk_idxs)
    return (topk_scores, topk_idxs, score_tid)

@pl.jit.inline
def indexer(x: pl.Tensor[[T_DYN, D], pl.BF16], qr: pl.Tensor[[T_DYN, Q_LORA], pl.INT8], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], wq_b: pl.Tensor[[Q_LORA, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT8], wq_b_scale: pl.Tensor[[IDX_N_HEADS * IDX_HEAD_DIM], pl.FP32], native_indexer_weights: pl.Tensor[[T_DYN, IDX_N_HEADS], pl.FP16], cos: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], sin: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], hadamard: pl.Tensor[[IDX_HEAD_DIM, IDX_HEAD_DIM], pl.BF16], idx_native_kv_cache: pl.Tensor[[IDX_NATIVE_CACHE_BLOCK_NUM_DYN, INDEXER_PAGE_BYTES_DYN], pl.INT8], idx_block_table: pl.Tensor[[B_DYN, INDEXER_TABLE_COLUMNS_DYN], pl.INT32], topk_scores: pl.Out[pl.Tensor[[T_DYN, IDX_TOPK], pl.FP32]], topk_idxs: pl.Out[pl.Tensor[[T_DYN, IDX_TOPK], pl.INT32]], position_ids: pl.Tensor[[T_DYN], pl.INT64], kv_seq_lens: pl.Tensor[[B_DYN], pl.INT32], token_request: pl.Tensor[[T_DYN], pl.INT32], query_start_loc: pl.Tensor[[QUERY_BOUNDS_DYN], pl.INT32], late_dep: pl.Scalar[pl.TASK_ID], cache_write_dep: pl.Scalar[pl.TASK_ID], host_max_seq_len: pl.Scalar[pl.INT32]):
    if host_max_seq_len // COMPRESS_RATIO >= INDEXER_NATIVE_CUBE_MIN_ROWS and host_max_seq_len // COMPRESS_RATIO <= TOPK_CANDIDATES_PER_LEAF:
        qr_hadamard_i8 = pl.create_tensor([T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], dtype=pl.INT8)
        qr_hadamard_scale_dq = pl.create_tensor([T_PAD * IDX_N_HEADS, 1], dtype=pl.FP32)
        weights = pl.create_tensor([T_PAD, IDX_N_HEADS], dtype=pl.FP32)
        gate = pl.system.task_dummy(deps=[])
        topk_scores, topk_idxs, pipeline_tid = pipeline_forest(qr_hadamard_i8, qr_hadamard_scale_dq, weights, idx_native_kv_cache, idx_block_table, position_ids, kv_seq_lens, token_request, query_start_loc, topk_scores, topk_idxs, gate, gate, cache_write_dep, host_max_seq_len, x, qr, qr_scale, wq_b, wq_b_scale, native_indexer_weights, cos, sin, hadamard)
    else:
        topk_scores, topk_idxs = original_indexer(x, qr, qr_scale, wq_b, wq_b_scale, native_indexer_weights, cos, sin, hadamard, idx_native_kv_cache, idx_block_table, topk_scores, topk_idxs, position_ids, kv_seq_lens, token_request, query_start_loc, late_dep, cache_write_dep, host_max_seq_len)
    return (topk_scores, topk_idxs)
