"""Derive dependency-only observation without changing qualified kernel sources."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PARENT = HERE / "indexer-pipeline-v6"
OUT = HERE / "indexer-dependency-v2"
OUT.mkdir(exist_ok=False)
remote = "/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-sdk-alignment-20261026-codex/"
source = (PARENT / "probe_perf.py").read_text()
prefix = source[:source.index("    def restore_readonly(fixture):")]
prefix = prefix.replace("enable_chip_swimlane=1,enable_dep_gen=False", "enable_chip_swimlane=0,enable_dep_gen=True")
tail = source[source.index("except Exception as exc:"):]
observation = '''    report['scope']='same-source complete Indexer dependency diagnostic; no timing or Native precision qualification'
    report['dependency_generation']=True
    report['timing_executed']=False
    report['accuracy_executed']=False
    report['derived_parent_sha256']=PARENT_SHA
    report['derived_probe_sha256']=DERIVED_SHA
    report['DFX']={'level':0,'enable_dep_gen':True,'windows':[]}
    stable={}
    initial={}
    index=0
    for repeat in range(2):
        for arm in ('baseline','candidate'):
            graph,f,output,topk=rows[arm]
            restore(f)
            for live,snapshot in f['readonly'].values():live.copy_(snapshot)
            torch.npu.synchronize()
            pypto.torch.begin_dfx();graph.replay();pypto.torch.end_dfx()
            torch.npu.synchronize()
            actual=collect_state(f,output,topk)
            if repeat==0:initial[arm]=actual
            else:assert all(exact(value,initial[arm][name]) for name,value in actual.items()),(arm,'dependency self-repeat drift')
            assert all(value['status']=='PASS' for value in guard_checks(f).values()),(arm,'guard')
            live,snapshots=packets_by_arm[arm]
            assert all(exact(v.cpu(),snapshots[k]) for k,v in live.items()),(arm,'readonly packet')
            dfx_path=args.out/'dfx'
            if index:dfx_path=dfx_path/f'window_{index}'
            dep_path=dfx_path/'deps.json'
            data=json.loads(dep_path.read_text())
            mapping={int(t['task_id']):t['kernel_ids'] for t in data['tasks']}
            if arm in stable:assert mapping==stable[arm],(arm,'dependency task map unstable')
            else:stable[arm]=mapping
            report['DFX']['windows'].append({'arm':arm,'repeat':repeat,'path':str(dep_path),'sha256':hashlib.sha256(dep_path.read_bytes()).hexdigest(),'tasks':len(mapping)})
            index+=1
            save()
            print('DEPENDENCY_WINDOW',arm,repeat,len(mapping),flush=True)
    report['complete']=True
    report['pass']=True
    save()
'''
derived = prefix + observation + tail
(OUT / "derived_probe.py").write_text(derived)
sha = lambda s: hashlib.sha256(s.encode()).hexdigest()
parent_sha, derived_sha = sha(source), sha(derived)
(OUT / "device.py").write_text(f'''from pathlib import Path
import hashlib,json,runpy,sys
here=Path(__file__).resolve().parent
assert all(hashlib.sha256((here/k).read_bytes()).hexdigest()==v for k,v in json.loads((here/'manifest.json').read_text()).items())
parent=Path({remote + PARENT.name!r})
assert hashlib.sha256((parent/'probe_perf.py').read_bytes()).hexdigest()=={parent_sha!r}
sys.path.insert(0,str(parent))
runpy.run_path(str(parent/'sdk_bind.py'),run_name='__sdk_preflight__')
source=(here/'derived_probe.py').read_text()
assert hashlib.sha256(source.encode()).hexdigest()=={derived_sha!r}
exec(compile(source,str(parent/'probe_perf.py'),'exec'),{{'__name__':'__main__','__file__':str(parent/'probe_perf.py'),'PARENT_SHA':{parent_sha!r},'DERIVED_SHA':{derived_sha!r}}})
''')
runner = (HERE / "query-dependency-v1/run.sh").read_text().replace("query-island-v14", PARENT.name)
# Preserve the accepted cache and SDK; observation does not change binaries.
runner = runner.replace('export PYPTO_CACHE=0\n', '')
runner = runner.replace('export PYPTO_PROG_BUILD_DIR="$tw_job_root/build"\n', '')
(OUT / "run.sh").write_text(runner)
(OUT / "DERIVATION.json").write_text(json.dumps({
    "parent_helper":PARENT.name,"parent_probe_sha256":parent_sha,"derived_probe_sha256":derived_sha,
    "kernel_source_changed":False,"timing_collected":False,"precision_versus_native":False,
    "self_repeat_only":True,"observation":"4 dependency windows; same CPU64 and actual READY child identity proof",
    "limits_seconds":[780,750],
},indent=2)+"\n")
(OUT / "manifest.json").write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.iterdir())},indent=2)+"\n")
print(OUT)
