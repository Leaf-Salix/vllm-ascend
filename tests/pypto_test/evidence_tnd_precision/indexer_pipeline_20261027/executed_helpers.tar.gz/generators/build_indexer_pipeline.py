"""Extract unchanged arithmetic into an isolated whole-Indexer schedule probe."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent / "vllm-ascend-nalinaly-tnd-20261008-codex"
OPS = REPO / "vllm_ascend/ops/pypto"
OUT = HERE / "indexer-pipeline-v6"
OUT.mkdir(exist_ok=False)
BASE = HERE / "had-four-token-v1"
for item in BASE.iterdir():
    if item.suffix in (".py", ".json", ".sh") and item.name not in {
        "hadamard.py", "indexer.py", "manifest.json", "SOURCE.json",
    }:
        shutil.copy2(item, OUT / item.name)
shutil.copytree(BASE / "candidate_package", OUT / "candidate_package",
                ignore=shutil.ignore_patterns("__pycache__", "._*"))

base_path = OPS / "deepseek_v4_flash_csa_tnd_precision/decode_indexer.py"
tree = ast.parse(base_path.read_text())
functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
spmd_path = OPS / "deepseek_v4_flash_csa_tnd_precision_spmd/indexer.py"
original_indexer = next(n for n in ast.parse(spmd_path.read_text()).body
                        if isinstance(n, ast.FunctionDef) and n.name == "indexer")

def statements(source):
    return ast.parse(source).body

def clone(name):
    return copy.deepcopy(functions[name])

def body_spmd(fn):
    return next(n for n in fn.body if isinstance(n, ast.With)
                and isinstance(n.items[0].context_expr, ast.Call)
                and ast.unparse(n.items[0].context_expr.func) == "pl.spmd")

def inline_worker(name, worker_assignment):
    fn = clone(name)
    with_node = body_spmd(fn)
    fn.body = copy.deepcopy(with_node.body)
    fn.body = [n for n in fn.body if ast.unparse(n) != worker_assignment]
    fn.args.args = [a for a in fn.args.args if not a.arg.endswith("_tid") and a.arg != "gate_dep"]
    fn.args.args.append(ast.arg(arg="worker", annotation=ast.parse("pl.Scalar[pl.INDEX]", mode="eval").body))
    fn.decorator_list = [ast.parse("pl.jit.inline(auto_scope=False)", mode="eval").body]
    return fn

# Complete FP16 publication, with the original row-block owner mapping.
weight = inline_worker("indexer_native_weights", "row = pl.tile.get_block_idx() * MM_ROW_TILE")
weight.name = "pipeline_weights"
weight.args.args.insert(1, ast.arg(arg="weights", annotation=ast.parse("pl.InOut[pl.Tensor[[T_PAD, IDX_N_HEADS], pl.FP32]]", mode="eval").body))
weight.body = statements("tokens = pl.tensor.dim(native_indexer_weights, 0)\nrow = worker * MM_ROW_TILE") + weight.body
weight.body = weight.body[:2] + [ast.If(test=ast.parse("row < tokens", mode="eval").body, body=weight.body[2:], orelse=[])]
weight.returns = None

coeff = inline_worker("indexer_head_coefficients", "coefficient_worker = pl.tile.get_block_idx()")
coeff.name = "pipeline_coefficients"
coeff.returns = None
coeff.args.args.insert(-1, ast.arg(arg="coefficients", annotation=ast.parse("pl.InOut[pl.Tensor[[PIPELINE_COEFF_ROWS, PIPELINE_COEFF_COLS], pl.FP16]]", mode="eval").body))
coeff.args.args[0] = ast.arg(arg="coefficient_scales", annotation=ast.parse("pl.Tensor[[T_PAD, IDX_N_HEADS], pl.FP32]", mode="eval").body)
coeff.body = statements("coefficient_worker = worker") + coeff.body

publish = clone("indexer_topk_single_leaf_publish")
publish.name = "pipeline_publish"
publish.decorator_list = [ast.parse("pl.jit.inline(auto_scope=False)", mode="eval").body]
publish.body = [n for n in publish.body if ast.unparse(n) != "worker = pl.tile.get_block_idx()"]
publish.args.args.append(ast.arg(arg="worker", annotation=ast.parse("pl.Scalar[pl.INDEX]", mode="eval").body))

extra_names = ("x", "qr", "qr_scale", "wq_b", "wq_b_scale", "native_indexer_weights", "cos", "sin", "hadamard", "topk_scores", "topk_idxs")
extra = [copy.deepcopy(next(a for a in original_indexer.args.args if a.arg == name)) for name in extra_names]
score = clone("indexer_score_topk_native_cube")
score.name = "pipeline_native_cube"
score.args.args += copy.deepcopy(extra)
spmd = body_spmd(score)
# Keep original cache descriptors and Score workspace allocations; move the
# coefficient producer into the same MIX, without changing its FP16 arithmetic.
score.body = [n for n in score.body if not (isinstance(n, ast.Assign)
    and isinstance(n.value, ast.Call) and ast.unparse(n.value.func) == "indexer_head_coefficients")]
spmd = body_spmd(score)
alloc = statements("""
coefficient_scales = pl.reshape(qr_hadamard_scale_dq, [T_PAD, IDX_N_HEADS])
coefficients = pl.create_tensor([T_PAD // query_group_size * NATIVE_QLI_WEIGHT_ROWS, query_group_size * IDX_N_HEADS], dtype=pl.FP16)
idx_acc = pl.create_tensor([QR_MM_T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], dtype=pl.INT32)
idx_bf = pl.create_tensor([T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], dtype=pl.BF16)
idx_bf_rows = pl.reshape(idx_bf, [T_PAD * IDX_N_HEADS, IDX_HEAD_DIM])
pipeline_tokens = pl.tensor.dim(x, 0)
had_acc = pl.create_tensor([pipeline_tokens * IDX_N_HEADS, IDX_HEAD_DIM], dtype=pl.FP32)
""")
score.body[score.body.index(spmd):score.body.index(spmd)] = alloc
spmd.items[0].context_expr.keywords = [
    ast.keyword(arg="name_hint", value=ast.Constant("complete_indexer_pipeline")),
    ast.keyword(arg="deps", value=ast.parse("[groups_tid, cache_write_tid]", mode="eval").body),
    ast.keyword(arg="sync_start", value=ast.Constant(True)),
    ast.keyword(arg="allow_early_resolve", value=ast.Constant(False)),
]
prefix = statements("""
pl.system.set_ffts(buf_score_ffts)
pipeline_worker = pl.tile.get_block_idx()
idx_acc = idx_cube(x, qr, wq_b, idx_acc, pipeline_worker)
handoff()
for query_lane in pl.split_aiv(2, mode=pl.SplitMode.NONE):
    vector_worker = pipeline_worker * 2 + query_lane
    idx_bf = idx_vector(x, qr_scale, wq_b_scale, cos, sin, idx_acc, idx_bf, vector_worker)
    pipeline_weights(native_indexer_weights, weights, vector_worker)
handoff()
had_acc = had_cube(x, idx_bf_rows, hadamard, had_acc, pipeline_worker, TOPK_SCORE_WORKERS)
handoff()
for quant_lane in pl.split_aiv(2, mode=pl.SplitMode.NONE):
    quant_worker = pipeline_worker * 2 + quant_lane
    qr_hadamard_i8, qr_hadamard_scale_dq = had_vector(x, had_acc, qr_hadamard_i8, qr_hadamard_scale_dq, quant_worker)
handoff()
for coefficient_lane_id in pl.split_aiv(2, mode=pl.SplitMode.NONE):
    pipeline_coefficients(coefficient_scales, weights, kv_seq_lens, group_row, group_rows, group_count_t, query_group_size, coefficients, pipeline_worker * 2 + coefficient_lane_id)
handoff()
""")
suffix = statements("""
handoff()
for publish_lane in pl.split_aiv(2, mode=pl.SplitMode.NONE):
    pipeline_publish(position_ids, kv_seq_lens, token_request, score_arena, topk_scores, topk_idxs, pipeline_worker * 2 + publish_lane)
handoff()
""")
spmd.body = prefix + spmd.body + suffix

forest = clone("indexer_score_topk_forest")
forest.name = "pipeline_forest"
forest.args.args += copy.deepcopy(extra[:-2])
# The candidate is only selected for single-leaf native-Cube history. Keep the
# four original policy arguments and runtime query-group selection unchanged.
branch = next(n for n in forest.body if isinstance(n, ast.If))
assert "max_topk_cache_len >=" in ast.unparse(branch.test)
branch.orelse = [ast.Pass()]
forest.body = forest.body[:forest.body.index(branch)] + branch.body
forest.body.append(ast.Return(value=ast.parse("(topk_scores, topk_idxs, score_tid)", mode="eval").body))
class Redirect(ast.NodeTransformer):
    def visit_Call(self, node):
        self.generic_visit(node)
        if isinstance(node.func, ast.Name) and node.func.id == "indexer_score_topk_native_cube":
            node.func.id = "pipeline_native_cube"
            node.args += [ast.Name(id=name, ctx=ast.Load()) for name in extra_names]
        return node
forest = Redirect().visit(forest)

entry = copy.deepcopy(original_indexer)
entry.body = statements("""
pipeline_history = host_max_seq_len // COMPRESS_RATIO
pipeline_enabled = pl.cast(0, pl.INT32)
if pipeline_history >= INDEXER_NATIVE_CUBE_MIN_ROWS:
    if pipeline_history <= TOPK_CANDIDATES_PER_LEAF:
        pipeline_enabled = pl.cast(1, pl.INT32)
if pipeline_enabled == 1:
    qr_hadamard_i8 = pl.create_tensor([T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], dtype=pl.INT8)
    qr_hadamard_scale_dq = pl.create_tensor([T_PAD * IDX_N_HEADS, 1], dtype=pl.FP32)
    weights = pl.create_tensor([T_PAD, IDX_N_HEADS], dtype=pl.FP32)
    gate = pl.system.task_dummy(deps=[])
    topk_scores, topk_idxs, pipeline_tid = pipeline_forest(qr_hadamard_i8, qr_hadamard_scale_dq, weights, idx_native_kv_cache, idx_block_table, position_ids, kv_seq_lens, token_request, query_start_loc, topk_scores, topk_idxs, gate, gate, cache_write_dep, host_max_seq_len, x, qr, qr_scale, wq_b, wq_b_scale, native_indexer_weights, cos, sin, hadamard)
else:
    topk_scores, topk_idxs = original_indexer(x, qr, qr_scale, wq_b, wq_b_scale, native_indexer_weights, cos, sin, hadamard, idx_native_kv_cache, idx_block_table, topk_scores, topk_idxs, position_ids, kv_seq_lens, token_request, query_start_loc, late_dep, cache_write_dep, host_max_seq_len)
return topk_scores, topk_idxs
""")
header = '''"""Whole IndexQuery-to-TopK MIX; immutable Native arithmetic, independent probe."""
import pypto.language as pl
from ..deepseek_v4_flash_csa_tnd_precision.decode_indexer import *
from .indexer import indexer as original_indexer
from .rendezvous import handoff
from .gap_pipeline_math import idx_cube, idx_vector, had_cube, had_vector
PIPELINE_COEFF_ROWS = pl.dynamic("PIPELINE_COEFF_ROWS")
PIPELINE_COEFF_COLS = pl.dynamic("PIPELINE_COEFF_COLS")
'''
module = ast.Module(body=[weight, coeff, publish, score, forest, entry], type_ignores=[])
ast.fix_missing_locations(module)
(OUT / "pipeline.py").write_text(header + ast.unparse(module) + "\n")
math_tree = ast.parse((HERE / "query-island-v10/island_math.py").read_text())
math_tree.body = [n for n in math_tree.body if not (isinstance(n, ast.FunctionDef) and n.name.startswith("main_"))]
(OUT / "pipeline_math.py").write_text(ast.unparse(math_tree) + "\n")
root = (OUT / "baseline_root.py").read_text().replace("precision_spmd.indexer import indexer", "precision_spmd.gap_pipeline import indexer")
root = root.replace(".gap_baseline_sparse", ".gap_candidate_sparse")
(OUT / "candidate_root.py").write_text(root)
loader = (OUT / "load_candidate.py").read_text()
start = loader.index(" if arm=='candidate':")
end = loader.index(" load('vllm_ascend", start)
loader = loader[:start] + " if arm=='candidate':\n  load(S+'.gap_pipeline_math',HERE/'pipeline_math.py')\n  load(S+'.gap_pipeline',HERE/'pipeline.py')\n" + loader[end:]
(OUT / "load_candidate.py").write_text(loader)
env = (OUT / "env.sh").read_text() + '\nexport PYPTO_PROG_BUILD_DIR="' + "/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-sdk-alignment-20261026-codex/indexer-pipeline-v6/build" + '"\n'
(OUT / "env.sh").write_text(env)
probe = (OUT / "probe_perf.py").read_text().replace("accepted Direct vs nalinaly four-token Hadamard row merge; performance first", "accepted Direct vs complete IndexQuery-to-TopK MIX; performance first").replace("Only Hadamard independent row merge M64 to M256 for T>=4, copied nalinaly1685; K128 and all Native rounding unchanged; short T original path", "Single-leaf native-Cube Indexer chain in one MIX; original tiles/math/query policy preserved; other history original path")
(OUT / "probe_perf.py").write_text(probe)
shutil.copy2(HERE / "had-four-observer-v2/identity.py", OUT / "identity.py")
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
files = sorted(p for p in OUT.rglob("*") if p.is_file() and p.name not in {"SOURCE.json", "manifest.json"})
proof = json.loads((BASE / "SOURCE.json").read_text())
proof["candidate_description"] = {"purpose": "whole IndexQuery-to-TopK MIX; six-stage conservative rendezvous", "precision_proven": False, "performance_proven": False}
proof["prototype_version"] = "indexer-pipeline-v6"
proof["candidates"] = {str(p.relative_to(OUT)): sha(p) for p in files}
proof["extraction_source"] = {str(base_path.relative_to(REPO)): sha(base_path), str(spmd_path.relative_to(REPO)): sha(spmd_path)}
(OUT / "SOURCE.json").write_text(json.dumps(proof, indent=2) + "\n")
files.append(OUT / "SOURCE.json")
(OUT / "manifest.json").write_text(json.dumps({str(p.relative_to(OUT)): sha(p) for p in sorted(files)}, indent=2) + "\n")
print(OUT)
