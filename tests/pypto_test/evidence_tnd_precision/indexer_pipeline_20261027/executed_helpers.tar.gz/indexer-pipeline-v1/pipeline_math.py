"""Independent post-QR persistent query island; Native math copied unchanged, no cache waits inside MIX."""
import pypto.language as pl
QH_ROWS = pl.dynamic('ISLAND_QH_ROWS')
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.decode_indexer import D, IDX_HEAD_DIM, IDX_N_HEADS, QR_MM_N_TILE, QR_MM_ROW_TILE, QR_MM_T_PAD, QR_PROJ_WORKERS, Q_LORA, T_DYN

@pl.jit.inline(auto_scope=False)
def idx_cube(x: pl.Tensor[[T_DYN, D], pl.BF16], qr: pl.Tensor[[T_DYN, Q_LORA], pl.INT8], wq_b: pl.Tensor[[Q_LORA, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT8], acc: pl.InOut[pl.Tensor[[QR_MM_T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT32]], worker: pl.Scalar[pl.INDEX]):
    bs = pl.tensor.dim(x, 0)
    row_blocks = (bs + QR_MM_ROW_TILE - 1) // QR_MM_ROW_TILE
    for qr_col in pl.range(worker, IDX_N_HEADS * IDX_HEAD_DIM // QR_MM_N_TILE, QR_PROJ_WORKERS):
        o_base = qr_col * QR_MM_N_TILE
        wq_tile = wq_b[0:Q_LORA, o_base:o_base + QR_MM_N_TILE]
        for qr_rb in pl.range(row_blocks):
            qr_r0 = qr_rb * QR_MM_ROW_TILE
            qr_rows = pl.min(QR_MM_ROW_TILE, bs - qr_r0)
            qr_tile = pl.slice(qr, [QR_MM_ROW_TILE, Q_LORA], [qr_r0, 0], valid_shape=[qr_rows, Q_LORA])
            qr_acc = pl.matmul(qr_tile, wq_tile, out_dtype=pl.INT32)
            acc[qr_r0:qr_r0 + QR_MM_ROW_TILE, o_base:o_base + QR_MM_N_TILE] = qr_acc
    return acc
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.decode_indexer import D, DEQUANT_T_TILE, DQ_ROPE_H_TILE, DQ_ROPE_WORKERS, IDX_HEAD_DIM, IDX_NOPE_HEAD_DIM, IDX_N_HEADS, QR_MM_T_PAD, ROPE_HEAD_DIM, T_DYN, T_PAD

@pl.jit.inline(auto_scope=False)
def idx_vector(x: pl.Tensor[[T_DYN, D], pl.BF16], qr_scale: pl.Tensor[[T_DYN, 1], pl.FP32], wq_b_scale: pl.Tensor[[IDX_N_HEADS * IDX_HEAD_DIM], pl.FP32], cos: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], sin: pl.Tensor[[T_DYN, ROPE_HEAD_DIM], pl.FP32], qr_acc_pad: pl.Tensor[[QR_MM_T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], pl.INT32], qr_bf16: pl.InOut[pl.Tensor[[T_PAD, IDX_N_HEADS * IDX_HEAD_DIM], pl.BF16]], worker: pl.Scalar[pl.INDEX]):
    bs = pl.tensor.dim(x, 0)
    dq_rope_units = (bs + DEQUANT_T_TILE - 1) // DEQUANT_T_TILE * (IDX_N_HEADS // DQ_ROPE_H_TILE)
    dq_rope_workers = pl.min(dq_rope_units, DQ_ROPE_WORKERS)
    if worker < dq_rope_workers:
        sw_ones = pl.full([DEQUANT_T_TILE, ROPE_HEAD_DIM], dtype=pl.FP32, value=1.0)
        sw_index = pl.cast(pl.arange(0, [1, ROPE_HEAD_DIM], dtype=pl.INT32), target_type=pl.FP32)
        sw_col = pl.col_expand_mul(sw_ones, sw_index)
        sw_dup_f = pl.cast(pl.cast(pl.mul(sw_col, 0.5), target_type=pl.INT32, mode='trunc'), target_type=pl.FP32)
        sw_lane = pl.sub(sw_col, pl.mul(sw_dup_f, 2.0))
        rope_swap_idx = pl.cast(pl.sub(pl.add(sw_col, 1.0), pl.mul(sw_lane, 2.0)), target_type=pl.INT32)
        for dq_unit in pl.range(worker, dq_rope_units, dq_rope_workers):
            hg = dq_unit % (IDX_N_HEADS // DQ_ROPE_H_TILE) * DQ_ROPE_H_TILE
            dq_t0 = dq_unit // (IDX_N_HEADS // DQ_ROPE_H_TILE) * DEQUANT_T_TILE
            if dq_t0 + DEQUANT_T_TILE <= bs:
                qr_scale_tile = qr_scale[dq_t0:dq_t0 + DEQUANT_T_TILE, :]
                cos_tile = cos[dq_t0:dq_t0 + DEQUANT_T_TILE, 0:ROPE_HEAD_DIM]
                sin_tile = sin[dq_t0:dq_t0 + DEQUANT_T_TILE, 0:ROPE_HEAD_DIM]
                for h_inner in pl.pipeline(DQ_ROPE_H_TILE, stage=2):
                    h0 = (hg + h_inner) * IDX_HEAD_DIM
                    wq_scale = pl.reshape(wq_b_scale[h0:h0 + IDX_HEAD_DIM], [1, IDX_HEAD_DIM])
                    acc_fp32 = pl.cast(qr_acc_pad[dq_t0:dq_t0 + DEQUANT_T_TILE, h0:h0 + IDX_HEAD_DIM], target_type=pl.FP32, mode='none')
                    qr_dequant_scale = pl.col_expand_mul(pl.row_expand_mul(pl.full([DEQUANT_T_TILE, IDX_HEAD_DIM], dtype=pl.FP32, value=1.0), qr_scale_tile), wq_scale)
                    qr_dequant = pl.mul(acc_fp32, qr_dequant_scale)
                    qr_dequant = pl.cast(pl.cast(qr_dequant, pl.BF16, mode='rint'), pl.FP32)
                    qr_nope_bf16 = pl.cast(qr_dequant[:, 0:IDX_NOPE_HEAD_DIM], target_type=pl.BF16, mode='rint')
                    qr_rope_slice = qr_dequant[:, IDX_NOPE_HEAD_DIM:IDX_HEAD_DIM]
                    qr_swapped = pl.gather(qr_rope_slice, dim=-1, index=rope_swap_idx)
                    rope_rot = pl.add(pl.mul(qr_rope_slice, cos_tile), pl.mul(qr_swapped, sin_tile))
                    rope_bf16 = pl.cast(rope_rot, target_type=pl.BF16, mode='rint')
                    qr_bf16[dq_t0:dq_t0 + DEQUANT_T_TILE, h0:h0 + IDX_NOPE_HEAD_DIM] = qr_nope_bf16
                    qr_bf16[dq_t0:dq_t0 + DEQUANT_T_TILE, h0 + IDX_NOPE_HEAD_DIM:h0 + IDX_HEAD_DIM] = rope_bf16
            else:
                tail_swap_idx = rope_swap_idx[0:1, :]
                for tail_t0 in pl.range(dq_t0, bs):
                    tail_qr_scale_value = pl.read(qr_scale, [tail_t0, 0])
                    tail_cos_tile = cos[tail_t0:tail_t0 + 1, 0:ROPE_HEAD_DIM]
                    tail_sin_tile = sin[tail_t0:tail_t0 + 1, 0:ROPE_HEAD_DIM]
                    for tail_h_inner in pl.pipeline(DQ_ROPE_H_TILE, stage=2):
                        tail_h0 = (hg + tail_h_inner) * IDX_HEAD_DIM
                        tail_wq_scale = pl.reshape(wq_b_scale[tail_h0:tail_h0 + IDX_HEAD_DIM], [1, IDX_HEAD_DIM])
                        tail_acc_fp32 = pl.cast(qr_acc_pad[tail_t0:tail_t0 + 1, tail_h0:tail_h0 + IDX_HEAD_DIM], target_type=pl.FP32, mode='none')
                        tail_qr_dequant_scale = pl.mul(tail_wq_scale, tail_qr_scale_value)
                        tail_qr_dequant = pl.mul(tail_acc_fp32, tail_qr_dequant_scale)
                        tail_qr_dequant = pl.cast(pl.cast(tail_qr_dequant, pl.BF16, mode='rint'), pl.FP32)
                        tail_qr_nope_bf16 = pl.cast(tail_qr_dequant[:, 0:IDX_NOPE_HEAD_DIM], target_type=pl.BF16, mode='rint')
                        tail_qr_rope_slice = tail_qr_dequant[:, IDX_NOPE_HEAD_DIM:IDX_HEAD_DIM]
                        tail_qr_swapped = pl.gather(tail_qr_rope_slice, dim=-1, index=tail_swap_idx)
                        tail_rope_rot = pl.add(pl.mul(tail_qr_rope_slice, tail_cos_tile), pl.mul(tail_qr_swapped, tail_sin_tile))
                        tail_rope_bf16 = pl.cast(tail_rope_rot, target_type=pl.BF16, mode='rint')
                        qr_bf16[tail_t0:tail_t0 + 1, tail_h0:tail_h0 + IDX_NOPE_HEAD_DIM] = tail_qr_nope_bf16
                        qr_bf16[tail_t0:tail_t0 + 1, tail_h0 + IDX_NOPE_HEAD_DIM:tail_h0 + IDX_HEAD_DIM] = tail_rope_bf16
    return qr_bf16
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.decode_indexer import D, IDX_HEAD_DIM, IDX_N_HEADS, QH_MM_TILE, T_DYN, T_PAD

@pl.jit.inline(auto_scope=False)
def had_cube(x: pl.Tensor[[T_DYN, D], pl.BF16], qr_bf16: pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.BF16], hadamard: pl.Tensor[[IDX_HEAD_DIM, IDX_HEAD_DIM], pl.BF16], qh_acc_gm: pl.InOut[pl.Tensor[[QH_ROWS, IDX_HEAD_DIM], pl.FP32]], worker: pl.Scalar[pl.INDEX], HAD_WORKERS: pl.constexpr):
    bs = pl.tensor.dim(x, 0)
    bs_heads = bs * IDX_N_HEADS
    qh_hadamard = hadamard[0:IDX_HEAD_DIM, 0:IDX_HEAD_DIM]
    for idx in pl.range(worker, bs_heads // QH_MM_TILE, HAD_WORKERS):
        o0 = idx * QH_MM_TILE
        qh_acc = pl.matmul(qr_bf16[o0:o0 + QH_MM_TILE, :], qh_hadamard, out_dtype=pl.FP32)
        qh_acc_gm[o0:o0 + QH_MM_TILE, :] = qh_acc
    return qh_acc_gm
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.decode_indexer import D, HADAMARD_SCALE, IDX_HEAD_DIM, IDX_N_HEADS, INT8_AMAX_EPS, INT8_SCALE_MAX, QH_HEAD_DIM_TILE, QH_QUANT_TILE, QH_QUANT_WORKERS, T_DYN, T_PAD

@pl.jit.inline(auto_scope=False)
def had_vector(x: pl.Tensor[[T_DYN, D], pl.BF16], qh_acc_gm: pl.Tensor[[QH_ROWS, IDX_HEAD_DIM], pl.FP32], qr_hadamard_i8: pl.InOut[pl.Tensor[[T_PAD * IDX_N_HEADS, IDX_HEAD_DIM], pl.INT8]], qr_hadamard_scale_dq: pl.InOut[pl.Tensor[[T_PAD * IDX_N_HEADS, 1], pl.FP32]], worker: pl.Scalar[pl.INDEX]):
    bs = pl.tensor.dim(x, 0)
    bs_heads = bs * IDX_N_HEADS
    for idx in pl.range(worker, bs_heads // QH_QUANT_TILE, QH_QUANT_WORKERS):
        o0 = idx * QH_QUANT_TILE
        qh_full_f32 = qh_acc_gm[o0:o0 + QH_QUANT_TILE, 0:IDX_HEAD_DIM]
        qh_full_f32 = pl.cast(pl.cast(qh_full_f32, pl.BF16, mode='rint'), pl.FP32)
        qh_full_f32 = pl.cast(pl.cast(pl.mul(qh_full_f32, HADAMARD_SCALE), pl.BF16, mode='rint'), pl.FP32)
        qh_amax = pl.full([1, QH_QUANT_TILE], dtype=pl.FP32, value=INT8_AMAX_EPS)
        for h0 in pl.range(0, IDX_HEAD_DIM, QH_HEAD_DIM_TILE):
            qh_a_f32 = qh_full_f32[:, h0:h0 + QH_HEAD_DIM_TILE]
            qh_a_neg = pl.neg(qh_a_f32)
            qh_a_abs = pl.maximum(qh_a_f32, qh_a_neg)
            qh_a_max_col = pl.row_max(qh_a_abs)
            qh_a_max = pl.reshape(qh_a_max_col, [1, QH_QUANT_TILE])
            qh_amax = pl.maximum(qh_amax, qh_a_max)
        qh_scale_numerator = pl.full([1, QH_QUANT_TILE], dtype=pl.FP32, value=INT8_SCALE_MAX)
        qh_scale_quant_row = pl.div(qh_scale_numerator, qh_amax)
        qh_scale_recip = pl.recip(qh_scale_quant_row)
        qh_scale_dq = pl.reshape(qh_scale_recip, [QH_QUANT_TILE, 1])
        qr_hadamard_scale_dq[o0:o0 + QH_QUANT_TILE, :] = pl.cast(pl.cast(qh_scale_dq, pl.FP16, mode='rint'), pl.FP32)
        qh_scale_quant = pl.reshape(qh_scale_quant_row, [QH_QUANT_TILE, 1])
        qh_q_scaled = pl.row_expand_mul(qh_full_f32, qh_scale_quant)
        qh_q_i32 = pl.cast(qh_q_scaled, target_type=pl.INT32, mode='rint')
        qh_q_half = pl.cast(qh_q_i32, target_type=pl.FP16, mode='round')
        qh_i8 = pl.cast(qh_q_half, target_type=pl.INT8, mode='trunc')
        qr_hadamard_i8[o0:o0 + QH_QUANT_TILE, 0:IDX_HEAD_DIM] = qh_i8
    return (qr_hadamard_i8, qr_hadamard_scale_dq)
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.q_projection import H, HEAD_DIM, QPROJ_MM_N_TILE, QPROJ_MM_T_DYN, QPROJ_M_TILE, QPROJ_N_BLOCKS, QPROJ_TAIL_M_TILE, QPROJ_T_PAD, QUANT_WEIGHT_LAYOUT, Q_LORA
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.qkv_proj_rope import EPS, H, HEAD_DIM, NOPE_DIM, QPROJ_MM_T_DYN, QPROJ_T_PAD, Q_DEQUANT_WORKERS, Q_ROPE_H_TILE, Q_ROPE_T_TILE, ROPE_DIM, ROPE_DIM_SCALE, T_DYN
