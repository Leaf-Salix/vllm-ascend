from pathlib import Path
import hashlib,json,runpy,sys
here=Path(__file__).resolve().parent
assert all(hashlib.sha256((here/k).read_bytes()).hexdigest()==v for k,v in json.loads((here/'manifest.json').read_text()).items())
parent=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/nal-sdk-alignment-20261026-codex/indexer-pipeline-v6')
assert hashlib.sha256((parent/'probe_perf.py').read_bytes()).hexdigest()=='f64e84dfbf10454de5d909b807c2ee15aa7c2d16ee05c142ce63082f0a386b4e'
sys.path.insert(0,str(parent))
runpy.run_path(str(parent/'sdk_bind.py'),run_name='__sdk_preflight__')
source=(here/'derived_probe.py').read_text()
assert hashlib.sha256(source.encode()).hexdigest()=='0474ef3ddfe5ddfebf1d16af309d9a4e507c34f8fe4c25b961a24bd926907469'
exec(compile(source,str(parent/'probe_perf.py'),'exec'),{'__name__':'__main__','__file__':str(parent/'probe_perf.py'),'PARENT_SHA':'f64e84dfbf10454de5d909b807c2ee15aa7c2d16ee05c142ce63082f0a386b4e','DERIVED_SHA':'0474ef3ddfe5ddfebf1d16af309d9a4e507c34f8fe4c25b961a24bd926907469'})
