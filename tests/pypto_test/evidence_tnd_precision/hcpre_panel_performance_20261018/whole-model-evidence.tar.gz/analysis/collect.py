"""Collect only explicit files from this completed run, never model/cache payloads."""
from pathlib import Path
import hashlib
import json
import tarfile

base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
job=base/'precision-perf-20261018/whole-v1'
root=Path('/data/pyptouser/yejia/lc128/perf-hcpanel-8k-pto-20261018')
config=json.loads((root/'configuration.json').read_text())
gold=Path(config['gold'])
files={}
for name in ('configuration.json','launch.log'):
    files['results/'+name]=root/name
for rank in range(16):
    for name in (f'rank{rank}.real_perf.json',f'rank{rank}.log',f'rank{rank}.capacity.json',f'request_stats_rank{rank}.jsonl'):
        files['results/'+name]=root/name
    for name in (f'rank{rank}.mixed.json',f'request_stats_rank{rank}.jsonl'):
        files['gold/'+name]=gold/name
for name,digest in json.loads((job/'helper-manifest.json').read_text())['files'].items():
    path=job/name
    assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
    files['helpers/'+name]=path
for name in ('helper-manifest.json','qualified-result.json','prepare-snapshot.log','preflight-failed-bank-path.log','preflight.log','snapshot/manifest.json','reference/mixed8k_cases.json','patch/hc_pre.py','patch/hc_pre_panel.py'):
    files['helpers/'+name]=job/name
for name in ('analyze.py','candidate-math.json','collect.py'):
    files['analysis/'+name]=Path(__file__).parent/name
index={name:{'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size} for name,path in files.items()}
archive=job/'whole-model-evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for name,path in files.items():t.add(path,arcname=name,recursive=False)
result={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'files':index}
(job/'whole-model-index.json').write_text(json.dumps(result,indent=2)+'\n')
print('COLLECTED',len(files),result['archive_bytes'])
