"""Build a private source snapshot; never edit the frozen source tree."""
import hashlib
import json
from pathlib import Path
import shutil

job=Path(__file__).resolve().parent
base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/full-dsl-single-entry-20261018/single-v1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(base/'manifest.json')=='7b0650b926a557241b622eba4f032731e7b21d75d807c3b6baccfe689b29c960'
manifest=json.loads((base/'manifest.json').read_text())
changes=json.loads((job/'candidate-math.json').read_text())
snapshot=job/'snapshot'
snapshot.mkdir()
shutil.copytree(base/'source',snapshot/'source',symlinks=True)
for name,digest in changes.items():
    patch=job/'patch'/Path(name).name
    assert sha(patch)==digest
    target=snapshot/'source'/name
    assert not target.is_symlink()
    shutil.copyfile(patch,target)
    manifest['files'][name]=digest
manifest['candidate_base_git']='c87e278e55cea4becd627f174bd5e3a382e9d895'
manifest['candidate_patch_sha256']=changes
(snapshot/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PRIVATE_SNAPSHOT_READY',str(snapshot),len(manifest['files']))
