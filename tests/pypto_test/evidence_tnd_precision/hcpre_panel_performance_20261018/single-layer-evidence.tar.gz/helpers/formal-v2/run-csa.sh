#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
source /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-perf-20261018/staged-v2/env.sh
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
out="$job/csa-results/${1:?}"
mkdir -p "$job/csa-results"
mkdir "$out"
ccache -s > "$out/ccache.log"
export ASCEND_CACHE_PATH="$out/ascend-cache" ASCEND_PROCESS_LOG_PATH="$out/ascend"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
python "$job/preflight.py" > "$out/preflight.log" 2>&1
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out/opp_env")
export VLLM_CACHE_ROOT="$out/vllm-cache"
python "$job/probe_csa.py" --out "$out/data" --lengths "${2:?}" --layer "${3:-4}" --history "${4:-8191}" > "$out/run.log" 2>&1
