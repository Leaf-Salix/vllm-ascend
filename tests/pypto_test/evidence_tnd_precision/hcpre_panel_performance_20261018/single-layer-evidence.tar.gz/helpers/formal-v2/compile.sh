#!/usr/bin/env bash
set -euo pipefail
source /data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-perf-20261018/staged-v2/env.sh
export ASCEND_RT_VISIBLE_DEVICES="" TORCH_DEVICE_BACKEND_AUTOLOAD=0
ccache -s
python "$job/compile.py"
