from pathlib import Path
from pypto.runtime import RunConfig
from staged_csa import decode_csa_tp1_layer_test
f=decode_csa_tp1_layer_test
print('ABI',len(f.param_names),flush=True)
p=f.compile(config=RunConfig(platform='a2a3'))
print('ADAPTIVE_ROOT_COMPILE_OK',p.output_dir,flush=True)
Path(__file__).with_name('compiled-root.txt').write_text(str(p.output_dir)+'\n')
