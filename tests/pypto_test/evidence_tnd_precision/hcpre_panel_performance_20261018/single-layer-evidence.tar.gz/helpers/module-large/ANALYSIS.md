# 保持TND逐bit精度的性能优化分析（2026-10-18）

## 比较身份

- 已冻结精度：Leaf-Salix `c87e278e55cea4becd627f174bd5e3a382e9d895`，数学`a20bcdb76`。
- nalinaly最新只读远端引用：`a919f11942d93627441c8fa694e310dcbd1c671b`；没有切换本地生产分支。
- 修改仅在独立实验目录，未改冻结生产、SDK或静态包；227使用原验收Python与工具链。

## 其性能来自哪些做法

| 位置 | nalinaly的具体实现 | 能否直接用于当前逐bit精度版 |
| --- | --- | --- |
| CSA内HC-pre投影 | `hc_pre.py`：T16、K256，4×4096分片，`pl.pipeline(stage=2)`与Cube matmul | 不能直接照搬；当前Native已验证为22×768分片（末段256）、HF32且每8积一次舍入。更换分片与乘加边界会破坏精度 |
| HC-pre输入预处理 | `decode_csa.py::hc_widen_rms`：在BF16→FP32搬运时顺便算RMS，K方向stage4流水，避免重复读GM；提前派发 | 融合搬运可借鉴，RMS的512块row_sum/rsqrt不能替代当前Native Gram统计和sqrt/div边界 |
| Indexer score | 请求内多query共享Key；N128面板、双缓冲、Key与Score的L1独立存活区；AIC/AIV ready/consumed事件；长序列平衡leaf | 是后续方向，但不能依赖固定S6分组，也不能改变Native量化/score归约/TopK并列顺序；当前8K整模型大回退尚未模块归因，不先认定它是主要瓶颈 |
| orchestration | 单根融合、独立scratch scope、早派发，减少中间GM与task同步 | 当前已保留单根和scope；继续调整必须验证生命周期及依赖，不把scope退出误作硬件barrier |
| 独立HC-pre | `vllm_ascend/ops/pypto/hc_pre.py`的T分档、双缓冲及48核分工 | 与CSA包内HC-pre不同入口，不能将其27～40us数字套用到整CSA或逐bit版本 |
| 最新单SPMD原型 | `a919f1194`新增实验和核间同步修复/128K对照材料 | commit/实验存在不等于已成为CSA生产默认或有稳定收益，不能据此直接合入 |

## 本轮单因素

先处理HC-pre精确乘加里明显的逐token重复搬运：把独立token行合为8行向量；每份weight用于8行；输入预转置后连续读取8token。
不改HF32权重转换、8个乘积、精确和185条舍入/修正语句、22分片和最终分片和序列。
这是根据上述块搬运/复用思路独立实现，尚不代表已取得收益；转换和更大临时量可能抵消计算收益。

### 已遇到的静态限制

- 两行方案的2×1列载体不满足32字节分配约束，未提交硬件。
- 标准fillpad后transpose在当前SDK生成的pad类型不一致；不用改SDK，改显式尾行初始化。
- 普通transpose会生成RowMajor 8×1非法4字节行宽；改成同一对齐缓冲区的transpose_view。

### 门禁

模块筛选：真实L4权重，T1/3/21先行，完整partials（含padding）、三输出逐bitNative、A/B/A/zero、NaN replay恢复、guard/权重/输入不变；精度通过才同卡正反交错8轮×10次raw graph计时。
模块Native是直接Native HC-pre raw graph，不能冒充服务13包static资格FULL图；模块有效才接入完整CSA，使用原验收bootstrap再次对拍。
每项NPU任务max780秒，首次不一致停止。未重新安装任何包。
