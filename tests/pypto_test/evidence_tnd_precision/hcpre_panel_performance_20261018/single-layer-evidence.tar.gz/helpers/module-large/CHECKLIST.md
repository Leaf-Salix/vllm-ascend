# TND精度保持性能优化（2026-10-18）

- [x] 固定精度黄金c87e278e5；原生产源码/运行树保持，实验使用独立目录。
- [x] 更新nalinaly参考引用a919f1194，区分CSA与独立HC-pre。
- [ ] 对照源码：不得改变HF32转换、每8积舍入、22分片和归约序列。
- [ ] HC-pre连续token共享Key/weight panel，先无设备编译。
- [ ] 同卡串行baseline/candidate/native模块精度和graph计时；短/尾/混合T；首差停止。
- [ ] 模块有效才完整CSA FULL graph byte-exact与延迟，独立审查。
- [ ] 只保留精度不退且稳定有效改动；记录无收益或失败，不重装SDK。
- [ ] 所有NPU task max780秒；每5分钟内监控；不创建sche。

初始研究：nal CSA使用分块matmul+pipeline，舍入/分片不同不能直搬。先只改HC-pre独立行向量搬运/批处理，逐元素算术图保持。总回退尚无模块profile，不预设HC-pre贡献比例。
