from pathlib import Path
import json
from pypto.runtime import RunConfig
from pypto.runtime.kernel_compiler import KernelCompiler
from candidate_hc import hcpre_linear_test,hc_pre_test
job=Path(__file__).parent
isa='/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/experiments/nalinaly-71153bb3/pypto-reference/runtime/build/pto-isa'
results=[]
for name,f in [('linear',hcpre_linear_test),('hcpre',hc_pre_test)]:
 p=f.compile(config=RunConfig(platform='a2a3'))
 print('NORM_DSL_GENERATE',name,p.output_dir,flush=True)
 files=[q for q in Path(p.output_dir).rglob('*.cpp') if q.parent.name=='aiv']
 assert files,(name,p.output_dir)
 out=job/('precompile-'+name);out.mkdir(exist_ok=True)
 for q in files:
  b=KernelCompiler('a2a3').compile_incore(str(q),core_type='aiv',pto_isa_root=isa,runtime_name='tensormap_and_ringbuffer',build_dir=str(out))
  (out/(q.stem+'.elf')).write_bytes(b)
  print('NORM_DSL_CCEC_OK',q.name,len(b),flush=True)
 results.append({'name':name,'output_dir':str(p.output_dir),'kernels':len(files)})
(job/'compile-result.json').write_text(json.dumps(results,indent=2)+'\n')
