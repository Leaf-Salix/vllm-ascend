"""复算归档计时、交错顺序和硬件收据；不独立重跑张量计算。"""

import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
rows = []
for path in sorted(ROOT.glob("evidence-*/result.json")):
    result = json.loads(path.read_text())
    assert result["complete"] and result["pass"]
    assert result["accuracy_executed"]
    performance = result["performance"]
    summary = performance["summary"]
    assert performance["dep_gen"] is False
    assert performance["replays_per_event_window"] == 100
    for index, window in enumerate(performance["event_windows"]):
        repeat = index // 2
        expected_order = ["frozen", "fused"] if repeat % 2 == 0 else ["fused", "frozen"]
        assert window["repeat"] == repeat and window["order"] == expected_order
        assert window["arm"] == expected_order[index % 2]
    assert len(performance["event_windows"]) == 24
    for arm in ("frozen", "fused"):
        event = [v["us"] for v in performance["event_windows"] if v["arm"] == arm]
        l1 = [v["us"] for v in performance["l1_windows"] if v["arm"] == arm]
        assert len(event) == 12 and len(l1) == 5
        assert event == summary[arm]["event_us"] and l1 == summary[arm]["l1_us"]
        assert statistics.median(event) == summary[arm]["event_median_us"]
        assert statistics.median(l1) == summary[arm]["l1_median_us"]
        for phase in ("comparisons", "B_comparisons"):
            boundaries = result[phase][arm]
            assert len(boundaries) == 8
            assert all(v["bit_equal"] and v["different_elements"] == 0 for v in boundaries.values())
    frozen, fused = (summary[a]["event_median_us"] for a in ("frozen", "fused"))
    decrease = 1 - fused / frozen
    wins = sum(a < b for a, b in zip(summary["fused"]["event_us"], summary["frozen"]["event_us"], strict=True))
    assert math.isclose(decrease, summary["fused"]["event_improvement"], abs_tol=1e-14)
    assert wins == summary["fused"]["paired_event_wins"]
    assert all(v["pass"] for v in result["execution_checks"])
    assert all(result["graphs"][a]["live_input_ABA"] for a in ("native", "frozen", "fused"))
    rows.append({"case": path.parent.name.removeprefix("evidence-"),
                 "true_tokens": result["true_tokens"], "history": result["history"],
                 "frozen_event_us": frozen, "fused_event_us": fused,
                 "event_decrease_percent": decrease * 100, "paired_wins": wins,
                 "native_A_B_eight_bit_equal": True, "ABA": True,
                 "actual_capture_order": result.get("actual_capture_order", ["native", "frozen", "fused"]),
                 "result_sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
report = {"pass": True, "scope": "CPU arithmetic/order and hardware receipt consistency, not independent raw tensor rerun", "cases": rows}
(ROOT / "RECHECK.json").write_text(json.dumps(report, indent=2) + "\n")
for row in rows:
    print(row["case"], f'{row["event_decrease_percent"]:.3f}%', row["paired_wins"], "/12", "Native A/B bit exact")
