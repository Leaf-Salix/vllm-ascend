#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
label=${1:?}; batch=${2:?}; history=${3:?}; explicit_lengths=${4:?}
[[ "$label" =~ ^[a-z0-9-]+$ && "$batch" =~ ^[0-9]+$ && "$history" =~ ^[0-9]+$ ]]
[[ "$explicit_lengths" =~ ^[1-6](,[1-6])*$ ]]
tw_job_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$tw_job_root/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
out="$tw_job_root/results/$label"
test ! -e "$out"
mkdir -p "$tw_job_root/results"
export PREFLIGHT_RECEIPT="$out-preflight.json"
export ASCEND_CACHE_PATH="$out-ascend-cache" ASCEND_PROCESS_LOG_PATH="$out-ascend-log" VLLM_CACHE_ROOT="$out-vllm-cache"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out-opp-env")
lengths="$explicit_lengths"
IFS=',' read -r -a fusion_lengths <<< "$lengths"
[[ "${#fusion_lengths[@]}" == "$batch" ]]
ccache -s > "$out-ccache.txt"
printf 'TASK_RUN_START %s\n' "$(date -Iseconds)"
trap 'printf "TASK_RUN_END %s\n" "$(date -Iseconds)"' EXIT
timeout --signal=TERM --kill-after=15s 750s python "$tw_job_root/device.py" --out "$out" --lengths "$lengths" --layer 4 --history "$history" > "$out-run.log" 2>&1
