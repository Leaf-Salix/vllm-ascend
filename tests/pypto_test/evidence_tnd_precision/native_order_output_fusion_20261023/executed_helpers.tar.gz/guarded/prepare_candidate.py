"""仅派生独立输出融合模块；默认算子和原验收资产不变。"""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[1]
REPO = WORKSPACE / 'vllm-ascend-nalinaly-tnd-20261008-codex'
OPS = REPO / 'vllm_ascend/ops/pypto'
root_path = OPS / 'deepseek_v4_flash_csa_tnd_precision_spmd_overlap/decode_csa.py'
oproj_path = OPS / 'deepseek_v4_flash_csa_tnd_full_precision/o_proj.py'
original = oproj_path.read_text()
marker = '    for block in pl.spmd(row_tiles * 8, name_hint="oproj_b_dequant"):'
assert original.count(marker) == 1
prefix = original[:original.index(marker)]
prefix = prefix.replace('def _o_proj_test(', 'def _o_proj_hcpost(')
prefix = prefix.replace('    output: pl.Out[pl.Tensor[[T, 4096], pl.BF16]],', '''    residual: pl.Tensor[[T, 4, 4096], pl.BF16],
    post: pl.Tensor[[T, 4], pl.FP32],
    comb: pl.Tensor[[T, 16], pl.FP32],
    output: pl.Out[pl.Tensor[[T, 4, 4096], pl.BF16]],''')
prefix = prefix.replace('    output.bind_dynamic(0, T)', '''    residual.bind_dynamic(0, T)
    post.bind_dynamic(0, T)
    comb.bind_dynamic(0, T)
    output.bind_dynamic(0, T)''')
prefix = prefix.replace('import pypto.language as pl', '''import pypto.language as pl
from ..deepseek_v4_flash_csa_tnd_precision.hc_post import hc_post_block''')
prefix = prefix.replace('"""Native WO-A BF16 → 整行量化 → INT32 WO-B → 通道/行 scale → BF16。"""',
    '"""借鉴nalinaly输出融合编排，保留我方Native数值体；独立诊断候选。"""')
suffix = '''    residual_flat = pl.reshape(residual, [rows, 16384])
    output_flat = pl.reshape(output, [rows, 16384])
    # Match Native channel*token scale and the attended BF16 publication.
    # Fusion only removes the attended GM store/reload and task handoff.
    for token_block in pl.spmd((rows + 3) // 4, name_hint="oproj_dequant_hcpost"):
        first = token_block * 4
        for row in pl.pipeline(first, first + 4, stage=2):
            if row < rows:
                ob_integer = pl.load(integer_accum, [row, 0], [1, 4096])
                channel = pl.reshape(pl.load(wo_b_scale, [0], [4096]), [1, 4096])
                scale = pl.read(token_scale, [row, 0])
                coefficient_one = pl.tile.full([1, 4096], dtype=pl.FP32, value=1.0)
                coefficient_channel = pl.col_expand_mul(coefficient_one, channel)
                coefficient = pl.mul(coefficient_channel, scale)
                ob_scaled = pl.mul(pl.cast(ob_integer, pl.FP32), coefficient)
                attended_bf16 = pl.cast(ob_scaled, pl.BF16, mode="rint")
                output_flat = hc_post_block(attended_bf16, residual_flat, post, comb,
                    output_flat, row, 0, 1, 1, 4096)
    return output


o_proj_hcpost_entry = pl.jit.inline(auto_scope=False)(_o_proj_hcpost)
o_proj_hcpost_test = pl.jit(_o_proj_hcpost)
'''
# Expand the unchanged DSL helper body because this SDK cannot infer a Tile
# argument passed directly from pl.cast into the generic inline helper.
hc_path = REPO / 'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision/hc_post.py'
hc_func = next(n for n in ast.parse(hc_path.read_text()).body
               if isinstance(n, ast.FunctionDef) and n.name == 'hc_post_block')
class HCArguments(ast.NodeTransformer):
    def visit_Call(self, node):
        node = self.generic_visit(node)
        if (isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name)
                and node.func.value.id == 'pl' and node.func.attr == 'slice'
                and isinstance(node.args[0], ast.Name) and node.args[0].id == 'residual_flat'):
            node.func.attr = 'load'
            node.args = [node.args[0], node.args[2], node.args[1]]
            node.keywords = [kw for kw in node.keywords if kw.arg != 'clamp']
        return node
    def visit_Assign(self, node):
        node = self.generic_visit(node)
        if len(node.targets) == 1 and isinstance(node.targets[0], ast.Subscript):
            return ast.copy_location(ast.Expr(value=ast.Call(
                func=ast.Attribute(value=ast.Name(id='pl', ctx=ast.Load()), attr='store', ctx=ast.Load()),
                args=[node.value, ast.List(elts=[ast.Name(id='row', ctx=ast.Load()),
                      ast.BinOp(left=ast.Name(id='out_h', ctx=ast.Load()), op=ast.Mult(), right=ast.Constant(4096))], ctx=ast.Load()),
                      ast.Name(id='output_flat', ctx=ast.Load())], keywords=[])), node)
        return node
    def visit_Name(self, node):
        replacements = {'x_block': 'attended_bf16', 'y_flat': 'output_flat', 't0': 'row'}
        constants = {'n0': 0, 'valid_rows': 1, 'ROWS': 1, 'COLS': 4096, 'D': 4096, 'HC_MULT': 4}
        if node.id in replacements:
            return ast.copy_location(ast.Name(id=replacements[node.id], ctx=node.ctx), node)
        if node.id in constants:
            return ast.copy_location(ast.Constant(constants[node.id]), node)
        return node
hc_body = [HCArguments().visit(node) for node in hc_func.body if not isinstance(node, ast.Return)]
hc_lines = '\n'.join(ast.unparse(ast.fix_missing_locations(node)) for node in hc_body)
hc_inline = '\n'.join('                ' + line for line in hc_lines.splitlines())
old_helper_call = "                output_flat = hc_post_block(attended_bf16, residual_flat, post, comb,\n                    output_flat, row, 0, 1, 1, 4096)"
assert suffix.count(old_helper_call) == 1
suffix = suffix.replace(old_helper_call, hc_inline)
prefix = prefix.replace('from ..deepseek_v4_flash_csa_tnd_precision.hc_post import hc_post_block\n', '')
new_oproj = prefix + suffix
root = root_path.read_text()
root = root.replace('from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.hc_post import hc_post_entry\n', '')
root = root.replace('from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.o_proj import o_proj_entry',
    'from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_full_precision.nal_fused_oproj import o_proj_hcpost_entry')
old_call = '''    with pl.scope():
        _oproj_result = o_proj_entry(
            heads, wo_a, wo_b, wo_b_scale, oproj_start, projected_o, quantized_o, scale_o, attention_out
        )
    with pl.scope():
        _hc_post_result = hc_post_entry(attention_out, x_hc, post, comb, x_out)'''
assert root.count(old_call) == 1
root = root.replace(old_call, '''    with pl.scope():
        _fused_result = o_proj_hcpost_entry(
            heads, wo_a, wo_b, wo_b_scale, oproj_start, projected_o, quantized_o, scale_o,
            x_hc, post, comb, x_out
        )''')
assert root.count('    attention_out = pl.create_tensor([tokens, D], dtype=pl.BF16)') == 1
root = root.replace('    attention_out = pl.create_tensor([tokens, D], dtype=pl.BF16)\n', '')
for name, code in (('nal_fused_oproj.py', new_oproj), ('nal_fused_root.py', root)):
    ast.parse(code)
    (HERE / name).write_text(code)

# Apart from new arguments/bindings, every WO-A/quant/INT32 WO-B AST node is identical.
old_func = next(n for n in ast.parse(original).body if isinstance(n, ast.FunctionDef))
new_func = next(n for n in ast.parse(new_oproj).body if isinstance(n, ast.FunctionDef))
old_prefix = old_func.body[:-2]
new_prefix = new_func.body[:len(old_prefix) + 3]
new_prefix = [n for n in new_prefix if not (
    isinstance(n, ast.Expr) and isinstance(n.value, ast.Call)
    and isinstance(n.value.func, ast.Attribute) and isinstance(n.value.func.value, ast.Name)
    and n.value.func.attr == 'bind_dynamic' and n.value.func.value.id in ('residual', 'post', 'comb'))]
assert len(old_prefix) == len(new_prefix)
assert all(ast.dump(a) == ast.dump(b) for a, b in zip(old_prefix, new_prefix, strict=True))
proof = {'baseline_commit': '6eabea0ec89313d6ab020ef7f94eb2b85a689fc8',
    'checkpoint_commit': '397941659ec0ee939f429a5899fe5cbd382f86db',
    'nal_reference': '67134f28bdbd9881b14c4d91f0e27092d88f6501 combined_v1 output fusion',
    'baseline': {key: {'file': str(path.relative_to(REPO)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                 for key, path in (('root', root_path), ('oproj', oproj_path))},
    'candidates': {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
                   for name in ('nal_fused_oproj.py', 'nal_fused_root.py')},
    'woa_quant_wob_prefix_ast_equal': True,
    'changed_math': False, 'hardware_precision_validated': False,
    'dynamic_t': True, 'root_tensor_args_expected': 64}
(HERE / 'SOURCE.json').write_text(json.dumps(proof, indent=2) + '\n')
print('Generated isolated candidates; WO-A/quant/WO-B prefix AST exact')
