"""捕获前按真实Tensor总行数选一个完整PTO入口；不改变请求布局。"""
def select_attention(tokens, original, fused):
    assert 0 < tokens <= 256
    return original if tokens <= 16 else fused
