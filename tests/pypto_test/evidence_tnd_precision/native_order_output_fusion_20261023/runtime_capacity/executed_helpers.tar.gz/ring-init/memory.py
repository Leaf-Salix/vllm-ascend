"""Measure existing runtime init residency only; no model or arithmetic kernel."""
from pathlib import Path
import hashlib
import json
import os
import runpy
import sys
ROOT=Path(__file__).resolve().parent
mode=sys.argv[1];out=Path(sys.argv[2]);assert mode in ('default','small') and not out.exists()
base=ROOT.parent
runpy.run_path(str(base/'sdk_bind.py'),run_name='__ring_sdk__')
runpy.run_path(str(base/'whole/runtime_bridge.py'),run_name='__ring_compat__')
import torch
import torch_npu
import pypto.torch
assert not torch_npu.npu.is_initialized()
torch.npu.set_device(0)
torch.npu.synchronize();torch.npu.empty_cache()
free,total=torch.npu.mem_get_info()
allocated=torch.npu.memory_allocated();reserved=torch.npu.memory_reserved()
kwargs={} if mode=='default' else {'ring_heap':tuple(m*1024**2 for m in (56,96,176,1)),'ring_task_window':2048}
pypto.torch.init(**kwargs)
torch.npu.synchronize()
after,total_after=torch.npu.mem_get_info()
record={'pass':True,'scope':'runtime init residency only; not operator heap/task-window or model precision qualification','memory_py_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'run_sh_sha256':hashlib.sha256((ROOT/'run.sh').read_bytes()).hexdigest(),'mode':mode,'init_kwargs':kwargs,'task_device':os.environ['TASK_DEVICE'],'device':torch.npu.current_device(),'total_bytes':total,'free_before':free,'free_after':after,'runtime_resident_delta_bytes':free-after,'torch_allocated_before':allocated,'torch_allocated_after':torch.npu.memory_allocated(),'torch_reserved_before':reserved,'torch_reserved_after':torch.npu.memory_reserved(),'sdk':json.loads(Path(os.environ['PREFLIGHT_RECEIPT']).read_text())}
assert total==total_after and record['runtime_resident_delta_bytes']>64*1024**2
assert record['torch_allocated_after']==allocated
out.write_text(json.dumps(record,indent=2)+'\n')
print('RING_INIT_RESIDENCY',mode,record['runtime_resident_delta_bytes'],flush=True)
