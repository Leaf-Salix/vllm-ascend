#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?single card task required}"
ring_init_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
label=${1:?}
[[ "$label" =~ ^[a-z0-9-]+$ ]]
source "$ring_init_root/../env.sh"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE"
out="$ring_init_root/results/$label"
mkdir -p "$ring_init_root/results"
mkdir "$out"
for mode in default small; do
 export PREFLIGHT_RECEIPT="$out/sdk-$mode.json"
 timeout --signal=TERM --kill-after=10s 120s python "$ring_init_root/memory.py" "$mode" "$out/$mode.json" > "$out/$mode.log" 2>&1
done
