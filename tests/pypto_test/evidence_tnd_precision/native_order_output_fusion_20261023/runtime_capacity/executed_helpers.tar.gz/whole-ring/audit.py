"""CPU复核16rank真实192token及实际融合root捕获资格；不触碰NPU。"""
from pathlib import Path
import hashlib
import json
import statistics
import sys
out=Path(sys.argv[1]);configuration=json.loads((out/'configuration.json').read_text())
assert configuration['pass'] and configuration['native_source_equal']
gold=Path(configuration['gold']);batch=configuration['batch'];bucket=240 if batch==40 else 144
report={'audit_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'routing_audit':'phase v2: captured PTO roots plus unchanged Native counts across measured round; aggregate profile counters are retained', 'pass':False,'batch':batch,'decode_tokens':192,'complete':False,'ranks':[],'tokens_compared':0,'no_profiler':True,'reused_native_gold':str(gold)}
for rank in range(16):
 f=out/f'rank{rank}.real_perf.json';raw=json.loads(f.read_text());native=json.loads((gold/f'rank{rank}.mixed.json').read_text())
 expected_tokens={q['key']:q['output_token_ids'] for q in native['requests']}
 expected_events={q['key']:q['events'] for q in map(json.loads,(gold/f'request_stats_rank{rank}.jsonl').read_text().splitlines())}
 assert raw['rank']==rank and raw['backend']=='pto' and raw['decode_tokens']==192 and raw['batch']==batch
 assert len(raw['rounds'])==1 and raw['warmup']
 timing=[]
 for cycle in [raw['warmup'],*raw['rounds']]:
  rows=cycle['requests'];assert len(rows)==batch and {q['key'] for q in rows}==set(expected_tokens)
  for q in rows:
   assert q['output_token_ids']==expected_tokens[q['key']] and len(q['output_token_ids'])==192
   assert q['events']==expected_events[q['key']] and q['preemptions']==0
   report['tokens_compared']+=192
 for row in raw['rounds']:
  assert len(row['timing'])==1
  assert len(row['identity_before']) == 1
  for measurement in row['timing']:
   before = row['identity_before'][0]
   after = measurement['identity']
   assert before['capture_time_selection'].keys() == after['capture_time_selection'].keys()
   assert len(before['static_full_qualification']['single_root_counts']) == 21
   for layer, selections in before['capture_time_selection'].items():
    native_before = {k: v for k, v in selections.items() if k.startswith('native_')}
    native_after = {k: v for k, v in after['capture_time_selection'][layer].items() if k.startswith('native_')}
    assert native_before == native_after, ('New Native dispatch during measured generation', rank, layer)
    for tokens in (6, bucket):
     captured_before = before['static_full_qualification']['single_root_counts'][layer][str(tokens)]
     captured_after = after['static_full_qualification']['single_root_counts'][layer][str(tokens)]
     assert captured_before == captured_after
     assert captured_before['capture'] == 1 and captured_before['warmup'] > 0
   assert measurement['sufficient'] and len(measurement['metadata'])==20
   assert all(any(route['actual_full_replay'] for route in q['actual_graph_routes']) for q in measurement['metadata'])
   assert all(q['graph_mode']=='FULL' and q['padded_tokens']==bucket and q['requests']==(40 if batch==40 else 21) for q in measurement['metadata'])
   identity=measurement['identity'];qual=identity['static_full_qualification']
   sizing=qual['runtime_sizing']
   assert len(sizing)==1 and sizing[0]['kwargs']==configuration['runtime_init_kwargs']
   assert qual['root_namespace']=='capture_policy: frozen T<=16 / fused T>16' and qual['root_abi_tensors']==64
   assert qual['ready'] and qual['actual_reselections']==1 and qual['validated_reuses']>0
   assert len(qual['single_root_counts'])==21
   for layer,counts in qual['single_root_counts'].items():
    for tokens in (6,bucket):
     assert counts[str(tokens)]['warmup']>0 and counts[str(tokens)]['capture']>0
     assert counts[str(tokens)]['root_namespace']==('dsv4_csa_tnd_precision_spmd_overlap::attention' if tokens<=16 else 'nal_fused_whole::attention')
    assert identity['capture_time_selection'][layer].get('pto_tokens'+str(bucket),0)>0
    # Native dummy/profile calls precede static qualification and graph capture.
    # Actual root capture plus before/after deltas qualifies replay, not lifetime totals.
   timing.append(measurement)
 report['ranks'].append({'rank':rank,'tokens_equal':True,'events_equal':True,'preemptions':0,'helper_output_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'timing':timing})
report['complete']=report['pass']=True
(out/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
print('WHOLE_FUSION_AUDIT_PASS',batch,report['tokens_compared'],'tokens, 16 ranks, Native tokens/events exact',flush=True)
