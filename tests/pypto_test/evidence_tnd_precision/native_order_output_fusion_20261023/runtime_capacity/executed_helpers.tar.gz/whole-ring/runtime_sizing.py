"""Observe the existing init API; no SDK or runtime implementation changes."""
import functools
import json
import os
from pathlib import Path

EXPECTED = {'ring_heap': tuple(m * 1024**2 for m in (56, 96, 176, 1)), 'ring_task_window': 2048}
records = []


def install():
    import pypto.torch
    import torch
    original = pypto.torch.init
    assert not getattr(original, '_sizing_observed', False)

    @functools.wraps(original)
    def initialize(*args, **kwargs):
        actual = {key: kwargs.get(key) for key in EXPECTED}
        assert actual == EXPECTED, ('Actual init does not receive qualified ring sizes', actual)
        assert not records, 'Unexpected repeated init: inspect before continuing'
        torch.npu.synchronize()
        free, total = torch.npu.mem_get_info()
        result = original(*args, **kwargs)
        torch.npu.synchronize()
        after, total_after = torch.npu.mem_get_info()
        assert total == total_after
        row = {'kwargs': actual, 'device': torch.npu.current_device(), 'task_device': os.environ['TASK_DEVICE'], 'free_before': free, 'free_after': after, 'resident_delta_bytes': free-after, 'total_bytes': total}
        records.append(row)
        target = Path(os.environ['PERF_OUTPUT']) / f'runtime-init-{os.getpid()}.json'
        assert not target.exists()
        target.write_text(json.dumps(row, indent=2) + '\n')
        return result

    initialize._sizing_observed = True
    pypto.torch.init = initialize


def proof():
    assert len(records) == 1
    assert records[0]['kwargs'] == EXPECTED
    return records
