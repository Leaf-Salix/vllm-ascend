#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
case_name=${1:?};backend=${2:?}
export PERF_REPEATS="${PERF_REPEATS:-3}"
case "$PERF_REPEATS" in 1|2|3) ;; *) echo "Invalid PERF_REPEATS" >&2; exit 2;; esac
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
job=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overlap-20261020/whole-overlap-v1
test -f "$job/FINAL_SOURCE_BOUND.json" || { echo "Final V6 source not bound" >&2; exit 2; }
old="$base/low-acceptance-20261010"
case "$case_name" in
 8k) batch=40;blocks=22000;active=40;bucket=240;util=0.95;bank="$old/banks/fixed8192";gold=/data/pyptouser/yejia/lc128/full-pto8k-native-20261016 ;;
 128k) batch=24;blocks=24000;active=21;bucket=144;util=0.97;bank="$base/low-acceptance-128k-b24-20261014/banks/fixed131072";gold=/data/pyptouser/yejia/lc128/retest192-native1-b24000 ;;
 *) exit 2;;
esac
case "$backend" in pto) ;; *) exit 2;; esac
out="/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overlap-20261020/whole-overlap-v1/results/$case_name-$backend"
mkdir -p "$(dirname "$out")"
mkdir "$out"
export PERF_BACKEND="$backend" PERF_CASE="$case_name" PERF_CAPTURE_BUCKET="$bucket"
export PERF_OUTPUT="$out" PERF_GOLD="$gold" PERF_ACTIVE_REQUESTS="$active"
export LOW_ACCEPTANCE_GPU_BLOCKS="$blocks" LOW_ACCEPTANCE_OFFICIAL_CACHE="$old/official-static-cache"
unset LOW_ACCEPTANCE_STATIC_MANIFEST
source "$job/env.sh"
python "$job/source_preflight.py"
python "$job/verify_assets.py"
python "$job/check_bank_$case_name.py"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/realperf.XXXXXX)
trap 'rmdir "$TMPDIR" 2>/dev/null || true' EXIT
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out/opp_env")
export PYPTO_PROG_BUILD_DIR="$out/build" ASCEND_CACHE_PATH="$out/ascend-cache"
export ASCEND_PROCESS_LOG_PATH="$out/ascend" VLLM_CACHE_ROOT="$out/vllm-cache"
mkdir -p "$ASCEND_PROCESS_LOG_PATH" "$ASCEND_CACHE_PATH"
python - "$job" "$out" "$case_name" "$backend" "$batch" "$blocks" "$active" "$bucket" "$util" "$bank" <<'PY'
from pathlib import Path
import hashlib,json,sys,os
job,out,case,backend,batch,blocks,active,bucket,util,bank=sys.argv[1:]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files={p.name:sha(p) for p in Path(job).iterdir() if p.suffix in ('.py','.sh')}
config={'case':case,'backend':backend,'batch':int(batch),'blocks':int(blocks),'active_requests_for_timing':int(active),'capture_sizes':[6,int(bucket)],'utilization':float(util),'bank':bank,'decode_tokens':192,'warmup_tokens':192,'repeats':int(os.environ['PERF_REPEATS']),'warmup_steps':8,'steps':20,'variant':'pkg:deepseek_v4_flash_csa_tnd_precision_spmd_overlap','baseline_git_commit':'c87e278e55cea4becd627f174bd5e3a382e9d895','candidate_math_files':json.loads((Path(job)/'candidate-math.json').read_text()),'source_manifest_sha256':sha(Path(os.environ['SOURCE_ROOT']).parent/'manifest.json'),'runtime_manifest_sha256':sha(os.environ['LOW_ACCEPTANCE_RUNTIME_PACKAGE']+'/manifest.json'),'bank_plan_sha256':sha(Path(bank)/'plan.json'),'helpers_sha256':files,'math_changed':True,'single_pto_entry':True,'handwritten_cpp':False,'profiler':False,'stage_hooks':False,'input_gpu_copy':False,'event_mode':1,'deterministic':True,'eplb':False}
config.update(snapshot=os.environ['SOURCE_ROOT'],snapshot_manifest=str(Path(os.environ['SOURCE_ROOT']).parent/'manifest.json'),static_metadata_sha256=sha(Path(os.environ['LOW_ACCEPTANCE_OFFICIAL_CACHE'])/'metadata.json'),gold=os.environ['PERF_GOLD'],helper_manifest_sha256=sha(Path(job)/'helper-manifest.json'))
(Path(out)/'configuration.json').write_text(json.dumps(config,indent=2)+'\n')
PY
cd "$out"
timeout --signal=TERM --kill-after=20s 750s python "$SOURCE_ROOT/tests/pypto_test/offline_pd/run.py" decode --output "$out" --backend "$backend" \
 --pto-attention csa --mixed-requests --batch "$batch" --decode-dp 16 --max-num-batched-tokens 400 \
 --weight-nz-mode 2 --deterministic --port 30981 --gpu-memory-utilization "$util" --event-work-mode 1 \
 --bank "$bank" --decode-tokens 192 --graph-mode full_decode_only --capture-sizes 6 "$bucket" > "$out/launch.log" 2>&1
