"""Collect successful whole-model evidence without weights or cache tensors."""
import argparse,hashlib,json,re,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('case',choices=('8k','128k'));p.add_argument('--job-name',default='whole-overlap-v1');args=p.parse_args();assert re.fullmatch(r'whole-overlap-[a-z0-9-]+',args.job_name)
base=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
exp=base/'precision-overlap-20261020';job=exp/args.job_name;case=args.case
root=job/f'results/{case}-pto';audit=json.loads((job/f'audit-{case}.json').read_text());assert audit['pass']
assert not list(root.glob('*STOP.json'))
config=json.loads((root/'configuration.json').read_text());paths={}
def add(name,path):
 assert path.is_file(),str(path)
 paths[name]=path
for q in root.iterdir():
 if q.is_file() and (q.name=='configuration.json' or q.name.endswith('.real_perf.json') or q.name in ('rank0.log','launch.log')):add('candidate/'+q.name,q)
for n in ('audit-'+case+'.json','preflight-'+case+'.log'):add(n,job/n)
add('baseline-environment.json',exp/'BASELINE.json');add('source-manifest.json',job/'snapshot/manifest.json')
for n in json.loads((job/'helper-manifest.json').read_text())['files']:add('tools/'+n,job/n)
add('tools/helper-manifest.json',job/'helper-manifest.json')
for n in ('independent8k.py','independent128k.py','audit_identity.py'):add('tools/qualification-audit/'+n,job/'qualification-audit'/n)
add('formal-overlap-compile.json',exp/'compile-full-csa-bf16layout.json')
bound=json.loads((job/'FINAL_SOURCE_BOUND.json').read_text())
for n,digest in bound['single_layer_gate_result_sha256'].items():
 gate=exp/'results'/n/'result.json'
 assert hashlib.sha256(gate.read_bytes()).hexdigest()==digest,n
 add('single-layer/'+n+'.json',gate)
gold=Path(config['gold'])
for rank in range(16):
 add(f'native-gold/rank{rank}.mixed.json',gold/f'rank{rank}.mixed.json')
 add(f'native-gold/request_stats_rank{rank}.jsonl',gold/f'request_stats_rank{rank}.jsonl')
for label,ref in {'native-historical':Path(audit['Native_8k_perf_root'] if case=='8k' else audit['Native_128k_perf_root']),
 'serial-parent':base/f'precision-spmd-20261019/whole-bf16qa126-v2/results/{case}-pto'}.items():
 add(label+'/configuration.json',ref/'configuration.json')
 for rank in range(16):add(f'{label}/rank{rank}.real_perf.json',ref/f'rank{rank}.real_perf.json')
for name in audit['tested_sources']:add('runtime-sources/'+name,Path(config['snapshot'])/name)
out=exp/f'{args.job_name}-{case}-evidence.tar.gz'
with tarfile.open(out,'w:gz') as archive:
 for n,q in sorted(paths.items()):archive.add(q,arcname=n)
print(out,len(paths),out.stat().st_size)
