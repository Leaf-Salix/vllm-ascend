"""No-device gates for layout-only prefix candidate; use the existing SDK."""
import hashlib,json,os,sys
from pathlib import Path
import pypto,simpler
import vllm_ascend.ops.pypto as namespace
from pypto.runtime import RunConfig
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program

exp=Path(os.environ['SPMD_EXPERIMENT']);namespace.__path__.insert(0,str(exp/'src/vllm_ascend/ops/pypto'));sys.path.insert(0,str(exp))
from prefix_control import prepacked_precision_hc_prefix_indexer as control
from prepack_candidate import prepack_fixed_hc_weight
from prefix_overlap import prepacked_precision_hc_prefix_indexer as candidate
assert os.environ['ASCEND_RT_VISIBLE_DEVICES']==''
assert 'low-acceptance-20261010/runtime-package/pypto' in pypto.__file__
assert 'pypto-reference/runtime/python/simpler' in simpler.__file__
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
record={'hardware_executed':False,'scope':'single factor move Sinkhorn between H8 and H9; no arithmetic or barrier count change','control_sha256':sha(exp/'prefix_control.py'),'candidate_sha256':sha(exp/'prefix_overlap.py'),'programs':{}}
for name,entry in [('control',control),('candidate',candidate),('prepare',prepack_fixed_hc_weight)]:
 artifact=exp/f'overlap-{name}-artifact'
 compiled=entry.compile(config=RunConfig(platform='a2a3',dump_passes=True,save_kernels=True,save_kernels_dir=str(artifact)))
 abi=kernel_abi_for_program(entry.specialize(),platform='a2a3',runtime='tensormap_and_ringbuffer')
 kernel=exp/f'overlap-{name}-kernel-artifact'
 _compile_impl(entry.specialize(),output_dir=str(kernel),platform='a2a3',dump_passes=True,_kernel_abi=abi)
 record['programs'][name]={'compiled':True,'kernel_mode_abi_pass':True,'kernel_artifact_dir':str(kernel),'generated':{str(p.relative_to(kernel)):sha(p) for p in kernel.rglob('*') if p.is_file() and p.suffix in ('.py','.json','.cpp')}}
import pypto.torch
for name,entry in [('control',control),('candidate',candidate),('prepare',prepack_fixed_hc_weight)]:
 registered=pypto.torch.register(entry,'overlap_compile_gate::'+name)
record['torch_dispatcher_registration_pass']=True
(exp/'compile-overlap.json').write_text(json.dumps(record,indent=2)+'\n')
print('BF16_INPUT_PACK_COMPILED',flush=True)
