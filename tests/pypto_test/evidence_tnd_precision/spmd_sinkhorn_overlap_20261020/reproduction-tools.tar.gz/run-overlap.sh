#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
case_name=${1:?}
tokens=${2:?}
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/vector-mte2-20261019-codex/full-csa-live-staging-v2/env.sh"
export SPMD_EXPERIMENT="$base/precision-overlap-20261020"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE" PYTHONNOUSERSITE=1
export PYPTO_PROG_BUILD_DIR="$SPMD_EXPERIMENT/device-build" PYPTO_CACHE_DIR="$SPMD_EXPERIMENT/device-cache"
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache
export CMAKE_BUILD_PARALLEL_LEVEL=4
out="$SPMD_EXPERIMENT/results/$case_name"
mkdir -p "$(dirname "$out")"
test ! -e "$out"
export ASCEND_CACHE_PATH="$out-ascend-cache" ASCEND_PROCESS_LOG_PATH="$out-ascend-log"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
ccache -s > "$out-ccache.log"
timeout 750s python "$SPMD_EXPERIMENT/probe_overlap.py" --out "$out" --tokens "$tokens" > "$out-run.log" 2>&1
