"""Create a fresh 77-source whole-model snapshot after both FULL gates pass."""
import argparse
import re
import ast
import hashlib
import json
import shutil
from pathlib import Path

BASE=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
EXP=BASE/'precision-overlap-20261020'
REF=BASE/'precision-spmd-20261019/whole-bf16qa126-v2'
parser=argparse.ArgumentParser()
parser.add_argument('--job-name',default='whole-overlap-v1')
parser.add_argument('--t126-case',default='full-t126-v3')
parser.add_argument('--t240-case',default='full-t240-v2')
args=parser.parse_args()
assert re.fullmatch(r'whole-overlap-[a-z0-9-]+',args.job_name)
assert all(re.fullmatch(r'[a-z0-9-]+',n) for n in (args.t126_case,args.t240_case))
JOB=EXP/args.job_name
OLD='deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout'
NEW='deepseek_v4_flash_csa_tnd_precision_spmd_overlap'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not JOB.exists()
receipt=json.loads((EXP/'compile-full-csa-bf16layout.json').read_text())
assert all(receipt[k] for k in ('compiled','kernel_mode_abi_pass','torch_dispatcher_registration_pass','formal_prepare_program_compiled','formal_prepare_kernel_mode_abi_pass','formal_operators_registered'))
source=EXP/'src/vllm_ascend/ops/pypto'/NEW
assert len(receipt['sources'])==6 and {p.name:sha(p) for p in source.glob('*.py')}==receipt['sources']
gates=(args.t126_case,args.t240_case)
for case,tokens in zip(gates,(126,240)):
 d=json.loads((EXP/'results'/case/'result.json').read_text())
 assert d['complete'] and d['pass'] and d['candidate_sources']==receipt['sources']
 assert d['true_tokens']==d['physical_graph_tokens']==tokens and d['per_request_padding']==0
 assert d['lengths']==([1,2,3,4,5,6]*6 if tokens==126 else [6]*40)
 assert d['layer']==4 and d['history']==8191
 assert set(d['graphs'])=={'native','serial','candidate'}
 assert all(v['bit_equal'] for arm in d['comparisons'].values() for v in arm.values())
 assert d['cross_bucket_warmup']['checks_count']==80
parent=json.loads((REF/'helper-manifest.json').read_text())['files']
assert all(sha(REF/n)==h for n,h in parent.items())
m=json.loads((REF/'snapshot/manifest.json').read_text());files=dict(m['files']);assert len(files)==3393
JOB.mkdir()
for n in parent:
 p=JOB/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(REF/n,p)
shutil.copytree(REF/'qualification-audit',JOB/'qualification-audit',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
shutil.copy2(REF/'helper-manifest.json',JOB/'overlap-parent-helper-manifest.json')
for name,digest in files.items():
 assert sha(REF/'snapshot/source'/name)==digest,name
 p=JOB/'snapshot/source'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(REF/'snapshot/source'/name,p)
for name,digest in receipt['sources'].items():
 n='vllm_ascend/ops/pypto/'+NEW+'/'+name;assert n not in files
 p=JOB/'snapshot/source'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/name,p);files[n]=digest
for n,h in receipt['baseline_sources'].items():assert files[n]==h
for pkg,key in (('deepseek_v4_flash_csa_tnd_precision_spmd','parent_spmd_sources'),('deepseek_v4_flash_csa_tnd_precision_spmd_prepack','parent_prepack_sources'),(OLD,'accepted_bf16_sources')):
 for n,h in receipt[key].items():assert files['vllm_ascend/ops/pypto/'+pkg+'/'+n]==h
m['files']=files;m['spmd_scope']='frozen71 plus isolated six-file Sinkhorn overlap variant; Native-order arithmetic unchanged'
(JOB/'snapshot/manifest.json').write_text(json.dumps(m,indent=2)+'\n')
for name in ('env.sh','preflight.sh','run-case.sh','source_preflight.py','mixed_perf.py','qualified_wkv.py','test_static_qualification.py'):
 p=JOB/name;s=p.read_text().replace(str(REF),str(JOB)).replace(OLD,NEW).replace('dsv4_csa_tnd_precision_spmd_bf16layout::','dsv4_csa_tnd_precision_spmd_overlap::')
 if name=='source_preflight.py':
  # The new root reuses the accepted precision modules, rather than duplicating them.
  assert (source/'qkv_proj_rope.py').is_file()
 p.write_text(s)
changes=json.loads((REF/'candidate-math.json').read_text());changes.update({n:h for n,h in files.items() if NEW+'/' in n});(JOB/'candidate-math.json').write_text(json.dumps(changes,indent=2)+'\n')
(JOB/'FINAL_SOURCE_BOUND.json').write_text(json.dumps({'pass':True,'NPU_executed':False,'scope':'source binding only; whole-model pending','root_ABI':64,'source_manifest_sha256':sha(JOB/'snapshot/manifest.json'),'candidate_sources':receipt['sources'],'preserved_parent_manifest_sha256':sha(REF/'snapshot/manifest.json'),'frozen71_sources':{n:h for n,h in files.items() if any('/'+p+'/' in n for p in ('deepseek_v4_flash_csa_tnd_precision','deepseek_v4_flash_csa_tnd_full_precision','deepseek_v4_flash_csa_tnd_precision_spmd','deepseek_v4_flash_csa_tnd_precision_spmd_prepack',OLD)) or n in ('vllm_ascend/ops/dsv4_csa.py','vllm_ascend/ops/pypto/variant.py')},'compile_receipt_sha256':sha(EXP/'compile-full-csa-bf16layout.json'),'single_layer_gate_result_sha256':{c:sha(EXP/'results'/c/'result.json') for c in gates}},indent=2)+'\n')
for name in ('independent8k.py','independent128k.py'):
 p=JOB/'qualification-audit'/name;p.write_text(p.read_text().replace(OLD,NEW).replace('dsv4_csa_tnd_precision_spmd_bf16layout::','dsv4_csa_tnd_precision_spmd_overlap::'))
p=JOB/'qualification-audit/audit_identity.py';s=p.read_text().replace('default=3393','default=3399').replace("'"+OLD+"')","'"+OLD+"','"+NEW+"')").replace('assert len(tested)==71','assert len(tested)==77')
needle="    package=source/'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_full_precision'"
extra="""    overlap=ast.parse((source/'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision_spmd_overlap/service.py').read_text())
    overlap_class=next(n for n in overlap.body if isinstance(n,ast.ClassDef) and n.name=='CSAServiceRuntime')
    assert [ast.unparse(b) for b in overlap_class.bases]==['PrepackedRuntime']
    assert not any(isinstance(n,ast.FunctionDef) for n in overlap_class.body)
"""
assert needle in s;p.write_text(s.replace(needle,extra+needle))
names=[*parent,'overlap-parent-helper-manifest.json']
(JOB/'helper-manifest.json').write_text(json.dumps({'files':{n:sha(JOB/n) for n in names}},indent=2)+'\n')
for p in list(JOB.glob('*.py'))+list((JOB/'qualification-audit').glob('*.py')):ast.parse(p.read_text())
assert len(files)==3399
print('WHOLE_OVERLAP_READY',JOB,'files',len(files),'manifest',sha(JOB/'snapshot/manifest.json'))
