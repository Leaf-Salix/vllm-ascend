#!/usr/bin/env bash
set -euo pipefail
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/vector-mte2-20261019-codex/full-csa-live-staging-v2/env.sh"
export SPMD_EXPERIMENT="$base/precision-overlap-20261020"
export PYTHONNOUSERSITE=1 ASCEND_RT_VISIBLE_DEVICES="" TORCH_DEVICE_BACKEND_AUTOLOAD=0
export PYPTO_PROG_BUILD_DIR="$SPMD_EXPERIMENT/build" PYPTO_CACHE_DIR="$SPMD_EXPERIMENT/cache"
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache CMAKE_BUILD_PARALLEL_LEVEL=4
ccache -s
timeout 600 python "$SPMD_EXPERIMENT/compile_full_overlap.py"
timeout 180 python "$SPMD_EXPERIMENT/compile_full_overlap_prepare.py"
