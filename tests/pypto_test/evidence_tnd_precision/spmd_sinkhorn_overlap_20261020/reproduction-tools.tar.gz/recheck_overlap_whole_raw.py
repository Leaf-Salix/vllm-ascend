"""独立重读归档载荷；不依赖原审计 pass 字段，不导入 NPU。"""

import argparse
import hashlib
import json
import math
import statistics
import tarfile
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("archive", type=Path)
args = parser.parse_args()
repo = Path(__file__).resolve().parents[2] / "vllm-ascend-nalinaly-tnd-20261008-codex"
sha = lambda raw: hashlib.sha256(raw).hexdigest()
with tarfile.open(args.archive) as archive:
    members = [m for m in archive if m.isfile()]
    assert len({m.name for m in members}) == len(members)
    data = {m.name: archive.extractfile(m).read() for m in members}
load = lambda name: json.loads(data[name])
config = load("candidate/configuration.json")
case = config["case"]
assert case in ("8k", "128k")
batch, active, actual, bucket = (40, 40, 240, 240) if case == "8k" else (24, 21, 126, 144)
variant = "deepseek_v4_flash_csa_tnd_precision_spmd_overlap"
layers = {f"model.layers.{i}.self_attn.attn" for i in range(2, 43, 2)}
manifest = load("source-manifest.json")["files"]
assert len(manifest) == 3399
assert sha(data["source-manifest.json"]) == config["source_manifest_sha256"]
assert config["source_manifest_sha256"] == "b229b29c69dc4aec637f99d586c1b68bafc9cc28cec9ebae2f54483baf1cdd4c"
tested = {name.removeprefix("runtime-sources/"): sha(raw) for name, raw in data.items()
          if name.startswith("runtime-sources/")}
assert len(tested) == 77
assert all(manifest[name] == digest == sha((repo / name).read_bytes()) for name, digest in tested.items())
previous = Path(__file__).resolve().parent.parent / "dsv4-tnd-precision-spmd-20261019/whole-bf16qa126-v2-8k-evidence.tar.gz"
with tarfile.open(previous) as old:
    preserved = {m.name.removeprefix("runtime-sources/"): sha(old.extractfile(m).read())
                 for m in old if m.isfile() and m.name.startswith("runtime-sources/")}
assert len(preserved) == 71 and all(tested[name] == digest for name, digest in preserved.items())
formal = json.loads((Path(__file__).resolve().parent / "FORMAL_CANDIDATE_SOURCES.json").read_text())

receipt = load("formal-overlap-compile.json")
assert len(receipt["sources"]) == 6 and receipt["sources"] == formal
for name, digest in receipt["sources"].items():
    assert tested[f"vllm_ascend/ops/pypto/{variant}/{name}"] == digest
assert all(receipt[k] for k in ("compiled", "kernel_mode_abi_pass", "torch_dispatcher_registration_pass",
                               "formal_prepare_program_compiled", "formal_prepare_kernel_mode_abi_pass",
                               "formal_operators_registered"))
helpers = load("tools/helper-manifest.json")["files"]
assert sha(data["tools/helper-manifest.json"]) == config["helper_manifest_sha256"]
assert all(sha(data["tools/" + name]) == digest for name, digest in helpers.items())
assert all(sha(data["tools/" + name]) == digest for name, digest in config["helpers_sha256"].items())
assert config["batch"] == batch and config["active_requests_for_timing"] == active
assert config["capture_sizes"] == [6, bucket]
assert config["repeats"] == 3 and config["decode_tokens"] == config["warmup_tokens"] == 192
assert config["variant"] == "pkg:" + variant and config["backend"] == "pto"
assert config["deterministic"] and config["event_mode"] == 1 and not config["eplb"]
assert config["single_pto_entry"] and not any(config[k] for k in ("handwritten_cpp", "profiler", "stage_hooks"))
arms = {arm: [load(f"{arm}/rank{rank}.real_perf.json") for rank in range(16)]
        for arm in ("candidate", "native-historical", "serial-parent")}
reference = load("native-historical/configuration.json")
for field in ("bank_plan_sha256", "runtime_manifest_sha256", "bank", "blocks", "capture_sizes",
              "batch", "decode_tokens", "warmup_tokens", "static_metadata_sha256"):
    assert config[field] == reference[field], field
tokens = events = phase_count = all_geometry_count = cross_phase_id_differences = 0
for rank, candidate in enumerate(arms["candidate"]):
    native = arms["native-historical"][rank]
    gold = {r["key"]: r["output_token_ids"] for r in load(f"native-gold/rank{rank}.mixed.json")["requests"]}
    gold_events = {r["key"]: r["events"] for r in map(json.loads, data[f"native-gold/request_stats_rank{rank}.jsonl"].splitlines())}
    assert len(gold) == len(gold_events) == batch and set(gold) == set(gold_events)
    assert all(len(v) == 192 for v in gold.values())
    assert candidate["rank"] == rank and candidate["batch"] == batch and candidate["backend"] == "pto"
    assert candidate["variant"] == "pkg:" + variant and candidate["repeats"] == 3
    assert [r["iteration"] for r in candidate["rounds"]] == [1, 2, 3]
    assert len(candidate["implementations"]) == len(candidate["worker_runtime_config"]) == 1
    impl = candidate["implementations"][0]
    csa = [v for v in impl if v["kind"] == "csa"]
    hca = [v for v in impl if v["kind"] == "hca"]
    assert len(csa) == 21 and all(v["implementation"] == "pto" and v["runtime_class"].endswith("." + variant + ".service") for v in csa)
    assert len(hca) == 20 and all(v["implementation"] == "native" for v in hca)
    runtime = candidate["worker_runtime_config"][0]
    assert runtime["torch_deterministic"] and runtime["deterministic_level"] == 1
    assert runtime["hccl_deterministic"] == "true" and runtime["cann_event_work_mode"] == 1
    assert not runtime["dynamic_eplb"]
    for window in [candidate["warmup"], *candidate["rounds"]]:
        requests = window["requests"]
        assert len(requests) == batch and {r["key"] for r in requests} == set(gold)
        for request in requests:
            assert request["output_token_ids"] == gold[request["key"]]
            assert request["events"] == gold_events[request["key"]] and request["preemptions"] == 0
            tokens += len(request["output_token_ids"])
            events += len(request["events"])
    for window in candidate["rounds"]:
        assert len(window["timing"]) == len(window["identity_before"]) == 1
        timing = window["timing"][0]
        assert timing["sufficient"] and timing["measured_steps"] == len(timing["metadata"]) == 20
        assert len(timing["forward"]["samples_us"]) == 20 and len(timing["cycle"]["samples_us"]) == 19
        identity = timing["identity"]
        qual = identity["static_full_qualification"]
        assert qual["ready"] and qual["actual_reselections"] == 1 and qual["validated_reuses"] > 0
        assert qual["metadata_sha256"] == config["static_metadata_sha256"]
        assert qual["root_namespace"] == "dsv4_csa_tnd_precision_spmd_overlap::attention" and qual["root_abi_tensors"] == 64
        assert set(qual["single_root_counts"]) == set(identity["capture_time_selection"]) == layers
        for name in layers:
            assert all(qual["single_root_counts"][name][str(n)]["warmup"] > 0
                       and qual["single_root_counts"][name][str(n)]["capture"] > 0 for n in (6, bucket))
            assert all(identity["capture_time_selection"][name][f"pto_tokens{n}"] > 0 for n in (6, active, bucket))
        before, after = window["identity_before"][0]["cache_stats"], identity["cache_stats"]
        for key in ("generation_builds", "binary_builds", "bypasses", "invalid_entries", "storage_errors", "forced_rebuilds"):
            assert before[key] == after[key]
        assert all(after[k] == 0 for k in ("bypasses", "invalid_entries", "storage_errors", "forced_rebuilds"))
        selected = 1 if window["iteration"] == 1 else 2
        target = next(n for n in native["rounds"] if n["iteration"] == selected)
        for left, right in zip(timing["metadata"], target["timing"][0]["metadata"], strict=True):
            assert {k: v for k, v in left.items() if k != "call"} == {k: v for k, v in right.items() if k != "call"}
            assert left["requests"] == active and left["actual_tokens"] == actual and left["padded_tokens"] == bucket
            assert left["graph_mode"] == "FULL" and left["dp_tokens"] == [bucket] * 16
            phase_count += 1
        for old in native["rounds"]:
            for left, right in zip(timing["metadata"], old["timing"][0]["metadata"], strict=True):
                omit = {"call"} if case == "8k" else {"call", "input_ids_cpu"}
                assert {k: v for k, v in left.items() if k not in omit} == {k: v for k, v in right.items() if k not in omit}
                pairs = list(zip(left["input_ids_cpu"], right["input_ids_cpu"], strict=True))
                assert all(a == b or {a, b} == {0, -1} for a, b in pairs)
                cross_phase_id_differences += sum(a != b for a, b in pairs)
                all_geometry_count += 1
assert phase_count == 960 and tokens == 16 * batch * 192 * 4
metrics = {}
for arm, ranks in arms.items():
    metrics[arm] = {}
    for kind, steps in (("forward", 20), ("cycle", 19)):
        samples = []
        for iteration in range(len(ranks[0]["rounds"])):
            rank_samples = [r["rounds"][iteration]["timing"][0][kind]["samples_us"] for r in ranks]
            assert all(len(x) == steps for x in rank_samples)
            samples.extend(max(values) / 1000 for values in zip(*rank_samples, strict=True))
        metrics[arm][kind] = {"mean_ms": statistics.mean(samples), "pstdev_ms": statistics.pstdev(samples), "samples": len(samples)}
original = load("audit-" + case + ".json")
# Only reconcile independent CPU summary rounding; all saved tensor/token/phase/source gates above remain exact.
summary_rounding = {}
for kind, key in (("forward", "target_forward_ms"), ("cycle", "target_cycle_ms")):
    actual, recorded = metrics["candidate"][kind]["mean_ms"], original[key]
    # Recompute the recorded convention independently from original microseconds, before unit conversion.
    raw_us = [max(values) for iteration in range(len(arms["candidate"][0]["rounds"]))
              for values in zip(*[rank["rounds"][iteration]["timing"][0][kind]["samples_us"]
                                   for rank in arms["candidate"]], strict=True)]
    recorded_convention = statistics.mean(raw_us) / 1000
    assert recorded_convention == recorded, (kind, recorded_convention, recorded)
    delta = abs(actual - recorded)
    limit = max(math.ulp(actual), math.ulp(recorded))
    assert delta <= limit, (kind, actual, recorded, delta, limit)
    summary_rounding[kind] = {"independent_mean_ms": actual, "recorded_mean_ms": recorded,
                              "microseconds_mean_then_convert_ms": recorded_convention,
                              "recorded_convention_exact_match": True,
                              "absolute_delta_ms": delta, "allowed_CPU_summary_ULPs": 1,
                              "ULP_size_ms": limit}
result = {"pass": True, "case": case, "archive_sha256": sha(args.archive.read_bytes()), "payloads": len(data),
          "tokens": tokens, "events": events, "zero_preemptions": True,
          "same_phase_CPU_all_fields_except_call": phase_count, "all_reference_geometry_comparisons": all_geometry_count,
          "cross_phase_0_negative1_elements": cross_phase_id_differences,
          "manifest_listed_sources": len(manifest), "actual_runtime_payloads_rehashed": len(tested), "preserved_parent_runtime_sources": len(preserved),
          "new6_sources_match_current_repo_and_receipt": True, "metrics": metrics,
          "CPU_summary_rounding": summary_rounding,
          "scope": "Independent saved-text CPU audit; no new hardware; historical arms are cross-task references"}
print(json.dumps(result, indent=2))
