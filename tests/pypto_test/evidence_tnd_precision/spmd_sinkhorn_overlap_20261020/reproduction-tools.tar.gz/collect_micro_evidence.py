"""Collect completed prefix/FULL evidence without caches or tensor dumps."""
from pathlib import Path
import json,tarfile
exp=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overlap-20261020')
cases=('prefix-t21-v1','prefix-t126-v1','prefix-t240-v1','full-t126-v2','full-t240-v1','full-t126-v3','full-t240-v2')
paths={}
for case in cases:
 p=exp/'results'/case/'result.json';d=json.loads(p.read_text());assert d['complete'] and d['pass']
 paths[f'{case}/result.json']=p
 p=exp/'results'/f'{case}-run.log';assert p.is_file();paths[f'{case}/run.log']=p
for name in ('compile-overlap.json','compile-full-csa-bf16layout.json','BASELINE.json'):
 p=exp/name;assert p.is_file();paths[name]=p
for p in (exp/'results').glob('full-t126-v1-*'):
 if p.is_file() and p.suffix=='.log':paths['argument-failure/'+p.name]=p
out=exp/'micro-full-evidence.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for name,p in sorted(paths.items()):t.add(p,arcname=name)
print(out,out.stat().st_size)
