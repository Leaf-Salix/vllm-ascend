#!/usr/bin/env bash
set -euo pipefail
case_name=${1:?8k or 128k}
job_name=${2:-whole-overlap-v1}
case "$case_name" in 8k|128k) ;; *) exit 2;; esac
[[ "$job_name" =~ ^whole-overlap-[a-z0-9-]+$ ]]
exp=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overlap-20261020
job="$exp/$job_name"
export PYTHONNOUSERSITE=1 TORCH_DEVICE_BACKEND_AUTOLOAD=0 PYTHONPATH=""
/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/env/bin/python "$job/qualification-audit/independent$case_name.py" \
 --root "$job/results/$case_name-pto" --identity "overlap-$case_name" \
 --expected-source-manifest b229b29c69dc4aec637f99d586c1b68bafc9cc28cec9ebae2f54483baf1cdd4c \
 --candidate-math "$job/candidate-math.json" --expected-file-count 3399 --expected-repeats 3 \
 > "$job/audit-$case_name.json"
