#!/usr/bin/env bash
set -euo pipefail
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/vector-mte2-20261019-codex/full-csa-live-staging-v2/env.sh"
export SPMD_EXPERIMENT="$base/precision-overlap-20261020"
exp="$base/b28-precision-20261021-codex"
export ASCEND_RT_VISIBLE_DEVICES='' PYTHONNOUSERSITE=1 HCCL_DETERMINISTIC=true
export PYPTO_PROG_BUILD_DIR="$exp/build" PYPTO_CACHE_DIR="$exp/cache"
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache CMAKE_BUILD_PARALLEL_LEVEL=4
python "$exp/preflight.py" > "$exp/preflight.json"
ccache -s > "$exp/ccache-before.txt"
timeout 750s python "$exp/compile_diagnostic.py" > "$exp/compile.log" 2>&1
