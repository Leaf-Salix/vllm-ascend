"""CPU-only cross-check of this experiment's own saved inputs, not a new golden."""
import json
from pathlib import Path
import torch
root=Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex')
paths={
    'current':root/'eight-l1-20261021-codex/results/eight-l1-128k-b28-v1/first-difference.pt',
    'old':root/'precision-spmd-20261019/results/bf16layout-full-t126-v1/first-difference.pt',
    'old_qa':root/'precision-spmd-20261019/results/t126-qa-stage-v5/query-calibration.pt',
}
r={'scope':'CPU-only own saved inputs; no inferred Native QA for T168','available':{n:p.is_file() for n,p in paths.items()}}
if r['available']['current'] and r['available']['old']:
    saved={n:torch.load(paths[n],map_location='cpu',weights_only=True,mmap=True) for n in ('current','old')}
    a=saved['current']['inputs']['native']['hidden'];b=saved['old']['inputs']['native']['hidden']
    r['hidden_shapes']=[list(a.shape),list(b.shape)]
    r['hidden_prefix_byte_equal']=bool(torch.equal(a[:b.shape[0]].contiguous().view(torch.uint8),b.contiguous().view(torch.uint8)))
    r['target_row_inputs_equal']={str(row):bool(torch.equal(a[row].view(torch.uint8),b[row].view(torch.uint8))) for row in (86,103)}
print(json.dumps(r,indent=2))
