# T168 静态路径复核

本记录仅保存已完成的只读分析。结论：**未发现可确认的 Q_A→QR→mainQ / Indexer 静态逻辑、dtype 或寻址缺陷**。这不是数值验收或 NPU 通过结论。

## 前提与实际枚举

当前 B28/T168、history=131072、L4；关注 row86/103。按现有源码常量，以 Python 标准库 Counter 复现循环整数边界，未导入 PyPTO、Torch 或初始化 NPU：

| 路径 | 已检查覆盖 |
| --- | --- |
| QA | 168 个真实行各一次；M64 完整行0–127，M16尾块128/144/160，最后有效8行 |
| mainQ dequant/RMS/RoPE | 168×64=10752 个 `(row,head)` 各一次；T8/H4、48 workers |
| Indexer query projection | 32 个 N256 输出列块各一次；24 workers；最后 M64 块有效40行 |
| Indexer Hadamard / quant | 10752 个 head 行按64行分成168块；24/48 workers 各覆盖所有块一次 |

row86/103 均位于 QA 的同一完整 M64 块64–127。T168整除8，这两行不走 QR、mainQ 或 Indexer dequant 的短行尾部分支。此枚举验证源码整数覆盖，未验证编译后硬件指令。

## Native 边界与当前源码

- Native Q：`vllm_ascend/attention/dsa_v1.py:2290–2350`，QA BF16 → fused RMS dynamic quant → INT8 WQ-B → BF16 → Q RMS → partial interleave RoPE。非A5的 Q RMS 选择位于 `vllm_ascend/device/device_op.py:784`。
- PTO QA：`qkv_proj_rope.py:219`；QR normalize 在约380行，显式将 QA FP32 累加值先舍入 BF16，再执行 RMS、归一化 amax 和量化。
- PTO mainQ：`qkv_proj_rope.py:467`，保留 INT32投影、两组scale先组合、反量化 BF16、Q RMS、旋转前 BF16 及旋转后 BF16 边界。
- Native Indexer：`dsa_v1.py:2559–2607`，query投影、partial RoPE、Hadamard；非A5权重/query/key scale边界在 `device_op.py:768–780`。
- PTO Indexer：`decode_indexer.py:1869` 和 `:1985`，保留投影反量化 BF16、RoPE BF16、Hadamard输出 BF16、缩放 BF16、INT8量化与 FP16 dequant scale。

完整文件路径与本次读取的 SHA256 见同名 JSON。可见边界相符不证明底层 Native 归约、rsqrt/div/recip 或动态量化实现逐位相同。

## 仍存在的资格缺口

`qkv_precision126.py` 只对 T126 使用已实测的 K512 packet 次序。T168走基线 `q_proj_qa`，且168不是48的倍数，不命中其 Native-order 特例。该路径对 T168 的 Native QA 次序尚未取得中间量实测资格，**不能据此认定本次 QA 是根因**。

既有失败快照显示六类 cache/state 精确相同，TopK仅 row86 顺序不同，最终输出 row86/103 不同。row103 的 TopK 精确相同，因此目前不能把 TopK 认定为唯一误差来源。

## 限度与下一步

本轮无正式文件修改、无远端操作、无新任务。源码无法排除编译后 SSA、动态shape、物理alias、同步或硬件算术差异。继续等待已排队13阶段诊断，按最早实际差异决定后续；不依据静态猜测修改归约次序。
