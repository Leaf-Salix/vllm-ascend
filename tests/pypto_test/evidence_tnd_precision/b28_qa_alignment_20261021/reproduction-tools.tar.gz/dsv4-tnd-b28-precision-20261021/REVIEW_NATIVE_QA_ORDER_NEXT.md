# Native QA order next 独立启动审查

## 结论

**通过本地启动审查，无剩余已知阻断项。** 可按下列封存版本做单卡 Native QA 复现；只有真实 FULL QA 的逐 bit 复现及重复稳定性都通过，才有资格解释后续有限 44 族探针。此结论不是硬件结果，也不是完整模型 token 验收。

| 封存文件 | SHA256 |
| --- | --- |
| `qa-order-next/MANIFEST.json` | `ce7e1a7f0f4de46295fbe63a772d108a35be79baabb0432b45dfc1a350effb7e` |
| `native_qa_order_probe.py` | `ef2a97c65f03af3b64bac879bfe28138278b5e7800fb2584413b28e9beb4a17c` |
| `PREPARATION_BINDING.json` | `bf8693b6e42874f5dfbcfe8ddd1cbcc1a3254816f3ac99360d275144bdb0f7cb` |
| `BASELINE_ENVIRONMENT_BOUND.json` | `57081a3f0f220420ba74e9d98b8f45a9473541310995d48cfa1513d4c32d0a7a` |

## 已核实的启动门禁

- 13 个 manifest 成员哈希全部一致。实际 QA result（`0e77f7ee…f172d`）通过当前 `validate_report`：8 个原输出边界 invariance、FULL/T168、compiled/raw、poison replay、非空且全部 PASS 的 guards 均为硬门禁。
- 先校验 calibration 文件及六个 CPU tensor 的字节 SHA、形状、dtype，再用全 168 行 BF16 输入和 NZ29 权重做两次 `F.linear`。必须与实际 FULL Native QA 逐 bit 相等且重复精确，失败即停止，不进入有限探针。
- 原先缺失的 Torch 全局 deterministic 开关已补齐：先设置 `torch.use_deterministic_algorithms(True)` 与 NPU level 1，读取并记录两者；有限查询前再次核验。`torch_npu._C._npu_get_deterministic_level()` 与两次成功 observer 使用同一 getter，在固定 SDK 已有硬件证据。
- 原先 whole/stage 路径及 variant 绑定错误已修复。实际 stage 的 6 个环境键逐项匹配 BOUND，包括 `SOURCE_ROOT` 与 `PTO_CSA_VARIANT=tnd_full_precision`。6 路实际 preflight 模块身份绑定保留；第 7 路 `npugraph_ex` 沿用历史 strict bound，当前启动时仍须精确匹配，此项不是新增的 stage 实测证明。
- 44 个顺序均为合法 16 块排列，六组三元查询的签名恰好区分这 44 个候选。查询重复不稳定、非预期抵消值、N16 内不一致、零候选或最终歧义均停止；不得强选顺序。
- wrapper 限制单个数字设备、可见设备一致、全新输出、SHA 参数、750s 内部限时；外层任务应维持 780s 上限。探针仅调用 Native `F.linear`，没有更改原数学、PyPTO 导出或 64 tensor ABI。

## 解释边界与检查范围

QA observer 已把 row86/103 最早可见差异收窄到 QA BF16 输出（各 1 项）；没有证明特定 K 分块或归约顺序就是根因。44 族若成功，只能确认这些合成查询在该形状、格式、运行环境下与某个有限候选一致，不能推广到所有排列、硬件归约树或真实模型 token。

本次只在本地读源码、核 SHA，并对实际 QA JSON 运行当前门禁及 44 族签名检查；未读取远端 calibration payload，未访问远端或提交设备任务，未改正式源码。正式 repo `git status --short` 为空。
