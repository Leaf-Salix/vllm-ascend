# B28 CPU preflight hook失败定位（2026-10-21）

## 原因与门禁

当前本地脚本可直接解释该失败：`whole-b28-next/env.sh`清除`ADMISSION_TRACE_DIR`；父`cpu_prepare_whole.sh`在第二进程只开启`B28_ACTIVE=1`，没有重新设置该变量。新`sitecustomize.ObserverFinder.find_spec`还要求`ADMISSION_TRACE_DIR`非空，才处理`offline_pd.worker`和`offline_pd.observer`。

因此sitecustomize本身可以成功加载，未受这个条件限制的`MixedFinder`也可将`mixed.run_batches`换成`mixed_b28`；但worker/observer finder主动返回None，两个类保持原方法。`load_model.__module__ == 'sitecustomize'`断言应当失败，不能删除该门禁。

真正`run-arm.sh`在任何Python命令之前同时设置`B28_ACTIVE=1`、`ADMISSION_TRACE_DIR=$out/trace`和`B28_OUTPUT=$out`。本轮CPU wrapper缺少后两项，导致它没有复现实际入口的hook启动条件。当前证据无需诉诸`__module__`不可靠来解释。

## 本机反证控制

`hook_install_probe.py`从封存sitecustomize的AST原样提取三个finder/loader组件，用Python真实import导入极小本地worker/observer/mixed模块；不导入Torch、Torch-NPU或旧远端bridge，不执行设备方法。只改变`ADMISSION_TRACE_DIR`是否存在：

| 条件 | mixed.run_batches | worker.load_model | observer.begin |
| --- | --- | --- | --- |
| 缺少ADMISSION_TRACE_DIR | mixed_b28 | offline_pd.worker原函数 | offline_pd.observer原函数 |
| ADMISSION_TRACE_DIR非空 | mixed_b28 | sitecustomize包装 | sitecustomize包装 |

两次worker都在测试import前未加载；第二种情况下worker方法的qualname为`WorkerLoader.exec_module.<locals>.load`，code filename为封存的B28 sitecustomize。结果见`HOOK_INSTALL_PROBE.json`。这精确复现了“mixed断言通过、worker断言失败”的组合，同时证明补环境后原断言仍能有效检查loader安装。

封存sitecustomize SHA保持`60b880e83e9ffba186c3e480923d93e9232b952be21f1e129552cc14ba8b3b6a`。本轮没有修改whole-b28-next任一封存文件、正式源码、远端脚本或任务。

## 最小修复与下一项远端只读诊断

优先只修父CPU shell wrapper，在启动第二个Python进程前补足实际入口环境；bank准备仍保持B28_ACTIVE=0及手动原bridge：

```bash
export B28_ACTIVE=1
export B28_OUTPUT="$PERF_OUTPUT"
export ADMISSION_TRACE_DIR="$PERF_OUTPUT/trace"
python "$exp/cpu_prepare_whole.py" preflight > "$exp/cpu-whole-preflight-v4.log" 2>&1
```

这些变量只使import包装被安装；不调用worker初始化、模型加载、观察RPC或NPU函数。继续保留空`ASCEND_RT_VISIBLE_DEVICES`、`TORCH_DEVICE_BACKEND_AUTOLOAD=0`、旧baseline全部7模块/环境精确比较及前后`torch.npu.is_initialized()==False`检查。无需重建已通过的bank28，也不改封存preflight的两个`__module__`断言。

如需下一次运行时直接证明安装顺序，可在父CPU Python脚本的baseline import循环之前打印：当前sitecustomize文件、B28_ACTIVE/ADMISSION_TRACE_DIR/B28_OUTPUT、worker/observer是否已在sys.modules，以及sys.meta_path各finder的module/qualname。循环后打印两个方法的module、qualname和code filename。此诊断只读取解释器状态。

补变量后若仍失败，先看worker是否在ObserverFinder注册前已被旧bridge导入，或是否加载了错误sitecustomize；不得通过reload已导入的Torch/vLLM、删除方法门禁或只改函数`__module__`制造通过。当前本地源码已确定的是缺少finder必需环境，尚未自行读取远端运行时状态。
