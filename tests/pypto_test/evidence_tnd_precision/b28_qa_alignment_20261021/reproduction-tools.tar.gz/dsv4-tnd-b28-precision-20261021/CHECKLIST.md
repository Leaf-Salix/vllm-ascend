# B28 首差定位（2026-10-21）

- [x] 读项目规则、Karpathy skill、既有 T126 导出脚本。
- [x] 确认失败档位：128K/B28，T168，L4，seed1024，Native level1。
- [x] 新增独立64参数诊断root，以扩展order packet导出两行阶段值；不改正式源文件或计算。
- [x] 静态比较原root算术/调用不变；Python AST检查。
- [x] 227无设备预检、原环境编译独立诊断root。
- [ ] 单卡FULL graph任务：复现已保存输入/初始cache；Native和PTO外部输出均须与原失败快照逐位相同。
- [ ] poison及guard检查；比较mixed/normed/post/comb/Q/QR/Indexer量化输入/heads/O-proj；首差定位。
- [ ] 每项硬件任务内层750s、队列780s；监控并确认退出。
- [ ] 独立审查、写结果记录；不以TopK集合相同替代排序一致，不放宽误差阈值。

- [x] 独立源码审查通过；正式数学和分支不变。
- [ ] NPU任务待结果：最后成功状态pending；SSH三次主动关闭，恢复后先查已有任务，不重复提交。

## 本轮续作：逐token验收（2026-10-21 12:35）

- [x] 用户调整最终目标为真实模型至少逐token一致；内部逐bit用作定位而非独立交付硬门禁。
- [x] 恢复正常SSH，查已有stage任务仍pending，未重复提交；原13分钟执行上限有效。
- [ ] 先取得可信阶段结果；随后仅修复有证据的首差模块。
- [ ] 区分单层合成输入误差与真实模型token误差；复用确定性Native金值并对齐入场/DSpark执行轨迹。
- [ ] 逐token通过后保留内部误差统计，不将放宽标准描述为已做到逐bit。

- [x] 真实28请求bank头/plan/token/target+MTP合同核验通过，不复制payload；新plan 3340c0ef…。
- [x] 7模块及CANN/ATB/PTOAS与旧token验收环境严格相同；CPU准备前后无NPU初始化。
- [x] CPU准备SDK选择器与hook环境两类问题按根因修复，失败日志保留；最终preflight任务task_20261021_131122_8667061113 exit0。
- [x] 真实CPU证据回收并独立重算，REMOTE_CPU_PREPARATION_RECHECK.json PASS_CPU_PREPARATION_ONLY；没有新token结果。

## 续作：2026-10-21 15:40

- [x] 只读复查原任务completed exit0；阶段JSON已下载，Native/PTO各8边界与原失败快照逐位相同；FULL168、poison、guard、readonly均通过。
- [x] 两行HC-pre/input Norm相同，QR INT8相同，但qr_scale各1元素不同；Q分别20/8元素差异。下一首差区间为QA→Q-LoRA Norm/量化，不把TopK作为最早根因。
- [x] 独立复核13stage有效性和QA-next前提/语义；REVIEW_STAGE_AND_QA_NEXT.md/json PASS。
- [x] QA-next在独立目录无设备preflight与编译，task_20261021_154002_401558724012 exit0；program/kernel ABI64、4源/exports SHA及原formal receipt匹配。
- [x] 仅成功编译后提交单卡QA观察器：task_20261021_154359_99322825833，max-time780s/内层750s；只读status/log监控。
- [x] QA task_20261021_154359_99322825833 exit0，15:44:08–15:46:59；原8边界/guard等全过。row86 col484、row103 col331各1 QA BF16首差，独立复核PASS；权重校准文件只留227。
- [ ] Native QA次序资格探针：先全M168/N1024/K4096独立F.linear重复逐byte复现实际FULL QA，再解释44个有限次序家族。
- [ ] 启用前修正并独立检查环境快照身份绑定、compiled/raw/poison/guard门禁，保留失败负控；仅单卡max-time780s/内层750s。
- [x] 上述资格补齐及独立复核通过：Native QA探针 task_20261021_160533_289197318338 已提交，1卡780/750秒；7模块、实际stage env、双确定性与校准SHA严格门禁。
- [ ] 测得次序后仅在独立候选验证相应QA；不得先扩T126分支或称通用归约规则。
- [x] Native次序任务exit0，22秒；全T168 QA/重复一致，实测10752(row,N16)全部匹配现有packet helper，主审及独立AST复核通过。
- [x] QA-only base/packet独立3Tensor候选主审、标准库覆盖/拒绝控制和shell语法检查通过；无设备编译task_20261021_161901_404552416248 exit0，两臂program/kernel ABI/orchestration通过，原环境不变。
- [ ] 单卡QA-only候选：base先重现实际两行QA首差，packet全168真实QA及2组固定seed新hidden的实际Native F.linear金值，graph poison/repeat/A-B-A/guard/readonly；首差停止。
- [ ] QA-only通过后才无设备编译及单卡验证full-fix-next完整CSA；正式源码和旧基准继续保留。
- [x] QA-only task_20261021_171911_31598208352 exit0，59秒；真实QA原24diff、两新hidden各37diff，packet三组全0；5case raw/poison/repeat/A-B-A/guard/readonly均过，独立review通过，收据SHA89b0804d…。
- [x] full-fix-next CPU compile task_20261021_172356_366977112788 exit1；固定SDK编排GenerateExprString不支持Or，未占卡，非数学精度失败。失败目录和日志保留。
- [x] 生成full-fix-v2：等价if/elif路由；移除新增elif可精确还原正式AST，未改SDK或生成C++；新源/清单已冻结待独立复核。
- [ ] v2原环境无设备编译通过后，提交单卡完整CSA A/B/ABA严格对拍；每项780/750秒。
- [ ] 先不提交新的16卡真实模型任务或后续大配置。

## Canonical T168 candidate (17:49 CST)

- [x] Private full-fix-v2 compiled; hardware task task_20261021_173741_102482026407 passed full Native/PTO A/B/ABA, all eight boundaries exact, 191s device runtime.
- [x] Independent review passed single-layer-only scope; timing was not executed.
- [x] Formal patch adds measured T168 packet route using existing DSL elif; constants inlined/prose removed AST equals executed private v2.
- [ ] New independent 3399-file snapshot (one changed runtime file), canonical full-root/preparer actual compile.
- [ ] New whole-helper identity and CPU controls; Native1 self-repeat then PTO172032-token comparison.
- [ ] Document result/reproducibility and push normal signed-off commit; preserve old baseline.

- [x] Final canonical whole-v2 actual compile task175514 and CPU prepare task175759 exit0; immutable source3399/runtime77/helper31 identities bound.
- [x] Independent final source/compile/CPU review passed; actualnew import and originaltoken/trajectory/gold gates intact.
- [x] Native1 task180516 submitted (16cards/max780/inner750), PTO remains gated on realREADY.
- [ ] Collect Native1/PTO first difference or complete172032-token result; no extrapolation from singlelayer.
