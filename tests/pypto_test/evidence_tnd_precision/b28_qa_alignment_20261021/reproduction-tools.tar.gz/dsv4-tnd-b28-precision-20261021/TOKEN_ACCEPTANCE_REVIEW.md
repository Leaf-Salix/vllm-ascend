# 逐 token 验收审查与最小补验方案（2026-10-21）

## 结论

最终标准改为“真实整模型输出至少与 Native 逐 token 一致”后，内部 Tensor 不逐 bit、TopK 排列差异和小幅输出误差可以保留为诊断信息，不再单独判定最终 token 验收失败。当前 B28/T168 是真实 L4 权重配合**合成 hidden/cache 的单层实验**；1731 个输出元素差异及 row86 的 TopK 重排尚未证实真实模型 token 不一致。

已有 overlap 整模型证据足以支持其固定两档协议的逐 token 结论。当前 HEAD `eebb58d0956d3fa5edbcb8659b6baf177d95453c` 的 77 份运行源码与该归档载荷逐 SHA 相同；本次未改正式实现、冻结数值基准 `48c58ce7c467dfce63d5cb5c41afd225488d6012`、SDK 或环境，也未提交硬件任务。主线程告知原13阶段任务 `task_20261021_121020_53834518291` 在未分卡时被等待命令自动取消，确认无结果后同命令重提为 `task_20261021_125130_324509630936`；此处没有自行查询或提交，不声明替代任务当前状态。

## 历史证据的准确范围

本次本机直接读取两包中全部 16 rank 的原始请求数组及 Native gold JSON/JSONL，检查请求 key 唯一且无缺失、逐个 token、完整接受事件、零抢占；重新计算结果如下，未以 `audit.pass` 代替原始比较。

| 配置 | 提交/测量活跃请求，每 rank | 实际 query 行/graph 行 | 全部 token/接受事件 | 结论 |
| --- | --- | --- | --- | --- |
| 8K/B40 | 40/40 | 240/240 | 491,520 / 105,152 | warm192＋三轮192，逐项等于 Native |
| 128K/B24 | 24/21 | 126/144 | 294,912 / 61,568 | warm192＋三轮192，逐项等于 Native |

共同条件：完整 `DeepSeek-V4-Flash-0731-w8a8`，TP1、DP=EP16，greedy、DSpark 出5验6、ignore EOS，确定性 level1/HCCL，EPLB 关闭，FULL_DECODE_ONLY；21 个 CSA 使用 `pkg:deepseek_v4_flash_csa_tnd_precision_spmd_overlap`，20 个 HCA 为 Native；HC-pre→HC-post、纯 DSL、64 Tensor 根、真 TND。真实请求尾段仍可少于6行。

测量相位每 rank 每轮20步，共960组 CPU metadata：8K 按固定轮次配对；128K 固定 **C1→N1、C2/C3→N2**，除进程局部 `call` 外，包含 input IDs 的全部保存字段严格相同。128K 跨其它 Native 轮的已知0/-1观察槽差异不能用于放宽固定配对；CPU 观察槽一致也不等于所有设备参数逐 bit 已导出。这里的 metadata 只覆盖保存的测量窗口，不能扩写为 overlap 每轮整个生成过程都有全轨迹输入证明。

更早的 `DSV4_FLASH_CSA_TND_192_ADMISSION_RETEST_20261016.md` 另有128K/B24、Native1→Native2→旧精度版的完整78轮生成窗口、73,728 token及接受事件一致，实际入场 q00–q20 在第0轮、q21/q22 在35轮、q23 在36轮；该记录可复用入场审计方法，不能重标为 overlap 全窗口的新设备证明。

## 可复用的路径与命令

以下本地路径相对工作区 `/Users/jiayetcs/Desktop/Project/PyPTO`：

- 正式报告：`vllm-ascend-nalinaly-tnd-20261008-codex/tests/pypto_test/DSV4_FLASH_CSA_TND_PRECISION_SINKHORN_OVERLAP_20261020.md`。
- 证据及工具：该 checkout 的 `tests/pypto_test/evidence_tnd_precision/spmd_sinkhorn_overlap_20261020/`。`whole-overlap-v1-8k-evidence.tar.gz` SHA 为 `d9bb1f8e57adcd821e25e854e8e8abda8efd2abdb8954c1239a96fbed1989f4b`；128K包为 `8a8f5bbf7fd3dde27630c7ffd1ceadc2b33b567fc07031ad88b8ffa56a3a6cb9`。
- 两包的 `candidate/rank*.real_perf.json`、`native-gold/rank*.mixed.json`、`native-gold/request_stats_rank*.jsonl` 是直接 token/事件证据；`native-historical/` 保存测量相位参考。
- `reproduction-tools.tar.gz` 中 `whole-tools/{run-case.sh,mixed_perf.py,perf_probe.py,preflight.sh}` 和 `qualification-audit/independent{8k,128k}.py` 是已运行启动/审计器。源清单 SHA 固定为 `b229b29c69dc4aec637f99d586c1b68bafc9cc28cec9ebae2f54483baf1cdd4c`。
- 完整入场参考方法：`reports/dsv4-full-pto-128k-b24-20261018/helper-v1/{admission_trace.py,generation_window.py,saved_reference.py}`；该 helper 包含真实设备输入复制和全窗口严格比较，不能作为低开销性能协议使用。

归档中227既有实验根与只读输入为：

```text
exp=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overlap-20261020
job=$exp/whole-overlap-v1
8K bank=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/low-acceptance-20261010/banks/fixed8192
8K gold=/data/pyptouser/yejia/lc128/full-pto8k-native-20261016
128K bank=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/low-acceptance-128k-b24-20261014/banks/fixed131072
128K gold=/data/pyptouser/yejia/lc128/retest192-native1-b24000
128K phase reference=/data/pyptouser/yejia/lc128/perf-single-dsl-128k-native-20261018-v2
```

历史三轮协议的现成命令如下；必须先创建新的 job/输出目录，按归档身份恢复依赖并完成预检，不能重跑到旧结果目录：

```bash
bash "$job/preflight.sh" 8k
# 通过 task-submit 分配16卡后执行：
bash "$job/run-case.sh" 8k pto
bash "$exp/audit-case.sh" 8k <new-job-name>
# 8K审计通过后，以128k依次执行同三项。
```

原脚本内部750秒、调度上限780秒，外加 `--device-num 16 --device auto --ptoas 0.63`；显式沿用环境收据中的 `PYTHONNOUSERSITE=1`、`ASCEND_HOME_PATH`、`PTOAS_ROOT`、`CCACHE_DIR` 和 `CMAKE_BUILD_PARALLEL_LEVEL=4`。这些路径是227原实验路径，此处未确认可访问性，不移用 hwServer 的通用 venv。

## 建议的最小验收

1. **现有覆盖可直接保留。** 当前运行源未变，无需因最终标准放宽而重跑旧通过配置。后续数值修改才按8K/B40→128K/B24复用现有 gold 回归。仅验精度时 warm192＋1轮192 已由 `PERF_REPEATS=1` 支持，token覆盖分别245,760与147,456；应在独立审计副本中显式用 `--expected-repeats 1`，保留固定C1→N1和全部 token/事件门禁。现成 `audit-case.sh` 写死三轮，不能原样宣称一轮已通过该审计。
2. **T168 最小新增真实模型场景选8K/B28。** 复用8K原 bank 的前28条、原初始cache和问题顺序，新建 Native 金值任务，再新建候选任务；每项仍 warm192＋1轮192、DP16、FULL `[6,168]`。须保存实际28活跃请求、168真实query行及21个CSA真实入口的证据；仅有 bucket168、名义B28或图中padding不算覆盖。两臂各172,032个输出token，逐项对照，不强行要求自然接受步长或接受长度分布等于某个常数。
3. **该最小新增场景覆盖真实模型的T168数值路径，但仅给8K历史资格。** 不能把它写成128K/B28通过。若要检验长历史与T168的交互，可另建同一新 Native/候选协议的混合 bank，例如20条128K＋8条8K，将长请求放在前20个以让 row86/103 属于长历史；先用实际 KV allocation/逻辑页估算证明28条可同时入场，再运行。它仍不等同28条全128K。全128K/B28必须预检容量并获得真正28活跃的轨迹；现有24000 blocks只实测支持21长请求，128K bank也只有24条，不能仅修改 `batch=28` 或图档位解决。

新增T168的 Native 金值不能从8K/B40 gold截取28条后直接命名为“Native B28”：M/静态选择、DP/MoE及调度组成改变，必须先跑Native本身。原 gold只作为独立跨形状参考，不能代替同形状控制。新 Native 任务中 warmup与正式轮也应彼此逐 token/事件重复；不重复时先记录 Native 自身不稳定，不判候选失败。当前 `run-case.sh` 只允许 `8k|128k` 和 `pto`，`mixed_perf.py` 强制读取既有 gold，`independent*.py` 固定batch/几何；新增B28需要独立小型harness副本，重新绑定helpers/plan/source SHA，不能把它称为现成命令可直接运行。

按后续授权，已在同目录 `whole-b28-next/` 准备该独立副本，说明见其 `README.md`。实际归档connector按每请求logical page加载，不含B40批维，故可派生前28条plan并只读链接原fixed8192 payload，无需重跑suffix prefill。Native1/PTO均固定batch28、max_num_seqs28、capture[6,168]，分任务运行；完整source77 SHA、真实T168、全量tokens、events与入场trace分状态验收。本机CPU正/负控制及wrapper模拟仅验证harness，不构成远端bank头或NPU验收；现阶段不提交新任务，先取已有13阶段结果。

## 入场、接受事件及判定

每臂固定模型/权重、tokenizer、bank与plan SHA、问题/key顺序、初始cache、容量、完整运行源、Native静态包及环境；用新的不可覆盖结果目录。保留原基准和默认路由；候选实际21个CSA全走所指定纯DSL根、20个HCA保持Native，禁止静默Native回退。

逐请求比较全部192个 token ID，覆盖warmup及正式轮，检查key唯一、请求数和长度完整、零抢占；接受事件数组逐项比较，不能只比接受总数、平均接受率或最终文本。接受事件/入场不一致而token暂时相同，应记为协议轨迹不一致，不能据此归为token精度失败，也不能宣称同轨迹验收通过。

新T168对照应记录完整生成窗口的联合DP向量、请求key及行序、query bounds/length、实际input IDs/positions/seq_lens、新入场/完成/抢占事件和图模式。可复用上述 `admission_trace.py`/`generation_window.py` 的严格方法，关闭outer/stage Tensor hook即可；各helper须重新做来源和观测保真资格，不能把组合后的脚本称为旧harness原样通过。完整窗口终点由16rank最后活跃轮推导，保留空闲轮；终点后的raw tail另审严格空跑，不按写死轮数裁剪。内部浮点摘要、logits和TopK排序仅用于首差解释，不要求逐 bit 后才允许token判定。

一个硬件任务只跑一个arm和一个配置，内层750秒、外层780秒，首个token/轨迹差异停止扩展并保留首差请求/位置/事件及原始输入。既有13阶段任务先查状态、收回结果；不重复提交，也不因验收标准变化覆盖失败证据。此方案没有新增性能测量要求。

## 不能下的结论

- 当前合成单层B28失败不证明真实token失败；旧两档token通过也不能覆盖T168或任意输入。
- T168真实token通过不能证明QA归约次序、TopK tie性质或内部浮点已逐 bit对齐；不能据此声称B28根因已定位/修复。
- 8K/B28、混合历史B28和全128K/B28应分别授予资格；未实际达到28活跃/T168就标记覆盖不足。
- 此次没有NPU新结果、性能结论、任意batch/EPLB开启/不同CANN版本的泛化保证。
