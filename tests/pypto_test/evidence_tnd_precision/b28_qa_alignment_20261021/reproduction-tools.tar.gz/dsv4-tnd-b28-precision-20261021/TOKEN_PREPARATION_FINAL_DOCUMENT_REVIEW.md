# 逐token准备报告最终独立审查

**PASS，无必要修正。** 此审查不授予新NPU或真实token资格，未修改文档、助手或正式数学。

已读正式主报告和证据README，逐项核验SHA256清单、三个tar的安全路径/唯一成员、22助手manifest、诊断数学源码与compile-receipt/exports及STATIC_REVIEW一致。

实际CPU原始包中，bank与最终preflight两份收据都记录NPU未初始化；七模块file/version及CANN/ATB/PTOAS等环境与历史BOUND逐项完全一致。28个唯一key、真实bank plan/audit及preflight互相绑定同一3340c0ef…SHA。bank阶段先通过但所在task整体exit1、后续preflight task exit0的分阶段描述准确，未改写旧失败。未声称重新hash全cache payload。

历史491520/105152和294912/61568的token/事件范围与既有两档证据一致，限定原固定bank、warm192+三轮192、EPLB关闭及实际40/T240或21/T126，未外推B28。合成单层B28首差明确不是已证真实token失败；T168前126行hidden相同不冒充QA或根因证明。12项mock控制已与真实CPU bank/preflight分开，不冒充设备结果。

两个未来Native1/PTO真实模型arm仍未提交；172032是计划两轮总量，Native自重复比较86016对，措辞准确。13阶段观察器仅有无设备编译资格，pending阶段尚无中间结果。误用wait超时自动取消的旧排队任务及同命令重提关系已披露，未把取消记为精度失败。

复现入口仍要求独立目录、原环境、先收回阶段数据、Native1 READY后才PTO，以及750/780秒和16卡分配；没有源码替换或Native QA旁路交付。所有数值及归因限定与证据相符。
