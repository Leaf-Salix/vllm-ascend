"""Prepare an equivalent existing-DSL route without changing the frozen SDK."""
import ast
import copy
import hashlib
import json
import shutil
from pathlib import Path

HERE = Path(__file__).resolve().parent
OLD = HERE / 'full-fix-next'
NEW = HERE / 'full-fix-v2'
assert not NEW.exists()
manifest = json.loads((OLD / 'MANIFEST.json').read_text())
NEW.mkdir()
for name, expected in manifest.items():
    source = OLD / name
    assert hashlib.sha256(source.read_bytes()).hexdigest() == expected, name
    destination = NEW / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)

path = NEW / 'full_fix_qkv.py'
tree = ast.parse(path.read_text())
function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'q_proj_qr')
routes = [n for n in ast.walk(function) if isinstance(n, ast.If) and isinstance(n.test, ast.BoolOp)]
assert len(routes) == 1
route = routes[0]
assert isinstance(route.test.op, ast.Or) and len(route.test.values) == 2
assert ast.unparse(route.test) == 'tile_rows == QA_NATIVE_PACKET_ROWS or tile_rows == 168'
route.orelse = [ast.If(test=route.test.values[1], body=copy.deepcopy(route.body), orelse=route.orelse)]
route.test = route.test.values[0]
ast.fix_missing_locations(tree)
path.write_text(ast.unparse(tree) + '\n')

# Recover the original formal tree by removing only the added T168 branch.
restored = copy.deepcopy(tree)
restored_function = next(n for n in restored.body if isinstance(n, ast.FunctionDef) and n.name == 'q_proj_qr')
added = [n for n in ast.walk(restored_function) if isinstance(n, ast.If) and ast.unparse(n.test) == 'tile_rows == QA_NATIVE_PACKET_ROWS']
assert len(added) == 1
assert len(added[0].orelse) == 1 and isinstance(added[0].orelse[0], ast.If)
extra = added[0].orelse[0]
assert ast.unparse(extra.test) == 'tile_rows == 168'
assert ast.dump(ast.Module(body=extra.body, type_ignores=[])) == ast.dump(ast.Module(body=added[0].body, type_ignores=[]))
added[0].orelse = extra.orelse
workspace = HERE.parents[1]
formal = workspace / 'vllm-ascend-nalinaly-tnd-20261008-codex/vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout/qkv_precision126.py'
assert ast.dump(restored, include_attributes=False) == ast.dump(ast.parse(formal.read_text()), include_attributes=False)

for name in ('compile.sh', 'run.sh'):
    target = NEW / name
    target.write_text(target.read_text().replace('/full-fix-next', '/full-fix-v2'))
proof_path = NEW / 'SOURCE_PROOF.json'
proof = json.loads(proof_path.read_text())
proof.update(private_qkv_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
             qkv_route_to='if T126: packet; elif T168: same packet; else: original base',
             qkv_only_route_condition_changed=False, qkv_only_added_equivalent_elif=True,
             qkv_restored_exact_formal_AST=True, fixed_SDK_or_expression_avoided=True)
proof_path.write_text(json.dumps(proof, indent=2) + '\n')
review_path = NEW / 'PREPARATION_REVIEW.json'
review = json.loads(review_path.read_text())
review['status'] = 'V2_PREPARED_ONLY_PENDING_REVIEW_AND_COMPILE'
review['v1_failure'] = 'GenerateExprString not implemented for expression type: Or; no device allocated'
review['v2_change'] = 'Equivalent nested if/elif using existing DSL; packet helper unchanged; formal AST recovered after removing added elif'
review['activation_prerequisites_still_missing'] = ['future successful private complete-root no-device compile receipt']
review['qa_only_qualified_result_sha256'] = '89b0804d1542f66c4e4f3b4eebfd828f92eb2ba8d5f8520dcb67015a0f1e749b'
review['original_failure_snapshot_sha256'] = '54e506e7027cbaf3fa9b905c9bc539fbae3214ce6455256372c01899aaa3d9ae'
review.pop('independent_agent_review', None)
review_path.write_text(json.dumps(review, indent=2) + '\n')
readme = NEW / 'README.md'
readme.write_text(readme.read_text().replace('B28 完整 CSA 私有修复候选', 'B28 完整 CSA 私有修复候选 v2') +
                  '\n## v2 编排兼容性\n\n第一版仅无设备编译失败：固定SDK不能生成该处`or`表达式。v2采用等价`if/elif`，两条分支调用同一原packet helper，未改SDK、C++或计算/舍入。删除新增elif后可精确还原正式AST；失败版本独立保留。\n')
for file in NEW.rglob('*.py'):
    ast.parse(file.read_text(), filename=str(file))
updated = {name: hashlib.sha256((NEW / name).read_bytes()).hexdigest() for name in manifest}
(NEW / 'MANIFEST.json').write_text(json.dumps(updated, indent=2) + '\n')
print('V2_ROUTE_AST_PROOF_PASS', proof['private_qkv_sha256'])
