"""本地生成B28追加QA观察器；不导入Torch/PyPTO，不编译或连接设备。"""

import ast
import copy
import hashlib
import json
import shutil
from pathlib import Path


HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
WORKSPACE = PARENT.parents[1]
OPS = WORKSPACE / "vllm-ascend-nalinaly-tnd-20261008-codex/vllm_ascend/ops/pypto"
QKV_SOURCE = OPS / "deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout/qkv_precision126.py"
PACKET_WORDS = 1048576
QA_OFFSET = 199168
FUNCTIONS = ("q_proj_qr", "q_proj_rope", "qkv_proj_rope")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(node):
    return ast.dump(node, include_attributes=False)


def read_tree(path):
    return ast.parse(path.read_text())


def function(tree, name):
    return next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == name)


def write_tree(path, tree):
    ast.fix_missing_locations(tree)
    path.write_text(ast.unparse(tree) + "\n")


layout = json.loads((PARENT / "exports.json").read_text())
assert layout["packet_size"] == PACKET_WORDS and "qa" not in layout["stages"]
layout["stages"]["qa"] = dict(width=1024, offset=QA_OFFSET, blocks=4,
                              source_dtype="BF16_after_original_QA_round", rows=[86, 103])
occupied = set(range(2560))
for stage in layout["stages"].values():
    for row in range(2):
        start = stage["offset"] + row * stage["blocks"] * 256
        words = set(range(start, start + stage["width"]))
        assert not occupied.intersection(words) and max(words) < PACKET_WORDS
        occupied.update(words)
(HERE / "exports.json").write_text(json.dumps(layout, indent=2) + "\n")

exports = (PARENT / "b28_exports.py").read_text()
exports += f'''
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.qkv_proj_rope import QPROJ_MM_T_DYN

@pl.jit.inline(auto_scope=False)
def export_qa(source: pl.Tensor[[QPROJ_MM_T_DYN,1024],pl.FP32], packet: pl.InOut[pl.Tensor[[{PACKET_WORDS}],pl.INT32]]):
    packet2=pl.reshape(packet,[1,{PACKET_WORDS}])
    with pl.spmd(8,name_hint="debug_qa"):
        block=pl.tile.get_block_idx()
        row=86
        if block>=4:
            row=103
        col=(block%4)*256
        value=pl.load(source,[row,col],[1,256])
        # Repeat only the existing normalize input's BF16 materialization.
        # This readonly observation never replaces the original FP32 source.
        rounded=pl.cast(pl.cast(value,pl.BF16,mode="rint"),pl.FP32)
        bits=pl.tile.reinterpret_view(rounded,pl.INT32)
        pl.store(bits,[0,{QA_OFFSET}+block*256],packet2)
'''
(HERE / "qa_next_exports.py").write_text(exports)

# Copy only three wrappers; all QA, normalize, Q math and KV postprocessing
# remain the same imported functions. Preserve the T126 branch verbatim.
base_qkv = read_tree(QKV_SOURCE)
wrappers = [copy.deepcopy(function(base_qkv, name)) for name in FUNCTIONS]
for wrapper in wrappers:
    wrapper.args.args.append(ast.arg(arg="debug_packet", annotation=ast.parse(
        f"pl.InOut[pl.Tensor[[{PACKET_WORDS}],pl.INT32]]", mode="eval").body))
    for node in ast.walk(wrapper):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in FUNCTIONS:
            node.args.append(ast.Name(id="debug_packet", ctx=ast.Load()))


class BeforeNormalize(ast.NodeTransformer):
    def visit_Expr(self, node):
        if (isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name)
                and node.value.func.id == "q_proj_qr_normalize"):
            return [ast.parse("export_qa(qr_fp32,debug_packet)").body[0], node]
        return self.generic_visit(node)


wrappers[0] = BeforeNormalize().visit(wrappers[0])
header = ast.parse(
    "from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.qkv_precision126 import *\n"
    "from qa_next_exports import export_qa\n")
qkv_tree = ast.Module(body=header.body + wrappers, type_ignores=[])
write_tree(HERE / "qa_next_qkv.py", qkv_tree)

root_tree = read_tree(PARENT / "b28_root.py")
original_import = None
for node in root_tree.body:
    if isinstance(node, ast.ImportFrom):
        if node.module == "b28_exports":
            node.module = "qa_next_exports"
        elif node.module == "b28_indexer":
            node.module = "qa_next_indexer"
        elif any(alias.name == "qkv_proj_rope" for alias in node.names):
            assert original_import is None
            original_import = copy.deepcopy(node)
            node.module, node.level = "qa_next_qkv", 0
assert original_import is not None
for node in ast.walk(root_tree):
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "qkv_proj_rope":
        node.args.append(ast.Name(id="order_packet", ctx=ast.Load()))
write_tree(HERE / "qa_next_root.py", root_tree)
(HERE / "qa_next_indexer.py").write_text(
    (PARENT / "b28_indexer.py").read_text().replace("from b28_exports import", "from qa_next_exports import"))


class RemoveQA(ast.NodeTransformer):
    def visit_FunctionDef(self, node):
        if node.name in FUNCTIONS:
            assert node.args.args[-1].arg == "debug_packet"
            node.args.args.pop()
        return self.generic_visit(node)

    def visit_Expr(self, node):
        if isinstance(node.value, ast.Call) and ast.unparse(node.value.func) == "export_qa":
            return None
        return self.generic_visit(node)

    def visit_Call(self, node):
        if isinstance(node.func, ast.Name) and node.func.id in FUNCTIONS:
            assert isinstance(node.args[-1], ast.Name) and node.args[-1].id == "debug_packet"
            node.args.pop()
        return self.generic_visit(node)


recovered_qkv = RemoveQA().visit(copy.deepcopy(qkv_tree))
assert all(dump(function(recovered_qkv, name)) == dump(function(base_qkv, name)) for name in FUNCTIONS)


class RestoreRoot(ast.NodeTransformer):
    def visit_ImportFrom(self, node):
        if node.module == "qa_next_exports":
            node.module = "b28_exports"
        elif node.module == "qa_next_indexer":
            node.module = "b28_indexer"
        elif node.module == "qa_next_qkv":
            return copy.deepcopy(original_import)
        return node

    def visit_Call(self, node):
        if isinstance(node.func, ast.Name) and node.func.id == "qkv_proj_rope":
            assert isinstance(node.args[-1], ast.Name) and node.args[-1].id == "order_packet"
            node.args.pop()
        return self.generic_visit(node)


assert dump(RestoreRoot().visit(copy.deepcopy(root_tree))) == dump(read_tree(PARENT / "b28_root.py"))
assert (HERE / "qa_next_indexer.py").read_text().replace("from qa_next_exports import", "from b28_exports import") == (PARENT / "b28_indexer.py").read_text()

tools = HERE / "tools"
tools.mkdir(exist_ok=True)
for path in (PARENT / "tools").iterdir():
    if path.is_file() and path.name not in ("probe_csa.py", "manifest.json"):
        shutil.copy2(path, tools / path.name)
probe = (PARENT / "tools/probe_csa.py").read_text()
probe = probe.replace("b28_root", "qa_next_root").replace("b28_stage_probe::attention", "b28_qa_next_probe::attention")
needle = "      'qr':((tokens,1024),torch.int8),'qr_scale':((tokens,1),torch.float32)}"
assert probe.count(needle) == 1
probe = probe.replace(needle, needle[:-1] + ",\n      'qa':((168,1024),torch.bfloat16)}")
needle = "    def observed_fused_qr(*values,**kwargs):\n        result=original_fused_qr(*values,**kwargs)"
assert probe.count(needle) == 1
probe = probe.replace(needle, """    def observed_fused_qr(*values,**kwargs):
        qa_input=values[0] if values else kwargs['x']
        assert qa_input.dtype==torch.bfloat16 and tuple(qa_input.shape)==(168,1024), 'Native QA input contract'
        native_debug['qa'].copy_(qa_input)
        result=original_fused_qr(*values,**kwargs)""")
needle = "            native_export={n:v.cpu().clone() for n,v in native_debug.items()}"
assert probe.count(needle) == 1
probe = probe.replace(needle, needle + """
            native_calibration={n:native_debug[n].detach().cpu().clone() for n in ('normed','qa','qr','qr_scale')}
            assert native_calibration['qa'].dtype==torch.bfloat16 and tuple(native_calibration['qa'].shape)==(168,1024)
            assert all(bool(torch.isfinite(v).all()) for v in native_calibration.values())
            native_wq_a=torch_npu.npu_format_cast(impl.wq_a.weight.detach(),2).cpu().contiguous()
            native_gamma=impl.q_norm.weight.detach().cpu().contiguous()
            assert tuple(native_wq_a.shape)==(1024,4096) and native_wq_a.dtype==torch.bfloat16
            assert tuple(native_gamma.shape)==(1024,) and native_gamma.dtype==torch.bfloat16
            native_calibration.update(wq_a=native_wq_a,gamma_cq=native_gamma)
            native_weight_format=int(torch_npu.get_npu_format(impl.wq_a.weight))
""")
needle = "            report['readonly_after_diagnostic']=True"
assert probe.count(needle) == 1
probe = probe.replace(needle, needle + """
            assert exact(native_calibration['wq_a'],torch_npu.npu_format_cast(runtime.weights['wq_a'],2).cpu().contiguous()), 'QA calibration weight mismatch'
            assert exact(native_calibration['gamma_cq'],runtime.weights['gamma_cq'].cpu().contiguous()), 'QA calibration Norm weight mismatch'
            calibration={'normed':native_calibration['normed'],'native_qa':native_calibration['qa'],
                         'native_qr':native_calibration['qr'],'native_qr_scale':native_calibration['qr_scale'],
                         'wq_a':native_calibration['wq_a'],'gamma_cq':native_calibration['gamma_cq']}
            assert tuple(calibration['normed'].shape)==(168,4096) and calibration['normed'].dtype==torch.bfloat16
            assert tuple(calibration['native_qr'].shape)==(168,1024) and calibration['native_qr'].dtype==torch.int8
            assert tuple(calibration['native_qr_scale'].shape)==(168,1) and calibration['native_qr_scale'].dtype==torch.float32
            calibration_path=args.out/'query-calibration.pt'
            torch.save(calibration,calibration_path)
            report['qa_calibration']={'file':str(calibration_path),'sha256':hashlib.sha256(calibration_path.read_bytes()).hexdigest(),
                'native_weight_format':native_weight_format,'actual_fused_qr_input_dtype':'torch.bfloat16',
                'scope':'Full T168 Native input/QA boundary after all eight original-output invariance gates; remote-only weight/tensors',
                'tensors':{name:{'shape':list(value.shape),'dtype':str(value.dtype),
                    'sha256':hashlib.sha256(value.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()} for name,value in calibration.items()}}
""")
(tools / "probe_csa.py").write_text(probe)
old_manifest = json.loads((PARENT / "tools/manifest.json").read_text())
(tools / "manifest.json").write_text(json.dumps({name: digest(tools / name) for name in old_manifest}, indent=2) + "\n")
shutil.copy2(PARENT / "STATIC_REVIEW.json", HERE / "STATIC_REVIEW.json")

for name in ("preflight.py", "compile.sh", "run.sh", "compile_diagnostic.py"):
    text = (PARENT / name).read_text()
    if name.endswith(".sh"):
        text = text.replace('exp="$base/b28-precision-20261021-codex"', 'exp="$base/b28-precision-20261021-codex/qa-next"')
    if name == "compile_diagnostic.py":
        text = text.replace("b28_root", "qa_next_root").replace("b28_stage_probe::attention", "b28_qa_next_probe::attention").replace("here.glob('b28_*.py')", "here.glob('qa_next_*.py')")
    (HERE / name).write_text(text)

for path in [*HERE.glob("*.py"), *tools.glob("*.py")]:
    ast.parse(path.read_text(), filename=str(path))
proof = dict(status="LOCAL_STATIC_ONLY_NO_COMPILE_NO_DEVICE", root_tensors=64, packet_words=PACKET_WORDS,
             target_rows=[86, 103], fixed_T=168, qa_offset=QA_OFFSET,
             generator_sha256=digest(Path(__file__)),
             wrappers_recovered_exact_AST=list(FUNCTIONS), parent_root_recovered_exact_AST=True,
             indexer_unchanged_except_import=True, all_packet_regions_disjoint=True,
             max_written_word=max(occupied), parent_sources={p.name: digest(p) for p in
                 (PARENT / "b28_root.py", PARENT / "b28_indexer.py", PARENT / "b28_exports.py", PARENT / "tools/probe_csa.py")},
             qkv_source=dict(path=str(QKV_SOURCE), sha256=digest(QKV_SOURCE)),
             generated_sources={p.name: digest(p) for p in HERE.glob("qa_next_*.py")},
             helper_sha256=digest(tools / "probe_csa.py"),
             inherited_formal_static_review_sha256=digest(HERE / "STATIC_REVIEW.json"),
             activation_gate="Only prepare future NPU test if the current 13-stage diagnostic first differs at QR/Q; final acceptance is real-model Native token equality")
(HERE / "QA_OBSERVER_SOURCE_PROOF.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(proof, ensure_ascii=False, indent=2))
