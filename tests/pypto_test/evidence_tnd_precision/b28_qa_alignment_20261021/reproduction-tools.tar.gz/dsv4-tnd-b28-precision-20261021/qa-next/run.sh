#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
case_name=${1:?}
[[ "$case_name" =~ ^[a-z0-9-]+$ ]]
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/vector-mte2-20261019-codex/full-csa-live-staging-v2/env.sh"
export SPMD_EXPERIMENT="$base/precision-overlap-20261020"
exp="$base/b28-precision-20261021-codex/qa-next"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE" PYTHONNOUSERSITE=1 HCCL_DETERMINISTIC=true
export PYPTO_PROG_BUILD_DIR="$exp/build" PYPTO_CACHE_DIR="$exp/cache"
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache CMAKE_BUILD_PARALLEL_LEVEL=4
out="$exp/results/$case_name"
test ! -e "$out"
mkdir -p "$exp/results"
python "$exp/preflight.py" > "$out-preflight.json"
export ASCEND_CACHE_PATH="$out-ascend-cache" ASCEND_PROCESS_LOG_PATH="$out-ascend-log" VLLM_CACHE_ROOT="$out-vllm-cache"
mkdir -p "$ASCEND_CACHE_PATH" "$ASCEND_PROCESS_LOG_PATH"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out-opp-env")
lengths=6
for ((i=1;i<28;i++)); do lengths+=,6; done
printf 'TASK_RUN_START %s\n' "$(date -Iseconds)"
trap 'printf "TASK_RUN_END %s\n" "$(date -Iseconds)"' EXIT
timeout 750s python "$exp/tools/probe_csa.py" --out "$out" --lengths "$lengths" --layer 4 --history 131072 > "$out-run.log" 2>&1
