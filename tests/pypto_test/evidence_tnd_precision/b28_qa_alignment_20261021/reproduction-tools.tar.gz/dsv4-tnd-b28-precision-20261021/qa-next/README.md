# B28后续QA观察器：仅本地静态准备

本目录是已排队13阶段B28诊断的后续备选，不修改父目录或正式算子。
只有当前阶段结果证明QR/Q链出现首差，才考虑启用；尚未编译、上传或提交设备任务。
最终交付目标已改为真实整模型与Native逐token一致，内部逐bit比较用于定位。

## 生成与源级证明

```bash
python3 build_qa_observer.py
```

生成器只用标准库处理本地源码和AST，不导入Torch/PyPTO。它生成独立
`qa_next_root/indexer/qkv/exports.py`、`tools/probe_csa.py`和未来编译/运行助手。
`QA_OBSERVER_SOURCE_PROOF.json`绑定父级四源、当前实际QKV源码、生成器和生成文件SHA。
继承的`STATIC_REVIEW.json`也随目录复制，仍绑定原正式root/Indexer身份；
它不代替本目录新增QA观察器的可逆AST证明。

- 根仍为64Tensor，私有order packet仍为1048576个INT32；原前2560字不变。
- 新QA导出占`199168..201215`，与原13项导出及gap无重叠。
- QKV三个wrapper仅透传packet，并在原Normalize前增加只读QA观察。
  移除该观察与透传参数后，三函数AST精确还原当前`qkv_precision126.py`。
- 原T126条件与T168实际自然序路径均保留；没有扩大T126特判。
- 导出重复原Normalize输入处既有的BF16物化，再扩大FP32保存其bits；不把观察结果反馈计算。
- root剥离本轮增量后精确还原父级`b28_root.py`；Indexer只改导出模块名。

## Native与校准输入

Native hook直接检查实际fusedQR输入为BF16 `[168,1024]`后复制，
不对Native输入做任何转换，也不修改原op参数、返回值或计算。
全T168 QA、normed、QR和scale通过已捕获FULL回放更新，并受NaN/INT毒化及guard保护。

Native和PTO各8个外部状态必须先与原B28失败快照逐byte相同；
只读参数包、order前2560字、所有未授权packet字和外围guard必须通过。
然后保存`query-calibration.pt`，包含全T168 Native normed、BF16 QA、QR/scale、
同一实际WQ-A和gamma；实际权重ND快照与PTO所用权重逐byte比较，记录原Native格式和各tensor SHA。
该文件含模型权重，只保留远端，不应作为普通证据包下载或提交Git。

PTO新QA仅导出row86/103，足以定位目标行的QA BF16边界；不能声称已观测全168行PTO QA。
未来独立线性入口必须先证明自己复现本文件实际Native FULL QA，才可以解释其归约次序探针。

## 当前状态与限制

本地Python AST/可逆性/packet范围检查通过；没有执行PyPTO lowering、CCEC、Native图捕获或NPU。
未来编译助手使用独立`qa-next`缓存和模块namespace，不复用或覆盖正在排队的父目录脚本。
源码和新helper仍须经主线程审阅、原环境无设备编译后，才能按750/780秒的小任务门禁执行。

## 本地依赖与CLI复核

`python3 check_local_dependencies.py`仅用标准库检查16项本地依赖、所有私有import、
helper清单及继承STATIC_REVIEW的原正式源SHA。它只抽取argparse与固定输入门禁AST执行，
验证合法B28被接受、短B1/错误层号/错误history/ragged均被拒绝，不导入运行时或触碰设备。
`LOCAL_DEPENDENCY_REVIEW.json`保存结果。Shell助手已通过`bash -n`。

`compile-receipt.json`应由未来成功无设备编译产生；当前不存在是预期状态，不能复制父级旧receipt冒充。
227冻结环境、模型、旧失败快照及静态包属于外部复现前提，本轮没有远端确认。
