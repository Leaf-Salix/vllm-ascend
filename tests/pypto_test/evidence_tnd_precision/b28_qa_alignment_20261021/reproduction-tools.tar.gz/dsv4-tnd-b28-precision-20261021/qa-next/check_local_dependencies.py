"""只审查本地文件/CLI的AST，不导入运行时、编译器或NPU模块。"""

import argparse
import ast
import hashlib
import json
import sys
from pathlib import Path


HERE = Path(__file__).resolve().parent
required = (
    "STATIC_REVIEW.json", "exports.json", "QA_OBSERVER_SOURCE_PROOF.json",
    "qa_next_root.py", "qa_next_indexer.py", "qa_next_qkv.py", "qa_next_exports.py",
    "compile_diagnostic.py", "compile.sh", "run.sh", "preflight.py",
    "tools/probe_csa.py", "tools/manifest.json", "tools/binding.json",
    "tools/source_identity.py", "tools/ragged_fixture.py",
)
assert all((HERE / name).is_file() for name in required)
manifest = json.loads((HERE / "tools/manifest.json").read_text())
assert all(hashlib.sha256((HERE / "tools" / name).read_bytes()).hexdigest() == sha
           for name, sha in manifest.items())
assert (HERE / "STATIC_REVIEW.json").read_bytes() == (HERE.parent / "STATIC_REVIEW.json").read_bytes()
static = json.loads((HERE / "STATIC_REVIEW.json").read_text())
for section in ("root", "indexer"):
    source = Path(static[section]["formal_source"])
    assert source.is_file() and hashlib.sha256(source.read_bytes()).hexdigest() == static[section]["sha256"]

for filename in ("qa_next_root.py", "qa_next_indexer.py", "qa_next_qkv.py", "qa_next_exports.py"):
    tree = ast.parse((HERE / filename).read_text())
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module and node.module.startswith("qa_next_"):
            assert (HERE / (node.module + ".py")).is_file(), (filename, node.module)
probe = ast.parse((HERE / "tools/probe_csa.py").read_text())
assert "ROOT.parent/'STATIC_REVIEW.json'" in (HERE / "tools/probe_csa.py").read_text()
assert "here.glob('qa_next_*.py')" in (HERE / "compile_diagnostic.py").read_text()
for shell in ("compile.sh", "run.sh"):
    text = (HERE / shell).read_text()
    assert 'exp="$base/b28-precision-20261021-codex/qa-next"' in text
    assert '"$exp/preflight.py"' in text

# Execute just argparse and the fixed-case input guards, before any NPU code.
cli_nodes = []
for node in probe.body:
    if (isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id in ("parser", "args", "lengths")):
        cli_nodes.append(node)
    elif isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Tuple):
        if [item.id for item in node.targets[0].elts] == ["tokens", "batch"]:
            cli_nodes.append(node)
    elif (isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
          and isinstance(node.value.func, ast.Attribute)
          and isinstance(node.value.func.value, ast.Name) and node.value.func.value.id == "parser"):
        cli_nodes.append(node)
    elif isinstance(node, ast.Assert) and "fixed B28 observer only" in ast.unparse(node):
        cli_nodes.append(node)
        break
cli = compile(ast.Module(body=cli_nodes, type_ignores=[]), "<isolated-CLI-AST>", "exec")
lengths = ",".join(["6"] * 28)
cases = (
    ("valid_B28", lengths, "4", "131072", True),
    ("short_B1", "6", "4", "131072", False),
    ("wrong_layer", lengths, "26", "131072", False),
    ("wrong_history", lengths, "4", "8192", False),
    ("ragged", ",".join(["5"] + ["6"] * 27), "4", "131072", False),
)
results = []
old_argv = sys.argv
try:
    for name, rows, layer, history, expected in cases:
        sys.argv = ["probe_csa.py", "--out", "/private/tmp/not-created-qa-cli",
                    "--lengths", rows, "--layer", layer, "--history", history]
        try:
            exec(cli, {"argparse": argparse, "Path": Path})
            accepted = True
        except AssertionError:
            accepted = False
        assert accepted == expected, name
        results.append(dict(case=name, accepted=accepted, expected=expected))
finally:
    sys.argv = old_argv

record = dict(pass_local_static=True, no_runtime_import_or_NPU=True,
              local_dependencies={name: hashlib.sha256((HERE / name).read_bytes()).hexdigest() for name in required},
              CLI_cases=results, compile_receipt="not created: requires a future successful no-device compile",
              external_prerequisites=["original frozen SOURCE_ROOT/SPMD_EXPERIMENT/runtime/SDK and 13 static packages",
                                      "model weights and saved B28 first-difference.pt on 227"],
              hardware_ready=False)
(HERE / "LOCAL_DEPENDENCY_REVIEW.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
print("LOCAL_DEPENDENCIES_AND_FIXED_CLI_PASS; NO_RUNTIME_IMPORT_NO_COMPILE_NO_DEVICE")
