# B28 精度定位当前状态（2026-10-21）

## 当前结论

新增128K/B28、T168单层同输入Native内部逐位对拍未通过，尚未证明真实模型token不同：row86的TopK有88位置重排，512选点集合相同；最终输出row86/103分别1343/388元素不同，整输出relative L2为7.13885310688056e-05。六cache/state逐位相同。row103 TopK完全相同，不能把全部误差归因于row86排序。

此前七档单层门禁及8K/B40、128K/B24真实整模型token验收仍限定在各自已记录配置；不能据此声称所有T已无误差。

## 本轮完成

1. 读取项目规则、Karpathy skill；保留正式分支eebb58d09/数值基准48c58ce7c。
2. 新建独立b28_root/indexer/exports，只通过扩展order packet导出row86/103的13阶段；仍64参数、纯DSL，不改正式源/SDK/环境。
3. 静态脚本剥离导出后，root和Indexer AST与正式源码完全相同；远端运行前另核验formal source hash。
4. 独立审查PASS_SOURCE_ONLY，固定B28/T168/history131072/L4门禁、guards、poison、readonly复验和原失败全部8边界invariance均已实现。
5. 首次无设备编译因诊断单列动态reshape失败；改为仅固定T168的诊断reshape（与硬门禁对应）。重编译task_20261021_120851_4358575420 exit0，program/kernel ABI/dispatcher64注册通过。未占NPU。
6. 已提交单卡task_20261021_121020_53834518291，命令run.sh b28-stages-v1。队列max-time780s、内部timeout750s；未新增性能或整模型任务。

## 阻塞与任务状态

最后成功查询为pending、队首：共享16卡被其他任务占用，我方尚未占卡。
随后原配置SSH连续三次返回`Connection closed by 1.95.79.227 port 22`；不能确认此后是否开始/结束，不把最后pending写成当前状态。
没有变更SSH配置/端口/代理、操作他人任务或启动定时自动化。

恢复连接后首先执行：

```bash
ssh -o BatchMode=yes -o ConnectTimeout=12 pto227 \
  'task-submit --status task_20261021_121020_53834518291'
```

远端实验：`/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/b28-precision-20261021-codex`
结果：`results/b28-stages-v1/result.json`；日志：`results/b28-stages-v1-run.log`。
用本目录`summarize_result.py`读取小JSON；仅在两个arm的original_output_invariance全通过后解释阶段首差。
如果诊断失败，不重提同名输出目录；先读error和日志。任务最终状态确认前不要宣称设备已释放。

## 优先核查线索（尚未证实）

当前T168走自然K256 Q_A顺序，而T126旧同两行首差曾定位到Native K512包顺序。T168没有找到QA同边界既有逐位资格。
这只确定了资格空白；须先看13阶段中的mixed/Norm/qr_scale/Q与Indexer输入，不盲目扩大126分支。
若QRscale/Q首差，再导出真实QA BF16，验证Native F.linear复现实际FULL，然后做有限抵消探针，最后全T168真实QA验证。
若上游均相同则按heads、preinverse、O-proj/HCpost继续二分。详见NEXT_DIAGNOSTIC.md和T168_QA_ORDER_QUALIFICATION.md。

尚未得到本轮NPU阶段结果，未修复正式实现、未新增验收通过结论、未为本轮pending诊断创建正式commit。

## 续作状态更新：2026-10-21 12:52

- SSH已恢复；原任务持续pending未分配卡。
- 主线程误用`task-submit --timeout 45 --wait`，CLI在超时时自动取消pending任务；输出明确写“超时前未分配到设备”。随后原ID --status为not_found，原结果目录未创建。
- 已向用户说明操作失误；同一不可变命令重提一次，替代ID **task_20261021_125130_324509630936**，输出仍为b28-stages-v1；没有重复活跃任务。当前后续只用--status/--log监控，禁止--wait/--run。
- 用户调整最低验收为真实模型逐token一致，不强制内部tensor全部逐bit；原单层失败证据保留。内部差异尚未证明真实token不一致。
- 新CPU证据：B28 hidden前126行与旧T126保存输入逐byte相同，包括row86/103；见HISTORICAL_INPUT_CPU.json。只用于提高QA调查优先级，不能当T168 Native QA金值。
- 后续qa-next仅本地准备，未上传/编译/设备运行，须当前阶段结果支持QR/Q首差才启用。
- whole-b28-next为独立8K/B28真实模型Native1/PTO两臂准备，尚未审核完整/上传/运行；不使用B40截取gold冒充同形状Native。

## 续作状态更新：2026-10-21 13:14

独立whole-b28-next 22助手完成两方审查和12项CPU正负控，已上传，仅做无设备准备。真实bank前28条target/MTP头、dtype/shape/压缩/owner、token与manifest身份通过；新plan SHA为3340c0efaffc9baf976f10d7a42b7a51d72e6568642777a146025d45877b4d75。没有复制或重建cache payload。

CPU准备过程中两次被旧editable PyPTO优先级门禁拦截；仅固定PYTHONPATH不足，复用原验收private启动桥后模块身份通过。随后独立CPU wrapper漏ADMISSION_TRACE_DIR，使worker/observer hook不启用；门禁正确拒绝，补齐和真实入口相同的环境后通过。封存22助手没改，修复只在父CPU wrapper。

bank阶段在task_20261021_130804_57068210312通过，该任务随后preflight hook失败，整体exit1；最终单独preflight task_20261021_131122_8667061113 exit0。7模块/环境与旧token验收相同，原3399文件/77数学源、75模型分片、真TND/64根/loader身份通过；CPU准备前后torch.npu.is_initialized均false。

取回cpu-whole-preparation-evidence.tar.gz（无weights/cache payload），本机recheck_cpu_preparation.py独立PASS。尚未运行新的Native1/PTO逐token测试；stage仍pending，当前唯一硬件诊断ID为task_20261021_125130_324509630936。后续先--status/--log查此ID。用户资源释放时间问题仍待回复；不向其他线程发送消息，不操作他人任务。

## 续作状态更新：2026-10-21 13:55

- 13:55原SSH配置重试恢复，单卡stage最新状态仍pending，未取得设备结果。13:53附近有两次服务器主动关闭SSH，未改端口、代理或配置。
- 已推送准备文档与CPU证据：`1bc33a4b4c06861de208f5add7fa5db4b338a862`；主文档为`tests/pypto_test/DSV4_FLASH_CSA_TND_TOKEN_ACCEPTANCE_PREPARATION_20261021.md`。独立审查和增量pre-commit/manual markdownlint均通过；77份正式数学源未改。
- 进一步独立静态复核未发现可确认的T168 Q_A/QR/mainQ/Indexer逻辑、dtype或寻址缺陷；row86/103位于完整M64块，不走短行尾路径。实际覆盖枚举及源码SHA见`T168_STATIC_PATH_REVIEW.md/json`。这不能排除运行时后端、同步或算术差异。
- 13阶段实际比较语义、首差分流和不可直接比较项见`STAGE_RESULT_AGENT_CHECKLIST.md`：qr为量化INT8，heads已经inverse RoPE，PTO scores不能作为Native QLI分数证明。
- QA-next依然仅本地静态准备，未激活；新的8K/B28 Native1/PTO两臂仍未提交。没有新精度/性能通过结论或正式数值修复。

## 续作状态更新：2026-10-21 16:10

用户回复“再试试”后恢复查询：原13stage任务实际14:03:17–14:06:04完成exit0，两arm原8边界、FULL/raw/poison/guard/readonly全过；最早可见差异是两行QR scale，各1项。13项实际结果已下载到`device-stage-v1/`，独立审查`REVIEW_STAGE_AND_QA_NEXT.md/json`。

QA-next已启用：无设备编译task_20261021_154002_401558724012 exit0，64ABI与4源/exports哈希匹配；单卡task_20261021_154359_99322825833在15:44:08–15:46:59完成exit0。两行最早差异确认QA BF16：row86 col484差2^-12，row103 col331差2^-13；normed相同；原8边界等全保持原失败。见`qa-next/device-b28-qa-v1/result.json`、`REVIEW_QA_BF16_RESULT.md/json`。含权重校准文件仅在远端`qa-next/results/b28-qa-v1/query-calibration.pt`，SHA e543fc19c363d25f5c35406f744feffe57dd447ed715279ecf97dda2aef82494。

Native QA次序探针在启用前修正了guard门禁、whole/stage模块路径、双确定性开关及variant实际值绑定；未删除门禁，失败负控均保留。实际stage env variant为`tnd_full_precision`，由只读回显保存`qa-order-next/ACTUAL_STAGE_ENV.json`。正式完整root在诊断中仍被明确手工选择overlap包，variant变量不是该诊断的算术替代证据。

该探针task_20261021_160533_289197318338在16:05:34–16:05:56完成exit0：独立F.linear全168×1024逐byte复现实际FULL QA并重复稳定；实际Torch确定性true、NPUlevel1；有限44族每个cell唯一。下载结果SHA f5789e3c11c35c976a660690f211f720fb584c0702f6c4be2085bc506aa3f368，位于`qa-order-next/device-native-qa-order-v1/result.json`。

主审公式比较及独立从正式dense/tail循环AST展开，都确认全部10752个(row,N16)观测与现有`q_proj_qa_126`的K512包顺序相同；记录`QA_ORDER_FORMULA_MATCH.json`和`REVIEW_T168_NATIVE_QA_ORDER.md/json`。这仅授予进入PTO候选的有限次序资格，不是候选QA/完整CSA/token通过。

正在由nalinaly_perf_review本地准备`qa-candidate-next`（base与packet仅QA单因素，全168真实QA及2组新hidden，FULL/raw/guard/readonly）；token_acceptance_review本地准备`full-fix-next`（只有T168路由新增，保留T126，完整CSA A/B/ABA/原门禁，precision-only）。两者尚未上传/无设备编译/运行，正式源码与Git HEAD 1bc33a4b4均未改。新的8K/B28 Native1/PTO仍未提交。

## 18:05 CST: isolated T168 fix passed; real-model Native1 queued

Private full-fix-v2 NPU task `task_20261021_173741_102482026407` exit0. Actual device interval 17:37:50--17:41:01 (191s), scheduler duration includes about10s cleanup. Result SHA `a8b0bd68ed36fc4e87a2d7c81c46f74f4b1c524e74d7b3f43cb8cdbec5554741`. A/B all8 external boundaries exact; original NativeA invariant, FULL/raw/ABA/poison/33guards/readonly pass; no timing. Independent review PASS_SINGLE_LAYER_B28_PRECISION_ONLY.

Formal qkv_precision126.py adds constant168 and existing packet helper elif; final QA SHA `ea30b2dec9bba1dc7fc0ae5d6a947a88c5eb4ef471b3291307e4524448a06e80`. Local `SIM114` comment is required: lint otherwise merges into unsupportedOr. Final full precommit math passed. Constant-expanded AST equals executed privatev2, helper bodies unchanged. Original T126/other routes preserved.

New canonical whole candidate is `whole-b28-qa168-v2` under localR and remoteE, NOT old `whole-b28-next` or initial `whole-b28-qa168`. Final snapshot3399/77 source SHA `48ee0351ebd554c2d52c93d28ff7aa4be357cf6636a4325d247f64a1f2671539`, runtime77 SHA `e0b25682cfd924f27021d85ceb025f9b08db354b4c780faa91b0724b5e91108b`. Only QA changed.31helper SHA `5aec62d22523f9433381f1c9f362cfaba4f4d301ca3099db1f90133b7c50e23b`.

Canonical final compile task `task_20261021_175514_302617310470` exit0, complete root64+preparer2 program/kernelABI/GCC/CCEC, noNPU. CPU bank/preflight task `task_20261021_175759_337840512052` exit0, actual7module pinnedenv/4runtime imports newSourceRoot/75modelshards/full3399/77/bank+hook/noNPU.12localcontrols pass. Independent final review PASS_CANONICAL_COMPILE_AND_CPU_PREFLIGHT_ONLY.

Native1 real-model task submitted `task_20261021_180516_970266700`,16cards,max780s,inner750s; standalone Native1 warm192+192. Next actualstatus/log poll around18:10 CST. Never--wait/--run. PTO not yet submitted; require Native READY and newgold hash/trajectory pass first. User requires monitor every5min, noautomation, noend right aftersubmit. NoNative2, no128K model. Newtoken result unknown. Old accepted48c58 baseline unchanged.

Report drafted in formal checkout `tests/pypto_test/DSV4_FLASH_CSA_TND_T168_QA_NATIVE_ALIGNMENT_20261021.md`. Evidence CPU verifier passes, explicitly not tokens/perf. Need update Native1/PTO actual results, archive/recompute, incrementalprecommit+manualmarkdownlint, signedoffcommit/push leaf. Formal commit not yet made. A builder bug replacing absoluteBASE instead of literal$base in env was independently caught and fixed before canonicalcompile; preflight gate never removed. Initial canonicalcompile/source preserved in separatev1 directory afterfinal lint-comment change.
