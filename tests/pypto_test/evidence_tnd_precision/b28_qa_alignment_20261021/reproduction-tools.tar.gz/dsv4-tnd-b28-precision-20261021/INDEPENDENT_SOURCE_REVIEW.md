# B28阶段定位：独立分析与诊断源审查

## 已知与未知

当前T168/128K/seed1024首次A的六组cache/state逐byte相同；TopK仅row86的88位置排列不同，512个选点集合相同；最终x_out在row86/103分别1343/388个元素不同。row86对应request14/query2，row103对应request17/query1。它们都在首个M128面板内，不能直接称为尾行写越界，也不能由此排除跨区别名/同步问题。

cache相同不意味着Q、Indexer query和系数、HC-pre混合/Norm、HC后置参数相同。row103的TopK相同仍有输出差异，故不能把整层问题全部归到TopK排序。当前没有内部首差证据，先观察再修。

## 源码边界与最小分段

1. HC前缀：mixed/normed/post/comb及Indexer projection经BF16、scale后BF16再FP16的输出。若在这些处出现首差，后续Q/score/output差异是传播结果。
2. Q和Indexer query：Q路径输出BF16 Q、qr INT8及qr_scale；Indexer量化query与FP16舍入后再扩大FP32的scale。六cache相同不能代替这些输入逐位核验。
3. Indexer score/TopK：当前代码将INT8 QK经pre_quant(1/1024)+ReLU写FP16，FP16系数参与Cube归约，最后乘FP32 key scale；之后sort32及mrgsort多级合并。集合相同不证明分数同，也不证明真正tie。必须先比query、weight、scale，再检查相关分数/merge顺序；不要直接按index升序稳定排序或使用近似tie阈值。
4. Sparse：native_compressed_pair_swap只调整每固定pair的物理地址顺序，不能消除row86已观察到的跨pair重排。原生slot顺序/分页寻址、K512在线softmax求和树、概率BF16、连续FP32 PV累加、发布BF16再inverse RoPE均会使顺序有数值含义。先看post-inverse heads，必要时再加preinverse BF16和FP32统计，不能先改K分块。
5. O-proj/HCpost：如果heads相同而projected_o首差，检查T168对应Native WO-A标定循环起点/宽M128路径；随后看全8192统一量化和WO-B缩放/最后HCpost。相同TopK与cache不足以排除这一层。即使heads不同，也可把同一heads分别送Native/PTO O-proj做独立边界资格，不能把不同输入结果作为O-proj本体误差。

## 可直接参考的既有工具

- `reports/dsv4-tnd-precision-spmd-20261019/t126-fix-20261020/packed64-v4/tools/probe_csa.py`：当前新脚本已复用其64参数order packet导出和Native活跃copy hook结构。旧T126输入/快照不能替代本次T168。
- `reports/dsv4-tnd-native-sum-fix-20261010/boundary507_native_clone_ab.py`：已有实际Native Q、preinverse、postinverse/O-proj输入的FULL graph观察及ABA防stale方法；若本轮heads首差，复用该观察机制，按当前64根另加导出。
- `reports/dsv4-tnd-qkpv-20261019/capture-b4/probe_threeway.py`：`DeviceOperator.get_dsa_sparse_attn_op`捕获真实sparse输入/前inverse输出，并要求观察运行与Native FULL全部8边界相同。旧B4/8191资格不可平移到B28/131072。
- `reports/dsv4-tnd-precision-overnight-20261019/math/oproj-woa-hybrid192-probe/probe.py`：真实Native WO-A/统一量化/scale/WO-B四阶段同输入门禁；可换成本次捕获heads，但必须使用T168的order模式，不能只抽两行变T2。
- 9月28日`generate_stage_probe.py`/`stage_probe.py`/`topk_probe.py`提供可逆AST导出和QLI输入捕获思路，但它们是旧52参数、不同Native接口，不能原样运行。

## 本次13阶段诊断源审查

独立剥离export调用、debug reshape、额外packet实参与私有导入后，b28_root与当前正式root AST完全相同，b28_indexer与正式Indexer AST完全相同。没有观察到算术替换。导出13阶段的两个目标行共190762个INT32有效字，最大写字198656，低于1048576；与0..2559的原order区无重叠，间隙与外部guard覆盖合理。BF16/FP16有限值扩大FP32保留有效位，INT8经FP16扩大也精确；这些导出值没有反馈计算。

原失败快照的hidden/positions/initial caches及全8外部边界invariance是必要强门禁，当前源码已包含。新增任务本身可以exit0表示诊断完成，但报告precision_pass保持false，这不等于修复或新精度验收。Native hook均调用原op并返回原结果；query/weights/query_scale用活跃buffer copy，避免CPU读取发生在capture内部。

### 上卡前两项修正

1. 固定导出row86/103，但probe目前允许其它S6 batch：短输入会越界。应在初始化NPU前硬断言B28/T168/history131072/layer4；run.sh目前确实传这些参数。
2. 脚本裁剪后readonly_packets/packet_snapshots原有回放后复验被删去；应在导出结果可用前重比所有norm/hc-packed/order snapshots。order前2560、debug gaps及外围guard检查应继续保留。

以上未修正前标记CHANGES_REQUESTED_BEFORE_DEVICE。除此没有发现源级阻断；CPU lowering/实际CCEC物理资源和依赖仍需另审。尤其较窄post/comb/weights的256宽masked load与1宽qr_scale load应从实际生成码确认有效store长度与边界。

后续如果全部上游13阶段相同而x_out仍首差，按同heads O-proj→HCpost二分；若heads首差，再加preinverse边界。不要一开始注入TopK以掩盖row103的独立分支，也不扩性能矩阵。

## 当前修正版复核

源级审查更新为PASS_SOURCE_ONLY。初始化NPU前已硬断言B28/T168/history131072/L4；导出后全量readonly packets与快照比较已恢复。qr_scale导出固定reshape为168仅适用于此私有诊断，与前置硬门禁一致，不改变正式计算。再次在本进程独立执行剥离observer后的AST比较，root/Indexer均精确还原正式源码。无剩余源级阻断。

主线程报告无设备编译exit0；本审查没有读取本轮实际生成文件或设备结果，不能将源级PASS外推为中间量已定位或精度修复。后续解释仍须先满足旧失败快照全8边界invariance。
