"""Prepare an independent canonical source/helper candidate; never edit old assets."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent / 'vllm-ascend-nalinaly-tnd-20261008-codex'
OLD = HERE / 'whole-b28-next'
NEW = HERE / 'whole-b28-qa168-v2'
BASE = '/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex'
REMOTE = BASE + '/b28-precision-20261021-codex/whole-b28-qa168-v2'
QA = 'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout/qkv_precision126.py'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, obj): p.write_text(json.dumps(obj, indent=2) + '\n')

# Inline the two immutable route constants and ignore only prose for a semantic
# comparison with the already executed private v2 candidate.
class Normalize(ast.NodeTransformer):
    def visit_Name(self, node):
        if isinstance(node.ctx, ast.Load) and node.id in {'QA_NATIVE_PACKET_ROWS', 'QA_NATIVE_PACKET_ROWS_B28'}:
            return ast.copy_location(ast.Constant(126 if node.id == 'QA_NATIVE_PACKET_ROWS' else 168), node)
        return node
    def visit_Module(self, node):
        self.generic_visit(node)
        node.body = [n for n in node.body if not (isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in {'QA_NATIVE_PACKET_ROWS', 'QA_NATIVE_PACKET_ROWS_B28'} for t in n.targets))]
        return self.strip(node)
    def strip(self, node):
        if node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Constant) and isinstance(node.body[0].value.value, str): node.body.pop(0)
        return node
    def visit_FunctionDef(self, node):
        self.generic_visit(node)
        return self.strip(node)

formal = (REPO / QA).read_bytes()
private = (HERE / 'full-fix-v2/full_fix_qkv.py').read_bytes()
assert ast.dump(Normalize().visit(ast.parse(formal))) == ast.dump(Normalize().visit(ast.parse(private)))
assert not NEW.exists()
NEW.mkdir()
old_helper = json.loads((OLD / 'helper-manifest.json').read_text())
for name, digest in old_helper['files'].items():
    assert sha(OLD / name) == digest, name
    dest = NEW / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(OLD / name, dest)
shutil.copy2(OLD / 'test_local.py', NEW / 'test_local.py')
(NEW / 'canonical-qkv.py').write_bytes(formal)
old_manifest = json.loads((OLD / 'source-manifest.json').read_text())
new_manifest = copy.deepcopy(old_manifest)
new_manifest['files'][QA] = sha(NEW / 'canonical-qkv.py')
new_manifest['candidate'] = 'T168 QA Native packet route; one canonical runtime file changed'
new_manifest['active_candidate'] = dict(parent_manifest_sha256=sha(OLD / 'source-manifest.json'), parent_git='1bc33a4b4c06861de208f5add7fa5db4b338a862', changed_path=QA, changed_sha256=new_manifest['files'][QA], predecessor_full_result_sha256='a8b0bd68ed36fc4e87a2d7c81c46f74f4b1c524e74d7b3f43cb8cdbec5554741', historical_metadata='Other inherited fields describe the sealed parent snapshot, not this patch')
write(NEW / 'source-manifest.json', new_manifest)
runtime = json.loads((OLD / 'runtime77.json').read_text())
runtime[QA] = new_manifest['files'][QA]
write(NEW / 'runtime77.json', runtime)
env = (NEW / 'env.sh').read_text().replace('$base/precision-overlap-20261020/whole-overlap-v1/snapshot/source', REMOTE + '/snapshot/source')
assert REMOTE + '/snapshot/source' in env and '$base/precision-overlap-' not in env
env += '\nunset SPMD_EXPERIMENT\n'
(NEW / 'env.sh').write_text(env)
proof = dict(scope='Prepared canonical candidate; whole-model qualification pending', original_helper_sha256=sha(OLD / 'helper-manifest.json'), original_source_sha256=sha(OLD / 'source-manifest.json'), original_runtime77_sha256=sha(OLD / 'runtime77.json'), source_manifest_sha256=sha(NEW / 'source-manifest.json'), runtime77_sha256=sha(NEW / 'runtime77.json'), changed_path=QA, qa_sha256=new_manifest['files'][QA], canonical_matches_executed_private_v2_AST=True, predecessor_result_sha256='a8b0bd68ed36fc4e87a2d7c81c46f74f4b1c524e74d7b3f43cb8cdbec5554741', source_count=3399, runtime_count=77, formal_branch='dev/pypto-dsv4-csa-nalinaly-tnd-20261008-codex')
write(NEW / 'CANDIDATE.json', proof)
# Additional identity gates do not weaken any original bank/token/trajectory gate.
with (NEW / 'source_preflight.py').open('a') as out:
    out.write('''
job = Path(__file__).resolve().parent
candidate = json.loads((job / 'CANDIDATE.json').read_text())
assert hashlib.sha256((r / 'manifest.json').read_bytes()).hexdigest() == candidate['source_manifest_sha256']
assert hashlib.sha256((job / 'runtime77.json').read_bytes()).hexdigest() == candidate['runtime77_sha256']
for suffix in ('deepseek_v4_flash_csa_tnd_precision_spmd_overlap.decode_csa',
               'deepseek_v4_flash_csa_tnd_precision_spmd_overlap.service',
               'deepseek_v4_flash_csa_tnd_precision_spmd_overlap.native_adapter',
               'deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.qkv_precision126'):
    module = importlib.import_module('vllm_ascend.ops.pypto.' + suffix)
    assert Path(module.__file__).resolve().is_relative_to(s.resolve()), (suffix, module.__file__)
qa = importlib.import_module('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.qkv_precision126')
assert qa.QA_NATIVE_PACKET_ROWS == 126 and qa.QA_NATIVE_PACKET_ROWS_B28 == 168
assert hashlib.sha256(Path(qa.__file__).read_bytes()).hexdigest() == candidate['qa_sha256']
receipt = json.loads((job / 'compile-receipt.json').read_text())
assert all(receipt[k] is True for k in ('compiled', 'kernel_abi_pass', 'orchestration_compiled', 'prepare_compiled'))
assert receipt['npu_initialized_after'] is False
assert receipt['source_manifest_sha256'] == candidate['source_manifest_sha256']
assert receipt['runtime77_sha256'] == candidate['runtime77_sha256']
assert receipt['qa_sha256'] == candidate['qa_sha256']
assert receipt['source_root'] == str(s.resolve())
print('CANONICAL_T168_SOURCE_AND_COMPILE_IDENTITY_PASS', json.dumps(candidate), flush=True)
''')
print(NEW)
