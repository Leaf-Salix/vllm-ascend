# QA-only packet 硬件结果独立复核

**通过。`full-fix-next` 所要求的 QA-only 资格已满足。** 当前仅能确认 QA 组件精度，尚未确认完整 CSA 或真实模型 token。

- 结果 SHA256：`89b0804d1542f66c4e4f3b4eebfd828f92eb2ba8d5f8520dcb67015a0f1e749b`。`complete/pass=true`，无 error；实际 Torch deterministic 为 true、NPU level 为 1。
- 精确 SOURCE_BINDING、冻结 helper manifest `fbfd0d32…af4f0`、实际编译收据 `c19cfe0c…77e02`、7 路模块身份均匹配。编译的 base/packet 两臂均为 3 Tensor ABI，staging 176 行，实际比较前 168 行。
- 实际输入及两个随机输入的每组 168×1024 个 QA BF16 元素，packet 对 Native 全部零差异。5 个 case 的 base 差异依次为 `24,37,24,37,24`，packet 为 `0,0,0,0,0`；三次 actual case 的完整结果记录一致。
- 四项 checks 全 true；五个 case 的真实 raw graph、输出 poison 恢复、重复精确、readonly 和外围 guard 全 true，actual/random/actual/random/actual 顺序符合冻结合同。

本地实际调用了封存 `full-fix-next/private_loader.py` 的原样 `require_qa_only()`，该收据通过其全部门禁。由于下载目录省略远端的 `results/<label>` 层，仅将结果与编译收据两个 JSON 按原字节复制到临时同结构目录；未改门禁、收据或封存文件。QA-only 与 full-fix 两个 manifest 的全部成员哈希均通过核验。

后续可按父线程审核进入私有完整 root 编译及 B28 完整 CSA 验证；完整 run 仍要求原失败 tensor 的实际 SHA。此次没有读取或执行远端内容，没有导入 Torch/PyPTO/NPU 运行时，没有提交任务或修改正式源码。
