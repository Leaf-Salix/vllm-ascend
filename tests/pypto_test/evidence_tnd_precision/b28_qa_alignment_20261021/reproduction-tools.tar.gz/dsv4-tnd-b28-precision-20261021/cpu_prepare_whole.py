"""在同一解释器内验证无NPU初始化、旧验收模块身份，并执行CPU准备。"""
import argparse
import importlib
import importlib.util
import json
import os
from pathlib import Path
import runpy
import sys

parser=argparse.ArgumentParser()
parser.add_argument('mode', choices=('bank','preflight'))
args=parser.parse_args()
here=Path(__file__).resolve().parent
job=here/'whole-b28-next'
expected=json.loads((here/'BASELINE_ENVIRONMENT_BOUND.json').read_text())
assert os.environ['ASCEND_RT_VISIBLE_DEVICES']==''
assert os.environ['PYTHONNOUSERSITE']=='1'
if os.environ['B28_ACTIVE']=='0':
    # Reuse the exact accepted SDK selectors while keeping B28 observation hooks off.
    # Editable-install meta finders take precedence over PYTHONPATH.
    bridge=here.parent/'low-acceptance-20261010/sitecustomize.py'
    spec=importlib.util.spec_from_file_location('b28_cpu_original_bridge',bridge)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
modules={}
for name,record in expected['modules'].items():
    m=importlib.import_module(name)
    actual={'file':m.__file__,'version':getattr(m,'__version__',None)}
    assert actual==record,(name,actual,record)
    modules[name]=actual
import torch
assert not torch.npu.is_initialized(),'CPU preparation initialized NPU'
for key,value in expected['env'].items():assert os.environ.get(key)==value,(key,os.environ.get(key),value)
if args.mode=='bank':
    assert os.environ['B28_ACTIVE']=='0'
    sys.argv=[str(job/'prepare_bank.py'),'--source',str(here.parent/'low-acceptance-20261010/banks/fixed8192'),'--bank',str(job/'bank28')]
    target='prepare_bank.py'
else:
    assert os.environ['B28_ACTIVE']=='1'
    sys.argv=[str(job/'preflight.py'),'--bank',str(job/'bank28'),'--arm','native','--output',str(job/'preflight-native-cpu.json')]
    target='preflight.py'
runpy.run_path(str(job/target),run_name='__main__')
assert not torch.npu.is_initialized(),'CPU preparation initialized NPU'
receipt={'mode':args.mode,'pass':True,'npu_initialized':False,'modules':modules,'env':expected['env']}
(here/f'CPU_WHOLE_{args.mode.upper()}_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('B28_CPU_ONLY_IDENTITY_AND_NO_DEVICE_PASS',args.mode,flush=True)
