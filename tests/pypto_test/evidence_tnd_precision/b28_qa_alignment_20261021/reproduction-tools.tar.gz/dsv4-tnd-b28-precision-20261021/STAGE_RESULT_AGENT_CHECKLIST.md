# Agent-only: minimal B28 stage-result decision checklist

Scope: read the existing T168/L4/history131072/seed1024 result; do not submit a task, edit formal math, or activate `qa-next` from this checklist. The final acceptance criterion is real-model Native token equality. Internal differences locate a boundary; they do not by themselves prove a token failure.

## 0. Qualify the observation before reading a first difference

- [ ] Require `diagnostic_complete`, no `error`, both arms' eight `original_output_invariance` entries true, actual FULL168, compiled/raw equality, poison replay, external/debug guards, readonly packets, original order words `[0:2560]`, and untouched packet gaps.
- [ ] Native and candidate must each match their **own** saved original failure, with the original hidden/positions/initial caches. `precision_pass=false` is intentional; a completed exporter is not a precision repair.
- [ ] Use `row_comparisons['86']` and `['103']` separately. Aggregate stage metrics can hide different first boundaries. A bit mismatch with `different_elements=0` can be a signed-zero byte difference; inspect saved bits rather than only numeric coordinates.

## Boundary map: what is actually compared

All saved stage arrays are FP32 representations. BF16/FP16 widening is exact for finite values; INT8→FP16→FP32 is exact over INT8. These are comparisons of the named publication boundary, not of unrounded accumulators. Only rows86/103 are exported by PTO.

| Stage(s) | Actual Native hook | PTO observation and meaning |
| --- | --- | --- |
| `mixed`, `post`, `comb` | Direct results of `l.hc_pre`; post/comb flattened | Prefix BF16 mixed `[T,4096]`, FP32 post `[T,4]` and comb `[T,16]`; comparable by row |
| `normed` | `l.input_layernorm(mixed)` output | Prefix input Norm BF16 `[T,4096]`; this is the **4096-wide input Norm**, not the later 1024-wide Q-LoRA Norm |
| `qr`, `qr_scale` | Results0/1 of the actual `_C_ascend.npu_rms_norm_dynamic_quant` | Q-LoRA Norm+dynamic-quant INT8 `[T,1024]` and FP32 per-token dequant scale `[T,1]`; **`qr` is not QA BF16** |
| `q` | First argument to the actual `get_dsa_sparse_attn_op()` callable | Main Q after QB, per-head Q RMS and forward partial RoPE, BF16 `[T,H*HEAD_DIM]`; not raw QB output |
| `indexer_weights` | QLI keyword `weights` after `prepare_dsa_indexer_weights` | Actual published FP1664 coefficients; not raw weights-projection or FP32 unrounded coefficients |
| `iq`, `iscale` | QLI keywords `query` and `query_dequant_scale` | Post-indexer projection/RoPE/Hadamard INT8 query `[T,64,128]`; FP16 consumer scales represented in FP32. PTO scale storage already contains FP16-rounded values widened to FP32 |
| `heads` | Actual `impl._forward_o_proj` input | BF16 heads **after inverse partial RoPE**; PTO `merge_norm` applies BF16 attention publication and inverse RoPE before `publish_native_heads` copies group-packed storage into `[T,32768]` |
| `projected_o` | Input to the actual `impl.wo_b.forward` | WO-A BF16 `[T,8192]` output before WO-B dynamic quantization/INT8 matmul; not WO-B INT8 quantized input |
| `attention_out` | Return from `l.self_attn` immediately before HC-post | WO-B BF16 `[T,4096]` output; external `x_out` is the later HC-post result |
| `qa` (only `qa-next`) | Actual fusedQR **input**, asserted BF16 `[168,1024]` before copying | Readonly view of QA FP32 accumulator **rounded to BF16 with the existing normalize-input rint**, then widened to FP32. Not the raw FP32 accumulator |

Native locations are in `tools/probe_csa.py` around the fusedQR/SAS/O-proj/QLI wrappers. PTO placements are in `b28_root.py`, `b28_indexer.py`, and `b28_exports.py`; Native inverse-RoPE ordering is explicit in `dsa_v1.py::forward` before `_forward_o_proj`.

## 1. Resolve the prefix and shared QR interface first

- [ ] If mixed/post/comb/normed differ, report that earlier boundary. Do not attribute a downstream TopK/heads change to QA or sorting yet.
- [ ] With normed equal, a QR/scale difference selects the QA→Q-LoRA Norm/quant chain for the next split. If QR and scale both agree but main Q differs, split **QB dequant→per-head Q RMS→forward RoPE**; the observed shared QR interface does not support prioritizing a QA-order change.
- [ ] If main Q agrees and only indexer query/scales differ, split indexer QB→RoPE→Hadamard→quantization. If only indexer coefficients differ, split its weights projection/scaling/publication. Neither case authorizes changing main-Q QA tiling.

## 2. Use `qa-next` only to split an unresolved QR-chain difference

- [ ] Preserve the same eight external invariance gates. Compare `qa` row86/103 at its **BF16 materialization**, then QR and scale. QA different selects the projection/publication boundary; QA equal with QR/scale different selects Q-LoRA RMS/amax/quant/scale arithmetic.
- [ ] The current `qa-next` has only local static/AST/dependency evidence. It adds one readonly export and a direct Native BF16-input copy, keeps T126/T168 routing unchanged, and has no successful compile/device receipt yet.
- [ ] `query-calibration.pt` would contain full Native168 normed/QA/QR/scale plus actual WQ-A and gamma, with weight identity and original format recorded. It does **not** contain full PTO168 QA; the PTO QA export still covers two rows. Keep the weight-bearing artifact remote.
- [ ] Before any order probe, reproduce the actual FULL Native QA using the same full M168/N1024/K4096, dtype, recorded weight format/static selection, and saved input. An independent `F.linear` result is not automatically the actual Native reference. Only then test a finite K-order family; a two-row T2 experiment changes Native tiling and cannot qualify M168.

## 3. Classify TopK without inventing Native scores

- [ ] Compare ordered512 indices **and** the sorted multiset for each row. Row86 has a known permutation; row103 is the unchanged-TopK control. Same selected set does not imply a tie or numerically order-invariant attention.
- [ ] Only prioritize QLI scoring/merge order after the corresponding `iq`, `iscale`, coefficients, cache/key scales, request lengths and page mapping agree at the consumer semantics. Three equal row exports alone do not prove every QLI parameter equal; inspect `native-qli-inputs.pt` and the fixture/state evidence.
- [ ] Actual Native QLI uses `return_value=False`; the observer records its indices, not actual Native scores. `stages.pt['pto_scores']` is **PTO-only selected scores**. A CPU reconstruction or score attached by PTO is not a Native score/tie witness. Native opaque QLI metadata also has no direct byte-equivalent PTO order packet.

## 4. Split attention accumulation from inverse RoPE before blaming either

- [ ] If main Q, cache/metadata semantics and ordered TopK agree but `heads` differ, the first unresolved interval is **SAS→BF16 publication→inverse RoPE**. Current13 stages cannot separate these.
- [ ] First inspect nonrotary versus rotary head lanes in the saved two rows. A difference confined to rotary lanes prioritizes inverse RoPE but does not prove its cause.
- [ ] The minimal further observation, if later authorized, is Native actual SAS return tuple element0 **before** `inplace_partial_rotary_mul`, versus PTO `merge_norm`'s BF16 `n_bf16` **before** inverse RoPE. Preserve full T168 geometry. Equal preinverse values with unequal heads selects inverse RoPE; unequal preinverse values selects attention/QK-softmax-PV/publication or a read/dependency issue. Final cache equality alone does not prove values/timing at the consumer.
- [ ] Do not alter TopK order to make the comparison pass. Row103 cannot be explained solely by row86's permutation when its own Q, cache and TopK agree; retain both rows as separate causal paths.

## 5. Only then split the suffix

- [ ] Heads equal, projected_o different: WO-A/group packing/publication interval. Keep full T168 inputs when qualifying Native matmul; do not replay only two rows.
- [ ] Projected_o equal, attention_out different: WO-B dynamic quantization/scale→INT8 matmul/dequant interval. These quantized intermediates are not in13stage.
- [ ] Attention_out, post/comb and original hidden equal, x_out different: HC-post operation tree/publication interval.
- [ ] If all13 exported boundaries agree but x_out does not, recheck signed bits, row association and observer validity before inventing an unobserved QA cause. Neither this fixed single-layer case nor a repaired internal boundary is a new real-model token acceptance result.
