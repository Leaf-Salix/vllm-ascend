# T168 Native QA 次序资格探针：备用准备

此目录只在本地准备，未上传、编译或运行设备；保留原 T126 文件不变。
目前 QA-next 实际观察已确认 row86/103 各有一项 QA BF16 差异，而 normed 相同，
具备运行本探针的定位动机。**这不等于 K-order 已被证明是根因**；独立线性复现仍须先通过。
最终用户验收目标是实际整模型 Native/PTO 逐token一致，有限次序推断只是定位工具。

## 先资格，再解释

1. 显式传入远端 `query-calibration.pt` 和同一次 QA-next `result.json`，同时传两份文件的实际SHA。
2. 核验已审 QA observer 身份、B28/T168/history131072/L4、两臂原8输出不变性、FULL图、compiled/raw逐byte一致、TopK毒化回放恢复、全部33项graph guard状态PASS、只读和导出guard。
   QA observer 的 `precision_pass=False` 是诊断状态；这里要求其 `diagnostic_complete=True`，不能误称整体精度通过。
3. 核验原七模块路径/版本、CANN9.2/PTOAS等环境、单卡 TASK_DEVICE、Torch确定性算法已开启且getter为True，Torch-NPU实际getter等级为1，HCCL确定性为true；模型数据只读取远端校准文件。
4. 核验校准全部六tensor shape/dtype/finite及逐tensor SHA，Native fused QR 实际输入必须本来就是 BF16。
5. 固定 M168/N1024/K4096，实际 BF16 normed与实际 BF16 WQ-A（NZ29），独立两次 `F.linear`。
   必须两次逐byte一致且与同次 FULL 导出的全168行 Native QA 逐byte一致，才允许运行下面的有限探针；失败立即停止。
6. 再次读取并断言Torch确定性与NPU实际等级不变后，与原T126相同，使用18次有限正负抵消query（每次重复一次），六组triples区分44个K256 cyclic/block-order家族。
   拒绝家族外结果、N16内部非均匀、重复差异、歧义；不强迫套用某个已知次序。

源脚本只返回小型 JSON 次序ID和指标，不另存校准/真实权重tensor。
校准文件含模型权重，必须留远端，不能下载或加入证据归档/Git。

## 未来命令（当前不执行）

先由主线程审阅、确认 QA-next 结果与实际SHA，再独立单卡任务调用：

```bash
bash run-native-qa-order.sh \
  /absolute/remote/qa-next-result/query-calibration.pt \
  /absolute/remote/qa-next-result/result.json \
  ACTUAL_CALIBRATION_SHA256 ACTUAL_QA_RESULT_SHA256 t168-native-qa-order-v1
```

脚本使用既有 `full-csa-live-staging-v2/env.sh`，与既有预检相同原SDK，不安装/修改工具链；
内层750秒，调度任务应使用既定780秒上限。输出必须为新目录。该命令不是提交器。
文件路径/版本核验来自随目录保存的 `BASELINE_ENVIRONMENT_BOUND.json`；
若资格不符，应停止定位原因，不可改成宽松版本匹配或暗中转换权重/输入dtype。

## 已执行的本地检查

```bash
python3 check_cpu.py
bash -n run-native-qa-order.sh
```

`check_cpu.py`只用标准库加载实际探针定义，不执行main、不导入Torch/PyPTO/NPU。
它检查44个合法排列、六triple签名唯一、每个合成家族可唯一还原，并对实际收据校验函数进行
1正15负mock控制；另检查实际 FULL-QA门禁位于有限query之前、无顶层运行时import。
结果为 `CPU_RESULT.json`，**不代表真实校准、Native或NPU通过**。

## 解释限度

通过只说明实际 `F.linear` 可复现同次 FULL QA，且观测可在这44个有限家族里唯一识别。
不能证明穷尽16!排列、Native内部Cube归约树、数据相关实现、其它T/N/K、其它dtype/格式/CANN版本。
不能直接生成生产特判或扩大T126特例；需要另行对相同实际权重/输入验证候选修正。
`PREPARATION_BINDING.json`绑定脚本、原T126参考、QA observer和环境文件身份；源/helper总SHA见 `MANIFEST.json`。

## 环境身份修正与实际收据

初版误沿用整模型 `whole-overlap-v1/snapshot/source` 的 vllm_ascend 导入路径和overlap variant，
与本探针继承的 `whole-live-staging-v2` env 不相符；设备前审查已拦截，未运行该版本。
现 `BASELINE_ENVIRONMENT_BOUND.json` 由实际 QA-next CPU预检原文
`QA_PREFLIGHT_RECEIPT.txt` 派生，严格固定实际 stage 的 vllm_ascend 路径。
其余5项预检模块路径/版本与历史bound逐项相同；第7项npugraph_ex沿用历史严格bound并在未来运行再次核验，
不谎称六模块preflight重新观测过第7项。CANN/PTOAS相同，显式绑定实际ccache与四路编译环境。

`derive_environment_profile.py` 记录可复核的本地派生：实际stage预检43项 tested source SHA
均与whole-profile的source manifest相同。它不声称两个完整3365/3399文件manifest相同，
也不以数学相同为由允许任意导入路径。来源及差异见 `ENVIRONMENT_PROFILE_PROOF.json`。
该派生助手需当前报告下的历史bound、qa-next/preflight与whole-b28-next/source-manifest；
未来设备入口只读取已封存的新bound，不需要这些旁侧目录。

`ACTUAL_QA_RECEIPT_CHECK.json` 是对实际QA-next result的标准库门禁检查：
两臂各33项guard、compiled/raw、TopK毒化恢复与校准声明通过。没有读取真实权重tensor、
没有执行独立F.linear，因此不能代替下一阶段设备资格。

启动资格补充：任何 `F.linear` 前显式 `torch.use_deterministic_algorithms(True)`，
读取 `torch.are_deterministic_algorithms_enabled()` 与当前Torch-NPU2.10的
`torch_npu._C._npu_get_deterministic_level()` 并断言 True/1，实际值写入结果。
有限query前再次断言两者未变；未以请求设置值替代实际getter。此新增门禁尚未设备执行。

实际环境收据 `ACTUAL_STAGE_ENV.json` 已补齐原QA预检未打印的6项：
SOURCE_ROOT严格为stage路径，PTO_CSA_VARIANT实际为`tnd_full_precision`，
PTO_CSA_RUNTIME实际为`tensormap_and_ringbuffer`，ASCEND/ATB/PTOAS与既有原SDK一致。
新bound逐项使用此实际值，历史whole的overlap variant只作为profile差异记录，
不再作为本探针的错误启动要求。原独立F.linear/有限query读取实际权重，不以variant值替代数值资格。
_C确定性getter保留与已成功的原13阶段及QA-next相同API；未换SDK或放宽assert。
