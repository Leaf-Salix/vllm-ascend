"""Standard-library controls of the actual probe helpers; never import torch/NPU."""
import ast
import copy
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
source = HERE / 'native_qa_order_probe.py'
namespace = {'__file__': str(source), '__name__': 'cpu_review_only'}
exec(compile(ast.parse(source.read_text()), str(source), 'exec'), namespace)
orders = namespace['make_orders']()
triples = namespace['TRIPLES']
assert len(orders) == 44
assert all(sorted(o) == list(range(16)) for o in orders)
signatures = [tuple(max(q, key=o.index) for q in triples) for o in orders]
assert len(set(signatures)) == 44
# Same observations identify each of the 44 candidates; no full-permutation claim.
for i, signature in enumerate(signatures):
    possible = set(range(44))
    for q, observed in zip(triples, signature):
        possible &= {j for j, o in enumerate(orders) if max(q, key=o.index) == observed}
    assert possible == {i}
binding = json.loads((HERE / 'PREPARATION_BINDING.json').read_text())
assert binding['native_probe_sha256'] == hashlib.sha256(source.read_bytes()).hexdigest()
assert binding['baseline_environment_sha256'] == hashlib.sha256((HERE / 'BASELINE_ENVIRONMENT_BOUND.json').read_bytes()).hexdigest()
bound = json.loads((HERE / 'BASELINE_ENVIRONMENT_BOUND.json').read_text())
profile = json.loads((HERE / 'ENVIRONMENT_PROFILE_PROOF.json').read_text())
assert bound['modules']['vllm_ascend']['file'] == profile['profile_path_change']['new'] + '/vllm_ascend/__init__.py'
assert bound['modules']['vllm_ascend']['file'] != profile['profile_path_change']['old'] + '/vllm_ascend/__init__.py'
assert len(bound['modules']) == 7
actual_env = json.loads((HERE / 'ACTUAL_STAGE_ENV.json').read_text())
assert all(bound['env'][name] == value for name,value in actual_env.items())
assert bound['env']['PTO_CSA_VARIANT'] == 'tnd_full_precision'
assert hashlib.sha256((HERE / 'ACTUAL_STAGE_ENV.json').read_bytes()).hexdigest() == binding['actual_stage_env_sha256']
assert hashlib.sha256((HERE / 'QA_PREFLIGHT_RECEIPT.txt').read_bytes()).hexdigest() == profile['actual_stage_preflight_sha256']
cal_sha = 'a' * 64
shapes = {'normed': ([168,4096], 'torch.bfloat16'), 'native_qa': ([168,1024], 'torch.bfloat16'),
          'native_qr': ([168,1024], 'torch.int8'), 'native_qr_scale': ([168,1], 'torch.float32'),
          'wq_a': ([1024,4096], 'torch.bfloat16'), 'gamma_cq': ([1024], 'torch.bfloat16')}
report = {'diagnostic_complete': True, 'readonly_after_diagnostic': True, 'debug_guards_pass': True,
          'lengths': [6]*28, 'true_tokens':168, 'physical_graph_tokens':168, 'layer':4,'history':131072,
          'helper_sha': {'probe_csa.py': binding['qa_observer_probe_sha256']},
          'original_output_invariance': {arm:{str(i):True for i in range(8)} for arm in ('native','candidate')},
          'graphs': {arm:{'actual_acl_graph':True,'fullgraph':True,'true_tokens':168,'graph_tokens':168,
                          'compiled_raw_equal':True,'topk_poison_replay_restored':True,
                          'guards':{'cache':{'status':'PASS'},'output':{'status':'PASS'}}} for arm in ('native','candidate')},
          'qa_calibration': {'sha256':cal_sha,'actual_fused_qr_input_dtype':'torch.bfloat16','native_weight_format':29,
             'tensors': {n:{'shape':s,'dtype':d,'sha256':'b'*64} for n,(s,d) in shapes.items()}}}
namespace['validate_report'](report, cal_sha, binding)
mutations = {
 'incomplete': lambda d:d.update(diagnostic_complete=False),
 'compiled_raw_false':lambda d:d['graphs']['candidate'].update(compiled_raw_equal=False),
 'topk_poison_not_restored':lambda d:d['graphs']['native'].update(topk_poison_replay_restored=False),
 'one_graph_guard_failed':lambda d:d['graphs']['candidate']['guards']['cache'].update(status='FAIL'),
 'empty_graph_guards':lambda d:d['graphs']['native'].update(guards={}),
 'wrong_arm_schema':lambda d:d['graphs'].update(pto=d['graphs'].pop('candidate')),
 'readonly_false':lambda d:d.update(readonly_after_diagnostic=False),
 'guard_false':lambda d:d.update(debug_guards_pass=False),
 'wrong_T':lambda d:d.update(true_tokens=126),
 'wrong_fixture_sha':lambda d:d['qa_calibration'].update(sha256='c'*64),
 'wrong_NZ':lambda d:d['qa_calibration'].update(native_weight_format=2),
 'native_changed':lambda d:d['original_output_invariance']['native'].update({'0':False}),
 'wrong_helper':lambda d:d['helper_sha'].update({'probe_csa.py':'d'*64}),
 'wrong_dtype':lambda d:d['qa_calibration']['tensors']['native_qa'].update(dtype='torch.float32'),
 'wrong_shape':lambda d:d['qa_calibration']['tensors']['native_qa'].update(shape=[126,1024]),
}
for name, mutate in mutations.items():
    altered = copy.deepcopy(report)
    mutate(altered)
    try:
        namespace['validate_report'](altered, cal_sha, binding)
    except AssertionError:
        continue
    raise AssertionError(('negative control accepted',name))
# Ensure no finite order query can run before actual FULL-QA reproduction assertion.
tree=ast.parse(source.read_text())
main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
assert source.read_text().index("assert record['actual_fixture_repeat_exact']") < source.read_text().index('orders = make_orders()',source.read_text().index('def main'))
body_source = source.read_text()[source.read_text().index('def main'): ]
assert body_source.index('torch.use_deterministic_algorithms(True)') < body_source.index('F.linear(real_x, real_w)')
assert body_source.count('assert torch.are_deterministic_algorithms_enabled()') == 2
assert body_source.count('_npu_get_deterministic_level()') == 2
assert body_source.index("record['finite_query_determinism_rechecked'] = True") < body_source.index('orders = make_orders()')
assert not any(n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom)) and any(x.name.split('.')[0] in ('torch','torch_npu','pypto') for x in n.names))
result={'status':'PASS_LOCAL_CPU_PREPARATION_ONLY','orders':44,'unique_six_triple_signatures':44,
        'positive_report_controls':1,'negative_report_controls':list(mutations),
        'fixture_controls_are_mock':True,'no_actual_calibration_read':True,'no_runtime_import_no_NPU':True,
        'native_probe_sha256':binding['native_probe_sha256']}
(HERE/'CPU_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
