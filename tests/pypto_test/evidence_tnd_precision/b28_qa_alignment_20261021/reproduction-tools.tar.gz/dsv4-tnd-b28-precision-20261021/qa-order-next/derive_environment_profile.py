"""Derive the stage profile from its actual CPU preflight receipt; no runtime import."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
old_path = BASE / 'BASELINE_ENVIRONMENT_BOUND.json'
receipt_path = BASE / 'qa-next/preflight.json'
whole_manifest_path = BASE / 'whole-b28-next/source-manifest.json'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
text = receipt_path.read_text()
preflight = json.loads(text[text.index('{'):])  # vLLM INFO prefix retained in raw receipt.
old = json.loads(old_path.read_text())
modules = old['modules']
actual_modules = {k: preflight[k] for k in ('pypto','simpler','torch','torch_npu','vllm','vllm_ascend')}
assert preflight['npu_initialized'] is False
old_stage = '/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overlap-20261020/whole-overlap-v1/snapshot/source'
new_stage = '/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/vector-mte2-20261019-codex/whole-live-staging-v2/snapshot/source'
assert modules['vllm_ascend']['file'] == old_stage + '/vllm_ascend/__init__.py'
assert actual_modules['vllm_ascend'] == {'file':new_stage+'/vllm_ascend/__init__.py','version':None}
for name, info in actual_modules.items():
    if name != 'vllm_ascend':
        assert info == modules[name], ('unexpected original SDK/library change',name)
assert len(modules) == 7 and 'npugraph_ex' in modules
# Preflight imports six modules; the seventh npugraph_ex is retained strictly from
# the original bound profile and will still be checked at runtime, not claimed anew.
source = preflight['source']
assert source['source_root'] == new_stage and source['source_file_count'] == 3365
assert source['whole_model_sitecustomize'] is False
assert len(source['tested_sources']) == 43
whole = json.loads(whole_manifest_path.read_text())['files']
assert all(whole[name] == value for name,value in source['tested_sources'].items())
for name, value in preflight['environment'].items():
    if name in old['env']:
        assert old['env'][name] == value
modules.update(actual_modules)
old['env'].update(preflight['environment'])
actual_env_path = HERE / 'ACTUAL_STAGE_ENV.json'
actual_env = json.loads(actual_env_path.read_text())
assert set(actual_env) == {'SOURCE_ROOT','ASCEND_HOME_PATH','ATB_HOME_PATH','PTOAS_ROOT','PTO_CSA_VARIANT','PTO_CSA_RUNTIME'}
assert actual_env['SOURCE_ROOT'] == new_stage
assert actual_env['PTO_CSA_VARIANT'] == 'tnd_full_precision'
assert actual_env['PTO_CSA_RUNTIME'] == 'tensormap_and_ringbuffer'
for name in ('ASCEND_HOME_PATH','ATB_HOME_PATH','PTOAS_ROOT','PTO_CSA_RUNTIME'):
    assert actual_env[name] == old['env'][name]
previous_variant = old['env']['PTO_CSA_VARIANT']
old['env'].update(actual_env)
old['derived_profile'] = 'actual QA-next stage preflight and environment receipt; strict stage path/variant; same original SDK'
old['profile_provenance'] = {
    'historical_whole_bound_sha256':sha(old_path),
    'actual_stage_preflight_sha256':sha(receipt_path),
    'actual_stage_env_sha256':sha(actual_env_path),
    'variant_profile_change':{'historical_whole':previous_variant,'actual_stage':actual_env['PTO_CSA_VARIANT']},
    'actual_env_keys_strictly_bound':list(actual_env),
    'unchanged_sdk_imports': ['pypto','simpler','torch','torch_npu','vllm'],
    'npugraph_ex':'strict historical bound retained; absent from six-module stage preflight; checked at future runtime',
    'source_tested43_matches_whole_manifest':True,
    'whole_manifest_sha256':sha(whole_manifest_path),
    'stage_source_manifest_sha256':source['source_manifest_sha256'],
    'profile_path_change':{'old':old_stage,'new':new_stage},
    'scope':'43 preflight tested-source hashes equal whole-profile source manifest, not a claim that complete 3365/3399 manifests are identical',
}
(HERE/'BASELINE_ENVIRONMENT_BOUND.json').write_text(json.dumps(old,indent=2)+'\n')
(HERE/'QA_PREFLIGHT_RECEIPT.txt').write_bytes(receipt_path.read_bytes())
(HERE/'ENVIRONMENT_PROFILE_PROOF.json').write_text(json.dumps(old['profile_provenance'],indent=2)+'\n')
print(json.dumps(old['profile_provenance']))
