"""T168 Native QA qualification; finite family identification is not universal proof."""
import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys

ROWS, OUTPUTS, INPUTS = 168, 1024, 4096
K_BLOCK, N_BLOCK = 256, 16
TRIPLES = ((0, 5, 11), (6, 7, 8), (2, 9, 12), (4, 6, 14), (1, 13, 15), (3, 10, 11))
HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def make_orders():
    orders = []
    for width in (1, 2, 4, 8, 16):
        for direction in (1, -1):
            for start in range(16 // width):
                order = tuple(((start + direction * i) % (16 // width)) * width + j
                              for i in range(16 // width) for j in range(width))
                if order not in orders:
                    orders.append(order)
    return orders


def validate_report(report, fixture_sha, binding):
    # The QA observer intentionally records precision_pass=False, because it diagnoses
    # the original mismatch. Its completed/invariance/guard gates are required instead.
    assert 'error' not in report
    assert report.get('diagnostic_complete') is True
    assert report.get('readonly_after_diagnostic') is True
    assert report.get('debug_guards_pass') is True
    assert report['lengths'] == [6] * 28
    assert report['true_tokens'] == ROWS and report['physical_graph_tokens'] == ROWS
    assert report['layer'] == 4 and report['history'] == 131072
    assert report['helper_sha']['probe_csa.py'] == binding['qa_observer_probe_sha256']
    assert set(report['original_output_invariance']) == {'native', 'candidate'}
    for checks in report['original_output_invariance'].values():
        assert len(checks) == 8 and all(v is True for v in checks.values())
    assert set(report['graphs']) == {'native', 'candidate'}
    for arm in ('native', 'candidate'):
        graph = report['graphs'][arm]
        assert graph['actual_acl_graph'] is True and graph['fullgraph'] is True
        assert graph['compiled_raw_equal'] is True
        assert graph['topk_poison_replay_restored'] is True
        assert graph['guards'] and all(value['status'] == 'PASS' for value in graph['guards'].values())
        assert graph['true_tokens'] == ROWS and graph['graph_tokens'] == ROWS
    cal = report['qa_calibration']
    assert cal['sha256'] == fixture_sha
    assert cal['actual_fused_qr_input_dtype'] == 'torch.bfloat16'
    assert cal['native_weight_format'] == 29, 'this qualification is NZ29 only'
    expected = {'normed': ([ROWS, INPUTS], 'torch.bfloat16'),
                'native_qa': ([ROWS, OUTPUTS], 'torch.bfloat16'),
                'native_qr': ([ROWS, OUTPUTS], 'torch.int8'),
                'native_qr_scale': ([ROWS, 1], 'torch.float32'),
                'wq_a': ([OUTPUTS, INPUTS], 'torch.bfloat16'),
                'gamma_cq': ([OUTPUTS], 'torch.bfloat16')}
    assert set(cal['tensors']) == set(expected)
    for name, (shape, dtype) in expected.items():
        meta = cal['tensors'][name]
        assert meta['shape'] == shape and meta['dtype'] == dtype
        assert len(meta['sha256']) == 64
    return expected


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--calibration', required=True, type=Path)
    parser.add_argument('--qa-result', required=True, type=Path)
    parser.add_argument('--expected-calibration-sha256', required=True)
    parser.add_argument('--expected-qa-result-sha256', required=True)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    assert not args.out.exists(), 'fresh output required'
    assert sha(args.calibration) == args.expected_calibration_sha256
    assert sha(args.qa_result) == args.expected_qa_result_sha256
    binding = json.loads((HERE / 'PREPARATION_BINDING.json').read_text())
    assert sha(__file__) == binding['native_probe_sha256']
    report = json.loads(args.qa_result.read_text())
    expected = validate_report(report, args.expected_calibration_sha256, binding)
    assert os.environ.get('PYTHONNOUSERSITE') == '1'
    assert os.environ.get('HCCL_DETERMINISTIC') == 'true'
    devices = os.environ['TASK_DEVICE'].split(',')
    assert len(devices) == 1 and devices[0].isdigit(), 'one scheduled NPU required'
    assert os.environ['ASCEND_RT_VISIBLE_DEVICES'] == os.environ['TASK_DEVICE']
    assert sys.version_info[:2] == (3, 12)
    assert sha(HERE / 'BASELINE_ENVIRONMENT_BOUND.json') == binding['baseline_environment_sha256']
    bound = json.loads((HERE / 'BASELINE_ENVIRONMENT_BOUND.json').read_text())
    modules = {n: importlib.import_module(n) for n in bound['modules']}
    identities = {n: {'file': str(Path(m.__file__).resolve()), 'version': getattr(m, '__version__', None)}
                  for n, m in modules.items()}
    assert identities == bound['modules'], 'wrong original runtime imports'
    for name, value in bound['env'].items():
        assert os.environ[name] == value, ('runtime environment', name)
    torch, torch_npu = modules['torch'], modules['torch_npu']
    assert not torch.npu.is_initialized()
    data = torch.load(args.calibration, map_location='cpu', weights_only=True, mmap=True)
    assert set(data) == set(expected)
    for name, (shape, dtype) in expected.items():
        value = data[name]
        assert list(value.shape) == shape and str(value.dtype) == dtype
        assert value.device.type == 'cpu' and bool(torch.isfinite(value).all())
        assert hashlib.sha256(value.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest() == report['qa_calibration']['tensors'][name]['sha256']
    args.out.mkdir()
    record = {'complete': False, 'rows': ROWS, 'N': OUTPUTS, 'K': INPUTS,
              'scope': 'Native standalone QA reproduces actual FULL QA, then finite 44-order-family queries; no whole-model/token acceptance',
              'script_sha256': sha(__file__), 'binding_sha256': sha(HERE / 'PREPARATION_BINDING.json'),
              'fixture_sha256': args.expected_calibration_sha256, 'qa_result_sha256': args.expected_qa_result_sha256,
              'modules': identities, 'environment': {n: os.environ[n] for n in bound['env']},
              'deterministic_level': 1, 'weight_format': 29, 'queries': []}
    def save():
        (args.out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
    def exact(a, b):
        return a.shape == b.shape and a.dtype == b.dtype and torch.equal(a.contiguous().view(torch.uint8), b.contiguous().view(torch.uint8))
    def host(t):
        return torch_npu.npu_format_cast(t, 2).cpu().contiguous()
    save()
    try:
        torch.set_num_threads(4)
        torch.use_deterministic_algorithms(True)
        torch_npu.npu.set_deterministic_level(1)
        assert torch.are_deterministic_algorithms_enabled()
        actual_npu_level = int(torch_npu._C._npu_get_deterministic_level())
        assert actual_npu_level == 1
        record['actual_torch_deterministic_algorithms_enabled'] = torch.are_deterministic_algorithms_enabled()
        record['actual_npu_deterministic_level'] = actual_npu_level
        save()
        torch.npu.set_device(0)
        torch.npu.config.allow_internal_format = True
        torch.npu.set_compile_mode(jit_compile=False)
        F = importlib.import_module('torch.nn.functional')
        real_x = data['normed'].npu()
        real_w = torch_npu.npu_format_cast(data['wq_a'].npu(), 29)
        assert torch_npu.get_npu_format(real_w) == 29
        with torch.inference_mode():
            real = host(F.linear(real_x, real_w))
            repeat = host(F.linear(real_x, real_w))
        record['actual_fixture_native_bit_equal'] = exact(real, data['native_qa'])
        record['actual_fixture_native_different'] = int((real != data['native_qa']).sum())
        record['actual_fixture_repeat_exact'] = exact(real, repeat)
        save()
        assert record['actual_fixture_repeat_exact'] and record['actual_fixture_native_bit_equal'], 'STOP: standalone F.linear did not reproduce actual FULL QA; finite order queries are unqualified'
        assert torch.are_deterministic_algorithms_enabled()
        assert int(torch_npu._C._npu_get_deterministic_level()) == 1
        record['finite_query_determinism_rechecked'] = True
        save()
        orders = make_orders()
        last = {q: torch.tensor([max(q, key=o.index) for o in orders]) for q in TRIPLES}
        assert len(orders) == 44
        assert len({tuple(last[q][i].item() for q in TRIPLES) for i in range(len(orders))}) == len(orders)
        candidates = torch.ones((ROWS, OUTPUTS // N_BLOCK, len(orders)), dtype=torch.bool)
        x = torch.ones((ROWS, INPUTS), dtype=torch.bfloat16, device='npu')
        with torch.inference_mode():
            for q in TRIPLES:
                flags = []
                for small in q:
                    rest = [k for k in q if k != small]
                    w = torch.zeros((OUTPUTS, INPUTS), dtype=torch.bfloat16)
                    w[:, rest[0] * K_BLOCK] = 1.0
                    w[:, rest[1] * K_BLOCK] = -1.0
                    w[:, small * K_BLOCK] = 2**-25
                    weight = torch_npu.npu_format_cast(w.npu(), 29)
                    actual = host(F.linear(x, weight))
                    again = host(F.linear(x, weight))
                    assert exact(actual, again), 'finite query repeat differs'
                    assert bool(((actual == 0) | (actual == 2**-25)).all()), 'finite serial cancellation model rejected'
                    assert exact(actual, actual[:, ::N_BLOCK].repeat_interleave(N_BLOCK, 1)), 'within-N16 nonuniform; family model rejected'
                    flags.append(actual[:, ::N_BLOCK] == 2**-25)
                bits = torch.stack(flags)
                assert bool((bits.sum(0) == 1).all()), 'not exactly one last K256 block'
                observed = torch.tensor(q)[bits.long().argmax(0)]
                candidates &= last[q][None, None, :] == observed[:, :, None]
                count = candidates.sum(2)
                record['queries'].append({'triple': q, 'min_candidates': int(count.min()), 'max_candidates': int(count.max())})
                save()
                assert bool((count > 0).all()), 'finite cyclic/block-order family rejected; do not force a family'
        assert bool((candidates.sum(2) == 1).all()), 'finite family remains ambiguous'
        selected = candidates.long().argmax(2)
        # Only small synthetic order IDs; never resave real model weight/calibration.
        record.update(complete=True, orders=orders, selected_by_row=selected.tolist(),
                      row_invariant=torch.equal(selected, selected[:1].expand_as(selected)),
                      selected_unique=selected.unique().tolist(),
                      interpretation='unique only within the tested 44-family, not all permutations or hardware reduction trees')
        save()
        print('NATIVE_QA_ORDER_RESULT', json.dumps({'complete': True, 'selected_unique': record['selected_unique'], 'row_invariant': record['row_invariant']}), flush=True)
    except Exception as exc:
        record['error'] = repr(exc)
        save()
        raise


if __name__ == '__main__':
    main()
