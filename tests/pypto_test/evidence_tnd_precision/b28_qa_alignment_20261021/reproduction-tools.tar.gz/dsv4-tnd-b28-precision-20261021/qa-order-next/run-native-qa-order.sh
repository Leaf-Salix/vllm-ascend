#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit required}"
[[ "$TASK_DEVICE" =~ ^[0-9]+$ ]]
calibration=${1:?remote query-calibration.pt required}
qa_result=${2:?QA-next result.json required}
calibration_sha=${3:?calibration SHA256 required}
qa_result_sha=${4:?QA-next result SHA256 required}
label=${5:?fresh result label required}
[[ "$label" =~ ^[a-z0-9-]+$ ]]
[[ "$calibration_sha" =~ ^[a-f0-9]{64}$ && "$qa_result_sha" =~ ^[a-f0-9]{64}$ ]]
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/vector-mte2-20261019-codex/full-csa-live-staging-v2/env.sh"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE" PYTHONNOUSERSITE=1 HCCL_DETERMINISTIC=true
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache CMAKE_BUILD_PARALLEL_LEVEL=4
here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
out="$here/results/$label"
test ! -e "$out"
mkdir -p "$here/results"
printf 'TASK_RUN_START %s\n' "$(date -Iseconds)"
trap 'printf "TASK_RUN_END %s\n" "$(date -Iseconds)"' EXIT
timeout 750s python "$here/native_qa_order_probe.py" --calibration "$calibration" --qa-result "$qa_result" --expected-calibration-sha256 "$calibration_sha" --expected-qa-result-sha256 "$qa_result_sha" --out "$out" > "$out-run.log" 2>&1
