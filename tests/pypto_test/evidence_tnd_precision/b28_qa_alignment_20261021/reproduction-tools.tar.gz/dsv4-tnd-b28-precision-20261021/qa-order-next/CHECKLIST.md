# 备用探针准备清单

本清单记录本地准备检查，不安排或授权新的硬件任务。

- [x] 阅读邻近T126次序探针及QA-next校准保存合同，保留原文件。
- [x] 固定T168/N1024/K4096/NZ29与原环境身份；FULL-QA复现失败先停止。
- [x] 原44家族/六triples保持；只报告有限资格。
- [x] `python3 check_cpu.py`：标准库模型/收据正负控制通过，无运行时import。
- [x] `bash -n run-native-qa-order.sh`通过。
- [x] QA-next实际确认两行QA BF16差异，尚未证明K-order根因；实际result的新增schema门禁通过。
- [x] 由实际stage preflight派生严格导入profile，保留原SDK与原7模块身份要求。
- [x] 补compiled/raw、TopK毒化恢复和所有graph guard硬门禁及负控。
- [ ] 主线程审阅后决定是否上传/运行；本目录未执行这些步骤。

- [x] 启动前显式开启Torch确定性并读取Torch/NPU实际getter；有限query前复核，实际F.linear门禁保留。
