#!/usr/bin/env bash
set -euo pipefail
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
exp="$base/b28-precision-20261021-codex"
job="$exp/whole-b28-next"
export PERF_BACKEND=native PERF_OUTPUT="$job/preflight-unused"
source "$job/env.sh"
export ASCEND_RT_VISIBLE_DEVICES='' TORCH_DEVICE_BACKEND_AUTOLOAD=0 B28_ACTIVE=0
export PYTHONPATH="$LOW_ACCEPTANCE_RUNTIME_PACKAGE:$job${PYTHONPATH:+:$PYTHONPATH}"
case "${1:-all}" in
  all) python "$exp/cpu_prepare_whole.py" bank > "$exp/cpu-bank-v4.log" 2>&1;;
  preflight) test -f "$exp/CPU_WHOLE_BANK_RECEIPT.json";;
  *) exit 2;;
esac
export B28_ACTIVE=1 B28_OUTPUT="$job/preflight-unused" ADMISSION_TRACE_DIR="$job/preflight-unused/trace"
python "$exp/cpu_prepare_whole.py" preflight > "$exp/cpu-whole-preflight-v4.log" 2>&1
