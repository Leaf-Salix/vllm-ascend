#!/usr/bin/env bash
set -euo pipefail
export QA_ONLY_RESULT=${1:?passing QA-only result.json required}
export QA_ONLY_RESULT_SHA256=${2:?passing QA-only result SHA256 required}
[[ "$QA_ONLY_RESULT_SHA256" =~ ^[a-f0-9]{64}$ ]]
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/vector-mte2-20261019-codex/full-csa-live-staging-v2/env.sh"
export SPMD_EXPERIMENT="$base/precision-overlap-20261020"
exp="$base/b28-precision-20261021-codex/full-fix-next"
export ASCEND_RT_VISIBLE_DEVICES='' PYTHONNOUSERSITE=1 HCCL_DETERMINISTIC=true
export PYPTO_PROG_BUILD_DIR="$exp/build" PYPTO_CACHE_DIR="$exp/cache"
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache CMAKE_BUILD_PARALLEL_LEVEL=4
python "$exp/preflight.py" > "$exp/preflight.json"
ccache -s > "$exp/ccache-before.txt"
timeout 750s python "$exp/compile_candidate.py" > "$exp/compile.log" 2>&1
