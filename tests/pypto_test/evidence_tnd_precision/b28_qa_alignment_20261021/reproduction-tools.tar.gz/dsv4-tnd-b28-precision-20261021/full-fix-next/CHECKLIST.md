# 本地准备检查单（2026-10-21）

- [x] 克隆正式 root/QKV；仅一处路由条件与一处 import 改动，反向还原 AST 精确一致。
- [x] 保留 eight-l1 precision 门禁；删除 DFX timing，readonly 检查先于成功标记。
- [x] QA-only 激活门禁对齐冻结 SOURCE_BINDING 与 helper manifest；没有真实 pass 收据时拒绝启用。
- [x] 私有注册使用真实 namespace/schema，复用原 workspace/prepare；原 order2560 和 64 ABI 未改。
- [x] 另一 agent 完成当前完整准备文件的静态审查；发现的 orchestration 别名路径错误已修正。
- [ ] QA-only 候选真实全168 QA 与控制输入验收通过（外部前提，当前未完成）。
- [ ] 原失败 tensor 的实际 SHA 已取得（外部前提，当前未读取远端文件）。
- [ ] 未来无设备完整 root 编译生成真实 compile-receipt。
- [ ] 未来完整 B28 precision-only 硬件验收。

仅可对本目录做标准库文件/AST 检查及 shell 语法解析；本轮不运行 CPU/native/NPU runner、编译器或上传任务。
