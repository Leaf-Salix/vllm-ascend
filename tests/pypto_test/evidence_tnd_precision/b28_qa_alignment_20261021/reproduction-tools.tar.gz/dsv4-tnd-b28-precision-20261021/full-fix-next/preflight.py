"""Check the original stage environment and the explicit QA-only activation receipt."""
import importlib
import json
import os
from pathlib import Path
import sys

from private_loader import HERE, private_identity, require_qa_only, sha

manifest = json.loads((HERE / 'MANIFEST.json').read_text())
assert all(sha(HERE / name) == digest for name, digest in manifest.items()), 'private preparation changed'
bound = json.loads((HERE / 'BASELINE_ENVIRONMENT_BOUND.json').read_text())
modules = {name: importlib.import_module(name) for name in bound['modules']}
observed = {name: {'file': str(Path(module.__file__).resolve()), 'version': getattr(module, '__version__', None)}
            for name, module in modules.items()}
assert observed == bound['modules']
assert sys.version_info[:2] == (3, 12) and os.environ['PYTHONNOUSERSITE'] == '1'
assert os.environ['HCCL_DETERMINISTIC'] == 'true'
for name, value in bound['env'].items():
    assert os.environ[name] == value, ('wrong original stage environment', name)
assert not modules['torch'].npu.is_initialized()
sys.path.insert(0, str(HERE / 'tools'))
from source_identity import source_identity
record = dict(modules=observed, environment={n: os.environ[n] for n in bound['env']},
              source=source_identity(), private_source=private_identity(),
              qa_only_activation=require_qa_only(), npu_initialized=False)
assert not modules['torch'].npu.is_initialized()
print(json.dumps(record, indent=2))
