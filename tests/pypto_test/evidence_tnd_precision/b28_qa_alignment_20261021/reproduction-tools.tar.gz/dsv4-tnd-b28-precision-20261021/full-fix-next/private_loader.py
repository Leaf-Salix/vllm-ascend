"""Load only the two private source copies; preserve original package dependencies."""
import hashlib
import importlib
import importlib.util
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def private_identity():
    proof = json.loads((HERE / 'SOURCE_PROOF.json').read_text())
    sources = {name: sha(HERE / name) for name in ('full_fix_root.py', 'full_fix_qkv.py')}
    assert sources['full_fix_root.py'] == proof['private_root_sha256']
    assert sources['full_fix_qkv.py'] == proof['private_qkv_sha256']
    return {'sources': sources, 'source_proof_sha256': sha(HERE / 'SOURCE_PROOF.json')}


def require_qa_only():
    path = Path(os.environ['QA_ONLY_RESULT']).resolve()
    expected_sha = os.environ['QA_ONLY_RESULT_SHA256']
    assert len(expected_sha) == 64 and all(c in '0123456789abcdef' for c in expected_sha)
    assert sha(path) == expected_sha, 'wrong QA-only activation receipt'
    result = json.loads(path.read_text())
    assert 'error' not in result and result['complete'] is True and result['pass'] is True
    assert result['staging_rows'] == 176 and result['tensor_abi'] == 3
    assert result['actual_torch_deterministic'] is True and result['actual_npu_deterministic_level'] == 1
    for key in ('native_component_full168_exact', 'base_two_observed_rows_exact',
                'candidate_eager_native_full168_exact', 'eager_capture_exact'):
        assert result['checks'][key] is True, key
    binding = result['binding']
    expected_binding = json.loads((HERE / 'QA_ONLY_SOURCE_BINDING.json').read_text())
    assert binding == expected_binding, 'QA-only source binding differs'
    preparation = json.loads((HERE / 'QA_ONLY_PREPARATION_BINDING.json').read_text())
    assert sha(HERE / 'QA_ONLY_SOURCE_BINDING.json') == preparation['source_binding_sha256']
    assert result['helper_manifest_sha256'] == preparation['helper_manifest_sha256']
    unit = path.parents[2]
    assert unit.name == 'qa-candidate-next' and path.parent.parent.name == 'results'
    compile_path = unit / 'compile-receipt.json'
    assert sha(compile_path) == result['compile_receipt_sha256']
    compiled = json.loads(compile_path.read_text())
    assert compiled['complete'] is True and compiled['no_NPU'] is True
    assert compiled['helper_manifest_sha256'] == preparation['helper_manifest_sha256']
    assert compiled['entry_source_sha256'] == preparation['entry_source_sha256']
    assert set(compiled['arms']) == {'base', 'packet'}
    assert all(arm['program_compiled'] is True and arm['kernel_abi_compiled'] is True
               and arm['orchestration_compiled'] is True for arm in compiled['arms'].values())
    assert (binding['rows'], binding['N'], binding['K']) == (168, 1024, 4096)
    assert binding['calibration_sha256'] == 'e543fc19c363d25f5c35406f744feffe57dd447ed715279ecf97dda2aef82494'
    assert binding['qa_result_sha256'] == '0e77f7eedb8f613cb3ff0852538ca998e722adadf80565e44add3065cf5f172d'
    assert binding['order_result_sha256'] == 'f5789e3c11c35c976a660690f211f720fb584c0702f6c4be2085bc506aa3f368'
    assert binding['formal_modules']['vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.qkv_precision126'] == json.loads((HERE / 'SOURCE_PROOF.json').read_text())['formal_qkv_sha256']
    assert set(result['cases']) == {'0', '1', '2', '3', '4'}
    for key, input_name in enumerate(('actual', '73001', 'actual', '73002', 'actual')):
        case = result['cases'][str(key)]
        assert case['input'] == input_name
        for flag in ('actual_raw_graph', 'output_poison_restored', 'poisoned_repeat_exact', 'readonly_and_outer_guards'):
            assert case[flag] is True, (key, flag)
        assert set(case['metrics']) == {'base', 'packet'}
        assert case['metrics']['packet']['bit_equal'] is True and case['metrics']['packet']['different'] == 0
    bound = json.loads((HERE / 'BASELINE_ENVIRONMENT_BOUND.json').read_text())
    assert result['modules'] == bound['modules']
    assert compiled['modules'] == bound['modules']
    return {'result_sha256': expected_sha, 'path': str(path),
            'helper_manifest_sha256': result['helper_manifest_sha256'],
            'compile_receipt_sha256': result['compile_receipt_sha256']}


def load_candidate():
    private_identity()
    proof = json.loads((HERE / 'SOURCE_PROOF.json').read_text())
    prefix = 'vllm_ascend.ops.pypto.'
    for module_name, key in (
        ('deepseek_v4_flash_csa_tnd_precision_spmd_overlap.decode_csa', 'formal_root_sha256'),
        ('deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.qkv_precision126', 'formal_qkv_sha256'),
    ):
        module = importlib.import_module(prefix + module_name)
        assert sha(module.__file__) == proof[key], ('formal dependency changed', module_name)
    modules = []
    for filename, module_name in (
        ('full_fix_qkv.py', 'deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.full_fix_qkv'),
        ('full_fix_root.py', 'deepseek_v4_flash_csa_tnd_precision_spmd_overlap.full_fix_root'),
    ):
        name = prefix + module_name
        assert name not in sys.modules, 'private module must be loaded once in a fresh process'
        spec = importlib.util.spec_from_file_location(name, HERE / filename)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        modules.append(module)
    assert modules[1].qkv_proj_rope is modules[0].qkv_proj_rope
    return modules[1]
