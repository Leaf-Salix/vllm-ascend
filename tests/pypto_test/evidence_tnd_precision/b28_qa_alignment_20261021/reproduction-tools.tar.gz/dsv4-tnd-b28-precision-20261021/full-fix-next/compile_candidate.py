"""Compile the private complete root only after a passing QA-only receipt."""
import json
import os
from pathlib import Path
import sys

import pypto
import pypto.torch
import simpler
import torch
from pypto.runtime import RunConfig
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program
from pypto.runtime.kernel_compiler import KernelCompiler
import vllm_ascend.ops.pypto as namespace

from private_loader import HERE, load_candidate, private_identity, require_qa_only, sha

assert os.environ['ASCEND_RT_VISIBLE_DEVICES'] == ''
assert not torch.npu.is_initialized()
activation = require_qa_only()
exp = Path(os.environ['SPMD_EXPERIMENT'])
namespace.__path__.insert(0, str(exp / 'src/vllm_ascend/ops/pypto'))
module = load_candidate()
entry = module.decode_csa_tp1_layer_test
assert not (HERE / 'compile-receipt.json').exists(), 'fresh compile receipt required'
entry.compile(config=RunConfig(platform='a2a3', save_kernels=True, save_kernels_dir=str(HERE / 'candidate-artifact')))
program = entry.specialize()
abi = kernel_abi_for_program(program, platform='a2a3', runtime='tensormap_and_ringbuffer')
_compile_impl(program, output_dir=str(HERE / 'candidate-kernel-artifact'), platform='a2a3', _kernel_abi=abi)
KernelCompiler().compile_orchestration('tensormap_and_ringbuffer', str(HERE / 'candidate-artifact/orchestration/_full_csa_tnd_prepacked.cpp'))
op = pypto.torch.register(entry, 'b28_full_fix_next::attention')
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.native_adapter import CSAOperators
original = CSAOperators.register()
assert len(op._schema.arguments) == 64
assert str(op._schema).split('(', 1)[1] == str(original.attention._schema).split('(', 1)[1]
record = dict(compiled=True, kernel_abi_pass=True, orchestration_compiled=True, schema=str(op._schema),
              pypto=pypto.__file__, simpler=simpler.__file__,
              **private_identity(), qa_only_activation=activation,
              helper_manifest_sha256=sha(HERE / 'MANIFEST.json'),
              formal_receipt_sha256=sha(exp / 'compile-full-csa-bf16layout.json'),
              npu_initialized_after=torch.npu.is_initialized())
assert record['npu_initialized_after'] is False
(HERE / 'compile-receipt.json').write_text(json.dumps(record, indent=2) + '\n')
print('PRIVATE_FULL_CSA_COMPILED', op._schema, flush=True)
