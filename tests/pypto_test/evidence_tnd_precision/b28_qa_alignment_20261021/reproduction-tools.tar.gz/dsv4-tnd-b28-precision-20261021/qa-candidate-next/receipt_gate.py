"""Actual QA receipt gate copied by AST from the reviewed order probe."""
ROWS, OUTPUTS, INPUTS = 168, 1024, 4096

def validate_report(report, fixture_sha, binding):
    assert 'error' not in report
    assert report.get('diagnostic_complete') is True
    assert report.get('readonly_after_diagnostic') is True
    assert report.get('debug_guards_pass') is True
    assert report['lengths'] == [6] * 28
    assert report['true_tokens'] == ROWS and report['physical_graph_tokens'] == ROWS
    assert report['layer'] == 4 and report['history'] == 131072
    assert report['helper_sha']['probe_csa.py'] == binding['qa_observer_probe_sha256']
    assert set(report['original_output_invariance']) == {'native', 'candidate'}
    for checks in report['original_output_invariance'].values():
        assert len(checks) == 8 and all((v is True for v in checks.values()))
    assert set(report['graphs']) == {'native', 'candidate'}
    for arm in ('native', 'candidate'):
        graph = report['graphs'][arm]
        assert graph['actual_acl_graph'] is True and graph['fullgraph'] is True
        assert graph['compiled_raw_equal'] is True
        assert graph['topk_poison_replay_restored'] is True
        assert graph['guards'] and all((value['status'] == 'PASS' for value in graph['guards'].values()))
        assert graph['true_tokens'] == ROWS and graph['graph_tokens'] == ROWS
    cal = report['qa_calibration']
    assert cal['sha256'] == fixture_sha
    assert cal['actual_fused_qr_input_dtype'] == 'torch.bfloat16'
    assert cal['native_weight_format'] == 29, 'this qualification is NZ29 only'
    expected = {'normed': ([ROWS, INPUTS], 'torch.bfloat16'), 'native_qa': ([ROWS, OUTPUTS], 'torch.bfloat16'), 'native_qr': ([ROWS, OUTPUTS], 'torch.int8'), 'native_qr_scale': ([ROWS, 1], 'torch.float32'), 'wq_a': ([OUTPUTS, INPUTS], 'torch.bfloat16'), 'gamma_cq': ([OUTPUTS], 'torch.bfloat16')}
    assert set(cal['tensors']) == set(expected)
    for name, (shape, dtype) in expected.items():
        meta = cal['tensors'][name]
        assert meta['shape'] == shape and meta['dtype'] == dtype
        assert len(meta['sha256']) == 64
    return expected
