# QA单因素备用准备清单

- [x] 参考T126既有QA-only helpers/编译器，使用直接调用而非复制数学。
- [x] 固定本次实际QA/calibration/order身份，原stage环境严格门禁。
- [x] 原正式helper整数AST次序、M64/M16覆盖与边界CPU检查。
- [x] Native实际次序全10752点比公式；5个拒绝控制。
- [x] AST语法及shell语法检查；无runtime导入/模型tensor读取。
- [ ] 父线程与独立review后决定是否无设备编译。
- [ ] 无设备program/kernelABI/orchestration通过，产生本次compile-receipt。
- [ ] 真实QA-only双臂、全168行及两seed回放门禁设备通过。
- [ ] 若设备通过，再另外评估完整CSA修正；当前正式路由不变。
