#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?one scheduled NPU required}"
[[ "$TASK_DEVICE" =~ ^[0-9]+$ ]]
calibration=${1:?remote calibration required}
qa_result=${2:?actual QA result required}
qa_stages=${3:?remote QA stages required}
qa_stages_sha=${4:?actual stages SHA256 required}
order_result=${5:?actual Native finite-order result required}
label=${6:?fresh output label required}
[[ "$qa_stages_sha" =~ ^[a-f0-9]{64}$ && "$label" =~ ^[a-z0-9-]+$ ]]
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/vector-mte2-20261019-codex/full-csa-live-staging-v2/env.sh"
here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
export SPMD_EXPERIMENT="$base/precision-overlap-20261020"
export ASCEND_RT_VISIBLE_DEVICES="$TASK_DEVICE" PYTHONNOUSERSITE=1 HCCL_DETERMINISTIC=true
export PYPTO_PROG_BUILD_DIR="$here/build" PYPTO_CACHE_DIR="$here/cache"
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache CMAKE_BUILD_PARALLEL_LEVEL=4
out="$here/results/$label"
test ! -e "$out"
mkdir -p "$here/results"
printf 'TASK_RUN_START %s\n' "$(date -Iseconds)"
trap 'printf "TASK_RUN_END %s\n" "$(date -Iseconds)"' EXIT
timeout 750s python "$here/probe_qa.py" --enable-packet-candidate --calibration "$calibration" --qa-result "$qa_result" --qa-stages "$qa_stages" --expected-qa-stages-sha256 "$qa_stages_sha" --order-result "$order_result" --out "$out" > "$out-run.log" 2>&1
