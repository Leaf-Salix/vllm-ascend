# T168 QA-only 次序单因素候选：仅本地准备

本目录不修改正式分流，不扩大 `tile_rows==126` 特例。未上传、未编译、未执行设备。
仅比较同一个真实 M168/N1024/K4096 QA投影的两种既有顺序：

| arm | 直接调用 | 保留内容 |
| --- | --- | --- |
| base | 正式 `q_proj_qa` | 当前T168自然K256序 |
| packet | 已有 `q_proj_qa_126` | 原group96/前9组/K512包内两块K256序 |

两个DSL入口只有被调helper不同，不复制或重写矩阵数学。均为3Tensor ABI：BF16 `[168,4096]`、
NZ29 BF16 `[1024,4096]`、FP32 staging `[176,1024]`。原M64/尾M16、单K256内部、
布局与累加边界不变；只在返回后按原QA物化边界把真实168行舍入BF16进行比较。
8个staging尾行不是额外请求，不是padding每请求至S6。本测试fixture自身为uniformS6，
也不能凭本单元证明ragged或整个TND调度。

## 启用资格与身份

`SOURCE_BINDING.json`固定两份正式helper源SHA、本次校准SHA `e543fc19…`、
QA result `0e77f7ee…`、Native次序 result `f5789e3c…`。
Native次序已观察到全168×64个N16映射与既有packet公式相同；本地CPU再次逐项复核。
仍必须显式 `--enable-packet-candidate` 且实际次序收据完整/确定性/实际FULL复现均通过，才能运行候选。
44族相同不代替下面的真实权重数值测试。

环境bound原样继承已修正的QA-order stage profile：严格 `tnd_full_precision` variant、
原7模块路径、CANN9.2/PTOAS/ATB、原PyPTO/Simpler，不沿用whole的overlap路径。
每次运行检查两正式helper实际加载的文件SHA、私有manifest与成功编译收据。
Torch确定性flag为True、实际NPU getter为1，HCCL=true；每个回放case前再次检查。

## 无设备编译入口（当前未执行）

```bash
bash compile.sh
```

编译脚本设置空可见设备、`PYTHONNOUSERSITE=1`、原checkout ccache和四路编译，
对两个program与kernel ABI分别编译，并编译实际orchestration，注册schema断言3参。
所有步骤必须保持NPU未初始化，成功后才产生 `compile-receipt.json`。
不存在该文件是当前仅准备状态的正常情况，不能复制旧收据冒充。

## 未来设备命令（当前不执行）

```bash
bash run.sh \
  /remote/qa-next-result/query-calibration.pt \
  /remote/qa-next-result/result.json \
  /remote/qa-next-result/stages.pt \
  ACTUAL_QA_STAGES_SHA256 \
  /remote/qa-order-result/result.json \
  qa-two-arm-v1
```

单卡调度应沿用外780秒、内750秒。脚本只执行，不自行提交任务。
需事先在远端记录QA-next实际`stages.pt`的SHA作为明确参数；不能复制模型权重/校准到本地。

硬门禁依次是：

1. 校准/QA报告/次序报告真实SHA；QA报告两臂原8输出不变、compiled/raw、TopK毒化恢复、
   所有graph guards PASS；校准tensor shape/dtype/finite/逐tensor SHA。
2. 同M/N/K/NZ29真实权重，独立Native `F.linear`两次逐byte一致，并全168行复现同次FULL QA。
3. base的row86/103逐byte复现同次`stages.pt`内PTO QA值；stages里的Native QA必须等于校准Native QA。
   不只核对差异比例或坐标。
4. packet输出全168×1024与Native逐byte一致；首差立即停止。
5. 两个QA根各自捕获一个真实raw NPUGraph。eager/capture逐byte比较，
   每次毒化整个176行输出后回放；A→seed73001→A→seed73002→A，
   两新BF16输入仍固定M168与同一真实权重，以同形状独立Native线性重复作为gold。
6. 每个case再毒化并重复回放，检查两arm自身重复一致；A恢复完整输出一致。
   每次检查输入及NZ29权重只读、输入/输出前后16行guard；候选任何新差异立即停止。

本测试不计时、不评估整体性能；raw full QA-root图不冒称vLLM FULL调度或整模型token验收。
新seed输入是固定生成的QA单元输入，不是额外真实整模型hidden或prompt。

## 本地准备检查

```bash
PYTHONDONTWRITEBYTECODE=1 python3 check_cpu.py
bash -n compile.sh run.sh
```

实际从两正式helper AST抽取并执行纯整数dense/tail次序部分，验证T168自然序与packet公式、
K256块排列完整、两M循环一致、真实168行覆盖和176行staging/guard边界。
实际Native次序收据10752点通过公式校验，并有5个错误次序收据拒绝控制。
两个wrapper AST仅helper调用不同。标准库检查不导入Torch/PyPTO，不编译或运行NPU，
不读取任何校准/模型tensor。`CPU_RESULT.json`不代表候选数值通过。
