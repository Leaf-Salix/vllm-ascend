"""Program + kernel ABI + orchestration compile, no NPU initialization."""
import json
import os
from pathlib import Path
import qualification as q

binding = q.check_files()
assert os.environ['ASCEND_RT_VISIBLE_DEVICES'] == ''
modules, identities = q.environment()
entries = q.load_entries(binding)
assert entries.BF16_WEIGHT_LAYOUT is not None, 'NZ29 BF16 layout required'
import pypto.torch
from pypto.runtime import RunConfig
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program
from pypto.runtime.kernel_compiler import KernelCompiler
here = Path(__file__).resolve().parent
receipt = {'complete': False, 'no_NPU': True, 'entry_source_sha256': q.sha(here/'qa_entries.py'),
           'helper_manifest_sha256': q.sha(here/'MANIFEST.json'), 'modules': identities, 'arms': {}}
assert not (here/'compile-receipt.json').exists()
for arm in ('base', 'packet'):
    name = 'qa_' + arm + '_test'
    entry = getattr(entries, name)
    out = here / ('qa-' + arm + '-artifact')
    entry.compile(config=RunConfig(platform='a2a3', save_kernels=True, save_kernels_dir=str(out)))
    program = entry.specialize()
    abi = kernel_abi_for_program(program, platform='a2a3', runtime='tensormap_and_ringbuffer')
    _compile_impl(program, output_dir=str(here/('qa-'+arm+'-kernel-artifact')), platform='a2a3', _kernel_abi=abi)
    KernelCompiler().compile_orchestration('tensormap_and_ringbuffer', str(out/'orchestration'/(name+'.cpp')))
    op = pypto.torch.register(entry, 'b28_qa_unit_compile::' + arm)
    assert len(op._schema.arguments) == 3
    receipt['arms'][arm] = {'program_compiled':True, 'kernel_abi_compiled':True, 'orchestration_compiled':True, 'schema':str(op._schema)}
    assert not modules['torch'].npu.is_initialized()
receipt['complete'] = True
(here/'compile-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('QA_UNIT_CPU_COMPILE',json.dumps(receipt),flush=True)
