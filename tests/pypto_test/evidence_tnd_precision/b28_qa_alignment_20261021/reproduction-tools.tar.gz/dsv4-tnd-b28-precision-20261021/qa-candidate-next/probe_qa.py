"""QA-only same-input raw full-root graph qualification; stop at first new mismatch."""
import argparse
import json
import os
from pathlib import Path
import qualification as q
from receipt_gate import validate_report

parser = argparse.ArgumentParser()
parser.add_argument('--calibration',type=Path,required=True)
parser.add_argument('--qa-result',type=Path,required=True)
parser.add_argument('--qa-stages',type=Path,required=True)
parser.add_argument('--expected-qa-stages-sha256',required=True)
parser.add_argument('--order-result',type=Path,required=True)
parser.add_argument('--enable-packet-candidate',action='store_true')
parser.add_argument('--out',type=Path,required=True)
args = parser.parse_args()
assert args.enable_packet_candidate, 'candidate disabled unless explicitly enabled after Native order qualification'
assert not args.out.exists()
binding = q.check_files()
for path,key in ((args.calibration,'calibration_sha256'),(args.qa_result,'qa_result_sha256'),(args.order_result,'order_result_sha256')):
    assert q.sha(path) == binding[key], ('wrong actual QA/order artifact',str(path))
assert q.sha(args.qa_stages) == args.expected_qa_stages_sha256
qa_report = json.loads(args.qa_result.read_text())
expected = validate_report(qa_report,binding['calibration_sha256'],binding)
order_report = json.loads(args.order_result.read_text())
q.validate_order(order_report,binding)
modules, identities = q.environment()
assert os.environ['TASK_DEVICE'].isdigit() and os.environ['ASCEND_RT_VISIBLE_DEVICES'] == os.environ['TASK_DEVICE']
torch, torch_npu = modules['torch'], modules['torch_npu']
entries = q.load_entries(binding)
assert entries.BF16_WEIGHT_LAYOUT is not None, 'NZ29 BF16 layout required'
receipt_path = q.HERE/'compile-receipt.json'
receipt = json.loads(receipt_path.read_text())
assert receipt['complete'] is True and receipt['no_NPU'] is True
assert receipt['entry_source_sha256'] == q.sha(q.HERE/'qa_entries.py')
assert receipt['helper_manifest_sha256'] == q.sha(q.HERE/'MANIFEST.json')
assert receipt['modules'] == identities and set(receipt['arms']) == {'base','packet'}
assert all(v['program_compiled'] and v['kernel_abi_compiled'] and v['orchestration_compiled'] for v in receipt['arms'].values())
data = torch.load(args.calibration,map_location='cpu',weights_only=True,mmap=True)
assert set(data) == set(expected)
for name,(shape,dtype) in expected.items():
    t=data[name]
    assert list(t.shape)==shape and str(t.dtype)==dtype and t.device.type=='cpu' and bool(torch.isfinite(t).all())
    import hashlib
    assert hashlib.sha256(t.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest() == qa_report['qa_calibration']['tensors'][name]['sha256']
stages = torch.load(args.qa_stages,map_location='cpu',weights_only=True,mmap=True)
def exact(a,b):
    return a.shape==b.shape and a.dtype==b.dtype and torch.equal(a.contiguous().view(torch.uint8),b.contiguous().view(torch.uint8))
assert exact(stages['native']['qa'],data['native_qa'][[86,103]].float()), 'stages do not share actual FULL Native QA'
assert exact(stages['pto']['qa'],stages['pto']['qa'].bfloat16().float()), 'observed QA is not BF16 boundary'
assert stages['pto']['qa'].shape == (2,1024)
args.out.mkdir()
record={'complete':False,'pass':False,'scope':'private QA-only M168/N1024/K4096; not whole CSA or token acceptance; raw full QA-root graph, not vLLM FULL scheduler proof',
        'binding':binding,'helper_manifest_sha256':q.sha(q.HERE/'MANIFEST.json'),'compile_receipt_sha256':q.sha(receipt_path),
        'qa_stages_sha256':args.expected_qa_stages_sha256,'modules':identities,'checks':{},'cases':{},'staging_rows':176,'tensor_abi':3}
def save():
    (args.out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
def metric(a,b):
    mismatch=a!=b
    return {'bit_equal':exact(a,b),'different':int(mismatch.sum()),'first_coordinates':mismatch.nonzero()[:8].tolist(),'max_abs':float((a.float()-b.float()).abs().max())}
def deterministic():
    assert torch.are_deterministic_algorithms_enabled()
    assert int(torch_npu._C._npu_get_deterministic_level())==1
save()
try:
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True)
    torch_npu.npu.set_deterministic_level(1)
    deterministic()
    record['actual_torch_deterministic']=torch.are_deterministic_algorithms_enabled()
    record['actual_npu_deterministic_level']=int(torch_npu._C._npu_get_deterministic_level())
    torch.npu.set_device(0)
    torch.npu.config.allow_internal_format=True
    torch.npu.set_compile_mode(jit_compile=False)
    from torch.nn import functional as F
    def host(t):return torch_npu.npu_format_cast(t,2).cpu().contiguous()
    weight=torch_npu.npu_format_cast(data['wq_a'].npu(),29)
    assert torch_npu.get_npu_format(weight)==29 and exact(host(weight),data['wq_a'])
    # Independent Native component must first reproduce every actual FULL QA byte.
    actual_x=data['normed'].npu()
    with torch.inference_mode():
        native_actual=host(F.linear(actual_x,weight));native_repeat=host(F.linear(actual_x,weight))
    assert exact(native_actual,native_repeat) and exact(native_actual,data['native_qa']), 'standalone Native failed actual FULL QA qualification'
    record['checks']['native_component_full168_exact']=True;save()
    import pypto.torch
    pypto.torch.init()
    ops={arm:pypto.torch.register(getattr(entries,'qa_'+arm+'_test'),'b28_qa_order_unit::'+arm) for arm in ('base','packet')}
    assert all(len(op._schema.arguments)==3 for op in ops.values())
    input_owner=torch.full((200,4096),37.,device='npu',dtype=torch.bfloat16)
    x=input_owner[16:184]
    outputs={arm:torch.full((208,1024),37.,device='npu',dtype=torch.float32) for arm in ops}
    views={arm:v[16:192] for arm,v in outputs.items()}
    x.copy_(actual_x)
    expected_input=data['normed']
    def guard():
        assert exact(x.cpu(),expected_input), 'input mutated'
        assert bool((input_owner[:16]==37).all()) and bool((input_owner[184:]==37).all())
        for v in outputs.values():assert bool((v[:16]==37).all()) and bool((v[192:]==37).all())
        assert exact(host(weight),data['wq_a'])
    def launch(arm):ops[arm](x,weight,views[arm])
    def collect():
        result={arm:views[arm].cpu()[:168].bfloat16() for arm in ops}
        assert all(bool(torch.isfinite(t).all()) for t in result.values())
        guard()
        return result
    with torch.inference_mode():
        for arm in ops:launch(arm)
        torch.npu.synchronize()
        eager=collect()
        assert exact(eager['base'][[86,103]].float(),stages['pto']['qa']), 'base does not reproduce actual two-row QA failure'
        assert exact(eager['packet'],native_actual), 'packet first difference at eager actual fixture'
        record['checks']['base_two_observed_rows_exact']=True
        record['checks']['candidate_eager_native_full168_exact']=True;save()
        stream=torch.npu.Stream();stream.wait_stream(torch.npu.current_stream())
        graphs={}
        with torch.npu.stream(stream):
            for arm in ops:
                graph=torch.npu.NPUGraph()
                with torch.npu.graph(graph,stream=stream):launch(arm)
                graphs[arm]=graph
            torch.npu.synchronize()
            captured=collect()
            assert all(exact(captured[arm],eager[arm]) for arm in ops), 'eager/capture mismatch'
            record['checks']['eager_capture_exact']=True
            seed_inputs={}
            for seed in (73001,73002):
                generator=torch.Generator(device='cpu').manual_seed(seed)
                seed_inputs[seed]=(torch.randn((168,4096),generator=generator,dtype=torch.float32)*0.25).bfloat16()
            for step,key in enumerate(('actual',73001,'actual',73002,'actual')):
                deterministic()
                cpu_x=data['normed'] if key=='actual' else seed_inputs[key]
                expected_input=cpu_x
                x.copy_(cpu_x)
                with torch.inference_mode():gold=host(F.linear(x,weight));repeat=host(F.linear(x,weight))
                assert exact(gold,repeat), 'new-input Native repeat differs'
                if key=='actual':assert exact(gold,data['native_qa'])
                for value in views.values():value.fill_(float('nan'))
                for arm in ops:graphs[arm].replay()
                torch.npu.synchronize()
                actual=collect()
                assert exact(x.cpu(),cpu_x), 'input mutated'
                for value in views.values():value.fill_(float('nan'))
                for arm in ops:graphs[arm].replay()
                torch.npu.synchronize()
                repeated=collect()
                assert all(exact(actual[arm],repeated[arm]) for arm in ops), 'poisoned raw repeat differs'
                metrics={arm:metric(v,gold) for arm,v in actual.items()}
                record['cases'][str(step)]={'input':str(key),'metrics':metrics,'actual_raw_graph':True,'output_poison_restored':True,'poisoned_repeat_exact':True,'readonly_and_outer_guards':True}
                save()
                assert exact(actual['packet'],gold), 'STOP: packet first difference at '+str(key)
                if key=='actual':
                    assert exact(actual['base'],eager['base']), 'base actual fixture did not restore on A/B/A'
                    assert exact(actual['packet'],eager['packet']), 'candidate actual fixture did not restore on A/B/A'
            record['pass']=True;record['complete']=True;save()
except Exception as exc:
    record['error']=repr(exc);save();raise
print('QA_UNIT_RESULT',record['pass'],flush=True)
