"""Identity and finite-order qualification shared by the private QA unit helpers."""
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROWS, COLS, WIDTH, PAD = 168, 1024, 4096, 176


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def packet_order(n16):
    group = n16 * 16 // 96
    if group >= 9:
        return tuple(range(16))
    return tuple(((group // 2 + (7 - k // 2 if group % 2 else k // 2)) % 8) * 2 + k % 2 for k in range(16))


def validate_order(record, binding):
    assert record['complete'] is True
    assert record['rows'] == ROWS and record['N'] == COLS and record['K'] == WIDTH
    assert record['actual_fixture_native_bit_equal'] is True and record['actual_fixture_repeat_exact'] is True
    assert record['actual_torch_deterministic_algorithms_enabled'] is True
    assert record['actual_npu_deterministic_level'] == 1 and record['finite_query_determinism_rechecked'] is True
    assert record['fixture_sha256'] == binding['calibration_sha256']
    assert record['qa_result_sha256'] == binding['qa_result_sha256']
    assert record['script_sha256'] == binding['order_probe_sha256']
    orders, selected = record['orders'], record['selected_by_row']
    assert len(orders) == 44 and all(sorted(x) == list(range(16)) for x in orders)
    assert len(selected) == ROWS and all(len(row) == 64 for row in selected)
    for row in selected:
        for n16, index in enumerate(row):
            assert type(index) is int and 0 <= index < len(orders)
            assert tuple(orders[index]) == packet_order(n16), 'Native finite-family order does not qualify existing packet helper'


def check_files():
    manifest = json.loads((HERE / 'MANIFEST.json').read_text())
    assert all(sha(HERE / name) == expected for name, expected in manifest.items()), 'private helper changed'
    return json.loads((HERE / 'SOURCE_BINDING.json').read_text())


def environment():
    bound = json.loads((HERE / 'BASELINE_ENVIRONMENT_BOUND.json').read_text())
    modules = {name: importlib.import_module(name) for name in bound['modules']}
    observed = {name: {'file': str(Path(module.__file__).resolve()), 'version': getattr(module, '__version__', None)} for name, module in modules.items()}
    assert observed == bound['modules'], 'original stage imports do not match'
    assert sys.version_info[:2] == (3, 12) and os.environ['PYTHONNOUSERSITE'] == '1'
    for name, expected in bound['env'].items():
        assert os.environ[name] == expected, ('wrong original stage env', name)
    assert os.environ['CMAKE_BUILD_PARALLEL_LEVEL'] == '4'
    assert os.environ['HCCL_DETERMINISTIC'] == 'true'
    assert not modules['torch'].npu.is_initialized()
    return modules, observed


def load_entries(binding):
    import vllm_ascend.ops.pypto as namespace
    namespace.__path__.insert(0, str(Path(os.environ['SPMD_EXPERIMENT']) / 'src/vllm_ascend/ops/pypto'))
    for name, expected in binding['formal_modules'].items():
        module = importlib.import_module(name)
        assert sha(module.__file__) == expected, ('formal helper changed', name)
    return importlib.import_module('qa_entries')
