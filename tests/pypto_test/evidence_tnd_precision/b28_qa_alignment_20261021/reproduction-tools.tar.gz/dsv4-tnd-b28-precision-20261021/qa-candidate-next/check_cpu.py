"""Read actual entry/helper AST; standard-library checks only, never import runtime."""
import ast
from collections import Counter
import copy
import importlib.util
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORKSPACE=HERE.parents[2]
REPO=WORKSPACE/'vllm-ascend-nalinaly-tnd-20261008-codex'
# Keep report discovery explicit; no neighboring checkout inventory.
assert REPO.is_dir()
spec=importlib.util.spec_from_file_location('qualification_cpu',HERE/'qualification.py')
q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
binding=json.loads((HERE/'SOURCE_BINDING.json').read_text())
base=REPO/'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision/qkv_proj_rope.py'
packet=REPO/'vllm_ascend/ops/pypto/deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout/qkv_precision126.py'
for name,path in zip(binding['formal_modules'],(base,packet)):
    assert q.sha(path)==binding['formal_modules'][name]
entries=ast.parse((HERE/'qa_entries.py').read_text())
functions=[n for n in entries.body if isinstance(n,ast.FunctionDef)]
assert [n.name for n in functions]==['qa_base_test','qa_packet_test']
for fn,target in zip(functions,('q_proj_qa','q_proj_qa_126')):
    assert len(fn.args.args)==3 and len(fn.body)==5
    call=fn.body[3].value
    assert ast.unparse(call)==target+'(x, w, output, 0, rows)'
# Inverse-normalize only the called helper/name: wrappers otherwise identical.
a,b=copy.deepcopy(functions)
a.name=b.name='same'
a.body[3].value.func.id=b.body[3].value.func.id='same_helper'
assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
const={'D':4096,'QR_NATIVE_K_BLOCKS':16,'QR_NATIVE_N_GROUP':96,'QR_NATIVE_SHIFT_GROUPS':9,
       'QR_NATIVE_SHIFT_MIN_ROWS':96,'QR_NATIVE_SHIFT_MAX_ROWS':240,'QR_NATIVE_SHIFT_ROW_STEP':48,
       'QR_NATIVE_PAIR_SHIFT':3,'QR_NATIVE_PACKET_BLOCKS':2,'QR_NATIVE_PACKETS':8}
actual_traces={}
for path,fn_name in ((base,'q_proj_qa'),(packet,'q_proj_qa_126')):
    fn=next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name==fn_name)
    actual_traces[fn_name]={}
    for induction,result in (('dense_k','dense_k_order'),('db','qr_k_order')):
        loop=next(n for n in ast.walk(fn) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id==induction)
        cut=next(i for i,n in enumerate(loop.body) if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id in ('dense_d0','qr_d0') for x in n.targets))
        scalar=ast.Module(body=copy.deepcopy(loop.body[:cut]),type_ignores=[])
        code=compile(ast.fix_missing_locations(scalar),str(path),'exec')
        traces=[]
        for n16 in range(64):
            trace=[]
            for k in range(16):
                context={**const,'tile_rows':168,'qr_native_group':n16*16//96,induction:k}
                exec(code,context)
                trace.append(context[result])
            assert sorted(trace)==list(range(16))
            if fn_name=='q_proj_qa':assert trace==list(range(16))
            else:assert tuple(trace)==q.packet_order(n16)
            traces.append(trace)
        actual_traces[fn_name][induction]=traces
    assert actual_traces[fn_name]['dense_k']==actual_traces[fn_name]['db']
# Source-loop M coverage, staging/guard boundaries, no K256 interior edits.
coverage=Counter(r for t in range(0,128,64) for r in range(t,t+64))
coverage.update(r for t in (128,144,160) for r in range(t,min(t+16,168)))
assert coverage==Counter({r:1 for r in range(168)})
assert 16+176==192 and 208-192==16 and 16+168==184 and 200-184==16
actual_order_path=HERE.parent/'qa-order-next/device-native-qa-order-v1/result.json'
order=json.loads(actual_order_path.read_text())
assert q.sha(actual_order_path)==binding['order_result_sha256']
q.validate_order(order,binding)
for mode in ('wrong_family','not_complete','repeat_false','wrong_fixture','determinism_false'):
    changed=copy.deepcopy(order)
    if mode=='wrong_family':changed['selected_by_row'][86][0]=(changed['selected_by_row'][86][0]+1)%44
    if mode=='not_complete':changed['complete']=False
    if mode=='repeat_false':changed['actual_fixture_repeat_exact']=False
    if mode=='wrong_fixture':changed['fixture_sha256']='0'*64
    if mode=='determinism_false':changed['actual_torch_deterministic_algorithms_enabled']=False
    try:q.validate_order(changed,binding)
    except AssertionError:continue
    raise AssertionError(('bad order receipt accepted',mode))
for p in HERE.glob('*.py'):ast.parse(p.read_text())
probe=(HERE/'probe_qa.py').read_text()
assert probe.index('native_component_full168_exact') < probe.index("for arm in ops:launch(arm)")
assert probe.index('base_two_observed_rows_exact') < probe.index('graphs={}')
assert "--enable-packet-candidate" in probe and "(73001,73002)" in probe
result={'status':'PASS_LOCAL_PREPARATION_ONLY','no_runtime_import_no_compile_no_NPU':True,
        'entry_count':2,'tensor_ABI_expected':3,'wrapper_only_call_difference':True,
        'actual_formal_scalar_AST_executed':True,'native_order_actual_receipt_10752_formula_equal':True,
        'base_and_packet_dense_tail_consistent':True,'real_rows_exact_once':168,'staging_capacity':176,
        'bad_order_receipt_controls':5,'full_model_token_acceptance_NOT_executed':True}
(HERE/'CPU_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
