#!/usr/bin/env bash
set -euo pipefail
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/vector-mte2-20261019-codex/full-csa-live-staging-v2/env.sh"
here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
export SPMD_EXPERIMENT="$base/precision-overlap-20261020"
export ASCEND_RT_VISIBLE_DEVICES='' PYTHONNOUSERSITE=1 HCCL_DETERMINISTIC=true
export PYPTO_PROG_BUILD_DIR="$here/build" PYPTO_CACHE_DIR="$here/cache"
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache CMAKE_BUILD_PARALLEL_LEVEL=4
ccache -s > "$here/ccache-before.txt"
timeout 750s python "$here/compile_qa.py" > "$here/compile.log" 2>&1
