"""No-device checks for the fixed B28 job; validates existing remote assets."""
import argparse
import hashlib
import json
import os
import runpy
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check(bank, arm):
    job = Path(__file__).resolve().parent
    manifest = json.loads((job / 'helper-manifest.json').read_text())['files']
    for name, digest in manifest.items():
        assert sha(job / name) == digest, name
    source = Path(os.environ['SOURCE_ROOT'])
    assert sha(source.parent / 'manifest.json') == sha(job / 'source-manifest.json')
    frozen = json.loads((job / 'source-manifest.json').read_text())['files']
    runtime = json.loads((job / 'runtime77.json').read_text())
    assert len(runtime) == 77
    for name, digest in runtime.items():
        assert frozen[name] == sha(source / name) == digest, name
    # These are the actual archived extended-cache harness files, rather than
    # the older offline_pd files in the current formal checkout.
    for name in ('run.py', 'connector.py'):
        assert sha(source / 'tests/pypto_test/offline_pd' / name) == sha(job / 'reference-offline_pd' / name)
    runpy.run_path(str(job / 'source_preflight.py'), run_name='__main__')
    assert os.environ['B28_ACTIVE'] == '1'
    from low_acceptance_20261001 import mixed
    from offline_pd.worker import OfflineNPUWorker
    from offline_pd.observer import OfflineCSAObserver
    assert mixed.run_batches.__module__ == 'mixed_b28'
    assert OfflineNPUWorker.load_model.__module__ == 'sitecustomize'
    assert OfflineCSAObserver.offline_begin_observation.__module__ == 'sitecustomize'
    plan = json.loads((bank / 'plan.json').read_text())
    audit = json.loads((bank / 'audit.json').read_text())
    assert len(plan['cases']) == len(audit['cases']) == 28 and audit['status'] == 'PASS'
    assert audit['plan_sha256'] == sha(bank / 'plan.json')
    proof = json.loads((job / 'bank-input-8k-qualified.json').read_text())
    assert audit['source_plan_sha256'] == proof['bank_plan_sha256']
    original = Path(audit['source_bank'])
    assert sha(original / 'plan.json') == proof['bank_plan_sha256']
    assert plan['cases'] == json.loads((original / 'plan.json').read_text())['cases'][:28]
    for case, row in zip(plan['cases'], audit['cases'], strict=True):
        assert case['key'] == row['key']
        assert (bank / case['key']).resolve() == original / case['key']
        assert sha(bank / case['tokens']) == row['tokens_sha256']
        folder = bank / case['key'] / 'tp0'
        assert sha(folder / 'manifest.json') == row['manifest_sha256']
        assert (folder / 'cache.safetensors').stat().st_size == row['cache_bytes']
    if arm == 'pto':
        ready = json.loads((job / 'results/native1/READY_GOLD.json').read_text())
        assert ready['status'] == 'READY_NATIVE1' and ready['tokens_checked'] == 172032
        assert ready['bank_plan_sha256'] == sha(bank / 'plan.json')
        assert ready['helper_manifest_sha256'] == sha(job / 'helper-manifest.json')
        assert ready['source_manifest_sha256'] == sha(source.parent / 'manifest.json')
        for name, digest in ready['gold_files'].items():
            assert sha(job / 'results/native1' / name) == digest, name
    for name in ('PYTHONNOUSERSITE', 'ASCEND_HOME_PATH', 'PTOAS_ROOT', 'CCACHE_DIR'):
        assert os.environ.get(name), name
    assert os.environ['PYTHONNOUSERSITE'] == '1' and os.environ['CMAKE_BUILD_PARALLEL_LEVEL'] == '4'
    config = {'backend': arm, 'batch': 28, 'max_num_seqs': 28, 'capture_sizes': [6, 168],
              'tp': 1, 'dp': 16, 'ep': 16, 'decode_tokens': 192, 'warmup_tokens': 192,
              'rounds': 2, 'blocks': 22000, 'max_num_batched_tokens': 400,
              'variant': 'pkg:deepseek_v4_flash_csa_tnd_precision_spmd_overlap',
              'bank': str(bank.resolve()), 'bank_plan_sha256': sha(bank / 'plan.json'),
              'source_manifest_sha256': sha(source.parent / 'manifest.json'),
              'helper_manifest_sha256': sha(job / 'helper-manifest.json'),
              'pure_dsl': True, 'stage_hooks': False, 'performance': False,
              'env': {k: os.environ[k] for k in ('PYTHONNOUSERSITE', 'ASCEND_HOME_PATH', 'PTOAS_ROOT', 'CCACHE_DIR', 'CMAKE_BUILD_PARALLEL_LEVEL')}}
    return config


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--bank', type=Path, required=True)
    parser.add_argument('--arm', choices=('native', 'pto'), required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    result = check(args.bank, args.arm)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print('B28_NO_DEVICE_PREFLIGHT_OK')
