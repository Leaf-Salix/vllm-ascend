# B28独立harness本机检查（2026-10-21）

- [x] `.venv311/bin/python reports/dsv4-tnd-b28-precision-20261021/whole-b28-next/test_local.py`：12项通过；完整16rank正控制；token首差、事件首差、真实input首差、Native轮间首差、Native gold改写、重复key和假T168负控制；77源SHA和Python语法。
- [x] wrapper模拟：执行真实wrapper副本，CLI/env均由本机临时mock替代；验证decode激活hooks、审计关闭hooks、固定28/[6,168]及拒绝15卡/重复卡。未执行远端bootstrap。
- [x] bank头模拟：验证前28条只链接、dtype错误、MTP缺失和`..`路径负控制；未读取真实远端bank。
- [x] `bash -n env.sh run-arm.sh`：语法通过；正式checkout `git status --short`为空。
- [ ] 源码独立审查：两arm、真实28活跃/T168、所有token、事件和完整生成窗口分开状态；无正式源修改。
- [ ] 227只读bank header预检：本次尚未执行。
- [ ] Native1/PTO硬件任务：本次尚未提交，先取得已有13阶段任务结果。
