#!/usr/bin/env bash
set -euo pipefail
: "${TASK_DEVICE:?task-submit16-device allocation required}"
IFS=',' read -r -a b28_devices <<< "$TASK_DEVICE"
[[ "${#b28_devices[@]}" == 16 ]] || { echo 'Exactly16 TASK_DEVICE entries required' >&2; exit 2; }
b28_seen=,
for b28_device in "${b28_devices[@]}"; do
  [[ "$b28_device" =~ ^[0-9]+$ && "$b28_seen" != *",$b28_device,"* ]] || { echo 'TASK_DEVICE must contain unique numeric entries' >&2; exit 2; }
  b28_seen+="$b28_device,"
done
arm=${1:?native or pto}
case "$arm" in native) label=native1;; pto) label=pto1;; *) exit 2;; esac
job=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$job/env.sh"
out="$job/results/$label"
mkdir -p "$job/results"
mkdir "$out"
export PERF_BACKEND="$arm" PERF_OUTPUT="$out" B28_OUTPUT="$out"
export B28_ACTIVE=1
export ADMISSION_TRACE_DIR="$out/trace" B28_NATIVE="$job/results/native1"
export ASCEND_OPP_PATH
ASCEND_OPP_PATH=$(python "$SOURCE_ROOT/tests/pypto_test/dsv4_hca_prepare_opp.py" --destination "$out/opp_env")
export PYPTO_PROG_BUILD_DIR="$out/build" ASCEND_CACHE_PATH="$out/ascend-cache"
export ASCEND_PROCESS_LOG_PATH="$out/ascend" VLLM_CACHE_ROOT="$out/vllm-cache"
mkdir -p "$ASCEND_PROCESS_LOG_PATH" "$ASCEND_CACHE_PATH"
python "$job/preflight.py" --bank "$job/bank28" --arm "$arm" --output "$out/configuration.json"
cd "$out"
timeout --signal=TERM --kill-after=20s 750s python "$SOURCE_ROOT/tests/pypto_test/offline_pd/run.py" decode \
  --output "$out" --backend "$arm" --pto-attention csa --mixed-requests --batch 28 --decode-dp 16 \
  --max-num-batched-tokens 400 --weight-nz-mode 2 --deterministic --port 30981 \
  --gpu-memory-utilization 0.95 --event-work-mode 1 --bank "$job/bank28" --decode-tokens 192 \
  --graph-mode full_decode_only --capture-sizes 6 168 > "$out/launch.log" 2>&1
export TORCH_DEVICE_BACKEND_AUTOLOAD=0
export B28_ACTIVE=0
unset PYTHONPATH
if [[ "$arm" == native ]]; then
  python "$job/audit.py" --native "$out" --output "$out/READY_GOLD.json"
else
  python "$job/audit.py" --native "$B28_NATIVE" --candidate "$out" --output "$out/audit.json"
fi
