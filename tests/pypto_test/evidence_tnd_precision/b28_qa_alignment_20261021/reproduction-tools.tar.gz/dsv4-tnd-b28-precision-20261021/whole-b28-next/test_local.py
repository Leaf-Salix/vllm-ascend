"""Local CPU positive/negative controls; creates only temporary JSON fixtures."""
import ast
import copy
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

import audit
import prepare_bank
from mixed_b28 import compare_requests


JOB = Path(__file__).resolve().parent


def requests():
    return [{'key': f'h8192_q{i:02d}', 'output_token_ids': [100 + i] * 192,
             'events': [[5, 3]] * 48, 'preemptions': 0} for i in range(28)]


def trace(rank):
    active = {'rank': rank, 'execute_index': 4, 'forward_index': 0, 'active': True,
              'graph_mode': 'FULL', 'padded_tokens': 168, 'actual_tokens': 168,
              'dp_tokens_across_ranks': [168] * 16,
              'keys': [f'h8192_q{i:02d}' for i in range(28)],
              'query_bounds': list(range(0, 169, 6)), 'query_lengths': [6] * 28,
              'scheduled_tokens': [6] * 28, 'input_ids': [3] * 168,
              'positions': list(range(168)), 'seq_lens': [8400] * 28,
              'padded_input_ids': [3] * 168, 'padded_positions': list(range(168)),
              'new_keys': [], 'finished_keys': [], 'preempted_keys': []}
    tail = {'rank': rank, 'execute_index': 5, 'forward_index': 1, 'active': False,
            'graph_mode': 'FULL', 'padded_tokens': 6, 'actual_tokens': 0,
            'dp_tokens_across_ranks': [6] * 16, 'query_bounds': [0],
            'padded_input_ids': [0] * 6, 'padded_positions': [0] * 6}
    tail.update({k: [] for k in ('keys', 'query_lengths', 'scheduled_tokens', 'input_ids', 'positions',
                                'seq_lens', 'new_keys', 'finished_keys', 'preempted_keys')})
    return [active, tail]


def make_arm(root, backend):
    root.mkdir()
    config = {'backend': backend, 'batch': 28, 'max_num_seqs': 28, 'capture_sizes': [6, 168],
              'tp': 1, 'dp': 16, 'ep': 16, 'decode_tokens': 192, 'warmup_tokens': 192, 'rounds': 2,
              'pure_dsl': True, 'stage_hooks': False, 'performance': False,
              'bank_plan_sha256': 'fixture-bank', 'helper_manifest_sha256': 'fixture-helpers',
              'source_manifest_sha256': 'fixture-source'}
    (root / 'configuration.json').write_text(json.dumps(config))
    runtime = {'deterministic_level': 1, 'torch_deterministic': True, 'hccl_deterministic': 'true',
               'dynamic_eplb': False, 'cann_event_work_mode': 1,
               'engine': {'async_scheduling': True, 'disable_hybrid_kv_cache_manager': False,
                          'cudagraph_mode': 'FULL_DECODE_ONLY'},
               'scheduler': {'max_num_seqs': 28, 'max_num_batched_tokens': 400, 'max_num_scheduled_tokens': 168}}
    implementations = [{'kind': 'csa', 'implementation': backend,
                        'runtime_class': 'x.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.service'}] * 21
    implementations += [{'kind': 'hca', 'implementation': 'native'}] * 20
    qualification = {'ready': True, 'actual_reselections': 1, 'validated_reuses': 1,
                     'metadata_sha256': '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'}
    if backend == 'pto':
        qualification.update(root_abi_tensors=64, root_namespace='dsv4_csa_tnd_precision_spmd_overlap::attention',
                             single_root_counts={str(i): {'6': {'warmup': 1, 'capture': 1},
                                                         '168': {'warmup': 1, 'capture': 1}} for i in range(21)})
    for rank in range(16):
        rounds = []
        for iteration in range(2):
            folder = root / 'trace' / f'round{iteration}'
            folder.mkdir(parents=True, exist_ok=True)
            (folder / f'rank{rank}.trace.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in trace(rank)))
            rounds.append({'iteration': iteration, 'requests': requests(),
                           'observation': [{'admission_trace': {'complete': True}, 'full_pto_qualification': qualification}]})
        data = {'rank': rank, 'backend': backend, 'complete': True, 'implementations': [implementations],
                'worker_runtime_config': [runtime], 'rounds': rounds}
        (root / f'rank{rank}.b28.json').write_text(json.dumps(data))


class AcceptanceControls(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.native = Path(self.tmp.name) / 'native1'
        self.pto = Path(self.tmp.name) / 'pto1'
        make_arm(self.native, 'native')
        make_arm(self.pto, 'pto')
        (self.native / 'READY_GOLD.json').write_text(json.dumps(audit.audit(self.native)))

    def mutate_report(self, root, change):
        path = root / 'rank7.b28.json'
        data = json.loads(path.read_text())
        change(data)
        path.write_text(json.dumps(data))

    def test_complete_native1_and_candidate(self):
        self.assertEqual(audit.audit(self.native)['status'], 'READY_NATIVE1')
        result = audit.audit(self.native, self.pto)
        self.assertEqual(result['status'], 'PASS_TOKEN_AND_PROTOCOL')
        self.assertEqual(result['tokens_checked'], 172032)
        self.assertEqual(sum(r['tokens_compared'] for r in result['comparisons']), 172032)

    def test_candidate_token_difference_is_identified(self):
        self.mutate_report(self.pto, lambda d: d['rounds'][1]['requests'][12]['output_token_ids'].__setitem__(86, 999))
        result = audit.audit(self.native, self.pto)
        self.assertEqual(result['status'], 'TOKEN_DIFFERENCE')
        diff = next(x for x in result['comparisons'] if not x['tokens_equal'])
        self.assertEqual((diff['rank'], diff['round'], diff['first_token_difference']['position']), (7, 1, 86))

    def test_changed_native_gold_is_rejected(self):
        self.mutate_report(self.native, lambda d: d['rounds'][0]['requests'][0]['output_token_ids'].__setitem__(0, 999))
        with self.assertRaises(AssertionError):
            audit.audit(self.native, self.pto)

    def test_events_are_separate_from_tokens(self):
        self.mutate_report(self.pto, lambda d: d['rounds'][0]['requests'][1]['events'][0].__setitem__(1, 4))
        result = audit.audit(self.native, self.pto)
        self.assertTrue(result['tokens_equal'])
        self.assertFalse(result['events_equal'])
        self.assertEqual(result['status'], 'TOKENS_EQUAL_PROTOCOL_DIFFERENCE')

    def test_native_repeated_round_is_not_self_comparison(self):
        self.mutate_report(self.native, lambda d: d['rounds'][1]['requests'][0]['output_token_ids'].__setitem__(0, 999))
        self.assertEqual(audit.audit(self.native)['status'], 'TOKEN_DIFFERENCE')

    def test_full_input_difference_is_separate(self):
        path = self.pto / 'trace/round1/rank7.trace.jsonl'
        rows = [json.loads(s) for s in path.read_text().splitlines()]
        rows[0]['input_ids'][103] = 777
        path.write_text(''.join(json.dumps(r) + '\n' for r in rows))
        result = audit.audit(self.native, self.pto)
        self.assertTrue(result['tokens_equal'])
        self.assertFalse(result['full_input_trace_equal'])
        self.assertEqual(result['first_trace_difference']['fields'], ['input_ids'])

    def test_duplicate_request_is_rejected(self):
        bad = copy.deepcopy(requests())
        bad[-1]['key'] = bad[0]['key']
        with self.assertRaises(AssertionError):
            compare_requests(bad, requests())

    def test_bucket168_without_actual168_is_rejected(self):
        path = self.pto / 'trace/round1/rank7.trace.jsonl'
        rows = [json.loads(s) for s in path.read_text().splitlines()]
        rows[0]['actual_tokens'] = 126
        path.write_text(''.join(json.dumps(r) + '\n' for r in rows))
        with self.assertRaisesRegex(AssertionError, 'No true active28/T168'):
            audit.audit(self.native, self.pto)

    def test_runtime77_and_python_syntax(self):
        repo = JOB.parents[2] / 'vllm-ascend-nalinaly-tnd-20261008-codex'
        bindings = json.loads((JOB / 'runtime77.json').read_text())
        self.assertEqual(len(bindings), 77)
        for name, digest in bindings.items():
            self.assertEqual(hashlib.sha256((repo / name).read_bytes()).hexdigest(), digest, name)
        for path in JOB.rglob('*.py'):
            ast.parse(path.read_text(), filename=str(path))

    def test_real_wrapper_activates_only_fixed_decode(self):
        wrapper = Path(self.tmp.name) / 'wrapper'
        wrapper.mkdir()
        shutil.copyfile(JOB / 'run-arm.sh', wrapper / 'run-arm.sh')
        (wrapper / 'env.sh').write_text('export SOURCE_ROOT="$job/fake-source"\nexport B28_ACTIVE=0\n')
        commands = wrapper / 'bin'
        commands.mkdir()
        python = commands / 'python'
        python.write_text('''#!/usr/bin/env python3
import json, os, sys
from pathlib import Path
args = sys.argv[1:]
with open(os.environ['B28_SMOKE_LOG'], 'a') as stream:
    stream.write(json.dumps({'args': args, 'active': os.environ.get('B28_ACTIVE')}) + '\\n')
if args[0].endswith('dsv4_hca_prepare_opp.py'):
    print('/unused/mock-opp')
elif args[0].endswith('preflight.py') or args[0].endswith('audit.py'):
    Path(args[args.index('--output') + 1]).write_text('{}')
elif args[0].endswith('offline_pd/run.py'):
    assert os.environ['B28_ACTIVE'] == '1'
else:
    raise AssertionError(args)
''')
        python.chmod(0o755)
        timeout = commands / 'timeout'
        timeout.write_text('#!/usr/bin/env bash\nshift 3\nexec "$@"\n')
        timeout.chmod(0o755)
        log = wrapper / 'commands.jsonl'
        environment = dict(os.environ, PATH=str(commands) + os.pathsep + os.environ['PATH'],
                           TASK_DEVICE=','.join(map(str, range(16))), B28_SMOKE_LOG=str(log))
        subprocess.run(['bash', str(wrapper / 'run-arm.sh'), 'native'], env=environment, check=True,
                       capture_output=True, text=True)
        rows = [json.loads(s) for s in log.read_text().splitlines()]
        decode = next(r for r in rows if r['args'][0].endswith('offline_pd/run.py'))
        self.assertEqual(decode['active'], '1')
        args = decode['args']
        self.assertEqual(args[args.index('--batch') + 1], '28')
        self.assertEqual(args[args.index('--capture-sizes') + 1:], ['6', '168'])
        self.assertEqual(args[args.index('--backend') + 1], 'native')
        final = next(r for r in rows if r['args'][0].endswith('audit.py'))
        self.assertEqual(final['active'], '0')
        self.assertTrue((wrapper / 'results/native1/READY_GOLD.json').is_file())

    def test_wrapper_rejects_insufficient_or_duplicate_devices(self):
        for devices in (','.join(map(str, range(15))), ','.join(['0'] * 16)):
            result = subprocess.run(['bash', str(JOB / 'run-arm.sh'), 'native'],
                                    env=dict(os.environ, TASK_DEVICE=devices), capture_output=True, text=True)
            self.assertEqual(result.returncode, 2)

    def test_bank_header_dtype_mtp_and_path_controls(self):
        source = Path(self.tmp.name) / 'source-bank'
        source.mkdir()
        model = source / 'model'
        model.mkdir()
        (model / 'config.json').write_text('{}')
        cases, proofs = [], []
        for i in range(40):
            key = f'h8192_q{i:02d}'
            tokens = source / f'{key}.tokens.json'
            tokens.write_text('[1, 2, 3, 4]')
            folder = source / key / 'tp0'
            folder.mkdir(parents=True)
            entry = {'logical_blocks': [0], 'shape': [32, 1], 'dtype': 'torch.bfloat16', 'compress_ratio': 1}
            manifest = {'history': 3, 'p_dp_rank': i % 16, 'p_tp_rank': 0,
                        'entries': {'target': entry, 'mtp': entry}}
            (folder / 'manifest.json').write_text(json.dumps(manifest))
            (folder / 'cache.safetensors').write_bytes(b'header-only-control')
            cases.append({'key': key, 'tokens': tokens.name, 'history': 3,
                          'decode_suffix_tokens': 1, 'p_dp_rank': i % 16})
            proofs.append({'key': key, 'history': 3, 'tokens_sha256': prepare_bank.sha(tokens),
                           'manifest_sha256': prepare_bank.sha(folder / 'manifest.json'), 'cache_bytes': 19})
        plan = {'model': str(model), 'cases': cases}
        (source / 'plan.json').write_text(json.dumps(plan))
        proof = source / 'proof.json'
        proof.write_text(json.dumps({'bank_plan_sha256': prepare_bank.sha(source / 'plan.json'), 'cases': proofs}))

        class Header:
            dtype, names = 'BF16', {'target', 'mtp'}
            def __enter__(self): return self
            def __exit__(self, *args): pass
            def keys(self): return self.names
            def get_slice(self, name): return self
            def get_shape(self): return [1, 32, 1]
            def get_dtype(self): return self.dtype

        modules = {'safetensors': types.SimpleNamespace(safe_open=lambda *args, **kwargs: Header()),
                   'offline_pd': types.ModuleType('offline_pd'),
                   'offline_pd.prefix': types.SimpleNamespace(cache_contract=lambda config: {'target': 1, 'mtp': 1})}
        with patch.dict(sys.modules, modules):
            derived = Path(self.tmp.name) / 'bank28'
            result = prepare_bank.prepare(source, derived, proof)
            self.assertEqual(len(result['cases']), 28)
            self.assertTrue((derived / 'h8192_q00').is_symlink())
            self.assertFalse((derived / 'h8192_q28').exists())
            Header.dtype = 'F32'
            with self.assertRaises(AssertionError):
                prepare_bank.prepare(source, Path(self.tmp.name) / 'wrong-dtype', proof)
            Header.dtype, Header.names = 'BF16', {'target'}
            with self.assertRaises(AssertionError):
                prepare_bank.prepare(source, Path(self.tmp.name) / 'missing-mtp', proof)
            Header.names = {'target', 'mtp'}
            plan['cases'][0]['tokens'] = '../escape.json'
            (source / 'plan.json').write_text(json.dumps(plan))
            proof.write_text(json.dumps({'bank_plan_sha256': prepare_bank.sha(source / 'plan.json'), 'cases': proofs}))
            with self.assertRaises(AssertionError):
                prepare_bank.prepare(source, Path(self.tmp.name) / 'bad-path', proof)


if __name__ == '__main__':
    unittest.main(verbosity=2)
