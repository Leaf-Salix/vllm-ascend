"""Derive exactly 28 read-only request references; never copy cache payloads."""
import argparse
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def prepare(source, destination, proof_path):
    from safetensors import safe_open
    from offline_pd.prefix import cache_contract

    source, destination = source.resolve(), destination.absolute()
    proof = json.loads(proof_path.read_text())
    plan = json.loads((source / 'plan.json').read_text())
    assert sha(source / 'plan.json') == proof['bank_plan_sha256']
    assert len(plan['cases']) == len(proof['cases']) == 40
    chosen = plan['cases'][:28]
    assert [c['key'] for c in chosen] == [f'h8192_q{i:02d}' for i in range(28)]
    contract = cache_contract(json.loads((Path(plan['model']) / 'config.json').read_text()))
    rows = []
    for case, frozen in zip(chosen, proof['cases'][:28], strict=True):
        key = case['key']
        assert key == frozen['key'] and case['decode_suffix_tokens'] == 1
        relative = Path(case['tokens'])
        assert not relative.is_absolute() and '..' not in relative.parts
        tokens_file = source / case['tokens']
        folder = source / key / 'tp0'
        manifest = json.loads((folder / 'manifest.json').read_text())
        assert sha(tokens_file) == frozen['tokens_sha256']
        assert sha(folder / 'manifest.json') == frozen['manifest_sha256']
        assert len(json.loads(tokens_file.read_text())) == case['history'] + 1
        assert manifest['history'] == case['history'] == frozen['history']
        assert manifest['p_dp_rank'] == case['p_dp_rank'] and manifest['p_tp_rank'] == 0
        cache = folder / 'cache.safetensors'
        assert cache.stat().st_size == frozen['cache_bytes']
        with safe_open(cache, framework='pt', device='cpu') as payload:
            assert set(payload.keys()) == set(manifest['entries']) == set(contract)
            for name, entry in manifest['entries'].items():
                tensor = payload.get_slice(name)
                assert tensor.get_shape() == [len(entry['logical_blocks']), *entry['shape']]
                dtypes = {'torch.bfloat16': 'BF16', 'torch.float32': 'F32', 'torch.float16': 'F16',
                          'torch.int8': 'I8', 'torch.uint8': 'U8', 'torch.int32': 'I32', 'torch.int64': 'I64'}
                assert tensor.get_dtype() == dtypes[entry['dtype']]
                assert entry['compress_ratio'] == contract[name]
        rows.append({'key': key, 'history': case['history'], 'tokens_sha256': sha(tokens_file),
                     'manifest_sha256': sha(folder / 'manifest.json'), 'cache_bytes': cache.stat().st_size})
    destination.mkdir(exist_ok=False)
    for case in chosen:
        token = destination / case['tokens']
        token.parent.mkdir(parents=True, exist_ok=True)
        token.symlink_to(source / case['tokens'])
        (destination / case['key']).symlink_to(source / case['key'], target_is_directory=True)
    plan['cases'] = chosen
    plan['inherited_prefix_bank'] = str(source)
    plan['b28_source_plan_sha256'] = proof['bank_plan_sha256']
    (destination / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    audit = {'status': 'PASS', 'cases': rows, 'source_bank': str(source),
             'source_plan_sha256': proof['bank_plan_sha256'], 'plan_sha256': sha(destination / 'plan.json'),
             'scope': 'first28 exact fixed Native suffix cache references; target/draft header qualification; payloads not copied or re-prefilled'}
    (destination / 'audit.json').write_text(json.dumps(audit, indent=2) + '\n')
    return audit


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--bank', type=Path, required=True)
    args = parser.parse_args()
    result = prepare(args.source, args.bank, Path(__file__).with_name('bank-input-8k-qualified.json'))
    print(json.dumps(result, indent=2))
