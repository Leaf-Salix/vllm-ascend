# 8K/B28真实token补验：待审独立副本

本目录仅做本地准备。**尚未连接227、读取远端bank头、编译、提交或运行NPU任务。先收回已有13阶段任务，再决定执行。** 不修改正式实现、77份数学源、既有bank或Native金值；不创建Native2，不跑128K。

固定配置为TP1、DP=EP16，每rank只提交原8K bank前28个不同请求，`batch=28`使实际归档runner的`max_num_seqs=28`，FULL capture `[6,168]`，22000 blocks、token预算400，greedy/DSpark出5验6、NZ2、level1/HCCL确定性、EPLB关闭。每个arm一次模型加载，warm192＋1轮192；Native1和PTO分两项16卡任务，各自内层750秒、调度上限780秒。每臂共有172,032个输出token。

`reference-offline_pd/{run.py,connector.py}` 是只读源码参考，SHA与实际overlap3399文件清单相符。执行仍从同一冻结snapshot导入它们，preflight拒绝其它版本。当前正式checkout的旧connector不支持相同的扩展suffix加载，不用它替换归档入口。

`prepare_bank.py` 只创建新28条plan及只读符号链接，保留每请求原始key/tokens/history/cache内容并赋予新plan SHA；检查所有target＋MTP名称/shape/dtype/compression、owner、token和manifest SHA。原fixed cache按每请求logical page序列化，没有B40批维：`fixed_bank.prepare`将suffix计入history、`decode_suffix_tokens=1`，`start_load_kv`映射新分配的pages，因此本方案不需要重跑问题suffix prefill。`384/768`等历史统计/行数不作为bank可复用资格；实际header不符立即停止。原始cache仍来自旧Native计算，此处只授予“共享同一冻结初态”身份。

必要改动都在本目录：

- `env.sh/run-arm.sh`：新输出目录、只允许native/pto两个arm，固定28/[6,168]，PTO预检要求本场景Native1的READY；不含任何提交命令。
- `sitecustomize.py`：复用已验收trace hook与静态资格桥，仅移除内部Tensor hook、加两轮独立trace目录、固定B28 driver；每个文本替换数量见`SITECUSTOMIZE_DELTA.json`。`B28_ACTIVE`防止普通CPU检查自动加载远端bootstrap。
- `mixed_b28.py`：保存全部请求token及接受事件；Native正式轮对warm轮真实token比较，PTO按同轮Native1比较，token首差保存请求/位置后停止。事件差异继续保存完整两轮token，由审计单独报告并停止后续。
- `audit.py`：全16rank、每轮28个唯一key、192token、零抢占；完整联合生成窗口/设备input/入场事件严格比较，只有进程局部execute_index可忽略；严格空尾单审。每rank每轮必须真正出现28活跃、168真实行、FULL168及一致DP向量。单独给`tokens_equal/events_equal/full_input_trace_equal`，事件或轨迹差而token同为`TOKENS_EQUAL_PROTOCOL_DIFFERENCE`。
- `qualified_wkv.py`和trace/window helper保持原字节，77份正式运行源只记录SHA，不复制或修改数学实现。纯DSL根和21CSA/20Native HCA实际资格保留。

未来在227的新实验目录恢复本目录后，CPU准备步骤如下；这些命令本次**未执行**：

```bash
job=<new-absolute-experiment-directory>/whole-b28-next
export PERF_BACKEND=native PERF_OUTPUT="$job/preflight-unused"
source "$job/env.sh"
export TORCH_DEVICE_BACKEND_AUTOLOAD=0 ASCEND_RT_VISIBLE_DEVICES=""
python "$job/prepare_bank.py" \
  --source "$base/low-acceptance-20261010/banks/fixed8192" --bank "$job/bank28"
export B28_ACTIVE=1
python "$job/preflight.py" --bank "$job/bank28" --arm native --output "$job/preflight-native.json"
```

`SOURCE_ROOT`固定使用原`precision-overlap-20261020/whole-overlap-v1/snapshot/source`。完整manifest、77源、实际connector/run入口、工具链和模型75分片全部核对；仅28case链接不会复制约2GB cache。若原bank失败，应先报告具体header/身份失败。本方案没有提供重建suffix的捷径，也没有证明新prefill能在15分钟内完成。

后续经审查和阶段A结果允许后，分别通过既有task-submit协议分配16卡，任务入口为`bash <job>/run-arm.sh native`，成功产生`results/native1/READY_GOLD.json`后才运行`bash <job>/run-arm.sh pto`。每次显式传入原环境的`PYTHONNOUSERSITE/PTOAS_ROOT/ASCEND_HOME_PATH/CCACHE_DIR/CMAKE_BUILD_PARALLEL_LEVEL=4`，device auto、ptoas0.63、max-time780；新任务不覆盖任何旧输出。不在普通shell直接执行这两个入口。

GPU执行时间预计小于原8K/B40 warm＋三轮方案，trace采用已运行的完整输入取证方式；启动/静态选择/新T168产物可能额外耗时，因此只有750/780秒硬上限，没有新环境的完成时长保证。超时记为环境/任务未完成，不算token失败。

这个补验授予8K真实模型T168资格。它不能证明全128K/B28、任意输入或内部逐bit一致，也不能将合成B28首差直接写成真实token失败。
