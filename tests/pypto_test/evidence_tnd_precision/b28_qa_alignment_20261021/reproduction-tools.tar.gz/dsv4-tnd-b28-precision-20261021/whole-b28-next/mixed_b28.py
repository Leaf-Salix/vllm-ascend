"""Fixed B28, one warm192 plus one192; distinct Native1/PTO task outputs."""
import json
import os
import time
from pathlib import Path


def compare_requests(actual, reference):
    expected = [f'h8192_q{i:02d}' for i in range(28)]
    for rows in (actual, reference):
        assert [r['key'] for r in rows] == expected
        assert len({r['key'] for r in rows}) == 28
        assert all(len(r['output_token_ids']) == 192 and r['preemptions'] == 0 for r in rows)
        assert all(r['events'] and all(0 <= accepted <= proposed <= 5 for proposed, accepted in r['events']) for r in rows)
    first_token = first_event = None
    for a, b in zip(actual, reference, strict=True):
        if first_token is None:
            first_token = next(({'key': a['key'], 'position': i, 'actual': x, 'native': y}
                                for i, (x, y) in enumerate(zip(a['output_token_ids'], b['output_token_ids'], strict=True)) if x != y), None)
        if first_event is None and a['events'] != b['events']:
            first_event = {'key': a['key'], 'actual': a['events'], 'native': b['events']}
    return {'tokens_equal': first_token is None, 'events_equal': first_event is None,
            'tokens_compared': 28 * 192, 'first_token_difference': first_token,
            'first_event_difference': first_event}


def run_batches(llm, args, cases):
    from offline_pd.batch import generate_aligned_batch
    from offline_pd.run import write_json
    from low_acceptance_20261001.mixed import wait_for_generation_peers
    from vllm import SamplingParams

    assert args.batch == 28 and args.decode_tokens == 192 and len(cases) == 28
    assert [c['key'] for c in cases] == [f'h8192_q{i:02d}' for i in range(28)]
    implementations = llm.collective_rpc('offline_attention_implementations')
    assert len(implementations) == 1
    for worker in implementations:
        csa = [v for v in worker if v['kind'] == 'csa']
        hca = [v for v in worker if v['kind'] == 'hca']
        assert len(csa) == 21 and len(hca) == 20
        assert all(v['implementation'] == 'native' for v in hca)
        assert all(v['implementation'] == args.backend for v in csa)
        if args.backend == 'pto':
            assert all(v['runtime_class'].endswith('.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.service') for v in csa)
    reference = None
    if args.backend == 'pto':
        reference = json.loads((Path(os.environ['B28_NATIVE']) / f'rank{args.rank}.b28.json').read_text())
        assert reference['backend'] == 'native' and reference['complete']
    report = {'rank': args.rank, 'backend': args.backend, 'batch': 28, 'decode_tokens': 192,
              'implementations': implementations, 'worker_runtime_config': args.worker_runtime_config,
              'rounds': [], 'complete': False, 'scope': 'warm192 plus one192; full raw input traces; no internal Tensor hooks or performance claims'}
    log = args.output / f'request_stats_rank{args.rank}.jsonl'
    for iteration in range(2):
        prompts = [{'prompt_token_ids': json.loads((args.bank / c['tokens']).read_text())} for c in cases]
        params = [SamplingParams(temperature=0, max_tokens=192, ignore_eos=True,
                                extra_args={'kv_transfer_params': {'offline_key': c['key']}}) for c in cases]
        before = len(log.read_text().splitlines()) if log.exists() else 0
        llm.collective_rpc('offline_begin_observation', args=(iteration,))
        started = time.monotonic()
        outputs = generate_aligned_batch(llm, prompts, params)
        wait_for_generation_peers(args.output, args.rank, iteration)
        observation = llm.collective_rpc('offline_end_observation')
        events = [json.loads(s) for s in log.read_text().splitlines()[before:]]
        assert len(events) == len({r['key'] for r in events}) == len(outputs) == 28
        by_key = {r['key']: r for r in events}
        rows = []
        for case, output in zip(cases, outputs, strict=True):
            record = by_key[case['key']]
            assert record['output_tokens'] == 192
            assert record['request_id'] == output.request_id or record['request_id'].startswith(output.request_id + '-')
            rows.append({'key': case['key'], 'output_token_ids': list(output.outputs[0].token_ids),
                         'events': record['events'], 'preemptions': record['preemptions']})
        if reference is not None:
            expected = reference['rounds'][iteration]['requests']
        else:
            expected = rows if iteration == 0 else report['rounds'][0]['requests']
        compared = compare_requests(rows, expected)
        report['rounds'].append({'iteration': iteration, 'elapsed_with_cache_io_seconds': time.monotonic() - started,
                                 'requests': rows, 'observation': observation, 'comparison': compared})
        write_json(args.output / f'rank{args.rank}.b28.json', report)
        if not compared['tokens_equal']:
            write_json(args.output / f'rank{args.rank}.TOKEN_STOP.json', compared)
            raise RuntimeError('B28_TOKEN_FIRST_DIFFERENCE')
        # Event/trace differences are reported separately after both token arrays
        # are available. They must never be mislabeled as token differences.
    report['complete'] = True
    write_json(args.output / f'rank{args.rank}.b28.json', report)
