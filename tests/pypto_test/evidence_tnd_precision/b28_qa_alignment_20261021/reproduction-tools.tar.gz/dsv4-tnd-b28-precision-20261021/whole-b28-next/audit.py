"""CPU audit: token, event and full-generation input statuses are separate."""
import argparse
import hashlib
import json
from pathlib import Path

from generation_window import generation_window
from mixed_b28 import compare_requests


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_arm(root, backend):
    config = json.loads((root / 'configuration.json').read_text())
    assert config['backend'] == backend and config['batch'] == config['max_num_seqs'] == 28
    assert config['capture_sizes'] == [6, 168] and config['tp'] == 1 and config['dp'] == config['ep'] == 16
    assert config['decode_tokens'] == config['warmup_tokens'] == 192 and config['rounds'] == 2
    assert config['pure_dsl'] and not config['stage_hooks'] and not config['performance']
    assert not list(root.glob('*.TOKEN_STOP.json'))
    reports = []
    for rank in range(16):
        data = json.loads((root / f'rank{rank}.b28.json').read_text())
        assert data['complete'] and data['rank'] == rank and data['backend'] == backend
        assert [r['iteration'] for r in data['rounds']] == [0, 1]
        assert len(data['implementations']) == len(data['worker_runtime_config']) == 1
        runtime = data['worker_runtime_config'][0]
        assert runtime['deterministic_level'] == 1 and runtime['torch_deterministic']
        assert runtime['hccl_deterministic'] == 'true' and not runtime['dynamic_eplb']
        assert runtime['cann_event_work_mode'] == 1
        assert runtime['engine']['async_scheduling'] and not runtime['engine']['disable_hybrid_kv_cache_manager']
        assert runtime['scheduler']['max_num_seqs'] == 28 and runtime['scheduler']['max_num_batched_tokens'] == 400
        assert runtime['scheduler']['max_num_scheduled_tokens'] >= 168
        assert runtime['engine']['cudagraph_mode'] == 'FULL_DECODE_ONLY'
        worker = data['implementations'][0]
        csa = [v for v in worker if v['kind'] == 'csa']
        hca = [v for v in worker if v['kind'] == 'hca']
        assert len(csa) == 21 and len(hca) == 20
        assert all(v['implementation'] == backend for v in csa)
        assert all(v['implementation'] == 'native' for v in hca)
        if backend == 'pto':
            assert all(v['runtime_class'].endswith('.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.service') for v in csa)
        for iteration, row in enumerate(data['rounds']):
            compare_requests(row['requests'], row['requests'])
            observation = row['observation']
            assert len(observation) == 1 and observation[0]['admission_trace']['complete']
            qualification = observation[0]['full_pto_qualification']
            assert qualification['ready'] and qualification['actual_reselections'] == 1
            assert qualification['validated_reuses'] > 0
            assert qualification['metadata_sha256'] == '863a1e5daffc54aec0e9e8afb9f809f1bc6f4b3a2487e440615f3c942f36c602'
            if backend == 'pto':
                assert qualification['root_abi_tensors'] == 64
                assert qualification['root_namespace'] == 'dsv4_csa_tnd_precision_spmd_overlap::attention'
                assert len(qualification['single_root_counts']) == 21
                for sizes in qualification['single_root_counts'].values():
                    for size in ('6', '168'):
                        assert sizes[size]['warmup'] > 0 and sizes[size]['capture'] > 0
        reports.append(data)
    windows = []
    stats = []
    for iteration in range(2):
        traces = [[json.loads(line) for line in (root / 'trace' / f'round{iteration}' / f'rank{rank}.trace.jsonl').read_text().splitlines()]
                  for rank in range(16)]
        prefix, tails = generation_window(traces)
        counts = []
        for rank, rows in enumerate(prefix):
            covered = [r for r in rows if r['active'] and r['actual_tokens'] == 168
                       and len(r['keys']) == 28 and r['query_lengths'] == [6] * 28
                       and r['padded_tokens'] == 168 and r['graph_mode'] == 'FULL'
                       and r['dp_tokens_across_ranks'] == [168] * 16]
            assert covered, (backend, iteration, rank, 'No true active28/T168 FULL forward')
            counts.append(len(covered))
        windows.append(prefix)
        stats.append({'round': iteration, 'full168_forwards_per_rank': counts, 'tails': tails,
                      'raw_actual_input_rows': sum(r['actual_tokens'] for rows in prefix for r in rows)})
    return config, reports, windows, stats


def compare_windows(actual, native):
    for iteration, (a_ranks, b_ranks) in enumerate(zip(actual, native, strict=True)):
        for rank, (a_rows, b_rows) in enumerate(zip(a_ranks, b_ranks, strict=True)):
            if len(a_rows) != len(b_rows):
                return {'round': iteration, 'rank': rank, 'reason': 'generation_window_lengths',
                        'actual': len(a_rows), 'native': len(b_rows)}
            for step, (a, b) in enumerate(zip(a_rows, b_rows, strict=True)):
                fields = [k for k in sorted(set(a) | set(b)) if k != 'execute_index' and a.get(k) != b.get(k)]
                if fields:
                    return {'round': iteration, 'rank': rank, 'step': step, 'fields': fields,
                            'actual': a, 'native': b}
    return None


def audit(native, candidate=None):
    if candidate is not None:
        ready = json.loads((native / 'READY_GOLD.json').read_text())
        assert ready['status'] == 'READY_NATIVE1'
        for name, digest in ready['gold_files'].items():
            assert sha(native / name) == digest, name
    nc, nr, nw, ns = load_arm(native, 'native')
    differences = []
    if candidate is None:
        for rank in range(16):
            differences.append({'rank': rank, **compare_requests(nr[rank]['rounds'][1]['requests'], nr[rank]['rounds'][0]['requests'])})
        trace_difference = compare_windows([nw[1]], [nw[0]])
        configs_equal = True
        stats = ns
    else:
        cc, cr, cw, stats = load_arm(candidate, 'pto')
        configs_equal = {k: v for k, v in cc.items() if k != 'backend'} == {k: v for k, v in nc.items() if k != 'backend'}
        assert configs_equal
        for rank in range(16):
            for iteration in range(2):
                differences.append({'rank': rank, 'round': iteration,
                                    **compare_requests(cr[rank]['rounds'][iteration]['requests'], nr[rank]['rounds'][iteration]['requests'])})
        trace_difference = compare_windows(cw, nw)
    tokens_equal = all(d['tokens_equal'] for d in differences)
    events_equal = all(d['events_equal'] for d in differences)
    protocol_equal = events_equal and trace_difference is None
    result = {'status': ('READY_NATIVE1' if candidate is None else 'PASS_TOKEN_AND_PROTOCOL') if tokens_equal and protocol_equal
                        else ('TOKEN_DIFFERENCE' if not tokens_equal else 'TOKENS_EQUAL_PROTOCOL_DIFFERENCE'),
              'tokens_equal': tokens_equal, 'events_equal': events_equal, 'full_input_trace_equal': trace_difference is None,
              'tokens_checked': 172032,
              'unique_native_repeat_tokens_compared': 86016 if candidate is None else None,
              'comparisons': differences, 'first_trace_difference': trace_difference,
              'coverage': stats, 'bank_plan_sha256': nc['bank_plan_sha256'],
              'helper_manifest_sha256': nc['helper_manifest_sha256'], 'source_manifest_sha256': nc['source_manifest_sha256']}
    if candidate is None:
        files = [native / 'configuration.json', *native.glob('rank*.b28.json'),
                 *native.glob('request_stats_rank*.jsonl'), *native.glob('trace/**/*.jsonl'),
                 *native.glob('trace/**/*.audit.json')]
        result['gold_files'] = {str(p.relative_to(native)): sha(p) for p in sorted(set(files))}
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--native', type=Path, required=True)
    parser.add_argument('--candidate', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    result = audit(args.native, args.candidate)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('comparisons', 'coverage')}, indent=2))
    raise SystemExit(0 if result['status'] in ('READY_NATIVE1', 'PASS_TOKEN_AND_PROTOCOL') else 1)
