# B28阶段结果及QA-next独立复核（2026-10-21）

**诊断有效；两行最早可见差异均在QR的FP32 scale，满足QA-next启用条件。QA-next源码、观察语义和新编译64ABI复核通过，未发现阻碍固定B28观察任务启动的问题。** 这还没有证明QA或K归约顺序是根因，也没有证明真实模型token不一致。

## 原诊断保真

直接读取`device-stage-v1/result.json`，SHA为`dded02cd99456f164a2b7f30b6334a69faee54d7f20e320fbdee94efb318dae3`。

- Native与candidate各自全部8个外部边界均逐byte保持原失败快照，输入/初态检查仍在对应observer路径中执行。
- 两臂均实际FULL168、零逐请求padding，compiled/raw一致、poison回放恢复；每臂33项guard全部PASS。
- readonly、debug guard、5项Norm packet及33项order packet检查均通过；一次真实静态reselection和一次复用，实际64Tensor根。
- 本机重哈77份运行源、四份helper和三份诊断源，均匹配结果中的身份。原数学未改。

`diagnostic_complete=true`且无error；`complete/pass/precision_pass=false`是该导出器保留的诊断标记，不能当作设备执行失败，也不能改写成精度通过。本次独立复核读取JSON门禁及源码执行顺序，没有下载大Tensor重新计算逐bit结果。

## 两行首差

| 边界 | row86 | row103 |
| --- | --- | --- |
| mixed/normed/post/comb | 全一致 | 全一致 |
| qr INT8 | 一致 | 一致 |
| **qr_scale FP32** | **1项不同，max abs 1.0244548320770264e-8** | **1项不同，max abs 2.7939677238464355e-9** |
| 主Q，RMS及RoPE后 | 20项不同 | 8项不同 |
| Indexer weights / scale | 一致 / 一致 | 一致 / 一致 |
| Indexer INT8 query | 3项不同 | 一致 |
| inverse-RoPE后heads | 1132项不同 | 505项不同 |
| WO-A / WO-B输出 | 1833 / 3089项不同 | 872 / 1638项不同 |

最早观测区间是**相同normed→QA→Q-LoRA RMS/quant scale发布**。当前13stage不包含QA，因此不能区分QA BF16输入先变，还是QA相同而RMS/amax/scale算法先变。QR整数相同不等于反量化输入相同，scale已经不同。row103的主Q也已变化，现有数据不能把其输出误差归因于row86的TopK重排；此时亦不能独立认定attention归约、逆RoPE或后缀另有缺陷。

## QA-next复核

独立剥离观察增量后，三层QKV wrapper的AST逐一还原正式`qkv_precision126.py`；root还原父`b28_root.py`，Indexer仅import名称变化，原13导出未改。T126条件及T168自然序路径保留，无数学修改或两行特判修复。

Native hook在实际fusedQR调用前断言输入是BF16 `[168,1024]`并复制，随后原参数调用原op、原样返回。PTO在原QA FP32结果上重复Normalize本来就有的BF16 `rint`物化，再精确扩大FP32保存；该只读观察不反馈计算。因此比较的是**QA BF16发布边界**，不能拿它当FP32 accumulator比较。

QA导出仅row86/103，占packet字`199168..201215`，与原13项导出、gap和前2560字order均无重叠；packet仍1048576字。Native校准文件保存全168行normed/QA/QR/scale及实际WQ-A/gamma，先核对与PTO权重一致；PTO QA仍只有两行，不能声称全168行QA对拍。含权重的校准文件应保留远端。

16项activation文件与helper清单逐SHA复核通过。新`compile-receipt.json`的compiled/kernel ABI均为true；四份新源、exports SHA匹配当前文件，schema与已完成父诊断除namespace外完全相同，仍64参数；原formal编译receipt及PyPTO/Simpler路径一致。该receipt只证明无设备编译和ABI资格。

后续固定B28观察仍须先通过两臂原8边界invariance、poison/guard/readonly及packet检查，才解释QA差异。若QA相同但scale不同，转Q-LoRA RMS/量化；若QA不同，先用全M168及原格式/静态选择复现实际Native FULL QA，再考虑有限K-order探针。当前无依据直接扩展T126分支。

本复核未访问远端、未提交设备任务、未修改正式源码或观察器。完整字段见同名JSON。
