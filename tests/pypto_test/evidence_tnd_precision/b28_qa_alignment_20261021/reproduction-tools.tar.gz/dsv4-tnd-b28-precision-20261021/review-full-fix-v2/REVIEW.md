# B28 完整CSA修复结果独立复核

**PASS，范围仅限 C4 单层 B28/T168/history131072 本例精度。**

已核实际 result SHA `a8b0bd68…`、helper/私有source manifest、编译与QA-only激活收据的身份闭环。
源码独立逆向AST复核：根仅更换QKV导入；QKV只增加 `elif tile_rows == 168` 调用既有packet helper，
移除该分支后与原正式源码AST一致，原K512包内两K256数学、其余CSA路径与64Tensor边界未改。

- A、B各8项外部边界均逐byte一致，different/max_abs/relative_l2均为0。
- Native A的8项与原失败快照不变；两臂原输入和initial cache通过源脚本硬门禁。
- 双方真实FULL/raw一致、TopK毒化恢复、活输入A/B/A恢复；各33项guard PASS。
- candidate实际PTO路由、eligible且调用计数2，64Tensor根；readonly norm/order/packed参数检查通过。
- timing_executed=false，本轮不含DFX或延迟资格。

支持的归因是：在已观测QA首差、有限Native次序与QA-only真实全168行验证的基础上，
仅将T168导向既有packet次序，消除了本例A/B中的原TopK和输出差异。
不能声称已得到所有CANN shape的通用次序规则，或证明整模型192 token逐token一致。
本轮未新增整模型token/性能/all-layer/ragged资格；真实权重也不等于真实整模型请求。

主线程给出的占卡191秒满足15分钟限制；本次本地只读审查未读取独立调度收据，
因此将该时长单列为主线程报告，不冒充本审查重新计时。初始SOURCE_PROOF的PREPARED字样是准备阶段记录，
实际成功依据是另行绑定的编译与设备result，不应把初始准备证明作为设备证据。

详细SHA和检查计数见同目录RESULTS.json。本轮未修改正式源码，未访问远端或初始化NPU。
