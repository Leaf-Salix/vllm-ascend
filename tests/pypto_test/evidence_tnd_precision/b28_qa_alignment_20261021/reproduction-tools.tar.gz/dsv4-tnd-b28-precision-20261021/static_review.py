"""Remove only observer additions, then require original AST equality."""
import ast
import hashlib
import json
from pathlib import Path
here=Path(__file__).resolve().parent
ops=here.parents[1]/'vllm-ascend-nalinaly-tnd-20261008-codex/vllm_ascend/ops/pypto'
results={}
for kind,original in [('root',ops/'deepseek_v4_flash_csa_tnd_precision_spmd_overlap/decode_csa.py'),('indexer',ops/'deepseek_v4_flash_csa_tnd_precision_spmd/indexer.py')]:
    base=ast.parse(original.read_text());probe=ast.parse((here/f'b28_{kind}.py').read_text())
    class StripObserver(ast.NodeTransformer):
        def visit_ImportFrom(self,node):
            if node.module=='b28_exports':return None
            if node.module=='b28_indexer':node.module='deepseek_v4_flash_csa_tnd_precision_spmd.indexer';node.level=2
            if kind=='indexer' and node.module.startswith('vllm_ascend.ops.pypto.'):
                node.module=node.module.removeprefix('vllm_ascend.ops.pypto.');node.level=2
            return node
        def visit_FunctionDef(self,node):
            if kind=='root' and node.name=='_full_csa_tnd_prepacked':
                next(a for a in node.args.args if a.arg=='order_packet').annotation=ast.parse('pl.Tensor[[2560],pl.INT32]',mode='eval').body
            if kind=='indexer' and node.name=='indexer':
                assert node.args.args[-1].arg=='order_packet';node.args.args.pop()
            return self.generic_visit(node)
        def visit_Assign(self,node):
            if any(isinstance(n,ast.Name) and n.id.startswith('debug_') for n in node.targets):return None
            return self.generic_visit(node)
        def visit_Expr(self,node):
            if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name) and node.value.func.id.startswith('export_'):return None
            return self.generic_visit(node)
        def visit_Call(self,node):
            if isinstance(node.func,ast.Name) and node.func.id=='indexer':
                assert isinstance(node.args[-1],ast.Name) and node.args[-1].id=='order_packet';node.args.pop()
            return self.generic_visit(node)
    recovered=StripObserver().visit(probe)
    assert ast.dump(base)==ast.dump(recovered),kind+' formal math changed'
    results[kind]={'formal_source':str(original),'sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'observer_only_AST_equal':True}
(here/'STATIC_REVIEW.json').write_text(json.dumps(results,indent=2)+'\n')
print('ROOT_AND_INDEXER_ORIGINAL_AST_RECOVERED_EXACTLY')
