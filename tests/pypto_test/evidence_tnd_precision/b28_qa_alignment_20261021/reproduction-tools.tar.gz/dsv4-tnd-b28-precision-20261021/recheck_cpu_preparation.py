"""独立重算本轮无设备证据；不赋予任何硬件或token精度资格。"""
import hashlib
import json
from pathlib import Path
import tarfile

here=Path(__file__).resolve().parent
archive=here/'cpu-whole-preparation-evidence.tar.gz'
with tarfile.open(archive) as tar:
    blobs={member.name:tar.extractfile(member).read() for member in tar.getmembers() if member.isfile()}
def read(name):return json.loads(blobs[name])
expected=json.loads((here/'BASELINE_ENVIRONMENT_BOUND.json').read_text())
for mode in ('BANK','PREFLIGHT'):
    receipt=read(f'CPU_WHOLE_{mode}_RECEIPT.json')
    assert receipt['pass'] and receipt['npu_initialized'] is False
    assert receipt['modules']==expected['modules'] and receipt['env']==expected['env']
    assert receipt['mode']==mode.lower()
plan=read('whole-b28-next/bank28/plan.json')
audit=read('whole-b28-next/bank28/audit.json')
preflight=read('whole-b28-next/preflight-native-cpu.json')
assert len(plan['cases'])==len(audit['cases'])==28
assert [c['key'] for c in plan['cases']]==[f'h8192_q{i:02d}' for i in range(28)]
plan_sha=hashlib.sha256(blobs['whole-b28-next/bank28/plan.json']).hexdigest()
assert audit['plan_sha256']==preflight['bank_plan_sha256']==plan_sha
assert audit['status']=='PASS'
assert preflight['batch']==preflight['max_num_seqs']==28 and preflight['capture_sizes']==[6,168]
assert preflight['tp']==1 and preflight['dp']==preflight['ep']==16
helper_sha=hashlib.sha256(blobs['whole-b28-next/helper-manifest.json']).hexdigest()
assert helper_sha==preflight['helper_manifest_sha256']
assert blobs['whole-b28-next/helper-manifest.json']==(here/'whole-b28-next/helper-manifest.json').read_bytes()
assert 'B28_CPU_ONLY_IDENTITY_AND_NO_DEVICE_PASS bank' in blobs['cpu-bank-v3.log'].decode()
assert 'B28_NO_DEVICE_PREFLIGHT_OK' in blobs['cpu-whole-preflight-v4.log'].decode()
assert 'B28_CPU_ONLY_IDENTITY_AND_NO_DEVICE_PASS preflight' in blobs['cpu-whole-preflight-v4.log'].decode()
record={'status':'PASS_CPU_PREPARATION_ONLY','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
        'plan_sha256':plan_sha,'helper_manifest_sha256':helper_sha,'cases':28,'modules_pinned':7,
        'npu_initialized':False,'full_cache_payload_rehashed':False,'new_token_results':False,
        'formal_math_changed':False,'cpu_bank_task':'task_20261021_130804_57068210312',
        'cpu_bank_task_exit':1,'bank_phase_passed_before_hook_preflight_failure':True,
        'cpu_preflight_task':'task_20261021_131122_8667061113','cpu_preflight_task_exit':0,
        'current_stage_task':'task_20261021_125130_324509630936'}
(here/'REMOTE_CPU_PREPARATION_RECHECK.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
