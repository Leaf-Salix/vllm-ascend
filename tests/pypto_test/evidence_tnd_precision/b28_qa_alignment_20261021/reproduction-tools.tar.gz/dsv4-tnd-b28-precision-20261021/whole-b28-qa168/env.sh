#!/usr/bin/env bash
base=/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex
source "$base/root-fix-20261016/env.sh"
export SOURCE_ROOT="/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/b28-precision-20261021-codex/whole-b28-qa168/snapshot/source"
export PYTHONPATH="$job:$SOURCE_ROOT:$SOURCE_ROOT/tests/pypto_test:$PYTHONPATH"
export PTO_CSA_VARIANT=pkg:deepseek_v4_flash_csa_tnd_precision_spmd_overlap
export PYTHONNOUSERSITE=1 OMP_NUM_THREADS=10 OMP_PROC_BIND=false
export CCACHE_DIR=/data/pyptouser/yejia/vllm-cann901-csa-0251rc1/src/pypto/.ccache
export CMAKE_BUILD_PARALLEL_LEVEL=4
export LOW_ACCEPTANCE_GPU_BLOCKS=22000
export LOW_ACCEPTANCE_OFFICIAL_CACHE="$base/low-acceptance-20261010/official-static-cache"
export PERF_CAPTURE_BUCKET=168
export B28_ACTIVE=0
unset LOCAL_WORLD_SIZE LOW_ACCEPTANCE_STATIC_MANIFEST
unset ADMISSION_REFERENCE ADMISSION_TRACE_DIR FULL_PROBE_DIR FULL_PROBE_MODE
unset FULL_PROBE_OUTER_REFERENCE FULL_PROBE_STAGE_REFERENCE LOW_ACCEPTANCE_FIRST_STEP_DIR
unset OFFLINE_PTO_SWIMLANE_DIR LOW_ACCEPTANCE_FIRST_STEP_ALL_CSA

unset SPMD_EXPERIMENT
