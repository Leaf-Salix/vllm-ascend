# B28 首差的可证伪定位顺序

本文件是诊断方案，不是误差根因结论。正式数值基准48c58c保持不变。

## 已有证据

- B28/T168、L4、history131072、seed1024，首次A有idx_topk和x_out差异。
- row86 TopK 88位置重排但选点集合相同，x_out row86/103分别1343/388元素不同；六cache/state逐位相同。
- 七档通过包含T6/24/48/96/144/192；它们不能证明T168的Native矩阵归约顺序已覆盖。
- QA126旧诊断曾出现相同row86/103首差模式；当时由实际QA BF16发布边界及有限抵消探针证实K512包顺序。
- 当前qkv_precision126只对T126使用该规则；T168走q_proj_qa自然K256顺序。旧q_proj_qa特殊门仅覆盖96/144/192/240，源码说明基于CANN9.0。
- 上述相似性仅提高优先级，不能据此认定B28同根因或直接扩大126分支。

## 首轮中间值

固定B28/T168才允许进入NPU；确定性Native FULL、正式PTO同一环境、原fixture生成顺序和初始cache。
诊断root只加导出，保留64参数；原order前2560字不变，尾部只供导出。
root及Indexer去掉导出后的AST必须还原正式源码；实际远端导入源码hash亦须匹配。

先检查Native及PTO所有8外部边界与未插桩失败快照逐位相同，再使用13阶段结果。
导出仅row86/103；这轮不能宣称已审全部内部token行。阶段包含：

1. mixed、post、comb、normed；
2. qr、qr_scale、RoPE后Q；
3. Indexer FP16 weights、INT8 query、FP32表示的scale；
4. inverse RoPE后heads、WO-A projected_o、WO-B attention_out。

毒化重放、外侧guard、packet间隙、原order及全部readonly packet均须通过。
诊断完成可exit0，但precision_pass保持false，不能将导出成功当作精度修复。

## 结果驱动的下一步

| 最早差异 | 下一项最小实验 | 禁止的推断或改法 |
| --- | --- | --- |
| mixed/post/comb/normed | 对照本次Native HC/RMS的原生输入及物化边界，再细分 | cache一致不能代替前缀验证 |
| qr/qr_scale，且Norm一致 | 导出本次真实QA BF16；同Norm/NZ2权重的Native独立F.linear先复现FULL，再做K256有限抵消探针 | 不能盲目将T126分支扩到T168、不能只针对两行特判 |
| Q，且qr/scale一致 | QB反量化、Q RMS及RoPE前后物化边界二分 | 不把TopK相同当成Q相同 |
| Indexer输入，且QR一致 | Indexer query投影/RoPE/Hadamard/量化逐段导出 | 不按index重新稳定排序掩盖分数差异 |
| TopK，全部Indexer输入一致 | 对照实际Native QLI分数生产、缩放和merge排序；实际返回为空时不冒充Native score | 集合相同不证明tie或等价排序 |
| heads，全部Q/缓存/TopK一致 | 导出Native/PTO preinverse BF16，再二分softmax概率、分母及PV | 不改K分块、近似exp或放宽阈值以获得通过 |
| projected_o，且heads一致 | 使用全T168相同heads对拍WO-A、全8192量化、WO-B | 不抽成T2破坏Native tiling资格 |
| x_out，attention_out及post/comb一致 | 核对HCpost FP32操作树及BF16发布 | 不以token暂时一致替代内部精度门禁 |

仅首差模块修复通过后才恢复该B28完整门禁，再考虑回归已验收8K/128K整模型token。
每项硬件任务执行上限780s，内部750s；排队时间不占NPU，不借用或终止他人任务。
