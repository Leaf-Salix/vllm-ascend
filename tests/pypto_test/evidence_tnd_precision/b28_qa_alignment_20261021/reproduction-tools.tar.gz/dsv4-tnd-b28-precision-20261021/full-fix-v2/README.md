# B28 完整 CSA 私有修复候选 v2

当前仅完成本地源码准备与静态检查。未运行 CPU 验收、编译、Native、NPU，未上传或提交任务。正式源码不变。

## 改动与身份

- `full_fix_qkv.py` 克隆正式 bf16layout `qkv_precision126.py`，只将 `q_proj_qr` 的路由条件扩大为 T126 或 T168；继续使用原 `q_proj_qa_126`，不改其 M64/M16、N32、K256、FP32 累加、packet 内序或舍入。
- `full_fix_root.py` 克隆正式 overlap `decode_csa.py`，只把 QKV import 指向上述私有模块。原 64 Tensor ABI、order packet 2560、后缀及其它依赖不变，没有 debug 导出。
- `SOURCE_PROOF.json` 记录原/私有 SHA 与精确 AST 反向还原证明。私有模块用原 package 下的独立完整模块名加载，保留原相对依赖。
- 原 `CSAOperators.register()` 的 workspace/prepare 保留；attention 使用实际注册的 `b28_full_fix_next::attention`。真实 schema 必须与正式 schema 去除 namespace 后完全相同。编译收据和结果分开记录正式依赖、私有源码与真实 schema。

## 资格与门禁

启用前必须已有 `qa-candidate-next/results/<label>/result.json` 的真实通过收据。compile/run 都校验其 SHA、精确 SOURCE_BINDING、冻结 helper manifest、实际 compile receipt、四项 checks、五个 actual/random/actual case、全部 packet 精确性及 raw/poison/readonly 门禁。缺收据即拒绝启用。本轮 QA-only 收据已通过，SHA为`89b0804d1542f66c4e4f3b4eebfd828f92eb2ba8d5f8520dcb67015a0f1e749b`；这不是完整CSA通过。

完整验收固定 B28/T168/L4/history131072、seed1024、S6。复用 eight-l1 原工具与 43 源快照绑定，保留 FULL/唯一实际图、raw poison replay、A/hidden+.125 的 B/ABA、八外部边界逐 bit、guard、只读 metadata/packet、5 norm/33 order、HC pack、static reselect、禁止 fallback 等原门禁。新 Native A 另须逐 byte 等于原失败快照的八边界、输入与初始 cache。旧失败没有 B golden；B 使用本轮 fresh Native B。

只移除后续 DFX timing 段；readonly packet 检查放到成功标记前。成功 `pass/precision_pass/complete` 仅表示本例完整 CSA 精度通过，`timing_executed=false`；不表示性能或真实模型 token 通过。

## 未来命令（当前不执行）

由父线程审核并取得 QA-only pass 后，在原 stage 环境按现有方式提交；每个外层任务上限 **780s**，助手内部限时 **750s**，使用原 ccache 与四路构建。此目录不包含 task-submit 调度脚本。

```bash
bash compile.sh /absolute/qa-candidate-next/results/<qa-label>/result.json <QA_RESULT_SHA256>
bash run.sh <fresh-label> /absolute/qa-candidate-next/results/<qa-label>/result.json <QA_RESULT_SHA256> <ORIGINAL_FIRST_DIFFERENCE_PT_SHA256>
```

`run.sh` 要求单个数字 `TASK_DEVICE` 并与可见设备一致。原失败 tensor 位于既有 `eight-l1-20261021-codex/results/eight-l1-128k-b28-v1/first-difference.pt`；其真实 SHA 须先从该文件取得，脚本使用流式 hash 后以 CPU mmap 只读加载，不复制大 tensor。私有完整 CSA 编译收据须由未来无设备编译实际生成，未放置占位通过结果。

## v2 编排兼容性

第一版仅无设备编译失败：固定SDK不能生成该处`or`表达式。v2采用等价`if/elif`，两条分支调用同一原packet helper，未改SDK、C++或计算/舍入。删除新增elif后可精确还原正式AST；失败版本独立保留。
