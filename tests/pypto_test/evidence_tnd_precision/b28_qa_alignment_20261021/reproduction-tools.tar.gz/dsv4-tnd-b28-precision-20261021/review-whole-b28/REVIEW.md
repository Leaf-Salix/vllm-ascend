# B28真实模型后续助手独立审查

## 结论

**PASS_LOCAL_DESIGN_ONLY，无源级阻断。** 未修改封存助手目录或正式源码，未访问227、实际bank头或设备。此PASS只授予继续准备/审查的资格，**不代表Native1、PTO、真实T168或172032个token已经通过**。现有13阶段任务未出结果前，不据此提交两项硬件任务。

## 独立执行和身份检查

以B28_ACTIVE=0、PYTHONDONTWRITEBYTECODE=1实际运行test_local.py，12项控制全部通过，2.267秒。测试含16rank模拟正例、token/事件/真实输入/Native重复轮首差、gold改写、重复key、假bucket168、mock bank dtype/MTP/路径拒绝及实际wrapper的mock CLI。没有导入NPU执行器。

22项helper SHA逐一复核，清单SHA为e2cf7ff68d10c10b3b80d0384aec45abdbc777f30ba738f00caa52cfaef414ec。3399源manifest和77运行源的子集SHA一致；CPU测试还核对77项当前正式checkout源码。真实remote3399文件与原connector/run仍须通过preflight，不能把本地subset比较写成已远端全量验证。

## 关键链路

- prepare_bank使用原40条plan的前28个不同key，绑定tokens/manifest SHA及原history；safe_open逐个核对target/MTP名称集合、dtype、完整shape和compress ratio，保留每请求logical页映射及decode_suffix_tokens=1。仅新建plan和符号链接，不执行suffix prefill或重写原cache。真实头尚未读取，mock测试不能替代它。
- mixed_b28的Native第1轮192token与第0轮真实warm192结果比较；不是同一数组的自比。PTO两轮各自与Native1对应轮比较。每rank/轮28个唯一请求、greedy192、零抢占及实际DSpark events均检查，token首差写TOKEN_STOP并抛异常。
- 两轮全16rank应记录172032个输出token。Native重复性比较本身只有86016对独立位置；audit分别标注这两个数量，没有将warm自比计为新重复证明。
- admission_trace实际读取_model_forward的device input_ids/positions及真实query bounds；包括空闲rank，联合DP向量和完整窗口长度核对。Native/PTO与Native自身轮间比较仅忽略进程局部execute_index，未归一化0/-1或删除真实input字段。合法空尾独立严格检查，不将尾部当生成窗口删样。
- 每rank每轮至少一次真正28活跃、query_lengths=[6]*28、actual_tokens=168、padded_tokens=168、FULL和DP向量[168]*16。只有capture168而实际126行的负例会失败，因此方案能在实测后区分提交B28与实际T168。
- 原77源、64Tensor完整纯DSL root、21CSA/20Native HCA和两bucket的实际warm/capture均要求资格。资格桥先完成13静态包检查及真实reselect再允许PTO；观察器不替换计算。未通过路由/捕获资格不能用token相同冒认完整PTO覆盖。
- Native1完成后READY_GOLD绑定全部config、16rank token报告、request stats和完整trace/audit文件。PTO preflight及最终audit重新核对gold所有SHA，候选不写Native输出。事件/完整输入不同时独立标TOKENS_EQUAL_PROTOCOL_DIFFERENCE，不伪称token错误，也不授予完整协议PASS。
- TASK_DEVICE要求16个不同数字；B28_ACTIVE在decode时明确为1、审计时为0；sitecustomize全部主动逻辑位于该开关内。输出目录使用mkdir拒绝覆盖；无task-submit代码。内层750秒加20秒kill grace，外层仍须780秒分配；模型/编译额外耗时意味着“在时限内完成”尚无实际保证。

## 范围和保留意见

当前只有模拟fixture/CLI通过；remote bank、原环境、Native warm/正式重复、PTO输出、完整设备输入轨迹及T168覆盖都待实测。cache复用资格检查plan/token/manifest、头及文件长度，没有独立重新hash全部约2GB payload；不要把它扩张成逐byte校验了所有cache文件内容。真实最终token仍严格比较，不可用单层relL2替代。

本方案不跑128K、不创建Native2、不在一个长任务内执行两个arm。真实8K/B28通过后也不能宣称128K/B28或任意prompt通过，不能把当前合成B28逐bit失败直接改称真实token失败。未发现需要修改源码或SDK的地方；下一步仍应等待已有阶段任务结果，再由主线程决定是否启用。
