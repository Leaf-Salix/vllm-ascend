"""Archive only small diagnostic source/text evidence, never model/tensor/binary data."""
import hashlib
import json
from pathlib import Path
import tarfile

r = Path(__file__).resolve().parent
e = r.parent.parent / 'vllm-ascend-nalinaly-tnd-20261008-codex/tests/pypto_test/evidence_tnd_precision/b28_qa_alignment_20261021'
paths = sorted(p for p in r.rglob('*') if p.is_file() and p.suffix in ('.py', '.sh', '.json', '.md', '.txt', '.log') and '__pycache__' not in p.parts and not p.name.startswith('._'))
assert sum(p.stat().st_size for p in paths) < 8_000_000
archive = e / 'reproduction-tools.tar.gz'
with tarfile.open(archive, 'w:gz') as bundle:
    for p in paths: bundle.add(p, arcname=str(Path(r.name) / p.relative_to(r)), recursive=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((e / 'SHA256.json').read_text())
m[archive.name] = sha(archive)
(e / 'SHA256.json').write_text(json.dumps(m, indent=2) + '\n')
print(len(paths), archive.stat().st_size, sha(archive))
