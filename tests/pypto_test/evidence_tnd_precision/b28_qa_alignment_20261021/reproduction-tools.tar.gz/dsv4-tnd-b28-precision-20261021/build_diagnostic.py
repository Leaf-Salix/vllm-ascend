"""独立导出诊断；保持正式root的算术和64参数ABI数量。"""
import ast
import hashlib
import json
import shutil
from pathlib import Path

here = Path(__file__).resolve().parent
workspace = here.parents[1]
old = workspace/'reports/dsv4-tnd-eight-l1-20261021'
prior = workspace/'reports/dsv4-tnd-precision-spmd-20261019/t126-fix-20261020/packed64-v4'
ops = workspace/'vllm-ascend-nalinaly-tnd-20261008-codex/vllm_ascend/ops/pypto'
out = here/'tools'
out.mkdir(exist_ok=True)
for p in (old/'tools').glob('*'):
    if p.is_file(): shutil.copy2(p, out/p.name)
shutil.copy2(old/'preflight.py', here/'preflight.py')
specs = {'mixed':(4096,'BF16'),'normed':(4096,'BF16'),'post':(4,'FP32'),'comb':(16,'FP32'),
         'indexer_weights':(64,'FP16'),'q':(32768,'BF16'),'heads':(32768,'BF16'),
         'projected_o':(8192,'BF16'),'attention_out':(4096,'BF16'),
         'iq':(8192,'INT8'),'iscale':(64,'FP32'),'qr':(1024,'INT8'),'qr_scale':(1,'FP32')}
packet_size = 1 << 20
cursor = 2816
layout = {}
helpers = []
for name,(width,dtype) in specs.items():
    blocks = (width+255)//256
    offset = cursor
    layout[name] = dict(width=width,offset=offset,blocks=blocks,source_dtype=dtype,rows=[86,103])
    cursor += 2*blocks*256+256
    dim = 'T_PAD' if name in ('iq','iscale') else 'T_DYN'
    widening = 'tile' if dtype=='FP32' else 'pl.cast(pl.cast(tile,pl.FP16),pl.FP32)' if dtype=='INT8' else 'pl.cast(tile,pl.FP32)'
    helper = f'''@pl.jit.inline(auto_scope=False)
def export_{name}(source: pl.Tensor[[{dim},{width}],pl.{dtype}], packet: pl.InOut[pl.Tensor[[{packet_size}],pl.INT32]]):
    packet2=pl.reshape(packet,[1,{packet_size}])
    with pl.spmd(8,name_hint="debug_{name}"):
        for block in pl.range(pl.tile.get_block_idx(),{2*blocks},8):
            row=86
            if block >= {blocks}:
                row=103
            col=(block % {blocks})*256
            tile=pl.load(source,[row,col],[1,256],valid_shape=[1,pl.min(256,{width}-col)])
            widened={widening}
            bits=pl.tile.reinterpret_view(widened,pl.INT32)
            valid=pl.set_validshape(bits,1,pl.min(256,{width}-col))
            pl.store(valid,[0,{offset}+block*256],packet2)
'''
    if name=='qr_scale':
        helper = f'''@pl.jit.inline(auto_scope=False)
def export_qr_scale(source: pl.Tensor[[T_DYN,1],pl.FP32], packet: pl.InOut[pl.Tensor[[{packet_size}],pl.INT32]]):
    packet2=pl.reshape(packet,[1,{packet_size}])
    flat_source=pl.reshape(source,[1,168])
    with pl.spmd(8,name_hint="debug_qr_scale"):
        for block in pl.range(pl.tile.get_block_idx(),2,8):
            row=86
            if block>=1:
                row=103
            value=pl.load(flat_source,[0,row],[1,8])
            bits=pl.tile.reinterpret_view(value,pl.INT32)
            pl.store(pl.set_validshape(bits,1,1),[0,{offset}+block*256],packet2)
'''
    helpers.append(helper)
assert cursor < packet_size
(here/'b28_exports.py').write_text('import pypto.language as pl\nfrom vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision.decode_csa import T_DYN,T_PAD\n\n'+'\n'.join(helpers))
(here/'exports.json').write_text(json.dumps(dict(packet_size=packet_size,stages=layout),indent=2)+'\n')
tree = ast.parse((ops/'deepseek_v4_flash_csa_tnd_precision_spmd_overlap/decode_csa.py').read_text())
for n in tree.body:
    if isinstance(n,ast.ImportFrom) and n.module=='deepseek_v4_flash_csa_tnd_precision_spmd.indexer':
        n.module='b28_indexer'; n.level=0
root = next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_full_csa_tnd_prepacked')
assert len(root.args.args)==64
next(a for a in root.args.args if a.arg=='order_packet').annotation=ast.parse(f'pl.InOut[pl.Tensor[[{packet_size}],pl.INT32]]',mode='eval').body
names=[n for n in specs if n not in ('iq','iscale')]
tree.body.insert(1,ast.ImportFrom(module='b28_exports',names=[ast.alias(name='export_'+n) for n in names],level=0))
for n in ast.walk(root):
    if isinstance(n,ast.Call) and ast.unparse(n.func)=='indexer': n.args.append(ast.Name(id='order_packet',ctx=ast.Load()))
def hascall(stmt,call):
    return any(isinstance(n,ast.Call) and ast.unparse(n.func)==call for n in ast.walk(stmt))
def export(name,src=None): return ast.parse(f'export_{name}({src or name},order_packet)').body[0]
new=[]
for stmt in root.body:
    new.append(stmt)
    if isinstance(stmt,ast.With) and hascall(stmt,'prepacked_prefix_indexer_group'):
        new.extend(export(n) for n in ('mixed','normed','post','comb','indexer_weights'))
    if isinstance(stmt,ast.With) and hascall(stmt,'qkv_proj_rope'):
        body=[]
        for inner in stmt.body:
            body.append(inner)
            if hascall(inner,'qkv_proj_rope'):
                body.append(ast.parse('debug_q_flat=pl.reshape(q,[t_dim,H*HEAD_DIM])').body[0])
                body.extend([export('q','debug_q_flat'),export('qr'),export('qr_scale')])
        stmt.body=body
        new.append(export('heads'))
    if isinstance(stmt,ast.With) and hascall(stmt,'o_proj_entry'):
        new.extend([export('projected_o'),export('attention_out')])
root.body=new
ast.fix_missing_locations(tree)
(here/'b28_root.py').write_text(ast.unparse(tree)+'\n')
tree=ast.parse((ops/'deepseek_v4_flash_csa_tnd_precision_spmd/indexer.py').read_text())
for n in tree.body:
    if isinstance(n,ast.ImportFrom) and n.level: n.module='vllm_ascend.ops.pypto.'+n.module;n.level=0
# T_PAD imports exist in the unchanged Indexer.
tree.body.insert(1,ast.ImportFrom(module='b28_exports',names=[ast.alias(name='export_iq'),ast.alias(name='export_iscale')],level=0))
entry=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='indexer')
entry.args.args.append(ast.arg(arg='order_packet',annotation=ast.parse(f'pl.InOut[pl.Tensor[[{packet_size}],pl.INT32]]',mode='eval').body))
new=[]
for stmt in entry.body:
    new.append(stmt)
    if hascall(stmt,'indexer_qr_hadamard'):
        new.extend(ast.parse('debug_iq_flat=pl.reshape(qr_hadamard_i8,[T_PAD,IDX_N_HEADS*IDX_HEAD_DIM])\ndebug_scale_flat=pl.reshape(qr_hadamard_scale_dq,[T_PAD,IDX_N_HEADS])').body)
        new.extend([export('iq','debug_iq_flat'),export('iscale','debug_scale_flat')])
entry.body=new
ast.fix_missing_locations(tree)
(here/'b28_indexer.py').write_text(ast.unparse(tree)+'\n')
# Reuse proven Native observation hooks and packed64 guard/poison logic.
old_probe=(prior/'tools/probe_csa.py').read_text()
s=(old/'tools/probe_csa.py').read_text()
def section(source,start,end): return source[source.index(start):source.index(end)]
block=section(old_probe,'native_debug={}','class NativeHalf(')
block=block.replace("experiment/'t126-fix-20261020/","ROOT.parent/'").replace("experiment/'t126-fix-20261020'","ROOT.parent").replace('t126_diagnostic_root','b28_root').replace('deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.b28_root','deepseek_v4_flash_csa_tnd_precision_spmd_overlap.b28_root').replace("n=='packet'","n=='packet'")
# Narrow export set, no extra Hadamard observers or Q RMS helper instrumentation.
s=s.replace('class NativeHalf(',block+'class NativeHalf(',1)
s=s.replace('from dsv4_csa_native_case import native_session','from dsv4_csa_native_case import native_session\nfrom vllm_ascend.device.device_op import DeviceOperator')
s=s.replace('        normed=l.input_layernorm(mixed)',"        native_debug['mixed'].copy_(mixed)\n        native_debug['post'].copy_(post.reshape(tokens,-1))\n        native_debug['comb'].copy_(comb.reshape(tokens,-1))\n        normed=l.input_layernorm(mixed)\n        native_debug['normed'].copy_(normed)")
s=s.replace('        output.copy_(l.hc_post(attended,hidden,post,comb))',"        native_debug['attention_out'].copy_(attended)\n        output.copy_(l.hc_post(attended,hidden,post,comb))")
hooks=section(old_probe,'    specs={','    original_qli=')
hooks=hooks[:hooks.index("    import vllm_ascend.attention.dsa_v1")] + section(old_probe,'    original_get_attn=','    original_qli=')
hooks=hooks.replace(",\n      'irope':((tokens,8192),torch.bfloat16),'ihadamard_scaled':((tokens,8192),torch.bfloat16)",'')
s=s.replace('    original_qli=',hooks+'    original_qli=',1)
s=s.replace("        result=original_qli(*values,**kwargs);observed['topk']=result[0];return result",section(old_probe,'        if not qli_kwargs:','    torch.ops._C_ascend.npu_vllm_quant_lightning_indexer=observe_qli').rstrip())
adapter=section(old_probe,'            original_ops=CSAOperators.register()','            with torch.inference_mode(False)')
adapter=adapter.replace('t126_stage_probe::attention','b28_stage_probe::attention')
s=s.replace('            operators=(SerialOperators if arm==\'serial\' else CSAOperators).register()\n',adapter)
s=s.replace("restore(f);output.fill_(float('nan'));topk.fill_(-12345);graph.replay();torch.npu.synchronize()","restore(f);output.fill_(float('nan'));topk.fill_(-12345);poison_debug();graph.replay();torch.npu.synchronize();check_debug_guards()")
start=s.index("        if arm!='native':\n            checks={name:metric(value,states['native'][name]) for name,value in actual.items()}")
end=s.index('except Exception as exc:',start)
exportblock=section(old_probe,"        reference=torch.load(","        if arm!='native':\n            checks={name:metric(value,states['native'][name]) for name,value in actual.items()}")
exportblock=exportblock.replace("experiment/'results/bf16layout-full-t126-v1/first-difference.pt'","BASE/'eight-l1-20261021-codex/results/eight-l1-128k-b28-v1/first-difference.pt'")
exportblock=exportblock.replace("            native_aux_export={n:v.cpu().clone() for n,v in native_aux.items()}\n            assert all(bool(torch.isfinite(v).all()) for v in native_aux_export.values()),'Native Q RMS hook missing/nonfinite'\n",'')
exportblock=exportblock.replace("{'native_aux':native_aux_export,'native':native_export", "{'native':native_export")
exportblock=exportblock.replace("        invariant={n:exact(v,reference['states'][arm][n]) for n,v in actual.items()}","        assert all(exact(f[n].cpu(),reference['inputs'][arm][n]) for n in ('hidden','positions')),'input differs from saved failure'\n        assert all(exact(g['initial'],reference['inputs'][arm]['initial'][n]) for n,g in f['groups'].items()),'initial cache differs from saved failure'\n        invariant={n:exact(v,reference['states'][arm][n]) for n,v in actual.items()}")
s=s[:start]+exportblock+'    save()\n'+s[end:]
s=s.replace("pypto.torch.init(enable_chip_swimlane=1,enable_dep_gen=False,output_dir=args.out/'dfx')","pypto.torch.init()")
s=s.replace("report['formal_root_file']=formal_root.__file__","report['formal_root_file']=formal_root.__file__\nstatic_review=json.loads((ROOT.parent/'STATIC_REVIEW.json').read_text())\nassert hashlib.sha256(Path(formal_root.__file__).read_bytes()).hexdigest()==static_review['root']['sha256']\nimport vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd.indexer as original_indexer\nassert hashlib.sha256(Path(original_indexer.__file__).read_bytes()).hexdigest()==static_review['indexer']['sha256']\nreport['diagnostic_AST_formal_sources_match']=True")
s=s.replace("assert all(q==6 for q in lengths) and batch<=40 and tokens<=256, 'this matrix is S6 only'","assert lengths==[6]*28 and tokens==168 and args.history==131072 and args.layer==4, 'fixed B28 observer only'")
s=s.replace("map_location='cpu',weights_only=False)","map_location='cpu',weights_only=True,mmap=True)")
s=s.replace("            packet_cpu=debug_packet.cpu()","            assert all(exact(v.cpu(),packet_snapshots[k]) for k,v in readonly_packets.items()), 'readonly packets changed by diagnostic'\n            report['readonly_after_diagnostic']=True\n            packet_cpu=debug_packet.cpu()")
(out/'probe_csa.py').write_text(s)
manifest=json.loads((out/'manifest.json').read_text())
(out/'manifest.json').write_text(json.dumps({n:hashlib.sha256((out/n).read_bytes()).hexdigest() for n in manifest},indent=2)+'\n')
s=(workspace/'reports/dsv4-tnd-precision-spmd-20261019/t126-fix-20261020/compile_stage_probe.py').read_text()
s=s.replace("here=exp/'t126-fix-20261020'","here=Path(__file__).resolve().parent").replace('t126_diagnostic_root.py','b28_root.py').replace('t126_diagnostic_root','b28_root').replace('deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.b28_root','deepseek_v4_flash_csa_tnd_precision_spmd_overlap.b28_root').replace('t126_stage_probe::attention','b28_stage_probe::attention').replace("here.glob('t126_diagnostic_*.py')","here.glob('b28_*.py')")
(here/'compile_diagnostic.py').write_text(s)
for p in [*here.glob('*.py'),*out.glob('*.py')]:ast.parse(p.read_text(),filename=str(p))
print('B28 diagnostic generated; packet used',cursor,'of',packet_size)
