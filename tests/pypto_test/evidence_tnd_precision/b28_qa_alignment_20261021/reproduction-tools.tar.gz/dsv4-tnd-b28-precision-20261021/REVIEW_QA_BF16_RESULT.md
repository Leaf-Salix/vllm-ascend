# QA BF16阶段首差独立复核（2026-10-21）

**资格通过；最早可见差异已前移至QA BF16发布边界，尚未确定具体K归约顺序。**

本机重哈结果JSON为`0e77f7eedb8f613cb3ff0852538ca998e722adadf80565e44add3065cf5f172d`。两臂各8项原边界invariance、FULL168、compiled/raw、poison回放、各33项guard、readonly/debug guard、5项Norm及33项order packet全通过；无error。四诊断源与当前成功编译receipt匹配，helper SHA一致，实际64Tensor ABI。新增QA观察前后的原13项逐行指标完全相同，保留了旧失败签名。

| 目标行 | normed | QA BF16 | QR整数 | QR scale / 主Q |
| --- | --- | --- | --- | --- |
| 86 | 一致 | 1项不同，max abs `0.000244140625` | 一致 | scale首差 / 20项Q差异 |
| 103 | 一致 | 1项不同，max abs `0.0001220703125` | 一致 | scale首差 / 8项Q差异 |

Native观察的是实际fusedQR的BF16输入；PTO观察的是原QA FP32结果经原Normalize同款BF16 rint物化后的值。相同normed之后，该QA发布边界先于RMS/量化scale变化，因此优先定位QA投影、归约与发布。还不能认定K256/K512、某个FMA顺序或证明全部下游差异仅由此引起。

校准JSON绑定SHA `e543fc19c363d25f5c35406f744feffe57dd447ed715279ecf97dda2aef82494`，实际Native权重格式29；记录全168行Native normed/QA/QR/scale及WQ-A、gamma的shape/dtype/逐Tensor SHA。校准载荷仅远端，本复核没有读取其字节；PTO QA依旧只观察两行。下一项顺序探针必须先用同一校准身份、完整M168/N1024/K4096和实际格式29，证明独立Native入口复现全168行FULL QA并重复确定，再解释有限K-order候选。

原结果`complete/pass/precision_pass=false`保留诊断语义，不是一次整模型token失败或修复通过。未访问远端、未改正式源码、未提交设备任务；qa-order-next待修正完成后再最终审查。详细检查见同名JSON。
