"""Local import-chain control using the sealed finders/loaders, without NPU imports."""
import ast
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys
import tempfile
from importlib.machinery import PathFinder
from unittest.mock import patch


here = Path(__file__).resolve().parent
source = here / 'whole-b28-next/sitecustomize.py'
before = hashlib.sha256(source.read_bytes()).hexdigest()
tree = ast.parse(source.read_text(), filename=str(source))
active = next(n for n in tree.body if isinstance(n, ast.If))
names = {'ObserverFinder', 'WorkerLoader', 'ObserverLoader', 'MixedFinder', 'MixedLoader'}
classes = [n for n in active.body if isinstance(n, ast.ClassDef) and n.name in names]
assert len(classes) == 5
namespace = {'__name__': 'sitecustomize', '__file__': str(source), 'os': os,
             'PathFinder': PathFinder}
exec(compile(ast.Module(body=classes, type_ignores=[]), str(source), 'exec'), namespace)
finders = [namespace['MixedFinder'], namespace['ObserverFinder']]

with tempfile.TemporaryDirectory() as temporary:
    root = Path(temporary)
    for package in ('offline_pd', 'low_acceptance_20261001'):
        (root / package).mkdir()
        (root / package / '__init__.py').write_text('')
    (root / 'offline_pd/worker.py').write_text('''class OfflineNPUWorker:
    def initialize_from_config(self, *args, **kwargs): pass
    def load_model(self, *args, **kwargs): pass
    def offline_batch_barrier(self, *args, **kwargs): pass
''')
    (root / 'offline_pd/observer.py').write_text('''class OfflineCSAObserver:
    def offline_begin_observation(self, *args, **kwargs): pass
    def offline_end_observation(self, *args, **kwargs): pass
''')
    (root / 'low_acceptance_20261001/mixed.py').write_text('def run_batches(*args): pass\n')
    old_path, old_meta = sys.path[:], sys.meta_path[:]
    sys.path[:0] = [str(root), str(here / 'whole-b28-next')]
    sys.meta_path[:0] = finders
    results = []
    try:
        for enabled in (False, True):
            for name in list(sys.modules):
                if name.split('.')[0] in ('offline_pd', 'low_acceptance_20261001', 'mixed_b28'):
                    del sys.modules[name]
            environment = {'B28_ACTIVE': '1', 'PERF_BACKEND': 'native'}
            if enabled:
                environment.update(ADMISSION_TRACE_DIR='/unused/preflight/trace', B28_OUTPUT='/unused/preflight')
            with patch.dict(os.environ, environment, clear=True):
                worker_preloaded = 'offline_pd.worker' in sys.modules
                worker = importlib.import_module('offline_pd.worker').OfflineNPUWorker
                observer = importlib.import_module('offline_pd.observer').OfflineCSAObserver
                mixed = importlib.import_module('low_acceptance_20261001.mixed')
                row = {'ADMISSION_TRACE_DIR_present': enabled, 'worker_preloaded': worker_preloaded,
                       'worker_load_module': worker.load_model.__module__,
                       'worker_load_qualname': worker.load_model.__qualname__,
                       'worker_load_filename': worker.load_model.__code__.co_filename,
                       'observer_begin_module': observer.offline_begin_observation.__module__,
                       'mixed_run_module': mixed.run_batches.__module__}
                assert mixed.run_batches.__module__ == 'mixed_b28'
                assert (worker.load_model.__module__ == 'sitecustomize') == enabled
                assert (observer.offline_begin_observation.__module__ == 'sitecustomize') == enabled
                results.append(row)
    finally:
        sys.path[:] = old_path
        sys.meta_path[:] = old_meta

after = hashlib.sha256(source.read_bytes()).hexdigest()
assert before == after
assert 'torch' not in sys.modules and 'torch_npu' not in sys.modules
result = {'pass': True, 'scope': 'real Python imports of tiny local fixtures through exact sealed AST finders/loaders; no remote/NPU',
          'sealed_sitecustomize_sha256': after, 'sealed_file_unchanged': True, 'cases': results}
(here / 'HOOK_INSTALL_PROBE.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
