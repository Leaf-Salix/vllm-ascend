#!/usr/bin/env bash
set -euo pipefail
job=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
export PERF_BACKEND=native PERF_OUTPUT="$job/preflight-unused"
source "$job/env.sh"
export ASCEND_RT_VISIBLE_DEVICES='' TORCH_DEVICE_BACKEND_AUTOLOAD=0 B28_ACTIVE=0
export PYTHONPATH="$LOW_ACCEPTANCE_RUNTIME_PACKAGE:$job${PYTHONPATH:+:$PYTHONPATH}"
if [[ ! -f "$job/CPU_BANK_RECEIPT.json" ]]; then
  python "$job/cpu_prepare.py" bank > "$job/cpu-bank.log" 2>&1
fi
export B28_ACTIVE=1 B28_OUTPUT="$job/preflight-unused" ADMISSION_TRACE_DIR="$job/preflight-unused/trace"
python "$job/cpu_prepare.py" preflight > "$job/cpu-preflight.log" 2>&1
