import hashlib, json, os, inspect
from pathlib import Path
import importlib
s=Path(os.environ["SOURCE_ROOT"]);r=s.parent
m=json.loads((r/"manifest.json").read_text())
for f,d in m["files"].items():
    assert hashlib.sha256((s/f).read_bytes()).hexdigest()==d, f
modules={}
for name in ("torch","torch_npu","vllm","vllm_ascend","pypto","simpler","npugraph_ex"):
    mod=importlib.import_module(name); modules[name]={"file":mod.__file__,"version":getattr(mod,"__version__",None)}
if os.environ.get('LOW_ACCEPTANCE_RUNTIME_PACKAGE'):
    package=Path(os.environ['LOW_ACCEPTANCE_RUNTIME_PACKAGE']).resolve()
    assert Path(modules['pypto']['file']).resolve().is_relative_to(package/'pypto')
    from pypto.jit._toolchain import capture_toolchain
    assert capture_toolchain('a2a3','tensormap_and_ringbuffer').usable
    print('PYPTO_TOOLCHAIN_USABLE=1',flush=True)
assert str(s) in modules["vllm_ascend"]["file"]
from vllm_ascend.ops.pypto.variant import variant_package
assert variant_package().endswith("deepseek_v4_flash_csa_tnd_precision_spmd_overlap")
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.service import CSAServiceRuntime
assert CSAServiceRuntime.variable_query_lengths
assert CSAServiceRuntime.single_pto_entry
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.native_adapter import CSAOperators
ops=CSAOperators.register()
assert len(ops.attention._schema.arguments)==64
assert ops.attention._schema.arguments[1].name=='hc_packed_weight'
assert len(ops.workspace.prepare_hc_weight._schema.arguments)==2
assert ops.attention._schema.name=="dsv4_csa_tnd_precision_spmd_overlap::attention"
from offline_pd.connector import OfflineDSV4Connector
assert "return history, False" in inspect.getsource(OfflineDSV4Connector.get_num_new_matched_tokens)
from low_acceptance_20261001.prepare_mixed import questions
assert len(questions())==40 and len(set(q for _,q in questions()))==40
model=Path("/data/model/DeepSeek-V4-Flash-0731-w8a8");idx=json.loads((model/"quant_model_weights.safetensors.index.json").read_text())
shards=set(idx["weight_map"].values());assert len(shards)==75 and all((model/f).is_file() for f in shards)
for name in ("ASCEND_HOME_PATH","ATB_HOME_PATH","PTOAS_ROOT"):
    assert os.environ.get(name),name
assert os.environ["HCCL_DETERMINISTIC"]=="true"
print(json.dumps({"modules":modules,"baseline_source_commit":json.loads((Path(__file__).parent/"production-package.json").read_text())["git_commit"],"env":{k:os.environ.get(k) for k in ("ASCEND_HOME_PATH","ATB_HOME_PATH","PTOAS_ROOT","PTO_CSA_VARIANT","PTO_CSA_RUNTIME")},"model_shards":len(shards),"sync_bank_load":True,"variable_query_lengths":True},indent=2))

from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap import qkv_proj_rope as reduction
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd import qkv_proj_rope as parent_reduction
assert reduction.QR_OK is parent_reduction.QR_OK and reduction.KV_OK is parent_reduction.KV_OK

job = Path(__file__).resolve().parent
candidate = json.loads((job / 'CANDIDATE.json').read_text())
assert hashlib.sha256((r / 'manifest.json').read_bytes()).hexdigest() == candidate['source_manifest_sha256']
assert hashlib.sha256((job / 'runtime77.json').read_bytes()).hexdigest() == candidate['runtime77_sha256']
for suffix in ('deepseek_v4_flash_csa_tnd_precision_spmd_overlap.decode_csa',
               'deepseek_v4_flash_csa_tnd_precision_spmd_overlap.service',
               'deepseek_v4_flash_csa_tnd_precision_spmd_overlap.native_adapter',
               'deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.qkv_precision126'):
    module = importlib.import_module('vllm_ascend.ops.pypto.' + suffix)
    assert Path(module.__file__).resolve().is_relative_to(s.resolve()), (suffix, module.__file__)
qa = importlib.import_module('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.qkv_precision126')
assert qa.QA_NATIVE_PACKET_ROWS == 126 and qa.QA_NATIVE_PACKET_ROWS_B28 == 168
assert hashlib.sha256(Path(qa.__file__).read_bytes()).hexdigest() == candidate['qa_sha256']
receipt = json.loads((job / 'compile-receipt.json').read_text())
assert all(receipt[k] is True for k in ('compiled', 'kernel_abi_pass', 'orchestration_compiled', 'prepare_compiled'))
assert receipt['npu_initialized_after'] is False
assert receipt['source_manifest_sha256'] == candidate['source_manifest_sha256']
assert receipt['runtime77_sha256'] == candidate['runtime77_sha256']
assert receipt['qa_sha256'] == candidate['qa_sha256']
assert receipt['source_root'] == str(s.resolve())
print('CANONICAL_T168_SOURCE_AND_COMPILE_IDENTITY_PASS', json.dumps(candidate), flush=True)
