"""Use exact pinned imports; create new read-only bank links and CPU preflight."""
import argparse
import importlib
import importlib.util
import json
import os
from pathlib import Path
import runpy
import sys

job = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('bank', 'preflight'))
args = parser.parse_args()
assert os.environ['ASCEND_RT_VISIBLE_DEVICES'] == ''
if os.environ['B28_ACTIVE'] == '0':
    bridge = job.parent.parent / 'low-acceptance-20261010/sitecustomize.py'
    spec = importlib.util.spec_from_file_location('canonical_cpu_original_bridge', bridge)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
expected = json.loads((job / 'EXPECTED_ENV.json').read_text())
actual = {}
for name, record in expected['modules'].items():
    m = importlib.import_module(name)
    actual[name] = dict(file=m.__file__, version=getattr(m, '__version__', None))
    assert actual[name] == record, (name, actual[name], record)
for k, v in expected['env'].items(): assert os.environ.get(k) == v, (k, os.environ.get(k), v)
import torch
assert not torch.npu.is_initialized()
if args.mode == 'bank':
    assert os.environ['B28_ACTIVE'] == '0'
    sys.argv = ['prepare_bank.py', '--source', str(job.parent.parent / 'low-acceptance-20261010/banks/fixed8192'), '--bank', str(job / 'bank28')]
    runpy.run_path(str(job / 'prepare_bank.py'), run_name='__main__')
else:
    assert os.environ['B28_ACTIVE'] == '1'
    sys.argv = ['preflight.py', '--bank', str(job / 'bank28'), '--arm', 'native', '--output', str(job / 'preflight-native-cpu.json')]
    runpy.run_path(str(job / 'preflight.py'), run_name='__main__')
assert not torch.npu.is_initialized()
(job / ('CPU_' + args.mode.upper() + '_RECEIPT.json')).write_text(json.dumps(dict(pass_cpu=True, npu_initialized=False, modules=actual, env=expected['env']), indent=2) + '\n')
print('CANONICAL_CPU_' + args.mode.upper() + '_PASS', flush=True)
