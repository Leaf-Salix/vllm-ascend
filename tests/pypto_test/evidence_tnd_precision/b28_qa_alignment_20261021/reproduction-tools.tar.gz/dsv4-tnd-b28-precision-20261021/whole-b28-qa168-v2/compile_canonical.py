"""Compile canonical full root and preparer without touching SDK or NPU."""
import hashlib
import importlib
import importlib.util
import json
import os
from pathlib import Path

job = Path(__file__).resolve().parent
assert os.environ['ASCEND_RT_VISIBLE_DEVICES'] == '' and os.environ['B28_ACTIVE'] == '0'
assert os.environ['CMAKE_BUILD_PARALLEL_LEVEL'] == '4' and os.environ['PYTHONNOUSERSITE'] == '1'
bridge = job.parent.parent / 'low-acceptance-20261010/sitecustomize.py'
spec = importlib.util.spec_from_file_location('canonical_original_sdk_bridge', bridge)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
import torch
import pypto
import pypto.torch
import simpler
from pypto.runtime import RunConfig
from pypto.ir.compile import _compile_impl
from pypto.ir._kernel_compile import kernel_abi_for_program
from pypto.runtime.kernel_compiler import KernelCompiler

sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
s = Path(os.environ['SOURCE_ROOT']).resolve()
proof = json.loads((job / 'CANDIDATE.json').read_text())
assert sha(s.parent / 'manifest.json') == proof['source_manifest_sha256']
assert sha(job / 'runtime77.json') == proof['runtime77_sha256']
for n, d in json.loads((job / 'source-manifest.json').read_text())['files'].items(): assert sha(s / n) == d, n
modules = {}
for name in ('torch', 'torch_npu', 'vllm', 'vllm_ascend', 'pypto', 'simpler', 'npugraph_ex'):
    m = importlib.import_module(name)
    modules[name] = dict(file=m.__file__, version=getattr(m, '__version__', None))
assert str(s / 'vllm_ascend/__init__.py') == modules['vllm_ascend']['file']
assert '/low-acceptance-20261010/runtime-package/pypto/' in pypto.__file__
assert '/pypto-reference/runtime/python/simpler/' in simpler.__file__
assert not torch.npu.is_initialized()
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.decode_csa import decode_csa_tp1_layer_test as entry
from vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.native_adapter import CSAOperators, prepack_fixed_hc_weight
qa = importlib.import_module('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_bf16layout.qkv_precision126')
assert Path(qa.__file__).resolve() == s / proof['changed_path']
assert sha(Path(qa.__file__)) == proof['qa_sha256']
for suffix in ('decode_csa', 'service', 'native_adapter'):
    module = importlib.import_module('vllm_ascend.ops.pypto.deepseek_v4_flash_csa_tnd_precision_spmd_overlap.' + suffix)
    assert Path(module.__file__).resolve().is_relative_to(s)
assert not (job / 'compile-receipt.json').exists()
artifacts = {}
for label, fn in (('attention', entry), ('prepare', prepack_fixed_hc_weight)):
    out = job / ('canonical-' + label + '-artifact')
    fn.compile(config=RunConfig(platform='a2a3', save_kernels=True, save_kernels_dir=str(out)))
    program = fn.specialize()
    abi = kernel_abi_for_program(program, platform='a2a3', runtime='tensormap_and_ringbuffer')
    _compile_impl(program, output_dir=str(job / ('canonical-' + label + '-kernel-artifact')), platform='a2a3', _kernel_abi=abi)
    cpp = list((out / 'orchestration').glob('*.cpp'))
    assert len(cpp) == 1, cpp
    KernelCompiler().compile_orchestration('tensormap_and_ringbuffer', str(cpp[0]))
    artifacts[label] = {str(p.relative_to(job)): sha(p) for p in out.rglob('*') if p.is_file() and p.suffix in ('.py', '.cpp', '.json', '.so')}
operators = CSAOperators.register()
assert len(operators.attention._schema.arguments) == 64
assert operators.attention._schema.arguments[1].name == 'hc_packed_weight'
assert len(operators.workspace.prepare_hc_weight._schema.arguments) == 2
assert operators.attention._schema.name == 'dsv4_csa_tnd_precision_spmd_overlap::attention'
assert not torch.npu.is_initialized()
result = dict(compiled=True, kernel_abi_pass=True, orchestration_compiled=True, prepare_compiled=True, npu_initialized_after=False,
              source_root=str(s), source_manifest_sha256=proof['source_manifest_sha256'], runtime77_sha256=proof['runtime77_sha256'],
              qa_sha256=proof['qa_sha256'], modules=modules, schema=str(operators.attention._schema), prepare_schema=str(operators.workspace.prepare_hc_weight._schema), artifacts=artifacts,
              env={k: os.environ[k] for k in ('ASCEND_HOME_PATH', 'ATB_HOME_PATH', 'PTOAS_ROOT', 'CCACHE_DIR', 'CMAKE_BUILD_PARALLEL_LEVEL', 'PYTHONNOUSERSITE')})
(job / 'compile-receipt.json').write_text(json.dumps(result, indent=2) + '\n')
print('CANONICAL_FULL_ROOT_AND_PREPARER_COMPILE_PASS', flush=True)
