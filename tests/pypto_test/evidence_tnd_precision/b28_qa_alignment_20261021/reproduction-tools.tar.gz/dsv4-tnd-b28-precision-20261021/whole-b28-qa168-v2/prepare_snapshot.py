"""Clone only the sealed manifest files and change one canonical QA file."""
import hashlib
import json
from pathlib import Path
import shutil

job = Path(__file__).resolve().parent
old = Path('/data/pyptouser/yejia/vllm-nalinaly-tnd-20261008-codex/precision-overlap-20261020/whole-overlap-v1/snapshot')
new = job / 'snapshot'
assert not new.exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
proof = json.loads((job / 'CANDIDATE.json').read_text())
assert sha(old / 'manifest.json') == proof['original_source_sha256']
m = json.loads((old / 'manifest.json').read_text())['files']
new_m = json.loads((job / 'source-manifest.json').read_text())['files']
assert len(m) == len(new_m) == 3399 and m.keys() == new_m.keys()
assert [n for n in m if m[n] != new_m[n]] == [proof['changed_path']]
for name, digest in m.items():
    src = old / 'source' / name
    assert sha(src) == digest, name
    dest = new / 'source' / name
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)
    if name == proof['changed_path']:
        assert sha(job / 'canonical-qkv.py') == new_m[name]
        shutil.copy2(job / 'canonical-qkv.py', dest)
    assert sha(dest) == new_m[name], name
shutil.copy2(job / 'source-manifest.json', new / 'manifest.json')
print('SNAPSHOT_3399_ONE_FILE_CHANGE_PASS')
