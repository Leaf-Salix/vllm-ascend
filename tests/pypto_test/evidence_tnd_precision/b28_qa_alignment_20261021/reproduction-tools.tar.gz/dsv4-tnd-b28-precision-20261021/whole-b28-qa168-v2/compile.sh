#!/usr/bin/env bash
set -euo pipefail
job=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source "$job/env.sh"
export ASCEND_RT_VISIBLE_DEVICES='' TORCH_DEVICE_BACKEND_AUTOLOAD=0 B28_ACTIVE=0
export PYTHONPATH="$LOW_ACCEPTANCE_RUNTIME_PACKAGE:$job${PYTHONPATH:+:$PYTHONPATH}"
export PYPTO_PROG_BUILD_DIR="$job/compile-build" PYPTO_CACHE_DIR="$job/compile-cache"
ccache -s > "$job/ccache-before.txt"
timeout --signal=TERM --kill-after=20s 750s python "$job/compile_canonical.py" > "$job/compile.log" 2>&1
