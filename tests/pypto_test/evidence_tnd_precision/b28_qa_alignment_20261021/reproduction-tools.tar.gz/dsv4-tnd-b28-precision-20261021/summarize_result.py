"""Read diagnostic JSON only; never load model weights or touch NPU."""
import json
import sys
from pathlib import Path
p=Path(sys.argv[1]);r=json.loads(p.read_text())
summary={k:r.get(k) for k in ('diagnostic_complete','error','original_output_invariance','readonly_after_diagnostic','debug_guards_pass','stage_comparisons','row_comparisons')}
print(json.dumps(summary,indent=2,ensure_ascii=False))
