# Canonical T168补丁与整模型helper初审

**仅源码准备通过；canonical编译及整模型资格仍待完成。**

- 正式运行源码只有QA文件变化；126/168具名常量值已独立核对。忽略文档并内联两常量后，
  与已实测private v2 QKV的AST完全一致。既有packet helper数学未修改。
- 3399源文件manifest、77项runtime集合不变，仅该QA文件SHA变化；正式文件与canonical副本字节相同。
- 原whole-b28-next的bank/token/入场轨迹、16rank、warm192+192、172032 tokens、
  Native重复和gold防改、全21CSA真PTO/64Tensor/20HCA原生、首差停止门禁均未变（原helper对应字节相同）。
- source_preflight保留原完整全文，再追加新manifest/77源身份、真实import限定新snapshot、
  126/168常量及编译收据的强断言。不能把旧snapshot导入标成新canonical。

发现并已通知父线程修复一个设备前阻断：builder原用绝对路径replace，原env却是字面`$base/...`，
替换未命中。当前builder及实际env已改为新snapshot绝对路径；旧路径不会因放松门禁获准。

本次读取时尚无新compile-receipt/helper-manifest。必须等canonical program/kernelABI/orchestration
及prepare编译成功、实际新snapshot导入通过、manifest齐备后再判断可否启动；当前不代表新token或性能结果。
旧PROVENANCE/production-package只描述父基线，active新身份以CANDIDATE、两个manifest及新编译收据为准。

仅本地只读审查，未运行构建器、未修改正式源、未访问227或提交设备任务。
