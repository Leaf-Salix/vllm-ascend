# B28 QA 候选的独立整模型集成方案

## 建议

**创建新的整模型 source snapshot，保留现有 overlap 包名和64参数接口，仅把已通过小门禁的 T168 QA 路由合入新 snapshot 的 `qkv_precision126.py`。** 新建 whole helper 副本，Native1、候选 PTO 都由该副本运行。原正式 checkout、旧 snapshot、现有22份 helper、Native金值及旧验收环境保持封存。

这样无需给正式环境安装包，也不需要新增注册 namespace 或 monkey-patch `CSAOperators`。T126及其它行数仍走原路由；full root 的64参数、`hc_packed_weight`、2560 order packet、HC-pre→HC-post范围和真正TND布局不变。

本报告只读源码与已有JSON，没有连接远端、执行编译、读取模型Tensor或提交NPU。小候选当前仅准备完成，以下内容不是硬件通过声明。

## 已核实的身份和阻断

| 项目 | 当前值或规则 |
|---|---|
| 正式 Git HEAD | `1bc33a4b4c06861de208f5add7fa5db4b338a862`，读取时工作区干净 |
| 旧 whole 源清单 | 3399文件；manifest SHA `b229b29c69dc4aec637f99d586c1b68bafc9cc28cec9ebae2f54483baf1cdd4c` |
| runtime清单 | 77文件；`runtime77.json` SHA `be620d32d11eeb4d4afc7217fdfbfa4b04f3579a7982a431904662f77c2ed158`，全部在3399清单中且SHA相同 |
| 封存 whole helper | 22文件，manifest SHA `e2cf7ff68d10c10b3b80d0384aec45abdbc777f30ba738f00caa52cfaef414ec`；本次逐文件验证一致 |
| 原 QA helper | `spmd_bf16layout/qkv_precision126.py`，SHA `4811033e502518bcf6e5dcb05bbc936fc5f35a287c51ca41997034f2cc8693b4` |
| 当前私有 QA 候选 | `full-fix-next/full_fix_qkv.py`，记录SHA `be6861b5271f868020c4adc943cebc5691d9a2c86a73a7599f44c1ee05c9cc7a`；只把 `tile_rows ==126` 扩成 `tile_rows ==126 or tile_rows ==168` |
| 当前私有 full root | 只改变QA helper导入，保留完整64参数；记录SHA `d33239b5fdf7fc635c828366b46f8d9c3a4a891436d0b1e22e7a92f64cfe31c0` |

`full-fix-next/SOURCE_PROOF.json` 是准备期证明，不能代替 actual compile receipt 或硬件门禁。冻结候选时需再次核对SHA，不能默认这里读取到的准备期字节就是最终字节。

原 whole helper 有以下强绑定，**不能只 export 新 `SPMD_EXPERIMENT` 后直接运行**：

1. `env.sh` 硬写旧 `SOURCE_ROOT`，并用它构造 `PYTHONPATH`。
2. `preflight.py` 要求 `SOURCE_ROOT.parent/manifest.json` 与 helper 中的 `source-manifest.json` 逐字节同SHA，同时对77份运行源逐SHA复核。
3. `source_preflight.py` 会完整校验3399文件，并直接导入 overlap 的 service/adapter，检查64参数namespace。
4. `qualified_wkv.py`、`mixed_b28.py`、`audit.py` 都明确检查 overlap service/namespace，不能悄悄换成另一私有root却继续沿用旧标签。
5. PTO preflight 要求 Native1 的 READY 中 helper SHA、source manifest SHA和本次完全相同；audit也要求两臂配置除backend外相同。

## 最小 source 集成步骤

以下是未来执行者的准备顺序；本报告没有执行它们。

1. 等 QA-only base/packet A/B、小候选完整64 root门禁完成。若首差未清楚，先定位，不进入整模型。
2. 从已冻结旧 whole snapshot 创建独立副本，例如新实验目录的 `snapshot/source`。原 snapshot 是复现基础，不能直接用当前 Git checkout 全量覆盖它：原3399清单还包含已验收的扩展bank connector/runner，当前checkout的同名harness不一定相同。
3. **只替换一份现有文件：**把已测 `full_fix_qkv.py` 的路由改动以相同包路径放入新 snapshot 的 `spmd_bf16layout/qkv_precision126.py`；保持 overlap `decode_csa.py` 原导入不变。无需把两个私有顶层文件名带进生产导入树。
4. 比较规范 AST：新 canonical QA 文件应等于已验收私有 QA 候选；`q_proj_qa_126` body不变，只有路由条件多T168；原T126及其它T的分支、K512包内两个K256次序、实际T168→176 staging尾部处理都保持。root、其余76份runtime源和3398份snapshot文件逐字节不变。
5. 重新生成新 `snapshot/manifest.json` 与新 `runtime77.json`，候选仍为3399/77文件。新 helper 的 `source-manifest.json` 必须与新 snapshot manifest 字节相同。新77列表只允许该一项SHA变化；记录旧manifest、旧77数学摘要和新摘要，不能继续把候选标成旧 `math48c58c`。
6. 新 manifest元数据记录 `base_snapshot_manifest_sha256`、正式Git基线 `1bc33a4b4`、单文件patch SHA及候选身份。旧 manifest 的历史 `baseline_git_commit/candidate_patch_sha256` 不能不加解释就当作新活动源身份；可保留在历史provenance字段中。
7. 在新 source 路径上做完整64 root的actual orchestration GCC及CCEC，保存新compile receipt。小候选的receipt可作数学前驱证明，但它的私有模块名/文件路径不等于canonical whole source，不能直接冒充后者的编译收据。

新receipt至少绑定：新3399manifest SHA、77份运行源摘要、canonical root及QA文件SHA、root模块/64参数次序、固定PyPTO/Simpler/toolchain身份、actual生成 `kernel_config.py`/orchestration及相关kernel SHA、GCC/CCEC完成状态。编译后到提交前再次复核所有源未变。

## whole helper 的最少变动

从封存22文件复制到新目录，例如 `whole-b28-qa168-candidate`，只在新副本修改。

| 文件/身份 | 必要处理 |
|---|---|
| `env.sh` | 新 `SOURCE_ROOT`；`PYTHONPATH`最前为新job、新source及其tests；保留同Python/SDK/CANN和原确定性设置 |
| `source-manifest.json`、`runtime77.json` | 更新为新候选source的实际清单 |
| 候选provenance | 同时记录原封存helper/source身份、新patch/compile receipt身份；不能只打印旧 `production-package.json` 中的历史commit作为活动候选身份 |
| `preflight.py/source_preflight.py` | 原有完整源、接口、模型/工具链、bank检查保留；新增canonical QA实际导入路径及SHA/route证明，并绑定新compile receipt |
| `helper-manifest.json` | 所有修改/新增文件完成后重建；旧22文件清单和SHA另行保留，不能覆盖 |
| `run-arm.sh` | 可以保留相对 `$job` 的结果与bank路径；新目录自然产生独立 `results/native1`、`results/pto1`，旧输出不动 |
| 静态资格与审计 | 包名不变时 `qualified_wkv.py/mixed_b28.py/audit.py` 的64namespace、21CSA/20Native HCA等检查可原字节保留 |

`SPMD_EXPERIMENT` 若无执行期消费者，建议显式 unset，防止继承旧实验。若固定bootstrap仍需要它，则设为新候选实验根，**同时**保留实际模块导入路径检查；该变量本身不是source身份。至少核对 `vllm_ascend.__file__`、overlap `decode_csa/service/native_adapter`、`spmd_bf16layout.qkv_precision126.__file__` 都解析到新 SOURCE_ROOT，并记录QA函数的源文件/全局依赖。只验证磁盘77份文件哈希、但实际从别处import，并不足以防混源。

不得复用 `cpu_prepare_whole.py` 的旧绝对模块绑定而静默跳过失败；若使用其验证思路，需要新副本中把活动 `vllm_ascend` 路径改成新source，其他SDK/venv路径不变。CPU预检保持 `ASCEND_RT_VISIBLE_DEVICES=''`、`TORCH_DEVICE_BACKEND_AUTOLOAD=0` 并最终断言未初始化NPU。

## Native1 → PTO 的运行和验收

- 同一新whole helper/source身份，先Native1，READY通过后再PTO。Native臂虽然不执行PTO数学，也使用新snapshot里其余逐字节相同的Native实现，因此不会与旧READY的source SHA冲突。
- 两臂都取旧8K固定bank的前28个不同key，只创建新plan/只读链接；按现有header/owner/token/manifest资格确认，不复制权重cache、不重新prefill。
- 每臂16卡，TP1、DP=EP16，greedy，DSpark出5验6，192 warm＋192正式，capture `[6,168]`，NZ2，level1/HCCL确定性，EPLB关闭，22000 blocks、budget400；内层750s、task max780s。首次JIT可能增加耗时；若预计超时，先无设备预编，不能放宽15分钟上限。
- Native1应在同一次模型加载内比较warm/正式轮，不能自动追加Native2。PTO逐轮对相应Native1输出比较；全部16rank×28请求×两轮×192 token，即172032 token。
- 保留真实全28活跃/T168/FULL168及DP向量覆盖、零抢占、21个CSA确实走PTO且20个HCA保持Native、warmup/capture资格、静态包/reselection与无fallback门禁。
- 首个token差异立即保存request/position与已有轨迹并停止，不继续大配置。无需为了内部bit全零阻塞已授权的token门禁，也不能把本次L4的QA顺序匹配当成其它20个CSA层或真实模型已经通过。
- 分开报告 `tokens_equal/events_equal/full_input_trace_equal`。当前封存audit会把token一致而事件/轨迹不同标为 `TOKENS_EQUAL_PROTOCOL_DIFFERENCE` 并返回失败；这种情况不能写成token失败，也不能不审查差异就声称同输入对拍通过。

## 为什么不优先私有新 namespace

若保留 `full_fix_qkv/full_fix_root` 两个新模块并新增服务namespace，就至少改变source文件集合（不再3399/77）、注册选择、service资格桥、实现类后缀、root namespace及审计配置，并让Native1/PTO使用不同活动source成为可能。也可以安全实现，但没有必要为一条已经限定在T168的路由新增这些集成变量。

本方案的成功门槛是：**新source身份闭环、canonical完整root编译通过、Native1重复可复现、PTO在相同真实入场轨迹下逐token一致。** 已验收旧8K/B40和128K/B24的资格作为基准保留；新8K/B28通过不能自动推广到任意prompt、任意T或新的128K/B28。
