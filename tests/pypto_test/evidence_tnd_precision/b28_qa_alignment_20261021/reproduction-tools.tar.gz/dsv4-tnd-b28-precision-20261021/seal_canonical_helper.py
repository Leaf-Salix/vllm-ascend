"""Seal prepared sources only after canonical actual compile; result files excluded."""
import hashlib
import json
from pathlib import Path
r=Path(__file__).resolve().parent
job=r/'whole-b28-qa168-v2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=json.loads((job/'CANDIDATE.json').read_text())
c=json.loads((job/'compile-receipt.json').read_text())
assert all(c[k] is True for k in ('compiled','kernel_abi_pass','orchestration_compiled','prepare_compiled'))
assert c['npu_initialized_after'] is False
for k in ('qa_sha256','source_manifest_sha256','runtime77_sha256'):assert c[k]==p[k], k
formal=r.parent.parent/'vllm-ascend-nalinaly-tnd-20261008-codex'/p['changed_path']
assert sha(formal)==sha(job/'canonical-qkv.py')==p['qa_sha256']
old=json.loads((r/'whole-b28-next/helper-manifest.json').read_text())['files']
extra=['CANDIDATE.json','EXPECTED_ENV.json','canonical-qkv.py','prepare_snapshot.py','compile_canonical.py','compile.sh','cpu_prepare.py','cpu_prepare.sh','compile-receipt.json','test_local.py']
names=sorted(set(old)|set(extra))
obj=dict(status='CANONICAL_COMPILED_PREPARED_FOR_CPU_PREFLIGHT', files={n:sha(job/n) for n in names}, predecessor_helper_sha256=sha(r/'whole-b28-next/helper-manifest.json'))
(job/'helper-manifest.json').write_text(json.dumps(obj,indent=2)+'\n')
print(len(names),sha(job/'helper-manifest.json'),p['qa_sha256'])
