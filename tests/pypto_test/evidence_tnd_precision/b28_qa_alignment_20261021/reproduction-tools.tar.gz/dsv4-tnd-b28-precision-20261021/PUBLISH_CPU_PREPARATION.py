"""保存本轮准备/CPU证据，明确没有新增硬件token结果。"""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

here=Path(__file__).resolve().parent
repo=here.parents[1]/'vllm-ascend-nalinaly-tnd-20261008-codex'
out=repo/'tests/pypto_test/evidence_tnd_precision/b28_token_preparation_20261021'
out.mkdir(exist_ok=False)
for name in ('cpu-whole-preparation-evidence.tar.gz','REMOTE_CPU_PREPARATION_RECHECK.json',
             'HISTORICAL_INPUT_CPU.json','BASELINE_ENVIRONMENT_BOUND.json','STATIC_REVIEW.json',
             'compile-receipt.json'):
    shutil.copy2(here/name,out/name)
with tarfile.open(out/'whole-b28-tools.tar.gz','w:gz') as tar:
    folders=['whole-b28-next','review-whole-b28']
    for folder in folders:
        for path in sorted((here/folder).rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts and not path.name.startswith('._') and path.name!='.DS_Store':
                tar.add(path,arcname=str(path.relative_to(here)),recursive=False)
    for name in ('cpu_prepare_whole.py','cpu_prepare_whole.sh','recheck_cpu_preparation.py','compare_historical_cpu.py',
                 'TOKEN_ACCEPTANCE_REVIEW.md','HOOK_INSTALL_REVIEW.md','HOOK_INSTALL_PROBE.json'):
        tar.add(here/name,arcname=name)
with tarfile.open(out/'stage-diagnostic-prepared-tools.tar.gz','w:gz') as tar:
    for name in ('b28_root.py','b28_indexer.py','b28_exports.py','exports.json','compile_diagnostic.py',
                 'compile.sh','run.sh','preflight.py','static_review.py','STATIC_REVIEW.json',
                 'INDEPENDENT_SOURCE_REVIEW.json','INDEPENDENT_SOURCE_REVIEW.md'):
        tar.add(here/name,arcname=name)
    for path in sorted((here/'tools').glob('*')):
        if path.is_file():tar.add(path,arcname='tools/'+path.name)
(out/'SHA256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir())},indent=2)+'\n')
print(out)
